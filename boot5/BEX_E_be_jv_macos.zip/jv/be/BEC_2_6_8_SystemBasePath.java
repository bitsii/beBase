package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(216108691);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-1755209627, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 384 */ {
bevt_4_tmpany_phold = bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 385 */
bevt_5_tmpany_phold = beva_other.bemd_0(1165865394);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 387 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-1406264904);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 388 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(216108691);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(-1408765800, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 392 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 392 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 394 */
 else  /* Line: 392 */ {
break;
} /* Line: 392 */
} /* Line: 392 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = bem_copy_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 410 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 410 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 411 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 412 */
 else  /* Line: 413 */ {
bevl_i.bem_nextGet_0();
} /* Line: 414 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 416 */
 else  /* Line: 410 */ {
break;
} /* Line: 410 */
} /* Line: 410 */
bevt_4_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 418 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 419 */
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 425 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 425 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 425 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 425 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 425 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 425 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 425 */
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 427 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 433 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 434 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 440 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 445 */ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 450 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 450 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 451 */ {
break;
} /* Line: 451 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 450 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 456 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 468 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 469 */
 else  /* Line: 470 */ {
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 471 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 477 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 477 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 478 */
 else  /* Line: 477 */ {
break;
} /* Line: 477 */
} /* Line: 477 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 517 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(-599428669, this);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 517 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(216108691);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 517 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 517 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 518 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 529 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 530 */
 else  /* Line: 531 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 532 */
bevl_res = bem_create_0();
bevl_res.bemd_1(-1613971284, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-401206484, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public final BEC_2_4_6_TextString bem_separatorGetDirect_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_2_4_6_TextString bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {345, 345, 349, 350, 354, 358, 362, 362, 366, 367, 367, 368, 372, 372, 376, 376, 376, 380, 380, 380, 384, 384, 384, 384, 385, 385, 387, 388, 388, 390, 391, 391, 392, 392, 393, 394, 396, 396, 397, 398, 400, 404, 405, 406, 406, 407, 408, 409, 410, 410, 411, 411, 412, 412, 414, 416, 418, 419, 421, 425, 425, 0, 425, 425, 425, 425, 425, 0, 0, 425, 425, 426, 426, 426, 427, 427, 429, 429, 433, 434, 434, 434, 439, 439, 439, 440, 445, 445, 445, 446, 447, 449, 450, 450, 450, 451, 451, 452, 453, 454, 450, 456, 461, 462, 463, 467, 468, 468, 469, 469, 471, 471, 471, 471, 476, 477, 477, 478, 478, 480, 484, 484, 488, 489, 490, 491, 495, 496, 497, 497, 498, 502, 502, 506, 506, 510, 510, 510, 517, 517, 0, 517, 0, 0, 0, 517, 517, 0, 0, 518, 518, 520, 520, 524, 524, 528, 529, 529, 530, 532, 534, 535, 536, 536, 536, 537, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 28, 29, 33, 37, 41, 42, 48, 49, 50, 51, 55, 56, 61, 62, 63, 68, 69, 70, 89, 90, 91, 92, 94, 95, 97, 99, 100, 102, 103, 104, 105, 108, 110, 111, 117, 118, 119, 120, 121, 134, 135, 136, 137, 138, 139, 140, 141, 144, 146, 151, 152, 153, 156, 158, 164, 166, 168, 183, 188, 189, 192, 193, 194, 195, 200, 201, 204, 208, 209, 211, 212, 213, 215, 216, 218, 219, 225, 227, 228, 229, 236, 237, 242, 243, 256, 257, 262, 263, 264, 265, 266, 269, 274, 275, 280, 283, 284, 285, 286, 292, 298, 299, 300, 310, 311, 316, 317, 318, 321, 322, 323, 324, 333, 334, 337, 339, 340, 346, 351, 352, 356, 357, 358, 359, 365, 366, 367, 368, 369, 373, 374, 378, 379, 384, 385, 390, 401, 406, 407, 410, 412, 415, 419, 422, 423, 425, 428, 432, 433, 435, 436, 440, 441, 450, 451, 456, 457, 460, 462, 463, 464, 465, 466, 467, 470, 473, 476, 480, 484, 487, 490, 494};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 345 23
new 0 345 23
new 1 345 24
assign 1 349 28
new 0 349 28
fromString 1 350 29
assign 1 354 33
return 1 358 37
assign 1 362 41
toStringWithSeparator 1 362 41
return 1 362 42
assign 1 366 48
split 1 366 48
assign 1 367 49
new 0 367 49
assign 1 367 50
join 2 367 50
return 1 368 51
assign 1 372 55
split 1 372 55
return 1 372 56
assign 1 376 61
split 1 376 61
assign 1 376 62
firstGet 0 376 62
return 1 376 63
assign 1 380 68
split 1 380 68
assign 1 380 69
lastGet 0 380 69
return 1 380 70
assign 1 384 89
pathGet 0 384 89
assign 1 384 90
new 0 384 90
assign 1 384 91
emptyGet 0 384 91
assign 1 384 92
equals 1 384 92
assign 1 385 94
copy 0 385 94
return 1 385 95
assign 1 387 97
isAbsoluteGet 0 387 97
assign 1 388 99
copy 0 388 99
return 1 388 100
assign 1 390 102
split 1 390 102
assign 1 391 103
pathGet 0 391 103
assign 1 391 104
split 1 391 104
assign 1 392 105
linkedListIteratorGet 0 392 105
assign 1 392 108
hasNextGet 0 392 108
assign 1 393 110
nextGet 0 393 110
addValue 1 394 111
assign 1 396 117
new 0 396 117
assign 1 396 118
join 2 396 118
assign 1 397 119
copy 0 397 119
assign 1 398 120
fromString 1 398 120
return 1 400 121
assign 1 404 134
split 1 404 134
assign 1 405 135
copy 0 405 135
assign 1 406 136
new 0 406 136
pathSet 1 406 137
assign 1 407 138
lengthGet 0 407 138
assign 1 408 139
decrement 0 408 139
assign 1 409 140
new 0 409 140
assign 1 410 141
linkedListIteratorGet 0 410 141
assign 1 410 144
hasNextGet 0 410 144
assign 1 411 146
lesser 1 411 151
assign 1 412 152
nextGet 0 412 152
addStep 1 412 153
nextGet 0 414 156
assign 1 416 158
increment 0 416 158
assign 1 418 164
isAbsoluteGet 0 418 164
makeAbsolute 0 419 166
return 1 421 168
assign 1 425 183
undef 1 425 188
assign 1 0 189
assign 1 425 192
toString 0 425 192
assign 1 425 193
sizeGet 0 425 193
assign 1 425 194
new 0 425 194
assign 1 425 195
lesser 1 425 200
assign 1 0 201
assign 1 0 204
assign 1 425 208
new 0 425 208
return 1 425 209
assign 1 426 211
new 0 426 211
assign 1 426 212
getPoint 1 426 212
assign 1 426 213
equals 1 426 213
assign 1 427 215
new 0 427 215
return 1 427 216
assign 1 429 218
new 0 429 218
return 1 429 219
assign 1 433 225
isAbsoluteGet 0 433 225
assign 1 434 227
new 0 434 227
assign 1 434 228
sizeGet 0 434 228
assign 1 434 229
substring 2 434 229
assign 1 439 236
isAbsoluteGet 0 439 236
assign 1 439 237
not 0 439 242
assign 1 440 243
add 1 440 243
assign 1 445 256
new 0 445 256
assign 1 445 257
greater 1 445 262
makeNonAbsolute 0 446 263
assign 1 447 264
split 1 447 264
assign 1 449 265
firstNodeGet 0 449 265
assign 1 450 266
new 0 450 266
assign 1 450 269
lesser 1 450 274
assign 1 451 275
undef 1 451 280
assign 1 452 283
assign 1 453 284
nextGet 0 453 284
delete 0 454 285
assign 1 450 286
increment 0 450 286
assign 1 456 292
join 2 456 292
assign 1 461 298
split 1 461 298
addValue 1 462 299
assign 1 463 300
join 2 463 300
assign 1 467 310
find 1 467 310
assign 1 468 311
undef 1 468 316
assign 1 469 317
new 0 469 317
assign 1 469 318
emptyGet 0 469 318
assign 1 471 321
new 0 471 321
assign 1 471 322
add 1 471 322
assign 1 471 323
sizeGet 0 471 323
assign 1 471 324
substring 2 471 324
assign 1 476 333
split 1 476 333
assign 1 477 334
linkedListIteratorGet 0 477 334
assign 1 477 337
hasNextGet 0 477 337
assign 1 478 339
nextGet 0 478 339
addValue 1 478 340
assign 1 480 346
join 2 480 346
assign 1 484 351
addStep 1 484 351
return 1 484 352
assign 1 488 356
split 1 488 356
addValue 1 489 357
addValue 1 490 358
assign 1 491 359
join 2 491 359
assign 1 495 365
create 0 495 365
copyTo 1 496 366
assign 1 497 367
copy 0 497 367
pathSet 1 497 368
return 1 498 369
assign 1 502 373
split 1 502 373
return 1 502 374
assign 1 506 378
hashGet 0 506 378
return 1 506 379
assign 1 510 384
equals 1 510 384
assign 1 510 385
not 0 510 390
return 1 510 390
assign 1 517 401
undef 1 517 406
assign 1 0 407
assign 1 517 410
otherType 1 517 410
assign 1 0 412
assign 1 0 415
assign 1 0 419
assign 1 517 422
pathGet 0 517 422
assign 1 517 423
notEquals 1 517 423
assign 1 0 425
assign 1 0 428
assign 1 518 432
new 0 518 432
return 1 518 433
assign 1 520 435
new 0 520 435
return 1 520 436
assign 1 524 440
subPath 2 524 440
return 1 524 441
assign 1 528 450
stepsGet 0 528 450
assign 1 529 451
undef 1 529 456
assign 1 530 457
subList 1 530 457
assign 1 532 460
subList 2 532 460
assign 1 534 462
create 0 534 462
separatorSet 1 535 463
assign 1 536 464
new 0 536 464
assign 1 536 465
join 2 536 465
pathSet 1 536 466
return 1 537 467
return 1 0 470
return 1 0 473
assign 1 0 476
assign 1 0 480
return 1 0 484
return 1 0 487
assign 1 0 490
assign 1 0 494
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1769189372: return bem_deserializeClassNameGet_0();
case -621270081: return bem_new_0();
case 51820034: return bem_pathGetDirect_0();
case -579194210: return bem_iteratorGet_0();
case 1353351142: return bem_firstStepGet_0();
case 1568711247: return bem_fieldIteratorGet_0();
case -1489022328: return bem_once_0();
case 1708718977: return bem_stepsGet_0();
case 572016682: return bem_serializationIteratorGet_0();
case 1476265575: return bem_toAny_0();
case 448246445: return bem_fieldNamesGet_0();
case -1168657718: return bem_create_0();
case -1406264904: return bem_copy_0();
case 11313755: return bem_echo_0();
case -1312786198: return bem_parentGet_0();
case -1682958828: return bem_tagGet_0();
case -165278261: return bem_hashGet_0();
case -1828907031: return bem_separatorGet_0();
case -1620245992: return bem_separatorGetDirect_0();
case 216108691: return bem_pathGet_0();
case -1470549734: return bem_lastStepGet_0();
case -558564135: return bem_makeAbsolute_0();
case -1534221363: return bem_stepListGet_0();
case -1791746868: return bem_print_0();
case -1430069919: return bem_serializeContents_0();
case 1925591260: return bem_makeNonAbsolute_0();
case -1976261358: return bem_deleteFirstStep_0();
case -1045898755: return bem_classNameGet_0();
case 334571614: return bem_many_0();
case 2079582721: return bem_toString_0();
case -980602152: return bem_sourceFileNameGet_0();
case 1165865394: return bem_isAbsoluteGet_0();
case 577869439: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 328965551: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
case -1613971284: return bem_separatorSet_1(bevd_0);
case -1118052196: return bem_pathSetDirect_1(bevd_0);
case -44302587: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case 1006658103: return bem_add_1(bevd_0);
case 663654715: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -499286587: return bem_addSteps_1(bevd_0);
case -401206484: return bem_pathSet_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case 397748575: return bem_separatorSetDirect_1(bevd_0);
case 1171039333: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case 2146382080: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1093191041: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1555754785: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1575308838: return bem_addStep_1(bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 229085396: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -404743667: return bem_addSteps_2(bevd_0, bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
