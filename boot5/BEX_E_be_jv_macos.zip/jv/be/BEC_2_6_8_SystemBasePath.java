package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevl_fpath = bem_stepListGet_0();
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_ta_ph.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_9_TextTokenizer bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_tokenize_1(bevp_path);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_stepListGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_stepListGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_8_SystemBasePath bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_7_TextStrings bevt_8_ta_ph = null;
bevt_1_ta_ph = beva_other.bemd_0(-417450064);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-1472371585, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 83*/ {
bevt_4_ta_ph = bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_ta_ph;
} /* Line: 84*/
bevt_5_ta_ph = beva_other.bemd_0(1909729056);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 86*/ {
bevt_6_ta_ph = beva_other.bemd_0(187681083);
return (BEC_2_6_8_SystemBasePath) bevt_6_ta_ph;
} /* Line: 87*/
bevl_fpath = bem_stepListGet_0();
bevl_spath = (BEC_2_9_10_ContainerLinkedList) beva_other.bemd_0(-556606602);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 91*/ {
bevt_7_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 91*/ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 93*/
 else /* Line: 91*/ {
break;
} /* Line: 91*/
} /* Line: 91*/
bevt_8_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_8_ta_ph.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_fpath = bem_stepListGet_0();
bevl_rpath = bem_copy_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_ta_ph);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 109*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 109*/ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_3_ta_ph = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_ta_ph);
} /* Line: 111*/
 else /* Line: 112*/ {
bevl_i.bem_nextGet_0();
} /* Line: 113*/
bevl_c = bevl_c.bem_increment_0();
} /* Line: 115*/
 else /* Line: 109*/ {
break;
} /* Line: 109*/
} /* Line: 109*/
bevt_4_ta_ph = bem_isAbsoluteGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 117*/ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 118*/
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (bevp_path == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 124*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 124*/ {
bevt_4_ta_ph = bevp_path.bem_toString_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_sizeGet_0();
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 124*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 124*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 124*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 124*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 124*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bevp_path.bem_getPoint_1(bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_equals_1(bevp_separator);
if (bevt_7_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 126*/
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 132*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 133*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_isAbsoluteGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 138*/ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 139*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_howMany.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 144*/ {
bem_makeNonAbsolute_0();
bevl_fpath = bem_stepListGet_0();
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 149*/ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 149*/ {
if (bevl_next == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 150*/ {
break;
} /* Line: 150*/
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 149*/
 else /* Line: 149*/ {
break;
} /* Line: 149*/
} /* Line: 149*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 155*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bem_stepListGet_0();
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_ta_ph.bem_emptyGet_0();
} /* Line: 168*/
 else /* Line: 169*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevl_fp.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_ta_ph, bevt_4_ta_ph);
} /* Line: 170*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_fpath = bem_stepListGet_0();
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
/* Line: 176*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 176*/ {
bevt_1_ta_ph = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_ta_ph);
} /* Line: 177*/
 else /* Line: 176*/ {
break;
} /* Line: 176*/
} /* Line: 176*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_addStep_1(beva_step);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bem_stepListGet_0();
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_stepListGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_hashGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_x == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 213*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 213*/ {
bevt_4_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_3_ta_ph = bevt_4_ta_ph.bem_otherType_2(beva_x, this);
if (bevt_3_ta_ph.bevi_bool)/* Line: 213*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 213*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 213*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 213*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 213*/ {
bevt_6_ta_ph = beva_x.bemd_0(-417450064);
bevt_5_ta_ph = bevp_path.bem_notEquals_1(bevt_6_ta_ph);
if (bevt_5_ta_ph.bevi_bool)/* Line: 213*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 213*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 213*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 213*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 214*/
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_subPath_2(beva_start, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 225*/ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 226*/
 else /* Line: 227*/ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 228*/
bevl_res = bem_create_0();
bevl_res.bemd_1(-865732216, bevp_separator);
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(347154355, bevt_1_ta_ph);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {44, 44, 48, 49, 53, 57, 61, 61, 65, 66, 66, 67, 71, 71, 71, 75, 75, 75, 79, 79, 79, 83, 83, 83, 83, 84, 84, 86, 87, 87, 89, 90, 91, 91, 92, 93, 95, 95, 96, 97, 99, 103, 104, 105, 105, 106, 107, 108, 109, 109, 110, 110, 111, 111, 113, 115, 117, 118, 120, 124, 124, 0, 124, 124, 124, 124, 124, 0, 0, 124, 124, 125, 125, 125, 126, 126, 128, 128, 132, 133, 133, 133, 138, 138, 138, 139, 144, 144, 144, 145, 146, 148, 149, 149, 149, 150, 150, 151, 152, 153, 149, 155, 160, 161, 162, 166, 167, 167, 168, 168, 170, 170, 170, 170, 175, 176, 176, 177, 177, 179, 183, 183, 187, 188, 189, 190, 194, 195, 196, 196, 197, 201, 201, 205, 205, 209, 209, 209, 213, 213, 0, 213, 213, 0, 0, 0, 213, 213, 0, 0, 214, 214, 216, 216, 220, 220, 224, 225, 225, 226, 228, 230, 231, 232, 232, 232, 233, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 23, 24, 28, 32, 36, 37, 43, 44, 45, 46, 51, 52, 53, 58, 59, 60, 65, 66, 67, 85, 86, 87, 88, 90, 91, 93, 95, 96, 98, 99, 100, 103, 105, 106, 112, 113, 114, 115, 116, 129, 130, 131, 132, 133, 134, 135, 136, 139, 141, 146, 147, 148, 151, 153, 159, 161, 163, 178, 183, 184, 187, 188, 189, 190, 195, 196, 199, 203, 204, 206, 207, 208, 210, 211, 213, 214, 220, 222, 223, 224, 231, 232, 237, 238, 251, 252, 257, 258, 259, 260, 261, 264, 269, 270, 275, 278, 279, 280, 281, 287, 293, 294, 295, 305, 306, 311, 312, 313, 316, 317, 318, 319, 328, 329, 332, 334, 335, 341, 346, 347, 351, 352, 353, 354, 360, 361, 362, 363, 364, 368, 369, 373, 374, 379, 380, 385, 397, 402, 403, 406, 407, 409, 412, 416, 419, 420, 422, 425, 429, 430, 432, 433, 437, 438, 447, 448, 453, 454, 457, 459, 460, 461, 462, 463, 464, 467, 470, 474, 477};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 44 18
new 0 44 18
new 1 44 19
assign 1 48 23
new 0 48 23
fromString 1 49 24
assign 1 53 28
return 1 57 32
assign 1 61 36
toStringWithSeparator 1 61 36
return 1 61 37
assign 1 65 43
stepListGet 0 65 43
assign 1 66 44
new 0 66 44
assign 1 66 45
join 2 66 45
return 1 67 46
assign 1 71 51
new 1 71 51
assign 1 71 52
tokenize 1 71 52
return 1 71 53
assign 1 75 58
stepListGet 0 75 58
assign 1 75 59
firstGet 0 75 59
return 1 75 60
assign 1 79 65
stepListGet 0 79 65
assign 1 79 66
lastGet 0 79 66
return 1 79 67
assign 1 83 85
pathGet 0 83 85
assign 1 83 86
new 0 83 86
assign 1 83 87
emptyGet 0 83 87
assign 1 83 88
equals 1 83 88
assign 1 84 90
copy 0 84 90
return 1 84 91
assign 1 86 93
isAbsoluteGet 0 86 93
assign 1 87 95
copy 0 87 95
return 1 87 96
assign 1 89 98
stepListGet 0 89 98
assign 1 90 99
stepListGet 0 90 99
assign 1 91 100
linkedListIteratorGet 0 91 100
assign 1 91 103
hasNextGet 0 91 103
assign 1 92 105
nextGet 0 92 105
addValue 1 93 106
assign 1 95 112
new 0 95 112
assign 1 95 113
join 2 95 113
assign 1 96 114
copy 0 96 114
assign 1 97 115
fromString 1 97 115
return 1 99 116
assign 1 103 129
stepListGet 0 103 129
assign 1 104 130
copy 0 104 130
assign 1 105 131
new 0 105 131
pathSet 1 105 132
assign 1 106 133
lengthGet 0 106 133
assign 1 107 134
decrement 0 107 134
assign 1 108 135
new 0 108 135
assign 1 109 136
linkedListIteratorGet 0 109 136
assign 1 109 139
hasNextGet 0 109 139
assign 1 110 141
lesser 1 110 146
assign 1 111 147
nextGet 0 111 147
addStep 1 111 148
nextGet 0 113 151
assign 1 115 153
increment 0 115 153
assign 1 117 159
isAbsoluteGet 0 117 159
makeAbsolute 0 118 161
return 1 120 163
assign 1 124 178
undef 1 124 183
assign 1 0 184
assign 1 124 187
toString 0 124 187
assign 1 124 188
sizeGet 0 124 188
assign 1 124 189
new 0 124 189
assign 1 124 190
lesser 1 124 195
assign 1 0 196
assign 1 0 199
assign 1 124 203
new 0 124 203
return 1 124 204
assign 1 125 206
new 0 125 206
assign 1 125 207
getPoint 1 125 207
assign 1 125 208
equals 1 125 208
assign 1 126 210
new 0 126 210
return 1 126 211
assign 1 128 213
new 0 128 213
return 1 128 214
assign 1 132 220
isAbsoluteGet 0 132 220
assign 1 133 222
new 0 133 222
assign 1 133 223
sizeGet 0 133 223
assign 1 133 224
substring 2 133 224
assign 1 138 231
isAbsoluteGet 0 138 231
assign 1 138 232
not 0 138 237
assign 1 139 238
add 1 139 238
assign 1 144 251
new 0 144 251
assign 1 144 252
greater 1 144 257
makeNonAbsolute 0 145 258
assign 1 146 259
stepListGet 0 146 259
assign 1 148 260
firstNodeGet 0 148 260
assign 1 149 261
new 0 149 261
assign 1 149 264
lesser 1 149 269
assign 1 150 270
undef 1 150 275
assign 1 151 278
assign 1 152 279
nextGet 0 152 279
delete 0 153 280
assign 1 149 281
increment 0 149 281
assign 1 155 287
join 2 155 287
assign 1 160 293
stepListGet 0 160 293
addValue 1 161 294
assign 1 162 295
join 2 162 295
assign 1 166 305
find 1 166 305
assign 1 167 306
undef 1 167 311
assign 1 168 312
new 0 168 312
assign 1 168 313
emptyGet 0 168 313
assign 1 170 316
new 0 170 316
assign 1 170 317
add 1 170 317
assign 1 170 318
sizeGet 0 170 318
assign 1 170 319
substring 2 170 319
assign 1 175 328
stepListGet 0 175 328
assign 1 176 329
linkedListIteratorGet 0 176 329
assign 1 176 332
hasNextGet 0 176 332
assign 1 177 334
nextGet 0 177 334
addValue 1 177 335
assign 1 179 341
join 2 179 341
assign 1 183 346
addStep 1 183 346
return 1 183 347
assign 1 187 351
stepListGet 0 187 351
addValue 1 188 352
addValue 1 189 353
assign 1 190 354
join 2 190 354
assign 1 194 360
create 0 194 360
copyTo 1 195 361
assign 1 196 362
copy 0 196 362
pathSet 1 196 363
return 1 197 364
assign 1 201 368
stepListGet 0 201 368
return 1 201 369
assign 1 205 373
hashGet 0 205 373
return 1 205 374
assign 1 209 379
equals 1 209 379
assign 1 209 380
not 0 209 385
return 1 209 385
assign 1 213 397
undef 1 213 402
assign 1 0 403
assign 1 213 406
new 0 213 406
assign 1 213 407
otherType 2 213 407
assign 1 0 409
assign 1 0 412
assign 1 0 416
assign 1 213 419
pathGet 0 213 419
assign 1 213 420
notEquals 1 213 420
assign 1 0 422
assign 1 0 425
assign 1 214 429
new 0 214 429
return 1 214 430
assign 1 216 432
new 0 216 432
return 1 216 433
assign 1 220 437
subPath 2 220 437
return 1 220 438
assign 1 224 447
stepsGet 0 224 447
assign 1 225 448
undef 1 225 453
assign 1 226 454
subList 1 226 454
assign 1 228 457
subList 2 228 457
assign 1 230 459
create 0 230 459
separatorSet 1 231 460
assign 1 232 461
new 0 232 461
assign 1 232 462
join 2 232 462
pathSet 1 232 463
return 1 233 464
return 1 0 467
assign 1 0 470
return 1 0 474
assign 1 0 477
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1191602699: return bem_hashGet_0();
case -556606602: return bem_stepListGet_0();
case 187681083: return bem_copy_0();
case 1909729056: return bem_isAbsoluteGet_0();
case 251273900: return bem_create_0();
case -1858934481: return bem_firstStepGet_0();
case 1137335771: return bem_separatorGet_0();
case -1500398500: return bem_parentGet_0();
case -636859890: return bem_deleteFirstStep_0();
case -1497890237: return bem_print_0();
case 1860455453: return bem_lastStepGet_0();
case -1836068415: return bem_makeAbsolute_0();
case -1773608927: return bem_toString_0();
case -1791111699: return bem_makeNonAbsolute_0();
case -417450064: return bem_pathGet_0();
case -770739058: return bem_stepsGet_0();
case -2069643406: return bem_iteratorGet_0();
case 814616851: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1056837285: return bem_notEquals_1(bevd_0);
case -964142088: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -61251069: return bem_def_1(bevd_0);
case -68237470: return bem_addSteps_1(bevd_0);
case -1472371585: return bem_equals_1(bevd_0);
case -1077863185: return bem_add_1(bevd_0);
case -1053373901: return bem_addStep_1(bevd_0);
case 347154355: return bem_pathSet_1(bevd_0);
case 1230809966: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1714921323: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 2118007658: return bem_copyTo_1(bevd_0);
case -865732216: return bem_separatorSet_1(bevd_0);
case -708582463: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1149315682: return bem_undef_1(bevd_0);
case -413664942: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1968512856: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 783177622: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2080349703: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -832674110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1596692323: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1492322303: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1937163330: return bem_addSteps_2(bevd_0, bevd_1);
case -1079693664: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
