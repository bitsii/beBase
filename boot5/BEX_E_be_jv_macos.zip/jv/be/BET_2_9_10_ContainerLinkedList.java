package be;
public class BET_2_9_10_ContainerLinkedList extends BETS_Object {
public BET_2_9_10_ContainerLinkedList() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "newNode_1", "appendNode_1", "prependNode_1", "deleteNode_1", "insertBeforeNode_2", "get_1", "put_2", "firstGet_0", "secondGet_0", "thirdGet_0", "lastGet_0", "getNode_1", "addValueWhole_1", "addValue_1", "iterateAdd_1", "addAll_1", "prepend_1", "lengthGet_0", "sizeGet_0", "isEmptyGet_0", "toNodeList_0", "toList_0", "linkedListIteratorGet_0", "serializationIteratorGet_0", "subList_1", "subList_2", "reverse_0", "firstNodeGet_0", "firstNodeSet_1", "lastNodeGet_0", "lastNodeSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "firstNode", "lastNode" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_9_10_ContainerLinkedList();
}
}
