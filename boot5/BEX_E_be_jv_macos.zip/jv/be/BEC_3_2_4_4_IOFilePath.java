package be;
/* IO:File: source/extended/FilePath.be */
public class BEC_3_2_4_4_IOFilePath extends BEC_2_6_8_SystemBasePath {
public BEC_3_2_4_4_IOFilePath() { }
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x50,0x61,0x74,0x68,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_2_4_4_IOFilePath_bels_0 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_4_IOFilePath_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_4_IOFilePath_bels_0, 1));
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_4 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_5 = (new BEC_2_4_3_MathInt(2));
public static BEC_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_inst;

public static BET_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_type;

public BEC_2_2_4_IOFile bevp_file;
public BEC_2_4_6_TextString bevp_driveLetter;
public BEC_3_2_4_4_IOFilePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevp_separator = bevt_0_tmpany_phold.bem_separatorGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_apNew_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_6_8_SystemPlatform bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = beva_spath.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_0;
if (bevt_2_tmpany_phold.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_6_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_1;
bevt_5_tmpany_phold = beva_spath.bem_getPoint_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_8_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_3;
bevt_9_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_4;
bevp_driveLetter = beva_spath.bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_5;
bevt_11_tmpany_phold = beva_spath.bem_sizeGet_0();
beva_spath = beva_spath.bem_substring_2(bevt_10_tmpany_phold, bevt_11_tmpany_phold);
} /* Line: 26 */
bevt_12_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl_p = bevt_12_tmpany_phold.bem_platformGet_0();
bevt_13_tmpany_phold = bevl_p.bem_otherSeparatorGet_0();
bevt_14_tmpany_phold = bevl_p.bem_separatorGet_0();
beva_spath = (BEC_2_4_6_TextString) beva_spath.bem_swap_2(bevt_13_tmpany_phold, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bem_new_1(beva_spath);
return (BEC_3_2_4_4_IOFilePath) bevt_15_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = super.bem_isAbsoluteGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_apNew_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_fileGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_file == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevp_file = (new BEC_2_2_4_IOFile()).bem_new_0();
bevp_file.bem_pathSet_1(this);
} /* Line: 57 */
return bevp_file;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_copy_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_3_2_4_4_IOFilePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_other.bem_fileSet_1(null);
return (BEC_3_2_4_4_IOFilePath) bevl_other;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_driveLetter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 71 */ {
bevt_1_tmpany_phold = bevp_driveLetter.bem_add_1(bevp_path);
return bevt_1_tmpany_phold;
} /* Line: 72 */
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_parentGet_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = super.bem_parentGet_0();
return (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevp_driveLetter = null;
super.bem_makeNonAbsolute_0();
} /* Line: 84 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_matchesGlob_1(BEC_2_4_6_TextString beva_glob) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_4_TextGlob bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_4_TextGlob()).bem_new_1(beva_glob);
bevt_2_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_match_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_6_6_SystemObject bevl_res = null;
bevl_res = super.bem_subPath_2(beva_start, beva_end);
bevl_res.bemd_1(-2031846488, bevp_driveLetter);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_lastStepGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_2_4_IOFile bem_fileGetDirect_0() throws Throwable {
return bevp_file;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_fileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_driveLetterGet_0() throws Throwable {
return bevp_driveLetter;
} /*method end*/
public final BEC_2_4_6_TextString bem_driveLetterGetDirect_0() throws Throwable {
return bevp_driveLetter;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_driveLetterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_driveLetterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 18, 19, 24, 24, 24, 24, 24, 24, 24, 24, 0, 0, 0, 25, 25, 25, 26, 26, 26, 28, 28, 29, 29, 29, 30, 30, 37, 37, 41, 41, 45, 49, 49, 55, 55, 56, 57, 59, 63, 64, 65, 65, 66, 67, 71, 71, 72, 72, 74, 78, 78, 82, 83, 84, 89, 89, 89, 89, 93, 94, 95, 99, 99, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 45, 46, 47, 52, 53, 54, 55, 56, 58, 61, 65, 68, 69, 70, 71, 72, 73, 75, 76, 77, 78, 79, 80, 81, 85, 86, 90, 91, 94, 99, 100, 104, 109, 110, 111, 113, 118, 119, 120, 121, 122, 123, 128, 133, 134, 135, 137, 141, 142, 146, 148, 149, 157, 158, 159, 160, 164, 165, 166, 170, 171, 174, 177, 181, 185, 188, 191, 195};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 22
new 0 18 22
assign 1 18 23
separatorGet 0 18 23
fromString 1 19 24
assign 1 24 45
sizeGet 0 24 45
assign 1 24 46
new 0 24 46
assign 1 24 47
greater 1 24 52
assign 1 24 53
new 0 24 53
assign 1 24 54
getPoint 1 24 54
assign 1 24 55
new 0 24 55
assign 1 24 56
equals 1 24 56
assign 1 0 58
assign 1 0 61
assign 1 0 65
assign 1 25 68
new 0 25 68
assign 1 25 69
new 0 25 69
assign 1 25 70
substring 2 25 70
assign 1 26 71
new 0 26 71
assign 1 26 72
sizeGet 0 26 72
assign 1 26 73
substring 2 26 73
assign 1 28 75
new 0 28 75
assign 1 28 76
platformGet 0 28 76
assign 1 29 77
otherSeparatorGet 0 29 77
assign 1 29 78
separatorGet 0 29 78
assign 1 29 79
swap 2 29 79
assign 1 30 80
new 1 30 80
return 1 30 81
assign 1 37 85
isAbsoluteGet 0 37 85
return 1 37 86
assign 1 41 90
toString 0 41 90
return 1 41 91
apNew 1 45 94
assign 1 49 99
new 0 49 99
return 1 49 100
assign 1 55 104
undef 1 55 109
assign 1 56 110
new 0 56 110
pathSet 1 57 111
return 1 59 113
assign 1 63 118
create 0 63 118
copyTo 1 64 119
assign 1 65 120
copy 0 65 120
pathSet 1 65 121
fileSet 1 66 122
return 1 67 123
assign 1 71 128
def 1 71 133
assign 1 72 134
add 1 72 134
return 1 72 135
return 1 74 137
assign 1 78 141
parentGet 0 78 141
return 1 78 142
assign 1 82 146
isAbsoluteGet 0 82 146
assign 1 83 148
makeNonAbsolute 0 84 149
assign 1 89 157
new 1 89 157
assign 1 89 158
toString 0 89 158
assign 1 89 159
match 1 89 159
return 1 89 160
assign 1 93 164
subPath 2 93 164
driveLetterSet 1 94 165
return 1 95 166
assign 1 99 170
lastStepGet 0 99 170
return 1 99 171
return 1 0 174
assign 1 0 177
assign 1 0 181
return 1 0 185
return 1 0 188
assign 1 0 191
assign 1 0 195
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 691119750: return bem_fileGet_0();
case -844497155: return bem_tagGet_0();
case 759003839: return bem_deleteFirstStep_0();
case -243903584: return bem_fieldNamesGet_0();
case -1486852325: return bem_copy_0();
case -1765473768: return bem_parentGet_0();
case -557938157: return bem_toString_0();
case -295279542: return bem_once_0();
case -120737825: return bem_makeAbsolute_0();
case -736476180: return bem_serializeContents_0();
case 1607918083: return bem_firstStepGet_0();
case -1191299721: return bem_deserializeClassNameGet_0();
case 1227289471: return bem_hashGet_0();
case -1348350074: return bem_create_0();
case 740465458: return bem_new_0();
case 1556462345: return bem_stepListGet_0();
case -5604421: return bem_many_0();
case -78307045: return bem_separatorGet_0();
case -1203535797: return bem_toAny_0();
case 294769645: return bem_driveLetterGetDirect_0();
case 819113163: return bem_nameGet_0();
case -160188567: return bem_separatorGetDirect_0();
case 115531058: return bem_lastStepGet_0();
case 1432632487: return bem_pathGet_0();
case 1567955799: return bem_fieldIteratorGet_0();
case 351178267: return bem_echo_0();
case 1715713974: return bem_driveLetterGet_0();
case -1831836246: return bem_isAbsoluteGet_0();
case -1549208772: return bem_pathGetDirect_0();
case 1840305191: return bem_serializeToString_0();
case -708320199: return bem_fileGetDirect_0();
case -383147285: return bem_serializationIteratorGet_0();
case -1166462165: return bem_iteratorGet_0();
case -2141220162: return bem_stepsGet_0();
case -2039624597: return bem_sourceFileNameGet_0();
case -1054172897: return bem_makeNonAbsolute_0();
case 1540627001: return bem_classNameGet_0();
case -260111055: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1724749097: return bem_undefined_1(bevd_0);
case 151691647: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -2100440987: return bem_def_1(bevd_0);
case 1187046692: return bem_defined_1(bevd_0);
case 2018926029: return bem_separatorSetDirect_1(bevd_0);
case 681538010: return bem_notEquals_1(bevd_0);
case 551786219: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -387830191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1670790162: return bem_sameClass_1(bevd_0);
case -1347265909: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -218864081: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1579982185: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 162585010: return bem_fileSetDirect_1(bevd_0);
case -2031846488: return bem_driveLetterSet_1(bevd_0);
case 84257001: return bem_matchesGlob_1((BEC_2_4_6_TextString) bevd_0);
case 859567390: return bem_separatorSet_1(bevd_0);
case -2095234015: return bem_apNew_1((BEC_2_4_6_TextString) bevd_0);
case -593937181: return bem_copyTo_1(bevd_0);
case 5580311: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 1839755987: return bem_otherType_1(bevd_0);
case -1227133832: return bem_pathSetDirect_1(bevd_0);
case -1748281966: return bem_sameObject_1(bevd_0);
case 13234418: return bem_fileSet_1(bevd_0);
case -100649989: return bem_addSteps_1(bevd_0);
case 1981763359: return bem_add_1(bevd_0);
case -1617719429: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 958315163: return bem_sameType_1(bevd_0);
case 1647627603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -714548596: return bem_driveLetterSetDirect_1(bevd_0);
case -1626360852: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1434301269: return bem_addStep_1(bevd_0);
case 2039711690: return bem_undef_1(bevd_0);
case -1258811879: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1569898372: return bem_pathSet_1(bevd_0);
case 1544353280: return bem_otherClass_1(bevd_0);
case -67300059: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1783125070: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1431755140: return bem_addSteps_2(bevd_0, bevd_1);
case 1046047039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1868703996: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1197157296: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -528171684: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1304899076: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1671846119: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 520681709: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_3_2_4_4_IOFilePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_3_2_4_4_IOFilePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_4_IOFilePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst = (BEC_3_2_4_4_IOFilePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_type;
}
}
