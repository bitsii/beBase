package be;
public class BET_2_4_6_JsonParser extends BETS_Object {
public BET_2_4_6_JsonParser() {String[] bevs_mtnames = new String[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "parse_2", "jsonUcIsPairStart_1", "jsonUcIsPairEnd_1", "jsonUcGetAfterPart_1", "jsonUcUnescape_1", "jsonUcAppendValue_3", "parseTokens_2", "quoteGet_0", "quoteSet_1", "lbraceGet_0", "lbraceSet_1", "rbraceGet_0", "rbraceSet_1", "lbracketGet_0", "lbracketSet_1", "rbracketGet_0", "rbracketSet_1", "spaceGet_0", "spaceSet_1", "colonGet_0", "colonSet_1", "escapeGet_0", "escapeSet_1", "crGet_0", "crSet_1", "lfGet_0", "lfSet_1", "commaGet_0", "commaSet_1", "tokensGet_0", "tokensSet_1", "tokerGet_0", "tokerSet_1", "hsubGet_0", "hsubSet_1", "vsubGet_0", "vsubSet_1", "hmAddGet_0", "hmAddSet_1" };
bems_buildMethodNames(bevs_mtnames);
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_6_JsonParser();
}
}
