package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_21_SystemStartupWithParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_21_SystemStartupWithParameters() { }
private static byte[] becc_BEC_2_6_21_SystemStartupWithParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x57,0x69,0x74,0x68,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_21_SystemStartupWithParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_21_SystemStartupWithParameters_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x4C,0x69,0x73,0x74,0x20,0x61,0x72,0x67,0x73,0x2C,0x20,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73,0x20,0x70,0x61,0x72,0x61,0x6D,0x73,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
public static BEC_2_6_21_SystemStartupWithParameters bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst;

public static BET_2_6_21_SystemStartupWithParameters bece_BEC_2_6_21_SystemStartupWithParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_6_21_SystemStartupWithParameters bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_ta_ph.bem_argsGet_0();
bevt_2_ta_ph = bevp_args.bem_lengthGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(164, bece_BEC_2_6_21_SystemStartupWithParameters_bels_0));
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 99*/
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_7_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bevp_args.bem_get_1(bevt_9_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_createInstance_1((BEC_2_4_6_TextString) bevt_8_ta_ph );
bevl_x = bevt_6_ta_ph.bemd_0(1125757906);
bevt_10_ta_ph = bevl_x.bemd_2(250348711, bevp_args, bevp_params);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {97, 97, 98, 98, 98, 98, 99, 99, 99, 101, 102, 102, 102, 102, 102, 103, 103, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {33, 34, 35, 36, 37, 42, 43, 44, 45, 47, 48, 49, 50, 51, 52, 53, 54, 57, 60, 64, 67};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 97 33
new 0 97 33
assign 1 97 34
argsGet 0 97 34
assign 1 98 35
lengthGet 0 98 35
assign 1 98 36
new 0 98 36
assign 1 98 37
lesser 1 98 42
assign 1 99 43
new 0 99 43
assign 1 99 44
new 1 99 44
throw 1 99 45
assign 1 101 47
new 1 101 47
assign 1 102 48
new 0 102 48
assign 1 102 49
new 0 102 49
assign 1 102 50
get 1 102 50
assign 1 102 51
createInstance 1 102 51
assign 1 102 52
new 0 102 52
assign 1 103 53
main 2 103 53
return 1 103 54
return 1 0 57
assign 1 0 60
return 1 0 64
assign 1 0 67
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1394550537: return bem_copy_0();
case -246278640: return bem_create_0();
case -1684356914: return bem_argsGet_0();
case 1461169107: return bem_toString_0();
case 1324893030: return bem_print_0();
case -1650807104: return bem_default_0();
case -1175712492: return bem_paramsGet_0();
case 178721427: return bem_hashGet_0();
case 776957315: return bem_main_0();
case 1125757906: return bem_new_0();
case -1618073132: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1915797651: return bem_notEquals_1(bevd_0);
case 594043501: return bem_print_1(bevd_0);
case -716906558: return bem_argsSet_1(bevd_0);
case -482098203: return bem_undef_1(bevd_0);
case 1427580756: return bem_paramsSet_1(bevd_0);
case 244340630: return bem_def_1(bevd_0);
case 392781782: return bem_equals_1(bevd_0);
case -2025525725: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1729000428: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1685769165: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -96915223: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -726117523: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_21_SystemStartupWithParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_21_SystemStartupWithParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_21_SystemStartupWithParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst = (BEC_2_6_21_SystemStartupWithParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_type;
}
}
