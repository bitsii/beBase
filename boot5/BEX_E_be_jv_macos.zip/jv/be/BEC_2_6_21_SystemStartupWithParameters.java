package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_21_SystemStartupWithParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_21_SystemStartupWithParameters() { }
private static byte[] becc_BEC_2_6_21_SystemStartupWithParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x57,0x69,0x74,0x68,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_21_SystemStartupWithParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_21_SystemStartupWithParameters_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x4C,0x69,0x73,0x74,0x20,0x61,0x72,0x67,0x73,0x2C,0x20,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73,0x20,0x70,0x61,0x72,0x61,0x6D,0x73,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
public static BEC_2_6_21_SystemStartupWithParameters bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst;

public static BET_2_6_21_SystemStartupWithParameters bece_BEC_2_6_21_SystemStartupWithParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_6_21_SystemStartupWithParameters bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_ta_ph.bem_argsGet_0();
bevt_2_ta_ph = bevp_args.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 92*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(164, bece_BEC_2_6_21_SystemStartupWithParameters_bels_0));
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 93*/
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_7_ta_ph = bevp_args.bem_get_1(bevt_8_ta_ph);
bevt_6_ta_ph = bem_createInstance_1((BEC_2_4_6_TextString) bevt_7_ta_ph );
bevl_x = bevt_6_ta_ph.bemd_0(-2131640624);
bevt_9_ta_ph = bevl_x.bemd_2(-60284690, bevp_args, bevp_params);
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_21_SystemStartupWithParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_21_SystemStartupWithParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_21_SystemStartupWithParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {91, 91, 92, 92, 92, 92, 93, 93, 93, 95, 96, 96, 96, 96, 97, 97, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {32, 33, 34, 35, 36, 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 55, 58, 61, 65, 69, 72, 75, 79};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 91 32
new 0 91 32
assign 1 91 33
argsGet 0 91 33
assign 1 92 34
sizeGet 0 92 34
assign 1 92 35
new 0 92 35
assign 1 92 36
lesser 1 92 41
assign 1 93 42
new 0 93 42
assign 1 93 43
new 1 93 43
throw 1 93 44
assign 1 95 46
new 1 95 46
assign 1 96 47
new 0 96 47
assign 1 96 48
get 1 96 48
assign 1 96 49
createInstance 1 96 49
assign 1 96 50
new 0 96 50
assign 1 97 51
main 2 97 51
return 1 97 52
return 1 0 55
return 1 0 58
assign 1 0 61
assign 1 0 65
return 1 0 69
return 1 0 72
assign 1 0 75
assign 1 0 79
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1051242816: return bem_argsGetDirect_0();
case 785161348: return bem_fieldNamesGet_0();
case 239077256: return bem_print_0();
case -157777737: return bem_fieldIteratorGet_0();
case -1270780814: return bem_default_0();
case 2113534779: return bem_hashGet_0();
case 1393634620: return bem_serializeToString_0();
case 1645989341: return bem_iteratorGet_0();
case 566573794: return bem_tagGet_0();
case 1005443364: return bem_create_0();
case 2071875109: return bem_sourceFileNameGet_0();
case 1464527658: return bem_toString_0();
case -281350604: return bem_serializeContents_0();
case 1864861581: return bem_echo_0();
case 350812655: return bem_copy_0();
case 1456267248: return bem_main_0();
case 969994032: return bem_serializationIteratorGet_0();
case 1587133120: return bem_classNameGet_0();
case 873828646: return bem_deserializeClassNameGet_0();
case 655016134: return bem_paramsGetDirect_0();
case -394079881: return bem_argsGet_0();
case -2131640624: return bem_new_0();
case 1903443157: return bem_paramsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -396283576: return bem_undef_1(bevd_0);
case -835695251: return bem_argsSet_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case -2105720058: return bem_argsSetDirect_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 233515208: return bem_paramsSetDirect_1(bevd_0);
case -1832245614: return bem_paramsSet_1(bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_21_SystemStartupWithParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_21_SystemStartupWithParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_21_SystemStartupWithParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst = (BEC_2_6_21_SystemStartupWithParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_21_SystemStartupWithParameters.bece_BEC_2_6_21_SystemStartupWithParameters_bevs_type;
}
}
