package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_9_BuildTransUnit extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransUnit() { }
private static byte[] becc_BEC_2_5_9_BuildTransUnit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x55,0x6E,0x69,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransUnit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildTransUnit bece_BEC_2_5_9_BuildTransUnit_bevs_inst;

public static BET_2_5_9_BuildTransUnit bece_BEC_2_5_9_BuildTransUnit_bevs_type;

public BEC_2_9_3_ContainerMap bevp_aliased;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_5_9_BuildTransUnit bem_new_0() throws Throwable {
bevp_aliased = (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_emits == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 59*/ {
bevp_emits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 60*/
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() throws Throwable {
return bevp_aliased;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() throws Throwable {
return bevp_emits;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {54, 59, 59, 61, 64, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 19, 24, 25, 27, 31, 34, 38, 41};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 54 14
new 0 54 14
assign 1 59 19
undef 1 59 24
assign 1 61 25
new 0 61 25
addValue 1 64 27
return 1 0 31
assign 1 0 34
return 1 0 38
assign 1 0 41
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1467274168: return bem_new_0();
case 447392967: return bem_copy_0();
case -953507231: return bem_create_0();
case 1430882405: return bem_toString_0();
case -1169546676: return bem_iteratorGet_0();
case -119375280: return bem_emitsGet_0();
case -776015162: return bem_print_0();
case -1626994991: return bem_aliasedGet_0();
case 148494370: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -310926947: return bem_def_1(bevd_0);
case 276386904: return bem_emitsSet_1(bevd_0);
case -1115270181: return bem_aliasedSet_1(bevd_0);
case 1747007145: return bem_equals_1(bevd_0);
case -440246922: return bem_notEquals_1(bevd_0);
case -540286919: return bem_addEmit_1(bevd_0);
case 1090166823: return bem_undef_1(bevd_0);
case -1059179702: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1072039287: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1571917853: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1557789855: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -754298914: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransUnit_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_9_BuildTransUnit_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildTransUnit();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_inst = (BEC_2_5_9_BuildTransUnit) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_type;
}
}
