package be;
public class BET_2_5_15_BuildCompilerProfile extends BETS_Object {
public BET_2_5_15_BuildCompilerProfile() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "doMakeDirs_1", "exeExtGet_0", "exeExtSet_1", "libExtGet_0", "libExtSet_1", "ccObjGet_0", "ccObjSet_1", "ccGet_0", "ccSet_1", "cextGet_0", "cextSet_1", "oextGet_0", "oextSet_1", "lBuildGet_0", "lBuildSet_1", "ccoutGet_0", "ccoutSet_1", "doCopyGet_0", "doCopySet_1", "mkdirsGet_0", "mkdirsSet_1", "lexeGet_0", "lexeSet_1", "exeLibExtGet_0", "exeLibExtSet_1", "nameGet_0", "nameSet_1", "diGet_0", "diSet_1", "smacGet_0", "smacSet_1", "dialectGet_0", "dialectSet_1", "compilerGet_0", "compilerSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "exeExt", "libExt", "ccObj", "cc", "cext", "oext", "lBuild", "ccout", "doCopy", "mkdirs", "lexe", "exeLibExt", "name", "di", "smac", "dialect", "compiler" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_15_BuildCompilerProfile();
}
}
