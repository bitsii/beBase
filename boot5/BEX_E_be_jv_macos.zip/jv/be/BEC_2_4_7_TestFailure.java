package be;
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure extends BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public BEC_2_4_7_TestFailure bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
super.bem_new_1(beva_descr);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 15 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 427473649: return bem_vvGet_0();
case -1794506213: return bem_many_0();
case -1396413274: return bem_classNameGet_0();
case 85669346: return bem_once_0();
case 398838525: return bem_framesGet_0();
case -808123537: return bem_hashGet_0();
case -526214247: return bem_translatedGetDirect_0();
case -295553573: return bem_new_0();
case -1160576197: return bem_framesTextGet_0();
case 1435781176: return bem_translateEmittedExceptionInner_0();
case 1598445817: return bem_klassNameGet_0();
case 1523861211: return bem_sourceFileNameGet_0();
case 889700256: return bem_langGet_0();
case -1460543860: return bem_fieldNamesGet_0();
case -407805688: return bem_framesGetDirect_0();
case 1560123499: return bem_getFrameText_0();
case 874569701: return bem_toAny_0();
case -1602615308: return bem_fieldIteratorGet_0();
case 1017730274: return bem_emitLangGetDirect_0();
case 1061933276: return bem_fileNameGet_0();
case -1025042119: return bem_vvGetDirect_0();
case -493975186: return bem_create_0();
case 1082531874: return bem_framesTextGetDirect_0();
case -1890398404: return bem_fileNameGetDirect_0();
case 1486645066: return bem_methodNameGetDirect_0();
case 1606613844: return bem_echo_0();
case 813271238: return bem_langGetDirect_0();
case -1706743432: return bem_iteratorGet_0();
case -2071452709: return bem_serializeContents_0();
case -1442653865: return bem_serializationIteratorGet_0();
case -1333837278: return bem_tagGet_0();
case 487466585: return bem_translateEmittedException_0();
case 899896295: return bem_print_0();
case -1894090923: return bem_toString_0();
case 1456278163: return bem_lineNumberGetDirect_0();
case -600575389: return bem_emitLangGet_0();
case 1520843468: return bem_descriptionGet_0();
case -1619643052: return bem_descriptionGetDirect_0();
case 1377047095: return bem_serializeToString_0();
case 1148142853: return bem_translatedGet_0();
case -41381797: return bem_copy_0();
case -802767414: return bem_deserializeClassNameGet_0();
case 1157144429: return bem_methodNameGet_0();
case -887830792: return bem_lineNumberGet_0();
case 1032253080: return bem_klassNameGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -708072209: return bem_framesSetDirect_1(bevd_0);
case 53407038: return bem_equals_1(bevd_0);
case 981175626: return bem_framesTextSet_1(bevd_0);
case 1719522067: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -390727554: return bem_langSet_1(bevd_0);
case 10942144: return bem_fileNameSet_1(bevd_0);
case -408707588: return bem_framesTextSetDirect_1(bevd_0);
case 1829433968: return bem_otherClass_1(bevd_0);
case 391192402: return bem_copyTo_1(bevd_0);
case -1794747952: return bem_translatedSetDirect_1(bevd_0);
case 251588443: return bem_otherType_1(bevd_0);
case -84206037: return bem_descriptionSetDirect_1(bevd_0);
case 150700345: return bem_descriptionSet_1(bevd_0);
case 826056150: return bem_emitLangSetDirect_1(bevd_0);
case 284248916: return bem_defined_1(bevd_0);
case -495420901: return bem_lineNumberSetDirect_1(bevd_0);
case -703379149: return bem_fileNameSetDirect_1(bevd_0);
case -666596898: return bem_new_1(bevd_0);
case 966131902: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -265277989: return bem_vvSet_1(bevd_0);
case 652115224: return bem_def_1(bevd_0);
case -467808258: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -920243169: return bem_sameObject_1(bevd_0);
case -319164445: return bem_undefined_1(bevd_0);
case 151472195: return bem_emitLangSet_1(bevd_0);
case -119471423: return bem_framesSet_1(bevd_0);
case 125631220: return bem_klassNameSet_1(bevd_0);
case 61859776: return bem_translatedSet_1(bevd_0);
case 1170147953: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1636353578: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -194482552: return bem_sameType_1(bevd_0);
case -698533498: return bem_methodNameSetDirect_1(bevd_0);
case 1729508827: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1989300932: return bem_sameClass_1(bevd_0);
case 888728042: return bem_lineNumberSet_1(bevd_0);
case 1328285078: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1179793891: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -794252146: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -902009530: return bem_methodNameSet_1(bevd_0);
case -1327704512: return bem_vvSetDirect_1(bevd_0);
case -445574019: return bem_langSetDirect_1(bevd_0);
case 1213137777: return bem_undef_1(bevd_0);
case 1475677279: return bem_klassNameSetDirect_1(bevd_0);
case 1028018501: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -2123613587: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1874085610: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1865862746: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736065910: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1057911785: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1158884482: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126000923: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1221539498: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1606841783: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TestFailure();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
