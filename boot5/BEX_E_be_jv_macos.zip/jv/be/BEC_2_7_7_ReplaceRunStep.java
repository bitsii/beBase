package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_7_7_ReplaceRunStep extends BEC_2_6_6_SystemObject {
public BEC_2_7_7_ReplaceRunStep() { }
private static byte[] becc_BEC_2_7_7_ReplaceRunStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x52,0x75,0x6E,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_7_ReplaceRunStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_7_7_ReplaceRunStep bece_BEC_2_7_7_ReplaceRunStep_bevs_inst;

public static BET_2_7_7_ReplaceRunStep bece_BEC_2_7_7_ReplaceRunStep_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_4_6_TextString bevp_str;
public BEC_2_7_7_ReplaceRunStep bem_new_2(BEC_2_8_7_TemplateReplace beva__replace, BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_replace = beva__replace;
bevp_str = beva__str;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) throws Throwable {
BEC_2_4_6_TextString bevl_toSwap = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_r.bemd_0(1640471435);
bevl_toSwap = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(-198509756, bevp_str);
if (bevl_toSwap == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 157 */ {
return bevl_toSwap;
} /* Line: 158 */
return bevp_str;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public final BEC_2_8_7_TemplateReplace bem_replaceGetDirect_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_7_7_ReplaceRunStep bem_replaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public final BEC_2_4_6_TextString bem_strGetDirect_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_7_7_ReplaceRunStep bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {149, 150, 156, 156, 157, 157, 158, 160, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 22, 23, 24, 29, 30, 32, 35, 38, 41, 45, 49, 52, 55, 59};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 149 14
assign 1 150 15
assign 1 156 22
swapGet 0 156 22
assign 1 156 23
get 1 156 23
assign 1 157 24
def 1 157 29
return 1 158 30
return 1 160 32
return 1 0 35
return 1 0 38
assign 1 0 41
assign 1 0 45
return 1 0 49
return 1 0 52
assign 1 0 55
assign 1 0 59
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 181352533: return bem_toString_0();
case -1629315459: return bem_once_0();
case 1143341249: return bem_hashGet_0();
case -285809792: return bem_iteratorGet_0();
case 1386516464: return bem_tagGet_0();
case -821330970: return bem_fieldIteratorGet_0();
case 1426181439: return bem_print_0();
case -1175877060: return bem_serializationIteratorGet_0();
case 1493048824: return bem_echo_0();
case 1318783010: return bem_replaceGet_0();
case -490981893: return bem_strGet_0();
case 631110600: return bem_classNameGet_0();
case -1588300494: return bem_many_0();
case -870926142: return bem_serializeContents_0();
case 570658979: return bem_strGetDirect_0();
case -1274019410: return bem_copy_0();
case -807409811: return bem_deserializeClassNameGet_0();
case 418678181: return bem_create_0();
case -1829424765: return bem_new_0();
case -871561427: return bem_replaceGetDirect_0();
case 1416939995: return bem_fieldNamesGet_0();
case -405562305: return bem_toAny_0();
case -759614770: return bem_serializeToString_0();
case 769814255: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2071839904: return bem_replaceSetDirect_1(bevd_0);
case 852730176: return bem_handle_1(bevd_0);
case 402602889: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 428227432: return bem_sameObject_1(bevd_0);
case -859534092: return bem_equals_1(bevd_0);
case -696186821: return bem_strSet_1(bevd_0);
case 537235008: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1468755134: return bem_sameType_1(bevd_0);
case 621653151: return bem_notEquals_1(bevd_0);
case -1366545491: return bem_otherClass_1(bevd_0);
case -2046792613: return bem_defined_1(bevd_0);
case 1747277191: return bem_undef_1(bevd_0);
case 1723573660: return bem_otherType_1(bevd_0);
case -1139109340: return bem_strSetDirect_1(bevd_0);
case 599422049: return bem_copyTo_1(bevd_0);
case -1027507443: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1378844995: return bem_def_1(bevd_0);
case -339502058: return bem_sameClass_1(bevd_0);
case 1075028542: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2055717440: return bem_undefined_1(bevd_0);
case 821688152: return bem_replaceSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 310321751: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -496019130: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1992393015: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1036754585: return bem_new_2((BEC_2_8_7_TemplateReplace) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1454137039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 981296949: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885634458: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 999054655: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_7_7_ReplaceRunStep_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_7_ReplaceRunStep_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_7_7_ReplaceRunStep();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_inst = (BEC_2_7_7_ReplaceRunStep) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_type;
}
}
