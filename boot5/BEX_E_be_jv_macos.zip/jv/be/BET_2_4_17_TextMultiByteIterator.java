package be;
public class BET_2_4_17_TextMultiByteIterator extends BETS_Object {
public BET_2_4_17_TextMultiByteIterator() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "containerGet_0", "serializeToString_0", "deserializeFromStringNew_1", "new_1", "hasNextGet_0", "nextGet_0", "next_1", "nextInt_1", "currentInt_1", "currentIntSet_1", "byteIteratorIteratorGet_0", "strGet_0", "strSet_1", "posGet_0", "posSet_1", "vcopyGet_0", "vcopySet_1", "multiByteIteratorIteratorGet_0", "bcountGet_0", "bcountSet_1", "ivalGet_0", "ivalSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "str", "pos", "vcopy", "bcount", "ival" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_17_TextMultiByteIterator();
}
}
