package be;
public class BET_2_4_3_MathInt extends BETS_Object {
public BET_2_4_3_MathInt() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "hexNew_1", "setStringValueDec_1", "setStringValueHex_1", "setStringValue_2", "setStringValue_5", "serializeToString_0", "deserializeFromStringNew_1", "serializeContentsGet_0", "toHexString_0", "toHexString_1", "toString_2", "toString_3", "toString_4", "abs_0", "absValue_0", "setValue_1", "incrementValue_0", "decrementValue_0", "add_1", "addValue_1", "subtract_1", "subtractValue_1", "multiply_1", "multiplyValue_1", "divide_1", "divideValue_1", "modulus_1", "modulusValue_1", "and_1", "andValue_1", "or_1", "orValue_1", "shiftLeft_1", "shiftLeftValue_1", "shiftRight_1", "shiftRightValue_1", "power_1", "squaredGet_0", "squareRootGet_0", "greater_1", "lesser_1", "greaterEquals_1", "lesserEquals_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] {  };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_3_MathInt();
}
}
