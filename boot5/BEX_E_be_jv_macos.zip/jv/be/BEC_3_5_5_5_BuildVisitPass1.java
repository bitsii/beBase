package be;
/* IO:File: source/build/Pass1.be */
public final class BEC_3_5_5_5_BuildVisitPass1 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass1() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_0 = {};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_1 = {};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_2 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_2, 1));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_3 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_3, 1));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_4 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_4, 1));
public static BEC_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;

public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_allAstElements;
public BEC_2_6_6_SystemObject bevp_f;
public BEC_2_4_6_TextString bevp_inClass;
public BEC_2_4_6_TextString bevp_inClassMethod;
public BEC_3_5_5_5_BuildVisitPass1 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_new_2(BEC_2_9_3_ContainerSet beva__printAstElements, BEC_2_4_6_TextString beva__fname) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
bevp_printAstElements = beva__printAstElements;
bevp_allAstElements = bevp_printAstElements.bem_isEmptyGet_0();
if (beva__fname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevt_3_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva__fname);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_writerGet_0();
bevp_f = bevt_1_tmpany_phold.bemd_0(1470866407);
} /* Line: 27 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_inLine = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_46_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_5_tmpany_phold.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 36 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_sameType_1(bevt_9_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevp_inClass = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 38 */
 else  /* Line: 39 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(74376179);
bevp_inClass = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bemd_0(-1333696208);
} /* Line: 40 */
bevp_inClassMethod = null;
bevl_inLine = null;
} /* Line: 43 */
bevt_13_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_14_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_13_tmpany_phold.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 45 */ {
if (bevp_inClass == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 45 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_18_tmpany_phold = beva_node.bem_heldGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_sameType_1(bevt_18_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevp_inClassMethod = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 47 */
 else  /* Line: 46 */ {
bevt_21_tmpany_phold = beva_node.bem_heldGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-80402566);
if (bevt_20_tmpany_phold == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_23_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_0;
bevt_22_tmpany_phold = bevp_inClass.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(-80402566);
bevp_inClassMethod = bevt_22_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
} /* Line: 49 */
 else  /* Line: 46 */ {
bevt_28_tmpany_phold = beva_node.bem_heldGet_0();
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(638052426);
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_30_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_1;
bevt_29_tmpany_phold = bevp_inClass.bem_add_1(bevt_30_tmpany_phold);
bevt_32_tmpany_phold = beva_node.bem_heldGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_0(638052426);
bevp_inClassMethod = bevt_29_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
} /* Line: 51 */
} /* Line: 46 */
} /* Line: 46 */
} /* Line: 46 */
if (bevp_inClassMethod == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_35_tmpany_phold = beva_node.bem_nlcGet_0();
if (bevt_35_tmpany_phold == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 55 */ {
bevt_37_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_2;
bevt_36_tmpany_phold = bevp_inClassMethod.bem_add_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = beva_node.bem_nlcGet_0();
bevl_inLine = bevt_36_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
} /* Line: 56 */
if (bevp_allAstElements.bevi_bool) /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
if (bevp_inClassMethod == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_40_tmpany_phold = bevp_printAstElements.bem_has_1(bevp_inClassMethod);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
 else  /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
if (bevl_inLine == null) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_42_tmpany_phold = bevp_printAstElements.bem_has_1(bevl_inLine);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
 else  /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 58 */ {
if (bevp_f == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_44_tmpany_phold = beva_node.bem_toString_0();
bevp_f.bemd_1(-49655441, bevt_44_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_newlineGet_0();
bevp_f.bemd_1(-49655441, bevt_45_tmpany_phold);
} /* Line: 61 */
 else  /* Line: 62 */ {
beva_node.bem_print_0();
} /* Line: 63 */
} /* Line: 59 */
bevt_47_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_47_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAstElementsGet_0() throws Throwable {
return bevp_allAstElements;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_allAstElementsGetDirect_0() throws Throwable {
return bevp_allAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fGet_0() throws Throwable {
return bevp_f;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fGetDirect_0() throws Throwable {
return bevp_f;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_fSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_f = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_fSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_f = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public final BEC_2_4_6_TextString bem_inClassGetDirect_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassMethodGet_0() throws Throwable {
return bevp_inClassMethod;
} /*method end*/
public final BEC_2_4_6_TextString bem_inClassMethodGetDirect_0() throws Throwable {
return bevp_inClassMethod;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 25, 26, 26, 27, 27, 27, 27, 36, 36, 36, 36, 37, 37, 37, 38, 40, 40, 40, 42, 43, 45, 45, 45, 45, 45, 45, 0, 0, 0, 46, 46, 46, 47, 48, 48, 48, 48, 49, 49, 49, 49, 49, 50, 50, 50, 50, 51, 51, 51, 51, 51, 55, 55, 55, 55, 55, 0, 0, 0, 56, 56, 56, 56, 0, 58, 58, 58, 0, 0, 0, 0, 0, 0, 58, 58, 58, 0, 0, 0, 0, 0, 59, 59, 60, 60, 61, 61, 61, 63, 66, 66, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {32, 33, 34, 39, 40, 41, 42, 43, 97, 98, 99, 104, 105, 106, 107, 109, 112, 113, 114, 116, 117, 119, 120, 121, 126, 127, 132, 133, 136, 140, 143, 144, 145, 147, 150, 151, 152, 157, 158, 159, 160, 161, 162, 165, 166, 167, 172, 173, 174, 175, 176, 177, 182, 187, 188, 189, 194, 195, 198, 202, 205, 206, 207, 208, 211, 214, 219, 220, 222, 225, 229, 232, 235, 239, 242, 247, 248, 250, 253, 257, 260, 263, 267, 272, 273, 274, 275, 276, 277, 280, 283, 284, 287, 290, 293, 297, 301, 304, 307, 311, 315, 318, 321, 325, 329, 332, 335, 339, 343, 346, 349, 353};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 32
assign 1 25 33
isEmptyGet 0 25 33
assign 1 26 34
def 1 26 39
assign 1 27 40
new 1 27 40
assign 1 27 41
fileGet 0 27 41
assign 1 27 42
writerGet 0 27 42
assign 1 27 43
open 0 27 43
assign 1 36 97
typenameGet 0 36 97
assign 1 36 98
CLASSGet 0 36 98
assign 1 36 99
equals 1 36 104
assign 1 37 105
new 0 37 105
assign 1 37 106
heldGet 0 37 106
assign 1 37 107
sameType 1 37 107
assign 1 38 109
heldGet 0 38 109
assign 1 40 112
heldGet 0 40 112
assign 1 40 113
namepathGet 0 40 113
assign 1 40 114
toString 0 40 114
assign 1 42 116
assign 1 43 117
assign 1 45 119
typenameGet 0 45 119
assign 1 45 120
METHODGet 0 45 120
assign 1 45 121
equals 1 45 126
assign 1 45 127
def 1 45 132
assign 1 0 133
assign 1 0 136
assign 1 0 140
assign 1 46 143
new 0 46 143
assign 1 46 144
heldGet 0 46 144
assign 1 46 145
sameType 1 46 145
assign 1 47 147
heldGet 0 47 147
assign 1 48 150
heldGet 0 48 150
assign 1 48 151
orgNameGet 0 48 151
assign 1 48 152
def 1 48 157
assign 1 49 158
new 0 49 158
assign 1 49 159
add 1 49 159
assign 1 49 160
heldGet 0 49 160
assign 1 49 161
orgNameGet 0 49 161
assign 1 49 162
add 1 49 162
assign 1 50 165
heldGet 0 50 165
assign 1 50 166
nameGet 0 50 166
assign 1 50 167
def 1 50 172
assign 1 51 173
new 0 51 173
assign 1 51 174
add 1 51 174
assign 1 51 175
heldGet 0 51 175
assign 1 51 176
nameGet 0 51 176
assign 1 51 177
add 1 51 177
assign 1 55 182
def 1 55 187
assign 1 55 188
nlcGet 0 55 188
assign 1 55 189
def 1 55 194
assign 1 0 195
assign 1 0 198
assign 1 0 202
assign 1 56 205
new 0 56 205
assign 1 56 206
add 1 56 206
assign 1 56 207
nlcGet 0 56 207
assign 1 56 208
add 1 56 208
assign 1 0 211
assign 1 58 214
def 1 58 219
assign 1 58 220
has 1 58 220
assign 1 0 222
assign 1 0 225
assign 1 0 229
assign 1 0 232
assign 1 0 235
assign 1 0 239
assign 1 58 242
def 1 58 247
assign 1 58 248
has 1 58 248
assign 1 0 250
assign 1 0 253
assign 1 0 257
assign 1 0 260
assign 1 0 263
assign 1 59 267
def 1 59 272
assign 1 60 273
toString 0 60 273
write 1 60 274
assign 1 61 275
new 0 61 275
assign 1 61 276
newlineGet 0 61 276
write 1 61 277
print 0 63 280
assign 1 66 283
nextDescendGet 0 66 283
return 1 66 284
return 1 0 287
return 1 0 290
assign 1 0 293
assign 1 0 297
return 1 0 301
return 1 0 304
assign 1 0 307
assign 1 0 311
return 1 0 315
return 1 0 318
assign 1 0 321
assign 1 0 325
return 1 0 329
return 1 0 332
assign 1 0 335
assign 1 0 339
return 1 0 343
return 1 0 346
assign 1 0 349
assign 1 0 353
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1521004371: return bem_copy_0();
case -907702096: return bem_once_0();
case 57422458: return bem_printAstElementsGet_0();
case 831513957: return bem_iteratorGet_0();
case 1097464934: return bem_print_0();
case 2035747151: return bem_printAstElementsGetDirect_0();
case 48884000: return bem_buildGet_0();
case 1121605448: return bem_serializeToString_0();
case -394574869: return bem_fGetDirect_0();
case -1413337062: return bem_transGet_0();
case -949791836: return bem_ntypesGetDirect_0();
case 268640521: return bem_hashGet_0();
case 2143550869: return bem_new_0();
case 885128203: return bem_create_0();
case 2072217533: return bem_constGetDirect_0();
case 1294757574: return bem_tagGet_0();
case 1234776985: return bem_constGet_0();
case 1159622845: return bem_echo_0();
case 1717240546: return bem_inClassGet_0();
case 444413474: return bem_toAny_0();
case -1315551696: return bem_ntypesGet_0();
case 1250827348: return bem_allAstElementsGet_0();
case -621942588: return bem_allAstElementsGetDirect_0();
case -2010885181: return bem_many_0();
case 1523724038: return bem_sourceFileNameGet_0();
case -730552231: return bem_fieldIteratorGet_0();
case 190810501: return bem_inClassMethodGet_0();
case 1377735259: return bem_transGetDirect_0();
case 84009197: return bem_deserializeClassNameGet_0();
case -843126344: return bem_serializationIteratorGet_0();
case -202510124: return bem_inClassMethodGetDirect_0();
case -649199060: return bem_serializeContents_0();
case 729500141: return bem_fGet_0();
case -1196401912: return bem_buildGetDirect_0();
case 2057652625: return bem_fieldNamesGet_0();
case -2060917023: return bem_classNameGet_0();
case 849543529: return bem_inClassGetDirect_0();
case -1333696208: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 85498757: return bem_ntypesSetDirect_1(bevd_0);
case 1676119850: return bem_inClassSetDirect_1(bevd_0);
case -1550385100: return bem_transSetDirect_1(bevd_0);
case 1899029531: return bem_fSet_1(bevd_0);
case -1261995806: return bem_allAstElementsSet_1(bevd_0);
case 171056025: return bem_defined_1(bevd_0);
case -933911215: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 775033796: return bem_sameClass_1(bevd_0);
case -351226620: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 852684200: return bem_inClassMethodSetDirect_1(bevd_0);
case 106370956: return bem_printAstElementsSetDirect_1(bevd_0);
case 288210658: return bem_ntypesSet_1(bevd_0);
case 544363262: return bem_otherClass_1(bevd_0);
case -571354968: return bem_notEquals_1(bevd_0);
case -1888439820: return bem_buildSet_1(bevd_0);
case -1155685893: return bem_transSet_1(bevd_0);
case -1023642656: return bem_fSetDirect_1(bevd_0);
case -1776510589: return bem_copyTo_1(bevd_0);
case 1189274855: return bem_sameType_1(bevd_0);
case -1417473277: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1400683696: return bem_inClassSet_1(bevd_0);
case -1035577062: return bem_equals_1(bevd_0);
case -873749918: return bem_begin_1(bevd_0);
case 2031133019: return bem_end_1(bevd_0);
case 82127106: return bem_constSetDirect_1(bevd_0);
case 459298083: return bem_otherType_1(bevd_0);
case -1863207166: return bem_def_1(bevd_0);
case 1947170687: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1290184008: return bem_constSet_1(bevd_0);
case 2123468926: return bem_sameObject_1(bevd_0);
case 1719411527: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1114550651: return bem_undefined_1(bevd_0);
case 1446503398: return bem_allAstElementsSetDirect_1(bevd_0);
case 740349917: return bem_inClassMethodSet_1(bevd_0);
case -839680850: return bem_undef_1(bevd_0);
case 1678647703: return bem_printAstElementsSet_1(bevd_0);
case -690118127: return bem_buildSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 661608167: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 319580096: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -111616333: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -87616259: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 710208868: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 520958435: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -842656681: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -553894493: return bem_new_2((BEC_2_9_3_ContainerSet) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass1_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass1_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass1();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst = (BEC_3_5_5_5_BuildVisitPass1) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;
}
}
