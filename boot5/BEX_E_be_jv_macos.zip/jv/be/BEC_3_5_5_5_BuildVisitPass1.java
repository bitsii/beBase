package be;
/* IO:File: source/build/Pass1.be */
public final class BEC_3_5_5_5_BuildVisitPass1 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass1() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_0 = {};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_1 = {0x2E};
public static BEC_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;

public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_allAstElements;
public BEC_2_6_6_SystemObject bevp_f;
public BEC_2_4_6_TextString bevp_inClass;
public BEC_2_4_6_TextString bevp_inClassMethod;
public BEC_3_5_5_5_BuildVisitPass1 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_new_2(BEC_2_9_3_ContainerSet beva__printAstElements, BEC_2_4_6_TextString beva__fname) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_2_4_IOFile bevt_2_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_3_ta_ph = null;
bevp_printAstElements = beva__printAstElements;
bevp_allAstElements = bevp_printAstElements.bem_isEmptyGet_0();
if (beva__fname == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_3_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva__fname);
bevt_2_ta_ph = bevt_3_ta_ph.bem_fileGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_writerGet_0();
bevp_f = bevt_1_ta_ph.bemd_0(35451404);
} /* Line: 26*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_inLine = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_7_TextStrings bevt_46_ta_ph = null;
BEC_2_5_4_BuildNode bevt_47_ta_ph = null;
bevt_5_ta_ph = beva_node.bem_typenameGet_0();
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_5_ta_ph.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 35*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_sameType_1(bevt_9_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 36*/ {
bevp_inClass = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 37*/
 else /* Line: 38*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(145041249);
bevp_inClass = (BEC_2_4_6_TextString) bevt_10_ta_ph.bemd_0(-1877158914);
} /* Line: 39*/
bevp_inClassMethod = null;
bevl_inLine = null;
} /* Line: 42*/
bevt_13_ta_ph = beva_node.bem_typenameGet_0();
bevt_14_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_13_ta_ph.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevp_inClass == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_18_ta_ph = beva_node.bem_heldGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bem_sameType_1(bevt_18_ta_ph);
if (bevt_16_ta_ph.bevi_bool)/* Line: 45*/ {
bevp_inClassMethod = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 46*/
 else /* Line: 45*/ {
bevt_21_ta_ph = beva_node.bem_heldGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(626417259);
if (bevt_20_ta_ph == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_22_ta_ph = bevp_inClass.bem_add_1(bevt_23_ta_ph);
bevt_25_ta_ph = beva_node.bem_heldGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(626417259);
bevp_inClassMethod = bevt_22_ta_ph.bem_add_1(bevt_24_ta_ph);
} /* Line: 48*/
 else /* Line: 45*/ {
bevt_28_ta_ph = beva_node.bem_heldGet_0();
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(408903881);
if (bevt_27_ta_ph == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_29_ta_ph = bevp_inClass.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = beva_node.bem_heldGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bemd_0(408903881);
bevp_inClassMethod = bevt_29_ta_ph.bem_add_1(bevt_31_ta_ph);
} /* Line: 50*/
} /* Line: 45*/
} /* Line: 45*/
} /* Line: 45*/
if (bevp_inClassMethod == null) {
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_35_ta_ph = beva_node.bem_nlcGet_0();
if (bevt_35_ta_ph == null) {
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 54*/
 else /* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 54*/ {
bevt_37_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_36_ta_ph = bevp_inClassMethod.bem_add_1(bevt_37_ta_ph);
bevt_38_ta_ph = beva_node.bem_nlcGet_0();
bevl_inLine = bevt_36_ta_ph.bem_add_1(bevt_38_ta_ph);
} /* Line: 55*/
if (bevp_allAstElements.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
if (bevp_inClassMethod == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_40_ta_ph = bevp_printAstElements.bem_has_1(bevp_inClassMethod);
if (bevt_40_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
if (bevl_inLine == null) {
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_42_ta_ph = bevp_printAstElements.bem_has_1(bevl_inLine);
if (bevt_42_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 57*/ {
if (bevp_f == null) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 58*/ {
bevt_44_ta_ph = beva_node.bem_toString_0();
bevp_f.bemd_1(913054634, bevt_44_ta_ph);
bevt_46_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_45_ta_ph = bevt_46_ta_ph.bem_newlineGet_0();
bevp_f.bemd_1(913054634, bevt_45_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
beva_node.bem_print_0();
} /* Line: 62*/
} /* Line: 58*/
bevt_47_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_47_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAstElementsGet_0() throws Throwable {
return bevp_allAstElements;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_allAstElementsGetDirect_0() throws Throwable {
return bevp_allAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fGet_0() throws Throwable {
return bevp_f;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fGetDirect_0() throws Throwable {
return bevp_f;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_fSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_f = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_fSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_f = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public final BEC_2_4_6_TextString bem_inClassGetDirect_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassMethodGet_0() throws Throwable {
return bevp_inClassMethod;
} /*method end*/
public final BEC_2_4_6_TextString bem_inClassMethodGetDirect_0() throws Throwable {
return bevp_inClassMethod;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 25, 26, 26, 26, 26, 35, 35, 35, 35, 36, 36, 36, 37, 39, 39, 39, 41, 42, 44, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 45, 46, 47, 47, 47, 47, 48, 48, 48, 48, 48, 49, 49, 49, 49, 50, 50, 50, 50, 50, 54, 54, 54, 54, 54, 0, 0, 0, 55, 55, 55, 55, 0, 57, 57, 57, 0, 0, 0, 0, 0, 0, 57, 57, 57, 0, 0, 0, 0, 0, 58, 58, 59, 59, 60, 60, 60, 62, 65, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 33, 34, 35, 36, 37, 91, 92, 93, 98, 99, 100, 101, 103, 106, 107, 108, 110, 111, 113, 114, 115, 120, 121, 126, 127, 130, 134, 137, 138, 139, 141, 144, 145, 146, 151, 152, 153, 154, 155, 156, 159, 160, 161, 166, 167, 168, 169, 170, 171, 176, 181, 182, 183, 188, 189, 192, 196, 199, 200, 201, 202, 205, 208, 213, 214, 216, 219, 223, 226, 229, 233, 236, 241, 242, 244, 247, 251, 254, 257, 261, 266, 267, 268, 269, 270, 271, 274, 277, 278, 281, 284, 287, 291, 295, 298, 301, 305, 309, 312, 315, 319, 323, 326, 329, 333, 337, 340, 343, 347};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 26
assign 1 24 27
isEmptyGet 0 24 27
assign 1 25 28
def 1 25 33
assign 1 26 34
new 1 26 34
assign 1 26 35
fileGet 0 26 35
assign 1 26 36
writerGet 0 26 36
assign 1 26 37
open 0 26 37
assign 1 35 91
typenameGet 0 35 91
assign 1 35 92
CLASSGet 0 35 92
assign 1 35 93
equals 1 35 98
assign 1 36 99
new 0 36 99
assign 1 36 100
heldGet 0 36 100
assign 1 36 101
sameType 1 36 101
assign 1 37 103
heldGet 0 37 103
assign 1 39 106
heldGet 0 39 106
assign 1 39 107
namepathGet 0 39 107
assign 1 39 108
toString 0 39 108
assign 1 41 110
assign 1 42 111
assign 1 44 113
typenameGet 0 44 113
assign 1 44 114
METHODGet 0 44 114
assign 1 44 115
equals 1 44 120
assign 1 44 121
def 1 44 126
assign 1 0 127
assign 1 0 130
assign 1 0 134
assign 1 45 137
new 0 45 137
assign 1 45 138
heldGet 0 45 138
assign 1 45 139
sameType 1 45 139
assign 1 46 141
heldGet 0 46 141
assign 1 47 144
heldGet 0 47 144
assign 1 47 145
orgNameGet 0 47 145
assign 1 47 146
def 1 47 151
assign 1 48 152
new 0 48 152
assign 1 48 153
add 1 48 153
assign 1 48 154
heldGet 0 48 154
assign 1 48 155
orgNameGet 0 48 155
assign 1 48 156
add 1 48 156
assign 1 49 159
heldGet 0 49 159
assign 1 49 160
nameGet 0 49 160
assign 1 49 161
def 1 49 166
assign 1 50 167
new 0 50 167
assign 1 50 168
add 1 50 168
assign 1 50 169
heldGet 0 50 169
assign 1 50 170
nameGet 0 50 170
assign 1 50 171
add 1 50 171
assign 1 54 176
def 1 54 181
assign 1 54 182
nlcGet 0 54 182
assign 1 54 183
def 1 54 188
assign 1 0 189
assign 1 0 192
assign 1 0 196
assign 1 55 199
new 0 55 199
assign 1 55 200
add 1 55 200
assign 1 55 201
nlcGet 0 55 201
assign 1 55 202
add 1 55 202
assign 1 0 205
assign 1 57 208
def 1 57 213
assign 1 57 214
has 1 57 214
assign 1 0 216
assign 1 0 219
assign 1 0 223
assign 1 0 226
assign 1 0 229
assign 1 0 233
assign 1 57 236
def 1 57 241
assign 1 57 242
has 1 57 242
assign 1 0 244
assign 1 0 247
assign 1 0 251
assign 1 0 254
assign 1 0 257
assign 1 58 261
def 1 58 266
assign 1 59 267
toString 0 59 267
write 1 59 268
assign 1 60 269
new 0 60 269
assign 1 60 270
newlineGet 0 60 270
write 1 60 271
print 0 62 274
assign 1 65 277
nextDescendGet 0 65 277
return 1 65 278
return 1 0 281
return 1 0 284
assign 1 0 287
assign 1 0 291
return 1 0 295
return 1 0 298
assign 1 0 301
assign 1 0 305
return 1 0 309
return 1 0 312
assign 1 0 315
assign 1 0 319
return 1 0 323
return 1 0 326
assign 1 0 329
assign 1 0 333
return 1 0 337
return 1 0 340
assign 1 0 343
assign 1 0 347
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -311019361: return bem_inClassMethodGet_0();
case 1581666123: return bem_fieldNamesGet_0();
case -1104258259: return bem_classNameGet_0();
case -1578643325: return bem_fGetDirect_0();
case -839101861: return bem_transGet_0();
case -1726772933: return bem_allAstElementsGetDirect_0();
case -500407962: return bem_inClassGetDirect_0();
case 848501271: return bem_ntypesGet_0();
case -2137674168: return bem_allAstElementsGet_0();
case 1198306290: return bem_constGet_0();
case 716688210: return bem_constGetDirect_0();
case -866936322: return bem_ntypesGetDirect_0();
case -1877158914: return bem_toString_0();
case -933021175: return bem_printAstElementsGetDirect_0();
case -548661343: return bem_print_0();
case 805022552: return bem_iteratorGet_0();
case 1906024104: return bem_new_0();
case -1740139760: return bem_hashGet_0();
case -380002249: return bem_buildGetDirect_0();
case 53861742: return bem_tagGet_0();
case 2014565793: return bem_inClassMethodGetDirect_0();
case -154100044: return bem_inClassGet_0();
case 718704900: return bem_transGetDirect_0();
case 724324530: return bem_printAstElementsGet_0();
case -881029601: return bem_sourceFileNameGet_0();
case 501632472: return bem_buildGet_0();
case 911217281: return bem_create_0();
case 312867770: return bem_copy_0();
case -227184234: return bem_fGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 489253828: return bem_otherClass_1(bevd_0);
case -1396194631: return bem_fSetDirect_1(bevd_0);
case 18677202: return bem_equals_1(bevd_0);
case -1967486805: return bem_inClassSetDirect_1(bevd_0);
case 1255589592: return bem_copyTo_1(bevd_0);
case -714827161: return bem_buildSet_1(bevd_0);
case -2137582298: return bem_inClassSet_1(bevd_0);
case -1559820130: return bem_transSet_1(bevd_0);
case 314517158: return bem_allAstElementsSetDirect_1(bevd_0);
case -1211508910: return bem_end_1(bevd_0);
case 558249851: return bem_notEquals_1(bevd_0);
case -163764740: return bem_fSet_1(bevd_0);
case -793898572: return bem_inClassMethodSet_1(bevd_0);
case 621846611: return bem_constSet_1(bevd_0);
case 1411685846: return bem_constSetDirect_1(bevd_0);
case 1376758358: return bem_otherType_1(bevd_0);
case 914750490: return bem_ntypesSet_1(bevd_0);
case -1887247579: return bem_sameObject_1(bevd_0);
case 1522481948: return bem_printAstElementsSet_1(bevd_0);
case 1264813341: return bem_begin_1(bevd_0);
case -1196243234: return bem_allAstElementsSet_1(bevd_0);
case -1388715556: return bem_transSetDirect_1(bevd_0);
case -1560907688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1293339574: return bem_undef_1(bevd_0);
case -1298677367: return bem_sameClass_1(bevd_0);
case 1114301310: return bem_def_1(bevd_0);
case -134002111: return bem_ntypesSetDirect_1(bevd_0);
case 1949518220: return bem_inClassMethodSetDirect_1(bevd_0);
case 1758484750: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1749803472: return bem_buildSetDirect_1(bevd_0);
case 1433290729: return bem_sameType_1(bevd_0);
case 1486679984: return bem_printAstElementsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 465163535: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -980431762: return bem_new_2((BEC_2_9_3_ContainerSet) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 290208042: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 332629402: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 732425668: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -772732651: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass1_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass1_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass1();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst = (BEC_3_5_5_5_BuildVisitPass1) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;
}
}
