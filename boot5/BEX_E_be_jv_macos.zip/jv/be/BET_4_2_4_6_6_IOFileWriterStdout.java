package be;
public class BET_4_2_4_6_6_IOFileWriterStdout extends BETS_Object {
public BET_4_2_4_6_6_IOFileWriterStdout() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "vfileGet_0", "vfileSet_1", "extOpen_0", "close_0", "write_1", "writeStringClose_1", "isClosedGet_0", "isClosedSet_1", "new_1", "openTruncate_0", "openAppend_0", "open_0", "open_1", "pathGet_0", "pathSet_1", "default_0" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "vfile", "isClosed", "path" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_4_2_4_6_6_IOFileWriterStdout();
}
}
