package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;

public static BET_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_0() throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bem_new_0();
bevp_lock.bem_lock_0();
try /* Line: 951*/ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 953*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 956*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_oGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 962*/ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 964*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 967*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 974*/ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 977*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 980*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
bevl_res = be.BECS_Runtime.boolFalse;
try /* Line: 988*/ {
if (bevp_obj == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 989*/ {
bevp_obj = beva__obj;
bevl_res = be.BECS_Runtime.boolTrue;
} /* Line: 991*/
bevp_lock.bem_unlock_0();
} /* Line: 993*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 996*/
return bevl_res;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 1003*/ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1005*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1008*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_oGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_oSet_1(beva__obj);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objGet_0() throws Throwable {
return bevp_obj;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_objGetDirect_0() throws Throwable {
return bevp_obj;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_obj = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_objSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_obj = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {941, 946, 950, 952, 953, 955, 956, 961, 963, 964, 966, 967, 969, 973, 975, 976, 977, 979, 980, 982, 986, 987, 989, 989, 990, 991, 993, 995, 996, 998, 1002, 1004, 1005, 1007, 1008, 1013, 1013, 1017, 1017, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 56, 60, 61, 63, 69, 70, 72, 77, 78, 79, 81, 85, 86, 88, 92, 94, 95, 99, 100, 106, 107, 111, 112, 115, 118, 121, 125, 129, 132, 135, 139};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 941 16
new 0 941 16
new 0 946 21
lock 0 950 22
assign 1 952 24
unlock 0 953 25
unlock 0 955 29
throw 1 956 30
lock 0 961 37
assign 1 963 39
unlock 0 964 40
unlock 0 966 44
throw 1 967 45
return 1 969 47
lock 0 973 52
assign 1 975 54
assign 1 976 55
unlock 0 977 56
unlock 0 979 60
throw 1 980 61
return 1 982 63
lock 0 986 69
assign 1 987 70
new 0 987 70
assign 1 989 72
undef 1 989 77
assign 1 990 78
assign 1 991 79
new 0 991 79
unlock 0 993 81
unlock 0 995 85
throw 1 996 86
return 1 998 88
lock 0 1002 92
assign 1 1004 94
unlock 0 1005 95
unlock 0 1007 99
throw 1 1008 100
assign 1 1013 106
oGet 0 1013 106
return 1 1013 107
assign 1 1017 111
oSet 1 1017 111
return 1 1017 112
return 1 0 115
return 1 0 118
assign 1 0 121
assign 1 0 125
return 1 0 129
return 1 0 132
assign 1 0 135
assign 1 0 139
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 711936274: return bem_lockGet_0();
case -1277154358: return bem_oGet_0();
case 1393634620: return bem_serializeToString_0();
case 1786844370: return bem_objGetDirect_0();
case 873828646: return bem_deserializeClassNameGet_0();
case -157777737: return bem_fieldIteratorGet_0();
case 785161348: return bem_fieldNamesGet_0();
case -281350604: return bem_serializeContents_0();
case 1005443364: return bem_create_0();
case -2131640624: return bem_new_0();
case 1587133120: return bem_classNameGet_0();
case -1286135694: return bem_getAndClear_0();
case 969994032: return bem_serializationIteratorGet_0();
case 2113534779: return bem_hashGet_0();
case 1438534895: return bem_lockGetDirect_0();
case 1645989341: return bem_iteratorGet_0();
case -270571456: return bem_objGet_0();
case 1464527658: return bem_toString_0();
case 2071875109: return bem_sourceFileNameGet_0();
case 566573794: return bem_tagGet_0();
case 239077256: return bem_print_0();
case 350812655: return bem_copy_0();
case 1864861581: return bem_echo_0();
case 2082001281: return bem_objectGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -396283576: return bem_undef_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case 999624882: return bem_objSet_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case 522008215: return bem_setIfClear_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -1581230672: return bem_lockSet_1(bevd_0);
case -1085120349: return bem_objSetDirect_1(bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case 1454812293: return bem_objectSet_1(bevd_0);
case -1353668075: return bem_new_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1860524531: return bem_lockSetDirect_1(bevd_0);
case -1989004063: return bem_oSet_1(bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;
}
}
