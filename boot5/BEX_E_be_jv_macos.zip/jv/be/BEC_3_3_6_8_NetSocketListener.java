package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_8_NetSocketListener extends BEC_2_6_6_SystemObject {
public BEC_3_3_6_8_NetSocketListener() { }

  public ServerSocket bevi_listener;
  private static byte[] becc_BEC_3_3_6_8_NetSocketListener_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x4C,0x69,0x73,0x74,0x65,0x6E,0x65,0x72};
private static byte[] becc_BEC_3_3_6_8_NetSocketListener_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_3_6_8_NetSocketListener_bels_0 = {0x30,0x2E,0x30,0x2E,0x30,0x2E,0x30};
public static BEC_3_3_6_8_NetSocketListener bece_BEC_3_3_6_8_NetSocketListener_bevs_inst;

public static BET_3_3_6_8_NetSocketListener bece_BEC_3_3_6_8_NetSocketListener_bevs_type;

public BEC_2_4_6_TextString bevp_address;
public BEC_2_4_3_MathInt bevp_port;
public BEC_2_4_3_MathInt bevp_backlog;
public BEC_3_3_6_8_NetSocketListener bem_new_2(BEC_2_4_6_TextString beva__address, BEC_2_4_3_MathInt beva__port) throws Throwable {
bevp_address = beva__address;
bevp_port = beva__port;
bevp_backlog = (new BEC_2_4_3_MathInt(25));
return this;
} /*method end*/
public BEC_3_3_6_8_NetSocketListener bem_new_1(BEC_2_4_3_MathInt beva__port) throws Throwable {
bevp_address = (new BEC_2_4_6_TextString(7, bece_BEC_3_3_6_8_NetSocketListener_bels_0));
bevp_port = beva__port;
bevp_backlog = (new BEC_2_4_3_MathInt(25));
return this;
} /*method end*/
public BEC_3_3_6_8_NetSocketListener bem_bind_0() throws Throwable {

    bevi_listener = new ServerSocket(bevp_port.bevi_int, bevp_backlog.bevi_int, InetAddress.getByName(bevp_address.bems_toJvString()));
    return this;
} /*method end*/
public BEC_2_3_6_NetSocket bem_accept_0() throws Throwable {
BEC_2_3_6_NetSocket bevl_s = null;
bevl_s = (BEC_2_3_6_NetSocket) (new BEC_2_3_6_NetSocket());

    bevl_s.bevi_socket = bevi_listener.accept();
    return bevl_s;
} /*method end*/
public BEC_2_4_6_TextString bem_addressGet_0() throws Throwable {
return bevp_address;
} /*method end*/
public BEC_3_3_6_8_NetSocketListener bem_addressSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_address = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_portGet_0() throws Throwable {
return bevp_port;
} /*method end*/
public BEC_3_3_6_8_NetSocketListener bem_portSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_port = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_backlogGet_0() throws Throwable {
return bevp_backlog;
} /*method end*/
public BEC_3_3_6_8_NetSocketListener bem_backlogSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_backlog = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {829, 830, 831, 838, 839, 840, 865, 876, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 22, 26, 27, 28, 38, 41, 44, 47, 51, 54, 58, 61};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 829 20
assign 1 830 21
assign 1 831 22
new 0 831 22
assign 1 838 26
new 0 838 26
assign 1 839 27
assign 1 840 28
new 0 840 28
assign 1 865 38
new 0 865 38
return 1 876 41
return 1 0 44
assign 1 0 47
return 1 0 51
assign 1 0 54
return 1 0 58
assign 1 0 61
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 603718350: return bem_print_0();
case -1147088242: return bem_create_0();
case -1158792828: return bem_backlogGet_0();
case 649475894: return bem_accept_0();
case 380806302: return bem_new_0();
case 53308341: return bem_toString_0();
case 1735342155: return bem_portGet_0();
case -615427058: return bem_iteratorGet_0();
case -1087891034: return bem_copy_0();
case -2066440059: return bem_addressGet_0();
case -1795256110: return bem_bind_0();
case -716837866: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1554282063: return bem_notEquals_1(bevd_0);
case -538424851: return bem_portSet_1(bevd_0);
case 1209125372: return bem_undef_1(bevd_0);
case -1237306698: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1462940865: return bem_copyTo_1(bevd_0);
case 1738005159: return bem_equals_1(bevd_0);
case 1897598917: return bem_addressSet_1(bevd_0);
case -1137828856: return bem_backlogSet_1(bevd_0);
case 971589665: return bem_def_1(bevd_0);
case 20832777: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -29663031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1804495597: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1505420135: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2021917335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 559223927: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1581466981: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_3_6_8_NetSocketListener_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_8_NetSocketListener_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_8_NetSocketListener();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_8_NetSocketListener.bece_BEC_3_3_6_8_NetSocketListener_bevs_inst = (BEC_3_3_6_8_NetSocketListener) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_8_NetSocketListener.bece_BEC_3_3_6_8_NetSocketListener_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_8_NetSocketListener.bece_BEC_3_3_6_8_NetSocketListener_bevs_type;
}
}
