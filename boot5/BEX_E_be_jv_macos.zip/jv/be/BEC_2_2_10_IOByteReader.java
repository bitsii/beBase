package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_10_IOByteReader extends BEC_2_6_6_SystemObject {
public BEC_2_2_10_IOByteReader() { }
private static byte[] becc_BEC_2_2_10_IOByteReader_clname = {0x49,0x4F,0x3A,0x42,0x79,0x74,0x65,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_10_IOByteReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_inst;

public static BET_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_type;

public BEC_2_2_6_IOReader bevp_reader;
public BEC_2_4_6_TextString bevp_buf;
public BEC_2_4_12_TextByteIterator bevp_iter;
public BEC_2_2_10_IOByteReader bem_readerBufferNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_6_TextString beva__buf) throws Throwable {
bevp_reader = beva__reader;
bevp_buf = beva__buf;
bevp_iter = bevp_buf.bem_biterGet_0();
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerNew_1(BEC_2_2_6_IOReader beva__reader) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(256));
bevt_0_ta_ph = bem_readerBlockNew_2(beva__reader, bevt_1_ta_ph);
return (BEC_2_2_10_IOByteReader) bevt_0_ta_ph;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerBlockNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_3_MathInt beva__blockSize) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva__blockSize);
bevt_0_ta_ph = bem_readerBufferNew_2(beva__reader, bevt_1_ta_ph);
return (BEC_2_2_10_IOByteReader) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_iter.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 39*/ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_ta_ph);
} /* Line: 41*/
bevt_3_ta_ph = bevp_iter.bem_hasNextGet_0();
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_dest) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_iter.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 51*/ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_ta_ph);
} /* Line: 53*/
bevt_3_ta_ph = bevp_iter.bem_next_1(beva_dest);
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_2_6_IOReader bem_readerGet_0() throws Throwable {
return bevp_reader;
} /*method end*/
public final BEC_2_2_6_IOReader bem_readerGetDirect_0() throws Throwable {
return bevp_reader;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_bufGet_0() throws Throwable {
return bevp_buf;
} /*method end*/
public final BEC_2_4_6_TextString bem_bufGetDirect_0() throws Throwable {
return bevp_buf;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_bufSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_bufSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_iterGetDirect_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_10_IOByteReader bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 25, 26, 31, 31, 31, 35, 35, 35, 39, 39, 39, 40, 41, 41, 43, 43, 47, 47, 47, 47, 51, 51, 51, 52, 53, 53, 55, 55, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 23, 24, 25, 30, 31, 32, 39, 40, 45, 46, 47, 48, 50, 51, 57, 58, 59, 60, 67, 68, 73, 74, 75, 76, 78, 79, 82, 85, 88, 92, 96, 99, 102, 106, 110, 113, 116, 120};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 15
assign 1 25 16
assign 1 26 17
biterGet 0 26 17
assign 1 31 23
new 0 31 23
assign 1 31 24
readerBlockNew 2 31 24
return 1 31 25
assign 1 35 30
new 1 35 30
assign 1 35 31
readerBufferNew 2 35 31
return 1 35 32
assign 1 39 39
hasNextGet 0 39 39
assign 1 39 40
not 0 39 45
readIntoBuffer 1 40 46
assign 1 41 47
new 0 41 47
posSet 1 41 48
assign 1 43 50
hasNextGet 0 43 50
return 1 43 51
assign 1 47 57
new 0 47 57
assign 1 47 58
new 1 47 58
assign 1 47 59
next 1 47 59
return 1 47 60
assign 1 51 67
hasNextGet 0 51 67
assign 1 51 68
not 0 51 73
readIntoBuffer 1 52 74
assign 1 53 75
new 0 53 75
posSet 1 53 76
assign 1 55 78
next 1 55 78
return 1 55 79
return 1 0 82
return 1 0 85
assign 1 0 88
assign 1 0 92
return 1 0 96
return 1 0 99
assign 1 0 102
assign 1 0 106
return 1 0 110
return 1 0 113
assign 1 0 116
assign 1 0 120
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 67700549: return bem_classNameGet_0();
case -681478278: return bem_nextGet_0();
case 138302413: return bem_new_0();
case 1023013074: return bem_bufGetDirect_0();
case -1627734356: return bem_serializeToString_0();
case 556090396: return bem_sourceFileNameGet_0();
case 432179744: return bem_fieldNamesGet_0();
case 178019168: return bem_toString_0();
case 1609612359: return bem_echo_0();
case -2132683432: return bem_iterGetDirect_0();
case 2036051475: return bem_iteratorGet_0();
case -2106036149: return bem_deserializeClassNameGet_0();
case -2145609558: return bem_readerGetDirect_0();
case 407759862: return bem_bufGet_0();
case 1132429880: return bem_tagGet_0();
case 1267631579: return bem_serializationIteratorGet_0();
case 478950400: return bem_print_0();
case -811046848: return bem_copy_0();
case -1564975844: return bem_serializeContents_0();
case -82406951: return bem_iterGet_0();
case 712783465: return bem_hashGet_0();
case -1812965558: return bem_fieldIteratorGet_0();
case -1996656571: return bem_readerGet_0();
case 1315977308: return bem_hasNextGet_0();
case -1747597055: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 465594002: return bem_def_1(bevd_0);
case -2043054404: return bem_readerNew_1((BEC_2_2_6_IOReader) bevd_0);
case -1447400213: return bem_readerSet_1(bevd_0);
case 2059692827: return bem_sameObject_1(bevd_0);
case -283173446: return bem_iterSet_1(bevd_0);
case -1084952852: return bem_undef_1(bevd_0);
case -225795861: return bem_sameType_1(bevd_0);
case -60802666: return bem_otherClass_1(bevd_0);
case 2107311680: return bem_notEquals_1(bevd_0);
case -951859496: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 1398899696: return bem_readerSetDirect_1(bevd_0);
case -1825923898: return bem_bufSetDirect_1(bevd_0);
case 1555593705: return bem_iterSetDirect_1(bevd_0);
case 1184247111: return bem_sameClass_1(bevd_0);
case 399670111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -301008142: return bem_equals_1(bevd_0);
case 672778758: return bem_bufSet_1(bevd_0);
case 606870566: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 257683973: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1964074985: return bem_otherType_1(bevd_0);
case 1951774795: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1294418403: return bem_readerBufferNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1679235980: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1666369147: return bem_readerBlockNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1107212100: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1035176912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 471675441: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1306506121: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_2_10_IOByteReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_10_IOByteReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_10_IOByteReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst = (BEC_2_2_10_IOByteReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_type;
}
}
