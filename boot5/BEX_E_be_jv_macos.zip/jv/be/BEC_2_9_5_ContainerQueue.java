package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerQueue extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerQueue() { }
private static byte[] becc_BEC_2_9_5_ContainerQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_5_ContainerQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_inst;

public static BET_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_bottom;
public BEC_3_9_5_4_ContainerStackNode bevp_end;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_5_ContainerQueue bem_new_0() throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_enqueue_1(beva_item);
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 131*/ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_end = bevp_top;
bevp_bottom = bevp_top;
} /* Line: 134*/
 else /* Line: 131*/ {
if (bevp_bottom == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 135*/ {
bevt_3_ta_ph = bevp_top.bem_nextGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 136*/ {
bevt_4_ta_ph = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_ta_ph);
bevt_5_ta_ph = bevp_top.bem_nextGet_0();
bevt_5_ta_ph.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
bevp_end = bevp_top;
} /* Line: 140*/
 else /* Line: 141*/ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 142*/
} /* Line: 136*/
 else /* Line: 144*/ {
bevp_bottom = bevp_top;
} /* Line: 145*/
} /* Line: 131*/
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dequeue_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_item = null;
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevp_bottom == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
return null;
} /* Line: 153*/
bevl_item = bevp_bottom.bem_heldGet_0();
bevp_bottom.bem_heldSet_1(null);
bevt_1_ta_ph = bevp_bottom.bem_equals_1(bevp_top);
if (bevt_1_ta_ph.bevi_bool)/* Line: 157*/ {
bevp_bottom = null;
} /* Line: 158*/
 else /* Line: 159*/ {
bevl_last = bevp_bottom;
bevp_bottom = bevp_bottom.bem_nextGet_0();
bevl_last.bem_nextSet_1(null);
bevl_last.bem_priorSet_1(bevp_end);
bevp_end.bem_nextSet_1(bevl_last);
bevp_end = bevl_last;
} /* Line: 166*/
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_bottom == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_dequeue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_9_5_ContainerQueue bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_enqueue_1(beva_item);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_bottomGet_0() throws Throwable {
return bevp_bottom;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_bottomSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_endGet_0() throws Throwable {
return bevp_end;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_endSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {121, 127, 131, 131, 132, 133, 134, 135, 135, 136, 136, 136, 137, 137, 138, 138, 139, 140, 142, 145, 147, 148, 152, 152, 153, 155, 156, 157, 158, 161, 162, 163, 164, 165, 166, 168, 169, 173, 173, 177, 177, 181, 181, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 20, 30, 35, 36, 37, 38, 41, 46, 47, 48, 53, 54, 55, 56, 57, 58, 59, 62, 66, 69, 70, 78, 83, 84, 86, 87, 88, 90, 93, 94, 95, 96, 97, 98, 100, 101, 105, 110, 114, 115, 119, 120, 123, 126, 130, 133, 137, 140, 144, 147};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 121 16
new 0 121 16
enqueue 1 127 20
assign 1 131 30
undef 1 131 35
assign 1 132 36
new 0 132 36
assign 1 133 37
assign 1 134 38
assign 1 135 41
def 1 135 46
assign 1 136 47
nextGet 0 136 47
assign 1 136 48
undef 1 136 53
assign 1 137 54
new 0 137 54
nextSet 1 137 55
assign 1 138 56
nextGet 0 138 56
priorSet 1 138 57
assign 1 139 58
nextGet 0 139 58
assign 1 140 59
assign 1 142 62
nextGet 0 142 62
assign 1 145 66
heldSet 1 147 69
assign 1 148 70
increment 0 148 70
assign 1 152 78
undef 1 152 83
return 1 153 84
assign 1 155 86
heldGet 0 155 86
heldSet 1 156 87
assign 1 157 88
equals 1 157 88
assign 1 158 90
assign 1 161 93
assign 1 162 94
nextGet 0 162 94
nextSet 1 163 95
priorSet 1 164 96
nextSet 1 165 97
assign 1 166 98
assign 1 168 100
decrement 0 168 100
return 1 169 101
assign 1 173 105
undef 1 173 110
return 1 173 110
assign 1 177 114
dequeue 0 177 114
return 1 177 115
assign 1 181 119
enqueue 1 181 119
return 1 181 120
return 1 0 123
assign 1 0 126
return 1 0 130
assign 1 0 133
return 1 0 137
assign 1 0 140
return 1 0 144
assign 1 0 147
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2136008673: return bem_topGet_0();
case -303434167: return bem_copy_0();
case 1479557703: return bem_hashGet_0();
case -878157125: return bem_bottomGet_0();
case 1700002135: return bem_dequeue_0();
case -1924399923: return bem_sizeGet_0();
case 694867988: return bem_toString_0();
case -758107855: return bem_new_0();
case 1173678142: return bem_get_0();
case -141417330: return bem_isEmptyGet_0();
case 688799135: return bem_iteratorGet_0();
case 1680733853: return bem_print_0();
case -846243640: return bem_endGet_0();
case -814788939: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1571586940: return bem_addValue_1(bevd_0);
case -64545429: return bem_sizeSet_1(bevd_0);
case -1721664005: return bem_copyTo_1(bevd_0);
case 1020977760: return bem_endSet_1(bevd_0);
case 700494353: return bem_enqueue_1(bevd_0);
case 283685995: return bem_equals_1(bevd_0);
case -873437111: return bem_bottomSet_1(bevd_0);
case 916104524: return bem_topSet_1(bevd_0);
case 342133054: return bem_undef_1(bevd_0);
case -1888177940: return bem_notEquals_1(bevd_0);
case 1906491870: return bem_put_1(bevd_0);
case -376840077: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1773263525: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 807856101: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -739362181: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1388702842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerQueue_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerQueue_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerQueue();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst = (BEC_2_9_5_ContainerQueue) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_type;
}
}
