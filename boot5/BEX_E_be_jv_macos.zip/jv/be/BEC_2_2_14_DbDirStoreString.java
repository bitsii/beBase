package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_14_DbDirStoreString extends BEC_2_2_8_DbDirStore {
public BEC_2_2_14_DbDirStoreString() { }
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_14_DbDirStoreString_bels_0 = {};
public static BEC_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_inst;

public static BET_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_type;

public BEC_2_2_14_DbDirStoreString bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_14_DbDirStoreString_bels_0));
bevt_2_ta_ph = beva_id.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 356*/
 else /* Line: 356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 356*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 358*/ {
bevt_5_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = beva_object.bemd_0(53308341);
bevt_5_ta_ph.bem_contentsSet_1((BEC_2_4_6_TextString) bevt_6_ta_ph );
} /* Line: 359*/
} /* Line: 358*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
if (beva_id == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 365*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_2_14_DbDirStoreString_bels_0));
bevt_3_ta_ph = beva_id.bem_notEquals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 365*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 365*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 365*/
 else /* Line: 365*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 365*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 367*/ {
bevt_7_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_existsGet_0();
if (bevt_6_ta_ph.bevi_bool)/* Line: 367*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 367*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 367*/
 else /* Line: 367*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 367*/ {
bevt_9_ta_ph = bevl_p.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_contentsGet_0();
return bevt_8_ta_ph;
} /* Line: 368*/
} /* Line: 367*/
return null;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {356, 356, 356, 356, 0, 0, 0, 357, 358, 358, 359, 359, 359, 365, 365, 365, 365, 0, 0, 0, 366, 367, 367, 367, 367, 0, 0, 0, 368, 368, 368, 371};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 26, 27, 28, 30, 33, 37, 40, 41, 46, 47, 48, 49, 66, 71, 72, 73, 75, 78, 82, 85, 86, 91, 92, 93, 95, 98, 102, 105, 106, 107, 110};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 356 21
def 1 356 26
assign 1 356 27
new 0 356 27
assign 1 356 28
notEquals 1 356 28
assign 1 0 30
assign 1 0 33
assign 1 0 37
assign 1 357 40
getPath 1 357 40
assign 1 358 41
def 1 358 46
assign 1 359 47
fileGet 0 359 47
assign 1 359 48
toString 0 359 48
contentsSet 1 359 49
assign 1 365 66
def 1 365 71
assign 1 365 72
new 0 365 72
assign 1 365 73
notEquals 1 365 73
assign 1 0 75
assign 1 0 78
assign 1 0 82
assign 1 366 85
getPath 1 366 85
assign 1 367 86
def 1 367 91
assign 1 367 92
fileGet 0 367 92
assign 1 367 93
existsGet 0 367 93
assign 1 0 95
assign 1 0 98
assign 1 0 102
assign 1 368 105
fileGet 0 368 105
assign 1 368 106
contentsGet 0 368 106
return 1 368 107
return 1 371 110
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1933942699: return bem_serGet_0();
case 53308341: return bem_toString_0();
case 603718350: return bem_print_0();
case -716837866: return bem_hashGet_0();
case -2062033892: return bem_keyEncoderGet_0();
case 701415296: return bem_storageDirGet_0();
case -615427058: return bem_iteratorGet_0();
case -1087891034: return bem_copy_0();
case 380806302: return bem_new_0();
case -1147088242: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1554282063: return bem_notEquals_1(bevd_0);
case -734047228: return bem_keyEncoderSet_1(bevd_0);
case 1738005159: return bem_equals_1(bevd_0);
case -1348967883: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case 1003487098: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case 1283860807: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1462940865: return bem_copyTo_1(bevd_0);
case -1237306698: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 971589665: return bem_def_1(bevd_0);
case -961014619: return bem_serSet_1(bevd_0);
case 20832777: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 49038656: return bem_storageDirSet_1(bevd_0);
case 1209125372: return bem_undef_1(bevd_0);
case -1916564908: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -387996884: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -1057394812: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -29663031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -626841821: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1804495597: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1505420135: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2021917335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 559223927: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1581466981: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_2_14_DbDirStoreString_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_14_DbDirStoreString_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_14_DbDirStoreString();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst = (BEC_2_2_14_DbDirStoreString) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_type;
}
}
