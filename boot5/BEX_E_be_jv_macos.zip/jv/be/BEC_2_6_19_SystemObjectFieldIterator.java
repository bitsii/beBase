package be;
/* IO:File: source/base/OpiFc.be */
public final class BEC_2_6_19_SystemObjectFieldIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1 = {0x53,0x65,0x74};
public static BEC_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;

public static BET_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_9_4_ContainerList bevp_instFieldNames;
public BEC_2_4_3_MathInt bevp_lastidx;
public BEC_2_6_19_SystemObjectFieldIterator bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_new_2(beva__instance, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) throws Throwable {
BEC_2_6_5_SystemTypes bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevt_0_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevp_instFieldNames = bevt_0_ta_ph.bem_fieldNames_1(bevp_instance);
bevt_1_ta_ph = bevp_instFieldNames.bem_sizeGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_lastidx = bevt_1_ta_ph.bem_subtract_1(bevt_2_ta_ph);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 29*/ {
bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 30*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_pos.bevi_int < bevp_lastidx.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 35*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 36*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_pos.bevi_int <= bevp_lastidx.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 43*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bem_advance_0();
bevt_0_ta_ph = bem_currentNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_1_ta_ph = bevp_instFieldNames.bem_get_1(bevp_pos);
return (BEC_2_4_6_TextString) bevt_1_ta_ph;
} /* Line: 55*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bem_advance_0();
bevt_0_ta_ph = bem_currentGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 66*/ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0));
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_res = bevp_instance.bemd_2(900181049, bevl_invokeName, bevt_2_ta_ph);
return bevl_res;
} /* Line: 70*/
return null;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bem_advance_0();
bem_currentSet_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_9_4_ContainerList bevl_args = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 81*/ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1));
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_args = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_args.bem_put_2(bevt_3_ta_ph, beva_value);
bevp_instance.bemd_2(900181049, bevl_invokeName, bevl_args);
} /* Line: 86*/
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 91*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 91*/ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 91*/
 else /* Line: 91*/ {
break;
} /* Line: 91*/
} /* Line: 91*/
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 16, 16, 21, 22, 23, 23, 24, 24, 24, 29, 30, 35, 35, 36, 36, 38, 38, 42, 42, 43, 43, 45, 45, 49, 50, 50, 54, 55, 55, 57, 61, 62, 62, 66, 67, 68, 68, 69, 69, 70, 72, 76, 77, 81, 82, 83, 83, 84, 84, 85, 85, 86, 91, 91, 91, 92, 91};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 31, 32, 33, 34, 35, 36, 37, 42, 44, 52, 57, 58, 59, 61, 62, 68, 73, 74, 75, 77, 78, 82, 83, 84, 89, 91, 92, 94, 98, 99, 100, 109, 111, 112, 113, 114, 115, 116, 118, 121, 122, 133, 135, 136, 137, 138, 139, 140, 141, 142, 149, 152, 157, 158, 159};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 23
new 0 16 23
assign 1 16 24
new 2 16 24
return 1 16 25
assign 1 21 31
new 0 21 31
assign 1 22 32
assign 1 23 33
new 0 23 33
assign 1 23 34
fieldNames 1 23 34
assign 1 24 35
sizeGet 0 24 35
assign 1 24 36
new 0 24 36
assign 1 24 37
subtract 1 24 37
assign 1 29 42
hasNextGet 0 29 42
assign 1 30 44
increment 0 30 44
assign 1 35 52
lesser 1 35 57
assign 1 36 58
new 0 36 58
return 1 36 59
assign 1 38 61
new 0 38 61
return 1 38 62
assign 1 42 68
lesserEquals 1 42 73
assign 1 43 74
new 0 43 74
return 1 43 75
assign 1 45 77
new 0 45 77
return 1 45 78
advance 0 49 82
assign 1 50 83
currentNameGet 0 50 83
return 1 50 84
assign 1 54 89
hasCurrentGet 0 54 89
assign 1 55 91
get 1 55 91
return 1 55 92
return 1 57 94
advance 0 61 98
assign 1 62 99
currentGet 0 62 99
return 1 62 100
assign 1 66 109
hasCurrentGet 0 66 109
assign 1 67 111
currentNameGet 0 67 111
assign 1 68 112
new 0 68 112
assign 1 68 113
add 1 68 113
assign 1 69 114
new 0 69 114
assign 1 69 115
invoke 2 69 115
return 1 70 116
return 1 72 118
advance 0 76 121
currentSet 1 77 122
assign 1 81 133
hasCurrentGet 0 81 133
assign 1 82 135
currentNameGet 0 82 135
assign 1 83 136
new 0 83 136
assign 1 83 137
add 1 83 137
assign 1 84 138
new 0 84 138
assign 1 84 139
new 1 84 139
assign 1 85 140
new 0 85 140
put 2 85 141
invoke 2 86 142
assign 1 91 149
new 0 91 149
assign 1 91 152
lesser 1 91 157
nextSet 1 92 158
incrementValue 0 91 159
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1016620633: return bem_nextNameGet_0();
case 1787222330: return bem_toString_0();
case 1897138803: return bem_advance_0();
case -369118516: return bem_print_0();
case -831352109: return bem_hasCurrentGet_0();
case -219382951: return bem_iteratorGet_0();
case 233311811: return bem_nextGet_0();
case 716353022: return bem_copy_0();
case -1182092368: return bem_hasNextGet_0();
case 178947736: return bem_currentGet_0();
case -615880915: return bem_hashGet_0();
case -281246947: return bem_currentNameGet_0();
case -1324622709: return bem_create_0();
case -1319517478: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -814326554: return bem_currentSet_1(bevd_0);
case 1603919423: return bem_equals_1(bevd_0);
case 1735143092: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -508758794: return bem_undef_1(bevd_0);
case 1073835775: return bem_copyTo_1(bevd_0);
case -1254710410: return bem_notEquals_1(bevd_0);
case 1657786616: return bem_def_1(bevd_0);
case -686485735: return bem_new_1(bevd_0);
case 88292070: return bem_nextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1956825510: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -691375819: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1361437844: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 238044200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 900181049: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemObjectFieldIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_19_SystemObjectFieldIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;
}
}
