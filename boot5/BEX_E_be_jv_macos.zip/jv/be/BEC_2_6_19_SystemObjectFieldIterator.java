package be;
/* IO:File: source/base/OpiFc.be */
public final class BEC_2_6_19_SystemObjectFieldIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0 = {0x47,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0, 9));
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1 = {0x53,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1, 9));
public static BEC_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;

public static BET_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_9_4_ContainerList bevp_instFieldNames;
public BEC_2_4_3_MathInt bevp_lastidx;
public BEC_2_6_19_SystemObjectFieldIterator bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_new_2(beva__instance, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevp_instance.bemd_0(80505915);
bevt_0_tmpany_phold = bevp_instFieldNames.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_0;
bevp_lastidx = bevt_0_tmpany_phold.bem_subtract_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 31 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_pos.bevi_int < bevp_lastidx.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 36 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 37 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_pos.bevi_int <= bevp_lastidx.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 44 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bem_advance_0();
bevt_0_tmpany_phold = bem_currentNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_1_tmpany_phold = bevp_instFieldNames.bem_get_1(bevp_pos);
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /* Line: 56 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bem_advance_0();
bevt_0_tmpany_phold = bem_currentGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 67 */ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_1;
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_res = bevp_instance.bemd_2(1872811781, bevl_invokeName, bevt_2_tmpany_phold);
return bevl_res;
} /* Line: 71 */
return null;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bem_advance_0();
bem_currentSet_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_9_4_ContainerList bevl_args = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_2;
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_args = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_args.bem_put_2(bevt_3_tmpany_phold, beva_value);
bevp_instance.bemd_2(1872811781, bevl_invokeName, bevl_args);
} /* Line: 87 */
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 92 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 92 */ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 92 */
 else  /* Line: 92 */ {
break;
} /* Line: 92 */
} /* Line: 92 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_posGetDirect_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() throws Throwable {
return bevp_instance;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_instanceGetDirect_0() throws Throwable {
return bevp_instance;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_instanceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_instFieldNamesGet_0() throws Throwable {
return bevp_instFieldNames;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_instFieldNamesGetDirect_0() throws Throwable {
return bevp_instFieldNames;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instFieldNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_instFieldNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lastidxGet_0() throws Throwable {
return bevp_lastidx;
} /*method end*/
public final BEC_2_4_3_MathInt bem_lastidxGetDirect_0() throws Throwable {
return bevp_lastidx;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_lastidxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastidx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_lastidxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastidx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 17, 17, 22, 23, 24, 25, 25, 25, 30, 31, 36, 36, 37, 37, 39, 39, 43, 43, 44, 44, 46, 46, 50, 51, 51, 55, 56, 56, 58, 62, 63, 63, 67, 68, 69, 69, 70, 70, 71, 73, 77, 78, 82, 83, 84, 84, 85, 85, 86, 86, 87, 92, 92, 92, 93, 92, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 33, 34, 35, 36, 37, 38, 43, 45, 53, 58, 59, 60, 62, 63, 69, 74, 75, 76, 78, 79, 83, 84, 85, 90, 92, 93, 95, 99, 100, 101, 110, 112, 113, 114, 115, 116, 117, 119, 122, 123, 134, 136, 137, 138, 139, 140, 141, 142, 143, 150, 153, 158, 159, 160, 169, 172, 175, 179, 183, 186, 189, 193, 197, 200, 203, 207, 211, 214, 217, 221};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 26
new 0 17 26
assign 1 17 27
new 2 17 27
return 1 17 28
assign 1 22 33
new 0 22 33
assign 1 23 34
assign 1 24 35
fieldNamesGet 0 24 35
assign 1 25 36
sizeGet 0 25 36
assign 1 25 37
new 0 25 37
assign 1 25 38
subtract 1 25 38
assign 1 30 43
hasNextGet 0 30 43
assign 1 31 45
increment 0 31 45
assign 1 36 53
lesser 1 36 58
assign 1 37 59
new 0 37 59
return 1 37 60
assign 1 39 62
new 0 39 62
return 1 39 63
assign 1 43 69
lesserEquals 1 43 74
assign 1 44 75
new 0 44 75
return 1 44 76
assign 1 46 78
new 0 46 78
return 1 46 79
advance 0 50 83
assign 1 51 84
currentNameGet 0 51 84
return 1 51 85
assign 1 55 90
hasCurrentGet 0 55 90
assign 1 56 92
get 1 56 92
return 1 56 93
return 1 58 95
advance 0 62 99
assign 1 63 100
currentGet 0 63 100
return 1 63 101
assign 1 67 110
hasCurrentGet 0 67 110
assign 1 68 112
currentNameGet 0 68 112
assign 1 69 113
new 0 69 113
assign 1 69 114
add 1 69 114
assign 1 70 115
new 0 70 115
assign 1 70 116
invoke 2 70 116
return 1 71 117
return 1 73 119
advance 0 77 122
currentSet 1 78 123
assign 1 82 134
hasCurrentGet 0 82 134
assign 1 83 136
currentNameGet 0 83 136
assign 1 84 137
new 0 84 137
assign 1 84 138
add 1 84 138
assign 1 85 139
new 0 85 139
assign 1 85 140
new 1 85 140
assign 1 86 141
new 0 86 141
put 2 86 142
invoke 2 87 143
assign 1 92 150
new 0 92 150
assign 1 92 153
lesser 1 92 158
nextSet 1 93 159
incrementValue 0 92 160
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1628631987: return bem_lastidxGetDirect_0();
case 520238370: return bem_print_0();
case 1754760186: return bem_iteratorGet_0();
case 1669893351: return bem_instanceGet_0();
case 1841075196: return bem_deserializeClassNameGet_0();
case -664291153: return bem_instFieldNamesGet_0();
case 834974873: return bem_once_0();
case 1683353518: return bem_lastidxGet_0();
case -1153621323: return bem_sourceFileNameGet_0();
case -516300936: return bem_many_0();
case 895793301: return bem_currentGet_0();
case -260016569: return bem_new_0();
case 1363596807: return bem_toAny_0();
case 1695553285: return bem_toString_0();
case 946079220: return bem_hasNextGet_0();
case 510740763: return bem_echo_0();
case -385649327: return bem_advance_0();
case -1906011811: return bem_classNameGet_0();
case 772185969: return bem_nextGet_0();
case -1481120: return bem_hashGet_0();
case 1934827441: return bem_tagGet_0();
case -2049404332: return bem_fieldIteratorGet_0();
case -277977889: return bem_posGet_0();
case 1764413045: return bem_currentNameGet_0();
case 1246525343: return bem_copy_0();
case 629513215: return bem_create_0();
case 962994829: return bem_hasCurrentGet_0();
case -1151122392: return bem_serializeToString_0();
case 1786844522: return bem_instanceGetDirect_0();
case -319884304: return bem_serializationIteratorGet_0();
case 80505915: return bem_fieldNamesGet_0();
case -2067934068: return bem_nextNameGet_0();
case 542740246: return bem_instFieldNamesGetDirect_0();
case -1784818407: return bem_serializeContents_0();
case 40550063: return bem_posGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1632353878: return bem_undef_1(bevd_0);
case -1144341678: return bem_notEquals_1(bevd_0);
case -1514163025: return bem_lastidxSet_1(bevd_0);
case -877753159: return bem_lastidxSetDirect_1(bevd_0);
case 982578922: return bem_instanceSetDirect_1(bevd_0);
case -951929577: return bem_defined_1(bevd_0);
case -395850459: return bem_undefined_1(bevd_0);
case -1159719368: return bem_posSetDirect_1(bevd_0);
case 989721692: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 462621647: return bem_def_1(bevd_0);
case 482689426: return bem_otherClass_1(bevd_0);
case -1512005598: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1643964341: return bem_instFieldNamesSetDirect_1(bevd_0);
case -3324026: return bem_instFieldNamesSet_1(bevd_0);
case -547808393: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1969022366: return bem_nextSet_1(bevd_0);
case 775207796: return bem_posSet_1(bevd_0);
case -228195679: return bem_copyTo_1(bevd_0);
case -1465560464: return bem_currentSet_1(bevd_0);
case 1523343000: return bem_sameClass_1(bevd_0);
case 1049358928: return bem_equals_1(bevd_0);
case 216738391: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1430178609: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -905896804: return bem_instanceSet_1(bevd_0);
case -1177836823: return bem_sameType_1(bevd_0);
case -753793171: return bem_new_1(bevd_0);
case 2122170094: return bem_otherType_1(bevd_0);
case -1573802551: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 455013349: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1872811781: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 518732674: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1018924161: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 308804077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2072018670: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -357078730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -277637599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemObjectFieldIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_19_SystemObjectFieldIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;
}
}
