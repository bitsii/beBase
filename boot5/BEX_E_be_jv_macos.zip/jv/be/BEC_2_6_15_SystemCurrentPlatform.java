package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 551 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 552 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 570 */
} /* Line: 552 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-2072822101, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {552, 552, 570, 576, 577, 581, 582, 583};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 28, 34, 35, 40, 41, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 552 20
undef 1 552 25
setName 1 570 28
assign 1 576 34
buildProfile 0 577 35
buildProfile 0 581 40
assign 1 582 41
new 0 582 41
newlineSet 1 583 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1521004371: return bem_copy_0();
case -860764758: return bem_nullFileGetDirect_0();
case 1525272327: return bem_buildProfile_0();
case -907702096: return bem_once_0();
case 831513957: return bem_iteratorGet_0();
case 1178602792: return bem_isNixGet_0();
case -144490350: return bem_isNixGetDirect_0();
case 1097464934: return bem_print_0();
case 1663313872: return bem_newlineGetDirect_0();
case -1884426158: return bem_otherSeparatorGetDirect_0();
case 1121605448: return bem_serializeToString_0();
case 1687097380: return bem_default_0();
case 268640521: return bem_hashGet_0();
case 76156978: return bem_separatorGet_0();
case 2143550869: return bem_new_0();
case 885128203: return bem_create_0();
case 1297435512: return bem_isWinGet_0();
case 1294757574: return bem_tagGet_0();
case 1159622845: return bem_echo_0();
case -1937935925: return bem_nullFileGet_0();
case 635798532: return bem_newlineGet_0();
case 444413474: return bem_toAny_0();
case 638052426: return bem_nameGet_0();
case -2010885181: return bem_many_0();
case 1523724038: return bem_sourceFileNameGet_0();
case -730552231: return bem_fieldIteratorGet_0();
case -747505642: return bem_isWinGetDirect_0();
case 447147181: return bem_separatorGetDirect_0();
case 84009197: return bem_deserializeClassNameGet_0();
case -1834815382: return bem_nameGetDirect_0();
case -843126344: return bem_serializationIteratorGet_0();
case -649199060: return bem_serializeContents_0();
case 2057652625: return bem_fieldNamesGet_0();
case -2060917023: return bem_classNameGet_0();
case -812544455: return bem_otherSeparatorGet_0();
case -1333696208: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1863207166: return bem_def_1(bevd_0);
case -2072822101: return bem_newlineSet_1(bevd_0);
case -274435245: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -2005091575: return bem_isNixSetDirect_1(bevd_0);
case -1114550651: return bem_undefined_1(bevd_0);
case -678856522: return bem_isNixSet_1(bevd_0);
case -1035577062: return bem_equals_1(bevd_0);
case 1232121525: return bem_separatorSet_1(bevd_0);
case 899961531: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -351226620: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1417473277: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2012691693: return bem_nullFileSet_1(bevd_0);
case 2045887354: return bem_otherSeparatorSet_1(bevd_0);
case -933911215: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1776510589: return bem_copyTo_1(bevd_0);
case 2123468926: return bem_sameObject_1(bevd_0);
case 775033796: return bem_sameClass_1(bevd_0);
case 1136417978: return bem_otherSeparatorSetDirect_1(bevd_0);
case 434673597: return bem_separatorSetDirect_1(bevd_0);
case 544363262: return bem_otherClass_1(bevd_0);
case 1037319878: return bem_nullFileSetDirect_1(bevd_0);
case 1007712560: return bem_isWinSetDirect_1(bevd_0);
case 459298083: return bem_otherType_1(bevd_0);
case 1189274855: return bem_sameType_1(bevd_0);
case 1719411527: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -943997398: return bem_nameSet_1(bevd_0);
case 171056025: return bem_defined_1(bevd_0);
case -839680850: return bem_undef_1(bevd_0);
case -571354968: return bem_notEquals_1(bevd_0);
case 1183592356: return bem_newlineSetDirect_1(bevd_0);
case -1994217383: return bem_nameSetDirect_1(bevd_0);
case 1899381258: return bem_isWinSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 661608167: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 319580096: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -111616333: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -87616259: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 710208868: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 520958435: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -842656681: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
