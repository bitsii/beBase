package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 565 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 566 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 589 */
} /* Line: 566 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(1845882763, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {566, 566, 589, 595, 596, 600, 601, 602};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 28, 34, 35, 40, 41, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 566 20
undef 1 566 25
setName 1 589 28
assign 1 595 34
buildProfile 0 596 35
buildProfile 0 600 40
assign 1 601 41
new 0 601 41
newlineSet 1 602 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -431168380: return bem_isNixGet_0();
case 810516096: return bem_tagGet_0();
case 1112419676: return bem_otherSeparatorGet_0();
case 1623449693: return bem_isNixGetDirect_0();
case 971520504: return bem_nameGetDirect_0();
case 1516528362: return bem_copy_0();
case 647733846: return bem_hashGet_0();
case 764111846: return bem_classNameGet_0();
case 2006257096: return bem_newlineGet_0();
case 1640160430: return bem_serializationIteratorGet_0();
case -1017363364: return bem_separatorGet_0();
case -2134610754: return bem_properNameGet_0();
case -2027075098: return bem_sourceFileNameGet_0();
case -1857169421: return bem_print_0();
case -1019129421: return bem_iteratorGet_0();
case 2060394991: return bem_default_0();
case -46175799: return bem_isWinGet_0();
case 1279899240: return bem_properNameGetDirect_0();
case -1459660688: return bem_once_0();
case 1020075506: return bem_nameGet_0();
case 1977268733: return bem_toAny_0();
case 415444144: return bem_many_0();
case -1440519528: return bem_new_0();
case 1464556610: return bem_serializeContents_0();
case -352222734: return bem_echo_0();
case -916808790: return bem_serializeToString_0();
case -819873797: return bem_isWinGetDirect_0();
case -706398562: return bem_otherSeparatorGetDirect_0();
case -551758503: return bem_scriptExtGet_0();
case -1127537726: return bem_nullFileGet_0();
case -2042019182: return bem_toString_0();
case -2135865674: return bem_newlineGetDirect_0();
case -767876265: return bem_buildProfile_0();
case 1311350203: return bem_scriptExtGetDirect_0();
case -1322750582: return bem_fieldNamesGet_0();
case 1966604989: return bem_deserializeClassNameGet_0();
case 1544637441: return bem_fieldIteratorGet_0();
case 214828892: return bem_separatorGetDirect_0();
case 1256493526: return bem_create_0();
case 489784992: return bem_nullFileGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1451816788: return bem_otherType_1(bevd_0);
case -1066262854: return bem_copyTo_1(bevd_0);
case -2113151813: return bem_otherClass_1(bevd_0);
case 1686689499: return bem_sameType_1(bevd_0);
case -2131506732: return bem_nameSet_1(bevd_0);
case 129664577: return bem_undefined_1(bevd_0);
case 858949566: return bem_sameObject_1(bevd_0);
case 1149328783: return bem_equals_1(bevd_0);
case 1119331095: return bem_nameSetDirect_1(bevd_0);
case 393765835: return bem_isWinSet_1(bevd_0);
case 40390051: return bem_separatorSetDirect_1(bevd_0);
case -1103921791: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1726382580: return bem_undef_1(bevd_0);
case -635052720: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -62499290: return bem_notEquals_1(bevd_0);
case -815303637: return bem_separatorSet_1(bevd_0);
case -189470558: return bem_otherSeparatorSetDirect_1(bevd_0);
case 173437066: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1877290002: return bem_scriptExtSet_1(bevd_0);
case -1884560238: return bem_sameClass_1(bevd_0);
case -1693595005: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1303995883: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1529930548: return bem_def_1(bevd_0);
case -1309551511: return bem_otherSeparatorSet_1(bevd_0);
case 456604916: return bem_defined_1(bevd_0);
case 1579233775: return bem_isNixSetDirect_1(bevd_0);
case 1845882763: return bem_newlineSet_1(bevd_0);
case -1169362676: return bem_newlineSetDirect_1(bevd_0);
case 715742849: return bem_properNameSet_1(bevd_0);
case -578297721: return bem_isNixSet_1(bevd_0);
case 1909763314: return bem_nullFileSetDirect_1(bevd_0);
case 1371517103: return bem_properNameSetDirect_1(bevd_0);
case -1162899840: return bem_nullFileSet_1(bevd_0);
case -255772660: return bem_scriptExtSetDirect_1(bevd_0);
case -395538631: return bem_isWinSetDirect_1(bevd_0);
case -773089298: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -840184945: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2113325337: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1732137967: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1058450326: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1752849240: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1337367239: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 572204899: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
