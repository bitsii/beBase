package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_9, 28));
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_10, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_11 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_11, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_12 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_9_SystemException_bels_13 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_13, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_14 = {0x46,0x72,0x61,0x6D,0x65,0x20,0x6C,0x69,0x6E,0x65,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_14, 14));
private static byte[] bece_BEC_2_6_9_SystemException_bels_15 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_15, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_16 = {0x73,0x74,0x61,0x72,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_16, 9));
private static byte[] bece_BEC_2_6_9_SystemException_bels_17 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_17, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_9 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_18 = {0x65,0x6E,0x64,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_18, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_19 = {0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_19, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_13 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_20 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_20, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_21 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_17 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_22 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_22, 5));
private static byte[] bece_BEC_2_6_9_SystemException_bels_23 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_23, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_24 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_24, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_25 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_25, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_22 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_26 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x65,0x6E,0x64,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_26, 13));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_27 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_25 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_28 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_27 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_29 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_29, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_29 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_30 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_31 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_30 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_31 = {0x63,0x61,0x6C,0x6C,0x50,0x61,0x72,0x74,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_31, 10));
private static byte[] bece_BEC_2_6_9_SystemException_bels_32 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_32, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_33 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_34 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_35 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_34 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6D,0x74,0x64,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_34, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_35 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_35, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_36 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_36, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_37 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_37, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_41 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_42 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_38 = {0x70,0x72,0x65,0x20,0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_38, 21));
private static byte[] bece_BEC_2_6_9_SystemException_bels_39 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_39, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_40 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_40, 17));
private static byte[] bece_BEC_2_6_9_SystemException_bels_41 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_41, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_42 = {0x61,0x64,0x64,0x69,0x6E,0x67,0x20,0x66,0x72,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_42, 12));
private static byte[] bece_BEC_2_6_9_SystemException_bels_43 = {0x6E,0x6F,0x20,0x65,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_43, 6));
private static byte[] bece_BEC_2_6_9_SystemException_bels_44 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_45 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_45, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_46 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_47 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_47, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_48 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_49 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_49, 4));
private static byte[] bece_BEC_2_6_9_SystemException_bels_50 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_52 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_53 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_51 = {0x3A};
private static byte[] bece_BEC_2_6_9_SystemException_bels_52 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_52, 4));
private static byte[] bece_BEC_2_6_9_SystemException_bels_53 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_55 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_56 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_54 = {0x5F};
private static byte[] bece_BEC_2_6_9_SystemException_bels_55 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_55, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_56 = {0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_56, 1));
public static BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_vv = be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_0));
if (bevp_description == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_1));
bevt_1_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevt_2_tmpany_phold);
bevl_toRet = bevt_1_tmpany_phold.bemd_1(1462458944, bevp_description);
} /* Line: 35 */
if (bevp_fileName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_2));
bevt_4_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevt_5_tmpany_phold);
bevl_toRet = bevt_4_tmpany_phold.bemd_1(1462458944, bevp_fileName);
} /* Line: 38 */
if (bevp_lineNumber == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_3));
bevt_7_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_lineNumber.bemd_0(1310553601);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(1462458944, bevt_9_tmpany_phold);
} /* Line: 41 */
if (bevp_lang == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_11_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevt_12_tmpany_phold);
bevl_toRet = bevt_11_tmpany_phold.bemd_1(1462458944, bevp_lang);
} /* Line: 44 */
if (bevp_emitLang == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_5));
bevt_14_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevt_15_tmpany_phold);
bevl_toRet = bevt_14_tmpany_phold.bemd_1(1462458944, bevp_emitLang);
} /* Line: 47 */
if (bevp_methodName == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_6));
bevt_17_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevt_18_tmpany_phold);
bevl_toRet = bevt_17_tmpany_phold.bemd_1(1462458944, bevp_methodName);
} /* Line: 50 */
if (bevp_klassName == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_7));
bevt_20_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevt_21_tmpany_phold);
bevl_toRet = bevt_20_tmpany_phold.bemd_1(1462458944, bevp_klassName);
} /* Line: 53 */
if (bevp_framesText == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_8));
bevt_23_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevt_24_tmpany_phold);
bevl_toRet = bevt_23_tmpany_phold.bemd_1(1462458944, bevp_framesText);
} /* Line: 56 */
if (bevp_frames == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_26_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(1462458944, bevt_26_tmpany_phold);
} /* Line: 59 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_9_SystemException bem_translateEmittedException_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 65 */ {
bem_translateEmittedExceptionInner_0();
} /* Line: 66 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_0;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 68 */
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_translateEmittedExceptionInner_0() throws Throwable {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpany_phold = null;
BEC_2_4_6_TextString bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_6_TextString bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_6_TextString bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_134_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_4_6_TextString bevt_142_tmpany_phold = null;
BEC_2_4_6_TextString bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_4_6_TextString bevt_145_tmpany_phold = null;
if (bevp_translated == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 76 */ {
if (bevp_translated.bevi_bool) /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 76 */
 else  /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 76 */ {
return this;
} /* Line: 77 */
if (bevp_vv == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevp_vv = be.BECS_Runtime.boolFalse;
} /* Line: 80 */
bevp_translated = be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 83 */ {
if (bevp_lang == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_17_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_1;
bevt_16_tmpany_phold = bevp_lang.bem_equals_1(bevt_17_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_2;
bevt_18_tmpany_phold = bevp_lang.bem_equals_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_12));
bevl_ltok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_20_tmpany_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_22_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_3;
bevt_21_tmpany_phold = bevp_lang.bem_equals_1(bevt_22_tmpany_phold);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevl_isCs = be.BECS_Runtime.boolTrue;
} /* Line: 87 */
 else  /* Line: 88 */ {
bevl_isCs = be.BECS_Runtime.boolFalse;
} /* Line: 89 */
bevt_0_tmpany_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 91 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
if (bevp_vv.bevi_bool) /* Line: 92 */ {
bevt_25_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_4;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevl_line);
bevt_24_tmpany_phold.bem_print_0();
} /* Line: 93 */
bevt_26_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_5;
bevl_start = bevl_line.bem_find_1(bevt_26_tmpany_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_29_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_6;
if (bevl_start.bevi_int >= bevt_29_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 98 */ {
if (bevp_vv.bevi_bool) /* Line: 99 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_7;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevl_start);
bevt_30_tmpany_phold.bem_print_0();
} /* Line: 100 */
bevt_32_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_8;
bevt_34_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_9;
bevt_33_tmpany_phold = bevl_start.bem_add_1(bevt_34_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
if (bevl_end == null) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 103 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 103 */ {
if (bevp_vv.bevi_bool) /* Line: 104 */ {
bevt_38_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_10;
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevl_end);
bevt_37_tmpany_phold.bem_print_0();
} /* Line: 105 */
bevt_40_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_11;
bevt_39_tmpany_phold = bevl_start.bem_add_1(bevt_40_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_39_tmpany_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 109 */ {
bevt_41_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_12;
bevl_start = bevl_line.bem_find_2(bevt_41_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_44_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_13;
bevt_43_tmpany_phold = bevl_start.bem_add_1(bevt_44_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_43_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_14;
bevt_45_tmpany_phold = bevl_inPart.bem_ends_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_48_tmpany_phold = bevl_inPart.bem_sizeGet_0();
bevt_49_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_15;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_subtract_1(bevt_49_tmpany_phold);
bevl_inPart.bem_sizeSet_1(bevt_47_tmpany_phold);
} /* Line: 115 */
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_21));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_50_tmpany_phold);
if (bevl_pdelim == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_52_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_16;
bevl_efile = bevl_inPart.bem_substring_2(bevt_52_tmpany_phold, bevl_pdelim);
bevt_54_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_17;
bevt_53_tmpany_phold = bevl_pdelim.bem_add_1(bevt_54_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_53_tmpany_phold);
bevt_56_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_18;
bevt_55_tmpany_phold = bevl_iv.bem_begins_1(bevt_56_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_57_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_57_tmpany_phold);
} /* Line: 124 */
bevt_58_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 128 */
} /* Line: 127 */
} /* Line: 119 */
} /* Line: 111 */
 else  /* Line: 132 */ {
bevt_59_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_19;
bevl_start = bevl_line.bem_find_2(bevt_59_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 134 */ {
if (bevp_vv.bevi_bool) /* Line: 135 */ {
bevt_61_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_20;
bevt_61_tmpany_phold.bem_print_0();
} /* Line: 136 */
bevt_62_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_21;
bevt_64_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_22;
bevt_63_tmpany_phold = bevl_start.bem_add_1(bevt_64_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
if (bevl_end == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 140 */ {
if (bevp_vv.bevi_bool) /* Line: 141 */ {
bevt_66_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_23;
bevt_66_tmpany_phold.bem_print_0();
} /* Line: 142 */
bevt_68_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_24;
bevt_67_tmpany_phold = bevl_start.bem_add_1(bevt_68_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_67_tmpany_phold, bevl_end);
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_27));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_69_tmpany_phold);
if (bevl_pdelim == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 147 */ {
bevt_71_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_25;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_71_tmpany_phold, bevl_pdelim);
bevt_72_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_28));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_72_tmpany_phold);
if (bevl_pdelim == null) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevt_74_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_26;
bevl_efile = bevl_inPart.bem_substring_2(bevt_74_tmpany_phold, bevl_pdelim);
} /* Line: 152 */
bevt_76_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_27;
bevt_75_tmpany_phold = bevl_pdelim.bem_add_1(bevt_76_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_77_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 157 */
} /* Line: 156 */
} /* Line: 147 */
} /* Line: 140 */
} /* Line: 134 */
} /* Line: 109 */
 else  /* Line: 163 */ {
bevt_78_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_28;
bevt_80_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_29;
bevt_79_tmpany_phold = bevl_start.bem_add_1(bevt_80_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
if (bevl_end == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 165 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 165 */
 else  /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 165 */ {
bevt_84_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_30;
bevt_83_tmpany_phold = bevl_start.bem_add_1(bevt_84_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_83_tmpany_phold, bevl_end);
} /* Line: 166 */
 else  /* Line: 167 */ {
bevt_86_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_31;
bevt_85_tmpany_phold = bevl_start.bem_add_1(bevt_86_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_85_tmpany_phold);
} /* Line: 168 */
} /* Line: 165 */
if (bevl_callPart == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 171 */ {
if (bevl_isCs.bevi_bool) /* Line: 172 */ {
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_30));
bevl_parts = bevl_callPart.bem_split_1(bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_90_tmpany_phold);
bevl_klass = bem_extractKlass_1(bevl_klass);
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_92_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_91_tmpany_phold = bem_getSourceFileName_1(bevt_92_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_91_tmpany_phold);
bem_addFrame_1(bevl_fr);
} /* Line: 185 */
 else  /* Line: 186 */ {
if (bevp_vv.bevi_bool) /* Line: 188 */ {
bevt_95_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_32;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevl_callPart);
bevt_96_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_33;
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bem_add_1(bevt_96_tmpany_phold);
bevt_93_tmpany_phold.bem_print_0();
} /* Line: 189 */
bevt_97_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_33));
bevl_parts = bevl_callPart.bem_split_1(bevt_97_tmpany_phold);
bevt_99_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_100_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_34;
if (bevt_99_tmpany_phold.bevi_int > bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_102_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_103_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_35;
if (bevt_102_tmpany_phold.bevi_int > bevt_103_tmpany_phold.bevi_int) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 193 */ {
bevt_104_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_105_tmpany_phold);
} /* Line: 195 */
 else  /* Line: 196 */ {
bevt_106_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_107_tmpany_phold);
} /* Line: 198 */
bevl_mtd = bem_extractMethod_1(bevl_mtd);
if (bevp_vv.bevi_bool) /* Line: 201 */ {
bevt_110_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_36;
bevt_109_tmpany_phold = bevt_110_tmpany_phold.bem_add_1(bevl_mtd);
bevt_111_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_37;
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bem_add_1(bevt_111_tmpany_phold);
bevt_108_tmpany_phold.bem_print_0();
} /* Line: 202 */
bevt_112_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_38;
bevl_start = bevl_klass.bem_find_1(bevt_112_tmpany_phold);
if (bevl_start == null) {
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_113_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevt_115_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_39;
if (bevl_start.bevi_int > bevt_115_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 205 */ {
bevt_116_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_40;
bevt_118_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_41;
bevt_117_tmpany_phold = bevl_start.bem_add_1(bevt_118_tmpany_phold);
bevl_end = bevl_klass.bem_find_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
if (bevl_end == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_121_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_42;
if (bevl_end.bevi_int > bevt_121_tmpany_phold.bevi_int) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 207 */
 else  /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 207 */ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
if (bevp_vv.bevi_bool) /* Line: 212 */ {
bevt_124_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_43;
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bem_add_1(bevl_klass);
bevt_125_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_44;
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bem_add_1(bevt_125_tmpany_phold);
bevt_122_tmpany_phold.bem_print_0();
} /* Line: 213 */
bevl_klass = bem_extractKlass_1(bevl_klass);
if (bevp_vv.bevi_bool) /* Line: 216 */ {
bevt_128_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_45;
bevt_127_tmpany_phold = bevt_128_tmpany_phold.bem_add_1(bevl_klass);
bevt_129_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_46;
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bem_add_1(bevt_129_tmpany_phold);
bevt_126_tmpany_phold.bem_print_0();
} /* Line: 217 */
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_131_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_130_tmpany_phold = bem_getSourceFileName_1(bevt_131_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_130_tmpany_phold);
if (bevp_vv.bevi_bool) /* Line: 221 */ {
bevt_132_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_47;
bevt_132_tmpany_phold.bem_print_0();
} /* Line: 222 */
bem_addFrame_1(bevl_fr);
} /* Line: 224 */
 else  /* Line: 225 */ {
if (bevp_vv.bevi_bool) /* Line: 226 */ {
bevt_133_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_48;
bevt_133_tmpany_phold.bem_print_0();
} /* Line: 227 */
} /* Line: 226 */
} /* Line: 207 */
} /* Line: 205 */
} /* Line: 192 */
} /* Line: 172 */
} /* Line: 171 */
} /* Line: 98 */
 else  /* Line: 91 */ {
break;
} /* Line: 91 */
} /* Line: 91 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_44));
bevp_framesText = null;
} /* Line: 238 */
 else  /* Line: 83 */ {
if (bevp_frames == null) {
bevt_134_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_134_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_134_tmpany_phold.bevi_bool) /* Line: 239 */ {
if (bevp_lang == null) {
bevt_135_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 239 */ {
bevt_137_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_49;
bevt_136_tmpany_phold = bevp_lang.bem_equals_1(bevt_137_tmpany_phold);
if (bevt_136_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpany_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_138_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_138_tmpany_phold).bevi_bool) /* Line: 240 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpany_loop.bem_nextGet_0();
bevt_140_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_139_tmpany_phold = bem_extractKlassLib_1(bevt_140_tmpany_phold);
bevl_fr.bem_klassNameSet_1(bevt_139_tmpany_phold);
bevt_142_tmpany_phold = bevl_fr.bem_methodNameGet_0();
bevt_141_tmpany_phold = bem_extractMethod_1(bevt_142_tmpany_phold);
bevl_fr.bem_methodNameSet_1(bevt_141_tmpany_phold);
bevt_144_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_143_tmpany_phold = bem_getSourceFileName_1(bevt_144_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_143_tmpany_phold);
 /* Line: 244 */ {
bevl_fr.bem_extractLine_0();
} /* Line: 245 */
} /* Line: 244 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_46));
} /* Line: 249 */
 else  /* Line: 250 */ {
} /* Line: 250 */
} /* Line: 83 */
if (bevp_vv.bevi_bool) /* Line: 253 */ {
bevt_145_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_50;
bevt_145_tmpany_phold.bem_print_0();
} /* Line: 254 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_i = bem_createInstance_2(beva_klassName, bevt_0_tmpany_phold);
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(1604962015);
return (BEC_2_4_6_TextString) bevt_2_tmpany_phold;
} /* Line: 263 */
return null;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_48));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_2_tmpany_phold = bevl_parts.bem_get_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpany_phold );
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 277 */ {
bevt_0_tmpany_phold = bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpany_phold;
} /* Line: 278 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 279 */
return beva_klass;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_51;
bevt_3_tmpany_phold = beva_klass.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 286 */ {
return beva_klass;
} /* Line: 287 */
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_5_tmpany_phold = beva_klass.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_50));
bevl_kparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_52;
bevl_kps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 294 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 294 */ {
bevt_11_tmpany_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpany_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpany_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_53;
bevt_15_tmpany_phold = bevl_i.bem_add_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_51));
bevl_bec.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 298 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 294 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
return bevl_bec;
} /*method end*/
public BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
if (beva_mtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 306 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_54;
bevt_3_tmpany_phold = beva_mtd.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 306 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 306 */ {
return beva_mtd;
} /* Line: 307 */
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(4));
bevt_5_tmpany_phold = beva_mtd.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_53));
bevl_mparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_55;
bevl_mps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_bem = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 312 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_11_tmpany_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_56;
bevt_13_tmpany_phold = bevl_i.bem_add_1(bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_54));
bevl_bem.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 314 */
bevl_i.bevi_int++;
} /* Line: 312 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
return bevl_bem;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bem_translateEmittedException_0();
if (bevp_vv.bevi_bool) /* Line: 324 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_57;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 325 */
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 335 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_58;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 337 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 337 */ {
bevl_ft = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 338 */
 else  /* Line: 337 */ {
break;
} /* Line: 337 */
} /* Line: 337 */
} /* Line: 337 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_frames == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevp_frames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 350 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGet_0() throws Throwable {
return bevp_vv;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 26, 30, 33, 34, 34, 35, 35, 35, 37, 37, 38, 38, 38, 40, 40, 41, 41, 41, 41, 43, 43, 44, 44, 44, 46, 46, 47, 47, 47, 49, 49, 50, 50, 50, 52, 52, 53, 53, 53, 55, 55, 56, 56, 56, 58, 58, 59, 59, 61, 66, 68, 68, 76, 76, 0, 0, 0, 77, 79, 79, 80, 82, 83, 83, 83, 83, 0, 0, 0, 83, 83, 0, 83, 83, 0, 0, 0, 0, 0, 84, 84, 85, 86, 86, 87, 89, 91, 0, 91, 91, 93, 93, 93, 95, 95, 96, 97, 98, 98, 98, 98, 98, 0, 0, 0, 100, 100, 100, 102, 102, 102, 102, 103, 103, 103, 103, 0, 0, 0, 105, 105, 105, 107, 107, 107, 110, 110, 111, 111, 113, 113, 113, 114, 114, 115, 115, 115, 115, 118, 118, 119, 119, 120, 120, 122, 122, 122, 123, 123, 124, 124, 127, 128, 133, 133, 134, 134, 136, 136, 139, 139, 139, 139, 140, 140, 142, 142, 144, 144, 144, 146, 146, 147, 147, 148, 148, 150, 150, 151, 151, 152, 152, 154, 154, 154, 156, 157, 164, 164, 164, 164, 165, 165, 165, 165, 0, 0, 0, 166, 166, 166, 168, 168, 168, 171, 171, 174, 174, 176, 176, 177, 177, 179, 181, 183, 184, 184, 184, 185, 189, 189, 189, 189, 189, 191, 191, 192, 192, 192, 192, 193, 193, 193, 193, 194, 194, 195, 195, 197, 197, 198, 198, 200, 202, 202, 202, 202, 202, 204, 204, 205, 205, 205, 205, 205, 0, 0, 0, 206, 206, 206, 206, 207, 207, 207, 207, 207, 0, 0, 0, 211, 213, 213, 213, 213, 213, 215, 217, 217, 217, 217, 217, 219, 220, 220, 220, 222, 222, 224, 227, 227, 236, 237, 238, 239, 239, 239, 239, 0, 0, 0, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 241, 241, 242, 242, 242, 243, 243, 243, 245, 248, 249, 254, 254, 260, 260, 261, 261, 263, 263, 266, 271, 271, 273, 273, 273, 273, 278, 278, 282, 286, 286, 0, 286, 286, 286, 286, 0, 0, 287, 289, 289, 289, 289, 290, 290, 290, 291, 292, 293, 294, 294, 294, 295, 295, 297, 297, 297, 298, 298, 298, 298, 298, 298, 299, 294, 302, 306, 306, 0, 306, 306, 306, 306, 0, 0, 307, 309, 309, 309, 309, 310, 310, 310, 311, 312, 312, 312, 313, 313, 314, 314, 314, 314, 314, 314, 312, 317, 323, 325, 325, 328, 332, 333, 334, 335, 335, 336, 336, 337, 0, 337, 337, 338, 341, 345, 349, 349, 350, 352, 356, 356, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {139, 140, 172, 173, 174, 179, 180, 181, 182, 184, 189, 190, 191, 192, 194, 199, 200, 201, 202, 203, 205, 210, 211, 212, 213, 215, 220, 221, 222, 223, 225, 230, 231, 232, 233, 235, 240, 241, 242, 243, 245, 250, 251, 252, 253, 255, 260, 261, 262, 264, 270, 274, 275, 442, 447, 449, 452, 456, 459, 461, 466, 467, 469, 470, 475, 476, 481, 482, 485, 489, 492, 493, 495, 498, 499, 501, 504, 508, 511, 515, 518, 519, 520, 521, 522, 524, 527, 529, 529, 532, 534, 536, 537, 538, 540, 541, 542, 543, 544, 549, 550, 551, 556, 557, 560, 564, 568, 569, 570, 572, 573, 574, 575, 576, 581, 582, 587, 588, 591, 595, 599, 600, 601, 603, 604, 605, 607, 608, 609, 614, 615, 616, 617, 618, 619, 621, 622, 623, 624, 626, 627, 628, 633, 634, 635, 636, 637, 638, 639, 640, 642, 643, 645, 647, 653, 654, 655, 660, 662, 663, 665, 666, 667, 668, 669, 674, 676, 677, 679, 680, 681, 682, 683, 684, 689, 690, 691, 692, 693, 694, 699, 700, 701, 703, 704, 705, 706, 708, 716, 717, 718, 719, 720, 725, 726, 731, 732, 735, 739, 742, 743, 744, 747, 748, 749, 752, 757, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 775, 776, 777, 778, 779, 781, 782, 783, 784, 785, 790, 791, 792, 793, 798, 799, 800, 801, 802, 805, 806, 807, 808, 810, 812, 813, 814, 815, 816, 818, 819, 820, 825, 826, 827, 832, 833, 836, 840, 843, 844, 845, 846, 847, 852, 853, 854, 859, 860, 863, 867, 870, 872, 873, 874, 875, 876, 878, 880, 881, 882, 883, 884, 886, 887, 888, 889, 891, 892, 894, 898, 899, 912, 913, 914, 917, 922, 923, 928, 929, 932, 936, 939, 940, 942, 945, 949, 952, 952, 955, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 968, 975, 976, 982, 983, 992, 993, 994, 999, 1000, 1001, 1003, 1011, 1012, 1013, 1014, 1015, 1016, 1022, 1023, 1028, 1056, 1061, 1062, 1065, 1066, 1067, 1072, 1073, 1076, 1080, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1095, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1113, 1114, 1115, 1117, 1118, 1124, 1147, 1152, 1153, 1156, 1157, 1158, 1163, 1164, 1167, 1171, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1181, 1184, 1189, 1190, 1191, 1192, 1193, 1194, 1199, 1200, 1201, 1203, 1209, 1213, 1215, 1216, 1218, 1228, 1229, 1230, 1231, 1236, 1237, 1238, 1239, 1239, 1242, 1244, 1245, 1252, 1255, 1259, 1264, 1265, 1267, 1272, 1273, 1277, 1280, 1284, 1288, 1291, 1295, 1298, 1302, 1305, 1309, 1312, 1316, 1319, 1323, 1327, 1330, 1334, 1337, 1341, 1344};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 139
new 0 23 139
assign 1 26 140
translateEmittedException 0 30 172
assign 1 33 173
new 0 33 173
assign 1 34 174
def 1 34 179
assign 1 35 180
new 0 35 180
assign 1 35 181
add 1 35 181
assign 1 35 182
add 1 35 182
assign 1 37 184
def 1 37 189
assign 1 38 190
new 0 38 190
assign 1 38 191
add 1 38 191
assign 1 38 192
add 1 38 192
assign 1 40 194
def 1 40 199
assign 1 41 200
new 0 41 200
assign 1 41 201
add 1 41 201
assign 1 41 202
toString 0 41 202
assign 1 41 203
add 1 41 203
assign 1 43 205
def 1 43 210
assign 1 44 211
new 0 44 211
assign 1 44 212
add 1 44 212
assign 1 44 213
add 1 44 213
assign 1 46 215
def 1 46 220
assign 1 47 221
new 0 47 221
assign 1 47 222
add 1 47 222
assign 1 47 223
add 1 47 223
assign 1 49 225
def 1 49 230
assign 1 50 231
new 0 50 231
assign 1 50 232
add 1 50 232
assign 1 50 233
add 1 50 233
assign 1 52 235
def 1 52 240
assign 1 53 241
new 0 53 241
assign 1 53 242
add 1 53 242
assign 1 53 243
add 1 53 243
assign 1 55 245
def 1 55 250
assign 1 56 251
new 0 56 251
assign 1 56 252
add 1 56 252
assign 1 56 253
add 1 56 253
assign 1 58 255
def 1 58 260
assign 1 59 261
getFrameText 0 59 261
assign 1 59 262
add 1 59 262
return 1 61 264
translateEmittedExceptionInner 0 66 270
assign 1 68 274
new 0 68 274
print 0 68 275
assign 1 76 442
def 1 76 447
assign 1 0 449
assign 1 0 452
assign 1 0 456
return 1 77 459
assign 1 79 461
undef 1 79 466
assign 1 80 467
new 0 80 467
assign 1 82 469
new 0 82 469
assign 1 83 470
def 1 83 475
assign 1 83 476
def 1 83 481
assign 1 0 482
assign 1 0 485
assign 1 0 489
assign 1 83 492
new 0 83 492
assign 1 83 493
equals 1 83 493
assign 1 0 495
assign 1 83 498
new 0 83 498
assign 1 83 499
equals 1 83 499
assign 1 0 501
assign 1 0 504
assign 1 0 508
assign 1 0 511
assign 1 0 515
assign 1 84 518
new 0 84 518
assign 1 84 519
new 1 84 519
assign 1 85 520
tokenize 1 85 520
assign 1 86 521
new 0 86 521
assign 1 86 522
equals 1 86 522
assign 1 87 524
new 0 87 524
assign 1 89 527
new 0 89 527
assign 1 91 529
linkedListIteratorGet 0 0 529
assign 1 91 532
hasNextGet 0 91 532
assign 1 91 534
nextGet 0 91 534
assign 1 93 536
new 0 93 536
assign 1 93 537
add 1 93 537
print 0 93 538
assign 1 95 540
new 0 95 540
assign 1 95 541
find 1 95 541
assign 1 96 542
assign 1 97 543
assign 1 98 544
def 1 98 549
assign 1 98 550
new 0 98 550
assign 1 98 551
greaterEquals 1 98 556
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 100 568
new 0 100 568
assign 1 100 569
add 1 100 569
print 0 100 570
assign 1 102 572
new 0 102 572
assign 1 102 573
new 0 102 573
assign 1 102 574
add 1 102 574
assign 1 102 575
find 2 102 575
assign 1 103 576
def 1 103 581
assign 1 103 582
greater 1 103 587
assign 1 0 588
assign 1 0 591
assign 1 0 595
assign 1 105 599
new 0 105 599
assign 1 105 600
add 1 105 600
print 0 105 601
assign 1 107 603
new 0 107 603
assign 1 107 604
add 1 107 604
assign 1 107 605
substring 2 107 605
assign 1 110 607
new 0 110 607
assign 1 110 608
find 2 110 608
assign 1 111 609
def 1 111 614
assign 1 113 615
new 0 113 615
assign 1 113 616
add 1 113 616
assign 1 113 617
substring 1 113 617
assign 1 114 618
new 0 114 618
assign 1 114 619
ends 1 114 619
assign 1 115 621
sizeGet 0 115 621
assign 1 115 622
new 0 115 622
assign 1 115 623
subtract 1 115 623
sizeSet 1 115 624
assign 1 118 626
new 0 118 626
assign 1 118 627
rfind 1 118 627
assign 1 119 628
def 1 119 633
assign 1 120 634
new 0 120 634
assign 1 120 635
substring 2 120 635
assign 1 122 636
new 0 122 636
assign 1 122 637
add 1 122 637
assign 1 122 638
substring 1 122 638
assign 1 123 639
new 0 123 639
assign 1 123 640
begins 1 123 640
assign 1 124 642
new 0 124 642
assign 1 124 643
substring 1 124 643
assign 1 127 645
isInteger 0 127 645
assign 1 128 647
new 1 128 647
assign 1 133 653
new 0 133 653
assign 1 133 654
find 2 133 654
assign 1 134 655
def 1 134 660
assign 1 136 662
new 0 136 662
print 0 136 663
assign 1 139 665
new 0 139 665
assign 1 139 666
new 0 139 666
assign 1 139 667
add 1 139 667
assign 1 139 668
find 2 139 668
assign 1 140 669
def 1 140 674
assign 1 142 676
new 0 142 676
print 0 142 677
assign 1 144 679
new 0 144 679
assign 1 144 680
add 1 144 680
assign 1 144 681
substring 2 144 681
assign 1 146 682
new 0 146 682
assign 1 146 683
rfind 1 146 683
assign 1 147 684
def 1 147 689
assign 1 148 690
new 0 148 690
assign 1 148 691
substring 2 148 691
assign 1 150 692
new 0 150 692
assign 1 150 693
rfind 1 150 693
assign 1 151 694
def 1 151 699
assign 1 152 700
new 0 152 700
assign 1 152 701
substring 2 152 701
assign 1 154 703
new 0 154 703
assign 1 154 704
add 1 154 704
assign 1 154 705
substring 1 154 705
assign 1 156 706
isInteger 0 156 706
assign 1 157 708
new 1 157 708
assign 1 164 716
new 0 164 716
assign 1 164 717
new 0 164 717
assign 1 164 718
add 1 164 718
assign 1 164 719
find 2 164 719
assign 1 165 720
def 1 165 725
assign 1 165 726
greater 1 165 731
assign 1 0 732
assign 1 0 735
assign 1 0 739
assign 1 166 742
new 0 166 742
assign 1 166 743
add 1 166 743
assign 1 166 744
substring 2 166 744
assign 1 168 747
new 0 168 747
assign 1 168 748
add 1 168 748
assign 1 168 749
substring 1 168 749
assign 1 171 752
def 1 171 757
assign 1 174 759
new 0 174 759
assign 1 174 760
split 1 174 760
assign 1 176 761
new 0 176 761
assign 1 176 762
get 1 176 762
assign 1 177 763
new 0 177 763
assign 1 177 764
get 1 177 764
assign 1 179 765
extractKlass 1 179 765
assign 1 181 766
extractMethod 1 181 766
assign 1 183 767
new 4 183 767
assign 1 184 768
klassNameGet 0 184 768
assign 1 184 769
getSourceFileName 1 184 769
fileNameSet 1 184 770
addFrame 1 185 771
assign 1 189 775
new 0 189 775
assign 1 189 776
add 1 189 776
assign 1 189 777
new 0 189 777
assign 1 189 778
add 1 189 778
print 0 189 779
assign 1 191 781
new 0 191 781
assign 1 191 782
split 1 191 782
assign 1 192 783
sizeGet 0 192 783
assign 1 192 784
new 0 192 784
assign 1 192 785
greater 1 192 790
assign 1 193 791
sizeGet 0 193 791
assign 1 193 792
new 0 193 792
assign 1 193 793
greater 1 193 798
assign 1 194 799
new 0 194 799
assign 1 194 800
get 1 194 800
assign 1 195 801
new 0 195 801
assign 1 195 802
get 1 195 802
assign 1 197 805
new 0 197 805
assign 1 197 806
get 1 197 806
assign 1 198 807
new 0 198 807
assign 1 198 808
get 1 198 808
assign 1 200 810
extractMethod 1 200 810
assign 1 202 812
new 0 202 812
assign 1 202 813
add 1 202 813
assign 1 202 814
new 0 202 814
assign 1 202 815
add 1 202 815
print 0 202 816
assign 1 204 818
new 0 204 818
assign 1 204 819
find 1 204 819
assign 1 205 820
def 1 205 825
assign 1 205 826
new 0 205 826
assign 1 205 827
greater 1 205 832
assign 1 0 833
assign 1 0 836
assign 1 0 840
assign 1 206 843
new 0 206 843
assign 1 206 844
new 0 206 844
assign 1 206 845
add 1 206 845
assign 1 206 846
find 2 206 846
assign 1 207 847
def 1 207 852
assign 1 207 853
new 0 207 853
assign 1 207 854
greater 1 207 859
assign 1 0 860
assign 1 0 863
assign 1 0 867
assign 1 211 870
substring 1 211 870
assign 1 213 872
new 0 213 872
assign 1 213 873
add 1 213 873
assign 1 213 874
new 0 213 874
assign 1 213 875
add 1 213 875
print 0 213 876
assign 1 215 878
extractKlass 1 215 878
assign 1 217 880
new 0 217 880
assign 1 217 881
add 1 217 881
assign 1 217 882
new 0 217 882
assign 1 217 883
add 1 217 883
print 0 217 884
assign 1 219 886
new 4 219 886
assign 1 220 887
klassNameGet 0 220 887
assign 1 220 888
getSourceFileName 1 220 888
fileNameSet 1 220 889
assign 1 222 891
new 0 222 891
print 0 222 892
addFrame 1 224 894
assign 1 227 898
new 0 227 898
print 0 227 899
assign 1 236 912
assign 1 237 913
new 0 237 913
assign 1 238 914
assign 1 239 917
def 1 239 922
assign 1 239 923
def 1 239 928
assign 1 0 929
assign 1 0 932
assign 1 0 936
assign 1 239 939
new 0 239 939
assign 1 239 940
equals 1 239 940
assign 1 0 942
assign 1 0 945
assign 1 0 949
assign 1 240 952
linkedListIteratorGet 0 0 952
assign 1 240 955
hasNextGet 0 240 955
assign 1 240 957
nextGet 0 240 957
assign 1 241 958
klassNameGet 0 241 958
assign 1 241 959
extractKlassLib 1 241 959
klassNameSet 1 241 960
assign 1 242 961
methodNameGet 0 242 961
assign 1 242 962
extractMethod 1 242 962
methodNameSet 1 242 963
assign 1 243 964
klassNameGet 0 243 964
assign 1 243 965
getSourceFileName 1 243 965
fileNameSet 1 243 966
extractLine 0 245 968
assign 1 248 975
assign 1 249 976
new 0 249 976
assign 1 254 982
new 0 254 982
print 0 254 983
assign 1 260 992
new 0 260 992
assign 1 260 993
createInstance 2 260 993
assign 1 261 994
def 1 261 999
assign 1 263 1000
sourceFileNameGet 0 263 1000
return 1 263 1001
return 1 266 1003
assign 1 271 1011
new 0 271 1011
assign 1 271 1012
split 1 271 1012
assign 1 273 1013
new 0 273 1013
assign 1 273 1014
get 1 273 1014
assign 1 273 1015
extractKlass 1 273 1015
return 1 273 1016
assign 1 278 1022
extractKlassInner 1 278 1022
return 1 278 1023
return 1 282 1028
assign 1 286 1056
undef 1 286 1061
assign 1 0 1062
assign 1 286 1065
new 0 286 1065
assign 1 286 1066
begins 1 286 1066
assign 1 286 1067
not 0 286 1072
assign 1 0 1073
assign 1 0 1076
return 1 287 1080
assign 1 289 1082
new 0 289 1082
assign 1 289 1083
substring 1 289 1083
assign 1 289 1084
new 0 289 1084
assign 1 289 1085
split 1 289 1085
assign 1 290 1086
sizeGet 0 290 1086
assign 1 290 1087
new 0 290 1087
assign 1 290 1088
subtract 1 290 1088
assign 1 291 1089
get 1 291 1089
assign 1 292 1090
new 0 292 1090
assign 1 293 1091
new 0 293 1091
assign 1 294 1092
new 0 294 1092
assign 1 294 1095
lesser 1 294 1100
assign 1 295 1101
get 1 295 1101
assign 1 295 1102
new 1 295 1102
assign 1 297 1103
add 1 297 1103
assign 1 297 1104
substring 2 297 1104
addValue 1 297 1105
assign 1 298 1106
new 0 298 1106
assign 1 298 1107
add 1 298 1107
assign 1 298 1108
lesser 1 298 1113
assign 1 298 1114
new 0 298 1114
addValue 1 298 1115
addValue 1 299 1117
incrementValue 0 294 1118
return 1 302 1124
assign 1 306 1147
undef 1 306 1152
assign 1 0 1153
assign 1 306 1156
new 0 306 1156
assign 1 306 1157
begins 1 306 1157
assign 1 306 1158
not 0 306 1163
assign 1 0 1164
assign 1 0 1167
return 1 307 1171
assign 1 309 1173
new 0 309 1173
assign 1 309 1174
substring 1 309 1174
assign 1 309 1175
new 0 309 1175
assign 1 309 1176
split 1 309 1176
assign 1 310 1177
sizeGet 0 310 1177
assign 1 310 1178
new 0 310 1178
assign 1 310 1179
subtract 1 310 1179
assign 1 311 1180
new 0 311 1180
assign 1 312 1181
new 0 312 1181
assign 1 312 1184
lesser 1 312 1189
assign 1 313 1190
get 1 313 1190
addValue 1 313 1191
assign 1 314 1192
new 0 314 1192
assign 1 314 1193
add 1 314 1193
assign 1 314 1194
lesser 1 314 1199
assign 1 314 1200
new 0 314 1200
addValue 1 314 1201
incrementValue 0 312 1203
return 1 317 1209
translateEmittedException 0 323 1213
assign 1 325 1215
new 0 325 1215
print 0 325 1216
return 1 328 1218
translateEmittedException 0 332 1228
assign 1 333 1229
new 0 333 1229
assign 1 334 1230
framesGet 0 334 1230
assign 1 335 1231
def 1 335 1236
assign 1 336 1237
new 0 336 1237
assign 1 336 1238
add 1 336 1238
assign 1 337 1239
linkedListIteratorGet 0 0 1239
assign 1 337 1242
hasNextGet 0 337 1242
assign 1 337 1244
nextGet 0 337 1244
assign 1 338 1245
add 1 338 1245
return 1 341 1252
return 1 345 1255
assign 1 349 1259
undef 1 349 1264
assign 1 350 1265
new 0 350 1265
addValue 1 352 1267
assign 1 356 1272
new 4 356 1272
addFrame 1 356 1273
return 1 0 1277
assign 1 0 1280
assign 1 0 1284
return 1 0 1288
assign 1 0 1291
return 1 0 1295
assign 1 0 1298
return 1 0 1302
assign 1 0 1305
return 1 0 1309
assign 1 0 1312
return 1 0 1316
assign 1 0 1319
assign 1 0 1323
return 1 0 1327
assign 1 0 1330
return 1 0 1334
assign 1 0 1337
return 1 0 1341
assign 1 0 1344
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1604962015: return bem_sourceFileNameGet_0();
case 1310553601: return bem_toString_0();
case -732524867: return bem_tagGet_0();
case 1924413487: return bem_hashGet_0();
case 1652177595: return bem_translateEmittedException_0();
case 14222936: return bem_descriptionGet_0();
case -980884323: return bem_new_0();
case -1451203303: return bem_lineNumberGet_0();
case -1897026239: return bem_echo_0();
case -1565549870: return bem_print_0();
case 1793221455: return bem_copy_0();
case 1129053182: return bem_translateEmittedExceptionInner_0();
case 1110529799: return bem_emitLangGet_0();
case 950136265: return bem_vvGet_0();
case -1226625126: return bem_once_0();
case 215322388: return bem_fileNameGet_0();
case 489788599: return bem_serializeContents_0();
case -176246897: return bem_framesTextGet_0();
case -1920531733: return bem_serializationIteratorGet_0();
case -1535847383: return bem_toAny_0();
case -306303426: return bem_methodNameGet_0();
case 1150664853: return bem_create_0();
case -1081087328: return bem_langGet_0();
case -290041240: return bem_serializeToString_0();
case 2049066942: return bem_fieldIteratorGet_0();
case -1326718107: return bem_getFrameText_0();
case 2052709534: return bem_many_0();
case -728210038: return bem_translatedGet_0();
case 194016774: return bem_iteratorGet_0();
case -259991050: return bem_klassNameGet_0();
case -525681067: return bem_classNameGet_0();
case 332981262: return bem_deserializeClassNameGet_0();
case 789313479: return bem_framesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1936074077: return bem_klassNameSet_1(bevd_0);
case -1545437990: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1966507736: return bem_undef_1(bevd_0);
case -1586463464: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 959360624: return bem_otherType_1(bevd_0);
case 863435643: return bem_equals_1(bevd_0);
case 978698391: return bem_fileNameSet_1(bevd_0);
case 279904401: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 257405303: return bem_copyTo_1(bevd_0);
case 420384947: return bem_def_1(bevd_0);
case 1091645150: return bem_emitLangSet_1(bevd_0);
case 386836188: return bem_otherClass_1(bevd_0);
case -1233990290: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -453401206: return bem_vvSet_1(bevd_0);
case 1868528499: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1181837366: return bem_translatedSet_1(bevd_0);
case 1693216688: return bem_sameClass_1(bevd_0);
case -2104330508: return bem_sameObject_1(bevd_0);
case -1021436824: return bem_sameType_1(bevd_0);
case 1858229799: return bem_descriptionSet_1(bevd_0);
case -1960812475: return bem_framesTextSet_1(bevd_0);
case -243829290: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1834098557: return bem_notEquals_1(bevd_0);
case -2075540734: return bem_langSet_1(bevd_0);
case -798191677: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -467299687: return bem_defined_1(bevd_0);
case 562081982: return bem_undefined_1(bevd_0);
case 1465161497: return bem_methodNameSet_1(bevd_0);
case -145738070: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1585694121: return bem_lineNumberSet_1(bevd_0);
case -1343499453: return bem_new_1(bevd_0);
case -475723519: return bem_framesSet_1(bevd_0);
case 1998776126: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2090513876: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1240676558: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -371043039: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1325559256: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1035622269: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -145115514: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686918154: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1895634211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1272540796: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
