package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_9, 28));
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_10, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_11 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_11, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_12 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_9_SystemException_bels_13 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_13, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_14 = {0x46,0x72,0x61,0x6D,0x65,0x20,0x6C,0x69,0x6E,0x65,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_14, 14));
private static byte[] bece_BEC_2_6_9_SystemException_bels_15 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_15, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_16 = {0x73,0x74,0x61,0x72,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_16, 9));
private static byte[] bece_BEC_2_6_9_SystemException_bels_17 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_17, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_9 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_18 = {0x65,0x6E,0x64,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_18, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_19 = {0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_19, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_13 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_20 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_20, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_21 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_17 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_22 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_22, 5));
private static byte[] bece_BEC_2_6_9_SystemException_bels_23 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_23, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_24 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_24, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_25 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_25, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_22 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_26 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x65,0x6E,0x64,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_26, 13));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_27 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_25 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_28 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_27 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_29 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_29, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_29 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_30 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_31 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_30 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_31 = {0x63,0x61,0x6C,0x6C,0x50,0x61,0x72,0x74,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_31, 10));
private static byte[] bece_BEC_2_6_9_SystemException_bels_32 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_32, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_33 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_34 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_35 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_34 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6D,0x74,0x64,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_34, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_35 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_35, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_36 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_36, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_37 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_37, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_41 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_42 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_38 = {0x70,0x72,0x65,0x20,0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_38, 21));
private static byte[] bece_BEC_2_6_9_SystemException_bels_39 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_39, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_40 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_40, 17));
private static byte[] bece_BEC_2_6_9_SystemException_bels_41 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_41, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_42 = {0x61,0x64,0x64,0x69,0x6E,0x67,0x20,0x66,0x72,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_42, 12));
private static byte[] bece_BEC_2_6_9_SystemException_bels_43 = {0x6E,0x6F,0x20,0x65,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_43, 6));
private static byte[] bece_BEC_2_6_9_SystemException_bels_44 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_45 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_45, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_46 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_47 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_47, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_48 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_49 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_49, 4));
private static byte[] bece_BEC_2_6_9_SystemException_bels_50 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_52 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_53 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_51 = {0x3A};
private static byte[] bece_BEC_2_6_9_SystemException_bels_52 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_52, 4));
private static byte[] bece_BEC_2_6_9_SystemException_bels_53 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_55 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_56 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_54 = {0x5F};
private static byte[] bece_BEC_2_6_9_SystemException_bels_55 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_55, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_56 = {0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_56, 1));
public static BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;
public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_vv = be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_0));
if (bevp_description == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_1));
bevt_1_tmpany_phold = bevl_toRet.bemd_1(419552466, bevt_2_tmpany_phold);
bevl_toRet = bevt_1_tmpany_phold.bemd_1(419552466, bevp_description);
} /* Line: 35 */
if (bevp_fileName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_2));
bevt_4_tmpany_phold = bevl_toRet.bemd_1(419552466, bevt_5_tmpany_phold);
bevl_toRet = bevt_4_tmpany_phold.bemd_1(419552466, bevp_fileName);
} /* Line: 38 */
if (bevp_lineNumber == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_3));
bevt_7_tmpany_phold = bevl_toRet.bemd_1(419552466, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_lineNumber.bemd_0(1737839713);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(419552466, bevt_9_tmpany_phold);
} /* Line: 41 */
if (bevp_lang == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_11_tmpany_phold = bevl_toRet.bemd_1(419552466, bevt_12_tmpany_phold);
bevl_toRet = bevt_11_tmpany_phold.bemd_1(419552466, bevp_lang);
} /* Line: 44 */
if (bevp_emitLang == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_5));
bevt_14_tmpany_phold = bevl_toRet.bemd_1(419552466, bevt_15_tmpany_phold);
bevl_toRet = bevt_14_tmpany_phold.bemd_1(419552466, bevp_emitLang);
} /* Line: 47 */
if (bevp_methodName == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_6));
bevt_17_tmpany_phold = bevl_toRet.bemd_1(419552466, bevt_18_tmpany_phold);
bevl_toRet = bevt_17_tmpany_phold.bemd_1(419552466, bevp_methodName);
} /* Line: 50 */
if (bevp_klassName == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_7));
bevt_20_tmpany_phold = bevl_toRet.bemd_1(419552466, bevt_21_tmpany_phold);
bevl_toRet = bevt_20_tmpany_phold.bemd_1(419552466, bevp_klassName);
} /* Line: 53 */
if (bevp_framesText == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_8));
bevt_23_tmpany_phold = bevl_toRet.bemd_1(419552466, bevt_24_tmpany_phold);
bevl_toRet = bevt_23_tmpany_phold.bemd_1(419552466, bevp_framesText);
} /* Line: 56 */
if (bevp_frames == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_26_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(419552466, bevt_26_tmpany_phold);
} /* Line: 59 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_9_SystemException bem_translateEmittedException_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 65 */ {
bem_translateEmittedExceptionInner_0();
} /* Line: 66 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_0;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 68 */
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_translateEmittedExceptionInner_0() throws Throwable {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpany_phold = null;
BEC_2_4_6_TextString bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_6_TextString bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_6_TextString bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_134_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_4_6_TextString bevt_142_tmpany_phold = null;
BEC_2_4_6_TextString bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_4_6_TextString bevt_145_tmpany_phold = null;
if (bevp_translated == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 76 */ {
if (bevp_translated.bevi_bool) /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 76 */
 else  /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 76 */ {
return this;
} /* Line: 77 */
if (bevp_vv == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevp_vv = be.BECS_Runtime.boolFalse;
} /* Line: 80 */
bevp_translated = be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 83 */ {
if (bevp_lang == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_17_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_1;
bevt_16_tmpany_phold = bevp_lang.bem_equals_1(bevt_17_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_2;
bevt_18_tmpany_phold = bevp_lang.bem_equals_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_12));
bevl_ltok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_20_tmpany_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_22_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_3;
bevt_21_tmpany_phold = bevp_lang.bem_equals_1(bevt_22_tmpany_phold);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevl_isCs = be.BECS_Runtime.boolTrue;
} /* Line: 87 */
 else  /* Line: 88 */ {
bevl_isCs = be.BECS_Runtime.boolFalse;
} /* Line: 89 */
bevt_0_tmpany_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 91 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
if (bevp_vv.bevi_bool) /* Line: 92 */ {
bevt_25_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_4;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevl_line);
bevt_24_tmpany_phold.bem_print_0();
} /* Line: 93 */
bevt_26_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_5;
bevl_start = bevl_line.bem_find_1(bevt_26_tmpany_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_29_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_6;
if (bevl_start.bevi_int >= bevt_29_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 98 */ {
if (bevp_vv.bevi_bool) /* Line: 99 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_7;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevl_start);
bevt_30_tmpany_phold.bem_print_0();
} /* Line: 100 */
bevt_32_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_8;
bevt_34_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_9;
bevt_33_tmpany_phold = bevl_start.bem_add_1(bevt_34_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
if (bevl_end == null) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 103 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 103 */ {
if (bevp_vv.bevi_bool) /* Line: 104 */ {
bevt_38_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_10;
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevl_end);
bevt_37_tmpany_phold.bem_print_0();
} /* Line: 105 */
bevt_40_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_11;
bevt_39_tmpany_phold = bevl_start.bem_add_1(bevt_40_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_39_tmpany_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 109 */ {
bevt_41_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_12;
bevl_start = bevl_line.bem_find_2(bevt_41_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_44_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_13;
bevt_43_tmpany_phold = bevl_start.bem_add_1(bevt_44_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_43_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_14;
bevt_45_tmpany_phold = bevl_inPart.bem_ends_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_48_tmpany_phold = bevl_inPart.bem_sizeGet_0();
bevt_49_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_15;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_subtract_1(bevt_49_tmpany_phold);
bevl_inPart.bem_sizeSet_1(bevt_47_tmpany_phold);
} /* Line: 115 */
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_21));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_50_tmpany_phold);
if (bevl_pdelim == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_52_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_16;
bevl_efile = bevl_inPart.bem_substring_2(bevt_52_tmpany_phold, bevl_pdelim);
bevt_54_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_17;
bevt_53_tmpany_phold = bevl_pdelim.bem_add_1(bevt_54_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_53_tmpany_phold);
bevt_56_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_18;
bevt_55_tmpany_phold = bevl_iv.bem_begins_1(bevt_56_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_57_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_57_tmpany_phold);
} /* Line: 124 */
bevt_58_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 128 */
} /* Line: 127 */
} /* Line: 119 */
} /* Line: 111 */
 else  /* Line: 132 */ {
bevt_59_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_19;
bevl_start = bevl_line.bem_find_2(bevt_59_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 134 */ {
if (bevp_vv.bevi_bool) /* Line: 135 */ {
bevt_61_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_20;
bevt_61_tmpany_phold.bem_print_0();
} /* Line: 136 */
bevt_62_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_21;
bevt_64_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_22;
bevt_63_tmpany_phold = bevl_start.bem_add_1(bevt_64_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
if (bevl_end == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 140 */ {
if (bevp_vv.bevi_bool) /* Line: 141 */ {
bevt_66_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_23;
bevt_66_tmpany_phold.bem_print_0();
} /* Line: 142 */
bevt_68_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_24;
bevt_67_tmpany_phold = bevl_start.bem_add_1(bevt_68_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_67_tmpany_phold, bevl_end);
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_27));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_69_tmpany_phold);
if (bevl_pdelim == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 147 */ {
bevt_71_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_25;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_71_tmpany_phold, bevl_pdelim);
bevt_72_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_28));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_72_tmpany_phold);
if (bevl_pdelim == null) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevt_74_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_26;
bevl_efile = bevl_inPart.bem_substring_2(bevt_74_tmpany_phold, bevl_pdelim);
} /* Line: 152 */
bevt_76_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_27;
bevt_75_tmpany_phold = bevl_pdelim.bem_add_1(bevt_76_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_77_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 157 */
} /* Line: 156 */
} /* Line: 147 */
} /* Line: 140 */
} /* Line: 134 */
} /* Line: 109 */
 else  /* Line: 163 */ {
bevt_78_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_28;
bevt_80_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_29;
bevt_79_tmpany_phold = bevl_start.bem_add_1(bevt_80_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
if (bevl_end == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 165 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 165 */
 else  /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 165 */ {
bevt_84_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_30;
bevt_83_tmpany_phold = bevl_start.bem_add_1(bevt_84_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_83_tmpany_phold, bevl_end);
} /* Line: 166 */
 else  /* Line: 167 */ {
bevt_86_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_31;
bevt_85_tmpany_phold = bevl_start.bem_add_1(bevt_86_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_85_tmpany_phold);
} /* Line: 168 */
} /* Line: 165 */
if (bevl_callPart == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 171 */ {
if (bevl_isCs.bevi_bool) /* Line: 172 */ {
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_30));
bevl_parts = bevl_callPart.bem_split_1(bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_90_tmpany_phold);
bevl_klass = bem_extractKlass_1(bevl_klass);
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_92_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_91_tmpany_phold = bem_getSourceFileName_1(bevt_92_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_91_tmpany_phold);
bem_addFrame_1(bevl_fr);
} /* Line: 185 */
 else  /* Line: 186 */ {
if (bevp_vv.bevi_bool) /* Line: 188 */ {
bevt_95_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_32;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevl_callPart);
bevt_96_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_33;
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bem_add_1(bevt_96_tmpany_phold);
bevt_93_tmpany_phold.bem_print_0();
} /* Line: 189 */
bevt_97_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_33));
bevl_parts = bevl_callPart.bem_split_1(bevt_97_tmpany_phold);
bevt_99_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_100_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_34;
if (bevt_99_tmpany_phold.bevi_int > bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_102_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_103_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_35;
if (bevt_102_tmpany_phold.bevi_int > bevt_103_tmpany_phold.bevi_int) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 193 */ {
bevt_104_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_105_tmpany_phold);
} /* Line: 195 */
 else  /* Line: 196 */ {
bevt_106_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_107_tmpany_phold);
} /* Line: 198 */
bevl_mtd = bem_extractMethod_1(bevl_mtd);
if (bevp_vv.bevi_bool) /* Line: 201 */ {
bevt_110_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_36;
bevt_109_tmpany_phold = bevt_110_tmpany_phold.bem_add_1(bevl_mtd);
bevt_111_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_37;
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bem_add_1(bevt_111_tmpany_phold);
bevt_108_tmpany_phold.bem_print_0();
} /* Line: 202 */
bevt_112_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_38;
bevl_start = bevl_klass.bem_find_1(bevt_112_tmpany_phold);
if (bevl_start == null) {
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_113_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevt_115_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_39;
if (bevl_start.bevi_int > bevt_115_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 205 */ {
bevt_116_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_40;
bevt_118_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_41;
bevt_117_tmpany_phold = bevl_start.bem_add_1(bevt_118_tmpany_phold);
bevl_end = bevl_klass.bem_find_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
if (bevl_end == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_121_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_42;
if (bevl_end.bevi_int > bevt_121_tmpany_phold.bevi_int) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 207 */
 else  /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 207 */ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
if (bevp_vv.bevi_bool) /* Line: 212 */ {
bevt_124_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_43;
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bem_add_1(bevl_klass);
bevt_125_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_44;
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bem_add_1(bevt_125_tmpany_phold);
bevt_122_tmpany_phold.bem_print_0();
} /* Line: 213 */
bevl_klass = bem_extractKlass_1(bevl_klass);
if (bevp_vv.bevi_bool) /* Line: 216 */ {
bevt_128_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_45;
bevt_127_tmpany_phold = bevt_128_tmpany_phold.bem_add_1(bevl_klass);
bevt_129_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_46;
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bem_add_1(bevt_129_tmpany_phold);
bevt_126_tmpany_phold.bem_print_0();
} /* Line: 217 */
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_131_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_130_tmpany_phold = bem_getSourceFileName_1(bevt_131_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_130_tmpany_phold);
if (bevp_vv.bevi_bool) /* Line: 221 */ {
bevt_132_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_47;
bevt_132_tmpany_phold.bem_print_0();
} /* Line: 222 */
bem_addFrame_1(bevl_fr);
} /* Line: 224 */
 else  /* Line: 225 */ {
if (bevp_vv.bevi_bool) /* Line: 226 */ {
bevt_133_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_48;
bevt_133_tmpany_phold.bem_print_0();
} /* Line: 227 */
} /* Line: 226 */
} /* Line: 207 */
} /* Line: 205 */
} /* Line: 192 */
} /* Line: 172 */
} /* Line: 171 */
} /* Line: 98 */
 else  /* Line: 91 */ {
break;
} /* Line: 91 */
} /* Line: 91 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_44));
bevp_framesText = null;
} /* Line: 238 */
 else  /* Line: 83 */ {
if (bevp_frames == null) {
bevt_134_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_134_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_134_tmpany_phold.bevi_bool) /* Line: 239 */ {
if (bevp_lang == null) {
bevt_135_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 239 */ {
bevt_137_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_49;
bevt_136_tmpany_phold = bevp_lang.bem_equals_1(bevt_137_tmpany_phold);
if (bevt_136_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpany_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_138_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_138_tmpany_phold != null && bevt_138_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_138_tmpany_phold).bevi_bool) /* Line: 240 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpany_loop.bem_nextGet_0();
bevt_140_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_139_tmpany_phold = bem_extractKlassLib_1(bevt_140_tmpany_phold);
bevl_fr.bem_klassNameSet_1(bevt_139_tmpany_phold);
bevt_142_tmpany_phold = bevl_fr.bem_methodNameGet_0();
bevt_141_tmpany_phold = bem_extractMethod_1(bevt_142_tmpany_phold);
bevl_fr.bem_methodNameSet_1(bevt_141_tmpany_phold);
bevt_144_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_143_tmpany_phold = bem_getSourceFileName_1(bevt_144_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_143_tmpany_phold);
 /* Line: 244 */ {
bevl_fr.bem_extractLine_0();
} /* Line: 245 */
} /* Line: 244 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_46));
} /* Line: 249 */
 else  /* Line: 250 */ {
} /* Line: 250 */
} /* Line: 83 */
if (bevp_vv.bevi_bool) /* Line: 253 */ {
bevt_145_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_50;
bevt_145_tmpany_phold.bem_print_0();
} /* Line: 254 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_i = bem_createInstance_2(beva_klassName, bevt_0_tmpany_phold);
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(-416881840);
return (BEC_2_4_6_TextString) bevt_2_tmpany_phold;
} /* Line: 263 */
return null;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_48));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_2_tmpany_phold = bevl_parts.bem_get_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpany_phold );
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 277 */ {
bevt_0_tmpany_phold = bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpany_phold;
} /* Line: 278 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 279 */
return beva_klass;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_51;
bevt_3_tmpany_phold = beva_klass.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 286 */ {
return beva_klass;
} /* Line: 287 */
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_5_tmpany_phold = beva_klass.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_50));
bevl_kparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_52;
bevl_kps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 294 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 294 */ {
bevt_11_tmpany_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpany_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpany_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_53;
bevt_15_tmpany_phold = bevl_i.bem_add_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_51));
bevl_bec.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 298 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 294 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
return bevl_bec;
} /*method end*/
public BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
if (beva_mtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 306 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_54;
bevt_3_tmpany_phold = beva_mtd.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 306 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 306 */ {
return beva_mtd;
} /* Line: 307 */
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(4));
bevt_5_tmpany_phold = beva_mtd.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_53));
bevl_mparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_55;
bevl_mps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_bem = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 312 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_11_tmpany_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_56;
bevt_13_tmpany_phold = bevl_i.bem_add_1(bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_54));
bevl_bem.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 314 */
bevl_i.bevi_int++;
} /* Line: 312 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
return bevl_bem;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bem_translateEmittedException_0();
if (bevp_vv.bevi_bool) /* Line: 324 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_57;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 325 */
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 335 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_58;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 337 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 337 */ {
bevl_ft = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 338 */
 else  /* Line: 337 */ {
break;
} /* Line: 337 */
} /* Line: 337 */
} /* Line: 337 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_frames == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevp_frames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 350 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGet_0() throws Throwable {
return bevp_vv;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 26, 30, 33, 34, 34, 35, 35, 35, 37, 37, 38, 38, 38, 40, 40, 41, 41, 41, 41, 43, 43, 44, 44, 44, 46, 46, 47, 47, 47, 49, 49, 50, 50, 50, 52, 52, 53, 53, 53, 55, 55, 56, 56, 56, 58, 58, 59, 59, 61, 66, 68, 68, 76, 76, 0, 0, 0, 77, 79, 79, 80, 82, 83, 83, 83, 83, 0, 0, 0, 83, 83, 0, 83, 83, 0, 0, 0, 0, 0, 84, 84, 85, 86, 86, 87, 89, 91, 0, 91, 91, 93, 93, 93, 95, 95, 96, 97, 98, 98, 98, 98, 98, 0, 0, 0, 100, 100, 100, 102, 102, 102, 102, 103, 103, 103, 103, 0, 0, 0, 105, 105, 105, 107, 107, 107, 110, 110, 111, 111, 113, 113, 113, 114, 114, 115, 115, 115, 115, 118, 118, 119, 119, 120, 120, 122, 122, 122, 123, 123, 124, 124, 127, 128, 133, 133, 134, 134, 136, 136, 139, 139, 139, 139, 140, 140, 142, 142, 144, 144, 144, 146, 146, 147, 147, 148, 148, 150, 150, 151, 151, 152, 152, 154, 154, 154, 156, 157, 164, 164, 164, 164, 165, 165, 165, 165, 0, 0, 0, 166, 166, 166, 168, 168, 168, 171, 171, 174, 174, 176, 176, 177, 177, 179, 181, 183, 184, 184, 184, 185, 189, 189, 189, 189, 189, 191, 191, 192, 192, 192, 192, 193, 193, 193, 193, 194, 194, 195, 195, 197, 197, 198, 198, 200, 202, 202, 202, 202, 202, 204, 204, 205, 205, 205, 205, 205, 0, 0, 0, 206, 206, 206, 206, 207, 207, 207, 207, 207, 0, 0, 0, 211, 213, 213, 213, 213, 213, 215, 217, 217, 217, 217, 217, 219, 220, 220, 220, 222, 222, 224, 227, 227, 236, 237, 238, 239, 239, 239, 239, 0, 0, 0, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 241, 241, 242, 242, 242, 243, 243, 243, 245, 248, 249, 254, 254, 260, 260, 261, 261, 263, 263, 266, 271, 271, 273, 273, 273, 273, 278, 278, 282, 286, 286, 0, 286, 286, 286, 286, 0, 0, 287, 289, 289, 289, 289, 290, 290, 290, 291, 292, 293, 294, 294, 294, 295, 295, 297, 297, 297, 298, 298, 298, 298, 298, 298, 299, 294, 302, 306, 306, 0, 306, 306, 306, 306, 0, 0, 307, 309, 309, 309, 309, 310, 310, 310, 311, 312, 312, 312, 313, 313, 314, 314, 314, 314, 314, 314, 312, 317, 323, 325, 325, 328, 332, 333, 334, 335, 335, 336, 336, 337, 0, 337, 337, 338, 341, 345, 349, 349, 350, 352, 356, 356, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {136, 137, 169, 170, 171, 176, 177, 178, 179, 181, 186, 187, 188, 189, 191, 196, 197, 198, 199, 200, 202, 207, 208, 209, 210, 212, 217, 218, 219, 220, 222, 227, 228, 229, 230, 232, 237, 238, 239, 240, 242, 247, 248, 249, 250, 252, 257, 258, 259, 261, 267, 271, 272, 439, 444, 446, 449, 453, 456, 458, 463, 464, 466, 467, 472, 473, 478, 479, 482, 486, 489, 490, 492, 495, 496, 498, 501, 505, 508, 512, 515, 516, 517, 518, 519, 521, 524, 526, 526, 529, 531, 533, 534, 535, 537, 538, 539, 540, 541, 546, 547, 548, 553, 554, 557, 561, 565, 566, 567, 569, 570, 571, 572, 573, 578, 579, 584, 585, 588, 592, 596, 597, 598, 600, 601, 602, 604, 605, 606, 611, 612, 613, 614, 615, 616, 618, 619, 620, 621, 623, 624, 625, 630, 631, 632, 633, 634, 635, 636, 637, 639, 640, 642, 644, 650, 651, 652, 657, 659, 660, 662, 663, 664, 665, 666, 671, 673, 674, 676, 677, 678, 679, 680, 681, 686, 687, 688, 689, 690, 691, 696, 697, 698, 700, 701, 702, 703, 705, 713, 714, 715, 716, 717, 722, 723, 728, 729, 732, 736, 739, 740, 741, 744, 745, 746, 749, 754, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 772, 773, 774, 775, 776, 778, 779, 780, 781, 782, 787, 788, 789, 790, 795, 796, 797, 798, 799, 802, 803, 804, 805, 807, 809, 810, 811, 812, 813, 815, 816, 817, 822, 823, 824, 829, 830, 833, 837, 840, 841, 842, 843, 844, 849, 850, 851, 856, 857, 860, 864, 867, 869, 870, 871, 872, 873, 875, 877, 878, 879, 880, 881, 883, 884, 885, 886, 888, 889, 891, 895, 896, 909, 910, 911, 914, 919, 920, 925, 926, 929, 933, 936, 937, 939, 942, 946, 949, 949, 952, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 965, 972, 973, 979, 980, 989, 990, 991, 996, 997, 998, 1000, 1008, 1009, 1010, 1011, 1012, 1013, 1019, 1020, 1025, 1053, 1058, 1059, 1062, 1063, 1064, 1069, 1070, 1073, 1077, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1092, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1110, 1111, 1112, 1114, 1115, 1121, 1144, 1149, 1150, 1153, 1154, 1155, 1160, 1161, 1164, 1168, 1170, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1178, 1181, 1186, 1187, 1188, 1189, 1190, 1191, 1196, 1197, 1198, 1200, 1206, 1210, 1212, 1213, 1215, 1225, 1226, 1227, 1228, 1233, 1234, 1235, 1236, 1236, 1239, 1241, 1242, 1249, 1252, 1256, 1261, 1262, 1264, 1269, 1270, 1274, 1277, 1281, 1285, 1288, 1292, 1295, 1299, 1302, 1306, 1309, 1313, 1316, 1320, 1324, 1327, 1331, 1334, 1338, 1341};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 136
new 0 23 136
assign 1 26 137
translateEmittedException 0 30 169
assign 1 33 170
new 0 33 170
assign 1 34 171
def 1 34 176
assign 1 35 177
new 0 35 177
assign 1 35 178
add 1 35 178
assign 1 35 179
add 1 35 179
assign 1 37 181
def 1 37 186
assign 1 38 187
new 0 38 187
assign 1 38 188
add 1 38 188
assign 1 38 189
add 1 38 189
assign 1 40 191
def 1 40 196
assign 1 41 197
new 0 41 197
assign 1 41 198
add 1 41 198
assign 1 41 199
toString 0 41 199
assign 1 41 200
add 1 41 200
assign 1 43 202
def 1 43 207
assign 1 44 208
new 0 44 208
assign 1 44 209
add 1 44 209
assign 1 44 210
add 1 44 210
assign 1 46 212
def 1 46 217
assign 1 47 218
new 0 47 218
assign 1 47 219
add 1 47 219
assign 1 47 220
add 1 47 220
assign 1 49 222
def 1 49 227
assign 1 50 228
new 0 50 228
assign 1 50 229
add 1 50 229
assign 1 50 230
add 1 50 230
assign 1 52 232
def 1 52 237
assign 1 53 238
new 0 53 238
assign 1 53 239
add 1 53 239
assign 1 53 240
add 1 53 240
assign 1 55 242
def 1 55 247
assign 1 56 248
new 0 56 248
assign 1 56 249
add 1 56 249
assign 1 56 250
add 1 56 250
assign 1 58 252
def 1 58 257
assign 1 59 258
getFrameText 0 59 258
assign 1 59 259
add 1 59 259
return 1 61 261
translateEmittedExceptionInner 0 66 267
assign 1 68 271
new 0 68 271
print 0 68 272
assign 1 76 439
def 1 76 444
assign 1 0 446
assign 1 0 449
assign 1 0 453
return 1 77 456
assign 1 79 458
undef 1 79 463
assign 1 80 464
new 0 80 464
assign 1 82 466
new 0 82 466
assign 1 83 467
def 1 83 472
assign 1 83 473
def 1 83 478
assign 1 0 479
assign 1 0 482
assign 1 0 486
assign 1 83 489
new 0 83 489
assign 1 83 490
equals 1 83 490
assign 1 0 492
assign 1 83 495
new 0 83 495
assign 1 83 496
equals 1 83 496
assign 1 0 498
assign 1 0 501
assign 1 0 505
assign 1 0 508
assign 1 0 512
assign 1 84 515
new 0 84 515
assign 1 84 516
new 1 84 516
assign 1 85 517
tokenize 1 85 517
assign 1 86 518
new 0 86 518
assign 1 86 519
equals 1 86 519
assign 1 87 521
new 0 87 521
assign 1 89 524
new 0 89 524
assign 1 91 526
linkedListIteratorGet 0 0 526
assign 1 91 529
hasNextGet 0 91 529
assign 1 91 531
nextGet 0 91 531
assign 1 93 533
new 0 93 533
assign 1 93 534
add 1 93 534
print 0 93 535
assign 1 95 537
new 0 95 537
assign 1 95 538
find 1 95 538
assign 1 96 539
assign 1 97 540
assign 1 98 541
def 1 98 546
assign 1 98 547
new 0 98 547
assign 1 98 548
greaterEquals 1 98 553
assign 1 0 554
assign 1 0 557
assign 1 0 561
assign 1 100 565
new 0 100 565
assign 1 100 566
add 1 100 566
print 0 100 567
assign 1 102 569
new 0 102 569
assign 1 102 570
new 0 102 570
assign 1 102 571
add 1 102 571
assign 1 102 572
find 2 102 572
assign 1 103 573
def 1 103 578
assign 1 103 579
greater 1 103 584
assign 1 0 585
assign 1 0 588
assign 1 0 592
assign 1 105 596
new 0 105 596
assign 1 105 597
add 1 105 597
print 0 105 598
assign 1 107 600
new 0 107 600
assign 1 107 601
add 1 107 601
assign 1 107 602
substring 2 107 602
assign 1 110 604
new 0 110 604
assign 1 110 605
find 2 110 605
assign 1 111 606
def 1 111 611
assign 1 113 612
new 0 113 612
assign 1 113 613
add 1 113 613
assign 1 113 614
substring 1 113 614
assign 1 114 615
new 0 114 615
assign 1 114 616
ends 1 114 616
assign 1 115 618
sizeGet 0 115 618
assign 1 115 619
new 0 115 619
assign 1 115 620
subtract 1 115 620
sizeSet 1 115 621
assign 1 118 623
new 0 118 623
assign 1 118 624
rfind 1 118 624
assign 1 119 625
def 1 119 630
assign 1 120 631
new 0 120 631
assign 1 120 632
substring 2 120 632
assign 1 122 633
new 0 122 633
assign 1 122 634
add 1 122 634
assign 1 122 635
substring 1 122 635
assign 1 123 636
new 0 123 636
assign 1 123 637
begins 1 123 637
assign 1 124 639
new 0 124 639
assign 1 124 640
substring 1 124 640
assign 1 127 642
isInteger 0 127 642
assign 1 128 644
new 1 128 644
assign 1 133 650
new 0 133 650
assign 1 133 651
find 2 133 651
assign 1 134 652
def 1 134 657
assign 1 136 659
new 0 136 659
print 0 136 660
assign 1 139 662
new 0 139 662
assign 1 139 663
new 0 139 663
assign 1 139 664
add 1 139 664
assign 1 139 665
find 2 139 665
assign 1 140 666
def 1 140 671
assign 1 142 673
new 0 142 673
print 0 142 674
assign 1 144 676
new 0 144 676
assign 1 144 677
add 1 144 677
assign 1 144 678
substring 2 144 678
assign 1 146 679
new 0 146 679
assign 1 146 680
rfind 1 146 680
assign 1 147 681
def 1 147 686
assign 1 148 687
new 0 148 687
assign 1 148 688
substring 2 148 688
assign 1 150 689
new 0 150 689
assign 1 150 690
rfind 1 150 690
assign 1 151 691
def 1 151 696
assign 1 152 697
new 0 152 697
assign 1 152 698
substring 2 152 698
assign 1 154 700
new 0 154 700
assign 1 154 701
add 1 154 701
assign 1 154 702
substring 1 154 702
assign 1 156 703
isInteger 0 156 703
assign 1 157 705
new 1 157 705
assign 1 164 713
new 0 164 713
assign 1 164 714
new 0 164 714
assign 1 164 715
add 1 164 715
assign 1 164 716
find 2 164 716
assign 1 165 717
def 1 165 722
assign 1 165 723
greater 1 165 728
assign 1 0 729
assign 1 0 732
assign 1 0 736
assign 1 166 739
new 0 166 739
assign 1 166 740
add 1 166 740
assign 1 166 741
substring 2 166 741
assign 1 168 744
new 0 168 744
assign 1 168 745
add 1 168 745
assign 1 168 746
substring 1 168 746
assign 1 171 749
def 1 171 754
assign 1 174 756
new 0 174 756
assign 1 174 757
split 1 174 757
assign 1 176 758
new 0 176 758
assign 1 176 759
get 1 176 759
assign 1 177 760
new 0 177 760
assign 1 177 761
get 1 177 761
assign 1 179 762
extractKlass 1 179 762
assign 1 181 763
extractMethod 1 181 763
assign 1 183 764
new 4 183 764
assign 1 184 765
klassNameGet 0 184 765
assign 1 184 766
getSourceFileName 1 184 766
fileNameSet 1 184 767
addFrame 1 185 768
assign 1 189 772
new 0 189 772
assign 1 189 773
add 1 189 773
assign 1 189 774
new 0 189 774
assign 1 189 775
add 1 189 775
print 0 189 776
assign 1 191 778
new 0 191 778
assign 1 191 779
split 1 191 779
assign 1 192 780
sizeGet 0 192 780
assign 1 192 781
new 0 192 781
assign 1 192 782
greater 1 192 787
assign 1 193 788
sizeGet 0 193 788
assign 1 193 789
new 0 193 789
assign 1 193 790
greater 1 193 795
assign 1 194 796
new 0 194 796
assign 1 194 797
get 1 194 797
assign 1 195 798
new 0 195 798
assign 1 195 799
get 1 195 799
assign 1 197 802
new 0 197 802
assign 1 197 803
get 1 197 803
assign 1 198 804
new 0 198 804
assign 1 198 805
get 1 198 805
assign 1 200 807
extractMethod 1 200 807
assign 1 202 809
new 0 202 809
assign 1 202 810
add 1 202 810
assign 1 202 811
new 0 202 811
assign 1 202 812
add 1 202 812
print 0 202 813
assign 1 204 815
new 0 204 815
assign 1 204 816
find 1 204 816
assign 1 205 817
def 1 205 822
assign 1 205 823
new 0 205 823
assign 1 205 824
greater 1 205 829
assign 1 0 830
assign 1 0 833
assign 1 0 837
assign 1 206 840
new 0 206 840
assign 1 206 841
new 0 206 841
assign 1 206 842
add 1 206 842
assign 1 206 843
find 2 206 843
assign 1 207 844
def 1 207 849
assign 1 207 850
new 0 207 850
assign 1 207 851
greater 1 207 856
assign 1 0 857
assign 1 0 860
assign 1 0 864
assign 1 211 867
substring 1 211 867
assign 1 213 869
new 0 213 869
assign 1 213 870
add 1 213 870
assign 1 213 871
new 0 213 871
assign 1 213 872
add 1 213 872
print 0 213 873
assign 1 215 875
extractKlass 1 215 875
assign 1 217 877
new 0 217 877
assign 1 217 878
add 1 217 878
assign 1 217 879
new 0 217 879
assign 1 217 880
add 1 217 880
print 0 217 881
assign 1 219 883
new 4 219 883
assign 1 220 884
klassNameGet 0 220 884
assign 1 220 885
getSourceFileName 1 220 885
fileNameSet 1 220 886
assign 1 222 888
new 0 222 888
print 0 222 889
addFrame 1 224 891
assign 1 227 895
new 0 227 895
print 0 227 896
assign 1 236 909
assign 1 237 910
new 0 237 910
assign 1 238 911
assign 1 239 914
def 1 239 919
assign 1 239 920
def 1 239 925
assign 1 0 926
assign 1 0 929
assign 1 0 933
assign 1 239 936
new 0 239 936
assign 1 239 937
equals 1 239 937
assign 1 0 939
assign 1 0 942
assign 1 0 946
assign 1 240 949
linkedListIteratorGet 0 0 949
assign 1 240 952
hasNextGet 0 240 952
assign 1 240 954
nextGet 0 240 954
assign 1 241 955
klassNameGet 0 241 955
assign 1 241 956
extractKlassLib 1 241 956
klassNameSet 1 241 957
assign 1 242 958
methodNameGet 0 242 958
assign 1 242 959
extractMethod 1 242 959
methodNameSet 1 242 960
assign 1 243 961
klassNameGet 0 243 961
assign 1 243 962
getSourceFileName 1 243 962
fileNameSet 1 243 963
extractLine 0 245 965
assign 1 248 972
assign 1 249 973
new 0 249 973
assign 1 254 979
new 0 254 979
print 0 254 980
assign 1 260 989
new 0 260 989
assign 1 260 990
createInstance 2 260 990
assign 1 261 991
def 1 261 996
assign 1 263 997
sourceFileNameGet 0 263 997
return 1 263 998
return 1 266 1000
assign 1 271 1008
new 0 271 1008
assign 1 271 1009
split 1 271 1009
assign 1 273 1010
new 0 273 1010
assign 1 273 1011
get 1 273 1011
assign 1 273 1012
extractKlass 1 273 1012
return 1 273 1013
assign 1 278 1019
extractKlassInner 1 278 1019
return 1 278 1020
return 1 282 1025
assign 1 286 1053
undef 1 286 1058
assign 1 0 1059
assign 1 286 1062
new 0 286 1062
assign 1 286 1063
begins 1 286 1063
assign 1 286 1064
not 0 286 1069
assign 1 0 1070
assign 1 0 1073
return 1 287 1077
assign 1 289 1079
new 0 289 1079
assign 1 289 1080
substring 1 289 1080
assign 1 289 1081
new 0 289 1081
assign 1 289 1082
split 1 289 1082
assign 1 290 1083
sizeGet 0 290 1083
assign 1 290 1084
new 0 290 1084
assign 1 290 1085
subtract 1 290 1085
assign 1 291 1086
get 1 291 1086
assign 1 292 1087
new 0 292 1087
assign 1 293 1088
new 0 293 1088
assign 1 294 1089
new 0 294 1089
assign 1 294 1092
lesser 1 294 1097
assign 1 295 1098
get 1 295 1098
assign 1 295 1099
new 1 295 1099
assign 1 297 1100
add 1 297 1100
assign 1 297 1101
substring 2 297 1101
addValue 1 297 1102
assign 1 298 1103
new 0 298 1103
assign 1 298 1104
add 1 298 1104
assign 1 298 1105
lesser 1 298 1110
assign 1 298 1111
new 0 298 1111
addValue 1 298 1112
addValue 1 299 1114
incrementValue 0 294 1115
return 1 302 1121
assign 1 306 1144
undef 1 306 1149
assign 1 0 1150
assign 1 306 1153
new 0 306 1153
assign 1 306 1154
begins 1 306 1154
assign 1 306 1155
not 0 306 1160
assign 1 0 1161
assign 1 0 1164
return 1 307 1168
assign 1 309 1170
new 0 309 1170
assign 1 309 1171
substring 1 309 1171
assign 1 309 1172
new 0 309 1172
assign 1 309 1173
split 1 309 1173
assign 1 310 1174
sizeGet 0 310 1174
assign 1 310 1175
new 0 310 1175
assign 1 310 1176
subtract 1 310 1176
assign 1 311 1177
new 0 311 1177
assign 1 312 1178
new 0 312 1178
assign 1 312 1181
lesser 1 312 1186
assign 1 313 1187
get 1 313 1187
addValue 1 313 1188
assign 1 314 1189
new 0 314 1189
assign 1 314 1190
add 1 314 1190
assign 1 314 1191
lesser 1 314 1196
assign 1 314 1197
new 0 314 1197
addValue 1 314 1198
incrementValue 0 312 1200
return 1 317 1206
translateEmittedException 0 323 1210
assign 1 325 1212
new 0 325 1212
print 0 325 1213
return 1 328 1215
translateEmittedException 0 332 1225
assign 1 333 1226
new 0 333 1226
assign 1 334 1227
framesGet 0 334 1227
assign 1 335 1228
def 1 335 1233
assign 1 336 1234
new 0 336 1234
assign 1 336 1235
add 1 336 1235
assign 1 337 1236
linkedListIteratorGet 0 0 1236
assign 1 337 1239
hasNextGet 0 337 1239
assign 1 337 1241
nextGet 0 337 1241
assign 1 338 1242
add 1 338 1242
return 1 341 1249
return 1 345 1252
assign 1 349 1256
undef 1 349 1261
assign 1 350 1262
new 0 350 1262
addValue 1 352 1264
assign 1 356 1269
new 4 356 1269
addFrame 1 356 1270
return 1 0 1274
assign 1 0 1277
assign 1 0 1281
return 1 0 1285
assign 1 0 1288
return 1 0 1292
assign 1 0 1295
return 1 0 1299
assign 1 0 1302
return 1 0 1306
assign 1 0 1309
return 1 0 1313
assign 1 0 1316
assign 1 0 1320
return 1 0 1324
assign 1 0 1327
return 1 0 1331
assign 1 0 1334
return 1 0 1338
assign 1 0 1341
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case 98234746: return bem_methodNameGet_0();
case 1641166290: return bem_translatedGet_0();
case -2116220804: return bem_new_0();
case -1436664914: return bem_print_0();
case -373295708: return bem_serializeContents_0();
case -416881840: return bem_sourceFileNameGet_0();
case -1077712420: return bem_vvGet_0();
case -1021276807: return bem_copy_0();
case -2006878754: return bem_create_0();
case -268338848: return bem_fieldIteratorGet_0();
case 1834445691: return bem_translateEmittedExceptionInner_0();
case 810650310: return bem_serializeToString_0();
case 1319500268: return bem_langGet_0();
case -2142748920: return bem_fileNameGet_0();
case -453378259: return bem_deserializeClassNameGet_0();
case -180143514: return bem_serializationIteratorGet_0();
case 1594875689: return bem_lineNumberGet_0();
case -1924106580: return bem_getFrameText_0();
case -1274969629: return bem_iteratorGet_0();
case -1637921: return bem_descriptionGet_0();
case -1250167905: return bem_framesGet_0();
case 1747145604: return bem_framesTextGet_0();
case -1682959242: return bem_many_0();
case -1329156032: return bem_echo_0();
case -605259456: return bem_toAny_0();
case -681406586: return bem_hashGet_0();
case -229716565: return bem_klassNameGet_0();
case 1737839713: return bem_toString_0();
case -1860146814: return bem_tagGet_0();
case -1250381101: return bem_classNameGet_0();
case -543473802: return bem_translateEmittedException_0();
case 1000454010: return bem_emitLangGet_0();
case -454647513: return bem_once_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case -578909492: return bem_klassNameSet_1(bevd_0);
case -1196486530: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 160077693: return bem_framesTextSet_1(bevd_0);
case -461593490: return bem_copyTo_1(bevd_0);
case 876860011: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 742399622: return bem_descriptionSet_1(bevd_0);
case 98957888: return bem_otherType_1(bevd_0);
case -1480218954: return bem_def_1(bevd_0);
case 1468796062: return bem_sameType_1(bevd_0);
case 1096308396: return bem_notEquals_1(bevd_0);
case -417583753: return bem_defined_1(bevd_0);
case 312688457: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -888403607: return bem_sameObject_1(bevd_0);
case -1688597634: return bem_sameClass_1(bevd_0);
case -254032128: return bem_emitLangSet_1(bevd_0);
case -34168266: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1728638213: return bem_otherClass_1(bevd_0);
case -1120672002: return bem_translatedSet_1(bevd_0);
case -779433144: return bem_undef_1(bevd_0);
case 1922760127: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1987098611: return bem_langSet_1(bevd_0);
case 34267686: return bem_new_1(bevd_0);
case 434478091: return bem_equals_1(bevd_0);
case -2081311194: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -856899509: return bem_methodNameSet_1(bevd_0);
case -1765283742: return bem_fileNameSet_1(bevd_0);
case 837740412: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -38640130: return bem_framesSet_1(bevd_0);
case -1155148606: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -935094060: return bem_undefined_1(bevd_0);
case 155022030: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1387433761: return bem_vvSet_1(bevd_0);
case 14292419: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -661802787: return bem_lineNumberSet_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 811659277: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -140724102: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 565033879: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1767747865: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2047096971: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 656540134: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1888103: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callCase) {
case -1252258811: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callCase, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
}
