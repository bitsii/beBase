package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_9, 28));
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x67,0x65,0x74,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_11 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_11, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_12 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_12, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_13 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_9_SystemException_bels_14 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_14, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_15 = {0x46,0x72,0x61,0x6D,0x65,0x20,0x6C,0x69,0x6E,0x65,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_15, 14));
private static byte[] bece_BEC_2_6_9_SystemException_bels_16 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_16, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_17 = {0x73,0x74,0x61,0x72,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_17, 9));
private static byte[] bece_BEC_2_6_9_SystemException_bels_18 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_18, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_9 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_19 = {0x65,0x6E,0x64,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_19, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_20 = {0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_20, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_13 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_21 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_21, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_22 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_17 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_23 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_23, 5));
private static byte[] bece_BEC_2_6_9_SystemException_bels_24 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_24, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_25 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_25, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_26 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_26, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_22 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_27 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x65,0x6E,0x64,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_27, 13));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_28 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_25 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_29 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_27 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_30 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_30, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_29 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_30 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_31 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_31 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_32 = {0x63,0x61,0x6C,0x6C,0x50,0x61,0x72,0x74,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_32, 10));
private static byte[] bece_BEC_2_6_9_SystemException_bels_33 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_33, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_34 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_34 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_35 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_35 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6D,0x74,0x64,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_35, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_36 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_36, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_37 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_37, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_38 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_38, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_41 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_42 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_39 = {0x70,0x72,0x65,0x20,0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_39, 21));
private static byte[] bece_BEC_2_6_9_SystemException_bels_40 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_40, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_41 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_41, 17));
private static byte[] bece_BEC_2_6_9_SystemException_bels_42 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_42, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_43 = {0x61,0x64,0x64,0x69,0x6E,0x67,0x20,0x66,0x72,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_43, 12));
private static byte[] bece_BEC_2_6_9_SystemException_bels_44 = {0x6E,0x6F,0x20,0x65,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_44, 6));
private static byte[] bece_BEC_2_6_9_SystemException_bels_45 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_46 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_46, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_47 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_48 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_48, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_49 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_50 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_50, 4));
private static byte[] bece_BEC_2_6_9_SystemException_bels_51 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_52 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_53 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_52 = {0x3A};
private static byte[] bece_BEC_2_6_9_SystemException_bels_53 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_53, 4));
private static byte[] bece_BEC_2_6_9_SystemException_bels_54 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_55 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_56 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_55 = {0x5F};
private static byte[] bece_BEC_2_6_9_SystemException_bels_56 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_56, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_57 = {0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_57, 1));
public static BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_vv = be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_0));
if (bevp_description == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_1));
bevt_1_tmpany_phold = bevl_toRet.bemd_1(-1152576261, bevt_2_tmpany_phold);
bevl_toRet = bevt_1_tmpany_phold.bemd_1(-1152576261, bevp_description);
} /* Line: 56 */
if (bevp_fileName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_2));
bevt_4_tmpany_phold = bevl_toRet.bemd_1(-1152576261, bevt_5_tmpany_phold);
bevl_toRet = bevt_4_tmpany_phold.bemd_1(-1152576261, bevp_fileName);
} /* Line: 59 */
if (bevp_lineNumber == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_3));
bevt_7_tmpany_phold = bevl_toRet.bemd_1(-1152576261, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_lineNumber.bemd_0(-1894090923);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(-1152576261, bevt_9_tmpany_phold);
} /* Line: 62 */
if (bevp_lang == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 64 */ {
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_11_tmpany_phold = bevl_toRet.bemd_1(-1152576261, bevt_12_tmpany_phold);
bevl_toRet = bevt_11_tmpany_phold.bemd_1(-1152576261, bevp_lang);
} /* Line: 65 */
if (bevp_emitLang == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 67 */ {
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_5));
bevt_14_tmpany_phold = bevl_toRet.bemd_1(-1152576261, bevt_15_tmpany_phold);
bevl_toRet = bevt_14_tmpany_phold.bemd_1(-1152576261, bevp_emitLang);
} /* Line: 68 */
if (bevp_methodName == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 70 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_6));
bevt_17_tmpany_phold = bevl_toRet.bemd_1(-1152576261, bevt_18_tmpany_phold);
bevl_toRet = bevt_17_tmpany_phold.bemd_1(-1152576261, bevp_methodName);
} /* Line: 71 */
if (bevp_klassName == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_7));
bevt_20_tmpany_phold = bevl_toRet.bemd_1(-1152576261, bevt_21_tmpany_phold);
bevl_toRet = bevt_20_tmpany_phold.bemd_1(-1152576261, bevp_klassName);
} /* Line: 74 */
if (bevp_framesText == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_8));
bevt_23_tmpany_phold = bevl_toRet.bemd_1(-1152576261, bevt_24_tmpany_phold);
bevl_toRet = bevt_23_tmpany_phold.bemd_1(-1152576261, bevp_framesText);
} /* Line: 77 */
if (bevp_frames == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevt_26_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(-1152576261, bevt_26_tmpany_phold);
} /* Line: 80 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_9_SystemException bem_translateEmittedException_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
try  /* Line: 86 */ {
bem_translateEmittedExceptionInner_0();
} /* Line: 87 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_1_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_0;
bevt_1_tmpany_phold.bem_print_0();
if (bevl_e == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 90 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_10));
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = bevl_e.bemd_2(-1865862746, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 90 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 90 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 90 */
 else  /* Line: 90 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 90 */ {
bevt_6_tmpany_phold = bevl_e.bemd_0(1520843468);
bevt_6_tmpany_phold.bemd_0(899896295);
} /* Line: 91 */
} /* Line: 90 */
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_translateEmittedExceptionInner_0() throws Throwable {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpany_phold = null;
BEC_2_4_6_TextString bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_6_TextString bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_6_TextString bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_134_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_4_6_TextString bevt_142_tmpany_phold = null;
BEC_2_4_6_TextString bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_4_6_TextString bevt_145_tmpany_phold = null;
if (bevp_translated == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 98 */ {
if (bevp_translated.bevi_bool) /* Line: 98 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 98 */ {
return this;
} /* Line: 99 */
if (bevp_vv == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 101 */ {
bevp_vv = be.BECS_Runtime.boolFalse;
} /* Line: 102 */
bevp_translated = be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 105 */ {
if (bevp_lang == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 105 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 105 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 105 */
 else  /* Line: 105 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 105 */ {
bevt_17_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_1;
bevt_16_tmpany_phold = bevp_lang.bem_equals_1(bevt_17_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 105 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 105 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_2;
bevt_18_tmpany_phold = bevp_lang.bem_equals_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 105 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 105 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 105 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 105 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 105 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 105 */
 else  /* Line: 105 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 105 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_13));
bevl_ltok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_20_tmpany_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_22_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_3;
bevt_21_tmpany_phold = bevp_lang.bem_equals_1(bevt_22_tmpany_phold);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevl_isCs = be.BECS_Runtime.boolTrue;
} /* Line: 109 */
 else  /* Line: 110 */ {
bevl_isCs = be.BECS_Runtime.boolFalse;
} /* Line: 111 */
bevt_0_tmpany_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 113 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 113 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
if (bevp_vv.bevi_bool) /* Line: 114 */ {
bevt_25_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_4;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevl_line);
bevt_24_tmpany_phold.bem_print_0();
} /* Line: 115 */
bevt_26_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_5;
bevl_start = bevl_line.bem_find_1(bevt_26_tmpany_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_29_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_6;
if (bevl_start.bevi_int >= bevt_29_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 120 */ {
if (bevp_vv.bevi_bool) /* Line: 121 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_7;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevl_start);
bevt_30_tmpany_phold.bem_print_0();
} /* Line: 122 */
bevt_32_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_8;
bevt_34_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_9;
bevt_33_tmpany_phold = bevl_start.bem_add_1(bevt_34_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
if (bevl_end == null) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 125 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 125 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 125 */
 else  /* Line: 125 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 125 */ {
if (bevp_vv.bevi_bool) /* Line: 126 */ {
bevt_38_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_10;
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevl_end);
bevt_37_tmpany_phold.bem_print_0();
} /* Line: 127 */
bevt_40_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_11;
bevt_39_tmpany_phold = bevl_start.bem_add_1(bevt_40_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_39_tmpany_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 131 */ {
bevt_41_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_12;
bevl_start = bevl_line.bem_find_2(bevt_41_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 133 */ {
bevt_44_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_13;
bevt_43_tmpany_phold = bevl_start.bem_add_1(bevt_44_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_43_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_14;
bevt_45_tmpany_phold = bevl_inPart.bem_ends_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_48_tmpany_phold = bevl_inPart.bem_sizeGet_0();
bevt_49_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_15;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_subtract_1(bevt_49_tmpany_phold);
bevl_inPart.bem_sizeSet_1(bevt_47_tmpany_phold);
} /* Line: 137 */
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_22));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_50_tmpany_phold);
if (bevl_pdelim == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevt_52_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_16;
bevl_efile = bevl_inPart.bem_substring_2(bevt_52_tmpany_phold, bevl_pdelim);
bevt_54_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_17;
bevt_53_tmpany_phold = bevl_pdelim.bem_add_1(bevt_54_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_53_tmpany_phold);
bevt_56_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_18;
bevt_55_tmpany_phold = bevl_iv.bem_begins_1(bevt_56_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 145 */ {
bevt_57_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_57_tmpany_phold);
} /* Line: 146 */
bevt_58_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 149 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 150 */
} /* Line: 149 */
} /* Line: 141 */
} /* Line: 133 */
 else  /* Line: 154 */ {
bevt_59_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_19;
bevl_start = bevl_line.bem_find_2(bevt_59_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 156 */ {
if (bevp_vv.bevi_bool) /* Line: 157 */ {
bevt_61_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_20;
bevt_61_tmpany_phold.bem_print_0();
} /* Line: 158 */
bevt_62_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_21;
bevt_64_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_22;
bevt_63_tmpany_phold = bevl_start.bem_add_1(bevt_64_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
if (bevl_end == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 162 */ {
if (bevp_vv.bevi_bool) /* Line: 163 */ {
bevt_66_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_23;
bevt_66_tmpany_phold.bem_print_0();
} /* Line: 164 */
bevt_68_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_24;
bevt_67_tmpany_phold = bevl_start.bem_add_1(bevt_68_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_67_tmpany_phold, bevl_end);
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_28));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_69_tmpany_phold);
if (bevl_pdelim == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_71_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_25;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_71_tmpany_phold, bevl_pdelim);
bevt_72_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_29));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_72_tmpany_phold);
if (bevl_pdelim == null) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevt_74_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_26;
bevl_efile = bevl_inPart.bem_substring_2(bevt_74_tmpany_phold, bevl_pdelim);
} /* Line: 174 */
bevt_76_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_27;
bevt_75_tmpany_phold = bevl_pdelim.bem_add_1(bevt_76_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_77_tmpany_phold.bevi_bool) /* Line: 178 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 179 */
} /* Line: 178 */
} /* Line: 169 */
} /* Line: 162 */
} /* Line: 156 */
} /* Line: 131 */
 else  /* Line: 185 */ {
bevt_78_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_28;
bevt_80_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_29;
bevt_79_tmpany_phold = bevl_start.bem_add_1(bevt_80_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
if (bevl_end == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 187 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 187 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 187 */
 else  /* Line: 187 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 187 */ {
bevt_84_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_30;
bevt_83_tmpany_phold = bevl_start.bem_add_1(bevt_84_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_83_tmpany_phold, bevl_end);
} /* Line: 188 */
 else  /* Line: 189 */ {
bevt_86_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_31;
bevt_85_tmpany_phold = bevl_start.bem_add_1(bevt_86_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_85_tmpany_phold);
} /* Line: 190 */
} /* Line: 187 */
if (bevl_callPart == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 193 */ {
if (bevl_isCs.bevi_bool) /* Line: 194 */ {
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_31));
bevl_parts = bevl_callPart.bem_split_1(bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_90_tmpany_phold);
bevl_klass = bem_extractKlass_1(bevl_klass);
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_92_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_91_tmpany_phold = bem_getSourceFileName_1(bevt_92_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_91_tmpany_phold);
bem_addFrame_1(bevl_fr);
} /* Line: 207 */
 else  /* Line: 208 */ {
if (bevp_vv.bevi_bool) /* Line: 210 */ {
bevt_95_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_32;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevl_callPart);
bevt_96_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_33;
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bem_add_1(bevt_96_tmpany_phold);
bevt_93_tmpany_phold.bem_print_0();
} /* Line: 211 */
bevt_97_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_34));
bevl_parts = bevl_callPart.bem_split_1(bevt_97_tmpany_phold);
bevt_99_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_100_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_34;
if (bevt_99_tmpany_phold.bevi_int > bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevt_102_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_103_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_35;
if (bevt_102_tmpany_phold.bevi_int > bevt_103_tmpany_phold.bevi_int) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevt_104_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_105_tmpany_phold);
} /* Line: 217 */
 else  /* Line: 218 */ {
bevt_106_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_107_tmpany_phold);
} /* Line: 220 */
bevl_mtd = bem_extractMethod_1(bevl_mtd);
if (bevp_vv.bevi_bool) /* Line: 223 */ {
bevt_110_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_36;
bevt_109_tmpany_phold = bevt_110_tmpany_phold.bem_add_1(bevl_mtd);
bevt_111_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_37;
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bem_add_1(bevt_111_tmpany_phold);
bevt_108_tmpany_phold.bem_print_0();
} /* Line: 224 */
bevt_112_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_38;
bevl_start = bevl_klass.bem_find_1(bevt_112_tmpany_phold);
if (bevl_start == null) {
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_113_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevt_115_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_39;
if (bevl_start.bevi_int > bevt_115_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
 else  /* Line: 227 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 227 */ {
bevt_116_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_40;
bevt_118_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_41;
bevt_117_tmpany_phold = bevl_start.bem_add_1(bevt_118_tmpany_phold);
bevl_end = bevl_klass.bem_find_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
if (bevl_end == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 229 */ {
bevt_121_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_42;
if (bevl_end.bevi_int > bevt_121_tmpany_phold.bevi_int) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 229 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 229 */
 else  /* Line: 229 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 229 */ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
if (bevp_vv.bevi_bool) /* Line: 234 */ {
bevt_124_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_43;
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bem_add_1(bevl_klass);
bevt_125_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_44;
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bem_add_1(bevt_125_tmpany_phold);
bevt_122_tmpany_phold.bem_print_0();
} /* Line: 235 */
bevl_klass = bem_extractKlass_1(bevl_klass);
if (bevp_vv.bevi_bool) /* Line: 238 */ {
bevt_128_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_45;
bevt_127_tmpany_phold = bevt_128_tmpany_phold.bem_add_1(bevl_klass);
bevt_129_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_46;
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bem_add_1(bevt_129_tmpany_phold);
bevt_126_tmpany_phold.bem_print_0();
} /* Line: 239 */
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_131_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_130_tmpany_phold = bem_getSourceFileName_1(bevt_131_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_130_tmpany_phold);
if (bevp_vv.bevi_bool) /* Line: 243 */ {
bevt_132_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_47;
bevt_132_tmpany_phold.bem_print_0();
} /* Line: 244 */
bem_addFrame_1(bevl_fr);
} /* Line: 246 */
 else  /* Line: 247 */ {
if (bevp_vv.bevi_bool) /* Line: 248 */ {
bevt_133_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_48;
bevt_133_tmpany_phold.bem_print_0();
} /* Line: 249 */
} /* Line: 248 */
} /* Line: 229 */
} /* Line: 227 */
} /* Line: 214 */
} /* Line: 194 */
} /* Line: 193 */
} /* Line: 120 */
 else  /* Line: 113 */ {
break;
} /* Line: 113 */
} /* Line: 113 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_45));
bevp_framesText = null;
} /* Line: 260 */
 else  /* Line: 105 */ {
if (bevp_frames == null) {
bevt_134_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_134_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_134_tmpany_phold.bevi_bool) /* Line: 261 */ {
if (bevp_lang == null) {
bevt_135_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 261 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 261 */
 else  /* Line: 261 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 261 */ {
bevt_137_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_49;
bevt_136_tmpany_phold = bevp_lang.bem_equals_1(bevt_137_tmpany_phold);
if (bevt_136_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 261 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 261 */
 else  /* Line: 261 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 261 */ {
bevt_1_tmpany_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 262 */ {
bevt_138_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_138_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpany_loop.bem_nextGet_0();
bevt_140_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_139_tmpany_phold = bem_extractKlassLib_1(bevt_140_tmpany_phold);
bevl_fr.bem_klassNameSet_1(bevt_139_tmpany_phold);
bevt_142_tmpany_phold = bevl_fr.bem_methodNameGet_0();
bevt_141_tmpany_phold = bem_extractMethod_1(bevt_142_tmpany_phold);
bevl_fr.bem_methodNameSet_1(bevt_141_tmpany_phold);
bevt_144_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_143_tmpany_phold = bem_getSourceFileName_1(bevt_144_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_143_tmpany_phold);
 /* Line: 266 */ {
bevl_fr.bem_extractLine_0();
} /* Line: 267 */
} /* Line: 266 */
 else  /* Line: 262 */ {
break;
} /* Line: 262 */
} /* Line: 262 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_47));
} /* Line: 271 */
 else  /* Line: 272 */ {
} /* Line: 272 */
} /* Line: 105 */
if (bevp_vv.bevi_bool) /* Line: 275 */ {
bevt_145_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_50;
bevt_145_tmpany_phold.bem_print_0();
} /* Line: 276 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_i = bem_createInstance_2(beva_klassName, bevt_0_tmpany_phold);
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 283 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(1523861211);
return (BEC_2_4_6_TextString) bevt_2_tmpany_phold;
} /* Line: 285 */
return null;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_49));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_2_tmpany_phold = bevl_parts.bem_get_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpany_phold );
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 299 */ {
bevt_0_tmpany_phold = bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpany_phold;
} /* Line: 300 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 301 */
return beva_klass;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 308 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 308 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_51;
bevt_3_tmpany_phold = beva_klass.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 308 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 308 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 308 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 308 */ {
return beva_klass;
} /* Line: 309 */
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_5_tmpany_phold = beva_klass.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_51));
bevl_kparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_52;
bevl_kps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 316 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_11_tmpany_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpany_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpany_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_53;
bevt_15_tmpany_phold = bevl_i.bem_add_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_52));
bevl_bec.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 320 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 316 */
 else  /* Line: 316 */ {
break;
} /* Line: 316 */
} /* Line: 316 */
return bevl_bec;
} /*method end*/
public BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
if (beva_mtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 328 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_54;
bevt_3_tmpany_phold = beva_mtd.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 328 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 328 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 328 */ {
return beva_mtd;
} /* Line: 329 */
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(4));
bevt_5_tmpany_phold = beva_mtd.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_54));
bevl_mparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_55;
bevl_mps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_bem = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 334 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_11_tmpany_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_56;
bevt_13_tmpany_phold = bevl_i.bem_add_1(bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 336 */ {
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_55));
bevl_bem.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 336 */
bevl_i.bevi_int++;
} /* Line: 334 */
 else  /* Line: 334 */ {
break;
} /* Line: 334 */
} /* Line: 334 */
return bevl_bem;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bem_translateEmittedException_0();
if (bevp_vv.bevi_bool) /* Line: 346 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_57;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 347 */
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_58;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 359 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 359 */ {
bevl_ft = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 360 */
 else  /* Line: 359 */ {
break;
} /* Line: 359 */
} /* Line: 359 */
} /* Line: 359 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_frames == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 371 */ {
bevp_frames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 372 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_methodNameGetDirect_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_klassNameGetDirect_0() throws Throwable {
return bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_descriptionGetDirect_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_descriptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fileNameGetDirect_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_lineNumberGetDirect_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_lineNumberSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public final BEC_2_4_6_TextString bem_langGetDirect_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_langSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public final BEC_2_4_6_TextString bem_emitLangGetDirect_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_emitLangSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_framesGetDirect_0() throws Throwable {
return bevp_frames;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_framesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public final BEC_2_4_6_TextString bem_framesTextGetDirect_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_framesTextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_translatedGetDirect_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_translatedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGet_0() throws Throwable {
return bevp_vv;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_vvGetDirect_0() throws Throwable {
return bevp_vv;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_vvSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {44, 47, 51, 54, 55, 55, 56, 56, 56, 58, 58, 59, 59, 59, 61, 61, 62, 62, 62, 62, 64, 64, 65, 65, 65, 67, 67, 68, 68, 68, 70, 70, 71, 71, 71, 73, 73, 74, 74, 74, 76, 76, 77, 77, 77, 79, 79, 80, 80, 82, 87, 89, 89, 90, 90, 90, 90, 90, 0, 0, 0, 91, 91, 98, 98, 0, 0, 0, 99, 101, 101, 102, 104, 105, 105, 105, 105, 0, 0, 0, 105, 105, 0, 105, 105, 0, 0, 0, 0, 0, 106, 106, 107, 108, 108, 109, 111, 113, 0, 113, 113, 115, 115, 115, 117, 117, 118, 119, 120, 120, 120, 120, 120, 0, 0, 0, 122, 122, 122, 124, 124, 124, 124, 125, 125, 125, 125, 0, 0, 0, 127, 127, 127, 129, 129, 129, 132, 132, 133, 133, 135, 135, 135, 136, 136, 137, 137, 137, 137, 140, 140, 141, 141, 142, 142, 144, 144, 144, 145, 145, 146, 146, 149, 150, 155, 155, 156, 156, 158, 158, 161, 161, 161, 161, 162, 162, 164, 164, 166, 166, 166, 168, 168, 169, 169, 170, 170, 172, 172, 173, 173, 174, 174, 176, 176, 176, 178, 179, 186, 186, 186, 186, 187, 187, 187, 187, 0, 0, 0, 188, 188, 188, 190, 190, 190, 193, 193, 196, 196, 198, 198, 199, 199, 201, 203, 205, 206, 206, 206, 207, 211, 211, 211, 211, 211, 213, 213, 214, 214, 214, 214, 215, 215, 215, 215, 216, 216, 217, 217, 219, 219, 220, 220, 222, 224, 224, 224, 224, 224, 226, 226, 227, 227, 227, 227, 227, 0, 0, 0, 228, 228, 228, 228, 229, 229, 229, 229, 229, 0, 0, 0, 233, 235, 235, 235, 235, 235, 237, 239, 239, 239, 239, 239, 241, 242, 242, 242, 244, 244, 246, 249, 249, 258, 259, 260, 261, 261, 261, 261, 0, 0, 0, 261, 261, 0, 0, 0, 262, 0, 262, 262, 263, 263, 263, 264, 264, 264, 265, 265, 265, 267, 270, 271, 276, 276, 282, 282, 283, 283, 285, 285, 288, 293, 293, 295, 295, 295, 295, 300, 300, 304, 308, 308, 0, 308, 308, 308, 308, 0, 0, 309, 311, 311, 311, 311, 312, 312, 312, 313, 314, 315, 316, 316, 316, 317, 317, 319, 319, 319, 320, 320, 320, 320, 320, 320, 321, 316, 324, 328, 328, 0, 328, 328, 328, 328, 0, 0, 329, 331, 331, 331, 331, 332, 332, 332, 333, 334, 334, 334, 335, 335, 336, 336, 336, 336, 336, 336, 334, 339, 345, 347, 347, 350, 354, 355, 356, 357, 357, 358, 358, 359, 0, 359, 359, 360, 363, 367, 371, 371, 372, 374, 378, 378, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {140, 141, 173, 174, 175, 180, 181, 182, 183, 185, 190, 191, 192, 193, 195, 200, 201, 202, 203, 204, 206, 211, 212, 213, 214, 216, 221, 222, 223, 224, 226, 231, 232, 233, 234, 236, 241, 242, 243, 244, 246, 251, 252, 253, 254, 256, 261, 262, 263, 265, 277, 281, 282, 283, 288, 289, 290, 291, 293, 296, 300, 303, 304, 472, 477, 479, 482, 486, 489, 491, 496, 497, 499, 500, 505, 506, 511, 512, 515, 519, 522, 523, 525, 528, 529, 531, 534, 538, 541, 545, 548, 549, 550, 551, 552, 554, 557, 559, 559, 562, 564, 566, 567, 568, 570, 571, 572, 573, 574, 579, 580, 581, 586, 587, 590, 594, 598, 599, 600, 602, 603, 604, 605, 606, 611, 612, 617, 618, 621, 625, 629, 630, 631, 633, 634, 635, 637, 638, 639, 644, 645, 646, 647, 648, 649, 651, 652, 653, 654, 656, 657, 658, 663, 664, 665, 666, 667, 668, 669, 670, 672, 673, 675, 677, 683, 684, 685, 690, 692, 693, 695, 696, 697, 698, 699, 704, 706, 707, 709, 710, 711, 712, 713, 714, 719, 720, 721, 722, 723, 724, 729, 730, 731, 733, 734, 735, 736, 738, 746, 747, 748, 749, 750, 755, 756, 761, 762, 765, 769, 772, 773, 774, 777, 778, 779, 782, 787, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 805, 806, 807, 808, 809, 811, 812, 813, 814, 815, 820, 821, 822, 823, 828, 829, 830, 831, 832, 835, 836, 837, 838, 840, 842, 843, 844, 845, 846, 848, 849, 850, 855, 856, 857, 862, 863, 866, 870, 873, 874, 875, 876, 877, 882, 883, 884, 889, 890, 893, 897, 900, 902, 903, 904, 905, 906, 908, 910, 911, 912, 913, 914, 916, 917, 918, 919, 921, 922, 924, 928, 929, 942, 943, 944, 947, 952, 953, 958, 959, 962, 966, 969, 970, 972, 975, 979, 982, 982, 985, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 998, 1005, 1006, 1012, 1013, 1022, 1023, 1024, 1029, 1030, 1031, 1033, 1041, 1042, 1043, 1044, 1045, 1046, 1052, 1053, 1058, 1086, 1091, 1092, 1095, 1096, 1097, 1102, 1103, 1106, 1110, 1112, 1113, 1114, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1125, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1143, 1144, 1145, 1147, 1148, 1154, 1177, 1182, 1183, 1186, 1187, 1188, 1193, 1194, 1197, 1201, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1214, 1219, 1220, 1221, 1222, 1223, 1224, 1229, 1230, 1231, 1233, 1239, 1243, 1245, 1246, 1248, 1258, 1259, 1260, 1261, 1266, 1267, 1268, 1269, 1269, 1272, 1274, 1275, 1282, 1285, 1289, 1294, 1295, 1297, 1302, 1303, 1307, 1310, 1313, 1317, 1321, 1324, 1328, 1332, 1335, 1338, 1342, 1346, 1349, 1352, 1356, 1360, 1363, 1366, 1370, 1374, 1377, 1380, 1384, 1388, 1391, 1394, 1398, 1402, 1405, 1409, 1413, 1416, 1419, 1423, 1427, 1430, 1433, 1437, 1441, 1444, 1447, 1451};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 44 140
new 0 44 140
assign 1 47 141
translateEmittedException 0 51 173
assign 1 54 174
new 0 54 174
assign 1 55 175
def 1 55 180
assign 1 56 181
new 0 56 181
assign 1 56 182
add 1 56 182
assign 1 56 183
add 1 56 183
assign 1 58 185
def 1 58 190
assign 1 59 191
new 0 59 191
assign 1 59 192
add 1 59 192
assign 1 59 193
add 1 59 193
assign 1 61 195
def 1 61 200
assign 1 62 201
new 0 62 201
assign 1 62 202
add 1 62 202
assign 1 62 203
toString 0 62 203
assign 1 62 204
add 1 62 204
assign 1 64 206
def 1 64 211
assign 1 65 212
new 0 65 212
assign 1 65 213
add 1 65 213
assign 1 65 214
add 1 65 214
assign 1 67 216
def 1 67 221
assign 1 68 222
new 0 68 222
assign 1 68 223
add 1 68 223
assign 1 68 224
add 1 68 224
assign 1 70 226
def 1 70 231
assign 1 71 232
new 0 71 232
assign 1 71 233
add 1 71 233
assign 1 71 234
add 1 71 234
assign 1 73 236
def 1 73 241
assign 1 74 242
new 0 74 242
assign 1 74 243
add 1 74 243
assign 1 74 244
add 1 74 244
assign 1 76 246
def 1 76 251
assign 1 77 252
new 0 77 252
assign 1 77 253
add 1 77 253
assign 1 77 254
add 1 77 254
assign 1 79 256
def 1 79 261
assign 1 80 262
getFrameText 0 80 262
assign 1 80 263
add 1 80 263
return 1 82 265
translateEmittedExceptionInner 0 87 277
assign 1 89 281
new 0 89 281
print 0 89 282
assign 1 90 283
def 1 90 288
assign 1 90 289
new 0 90 289
assign 1 90 290
new 0 90 290
assign 1 90 291
can 2 90 291
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 91 303
descriptionGet 0 91 303
print 0 91 304
assign 1 98 472
def 1 98 477
assign 1 0 479
assign 1 0 482
assign 1 0 486
return 1 99 489
assign 1 101 491
undef 1 101 496
assign 1 102 497
new 0 102 497
assign 1 104 499
new 0 104 499
assign 1 105 500
def 1 105 505
assign 1 105 506
def 1 105 511
assign 1 0 512
assign 1 0 515
assign 1 0 519
assign 1 105 522
new 0 105 522
assign 1 105 523
equals 1 105 523
assign 1 0 525
assign 1 105 528
new 0 105 528
assign 1 105 529
equals 1 105 529
assign 1 0 531
assign 1 0 534
assign 1 0 538
assign 1 0 541
assign 1 0 545
assign 1 106 548
new 0 106 548
assign 1 106 549
new 1 106 549
assign 1 107 550
tokenize 1 107 550
assign 1 108 551
new 0 108 551
assign 1 108 552
equals 1 108 552
assign 1 109 554
new 0 109 554
assign 1 111 557
new 0 111 557
assign 1 113 559
linkedListIteratorGet 0 0 559
assign 1 113 562
hasNextGet 0 113 562
assign 1 113 564
nextGet 0 113 564
assign 1 115 566
new 0 115 566
assign 1 115 567
add 1 115 567
print 0 115 568
assign 1 117 570
new 0 117 570
assign 1 117 571
find 1 117 571
assign 1 118 572
assign 1 119 573
assign 1 120 574
def 1 120 579
assign 1 120 580
new 0 120 580
assign 1 120 581
greaterEquals 1 120 586
assign 1 0 587
assign 1 0 590
assign 1 0 594
assign 1 122 598
new 0 122 598
assign 1 122 599
add 1 122 599
print 0 122 600
assign 1 124 602
new 0 124 602
assign 1 124 603
new 0 124 603
assign 1 124 604
add 1 124 604
assign 1 124 605
find 2 124 605
assign 1 125 606
def 1 125 611
assign 1 125 612
greater 1 125 617
assign 1 0 618
assign 1 0 621
assign 1 0 625
assign 1 127 629
new 0 127 629
assign 1 127 630
add 1 127 630
print 0 127 631
assign 1 129 633
new 0 129 633
assign 1 129 634
add 1 129 634
assign 1 129 635
substring 2 129 635
assign 1 132 637
new 0 132 637
assign 1 132 638
find 2 132 638
assign 1 133 639
def 1 133 644
assign 1 135 645
new 0 135 645
assign 1 135 646
add 1 135 646
assign 1 135 647
substring 1 135 647
assign 1 136 648
new 0 136 648
assign 1 136 649
ends 1 136 649
assign 1 137 651
sizeGet 0 137 651
assign 1 137 652
new 0 137 652
assign 1 137 653
subtract 1 137 653
sizeSet 1 137 654
assign 1 140 656
new 0 140 656
assign 1 140 657
rfind 1 140 657
assign 1 141 658
def 1 141 663
assign 1 142 664
new 0 142 664
assign 1 142 665
substring 2 142 665
assign 1 144 666
new 0 144 666
assign 1 144 667
add 1 144 667
assign 1 144 668
substring 1 144 668
assign 1 145 669
new 0 145 669
assign 1 145 670
begins 1 145 670
assign 1 146 672
new 0 146 672
assign 1 146 673
substring 1 146 673
assign 1 149 675
isInteger 0 149 675
assign 1 150 677
new 1 150 677
assign 1 155 683
new 0 155 683
assign 1 155 684
find 2 155 684
assign 1 156 685
def 1 156 690
assign 1 158 692
new 0 158 692
print 0 158 693
assign 1 161 695
new 0 161 695
assign 1 161 696
new 0 161 696
assign 1 161 697
add 1 161 697
assign 1 161 698
find 2 161 698
assign 1 162 699
def 1 162 704
assign 1 164 706
new 0 164 706
print 0 164 707
assign 1 166 709
new 0 166 709
assign 1 166 710
add 1 166 710
assign 1 166 711
substring 2 166 711
assign 1 168 712
new 0 168 712
assign 1 168 713
rfind 1 168 713
assign 1 169 714
def 1 169 719
assign 1 170 720
new 0 170 720
assign 1 170 721
substring 2 170 721
assign 1 172 722
new 0 172 722
assign 1 172 723
rfind 1 172 723
assign 1 173 724
def 1 173 729
assign 1 174 730
new 0 174 730
assign 1 174 731
substring 2 174 731
assign 1 176 733
new 0 176 733
assign 1 176 734
add 1 176 734
assign 1 176 735
substring 1 176 735
assign 1 178 736
isInteger 0 178 736
assign 1 179 738
new 1 179 738
assign 1 186 746
new 0 186 746
assign 1 186 747
new 0 186 747
assign 1 186 748
add 1 186 748
assign 1 186 749
find 2 186 749
assign 1 187 750
def 1 187 755
assign 1 187 756
greater 1 187 761
assign 1 0 762
assign 1 0 765
assign 1 0 769
assign 1 188 772
new 0 188 772
assign 1 188 773
add 1 188 773
assign 1 188 774
substring 2 188 774
assign 1 190 777
new 0 190 777
assign 1 190 778
add 1 190 778
assign 1 190 779
substring 1 190 779
assign 1 193 782
def 1 193 787
assign 1 196 789
new 0 196 789
assign 1 196 790
split 1 196 790
assign 1 198 791
new 0 198 791
assign 1 198 792
get 1 198 792
assign 1 199 793
new 0 199 793
assign 1 199 794
get 1 199 794
assign 1 201 795
extractKlass 1 201 795
assign 1 203 796
extractMethod 1 203 796
assign 1 205 797
new 4 205 797
assign 1 206 798
klassNameGet 0 206 798
assign 1 206 799
getSourceFileName 1 206 799
fileNameSet 1 206 800
addFrame 1 207 801
assign 1 211 805
new 0 211 805
assign 1 211 806
add 1 211 806
assign 1 211 807
new 0 211 807
assign 1 211 808
add 1 211 808
print 0 211 809
assign 1 213 811
new 0 213 811
assign 1 213 812
split 1 213 812
assign 1 214 813
sizeGet 0 214 813
assign 1 214 814
new 0 214 814
assign 1 214 815
greater 1 214 820
assign 1 215 821
sizeGet 0 215 821
assign 1 215 822
new 0 215 822
assign 1 215 823
greater 1 215 828
assign 1 216 829
new 0 216 829
assign 1 216 830
get 1 216 830
assign 1 217 831
new 0 217 831
assign 1 217 832
get 1 217 832
assign 1 219 835
new 0 219 835
assign 1 219 836
get 1 219 836
assign 1 220 837
new 0 220 837
assign 1 220 838
get 1 220 838
assign 1 222 840
extractMethod 1 222 840
assign 1 224 842
new 0 224 842
assign 1 224 843
add 1 224 843
assign 1 224 844
new 0 224 844
assign 1 224 845
add 1 224 845
print 0 224 846
assign 1 226 848
new 0 226 848
assign 1 226 849
find 1 226 849
assign 1 227 850
def 1 227 855
assign 1 227 856
new 0 227 856
assign 1 227 857
greater 1 227 862
assign 1 0 863
assign 1 0 866
assign 1 0 870
assign 1 228 873
new 0 228 873
assign 1 228 874
new 0 228 874
assign 1 228 875
add 1 228 875
assign 1 228 876
find 2 228 876
assign 1 229 877
def 1 229 882
assign 1 229 883
new 0 229 883
assign 1 229 884
greater 1 229 889
assign 1 0 890
assign 1 0 893
assign 1 0 897
assign 1 233 900
substring 1 233 900
assign 1 235 902
new 0 235 902
assign 1 235 903
add 1 235 903
assign 1 235 904
new 0 235 904
assign 1 235 905
add 1 235 905
print 0 235 906
assign 1 237 908
extractKlass 1 237 908
assign 1 239 910
new 0 239 910
assign 1 239 911
add 1 239 911
assign 1 239 912
new 0 239 912
assign 1 239 913
add 1 239 913
print 0 239 914
assign 1 241 916
new 4 241 916
assign 1 242 917
klassNameGet 0 242 917
assign 1 242 918
getSourceFileName 1 242 918
fileNameSet 1 242 919
assign 1 244 921
new 0 244 921
print 0 244 922
addFrame 1 246 924
assign 1 249 928
new 0 249 928
print 0 249 929
assign 1 258 942
assign 1 259 943
new 0 259 943
assign 1 260 944
assign 1 261 947
def 1 261 952
assign 1 261 953
def 1 261 958
assign 1 0 959
assign 1 0 962
assign 1 0 966
assign 1 261 969
new 0 261 969
assign 1 261 970
equals 1 261 970
assign 1 0 972
assign 1 0 975
assign 1 0 979
assign 1 262 982
linkedListIteratorGet 0 0 982
assign 1 262 985
hasNextGet 0 262 985
assign 1 262 987
nextGet 0 262 987
assign 1 263 988
klassNameGet 0 263 988
assign 1 263 989
extractKlassLib 1 263 989
klassNameSet 1 263 990
assign 1 264 991
methodNameGet 0 264 991
assign 1 264 992
extractMethod 1 264 992
methodNameSet 1 264 993
assign 1 265 994
klassNameGet 0 265 994
assign 1 265 995
getSourceFileName 1 265 995
fileNameSet 1 265 996
extractLine 0 267 998
assign 1 270 1005
assign 1 271 1006
new 0 271 1006
assign 1 276 1012
new 0 276 1012
print 0 276 1013
assign 1 282 1022
new 0 282 1022
assign 1 282 1023
createInstance 2 282 1023
assign 1 283 1024
def 1 283 1029
assign 1 285 1030
sourceFileNameGet 0 285 1030
return 1 285 1031
return 1 288 1033
assign 1 293 1041
new 0 293 1041
assign 1 293 1042
split 1 293 1042
assign 1 295 1043
new 0 295 1043
assign 1 295 1044
get 1 295 1044
assign 1 295 1045
extractKlass 1 295 1045
return 1 295 1046
assign 1 300 1052
extractKlassInner 1 300 1052
return 1 300 1053
return 1 304 1058
assign 1 308 1086
undef 1 308 1091
assign 1 0 1092
assign 1 308 1095
new 0 308 1095
assign 1 308 1096
begins 1 308 1096
assign 1 308 1097
not 0 308 1102
assign 1 0 1103
assign 1 0 1106
return 1 309 1110
assign 1 311 1112
new 0 311 1112
assign 1 311 1113
substring 1 311 1113
assign 1 311 1114
new 0 311 1114
assign 1 311 1115
split 1 311 1115
assign 1 312 1116
sizeGet 0 312 1116
assign 1 312 1117
new 0 312 1117
assign 1 312 1118
subtract 1 312 1118
assign 1 313 1119
get 1 313 1119
assign 1 314 1120
new 0 314 1120
assign 1 315 1121
new 0 315 1121
assign 1 316 1122
new 0 316 1122
assign 1 316 1125
lesser 1 316 1130
assign 1 317 1131
get 1 317 1131
assign 1 317 1132
new 1 317 1132
assign 1 319 1133
add 1 319 1133
assign 1 319 1134
substring 2 319 1134
addValue 1 319 1135
assign 1 320 1136
new 0 320 1136
assign 1 320 1137
add 1 320 1137
assign 1 320 1138
lesser 1 320 1143
assign 1 320 1144
new 0 320 1144
addValue 1 320 1145
addValue 1 321 1147
incrementValue 0 316 1148
return 1 324 1154
assign 1 328 1177
undef 1 328 1182
assign 1 0 1183
assign 1 328 1186
new 0 328 1186
assign 1 328 1187
begins 1 328 1187
assign 1 328 1188
not 0 328 1193
assign 1 0 1194
assign 1 0 1197
return 1 329 1201
assign 1 331 1203
new 0 331 1203
assign 1 331 1204
substring 1 331 1204
assign 1 331 1205
new 0 331 1205
assign 1 331 1206
split 1 331 1206
assign 1 332 1207
sizeGet 0 332 1207
assign 1 332 1208
new 0 332 1208
assign 1 332 1209
subtract 1 332 1209
assign 1 333 1210
new 0 333 1210
assign 1 334 1211
new 0 334 1211
assign 1 334 1214
lesser 1 334 1219
assign 1 335 1220
get 1 335 1220
addValue 1 335 1221
assign 1 336 1222
new 0 336 1222
assign 1 336 1223
add 1 336 1223
assign 1 336 1224
lesser 1 336 1229
assign 1 336 1230
new 0 336 1230
addValue 1 336 1231
incrementValue 0 334 1233
return 1 339 1239
translateEmittedException 0 345 1243
assign 1 347 1245
new 0 347 1245
print 0 347 1246
return 1 350 1248
translateEmittedException 0 354 1258
assign 1 355 1259
new 0 355 1259
assign 1 356 1260
framesGet 0 356 1260
assign 1 357 1261
def 1 357 1266
assign 1 358 1267
new 0 358 1267
assign 1 358 1268
add 1 358 1268
assign 1 359 1269
linkedListIteratorGet 0 0 1269
assign 1 359 1272
hasNextGet 0 359 1272
assign 1 359 1274
nextGet 0 359 1274
assign 1 360 1275
add 1 360 1275
return 1 363 1282
return 1 367 1285
assign 1 371 1289
undef 1 371 1294
assign 1 372 1295
new 0 372 1295
addValue 1 374 1297
assign 1 378 1302
new 4 378 1302
addFrame 1 378 1303
return 1 0 1307
return 1 0 1310
assign 1 0 1313
assign 1 0 1317
return 1 0 1321
assign 1 0 1324
assign 1 0 1328
return 1 0 1332
return 1 0 1335
assign 1 0 1338
assign 1 0 1342
return 1 0 1346
return 1 0 1349
assign 1 0 1352
assign 1 0 1356
return 1 0 1360
return 1 0 1363
assign 1 0 1366
assign 1 0 1370
return 1 0 1374
return 1 0 1377
assign 1 0 1380
assign 1 0 1384
return 1 0 1388
return 1 0 1391
assign 1 0 1394
assign 1 0 1398
return 1 0 1402
assign 1 0 1405
assign 1 0 1409
return 1 0 1413
return 1 0 1416
assign 1 0 1419
assign 1 0 1423
return 1 0 1427
return 1 0 1430
assign 1 0 1433
assign 1 0 1437
return 1 0 1441
return 1 0 1444
assign 1 0 1447
assign 1 0 1451
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 427473649: return bem_vvGet_0();
case -1794506213: return bem_many_0();
case -1396413274: return bem_classNameGet_0();
case 85669346: return bem_once_0();
case 398838525: return bem_framesGet_0();
case -808123537: return bem_hashGet_0();
case -526214247: return bem_translatedGetDirect_0();
case -295553573: return bem_new_0();
case -1160576197: return bem_framesTextGet_0();
case 1435781176: return bem_translateEmittedExceptionInner_0();
case 1598445817: return bem_klassNameGet_0();
case 1523861211: return bem_sourceFileNameGet_0();
case 889700256: return bem_langGet_0();
case -1460543860: return bem_fieldNamesGet_0();
case -407805688: return bem_framesGetDirect_0();
case 1560123499: return bem_getFrameText_0();
case 874569701: return bem_toAny_0();
case -1602615308: return bem_fieldIteratorGet_0();
case 1017730274: return bem_emitLangGetDirect_0();
case 1061933276: return bem_fileNameGet_0();
case -1025042119: return bem_vvGetDirect_0();
case -493975186: return bem_create_0();
case 1082531874: return bem_framesTextGetDirect_0();
case -1890398404: return bem_fileNameGetDirect_0();
case 1486645066: return bem_methodNameGetDirect_0();
case 1606613844: return bem_echo_0();
case 813271238: return bem_langGetDirect_0();
case -1706743432: return bem_iteratorGet_0();
case -2071452709: return bem_serializeContents_0();
case -1442653865: return bem_serializationIteratorGet_0();
case -1333837278: return bem_tagGet_0();
case 487466585: return bem_translateEmittedException_0();
case 899896295: return bem_print_0();
case -1894090923: return bem_toString_0();
case 1456278163: return bem_lineNumberGetDirect_0();
case -600575389: return bem_emitLangGet_0();
case 1520843468: return bem_descriptionGet_0();
case -1619643052: return bem_descriptionGetDirect_0();
case 1377047095: return bem_serializeToString_0();
case 1148142853: return bem_translatedGet_0();
case -41381797: return bem_copy_0();
case -802767414: return bem_deserializeClassNameGet_0();
case 1157144429: return bem_methodNameGet_0();
case -887830792: return bem_lineNumberGet_0();
case 1032253080: return bem_klassNameGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -708072209: return bem_framesSetDirect_1(bevd_0);
case 53407038: return bem_equals_1(bevd_0);
case 981175626: return bem_framesTextSet_1(bevd_0);
case 1719522067: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -390727554: return bem_langSet_1(bevd_0);
case 10942144: return bem_fileNameSet_1(bevd_0);
case -408707588: return bem_framesTextSetDirect_1(bevd_0);
case 1829433968: return bem_otherClass_1(bevd_0);
case 391192402: return bem_copyTo_1(bevd_0);
case -1794747952: return bem_translatedSetDirect_1(bevd_0);
case 251588443: return bem_otherType_1(bevd_0);
case -84206037: return bem_descriptionSetDirect_1(bevd_0);
case 150700345: return bem_descriptionSet_1(bevd_0);
case 826056150: return bem_emitLangSetDirect_1(bevd_0);
case 284248916: return bem_defined_1(bevd_0);
case -495420901: return bem_lineNumberSetDirect_1(bevd_0);
case -703379149: return bem_fileNameSetDirect_1(bevd_0);
case -666596898: return bem_new_1(bevd_0);
case 966131902: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -265277989: return bem_vvSet_1(bevd_0);
case 652115224: return bem_def_1(bevd_0);
case -467808258: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -920243169: return bem_sameObject_1(bevd_0);
case -319164445: return bem_undefined_1(bevd_0);
case 151472195: return bem_emitLangSet_1(bevd_0);
case -119471423: return bem_framesSet_1(bevd_0);
case 125631220: return bem_klassNameSet_1(bevd_0);
case 61859776: return bem_translatedSet_1(bevd_0);
case 1170147953: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1636353578: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -194482552: return bem_sameType_1(bevd_0);
case -698533498: return bem_methodNameSetDirect_1(bevd_0);
case 1729508827: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1989300932: return bem_sameClass_1(bevd_0);
case 888728042: return bem_lineNumberSet_1(bevd_0);
case 1328285078: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1179793891: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -794252146: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -902009530: return bem_methodNameSet_1(bevd_0);
case -1327704512: return bem_vvSetDirect_1(bevd_0);
case -445574019: return bem_langSetDirect_1(bevd_0);
case 1213137777: return bem_undef_1(bevd_0);
case 1475677279: return bem_klassNameSetDirect_1(bevd_0);
case 1028018501: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -2123613587: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1874085610: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1865862746: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736065910: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1057911785: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1158884482: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126000923: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1221539498: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1606841783: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
