package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildPtySyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildPtySyn() { }
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x74,0x79,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_0 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_2 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_3 = {0x6D,0x65,0x6D,0x54,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_4 = {0x61,0x6E,0x79};
public static BEC_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_inst;

public static BET_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_type;

public BEC_2_4_3_MathInt bevp_mpos;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_6_BuildVarSyn bevp_memSyn;
public BEC_2_5_4_LogicBool bevp_isSlot;
public BEC_2_5_6_BuildPtySyn bem_new_2(BEC_2_6_6_SystemObject beva_vnode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_5_3_BuildVar bevl_v = null;
bevl_v = (BEC_2_5_3_BuildVar) beva_vnode.bemd_0(1393852065);
bevp_name = bevl_v.bem_nameGet_0();
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_memSyn = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1(bevl_v);
bevp_isSlot = bevl_v.bem_isSlotGet_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_0_ta_ph.bem_newlineGet_0();
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_6_BuildPtySyn_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_nl);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildPtySyn_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevl_nl);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_name);
bevl_toRet = bevt_1_ta_ph.bem_add_1(bevl_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildPtySyn_bels_2));
bevt_9_ta_ph = bevl_toRet.bemd_1(2023644502, bevt_10_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_1(2023644502, bevl_nl);
bevt_11_ta_ph = bevp_origin.bem_toString_0();
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(2023644502, bevt_11_ta_ph);
bevl_toRet = bevt_7_ta_ph.bemd_1(2023644502, bevl_nl);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildPtySyn_bels_3));
bevt_12_ta_ph = bevl_toRet.bemd_1(2023644502, bevt_13_ta_ph);
bevl_toRet = bevt_12_ta_ph.bemd_1(2023644502, bevl_nl);
bevt_14_ta_ph = bevp_memSyn.bem_isTypedGet_0();
if (bevt_14_ta_ph.bevi_bool)/* Line: 527*/ {
bevt_17_ta_ph = bevp_memSyn.bem_namepathGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bem_toString_0();
bevt_15_ta_ph = bevl_toRet.bemd_1(2023644502, bevt_16_ta_ph);
bevl_toRet = bevt_15_ta_ph.bemd_1(2023644502, bevl_nl);
} /* Line: 528*/
 else /* Line: 529*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildPtySyn_bels_4));
bevt_18_ta_ph = bevl_toRet.bemd_1(2023644502, bevt_19_ta_ph);
bevl_toRet = bevt_18_ta_ph.bemd_1(2023644502, bevl_nl);
} /* Line: 530*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_mposGet_0() throws Throwable {
return bevp_mpos;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_mposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_memSynGet_0() throws Throwable {
return bevp_memSyn;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_memSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSlotGet_0() throws Throwable {
return bevp_isSlot;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_isSlotSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {511, 515, 516, 517, 518, 523, 523, 524, 524, 524, 524, 524, 524, 524, 525, 525, 525, 525, 525, 525, 526, 526, 526, 527, 528, 528, 528, 528, 530, 530, 530, 532, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 73, 74, 75, 76, 79, 80, 81, 83, 86, 89, 93, 96, 100, 103, 107, 110, 114, 117};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 511 23
heldGet 0 511 23
assign 1 515 24
nameGet 0 515 24
assign 1 516 25
assign 1 517 26
anyNew 1 517 26
assign 1 518 27
isSlotGet 0 518 27
assign 1 523 53
new 0 523 53
assign 1 523 54
newlineGet 0 523 54
assign 1 524 55
new 0 524 55
assign 1 524 56
add 1 524 56
assign 1 524 57
new 0 524 57
assign 1 524 58
add 1 524 58
assign 1 524 59
add 1 524 59
assign 1 524 60
add 1 524 60
assign 1 524 61
add 1 524 61
assign 1 525 62
new 0 525 62
assign 1 525 63
add 1 525 63
assign 1 525 64
add 1 525 64
assign 1 525 65
toString 0 525 65
assign 1 525 66
add 1 525 66
assign 1 525 67
add 1 525 67
assign 1 526 68
new 0 526 68
assign 1 526 69
add 1 526 69
assign 1 526 70
add 1 526 70
assign 1 527 71
isTypedGet 0 527 71
assign 1 528 73
namepathGet 0 528 73
assign 1 528 74
toString 0 528 74
assign 1 528 75
add 1 528 75
assign 1 528 76
add 1 528 76
assign 1 530 79
new 0 530 79
assign 1 530 80
add 1 530 80
assign 1 530 81
add 1 530 81
return 1 532 83
return 1 0 86
assign 1 0 89
return 1 0 93
assign 1 0 96
return 1 0 100
assign 1 0 103
return 1 0 107
assign 1 0 110
return 1 0 114
assign 1 0 117
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -639717510: return bem_create_0();
case -673274744: return bem_originGet_0();
case 1481144265: return bem_iteratorGet_0();
case 773827023: return bem_hashGet_0();
case 1458462738: return bem_new_0();
case -400875090: return bem_memSynGet_0();
case 188720761: return bem_isSlotGet_0();
case 1605403851: return bem_mposGet_0();
case 680360862: return bem_toString_0();
case 1185043471: return bem_nameGet_0();
case 257293855: return bem_copy_0();
case 1168727565: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -496366080: return bem_undef_1(bevd_0);
case -1122390917: return bem_mposSet_1(bevd_0);
case 1738126633: return bem_copyTo_1(bevd_0);
case 2122077404: return bem_originSet_1(bevd_0);
case 1792974198: return bem_memSynSet_1(bevd_0);
case 485019580: return bem_notEquals_1(bevd_0);
case -1482473136: return bem_isSlotSet_1(bevd_0);
case 1995371181: return bem_equals_1(bevd_0);
case 1309341491: return bem_nameSet_1(bevd_0);
case -1831694135: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1960185659: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2002366118: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 147231706: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -906550586: return bem_new_2(bevd_0, bevd_1);
case -208746106: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildPtySyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildPtySyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildPtySyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst = (BEC_2_5_6_BuildPtySyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_type;
}
}
