package be;
/* IO:File: source/base/EncodeHex.be */
public class BEC_2_6_3_EncodeHex extends BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeHex() { }
private static byte[] becc_BEC_2_6_3_EncodeHex_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x65,0x78};
private static byte[] becc_BEC_2_6_3_EncodeHex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x48,0x65,0x78,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_3_EncodeHex_bels_0 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x68,0x65,0x78,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20};
public static BEC_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_inst;

public static BET_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_type;

public BEC_2_6_3_EncodeHex bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl_ac = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_cur = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = bevl_ssz.bem_multiply_1(bevt_2_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_ta_ph);
bevl_pos = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 24*/ {
if (bevl_pos.bevi_int < bevl_ssz.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 24*/ {
beva_str.bem_getCode_2(bevl_pos, bevl_ac);
bevt_4_ta_ph = bevl_ac.bem_toHexString_1(bevl_cur);
bevl_r.bem_addValue_1(bevt_4_ta_ph);
bevl_pos.bevi_int++;
} /* Line: 24*/
 else /* Line: 24*/ {
break;
} /* Line: 24*/
} /* Line: 24*/
return bevl_r;
} /*method end*/
public BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pta = null;
BEC_2_4_6_TextString bevl_ptb = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_9_SystemException bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_ssz.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 33*/ {
return beva_str;
} /* Line: 34*/
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_3_ta_ph = bevl_ssz.bem_modulus_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_6_3_EncodeHex_bels_0));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_ssz);
bevt_6_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_ta_ph);
throw new be.BECS_ThrowBack(bevt_6_ta_ph);
} /* Line: 37*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_cur = (new BEC_2_4_6_TextString()).bem_new_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_10_ta_ph = bevl_ssz.bem_divide_1(bevt_11_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_10_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_12_ta_ph = bevl_ssz.bem_divide_1(bevt_13_ta_ph);
bevl_r.bem_sizeSet_1(bevt_12_ta_ph);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_pta = (new BEC_2_4_6_TextString()).bem_new_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_ptb = (new BEC_2_4_6_TextString()).bem_new_1(bevt_15_ta_ph);
bevl_pos = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 46*/ {
bevt_16_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 46*/ {
bevl_tb.bem_next_1(bevl_pta);
bevl_tb.bem_next_1(bevl_ptb);
bevt_18_ta_ph = bevl_pta.bem_add_1(bevl_ptb);
bevt_17_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_ta_ph);
bevl_r.bem_setCodeUnchecked_2(bevl_pos, bevt_17_ta_ph);
bevl_pos.bevi_int++;
} /* Line: 50*/
 else /* Line: 46*/ {
break;
} /* Line: 46*/
} /* Line: 46*/
return bevl_r;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 21, 21, 22, 23, 23, 23, 24, 24, 24, 25, 26, 26, 24, 28, 32, 33, 33, 33, 34, 36, 36, 36, 36, 36, 37, 37, 37, 37, 39, 39, 40, 40, 40, 41, 41, 41, 42, 43, 43, 44, 44, 45, 46, 47, 48, 49, 49, 49, 50, 52};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 30, 31, 32, 33, 34, 35, 36, 39, 44, 45, 46, 47, 48, 54, 83, 84, 85, 90, 91, 93, 94, 95, 96, 101, 102, 103, 104, 105, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 125, 126, 127, 128, 129, 130, 136};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 29
new 0 20 29
assign 1 21 30
new 0 21 30
assign 1 21 31
new 1 21 31
assign 1 22 32
sizeGet 0 22 32
assign 1 23 33
new 0 23 33
assign 1 23 34
multiply 1 23 34
assign 1 23 35
new 1 23 35
assign 1 24 36
new 0 24 36
assign 1 24 39
lesser 1 24 44
getCode 2 25 45
assign 1 26 46
toHexString 1 26 46
addValue 1 26 47
incrementValue 0 24 48
return 1 28 54
assign 1 32 83
sizeGet 0 32 83
assign 1 33 84
new 0 33 84
assign 1 33 85
lesser 1 33 90
return 1 34 91
assign 1 36 93
new 0 36 93
assign 1 36 94
modulus 1 36 94
assign 1 36 95
new 0 36 95
assign 1 36 96
notEquals 1 36 101
assign 1 37 102
new 0 37 102
assign 1 37 103
add 1 37 103
assign 1 37 104
new 1 37 104
throw 1 37 105
assign 1 39 107
new 0 39 107
assign 1 39 108
new 1 39 108
assign 1 40 109
new 0 40 109
assign 1 40 110
divide 1 40 110
assign 1 40 111
new 1 40 111
assign 1 41 112
new 0 41 112
assign 1 41 113
divide 1 41 113
sizeSet 1 41 114
assign 1 42 115
new 1 42 115
assign 1 43 116
new 0 43 116
assign 1 43 117
new 1 43 117
assign 1 44 118
new 0 44 118
assign 1 44 119
new 1 44 119
assign 1 45 120
new 0 45 120
assign 1 46 123
hasNextGet 0 46 123
next 1 47 125
next 1 48 126
assign 1 49 127
add 1 49 127
assign 1 49 128
hexNew 1 49 128
setCodeUnchecked 2 49 129
incrementValue 0 50 130
return 1 52 136
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -52976429: return bem_new_0();
case 1293705497: return bem_iteratorGet_0();
case -424614227: return bem_print_0();
case -1648793551: return bem_hashGet_0();
case -676802561: return bem_create_0();
case -2046929697: return bem_toString_0();
case 827808077: return bem_default_0();
case -1337014400: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1337452029: return bem_notEquals_1(bevd_0);
case -2103393844: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 1043643914: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case 1346074140: return bem_equals_1(bevd_0);
case 526222373: return bem_def_1(bevd_0);
case 322005879: return bem_copyTo_1(bevd_0);
case 1651082390: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 964580200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1649942408: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -628094110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1488275060: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeHex_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_3_EncodeHex_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_EncodeHex();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst = (BEC_2_6_3_EncodeHex) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_type;
}
}
