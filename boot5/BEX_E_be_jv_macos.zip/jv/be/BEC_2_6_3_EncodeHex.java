package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeHex extends BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeHex() { }
private static byte[] becc_BEC_2_6_3_EncodeHex_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x65,0x78};
private static byte[] becc_BEC_2_6_3_EncodeHex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_3_EncodeHex_bels_0 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x68,0x65,0x78,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeHex_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeHex_bels_0, 26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_6 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_inst;

public static BET_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_type;

public BEC_2_6_3_EncodeHex bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl_ac = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_cur = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_2_ta_ph = bece_BEC_2_6_3_EncodeHex_bevo_0;
bevt_1_ta_ph = bevl_ssz.bem_multiply_1(bevt_2_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_ta_ph);
bevl_pos = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 20*/ {
if (bevl_pos.bevi_int < bevl_ssz.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 20*/ {
beva_str.bem_getCode_2(bevl_pos, bevl_ac);
bevt_4_ta_ph = bevl_ac.bem_toHexString_1(bevl_cur);
bevl_r.bem_addValue_1(bevt_4_ta_ph);
bevl_pos.bevi_int++;
} /* Line: 20*/
 else /* Line: 20*/ {
break;
} /* Line: 20*/
} /* Line: 20*/
return bevl_r;
} /*method end*/
public BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pta = null;
BEC_2_4_6_TextString bevl_ptb = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_9_SystemException bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_1_ta_ph = bece_BEC_2_6_3_EncodeHex_bevo_1;
if (bevl_ssz.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 29*/ {
return beva_str;
} /* Line: 30*/
bevt_4_ta_ph = bece_BEC_2_6_3_EncodeHex_bevo_2;
bevt_3_ta_ph = bevl_ssz.bem_modulus_1(bevt_4_ta_ph);
bevt_5_ta_ph = bece_BEC_2_6_3_EncodeHex_bevo_3;
if (bevt_3_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 32*/ {
bevt_8_ta_ph = bece_BEC_2_6_3_EncodeHex_bevo_4;
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_ssz);
bevt_6_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_ta_ph);
throw new be.BECS_ThrowBack(bevt_6_ta_ph);
} /* Line: 33*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_cur = (new BEC_2_4_6_TextString()).bem_new_1(bevt_9_ta_ph);
bevt_11_ta_ph = bece_BEC_2_6_3_EncodeHex_bevo_5;
bevt_10_ta_ph = bevl_ssz.bem_divide_1(bevt_11_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_10_ta_ph);
bevt_13_ta_ph = bece_BEC_2_6_3_EncodeHex_bevo_6;
bevt_12_ta_ph = bevl_ssz.bem_divide_1(bevt_13_ta_ph);
bevl_r.bem_sizeSet_1(bevt_12_ta_ph);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_pta = (new BEC_2_4_6_TextString()).bem_new_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_ptb = (new BEC_2_4_6_TextString()).bem_new_1(bevt_15_ta_ph);
bevl_pos = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 42*/ {
bevt_16_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 42*/ {
bevl_tb.bem_next_1(bevl_pta);
bevl_tb.bem_next_1(bevl_ptb);
bevt_18_ta_ph = bevl_pta.bem_add_1(bevl_ptb);
bevt_17_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_ta_ph);
bevl_r.bem_setCodeUnchecked_2(bevl_pos, bevt_17_ta_ph);
bevl_pos.bevi_int++;
} /* Line: 46*/
 else /* Line: 42*/ {
break;
} /* Line: 42*/
} /* Line: 42*/
return bevl_r;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 17, 18, 19, 19, 19, 20, 20, 20, 21, 22, 22, 20, 24, 28, 29, 29, 29, 30, 32, 32, 32, 32, 32, 33, 33, 33, 33, 35, 35, 36, 36, 36, 37, 37, 37, 38, 39, 39, 40, 40, 41, 42, 43, 44, 45, 45, 45, 46, 48};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {38, 39, 40, 41, 42, 43, 44, 45, 48, 53, 54, 55, 56, 57, 63, 92, 93, 94, 99, 100, 102, 103, 104, 105, 110, 111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 134, 135, 136, 137, 138, 139, 145};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 38
new 0 16 38
assign 1 17 39
new 0 17 39
assign 1 17 40
new 1 17 40
assign 1 18 41
sizeGet 0 18 41
assign 1 19 42
new 0 19 42
assign 1 19 43
multiply 1 19 43
assign 1 19 44
new 1 19 44
assign 1 20 45
new 0 20 45
assign 1 20 48
lesser 1 20 53
getCode 2 21 54
assign 1 22 55
toHexString 1 22 55
addValue 1 22 56
incrementValue 0 20 57
return 1 24 63
assign 1 28 92
sizeGet 0 28 92
assign 1 29 93
new 0 29 93
assign 1 29 94
lesser 1 29 99
return 1 30 100
assign 1 32 102
new 0 32 102
assign 1 32 103
modulus 1 32 103
assign 1 32 104
new 0 32 104
assign 1 32 105
notEquals 1 32 110
assign 1 33 111
new 0 33 111
assign 1 33 112
add 1 33 112
assign 1 33 113
new 1 33 113
throw 1 33 114
assign 1 35 116
new 0 35 116
assign 1 35 117
new 1 35 117
assign 1 36 118
new 0 36 118
assign 1 36 119
divide 1 36 119
assign 1 36 120
new 1 36 120
assign 1 37 121
new 0 37 121
assign 1 37 122
divide 1 37 122
sizeSet 1 37 123
assign 1 38 124
new 1 38 124
assign 1 39 125
new 0 39 125
assign 1 39 126
new 1 39 126
assign 1 40 127
new 0 40 127
assign 1 40 128
new 1 40 128
assign 1 41 129
new 0 41 129
assign 1 42 132
hasNextGet 0 42 132
next 1 43 134
next 1 44 135
assign 1 45 136
add 1 45 136
assign 1 45 137
hexNew 1 45 137
setCodeUnchecked 2 45 138
incrementValue 0 46 139
return 1 48 145
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1938521961: return bem_create_0();
case 1428196909: return bem_deserializeClassNameGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case 1469761457: return bem_serializeToString_0();
case -1120775249: return bem_classNameGet_0();
case -559654393: return bem_sourceFileNameGet_0();
case 976077722: return bem_new_0();
case -1359840989: return bem_toAny_0();
case -129765629: return bem_print_0();
case -1677294751: return bem_hashGet_0();
case -1660007365: return bem_iteratorGet_0();
case 126164297: return bem_serializationIteratorGet_0();
case -1640020074: return bem_toString_0();
case -374496050: return bem_tagGet_0();
case -1530492540: return bem_many_0();
case 921209725: return bem_echo_0();
case -1606863806: return bem_fieldIteratorGet_0();
case -1483834827: return bem_copy_0();
case 510046831: return bem_default_0();
case 2028199664: return bem_once_0();
case 1963846645: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1090972685: return bem_otherType_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1789648416: return bem_def_1(bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1898344200: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case -200920808: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case 1414981672: return bem_defined_1(bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeHex_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeHex_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_EncodeHex();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst = (BEC_2_6_3_EncodeHex) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_type;
}
}
