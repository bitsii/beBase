package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 882 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 884 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 887 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 893 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(611376877, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 895 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 898 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 905 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(1022587247, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 907 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 910 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 917 */ {
bevl_r = bevp_container.bemd_0(-96121362);
bevp_lock.bem_unlock_0();
} /* Line: 919 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 922 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 929 */ {
bevl_r = bevp_container.bemd_1(548242717, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 931 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 934 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 941 */ {
bevl_r = bevp_container.bemd_1(548242717, beva_key);
bevp_container.bemd_1(-2132349703, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 944 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 947 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 954 */ {
bevl_r = bevp_container.bemd_2(-1594887074, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 956 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 959 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 966 */ {
bevp_container.bemd_1(-396018626, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 968 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 971 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 977 */ {
bevl_r = bevp_container.bemd_1(853752511, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 979 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 982 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 989 */ {
bevp_container.bemd_1(853752511, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 991 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 994 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1000 */ {
bevl_r = bevp_container.bemd_2(1871090448, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1002 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1005 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1012 */ {
bevp_container.bemd_2(1871090448, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1014 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1017 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1023 */ {
bevl_rc = bevp_container.bemd_3(-321078554, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1025 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1028 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSet_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1035 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(82610740);
bevp_lock.bem_unlock_0();
} /* Line: 1037 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1040 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1047 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-2000462519);
bevp_lock.bem_unlock_0();
} /* Line: 1049 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1052 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1059 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-1298889612, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 1061 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1064 */
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1071 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(611376877, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1072 */ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 1073 */
 else  /* Line: 1074 */ {
bevp_container.bemd_2(1871090448, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 1076 */
bevp_lock.bem_unlock_0();
} /* Line: 1078 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1081 */
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1088 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(611376877, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1089 */ {
bevl_result = bevp_container.bemd_1(548242717, beva_key);
} /* Line: 1090 */
 else  /* Line: 1091 */ {
bevp_container.bemd_2(1871090448, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1093 */
bevp_lock.bem_unlock_0();
} /* Line: 1095 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1098 */
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1105 */ {
bevp_container.bemd_3(1092975873, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1107 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1110 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1116 */ {
bevl_r = bevp_container.bemd_1(-2132349703, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1118 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1121 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1128 */ {
bevl_r = bevp_container.bemd_2(-1659392494, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1130 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1133 */
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1140 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(1374995571);
bevp_lock.bem_unlock_0();
} /* Line: 1142 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1145 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1152 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-1879000483);
bevp_lock.bem_unlock_0();
} /* Line: 1154 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1157 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1164 */ {
bevl_r = bevp_container.bemd_0(-1486852325);
bevp_lock.bem_unlock_0();
} /* Line: 1166 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1169 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1176 */ {
bevp_container.bemd_0(-1889174956);
bevp_lock.bem_unlock_0();
} /* Line: 1178 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1181 */
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1187 */ {
bevp_container.bemd_0(411224144);
bevp_lock.bem_unlock_0();
} /* Line: 1189 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1192 */
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {878, 881, 883, 884, 886, 887, 892, 894, 895, 897, 898, 900, 904, 906, 907, 909, 910, 912, 916, 918, 919, 921, 922, 924, 928, 930, 931, 933, 934, 936, 940, 942, 943, 944, 946, 947, 949, 953, 955, 956, 958, 959, 961, 965, 967, 968, 970, 971, 976, 978, 979, 981, 982, 984, 988, 990, 991, 993, 994, 999, 1001, 1002, 1004, 1005, 1007, 1011, 1013, 1014, 1016, 1017, 1022, 1024, 1025, 1027, 1028, 1030, 1034, 1036, 1037, 1039, 1040, 1042, 1046, 1048, 1049, 1051, 1052, 1054, 1058, 1060, 1061, 1063, 1064, 1066, 1070, 1072, 1073, 1075, 1076, 1078, 1080, 1081, 1083, 1087, 1089, 1090, 1092, 1093, 1095, 1097, 1098, 1100, 1104, 1106, 1107, 1109, 1110, 1115, 1117, 1118, 1120, 1121, 1123, 1127, 1129, 1130, 1132, 1133, 1135, 1139, 1141, 1142, 1144, 1145, 1147, 1151, 1153, 1154, 1156, 1157, 1159, 1163, 1165, 1166, 1168, 1169, 1171, 1175, 1177, 1178, 1180, 1181, 1186, 1188, 1189, 1191, 1192, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 241, 243, 244, 248, 249, 251, 257, 259, 261, 264, 265, 267, 271, 272, 274, 280, 282, 284, 287, 288, 290, 294, 295, 297, 301, 303, 304, 308, 309, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 376, 378, 379, 383, 384, 386, 390, 392, 393, 397, 398, 404, 406, 407, 411, 412, 417, 420, 423, 427, 431, 434, 437, 441};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 878 17
new 0 878 17
lock 0 881 18
assign 1 883 20
unlock 0 884 21
unlock 0 886 25
throw 1 887 26
lock 0 892 33
assign 1 894 35
has 1 894 35
unlock 0 895 36
unlock 0 897 40
throw 1 898 41
return 1 900 43
lock 0 904 48
assign 1 906 50
has 2 906 50
unlock 0 907 51
unlock 0 909 55
throw 1 910 56
return 1 912 58
lock 0 916 63
assign 1 918 65
get 0 918 65
unlock 0 919 66
unlock 0 921 70
throw 1 922 71
return 1 924 73
lock 0 928 78
assign 1 930 80
get 1 930 80
unlock 0 931 81
unlock 0 933 85
throw 1 934 86
return 1 936 88
lock 0 940 93
assign 1 942 95
get 1 942 95
delete 1 943 96
unlock 0 944 97
unlock 0 946 101
throw 1 947 102
return 1 949 104
lock 0 953 109
assign 1 955 111
get 2 955 111
unlock 0 956 112
unlock 0 958 116
throw 1 959 117
return 1 961 119
lock 0 965 123
addValue 1 967 125
unlock 0 968 126
unlock 0 970 130
throw 1 971 131
lock 0 976 138
assign 1 978 140
put 1 978 140
unlock 0 979 141
unlock 0 981 145
throw 1 982 146
return 1 984 148
lock 0 988 152
put 1 990 154
unlock 0 991 155
unlock 0 993 159
throw 1 994 160
lock 0 999 167
assign 1 1001 169
put 2 1001 169
unlock 0 1002 170
unlock 0 1004 174
throw 1 1005 175
return 1 1007 177
lock 0 1011 181
put 2 1013 183
unlock 0 1014 184
unlock 0 1016 188
throw 1 1017 189
lock 0 1022 196
assign 1 1024 198
testAndPut 3 1024 198
unlock 0 1025 199
unlock 0 1027 203
throw 1 1028 204
return 1 1030 206
lock 0 1034 211
assign 1 1036 213
getSet 0 1036 213
unlock 0 1037 214
unlock 0 1039 218
throw 1 1040 219
return 1 1042 221
lock 0 1046 226
assign 1 1048 228
getMap 0 1048 228
unlock 0 1049 229
unlock 0 1051 233
throw 1 1052 234
return 1 1054 236
lock 0 1058 241
assign 1 1060 243
getMap 1 1060 243
unlock 0 1061 244
unlock 0 1063 248
throw 1 1064 249
return 1 1066 251
lock 0 1070 257
assign 1 1072 259
has 1 1072 259
assign 1 1073 261
new 0 1073 261
put 2 1075 264
assign 1 1076 265
new 0 1076 265
unlock 0 1078 267
unlock 0 1080 271
throw 1 1081 272
return 1 1083 274
lock 0 1087 280
assign 1 1089 282
has 1 1089 282
assign 1 1090 284
get 1 1090 284
put 2 1092 287
assign 1 1093 288
unlock 0 1095 290
unlock 0 1097 294
throw 1 1098 295
return 1 1100 297
lock 0 1104 301
put 3 1106 303
unlock 0 1107 304
unlock 0 1109 308
throw 1 1110 309
lock 0 1115 316
assign 1 1117 318
delete 1 1117 318
unlock 0 1118 319
unlock 0 1120 323
throw 1 1121 324
return 1 1123 326
lock 0 1127 331
assign 1 1129 333
delete 2 1129 333
unlock 0 1130 334
unlock 0 1132 338
throw 1 1133 339
return 1 1135 341
lock 0 1139 346
assign 1 1141 348
sizeGet 0 1141 348
unlock 0 1142 349
unlock 0 1144 353
throw 1 1145 354
return 1 1147 356
lock 0 1151 361
assign 1 1153 363
isEmptyGet 0 1153 363
unlock 0 1154 364
unlock 0 1156 368
throw 1 1157 369
return 1 1159 371
lock 0 1163 376
assign 1 1165 378
copy 0 1165 378
unlock 0 1166 379
unlock 0 1168 383
throw 1 1169 384
return 1 1171 386
lock 0 1175 390
clear 0 1177 392
unlock 0 1178 393
unlock 0 1180 397
throw 1 1181 398
lock 0 1186 404
close 0 1188 406
unlock 0 1189 407
unlock 0 1191 411
throw 1 1192 412
return 1 0 417
return 1 0 420
assign 1 0 423
assign 1 0 427
return 1 0 431
return 1 0 434
assign 1 0 437
assign 1 0 441
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1203535797: return bem_toAny_0();
case -1166462165: return bem_iteratorGet_0();
case -1191299721: return bem_deserializeClassNameGet_0();
case -260111055: return bem_print_0();
case 1227289471: return bem_hashGet_0();
case 740465458: return bem_new_0();
case -1847716573: return bem_lockGet_0();
case -1348350074: return bem_create_0();
case 411224144: return bem_close_0();
case -736476180: return bem_serializeContents_0();
case 1567955799: return bem_fieldIteratorGet_0();
case 1931094190: return bem_lockGetDirect_0();
case 1840305191: return bem_serializeToString_0();
case 668710875: return bem_copyContainer_0();
case -844497155: return bem_tagGet_0();
case -1879000483: return bem_isEmptyGet_0();
case 351178267: return bem_echo_0();
case -383147285: return bem_serializationIteratorGet_0();
case -557938157: return bem_toString_0();
case -2039624597: return bem_sourceFileNameGet_0();
case -96121362: return bem_get_0();
case -1889174956: return bem_clear_0();
case -2000462519: return bem_getMap_0();
case 1374995571: return bem_sizeGet_0();
case 1540627001: return bem_classNameGet_0();
case 2095267690: return bem_containerGetDirect_0();
case 82610740: return bem_getSet_0();
case -295279542: return bem_once_0();
case 1796376822: return bem_containerGet_0();
case -1486852325: return bem_copy_0();
case -5604421: return bem_many_0();
case -243903584: return bem_fieldNamesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -396018626: return bem_addValue_1(bevd_0);
case -548119011: return bem_containerSet_1(bevd_0);
case -933517830: return bem_putReturn_1(bevd_0);
case -2132349703: return bem_delete_1(bevd_0);
case 551786219: return bem_new_1(bevd_0);
case -1298889612: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 611376877: return bem_has_1(bevd_0);
case -218864081: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1670790162: return bem_sameClass_1(bevd_0);
case 681538010: return bem_notEquals_1(bevd_0);
case -67300059: return bem_equals_1(bevd_0);
case 853752511: return bem_put_1(bevd_0);
case 1544353280: return bem_otherClass_1(bevd_0);
case -535190245: return bem_lockSet_1(bevd_0);
case 1724749097: return bem_undefined_1(bevd_0);
case -1748281966: return bem_sameObject_1(bevd_0);
case 1647627603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1148285914: return bem_containerSetDirect_1(bevd_0);
case -2100440987: return bem_def_1(bevd_0);
case 958315163: return bem_sameType_1(bevd_0);
case -593937181: return bem_copyTo_1(bevd_0);
case 548242717: return bem_get_1(bevd_0);
case 1187046692: return bem_defined_1(bevd_0);
case -1258811879: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2039711690: return bem_undef_1(bevd_0);
case 1263697515: return bem_lockSetDirect_1(bevd_0);
case 538504494: return bem_getAndClear_1(bevd_0);
case -387830191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1839755987: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1046047039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1022587247: return bem_has_2(bevd_0, bevd_1);
case -1708434276: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 520681709: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -528171684: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1594887074: return bem_get_2(bevd_0, bevd_1);
case -644525834: return bem_putReturn_2(bevd_0, bevd_1);
case 1304899076: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1871090448: return bem_put_2(bevd_0, bevd_1);
case 1671846119: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1659392494: return bem_delete_2(bevd_0, bevd_1);
case -1365116511: return bem_getOrPut_2(bevd_0, bevd_1);
case 1868703996: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1783125070: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1092975873: return bem_put_3(bevd_0, bevd_1, bevd_2);
case -321078554: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
