package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 824 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 826 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 829 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 835 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-702689265, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 837 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 840 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 847 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(569419987, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 849 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 852 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 859 */ {
bevl_r = bevp_container.bemd_0(988305467);
bevp_lock.bem_unlock_0();
} /* Line: 861 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 864 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 871 */ {
bevl_r = bevp_container.bemd_1(-1166994632, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 873 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 876 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 883 */ {
bevl_r = bevp_container.bemd_1(-1166994632, beva_key);
bevp_container.bemd_1(1040931602, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 886 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 889 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 896 */ {
bevl_r = bevp_container.bemd_2(-928754183, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 898 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 901 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 908 */ {
bevp_container.bemd_1(-1150984409, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 910 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 913 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 919 */ {
bevl_r = bevp_container.bemd_1(1967350921, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 921 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 924 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 931 */ {
bevp_container.bemd_1(1967350921, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 933 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 936 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 942 */ {
bevl_r = bevp_container.bemd_2(-783638750, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 944 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 947 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 954 */ {
bevp_container.bemd_2(-783638750, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 956 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 959 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 965 */ {
bevl_rc = bevp_container.bemd_3(-1580546850, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 967 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 970 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 977 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1041941741);
bevp_lock.bem_unlock_0();
} /* Line: 979 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 982 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 989 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(982421129, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 991 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 994 */
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1001 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-702689265, beva_key);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1002 */ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 1003 */
 else  /* Line: 1004 */ {
bevp_container.bemd_2(-783638750, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 1006 */
bevp_lock.bem_unlock_0();
} /* Line: 1008 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1011 */
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1018 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-702689265, beva_key);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1019 */ {
bevl_result = bevp_container.bemd_1(-1166994632, beva_key);
} /* Line: 1020 */
 else  /* Line: 1021 */ {
bevp_container.bemd_2(-783638750, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1023 */
bevp_lock.bem_unlock_0();
} /* Line: 1025 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1028 */
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1035 */ {
bevp_container.bemd_3(-1568577618, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1037 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1040 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1046 */ {
bevl_r = bevp_container.bemd_1(1040931602, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1048 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1051 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1058 */ {
bevl_r = bevp_container.bemd_2(1358409373, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1060 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1063 */
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1070 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(1942258633);
bevp_lock.bem_unlock_0();
} /* Line: 1072 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1075 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1082 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(1810668720);
bevp_lock.bem_unlock_0();
} /* Line: 1084 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1087 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1094 */ {
bevl_r = bevp_container.bemd_0(1586265763);
bevp_lock.bem_unlock_0();
} /* Line: 1096 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1099 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1106 */ {
bevp_container.bemd_0(1019764096);
bevp_lock.bem_unlock_0();
} /* Line: 1108 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1111 */
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1117 */ {
bevp_container.bemd_0(765609192);
bevp_lock.bem_unlock_0();
} /* Line: 1119 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1122 */
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {820, 823, 825, 826, 828, 829, 834, 836, 837, 839, 840, 842, 846, 848, 849, 851, 852, 854, 858, 860, 861, 863, 864, 866, 870, 872, 873, 875, 876, 878, 882, 884, 885, 886, 888, 889, 891, 895, 897, 898, 900, 901, 903, 907, 909, 910, 912, 913, 918, 920, 921, 923, 924, 926, 930, 932, 933, 935, 936, 941, 943, 944, 946, 947, 949, 953, 955, 956, 958, 959, 964, 966, 967, 969, 970, 972, 976, 978, 979, 981, 982, 984, 988, 990, 991, 993, 994, 996, 1000, 1002, 1003, 1005, 1006, 1008, 1010, 1011, 1013, 1017, 1019, 1020, 1022, 1023, 1025, 1027, 1028, 1030, 1034, 1036, 1037, 1039, 1040, 1045, 1047, 1048, 1050, 1051, 1053, 1057, 1059, 1060, 1062, 1063, 1065, 1069, 1071, 1072, 1074, 1075, 1077, 1081, 1083, 1084, 1086, 1087, 1089, 1093, 1095, 1096, 1098, 1099, 1101, 1105, 1107, 1108, 1110, 1111, 1116, 1118, 1119, 1121, 1122, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 17, 18, 22, 23, 30, 32, 33, 37, 38, 40, 45, 47, 48, 52, 53, 55, 60, 62, 63, 67, 68, 70, 75, 77, 78, 82, 83, 85, 90, 92, 93, 94, 98, 99, 101, 106, 108, 109, 113, 114, 116, 120, 122, 123, 127, 128, 135, 137, 138, 142, 143, 145, 149, 151, 152, 156, 157, 164, 166, 167, 171, 172, 174, 178, 180, 181, 185, 186, 193, 195, 196, 200, 201, 203, 208, 210, 211, 215, 216, 218, 223, 225, 226, 230, 231, 233, 239, 241, 243, 246, 247, 249, 253, 254, 256, 262, 264, 266, 269, 270, 272, 276, 277, 279, 283, 285, 286, 290, 291, 298, 300, 301, 305, 306, 308, 313, 315, 316, 320, 321, 323, 328, 330, 331, 335, 336, 338, 343, 345, 346, 350, 351, 353, 358, 360, 361, 365, 366, 368, 372, 374, 375, 379, 380, 386, 388, 389, 393, 394, 399, 402, 406, 409};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 820 14
new 0 820 14
lock 0 823 15
assign 1 825 17
unlock 0 826 18
unlock 0 828 22
throw 1 829 23
lock 0 834 30
assign 1 836 32
has 1 836 32
unlock 0 837 33
unlock 0 839 37
throw 1 840 38
return 1 842 40
lock 0 846 45
assign 1 848 47
has 2 848 47
unlock 0 849 48
unlock 0 851 52
throw 1 852 53
return 1 854 55
lock 0 858 60
assign 1 860 62
get 0 860 62
unlock 0 861 63
unlock 0 863 67
throw 1 864 68
return 1 866 70
lock 0 870 75
assign 1 872 77
get 1 872 77
unlock 0 873 78
unlock 0 875 82
throw 1 876 83
return 1 878 85
lock 0 882 90
assign 1 884 92
get 1 884 92
delete 1 885 93
unlock 0 886 94
unlock 0 888 98
throw 1 889 99
return 1 891 101
lock 0 895 106
assign 1 897 108
get 2 897 108
unlock 0 898 109
unlock 0 900 113
throw 1 901 114
return 1 903 116
lock 0 907 120
addValue 1 909 122
unlock 0 910 123
unlock 0 912 127
throw 1 913 128
lock 0 918 135
assign 1 920 137
put 1 920 137
unlock 0 921 138
unlock 0 923 142
throw 1 924 143
return 1 926 145
lock 0 930 149
put 1 932 151
unlock 0 933 152
unlock 0 935 156
throw 1 936 157
lock 0 941 164
assign 1 943 166
put 2 943 166
unlock 0 944 167
unlock 0 946 171
throw 1 947 172
return 1 949 174
lock 0 953 178
put 2 955 180
unlock 0 956 181
unlock 0 958 185
throw 1 959 186
lock 0 964 193
assign 1 966 195
testAndPut 3 966 195
unlock 0 967 196
unlock 0 969 200
throw 1 970 201
return 1 972 203
lock 0 976 208
assign 1 978 210
getMap 0 978 210
unlock 0 979 211
unlock 0 981 215
throw 1 982 216
return 1 984 218
lock 0 988 223
assign 1 990 225
getMap 1 990 225
unlock 0 991 226
unlock 0 993 230
throw 1 994 231
return 1 996 233
lock 0 1000 239
assign 1 1002 241
has 1 1002 241
assign 1 1003 243
new 0 1003 243
put 2 1005 246
assign 1 1006 247
new 0 1006 247
unlock 0 1008 249
unlock 0 1010 253
throw 1 1011 254
return 1 1013 256
lock 0 1017 262
assign 1 1019 264
has 1 1019 264
assign 1 1020 266
get 1 1020 266
put 2 1022 269
assign 1 1023 270
unlock 0 1025 272
unlock 0 1027 276
throw 1 1028 277
return 1 1030 279
lock 0 1034 283
put 3 1036 285
unlock 0 1037 286
unlock 0 1039 290
throw 1 1040 291
lock 0 1045 298
assign 1 1047 300
delete 1 1047 300
unlock 0 1048 301
unlock 0 1050 305
throw 1 1051 306
return 1 1053 308
lock 0 1057 313
assign 1 1059 315
delete 2 1059 315
unlock 0 1060 316
unlock 0 1062 320
throw 1 1063 321
return 1 1065 323
lock 0 1069 328
assign 1 1071 330
sizeGet 0 1071 330
unlock 0 1072 331
unlock 0 1074 335
throw 1 1075 336
return 1 1077 338
lock 0 1081 343
assign 1 1083 345
isEmptyGet 0 1083 345
unlock 0 1084 346
unlock 0 1086 350
throw 1 1087 351
return 1 1089 353
lock 0 1093 358
assign 1 1095 360
copy 0 1095 360
unlock 0 1096 361
unlock 0 1098 365
throw 1 1099 366
return 1 1101 368
lock 0 1105 372
clear 0 1107 374
unlock 0 1108 375
unlock 0 1110 379
throw 1 1111 380
lock 0 1116 386
close 0 1118 388
unlock 0 1119 389
unlock 0 1121 393
throw 1 1122 394
return 1 0 399
assign 1 0 402
return 1 0 406
assign 1 0 409
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1724993772: return bem_many_0();
case 1019764096: return bem_clear_0();
case 836604081: return bem_tagGet_0();
case 765609192: return bem_close_0();
case 755005070: return bem_echo_0();
case 1550782506: return bem_print_0();
case 1900537696: return bem_containerGet_0();
case -1674644863: return bem_serializeToString_0();
case 988305467: return bem_get_0();
case 353744263: return bem_once_0();
case -1408149831: return bem_copyContainer_0();
case -1207227016: return bem_toAny_0();
case 1586265763: return bem_copy_0();
case -1615155660: return bem_sourceFileNameGet_0();
case -1041941741: return bem_getMap_0();
case 1942258633: return bem_sizeGet_0();
case -2035802034: return bem_hashGet_0();
case -2079261808: return bem_toString_0();
case 331067077: return bem_iteratorGet_0();
case -868754815: return bem_serializeContents_0();
case -1704001450: return bem_serializationIteratorGet_0();
case -1144635038: return bem_fieldIteratorGet_0();
case 1107063436: return bem_create_0();
case 2019810837: return bem_lockGet_0();
case 1618197244: return bem_new_0();
case -1432966592: return bem_deserializeClassNameGet_0();
case 2089277173: return bem_classNameGet_0();
case 1810668720: return bem_isEmptyGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 518971201: return bem_putReturn_1(bevd_0);
case 567619203: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 779346053: return bem_lockSet_1(bevd_0);
case 894987079: return bem_undef_1(bevd_0);
case -1166994632: return bem_get_1(bevd_0);
case -2018158572: return bem_sameType_1(bevd_0);
case 2082220238: return bem_new_1(bevd_0);
case -1743252117: return bem_sameObject_1(bevd_0);
case 1053963189: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -366756123: return bem_containerSet_1(bevd_0);
case 1292274364: return bem_undefined_1(bevd_0);
case -955519709: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -864903677: return bem_otherType_1(bevd_0);
case -1690226246: return bem_notEquals_1(bevd_0);
case 982421129: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1181026029: return bem_copyTo_1(bevd_0);
case -102763151: return bem_defined_1(bevd_0);
case 1040931602: return bem_delete_1(bevd_0);
case -1348736504: return bem_getAndClear_1(bevd_0);
case 1820941401: return bem_def_1(bevd_0);
case -467831865: return bem_otherClass_1(bevd_0);
case 1967350921: return bem_put_1(bevd_0);
case 729465196: return bem_equals_1(bevd_0);
case -1285524271: return bem_sameClass_1(bevd_0);
case -702689265: return bem_has_1(bevd_0);
case 1975786452: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1150984409: return bem_addValue_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1358409373: return bem_delete_2(bevd_0, bevd_1);
case 1713973958: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2041527697: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1814064163: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1639759790: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -1241720452: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 569419987: return bem_has_2(bevd_0, bevd_1);
case 1527927145: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 285926412: return bem_getOrPut_2(bevd_0, bevd_1);
case -1067491989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -928754183: return bem_get_2(bevd_0, bevd_1);
case 1632202498: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 693927780: return bem_putReturn_2(bevd_0, bevd_1);
case -783638750: return bem_put_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1580546850: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
case -1568577618: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
}
