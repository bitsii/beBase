package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 824 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 826 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 829 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 835 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-1617175076, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 837 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 840 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 847 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-423199848, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 849 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 852 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 859 */ {
bevl_r = bevp_container.bemd_0(1290371969);
bevp_lock.bem_unlock_0();
} /* Line: 861 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 864 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 871 */ {
bevl_r = bevp_container.bemd_1(-517240107, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 873 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 876 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 883 */ {
bevl_r = bevp_container.bemd_1(-517240107, beva_key);
bevp_container.bemd_1(1360616895, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 886 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 889 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 896 */ {
bevl_r = bevp_container.bemd_2(-690585465, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 898 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 901 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 908 */ {
bevp_container.bemd_1(-380820495, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 910 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 913 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 919 */ {
bevl_r = bevp_container.bemd_1(-425191892, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 921 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 924 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 931 */ {
bevp_container.bemd_1(-425191892, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 933 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 936 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 942 */ {
bevl_r = bevp_container.bemd_2(-1957857497, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 944 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 947 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 954 */ {
bevp_container.bemd_2(-1957857497, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 956 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 959 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 965 */ {
bevl_rc = bevp_container.bemd_3(-2067621373, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 967 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 970 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 977 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1465092891);
bevp_lock.bem_unlock_0();
} /* Line: 979 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 982 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 989 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-853660490, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 991 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 994 */
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1001 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-1617175076, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1002 */ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 1003 */
 else  /* Line: 1004 */ {
bevp_container.bemd_2(-1957857497, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 1006 */
bevp_lock.bem_unlock_0();
} /* Line: 1008 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1011 */
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1018 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-1617175076, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1019 */ {
bevl_result = bevp_container.bemd_1(-517240107, beva_key);
} /* Line: 1020 */
 else  /* Line: 1021 */ {
bevp_container.bemd_2(-1957857497, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1023 */
bevp_lock.bem_unlock_0();
} /* Line: 1025 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1028 */
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1035 */ {
bevp_container.bemd_3(-2080067234, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1037 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1040 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1046 */ {
bevl_r = bevp_container.bemd_1(1360616895, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1048 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1051 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1058 */ {
bevl_r = bevp_container.bemd_2(-495657566, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1060 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1063 */
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1070 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(1643609078);
bevp_lock.bem_unlock_0();
} /* Line: 1072 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1075 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1082 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-856086754);
bevp_lock.bem_unlock_0();
} /* Line: 1084 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1087 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1094 */ {
bevl_r = bevp_container.bemd_0(1793221455);
bevp_lock.bem_unlock_0();
} /* Line: 1096 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1099 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1106 */ {
bevp_container.bemd_0(-520612795);
bevp_lock.bem_unlock_0();
} /* Line: 1108 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1111 */
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1117 */ {
bevp_container.bemd_0(-1827045033);
bevp_lock.bem_unlock_0();
} /* Line: 1119 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1122 */
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {820, 823, 825, 826, 828, 829, 834, 836, 837, 839, 840, 842, 846, 848, 849, 851, 852, 854, 858, 860, 861, 863, 864, 866, 870, 872, 873, 875, 876, 878, 882, 884, 885, 886, 888, 889, 891, 895, 897, 898, 900, 901, 903, 907, 909, 910, 912, 913, 918, 920, 921, 923, 924, 926, 930, 932, 933, 935, 936, 941, 943, 944, 946, 947, 949, 953, 955, 956, 958, 959, 964, 966, 967, 969, 970, 972, 976, 978, 979, 981, 982, 984, 988, 990, 991, 993, 994, 996, 1000, 1002, 1003, 1005, 1006, 1008, 1010, 1011, 1013, 1017, 1019, 1020, 1022, 1023, 1025, 1027, 1028, 1030, 1034, 1036, 1037, 1039, 1040, 1045, 1047, 1048, 1050, 1051, 1053, 1057, 1059, 1060, 1062, 1063, 1065, 1069, 1071, 1072, 1074, 1075, 1077, 1081, 1083, 1084, 1086, 1087, 1089, 1093, 1095, 1096, 1098, 1099, 1101, 1105, 1107, 1108, 1110, 1111, 1116, 1118, 1119, 1121, 1122, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 242, 244, 246, 249, 250, 252, 256, 257, 259, 265, 267, 269, 272, 273, 275, 279, 280, 282, 286, 288, 289, 293, 294, 301, 303, 304, 308, 309, 311, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 375, 377, 378, 382, 383, 389, 391, 392, 396, 397, 402, 405, 409, 412};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 820 17
new 0 820 17
lock 0 823 18
assign 1 825 20
unlock 0 826 21
unlock 0 828 25
throw 1 829 26
lock 0 834 33
assign 1 836 35
has 1 836 35
unlock 0 837 36
unlock 0 839 40
throw 1 840 41
return 1 842 43
lock 0 846 48
assign 1 848 50
has 2 848 50
unlock 0 849 51
unlock 0 851 55
throw 1 852 56
return 1 854 58
lock 0 858 63
assign 1 860 65
get 0 860 65
unlock 0 861 66
unlock 0 863 70
throw 1 864 71
return 1 866 73
lock 0 870 78
assign 1 872 80
get 1 872 80
unlock 0 873 81
unlock 0 875 85
throw 1 876 86
return 1 878 88
lock 0 882 93
assign 1 884 95
get 1 884 95
delete 1 885 96
unlock 0 886 97
unlock 0 888 101
throw 1 889 102
return 1 891 104
lock 0 895 109
assign 1 897 111
get 2 897 111
unlock 0 898 112
unlock 0 900 116
throw 1 901 117
return 1 903 119
lock 0 907 123
addValue 1 909 125
unlock 0 910 126
unlock 0 912 130
throw 1 913 131
lock 0 918 138
assign 1 920 140
put 1 920 140
unlock 0 921 141
unlock 0 923 145
throw 1 924 146
return 1 926 148
lock 0 930 152
put 1 932 154
unlock 0 933 155
unlock 0 935 159
throw 1 936 160
lock 0 941 167
assign 1 943 169
put 2 943 169
unlock 0 944 170
unlock 0 946 174
throw 1 947 175
return 1 949 177
lock 0 953 181
put 2 955 183
unlock 0 956 184
unlock 0 958 188
throw 1 959 189
lock 0 964 196
assign 1 966 198
testAndPut 3 966 198
unlock 0 967 199
unlock 0 969 203
throw 1 970 204
return 1 972 206
lock 0 976 211
assign 1 978 213
getMap 0 978 213
unlock 0 979 214
unlock 0 981 218
throw 1 982 219
return 1 984 221
lock 0 988 226
assign 1 990 228
getMap 1 990 228
unlock 0 991 229
unlock 0 993 233
throw 1 994 234
return 1 996 236
lock 0 1000 242
assign 1 1002 244
has 1 1002 244
assign 1 1003 246
new 0 1003 246
put 2 1005 249
assign 1 1006 250
new 0 1006 250
unlock 0 1008 252
unlock 0 1010 256
throw 1 1011 257
return 1 1013 259
lock 0 1017 265
assign 1 1019 267
has 1 1019 267
assign 1 1020 269
get 1 1020 269
put 2 1022 272
assign 1 1023 273
unlock 0 1025 275
unlock 0 1027 279
throw 1 1028 280
return 1 1030 282
lock 0 1034 286
put 3 1036 288
unlock 0 1037 289
unlock 0 1039 293
throw 1 1040 294
lock 0 1045 301
assign 1 1047 303
delete 1 1047 303
unlock 0 1048 304
unlock 0 1050 308
throw 1 1051 309
return 1 1053 311
lock 0 1057 316
assign 1 1059 318
delete 2 1059 318
unlock 0 1060 319
unlock 0 1062 323
throw 1 1063 324
return 1 1065 326
lock 0 1069 331
assign 1 1071 333
sizeGet 0 1071 333
unlock 0 1072 334
unlock 0 1074 338
throw 1 1075 339
return 1 1077 341
lock 0 1081 346
assign 1 1083 348
isEmptyGet 0 1083 348
unlock 0 1084 349
unlock 0 1086 353
throw 1 1087 354
return 1 1089 356
lock 0 1093 361
assign 1 1095 363
copy 0 1095 363
unlock 0 1096 364
unlock 0 1098 368
throw 1 1099 369
return 1 1101 371
lock 0 1105 375
clear 0 1107 377
unlock 0 1108 378
unlock 0 1110 382
throw 1 1111 383
lock 0 1116 389
close 0 1118 391
unlock 0 1119 392
unlock 0 1121 396
throw 1 1122 397
return 1 0 402
assign 1 0 405
return 1 0 409
assign 1 0 412
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1604962015: return bem_sourceFileNameGet_0();
case 1310553601: return bem_toString_0();
case -732524867: return bem_tagGet_0();
case 1924413487: return bem_hashGet_0();
case -980884323: return bem_new_0();
case 1643609078: return bem_sizeGet_0();
case -1897026239: return bem_echo_0();
case -1584492961: return bem_copyContainer_0();
case -1757606239: return bem_containerGet_0();
case -1565549870: return bem_print_0();
case 1793221455: return bem_copy_0();
case -1226625126: return bem_once_0();
case -1465092891: return bem_getMap_0();
case 489788599: return bem_serializeContents_0();
case -1920531733: return bem_serializationIteratorGet_0();
case -856086754: return bem_isEmptyGet_0();
case -1535847383: return bem_toAny_0();
case 1150664853: return bem_create_0();
case -290041240: return bem_serializeToString_0();
case -520612795: return bem_clear_0();
case 2049066942: return bem_fieldIteratorGet_0();
case -846413213: return bem_lockGet_0();
case 2052709534: return bem_many_0();
case 194016774: return bem_iteratorGet_0();
case 1290371969: return bem_get_0();
case -525681067: return bem_classNameGet_0();
case 332981262: return bem_deserializeClassNameGet_0();
case -1827045033: return bem_close_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 959360624: return bem_otherType_1(bevd_0);
case -1021436824: return bem_sameType_1(bevd_0);
case 863435643: return bem_equals_1(bevd_0);
case 98332446: return bem_getAndClear_1(bevd_0);
case -1343499453: return bem_new_1(bevd_0);
case -145738070: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1617175076: return bem_has_1(bevd_0);
case -467299687: return bem_defined_1(bevd_0);
case 1693216688: return bem_sameClass_1(bevd_0);
case -853660490: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -425191892: return bem_put_1(bevd_0);
case 1360616895: return bem_delete_1(bevd_0);
case -380820495: return bem_addValue_1(bevd_0);
case 1868528499: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 257405303: return bem_copyTo_1(bevd_0);
case -517240107: return bem_get_1(bevd_0);
case -2104330508: return bem_sameObject_1(bevd_0);
case 2094292121: return bem_putReturn_1(bevd_0);
case 1998776126: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1966507736: return bem_undef_1(bevd_0);
case 420384947: return bem_def_1(bevd_0);
case -1834098557: return bem_notEquals_1(bevd_0);
case 1667577357: return bem_containerSet_1(bevd_0);
case 562081982: return bem_undefined_1(bevd_0);
case 386836188: return bem_otherClass_1(bevd_0);
case -1545437990: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 277046792: return bem_lockSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1035622269: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -495657566: return bem_delete_2(bevd_0, bevd_1);
case 557982604: return bem_putReturn_2(bevd_0, bevd_1);
case -371043039: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -423199848: return bem_has_2(bevd_0, bevd_1);
case -1240676558: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1274945910: return bem_getOrPut_2(bevd_0, bevd_1);
case -1957857497: return bem_put_2(bevd_0, bevd_1);
case 1325559256: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1895634211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 686918154: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -690585465: return bem_get_2(bevd_0, bevd_1);
case -145115514: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953892811: return bem_putIfAbsent_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -2080067234: return bem_put_3(bevd_0, bevd_1, bevd_2);
case -2067621373: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
