package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try /* Line: 579*/ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 581*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 584*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 590*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-127210429, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 592*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 595*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 602*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(1067006414, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 604*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 607*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 614*/ {
bevl_r = bevp_container.bemd_0(-7921691);
bevp_lock.bem_unlock_0();
} /* Line: 616*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 619*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 626*/ {
bevl_r = bevp_container.bemd_1(499249094, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 628*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 631*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 638*/ {
bevl_r = bevp_container.bemd_1(499249094, beva_key);
bevp_container.bemd_1(-1475795645, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 641*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 644*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 651*/ {
bevl_r = bevp_container.bemd_2(-1727573392, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 653*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 656*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 663*/ {
bevp_container.bemd_1(-1505656903, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 665*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 668*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 674*/ {
bevl_r = bevp_container.bemd_1(2139013885, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 676*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 679*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 686*/ {
bevp_container.bemd_1(2139013885, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 688*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 691*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 697*/ {
bevl_r = bevp_container.bemd_2(-632651049, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 699*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 702*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 709*/ {
bevp_container.bemd_2(-632651049, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 711*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 714*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 720*/ {
bevl_rc = bevp_container.bemd_3(128553165, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 722*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 725*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSet_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 732*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-204506259);
bevp_lock.bem_unlock_0();
} /* Line: 734*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 737*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 744*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(858559440);
bevp_lock.bem_unlock_0();
} /* Line: 746*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 749*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 756*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(2117147534, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 758*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 761*/
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 768*/ {
bevt_0_ta_ph = bevp_container.bemd_1(-127210429, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 769*/ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 770*/
 else /* Line: 771*/ {
bevp_container.bemd_2(-632651049, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 773*/
bevp_lock.bem_unlock_0();
} /* Line: 775*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 778*/
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 785*/ {
bevt_0_ta_ph = bevp_container.bemd_1(-127210429, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 786*/ {
bevl_result = bevp_container.bemd_1(499249094, beva_key);
} /* Line: 787*/
 else /* Line: 788*/ {
bevp_container.bemd_2(-632651049, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 790*/
bevp_lock.bem_unlock_0();
} /* Line: 792*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 795*/
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 802*/ {
bevp_container.bemd_3(1014701855, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 804*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 807*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 813*/ {
bevl_r = bevp_container.bemd_1(-1475795645, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 815*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 818*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 825*/ {
bevl_r = bevp_container.bemd_2(-2082720009, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 827*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 830*/
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 837*/ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-1876444336);
bevp_lock.bem_unlock_0();
} /* Line: 839*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 842*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 849*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(1962517262);
bevp_lock.bem_unlock_0();
} /* Line: 851*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 854*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 861*/ {
bevl_r = bevp_container.bemd_0(232491947);
bevp_lock.bem_unlock_0();
} /* Line: 863*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 866*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 873*/ {
bevp_container.bemd_0(1678057615);
bevp_lock.bem_unlock_0();
} /* Line: 875*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 878*/
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 884*/ {
bevp_container.bemd_0(624815613);
bevp_lock.bem_unlock_0();
} /* Line: 886*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 889*/
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {575, 578, 580, 581, 583, 584, 589, 591, 592, 594, 595, 597, 601, 603, 604, 606, 607, 609, 613, 615, 616, 618, 619, 621, 625, 627, 628, 630, 631, 633, 637, 639, 640, 641, 643, 644, 646, 650, 652, 653, 655, 656, 658, 662, 664, 665, 667, 668, 673, 675, 676, 678, 679, 681, 685, 687, 688, 690, 691, 696, 698, 699, 701, 702, 704, 708, 710, 711, 713, 714, 719, 721, 722, 724, 725, 727, 731, 733, 734, 736, 737, 739, 743, 745, 746, 748, 749, 751, 755, 757, 758, 760, 761, 763, 767, 769, 770, 772, 773, 775, 777, 778, 780, 784, 786, 787, 789, 790, 792, 794, 795, 797, 801, 803, 804, 806, 807, 812, 814, 815, 817, 818, 820, 824, 826, 827, 829, 830, 832, 836, 838, 839, 841, 842, 844, 848, 850, 851, 853, 854, 856, 860, 862, 863, 865, 866, 868, 872, 874, 875, 877, 878, 883, 885, 886, 888, 889, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 241, 243, 244, 248, 249, 251, 257, 259, 261, 264, 265, 267, 271, 272, 274, 280, 282, 284, 287, 288, 290, 294, 295, 297, 301, 303, 304, 308, 309, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 376, 378, 379, 383, 384, 386, 390, 392, 393, 397, 398, 404, 406, 407, 411, 412, 417, 420, 424, 427};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 575 17
new 0 575 17
lock 0 578 18
assign 1 580 20
unlock 0 581 21
unlock 0 583 25
throw 1 584 26
lock 0 589 33
assign 1 591 35
has 1 591 35
unlock 0 592 36
unlock 0 594 40
throw 1 595 41
return 1 597 43
lock 0 601 48
assign 1 603 50
has 2 603 50
unlock 0 604 51
unlock 0 606 55
throw 1 607 56
return 1 609 58
lock 0 613 63
assign 1 615 65
get 0 615 65
unlock 0 616 66
unlock 0 618 70
throw 1 619 71
return 1 621 73
lock 0 625 78
assign 1 627 80
get 1 627 80
unlock 0 628 81
unlock 0 630 85
throw 1 631 86
return 1 633 88
lock 0 637 93
assign 1 639 95
get 1 639 95
delete 1 640 96
unlock 0 641 97
unlock 0 643 101
throw 1 644 102
return 1 646 104
lock 0 650 109
assign 1 652 111
get 2 652 111
unlock 0 653 112
unlock 0 655 116
throw 1 656 117
return 1 658 119
lock 0 662 123
addValue 1 664 125
unlock 0 665 126
unlock 0 667 130
throw 1 668 131
lock 0 673 138
assign 1 675 140
put 1 675 140
unlock 0 676 141
unlock 0 678 145
throw 1 679 146
return 1 681 148
lock 0 685 152
put 1 687 154
unlock 0 688 155
unlock 0 690 159
throw 1 691 160
lock 0 696 167
assign 1 698 169
put 2 698 169
unlock 0 699 170
unlock 0 701 174
throw 1 702 175
return 1 704 177
lock 0 708 181
put 2 710 183
unlock 0 711 184
unlock 0 713 188
throw 1 714 189
lock 0 719 196
assign 1 721 198
testAndPut 3 721 198
unlock 0 722 199
unlock 0 724 203
throw 1 725 204
return 1 727 206
lock 0 731 211
assign 1 733 213
getSet 0 733 213
unlock 0 734 214
unlock 0 736 218
throw 1 737 219
return 1 739 221
lock 0 743 226
assign 1 745 228
getMap 0 745 228
unlock 0 746 229
unlock 0 748 233
throw 1 749 234
return 1 751 236
lock 0 755 241
assign 1 757 243
getMap 1 757 243
unlock 0 758 244
unlock 0 760 248
throw 1 761 249
return 1 763 251
lock 0 767 257
assign 1 769 259
has 1 769 259
assign 1 770 261
new 0 770 261
put 2 772 264
assign 1 773 265
new 0 773 265
unlock 0 775 267
unlock 0 777 271
throw 1 778 272
return 1 780 274
lock 0 784 280
assign 1 786 282
has 1 786 282
assign 1 787 284
get 1 787 284
put 2 789 287
assign 1 790 288
unlock 0 792 290
unlock 0 794 294
throw 1 795 295
return 1 797 297
lock 0 801 301
put 3 803 303
unlock 0 804 304
unlock 0 806 308
throw 1 807 309
lock 0 812 316
assign 1 814 318
delete 1 814 318
unlock 0 815 319
unlock 0 817 323
throw 1 818 324
return 1 820 326
lock 0 824 331
assign 1 826 333
delete 2 826 333
unlock 0 827 334
unlock 0 829 338
throw 1 830 339
return 1 832 341
lock 0 836 346
assign 1 838 348
sizeGet 0 838 348
unlock 0 839 349
unlock 0 841 353
throw 1 842 354
return 1 844 356
lock 0 848 361
assign 1 850 363
isEmptyGet 0 850 363
unlock 0 851 364
unlock 0 853 368
throw 1 854 369
return 1 856 371
lock 0 860 376
assign 1 862 378
copy 0 862 378
unlock 0 863 379
unlock 0 865 383
throw 1 866 384
return 1 868 386
lock 0 872 390
clear 0 874 392
unlock 0 875 393
unlock 0 877 397
throw 1 878 398
lock 0 883 404
close 0 885 406
unlock 0 886 407
unlock 0 888 411
throw 1 889 412
return 1 0 417
assign 1 0 420
return 1 0 424
assign 1 0 427
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -204506259: return bem_getSet_0();
case -1362125758: return bem_copyContainer_0();
case 858559440: return bem_getMap_0();
case 232491947: return bem_copy_0();
case 423199807: return bem_print_0();
case 624815613: return bem_close_0();
case -351888968: return bem_lockGet_0();
case -418254990: return bem_new_0();
case 1004934278: return bem_create_0();
case 1962517262: return bem_isEmptyGet_0();
case -1567950291: return bem_toString_0();
case -2013190222: return bem_iteratorGet_0();
case 1678057615: return bem_clear_0();
case -1876444336: return bem_sizeGet_0();
case -7921691: return bem_get_0();
case -2003946884: return bem_containerGet_0();
case -317313398: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1390305309: return bem_containerSet_1(bevd_0);
case 499249094: return bem_get_1(bevd_0);
case 2117147534: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -885417549: return bem_new_1(bevd_0);
case -1505656903: return bem_addValue_1(bevd_0);
case 1201794665: return bem_notEquals_1(bevd_0);
case -1475795645: return bem_delete_1(bevd_0);
case -1485521647: return bem_copyTo_1(bevd_0);
case 371317702: return bem_def_1(bevd_0);
case 572943285: return bem_lockSet_1(bevd_0);
case -393818298: return bem_equals_1(bevd_0);
case 2139013885: return bem_put_1(bevd_0);
case 2140534245: return bem_putReturn_1(bevd_0);
case 446734239: return bem_undef_1(bevd_0);
case -127210429: return bem_has_1(bevd_0);
case -2104374144: return bem_getAndClear_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1372095061: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 4109253: return bem_putReturn_2(bevd_0, bevd_1);
case 1067006414: return bem_has_2(bevd_0, bevd_1);
case -632651049: return bem_put_2(bevd_0, bevd_1);
case -2138251913: return bem_getOrPut_2(bevd_0, bevd_1);
case 4693599: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1727573392: return bem_get_2(bevd_0, bevd_1);
case -393719052: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -564165706: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1306851555: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -2082720009: return bem_delete_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1014701855: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 128553165: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
