package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 882 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 884 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 887 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 893 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-934816238, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 895 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 898 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 905 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(1427009897, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 907 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 910 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 917 */ {
bevl_r = bevp_container.bemd_0(50192261);
bevp_lock.bem_unlock_0();
} /* Line: 919 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 922 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 929 */ {
bevl_r = bevp_container.bemd_1(-1230021919, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 931 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 934 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 941 */ {
bevl_r = bevp_container.bemd_1(-1230021919, beva_key);
bevp_container.bemd_1(1846521136, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 944 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 947 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 954 */ {
bevl_r = bevp_container.bemd_2(1024949629, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 956 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 959 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 966 */ {
bevp_container.bemd_1(544331812, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 968 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 971 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 977 */ {
bevl_r = bevp_container.bemd_1(1033595679, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 979 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 982 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 989 */ {
bevp_container.bemd_1(1033595679, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 991 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 994 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1000 */ {
bevl_r = bevp_container.bemd_2(560517072, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1002 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1005 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1012 */ {
bevp_container.bemd_2(560517072, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1014 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1017 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1023 */ {
bevl_rc = bevp_container.bemd_3(-1718802466, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1025 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1028 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSet_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1035 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1809705956);
bevp_lock.bem_unlock_0();
} /* Line: 1037 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1040 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1047 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(603341290);
bevp_lock.bem_unlock_0();
} /* Line: 1049 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1052 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1059 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-1465702964, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 1061 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1064 */
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1071 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-934816238, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1072 */ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 1073 */
 else  /* Line: 1074 */ {
bevp_container.bemd_2(560517072, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 1076 */
bevp_lock.bem_unlock_0();
} /* Line: 1078 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1081 */
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1088 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-934816238, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1089 */ {
bevl_result = bevp_container.bemd_1(-1230021919, beva_key);
} /* Line: 1090 */
 else  /* Line: 1091 */ {
bevp_container.bemd_2(560517072, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1093 */
bevp_lock.bem_unlock_0();
} /* Line: 1095 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1098 */
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1105 */ {
bevp_container.bemd_3(1559650787, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1107 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1110 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1116 */ {
bevl_r = bevp_container.bemd_1(1846521136, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1118 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1121 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1128 */ {
bevl_r = bevp_container.bemd_2(-899665012, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1130 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1133 */
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1140 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-1479689362);
bevp_lock.bem_unlock_0();
} /* Line: 1142 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1145 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1152 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(1863016051);
bevp_lock.bem_unlock_0();
} /* Line: 1154 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1157 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1164 */ {
bevl_r = bevp_container.bemd_0(-1406264904);
bevp_lock.bem_unlock_0();
} /* Line: 1166 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1169 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1176 */ {
bevp_container.bemd_0(825365512);
bevp_lock.bem_unlock_0();
} /* Line: 1178 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1181 */
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1187 */ {
bevp_container.bemd_0(-1342163691);
bevp_lock.bem_unlock_0();
} /* Line: 1189 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1192 */
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {878, 881, 883, 884, 886, 887, 892, 894, 895, 897, 898, 900, 904, 906, 907, 909, 910, 912, 916, 918, 919, 921, 922, 924, 928, 930, 931, 933, 934, 936, 940, 942, 943, 944, 946, 947, 949, 953, 955, 956, 958, 959, 961, 965, 967, 968, 970, 971, 976, 978, 979, 981, 982, 984, 988, 990, 991, 993, 994, 999, 1001, 1002, 1004, 1005, 1007, 1011, 1013, 1014, 1016, 1017, 1022, 1024, 1025, 1027, 1028, 1030, 1034, 1036, 1037, 1039, 1040, 1042, 1046, 1048, 1049, 1051, 1052, 1054, 1058, 1060, 1061, 1063, 1064, 1066, 1070, 1072, 1073, 1075, 1076, 1078, 1080, 1081, 1083, 1087, 1089, 1090, 1092, 1093, 1095, 1097, 1098, 1100, 1104, 1106, 1107, 1109, 1110, 1115, 1117, 1118, 1120, 1121, 1123, 1127, 1129, 1130, 1132, 1133, 1135, 1139, 1141, 1142, 1144, 1145, 1147, 1151, 1153, 1154, 1156, 1157, 1159, 1163, 1165, 1166, 1168, 1169, 1171, 1175, 1177, 1178, 1180, 1181, 1186, 1188, 1189, 1191, 1192, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 241, 243, 244, 248, 249, 251, 257, 259, 261, 264, 265, 267, 271, 272, 274, 280, 282, 284, 287, 288, 290, 294, 295, 297, 301, 303, 304, 308, 309, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 376, 378, 379, 383, 384, 386, 390, 392, 393, 397, 398, 404, 406, 407, 411, 412, 417, 420, 423, 427, 431, 434, 437, 441};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 878 17
new 0 878 17
lock 0 881 18
assign 1 883 20
unlock 0 884 21
unlock 0 886 25
throw 1 887 26
lock 0 892 33
assign 1 894 35
has 1 894 35
unlock 0 895 36
unlock 0 897 40
throw 1 898 41
return 1 900 43
lock 0 904 48
assign 1 906 50
has 2 906 50
unlock 0 907 51
unlock 0 909 55
throw 1 910 56
return 1 912 58
lock 0 916 63
assign 1 918 65
get 0 918 65
unlock 0 919 66
unlock 0 921 70
throw 1 922 71
return 1 924 73
lock 0 928 78
assign 1 930 80
get 1 930 80
unlock 0 931 81
unlock 0 933 85
throw 1 934 86
return 1 936 88
lock 0 940 93
assign 1 942 95
get 1 942 95
delete 1 943 96
unlock 0 944 97
unlock 0 946 101
throw 1 947 102
return 1 949 104
lock 0 953 109
assign 1 955 111
get 2 955 111
unlock 0 956 112
unlock 0 958 116
throw 1 959 117
return 1 961 119
lock 0 965 123
addValue 1 967 125
unlock 0 968 126
unlock 0 970 130
throw 1 971 131
lock 0 976 138
assign 1 978 140
put 1 978 140
unlock 0 979 141
unlock 0 981 145
throw 1 982 146
return 1 984 148
lock 0 988 152
put 1 990 154
unlock 0 991 155
unlock 0 993 159
throw 1 994 160
lock 0 999 167
assign 1 1001 169
put 2 1001 169
unlock 0 1002 170
unlock 0 1004 174
throw 1 1005 175
return 1 1007 177
lock 0 1011 181
put 2 1013 183
unlock 0 1014 184
unlock 0 1016 188
throw 1 1017 189
lock 0 1022 196
assign 1 1024 198
testAndPut 3 1024 198
unlock 0 1025 199
unlock 0 1027 203
throw 1 1028 204
return 1 1030 206
lock 0 1034 211
assign 1 1036 213
getSet 0 1036 213
unlock 0 1037 214
unlock 0 1039 218
throw 1 1040 219
return 1 1042 221
lock 0 1046 226
assign 1 1048 228
getMap 0 1048 228
unlock 0 1049 229
unlock 0 1051 233
throw 1 1052 234
return 1 1054 236
lock 0 1058 241
assign 1 1060 243
getMap 1 1060 243
unlock 0 1061 244
unlock 0 1063 248
throw 1 1064 249
return 1 1066 251
lock 0 1070 257
assign 1 1072 259
has 1 1072 259
assign 1 1073 261
new 0 1073 261
put 2 1075 264
assign 1 1076 265
new 0 1076 265
unlock 0 1078 267
unlock 0 1080 271
throw 1 1081 272
return 1 1083 274
lock 0 1087 280
assign 1 1089 282
has 1 1089 282
assign 1 1090 284
get 1 1090 284
put 2 1092 287
assign 1 1093 288
unlock 0 1095 290
unlock 0 1097 294
throw 1 1098 295
return 1 1100 297
lock 0 1104 301
put 3 1106 303
unlock 0 1107 304
unlock 0 1109 308
throw 1 1110 309
lock 0 1115 316
assign 1 1117 318
delete 1 1117 318
unlock 0 1118 319
unlock 0 1120 323
throw 1 1121 324
return 1 1123 326
lock 0 1127 331
assign 1 1129 333
delete 2 1129 333
unlock 0 1130 334
unlock 0 1132 338
throw 1 1133 339
return 1 1135 341
lock 0 1139 346
assign 1 1141 348
sizeGet 0 1141 348
unlock 0 1142 349
unlock 0 1144 353
throw 1 1145 354
return 1 1147 356
lock 0 1151 361
assign 1 1153 363
isEmptyGet 0 1153 363
unlock 0 1154 364
unlock 0 1156 368
throw 1 1157 369
return 1 1159 371
lock 0 1163 376
assign 1 1165 378
copy 0 1165 378
unlock 0 1166 379
unlock 0 1168 383
throw 1 1169 384
return 1 1171 386
lock 0 1175 390
clear 0 1177 392
unlock 0 1178 393
unlock 0 1180 397
throw 1 1181 398
lock 0 1186 404
close 0 1188 406
unlock 0 1189 407
unlock 0 1191 411
throw 1 1192 412
return 1 0 417
return 1 0 420
assign 1 0 423
assign 1 0 427
return 1 0 431
return 1 0 434
assign 1 0 437
assign 1 0 441
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2067410665: return bem_containerGetDirect_0();
case -621270081: return bem_new_0();
case -579194210: return bem_iteratorGet_0();
case -1406264904: return bem_copy_0();
case -1809705956: return bem_getSet_0();
case -980602152: return bem_sourceFileNameGet_0();
case 32824861: return bem_containerGet_0();
case 11313755: return bem_echo_0();
case 1476265575: return bem_toAny_0();
case 825365512: return bem_clear_0();
case -1295312086: return bem_lockGetDirect_0();
case -1430069919: return bem_serializeContents_0();
case 1568711247: return bem_fieldIteratorGet_0();
case 577869439: return bem_serializeToString_0();
case 1943121549: return bem_copyContainer_0();
case -1247596051: return bem_lockGet_0();
case -1682958828: return bem_tagGet_0();
case 1863016051: return bem_isEmptyGet_0();
case -1342163691: return bem_close_0();
case 2079582721: return bem_toString_0();
case 572016682: return bem_serializationIteratorGet_0();
case -1791746868: return bem_print_0();
case 603341290: return bem_getMap_0();
case 448246445: return bem_fieldNamesGet_0();
case -1045898755: return bem_classNameGet_0();
case -1479689362: return bem_sizeGet_0();
case -165278261: return bem_hashGet_0();
case -1489022328: return bem_once_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case -1168657718: return bem_create_0();
case 334571614: return bem_many_0();
case 50192261: return bem_get_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2101147682: return bem_lockSetDirect_1(bevd_0);
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1230021919: return bem_get_1(bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case -1465702964: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1645812903: return bem_containerSet_1(bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case 874944338: return bem_getAndClear_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
case -740754659: return bem_putReturn_1(bevd_0);
case 1033595679: return bem_put_1(bevd_0);
case 544331812: return bem_addValue_1(bevd_0);
case 1846521136: return bem_delete_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case -32388888: return bem_lockSet_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1171039333: return bem_new_1(bevd_0);
case -1140199681: return bem_containerSetDirect_1(bevd_0);
case -934816238: return bem_has_1(bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 560517072: return bem_put_2(bevd_0, bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 181799299: return bem_getOrPut_2(bevd_0, bevd_1);
case 1762506122: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 211774317: return bem_putReturn_2(bevd_0, bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1427009897: return bem_has_2(bevd_0, bevd_1);
case -899665012: return bem_delete_2(bevd_0, bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1024949629: return bem_get_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1559650787: return bem_put_3(bevd_0, bevd_1, bevd_2);
case -1718802466: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
