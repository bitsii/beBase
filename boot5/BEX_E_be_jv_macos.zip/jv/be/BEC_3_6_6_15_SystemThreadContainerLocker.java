package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try /* Line: 620*/ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 622*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 625*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 631*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-1930347765, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 633*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 636*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 643*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-1351962685, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 645*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 648*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 655*/ {
bevl_r = bevp_container.bemd_0(-1206415987);
bevp_lock.bem_unlock_0();
} /* Line: 657*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 660*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 667*/ {
bevl_r = bevp_container.bemd_1(585709857, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 669*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 672*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 679*/ {
bevl_r = bevp_container.bemd_1(585709857, beva_key);
bevp_container.bemd_1(-355852240, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 682*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 685*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 692*/ {
bevl_r = bevp_container.bemd_2(-1987671529, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 694*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 697*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 704*/ {
bevp_container.bemd_1(-1100739433, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 706*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 709*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 715*/ {
bevl_r = bevp_container.bemd_1(1230715635, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 717*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 720*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 727*/ {
bevp_container.bemd_1(1230715635, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 729*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 732*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 738*/ {
bevl_r = bevp_container.bemd_2(-1198500054, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 740*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 743*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 750*/ {
bevp_container.bemd_2(-1198500054, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 752*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 755*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 761*/ {
bevl_rc = bevp_container.bemd_3(312596376, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 763*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 766*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSet_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 773*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-18548019);
bevp_lock.bem_unlock_0();
} /* Line: 775*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 778*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 785*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(772306571);
bevp_lock.bem_unlock_0();
} /* Line: 787*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 790*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 797*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(552800599, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 799*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 802*/
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 809*/ {
bevt_0_ta_ph = bevp_container.bemd_1(-1930347765, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 810*/ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 811*/
 else /* Line: 812*/ {
bevp_container.bemd_2(-1198500054, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 814*/
bevp_lock.bem_unlock_0();
} /* Line: 816*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 819*/
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 826*/ {
bevt_0_ta_ph = bevp_container.bemd_1(-1930347765, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 827*/ {
bevl_result = bevp_container.bemd_1(585709857, beva_key);
} /* Line: 828*/
 else /* Line: 829*/ {
bevp_container.bemd_2(-1198500054, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 831*/
bevp_lock.bem_unlock_0();
} /* Line: 833*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 836*/
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 843*/ {
bevp_container.bemd_3(52063249, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 845*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 848*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 854*/ {
bevl_r = bevp_container.bemd_1(-355852240, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 856*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 859*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 866*/ {
bevl_r = bevp_container.bemd_2(-742188603, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 868*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 871*/
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 878*/ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-695713841);
bevp_lock.bem_unlock_0();
} /* Line: 880*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 883*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 890*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(1039765787);
bevp_lock.bem_unlock_0();
} /* Line: 892*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 895*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 902*/ {
bevl_r = bevp_container.bemd_0(350812655);
bevp_lock.bem_unlock_0();
} /* Line: 904*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 907*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 914*/ {
bevp_container.bemd_0(829958257);
bevp_lock.bem_unlock_0();
} /* Line: 916*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 919*/
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 925*/ {
bevp_container.bemd_0(-1104424295);
bevp_lock.bem_unlock_0();
} /* Line: 927*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 930*/
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {616, 619, 621, 622, 624, 625, 630, 632, 633, 635, 636, 638, 642, 644, 645, 647, 648, 650, 654, 656, 657, 659, 660, 662, 666, 668, 669, 671, 672, 674, 678, 680, 681, 682, 684, 685, 687, 691, 693, 694, 696, 697, 699, 703, 705, 706, 708, 709, 714, 716, 717, 719, 720, 722, 726, 728, 729, 731, 732, 737, 739, 740, 742, 743, 745, 749, 751, 752, 754, 755, 760, 762, 763, 765, 766, 768, 772, 774, 775, 777, 778, 780, 784, 786, 787, 789, 790, 792, 796, 798, 799, 801, 802, 804, 808, 810, 811, 813, 814, 816, 818, 819, 821, 825, 827, 828, 830, 831, 833, 835, 836, 838, 842, 844, 845, 847, 848, 853, 855, 856, 858, 859, 861, 865, 867, 868, 870, 871, 873, 877, 879, 880, 882, 883, 885, 889, 891, 892, 894, 895, 897, 901, 903, 904, 906, 907, 909, 913, 915, 916, 918, 919, 924, 926, 927, 929, 930, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 241, 243, 244, 248, 249, 251, 257, 259, 261, 264, 265, 267, 271, 272, 274, 280, 282, 284, 287, 288, 290, 294, 295, 297, 301, 303, 304, 308, 309, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 376, 378, 379, 383, 384, 386, 390, 392, 393, 397, 398, 404, 406, 407, 411, 412, 417, 420, 423, 427, 431, 434, 437, 441};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 616 17
new 0 616 17
lock 0 619 18
assign 1 621 20
unlock 0 622 21
unlock 0 624 25
throw 1 625 26
lock 0 630 33
assign 1 632 35
has 1 632 35
unlock 0 633 36
unlock 0 635 40
throw 1 636 41
return 1 638 43
lock 0 642 48
assign 1 644 50
has 2 644 50
unlock 0 645 51
unlock 0 647 55
throw 1 648 56
return 1 650 58
lock 0 654 63
assign 1 656 65
get 0 656 65
unlock 0 657 66
unlock 0 659 70
throw 1 660 71
return 1 662 73
lock 0 666 78
assign 1 668 80
get 1 668 80
unlock 0 669 81
unlock 0 671 85
throw 1 672 86
return 1 674 88
lock 0 678 93
assign 1 680 95
get 1 680 95
delete 1 681 96
unlock 0 682 97
unlock 0 684 101
throw 1 685 102
return 1 687 104
lock 0 691 109
assign 1 693 111
get 2 693 111
unlock 0 694 112
unlock 0 696 116
throw 1 697 117
return 1 699 119
lock 0 703 123
addValue 1 705 125
unlock 0 706 126
unlock 0 708 130
throw 1 709 131
lock 0 714 138
assign 1 716 140
put 1 716 140
unlock 0 717 141
unlock 0 719 145
throw 1 720 146
return 1 722 148
lock 0 726 152
put 1 728 154
unlock 0 729 155
unlock 0 731 159
throw 1 732 160
lock 0 737 167
assign 1 739 169
put 2 739 169
unlock 0 740 170
unlock 0 742 174
throw 1 743 175
return 1 745 177
lock 0 749 181
put 2 751 183
unlock 0 752 184
unlock 0 754 188
throw 1 755 189
lock 0 760 196
assign 1 762 198
testAndPut 3 762 198
unlock 0 763 199
unlock 0 765 203
throw 1 766 204
return 1 768 206
lock 0 772 211
assign 1 774 213
getSet 0 774 213
unlock 0 775 214
unlock 0 777 218
throw 1 778 219
return 1 780 221
lock 0 784 226
assign 1 786 228
getMap 0 786 228
unlock 0 787 229
unlock 0 789 233
throw 1 790 234
return 1 792 236
lock 0 796 241
assign 1 798 243
getMap 1 798 243
unlock 0 799 244
unlock 0 801 248
throw 1 802 249
return 1 804 251
lock 0 808 257
assign 1 810 259
has 1 810 259
assign 1 811 261
new 0 811 261
put 2 813 264
assign 1 814 265
new 0 814 265
unlock 0 816 267
unlock 0 818 271
throw 1 819 272
return 1 821 274
lock 0 825 280
assign 1 827 282
has 1 827 282
assign 1 828 284
get 1 828 284
put 2 830 287
assign 1 831 288
unlock 0 833 290
unlock 0 835 294
throw 1 836 295
return 1 838 297
lock 0 842 301
put 3 844 303
unlock 0 845 304
unlock 0 847 308
throw 1 848 309
lock 0 853 316
assign 1 855 318
delete 1 855 318
unlock 0 856 319
unlock 0 858 323
throw 1 859 324
return 1 861 326
lock 0 865 331
assign 1 867 333
delete 2 867 333
unlock 0 868 334
unlock 0 870 338
throw 1 871 339
return 1 873 341
lock 0 877 346
assign 1 879 348
sizeGet 0 879 348
unlock 0 880 349
unlock 0 882 353
throw 1 883 354
return 1 885 356
lock 0 889 361
assign 1 891 363
isEmptyGet 0 891 363
unlock 0 892 364
unlock 0 894 368
throw 1 895 369
return 1 897 371
lock 0 901 376
assign 1 903 378
copy 0 903 378
unlock 0 904 379
unlock 0 906 383
throw 1 907 384
return 1 909 386
lock 0 913 390
clear 0 915 392
unlock 0 916 393
unlock 0 918 397
throw 1 919 398
lock 0 924 404
close 0 926 406
unlock 0 927 407
unlock 0 929 411
throw 1 930 412
return 1 0 417
return 1 0 420
assign 1 0 423
assign 1 0 427
return 1 0 431
return 1 0 434
assign 1 0 437
assign 1 0 441
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1039765787: return bem_isEmptyGet_0();
case 711936274: return bem_lockGet_0();
case 1393634620: return bem_serializeToString_0();
case 1883135910: return bem_containerGetDirect_0();
case 873828646: return bem_deserializeClassNameGet_0();
case -157777737: return bem_fieldIteratorGet_0();
case 785161348: return bem_fieldNamesGet_0();
case -281350604: return bem_serializeContents_0();
case -18548019: return bem_getSet_0();
case 1150015978: return bem_copyContainer_0();
case 1005443364: return bem_create_0();
case -2131640624: return bem_new_0();
case 1587133120: return bem_classNameGet_0();
case 969994032: return bem_serializationIteratorGet_0();
case 2113534779: return bem_hashGet_0();
case 1438534895: return bem_lockGetDirect_0();
case 1645989341: return bem_iteratorGet_0();
case -695713841: return bem_sizeGet_0();
case 1464527658: return bem_toString_0();
case -1206415987: return bem_get_0();
case 2071875109: return bem_sourceFileNameGet_0();
case 566573794: return bem_tagGet_0();
case 239077256: return bem_print_0();
case 829958257: return bem_clear_0();
case 350812655: return bem_copy_0();
case 772306571: return bem_getMap_0();
case -1104424295: return bem_close_0();
case 1864861581: return bem_echo_0();
case -2068272454: return bem_containerGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -431429582: return bem_containerSetDirect_1(bevd_0);
case -355852240: return bem_delete_1(bevd_0);
case -396283576: return bem_undef_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case -1930347765: return bem_has_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case 1866840560: return bem_containerSet_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -1581230672: return bem_lockSet_1(bevd_0);
case 1230715635: return bem_put_1(bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case -1353668075: return bem_new_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 552800599: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1567595449: return bem_putReturn_1(bevd_0);
case 1860524531: return bem_lockSetDirect_1(bevd_0);
case -1100739433: return bem_addValue_1(bevd_0);
case 895717180: return bem_getAndClear_1(bevd_0);
case 585709857: return bem_get_1(bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1198500054: return bem_put_2(bevd_0, bevd_1);
case -1987671529: return bem_get_2(bevd_0, bevd_1);
case -1351962685: return bem_has_2(bevd_0, bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1170432659: return bem_putReturn_2(bevd_0, bevd_1);
case 1020337166: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -742188603: return bem_delete_2(bevd_0, bevd_1);
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 258050706: return bem_getOrPut_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 312596376: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
case 52063249: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
