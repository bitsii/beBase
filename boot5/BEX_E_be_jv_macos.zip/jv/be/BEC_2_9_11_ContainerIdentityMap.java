package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {91, 91, 95, 96, 97, 98, 99, 100};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 11, 15, 16, 17, 18, 19, 20};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 91 10
new 0 91 10
new 1 91 11
assign 1 95 15
new 1 95 15
assign 1 96 16
assign 1 97 17
new 0 97 17
assign 1 98 18
new 0 98 18
assign 1 99 19
new 0 99 19
assign 1 100 20
new 0 100 20
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 301206433: return bem_echo_0();
case 1463342304: return bem_moduGet_0();
case 117408473: return bem_valuesGet_0();
case 458508116: return bem_clear_0();
case 1905279649: return bem_baseNodeGet_0();
case -803388239: return bem_deserializeClassNameGet_0();
case 1314576819: return bem_print_0();
case 2033657832: return bem_hashGet_0();
case -1980796873: return bem_copy_0();
case -70500062: return bem_fieldIteratorGet_0();
case 366164054: return bem_serializeContents_0();
case 1732876397: return bem_serializationIteratorGet_0();
case 737771364: return bem_toString_0();
case 1452879382: return bem_sourceFileNameGet_0();
case -420235024: return bem_classNameGet_0();
case 1904009362: return bem_valueIteratorGet_0();
case -1866917929: return bem_serializeToString_0();
case -1790259515: return bem_slotsGet_0();
case -1936050782: return bem_setIteratorGet_0();
case -1387659607: return bem_notEmptyGet_0();
case -302965453: return bem_tagGet_0();
case 1222310146: return bem_many_0();
case 482356666: return bem_toAny_0();
case 80522273: return bem_innerPutAddedGet_0();
case 1023783415: return bem_create_0();
case -255380110: return bem_nodeIteratorGet_0();
case 662260918: return bem_mapIteratorGet_0();
case 1775715094: return bem_once_0();
case 997723391: return bem_iteratorGet_0();
case -889572126: return bem_relGet_0();
case 828630715: return bem_keyIteratorGet_0();
case -1581807895: return bem_keysGet_0();
case 1740522405: return bem_sizeGet_0();
case -1841967863: return bem_keyValueIteratorGet_0();
case 1695672372: return bem_multiGet_0();
case -652878848: return bem_nodesGet_0();
case 737353003: return bem_new_0();
case 1968685700: return bem_isEmptyGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1210677960: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1035846111: return bem_multiSet_1(bevd_0);
case 1235111255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 721039721: return bem_get_1(bevd_0);
case 1452810576: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1458727376: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -396768715: return bem_addValue_1(bevd_0);
case 235706821: return bem_defined_1(bevd_0);
case 1259583334: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1086156485: return bem_moduSet_1(bevd_0);
case -369272378: return bem_undefined_1(bevd_0);
case 228693515: return bem_notEquals_1(bevd_0);
case 415710220: return bem_put_1(bevd_0);
case 1178034963: return bem_delete_1(bevd_0);
case 933808622: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 218513249: return bem_innerPutAddedSet_1(bevd_0);
case 808158717: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 439216438: return bem_has_1(bevd_0);
case 1735205112: return bem_sameType_1(bevd_0);
case 1940225088: return bem_sameClass_1(bevd_0);
case -1112750632: return bem_otherType_1(bevd_0);
case -1732568943: return bem_sameObject_1(bevd_0);
case 1820711442: return bem_sizeSet_1(bevd_0);
case 1732014863: return bem_equals_1(bevd_0);
case 254712574: return bem_def_1(bevd_0);
case -1691749788: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -10325606: return bem_undef_1(bevd_0);
case 1107846755: return bem_otherClass_1(bevd_0);
case 1261512952: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -863382240: return bem_baseNodeSet_1(bevd_0);
case -2040539499: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 935012977: return bem_slotsSet_1(bevd_0);
case -819601996: return bem_relSet_1(bevd_0);
case -2064575716: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1078688343: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1437812444: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -244320202: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -164742720: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -735369440: return bem_put_2(bevd_0, bevd_1);
case -1990568085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815656517: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1747848637: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -303274357: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -70659423: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1172266394: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
}
