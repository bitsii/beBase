package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {90, 90, 94, 95, 96, 97, 98, 99};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 90 13
new 0 90 13
new 1 90 14
assign 1 94 18
new 1 94 18
assign 1 95 19
assign 1 96 20
new 0 96 20
assign 1 97 21
new 0 97 21
assign 1 98 22
new 0 98 22
assign 1 99 23
new 0 99 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1544637441: return bem_fieldIteratorGet_0();
case -916808790: return bem_serializeToString_0();
case 1479217845: return bem_keyValueIteratorGet_0();
case -1506338509: return bem_setIteratorGet_0();
case -1440519528: return bem_new_0();
case 1516528362: return bem_copy_0();
case -352222734: return bem_echo_0();
case 557530926: return bem_multiGet_0();
case -1857169421: return bem_print_0();
case -1019129421: return bem_iteratorGet_0();
case 1256493526: return bem_create_0();
case 1866349269: return bem_moduGet_0();
case 811385600: return bem_relGet_0();
case 561102070: return bem_valuesGet_0();
case 1966604989: return bem_deserializeClassNameGet_0();
case 415444144: return bem_many_0();
case 1977268733: return bem_toAny_0();
case 1640160430: return bem_serializationIteratorGet_0();
case -1412029079: return bem_multiGetDirect_0();
case -722651638: return bem_clear_0();
case 675812520: return bem_valueIteratorGet_0();
case 6718322: return bem_sizeGet_0();
case -807375234: return bem_slotsGetDirect_0();
case -1304009809: return bem_isEmptyGet_0();
case 2108053342: return bem_innerPutAddedGet_0();
case -1138165086: return bem_sizeGetDirect_0();
case -1459660688: return bem_once_0();
case 764111846: return bem_classNameGet_0();
case 1985043632: return bem_nodesGet_0();
case 339749199: return bem_slotsGet_0();
case -2027075098: return bem_sourceFileNameGet_0();
case 1464556610: return bem_serializeContents_0();
case 1387201420: return bem_moduGetDirect_0();
case -212244867: return bem_nodeIteratorGet_0();
case 647733846: return bem_hashGet_0();
case -1322750582: return bem_fieldNamesGet_0();
case -902897826: return bem_baseNodeGetDirect_0();
case -427250910: return bem_notEmptyGet_0();
case 810516096: return bem_tagGet_0();
case -1287141517: return bem_innerPutAddedGetDirect_0();
case -683427380: return bem_mapIteratorGet_0();
case 159270674: return bem_keysGet_0();
case -2042019182: return bem_toString_0();
case 174742642: return bem_relGetDirect_0();
case 1555256264: return bem_baseNodeGet_0();
case 839438120: return bem_keyIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1451816788: return bem_otherType_1(bevd_0);
case -882863317: return bem_put_1(bevd_0);
case -1066262854: return bem_copyTo_1(bevd_0);
case -1192484058: return bem_baseNodeSet_1(bevd_0);
case 1134076070: return bem_multiSet_1(bevd_0);
case -695845290: return bem_baseNodeSetDirect_1(bevd_0);
case -2113151813: return bem_otherClass_1(bevd_0);
case 1686689499: return bem_sameType_1(bevd_0);
case -615053439: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -812482700: return bem_innerPutAddedSetDirect_1(bevd_0);
case 129664577: return bem_undefined_1(bevd_0);
case 858949566: return bem_sameObject_1(bevd_0);
case 1149328783: return bem_equals_1(bevd_0);
case 1083845207: return bem_slotsSet_1(bevd_0);
case -1103921791: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -940731965: return bem_sizeSet_1(bevd_0);
case -1726382580: return bem_undef_1(bevd_0);
case -1142216722: return bem_moduSetDirect_1(bevd_0);
case -1059491571: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -635052720: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -62499290: return bem_notEquals_1(bevd_0);
case 94845335: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 173437066: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -816615815: return bem_has_1(bevd_0);
case 100834532: return bem_moduSet_1(bevd_0);
case 423398009: return bem_delete_1(bevd_0);
case -1884560238: return bem_sameClass_1(bevd_0);
case -1693595005: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1303995883: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1529930548: return bem_def_1(bevd_0);
case -1115611450: return bem_sizeSetDirect_1(bevd_0);
case 456604916: return bem_defined_1(bevd_0);
case 1053633682: return bem_slotsSetDirect_1(bevd_0);
case -1283257515: return bem_innerPutAddedSet_1(bevd_0);
case 411249313: return bem_relSetDirect_1(bevd_0);
case -416017260: return bem_addValue_1(bevd_0);
case 222854188: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1779998503: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 760073212: return bem_multiSetDirect_1(bevd_0);
case 1616737436: return bem_relSet_1(bevd_0);
case -1289225920: return bem_get_1(bevd_0);
case 364924780: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -840184945: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1393445392: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2113325337: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1732137967: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1058450326: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1752849240: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1337367239: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 572204899: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -331779046: return bem_put_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1219768660: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
