package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {90, 90, 94, 95, 96, 97, 98, 99};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 90 13
new 0 90 13
new 1 90 14
assign 1 94 18
new 1 94 18
assign 1 95 19
assign 1 96 20
new 0 96 20
assign 1 97 21
new 0 97 21
assign 1 98 22
new 0 98 22
assign 1 99 23
new 0 99 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1660601909: return bem_slotsGetDirect_0();
case 797736664: return bem_valueIteratorGet_0();
case 1609612359: return bem_echo_0();
case -1285638795: return bem_baseNodeGet_0();
case 556090396: return bem_sourceFileNameGet_0();
case -165115142: return bem_keysGet_0();
case -353659624: return bem_mapIteratorGet_0();
case -1564975844: return bem_serializeContents_0();
case 1940548896: return bem_moduGet_0();
case 582014812: return bem_valuesGet_0();
case -115369053: return bem_isEmptyGet_0();
case -1714224723: return bem_sizeGetDirect_0();
case 916011301: return bem_baseNodeGetDirect_0();
case 18288957: return bem_relGet_0();
case -811046848: return bem_copy_0();
case -2045843113: return bem_sizeGet_0();
case 239813980: return bem_moduGetDirect_0();
case 937514229: return bem_nodeIteratorGet_0();
case -1535878537: return bem_setIteratorGet_0();
case 1132429880: return bem_tagGet_0();
case 1760326959: return bem_relGetDirect_0();
case -373878952: return bem_innerPutAddedGetDirect_0();
case -739204631: return bem_keyValueIteratorGet_0();
case 432179744: return bem_fieldNamesGet_0();
case -1812965558: return bem_fieldIteratorGet_0();
case 138302413: return bem_new_0();
case -1747597055: return bem_create_0();
case 712783465: return bem_hashGet_0();
case -819923642: return bem_nodesGet_0();
case 1267631579: return bem_serializationIteratorGet_0();
case 67700549: return bem_classNameGet_0();
case -854322554: return bem_notEmptyGet_0();
case 178019168: return bem_toString_0();
case 1176322821: return bem_multiGet_0();
case -521707684: return bem_slotsGet_0();
case -2106036149: return bem_deserializeClassNameGet_0();
case 1382646074: return bem_innerPutAddedGet_0();
case 2118953440: return bem_keyIteratorGet_0();
case 2036051475: return bem_iteratorGet_0();
case -1627734356: return bem_serializeToString_0();
case 478950400: return bem_print_0();
case 1932755778: return bem_multiGetDirect_0();
case 1401397040: return bem_clear_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 606870566: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1839912387: return bem_relSetDirect_1(bevd_0);
case -60802666: return bem_otherClass_1(bevd_0);
case 300457019: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1611934182: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 465594002: return bem_def_1(bevd_0);
case -1084952852: return bem_undef_1(bevd_0);
case -738053017: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -2029731919: return bem_has_1(bevd_0);
case -1355759120: return bem_moduSetDirect_1(bevd_0);
case 2059692827: return bem_sameObject_1(bevd_0);
case -1537592796: return bem_put_1(bevd_0);
case 2048872139: return bem_baseNodeSet_1(bevd_0);
case 1184247111: return bem_sameClass_1(bevd_0);
case -232942059: return bem_baseNodeSetDirect_1(bevd_0);
case 72400397: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 399670111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 960402060: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1203589172: return bem_multiSetDirect_1(bevd_0);
case 2107311680: return bem_notEquals_1(bevd_0);
case 257683973: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1176553472: return bem_relSet_1(bevd_0);
case -1451354876: return bem_multiSet_1(bevd_0);
case 491418465: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1964074985: return bem_otherType_1(bevd_0);
case 545360178: return bem_get_1(bevd_0);
case -2137142891: return bem_moduSet_1(bevd_0);
case -301008142: return bem_equals_1(bevd_0);
case -1446114275: return bem_addValue_1(bevd_0);
case 1372688716: return bem_sizeSetDirect_1(bevd_0);
case 381390502: return bem_innerPutAddedSet_1(bevd_0);
case -225795861: return bem_sameType_1(bevd_0);
case 29559336: return bem_slotsSet_1(bevd_0);
case 1989350941: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 735081139: return bem_slotsSetDirect_1(bevd_0);
case 1951774795: return bem_copyTo_1(bevd_0);
case 1365607091: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -384550601: return bem_sizeSet_1(bevd_0);
case 1645994064: return bem_delete_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1679235980: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1396181242: return bem_put_2(bevd_0, bevd_1);
case -1107212100: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1022886306: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1035176912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 471675441: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1306506121: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1799970709: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
