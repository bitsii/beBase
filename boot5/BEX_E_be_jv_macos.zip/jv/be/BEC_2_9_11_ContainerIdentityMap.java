package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap extends BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
public BEC_2_9_11_ContainerIdentityMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {91, 91, 95, 96, 97, 98, 99, 100};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 11, 15, 16, 17, 18, 19, 20};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 91 10
new 0 91 10
new 1 91 11
assign 1 95 15
new 1 95 15
assign 1 96 16
assign 1 97 17
new 0 97 17
assign 1 98 18
new 0 98 18
assign 1 99 19
new 0 99 19
assign 1 100 20
new 0 100 20
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1724993772: return bem_many_0();
case -2042552479: return bem_keysGet_0();
case 1019764096: return bem_clear_0();
case 1255154985: return bem_nodesGet_0();
case -507734168: return bem_moduGet_0();
case -1080169573: return bem_notEmptyGet_0();
case 836604081: return bem_tagGet_0();
case 755005070: return bem_echo_0();
case 1550782506: return bem_print_0();
case 435982358: return bem_multiGet_0();
case -1674644863: return bem_serializeToString_0();
case 353744263: return bem_once_0();
case 427095721: return bem_slotsGet_0();
case -1207227016: return bem_toAny_0();
case 1381650127: return bem_keyIteratorGet_0();
case -208131809: return bem_setIteratorGet_0();
case -1519544878: return bem_keyValueIteratorGet_0();
case 1586265763: return bem_copy_0();
case -1615155660: return bem_sourceFileNameGet_0();
case 628564451: return bem_valueIteratorGet_0();
case 830826195: return bem_baseNodeGet_0();
case 1942258633: return bem_sizeGet_0();
case -2035802034: return bem_hashGet_0();
case -2079261808: return bem_toString_0();
case 331067077: return bem_iteratorGet_0();
case -868754815: return bem_serializeContents_0();
case 2126517131: return bem_valuesGet_0();
case -1704001450: return bem_serializationIteratorGet_0();
case -1144635038: return bem_fieldIteratorGet_0();
case 1107063436: return bem_create_0();
case -1296312163: return bem_relGet_0();
case -675781273: return bem_mapIteratorGet_0();
case -1741784553: return bem_innerPutAddedGet_0();
case 1618197244: return bem_new_0();
case -1432966592: return bem_deserializeClassNameGet_0();
case 1967827334: return bem_nodeIteratorGet_0();
case 2089277173: return bem_classNameGet_0();
case 1810668720: return bem_isEmptyGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -702689265: return bem_has_1(bevd_0);
case -1391920064: return bem_multiSet_1(bevd_0);
case -1640542280: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1967350921: return bem_put_1(bevd_0);
case 1292274364: return bem_undefined_1(bevd_0);
case -269163422: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 567619203: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2018158572: return bem_sameType_1(bevd_0);
case 1053963189: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -864903677: return bem_otherType_1(bevd_0);
case 1529874757: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1513694604: return bem_innerPutAddedSet_1(bevd_0);
case 12223317: return bem_relSet_1(bevd_0);
case 1442730252: return bem_sizeSet_1(bevd_0);
case -467831865: return bem_otherClass_1(bevd_0);
case -1166994632: return bem_get_1(bevd_0);
case -955519709: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1742780228: return bem_moduSet_1(bevd_0);
case -1743252117: return bem_sameObject_1(bevd_0);
case 1986602925: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 729465196: return bem_equals_1(bevd_0);
case 1975786452: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1689318290: return bem_baseNodeSet_1(bevd_0);
case -1285524271: return bem_sameClass_1(bevd_0);
case 1820941401: return bem_def_1(bevd_0);
case -102763151: return bem_defined_1(bevd_0);
case -1947792037: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 894987079: return bem_undef_1(bevd_0);
case -1150984409: return bem_addValue_1(bevd_0);
case -227418614: return bem_slotsSet_1(bevd_0);
case 1181026029: return bem_copyTo_1(bevd_0);
case 2082220238: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 982421129: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1690226246: return bem_notEquals_1(bevd_0);
case 1040931602: return bem_delete_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1632202498: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1527927145: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -783638750: return bem_put_2(bevd_0, bevd_1);
case -1067491989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1241720452: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2041527697: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1713973958: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1814064163: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -13625888: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2116132271: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentityMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
}
