package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_13_ContainerMapValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_13_ContainerMapValueIterator() { }
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;

public static BET_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_tr = super.bem_nextGet_0();
if (bevl_tr == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevt_1_tmpany_phold = bevl_tr.bemd_0(-1597711973);
return bevt_1_tmpany_phold;
} /* Line: 632 */
return bevl_tr;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {630, 631, 631, 632, 632, 634};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 21, 22, 23, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 630 15
nextGet 0 630 15
assign 1 631 16
def 1 631 21
assign 1 632 22
valueGet 0 632 22
return 1 632 23
return 1 634 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1641225752: return bem_currentGetDirect_0();
case 26417469: return bem_create_0();
case 2132890711: return bem_new_0();
case -868741030: return bem_nextGet_0();
case 1965613314: return bem_tagGet_0();
case 1359777543: return bem_toAny_0();
case 1191040264: return bem_slotsGet_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case 2069196027: return bem_print_0();
case 344752250: return bem_hashGet_0();
case 334767424: return bem_copy_0();
case 27033645: return bem_sourceFileNameGet_0();
case 605755759: return bem_fieldNamesGet_0();
case 2061412556: return bem_classNameGet_0();
case -39706070: return bem_serializeContents_0();
case 258776523: return bem_currentGet_0();
case -976763948: return bem_nodeIteratorIteratorGet_0();
case -1509669842: return bem_setGetDirect_0();
case -1276472965: return bem_hasNextGet_0();
case -2097483702: return bem_moduGetDirect_0();
case -1951841333: return bem_delete_0();
case 35200379: return bem_slotsGetDirect_0();
case 874968344: return bem_once_0();
case -799200084: return bem_serializeToString_0();
case 713825943: return bem_moduGet_0();
case 159014997: return bem_containerGet_0();
case -1878305271: return bem_many_0();
case 1578098134: return bem_toString_0();
case 325964466: return bem_echo_0();
case 962099177: return bem_fieldIteratorGet_0();
case 1480415803: return bem_serializationIteratorGet_0();
case 235719161: return bem_setGet_0();
case 502031978: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1747758794: return bem_slotsSet_1(bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case 710928465: return bem_slotsSetDirect_1(bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case 419124452: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case -240742675: return bem_moduSetDirect_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 676866711: return bem_currentSetDirect_1(bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2098607810: return bem_setSetDirect_1(bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case -1731088347: return bem_moduSet_1(bevd_0);
case 921042266: return bem_setSet_1(bevd_0);
case 1162406138: return bem_currentSet_1(bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_3_9_3_13_ContainerMapValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_13_ContainerMapValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst = (BEC_3_9_3_13_ContainerMapValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_type;
}
}
