package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_17, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_22, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_24, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_26, 14));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_29, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_36, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_39, 9));
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(731731497);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(-190996314);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(-190996314);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_ta_ph = bevl_bet.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_ta_ph);
bevl_tout.bemd_1(947427583, bevl_bet);
bevl_tout.bemd_0(-611877296);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(279606262);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1995106938);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_typeName);
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_ta_ph = bevl_bc.bem_begins_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 88*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
beva_sdec.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 90*/
bevt_5_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 103*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 103*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 103*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 103*/
 else /* Line: 103*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 103*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 104*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 110*/
 else /* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 110*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 111*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_exceptDec);
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_ms = bevt_0_ta_ph.bem_add_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_6_ta_ph = bevl_ms.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_9_ta_ph = bevl_ms.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-433553307);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_once_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 81, 81, 81, 81, 86, 87, 88, 88, 89, 89, 90, 90, 92, 92, 92, 93, 99, 99, 99, 99, 99, 99, 103, 103, 103, 0, 0, 0, 104, 104, 106, 106, 110, 110, 110, 0, 0, 0, 111, 111, 113, 113, 117, 117, 121, 121, 121, 121, 121, 122, 122, 122, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 125, 129, 129, 129, 133, 133, 133, 133, 133, 133, 133, 137, 137, 141, 141, 145, 145, 145, 145};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {66, 67, 68, 69, 127, 128, 129, 130, 135, 136, 137, 138, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 163, 166, 168, 170, 173, 174, 176, 177, 178, 179, 185, 186, 187, 188, 189, 190, 191, 192, 193, 193, 196, 198, 200, 203, 204, 206, 207, 208, 209, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 280, 281, 282, 283, 284, 294, 295, 296, 297, 299, 300, 301, 302, 304, 305, 306, 307, 316, 317, 318, 319, 320, 321, 329, 334, 335, 337, 340, 344, 347, 348, 350, 351, 359, 364, 365, 367, 370, 374, 377, 378, 380, 381, 385, 386, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 435, 436, 437, 446, 447, 448, 449, 450, 451, 452, 456, 457, 461, 462, 468, 469, 470, 471};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 66
new 0 16 66
assign 1 17 67
new 0 17 67
assign 1 18 68
new 0 18 68
new 1 22 69
assign 1 26 127
classDirGet 0 26 127
assign 1 26 128
fileGet 0 26 128
assign 1 26 129
existsGet 0 26 129
assign 1 26 130
not 0 26 135
assign 1 27 136
classDirGet 0 27 136
assign 1 27 137
fileGet 0 27 137
makeDirs 0 27 138
assign 1 29 140
typePathGet 0 29 140
assign 1 29 141
fileGet 0 29 141
assign 1 29 142
writerGet 0 29 142
assign 1 29 143
open 0 29 143
assign 1 30 144
new 0 30 144
assign 1 31 145
new 0 31 145
addValue 1 31 146
assign 1 32 147
new 0 32 147
assign 1 32 148
addValue 1 32 148
assign 1 32 149
typeEmitNameGet 0 32 149
assign 1 32 150
addValue 1 32 150
assign 1 32 151
new 0 32 151
addValue 1 32 152
assign 1 33 153
new 0 33 153
assign 1 33 154
addValue 1 33 154
assign 1 33 155
typeEmitNameGet 0 33 155
assign 1 33 156
addValue 1 33 156
assign 1 33 157
new 0 33 157
addValue 1 33 158
assign 1 35 159
new 0 35 159
addValue 1 35 160
assign 1 36 161
new 0 36 161
assign 1 37 162
mtdListGet 0 37 162
assign 1 37 163
iteratorGet 0 0 163
assign 1 37 166
hasNextGet 0 37 166
assign 1 37 168
nextGet 0 37 168
assign 1 39 170
new 0 39 170
assign 1 41 173
new 0 41 173
addValue 1 41 174
assign 1 43 176
addValue 1 43 176
assign 1 43 177
nameGet 0 43 177
assign 1 43 178
addValue 1 43 178
addValue 1 43 179
assign 1 45 185
new 0 45 185
addValue 1 45 186
assign 1 46 187
new 0 46 187
addValue 1 46 188
assign 1 48 189
new 0 48 189
addValue 1 48 190
assign 1 49 191
new 0 49 191
assign 1 50 192
ptyListGet 0 50 192
assign 1 50 193
iteratorGet 0 0 193
assign 1 50 196
hasNextGet 0 50 196
assign 1 50 198
nextGet 0 50 198
assign 1 52 200
new 0 52 200
assign 1 54 203
new 0 54 203
addValue 1 54 204
assign 1 56 206
addValue 1 56 206
assign 1 56 207
nameGet 0 56 207
assign 1 56 208
addValue 1 56 208
addValue 1 56 209
assign 1 58 215
new 0 58 215
addValue 1 58 216
assign 1 60 217
new 0 60 217
addValue 1 60 218
assign 1 62 219
new 0 62 219
addValue 1 62 220
assign 1 63 221
new 0 63 221
assign 1 63 222
addValue 1 63 222
assign 1 63 223
emitNameGet 0 63 223
assign 1 63 224
addValue 1 63 224
assign 1 63 225
new 0 63 225
addValue 1 63 226
assign 1 64 227
new 0 64 227
addValue 1 64 228
assign 1 65 229
new 0 65 229
addValue 1 65 230
write 1 66 231
close 0 67 232
assign 1 71 253
new 0 71 253
assign 1 71 254
toString 0 71 254
assign 1 71 255
add 1 71 255
incrementValue 0 72 256
assign 1 73 257
new 0 73 257
assign 1 73 258
addValue 1 73 258
assign 1 73 259
addValue 1 73 259
assign 1 73 260
new 0 73 260
assign 1 73 261
addValue 1 73 261
addValue 1 73 262
assign 1 75 263
containedGet 0 75 263
assign 1 75 264
firstGet 0 75 264
assign 1 75 265
containedGet 0 75 265
assign 1 75 266
firstGet 0 75 266
assign 1 75 267
new 0 75 267
assign 1 75 268
add 1 75 268
assign 1 75 269
new 0 75 269
assign 1 75 270
add 1 75 270
assign 1 75 271
finalAssign 4 75 271
addValue 1 75 272
assign 1 81 280
new 0 81 280
assign 1 81 281
add 1 81 281
assign 1 81 282
new 0 81 282
assign 1 81 283
add 1 81 283
return 1 81 284
getInt 2 86 294
assign 1 87 295
toHexString 1 87 295
assign 1 88 296
new 0 88 296
assign 1 88 297
begins 1 88 297
assign 1 89 299
new 0 89 299
assign 1 89 300
substring 1 89 300
assign 1 90 301
new 0 90 301
addValue 1 90 302
assign 1 92 304
new 0 92 304
assign 1 92 305
once 0 92 305
addValue 1 92 306
addValue 1 93 307
assign 1 99 316
new 0 99 316
assign 1 99 317
add 1 99 317
assign 1 99 318
new 0 99 318
assign 1 99 319
add 1 99 319
assign 1 99 320
add 1 99 320
return 1 99 321
assign 1 103 329
def 1 103 334
assign 1 103 335
isFinalGet 0 103 335
assign 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 104 347
new 0 104 347
return 1 104 348
assign 1 106 350
new 0 106 350
return 1 106 351
assign 1 110 359
def 1 110 364
assign 1 110 365
isFinalGet 0 110 365
assign 1 0 367
assign 1 0 370
assign 1 0 374
assign 1 111 377
new 0 111 377
return 1 111 378
assign 1 113 380
new 0 113 380
return 1 113 381
assign 1 117 385
new 0 117 385
return 1 117 386
assign 1 121 408
new 0 121 408
assign 1 121 409
add 1 121 409
assign 1 121 410
new 0 121 410
assign 1 121 411
add 1 121 411
assign 1 121 412
add 1 121 412
assign 1 122 413
new 0 122 413
assign 1 122 414
addValue 1 122 414
assign 1 122 415
addValue 1 122 415
assign 1 122 416
new 0 122 416
assign 1 122 417
addValue 1 122 417
addValue 1 122 418
assign 1 123 419
new 0 123 419
assign 1 123 420
addValue 1 123 420
addValue 1 123 421
assign 1 124 422
new 0 124 422
assign 1 124 423
addValue 1 124 423
assign 1 124 424
outputPlatformGet 0 124 424
assign 1 124 425
nameGet 0 124 425
assign 1 124 426
addValue 1 124 426
assign 1 124 427
new 0 124 427
assign 1 124 428
addValue 1 124 428
addValue 1 124 429
return 1 125 430
assign 1 129 435
libNameGet 0 129 435
assign 1 129 436
beginNs 1 129 436
return 1 129 437
assign 1 133 446
new 0 133 446
assign 1 133 447
libNs 1 133 447
assign 1 133 448
add 1 133 448
assign 1 133 449
new 0 133 449
assign 1 133 450
add 1 133 450
assign 1 133 451
add 1 133 451
return 1 133 452
assign 1 137 456
getNameSpace 1 137 456
return 1 137 457
assign 1 141 461
new 0 141 461
return 1 141 462
assign 1 145 468
new 0 145 468
assign 1 145 469
once 0 145 469
assign 1 145 470
add 1 145 470
return 1 145 471
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1549621983: return bem_afterCast_0();
case 79267079: return bem_onceDecsGetDirect_0();
case 573638497: return bem_scvpGet_0();
case -1728706620: return bem_classEmitsGetDirect_0();
case 1428196909: return bem_deserializeClassNameGet_0();
case 1010241612: return bem_dynMethodsGet_0();
case -631770624: return bem_newDecGet_0();
case -1368992262: return bem_boolNpGet_0();
case 1041033193: return bem_mainInClassGet_0();
case 1849991887: return bem_boolNpGetDirect_0();
case -1492236149: return bem_baseSmtdDecGet_0();
case 1638094888: return bem_invpGet_0();
case 72001427: return bem_smnlecsGetDirect_0();
case -62267159: return bem_preClassGetDirect_0();
case 869857920: return bem_emitLangGet_0();
case 1769534124: return bem_idToNameGet_0();
case 1516206590: return bem_loadIds_0();
case -1738947801: return bem_idToNamePathGetDirect_0();
case 1963846645: return bem_serializeContents_0();
case -559654393: return bem_sourceFileNameGet_0();
case -760315485: return bem_mainOutsideNsGet_0();
case -1530492540: return bem_many_0();
case -272898937: return bem_lastMethodBodyLinesGetDirect_0();
case -2008815306: return bem_objectNpGetDirect_0();
case -480070301: return bem_instOfGetDirect_0();
case -932917927: return bem_useDynMethodsGet_0();
case 474962230: return bem_buildGetDirect_0();
case -1694224984: return bem_propDecGet_0();
case 999024614: return bem_lastMethodBodyLinesGet_0();
case -182327627: return bem_emitLib_0();
case 2098587770: return bem_qGetDirect_0();
case -1660007365: return bem_iteratorGet_0();
case 911450332: return bem_maxDynArgsGetDirect_0();
case 1469761457: return bem_serializeToString_0();
case -1504025822: return bem_saveIds_0();
case 808480381: return bem_idToNameGetDirect_0();
case -373366519: return bem_lineCountGetDirect_0();
case 541771749: return bem_lastMethodsSizeGetDirect_0();
case -38623636: return bem_objectNpGet_0();
case -1885344776: return bem_nameToIdGet_0();
case -757122911: return bem_libEmitNameGetDirect_0();
case 646532675: return bem_objectCcGetDirect_0();
case 921209725: return bem_echo_0();
case 2058923405: return bem_falseValueGet_0();
case -1113097228: return bem_exceptDecGet_0();
case 1938017540: return bem_gcMarksGetDirect_0();
case -2078401329: return bem_classEmitsGet_0();
case 1617803079: return bem_trueValueGetDirect_0();
case 4197906: return bem_typeDecGet_0();
case -734629491: return bem_msynGet_0();
case 1082277882: return bem_lastMethodBodySizeGetDirect_0();
case 1556017976: return bem_emitLangGetDirect_0();
case -1640020074: return bem_toString_0();
case 1184396132: return bem_lastCallGet_0();
case -1309387261: return bem_dynMethodsGetDirect_0();
case -1803562826: return bem_smnlecsGet_0();
case -1624008753: return bem_fileExtGetDirect_0();
case -1540970494: return bem_classConfGetDirect_0();
case 1629704468: return bem_nativeCSlotsGetDirect_0();
case -1336252214: return bem_maxDynArgsGet_0();
case -1251332994: return bem_mainEndGet_0();
case -1175672383: return bem_intNpGet_0();
case -982637711: return bem_boolCcGetDirect_0();
case 976077722: return bem_new_0();
case -669586306: return bem_inFilePathedGet_0();
case 90165143: return bem_inClassGetDirect_0();
case -938303454: return bem_methodCallsGet_0();
case 212821421: return bem_preClassGet_0();
case -2047003963: return bem_buildClassInfo_0();
case 126164297: return bem_serializationIteratorGet_0();
case -1314685273: return bem_nullValueGet_0();
case 1557417370: return bem_saveSyns_0();
case -1853338236: return bem_parentConfGet_0();
case 809295624: return bem_instanceNotEqualGetDirect_0();
case -810352704: return bem_ccCacheGet_0();
case -1432783857: return bem_beginNs_0();
case 750240223: return bem_covariantReturnsGet_0();
case -901664082: return bem_methodCallsGetDirect_0();
case 880575739: return bem_onceDecsGet_0();
case 918163558: return bem_buildGet_0();
case -1713542144: return bem_gcMarksGet_0();
case -1703863841: return bem_methodCatchGetDirect_0();
case -667923282: return bem_ccCacheGetDirect_0();
case -149541064: return bem_mainStartGet_0();
case 2133319355: return bem_buildCreate_0();
case -534139917: return bem_smnlcsGet_0();
case -1619718776: return bem_mnodeGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case -489715464: return bem_ntypesGetDirect_0();
case -560535375: return bem_boolCcGet_0();
case 1916121565: return bem_nativeCSlotsGet_0();
case -853779375: return bem_classesInDepthOrderGet_0();
case -965367604: return bem_falseValueGetDirect_0();
case 1235859938: return bem_libEmitNameGet_0();
case -441983038: return bem_maxSpillArgsLenGetDirect_0();
case 1404560533: return bem_baseMtdDecGet_0();
case -1938521961: return bem_create_0();
case -1865074999: return bem_methodBodyGetDirect_0();
case 2034664732: return bem_mnodeGetDirect_0();
case -374496050: return bem_tagGet_0();
case -264633330: return bem_classConfGet_0();
case -2039051556: return bem_randGet_0();
case -1213095994: return bem_floatNpGetDirect_0();
case 1857725430: return bem_msynGetDirect_0();
case -1339650999: return bem_objectCcGet_0();
case 120046268: return bem_instanceNotEqualGet_0();
case -1933513603: return bem_superCallsGet_0();
case -799300670: return bem_boolTypeGet_0();
case -622892906: return bem_getClassOutput_0();
case -1665477413: return bem_onceCountGet_0();
case 342168871: return bem_spropDecGet_0();
case 284524914: return bem_propertyDecsGet_0();
case 1285405295: return bem_transGetDirect_0();
case -344329653: return bem_callNamesGetDirect_0();
case -1677294751: return bem_hashGet_0();
case 177578443: return bem_lastMethodsLinesGetDirect_0();
case -1359840989: return bem_toAny_0();
case 469227570: return bem_belslitsGetDirect_0();
case 1697030745: return bem_nullValueGetDirect_0();
case 2069874486: return bem_constGetDirect_0();
case -1426796508: return bem_overrideMtdDecGet_0();
case 1684060040: return bem_instOfGet_0();
case -56476806: return bem_floatNpGet_0();
case 1270622152: return bem_propertyDecsGetDirect_0();
case 2009824260: return bem_writeBET_0();
case -1780774904: return bem_maxSpillArgsLenGet_0();
case 931825154: return bem_nameToIdPathGet_0();
case 1310476486: return bem_onceCountGetDirect_0();
case -1445674468: return bem_methodCatchGet_0();
case 78342517: return bem_transGet_0();
case 859478775: return bem_returnTypeGet_0();
case -688458928: return bem_csynGetDirect_0();
case -527347445: return bem_belslitsGet_0();
case 1342564574: return bem_ntypesGet_0();
case -1489800621: return bem_classCallsGetDirect_0();
case 957272449: return bem_cnodeGetDirect_0();
case -1606863806: return bem_fieldIteratorGet_0();
case -745776516: return bem_methodBodyGet_0();
case 1300723694: return bem_getLibOutput_0();
case -1204114663: return bem_inFilePathedGetDirect_0();
case 751565552: return bem_instanceEqualGetDirect_0();
case 1745932584: return bem_cnodeGet_0();
case 1963895268: return bem_callNamesGet_0();
case 1847317098: return bem_ccMethodsGetDirect_0();
case -1560079699: return bem_preClassOutput_0();
case 1468768396: return bem_ccMethodsGet_0();
case -129765629: return bem_print_0();
case 1168883670: return bem_initialDecGet_0();
case -47374135: return bem_instanceEqualGet_0();
case 986861100: return bem_endNs_0();
case 1792835154: return bem_scvpGetDirect_0();
case 959138183: return bem_nameToIdGetDirect_0();
case -33909119: return bem_synEmitPathGet_0();
case -304053239: return bem_idToNamePathGet_0();
case -55205772: return bem_qGet_0();
case -1483834827: return bem_copy_0();
case -352158862: return bem_superNameGet_0();
case -93250672: return bem_runtimeInitGet_0();
case -995908414: return bem_parentConfGetDirect_0();
case -1679633478: return bem_buildInitial_0();
case 2011366903: return bem_exceptDecGetDirect_0();
case -1543042716: return bem_invpGetDirect_0();
case -2071858757: return bem_methodsGet_0();
case -1120775249: return bem_classNameGet_0();
case 814622698: return bem_inClassGet_0();
case -1744350502: return bem_fileExtGet_0();
case 318774532: return bem_fullLibEmitNameGet_0();
case -758635898: return bem_smnlcsGetDirect_0();
case 579025931: return bem_lastMethodsSizeGet_0();
case 1045630899: return bem_superCallsGetDirect_0();
case -146181712: return bem_doEmit_0();
case 479112110: return bem_classesInDepthOrderGetDirect_0();
case -1223201525: return bem_stringNpGet_0();
case 529900773: return bem_returnTypeGetDirect_0();
case -788466978: return bem_classEndGet_0();
case 1858861487: return bem_libEmitPathGetDirect_0();
case 309556659: return bem_classCallsGet_0();
case 1086682307: return bem_stringNpGetDirect_0();
case -1902850774: return bem_csynGet_0();
case -46637924: return bem_libEmitPathGet_0();
case 145597398: return bem_nlGetDirect_0();
case -1763477507: return bem_fullLibEmitNameGetDirect_0();
case -1418894633: return bem_randGetDirect_0();
case -1188881494: return bem_nameToIdPathGetDirect_0();
case 1618380522: return bem_lastMethodsLinesGet_0();
case -1524780977: return bem_nlGet_0();
case -1299108005: return bem_trueValueGet_0();
case -1339686675: return bem_lineCountGet_0();
case 736111648: return bem_synEmitPathGetDirect_0();
case 951950867: return bem_lastCallGetDirect_0();
case -1451184761: return bem_constGet_0();
case -889428894: return bem_methodsGetDirect_0();
case 2028199664: return bem_once_0();
case -532901245: return bem_intNpGetDirect_0();
case 1365146346: return bem_lastMethodBodySizeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2068026669: return bem_classConfSetDirect_1(bevd_0);
case -1250072859: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -919533629: return bem_objectNpSet_1(bevd_0);
case -1183881117: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1910673189: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1351297913: return bem_superCallsSetDirect_1(bevd_0);
case -1166768655: return bem_classesInDepthOrderSet_1(bevd_0);
case 1628266148: return bem_exceptDecSetDirect_1(bevd_0);
case -905438323: return bem_floatNpSet_1(bevd_0);
case -1053703435: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -633051363: return bem_exceptDecSet_1(bevd_0);
case -1838687907: return bem_buildSetDirect_1(bevd_0);
case 1414981672: return bem_defined_1(bevd_0);
case 435130158: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1581679665: return bem_superCallsSet_1(bevd_0);
case 1662145724: return bem_constSetDirect_1(bevd_0);
case -1383582564: return bem_transSetDirect_1(bevd_0);
case 1370940251: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -943060017: return bem_ntypesSetDirect_1(bevd_0);
case -1117001: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -1391569691: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -2090747953: return bem_methodsSetDirect_1(bevd_0);
case 2031920130: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case 1681519687: return bem_lineCountSetDirect_1(bevd_0);
case 1486683431: return bem_propertyDecsSetDirect_1(bevd_0);
case 1930022652: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1538696579: return bem_idToNameSetDirect_1(bevd_0);
case -679875773: return bem_invpSet_1(bevd_0);
case -765148261: return bem_smnlecsSetDirect_1(bevd_0);
case 247880150: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -239131095: return bem_mnodeSet_1(bevd_0);
case -1976319286: return bem_smnlecsSet_1(bevd_0);
case -639980586: return bem_ccMethodsSet_1(bevd_0);
case 1684367234: return bem_synEmitPathSet_1(bevd_0);
case -1300371123: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -5032081: return bem_ccCacheSet_1(bevd_0);
case 4455191: return bem_boolNpSetDirect_1(bevd_0);
case 1233102724: return bem_begin_1(bevd_0);
case 612268090: return bem_nullValueSet_1(bevd_0);
case 1940277313: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case -999312216: return bem_nameToIdSetDirect_1(bevd_0);
case -901360388: return bem_belslitsSetDirect_1(bevd_0);
case -1793335696: return bem_invpSetDirect_1(bevd_0);
case 808625299: return bem_falseValueSetDirect_1(bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case -1971312455: return bem_callNamesSetDirect_1(bevd_0);
case -1503169881: return bem_preClassSetDirect_1(bevd_0);
case -391227917: return bem_fullLibEmitNameSet_1(bevd_0);
case 1161913362: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 395605552: return bem_callNamesSet_1(bevd_0);
case 922063890: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1028484080: return bem_stringNpSetDirect_1(bevd_0);
case 290203493: return bem_scvpSet_1(bevd_0);
case -1206173935: return bem_classCallsSetDirect_1(bevd_0);
case -1242595467: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 628402835: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 606678286: return bem_msynSet_1(bevd_0);
case -1784136420: return bem_classConfSet_1(bevd_0);
case -296234756: return bem_parentConfSet_1(bevd_0);
case 1839567711: return bem_smnlcsSet_1(bevd_0);
case -1385002244: return bem_floatNpSetDirect_1(bevd_0);
case -2058827983: return bem_cnodeSet_1(bevd_0);
case -640533169: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1760011831: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1311298598: return bem_csynSet_1(bevd_0);
case 1468408403: return bem_trueValueSet_1(bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2021459465: return bem_dynMethodsSetDirect_1(bevd_0);
case -8003365: return bem_inFilePathedSet_1(bevd_0);
case -1378863238: return bem_intNpSet_1(bevd_0);
case -631555945: return bem_returnTypeSetDirect_1(bevd_0);
case -1603549981: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2016520424: return bem_nativeCSlotsSet_1(bevd_0);
case 911661641: return bem_mnodeSetDirect_1(bevd_0);
case -1478545824: return bem_lastCallSetDirect_1(bevd_0);
case -144508560: return bem_belslitsSet_1(bevd_0);
case -113303787: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 2090122434: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 39982609: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -450158066: return bem_gcMarksSet_1(bevd_0);
case -529192689: return bem_lastMethodBodySizeSet_1(bevd_0);
case 430633118: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 869850749: return bem_instanceNotEqualSet_1(bevd_0);
case -1065165191: return bem_randSetDirect_1(bevd_0);
case -1797525697: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case 1791833898: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -456309637: return bem_idToNamePathSet_1(bevd_0);
case -1790532054: return bem_libEmitNameSet_1(bevd_0);
case -1095682099: return bem_libEmitPathSetDirect_1(bevd_0);
case 84465387: return bem_lastCallSet_1(bevd_0);
case 654588816: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1292415657: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 715483654: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -870875162: return bem_lastMethodsSizeSet_1(bevd_0);
case -995299441: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 175516239: return bem_end_1(bevd_0);
case 353360334: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -131147805: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 938840927: return bem_emitLangSetDirect_1(bevd_0);
case 370358732: return bem_parentConfSetDirect_1(bevd_0);
case 1295081349: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1251610635: return bem_transSet_1(bevd_0);
case -1555686761: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 291105165: return bem_intNpSetDirect_1(bevd_0);
case -415572594: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1349479221: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1874863982: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1009814562: return bem_ccMethodsSetDirect_1(bevd_0);
case 1230074339: return bem_instOfSetDirect_1(bevd_0);
case 1176167093: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1481508055: return bem_preClassSet_1(bevd_0);
case 2065069764: return bem_libEmitNameSetDirect_1(bevd_0);
case -1185215433: return bem_idToNameSet_1(bevd_0);
case -2072745264: return bem_scvpSetDirect_1(bevd_0);
case -1163034300: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 232561331: return bem_buildSet_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case 1780133082: return bem_boolCcSetDirect_1(bevd_0);
case 1185542541: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1726321453: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1981836596: return bem_boolNpSet_1(bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case -1878544712: return bem_idToNamePathSetDirect_1(bevd_0);
case 286740251: return bem_objectCcSet_1(bevd_0);
case 457411712: return bem_objectCcSetDirect_1(bevd_0);
case -1395587983: return bem_methodCallsSetDirect_1(bevd_0);
case 312086633: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1464849375: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -487151186: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1164058836: return bem_synEmitPathSetDirect_1(bevd_0);
case -2142741195: return bem_objectNpSetDirect_1(bevd_0);
case 1654163580: return bem_nameToIdPathSet_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1415255045: return bem_nlSetDirect_1(bevd_0);
case -29439123: return bem_nameToIdSet_1(bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case -382801248: return bem_qSetDirect_1(bevd_0);
case 2004955952: return bem_inFilePathedSetDirect_1(bevd_0);
case 1664581787: return bem_methodsSet_1(bevd_0);
case 966193365: return bem_onceCountSetDirect_1(bevd_0);
case -1463970463: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 2043043484: return bem_msynSetDirect_1(bevd_0);
case -872100885: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -516773674: return bem_nullValueSetDirect_1(bevd_0);
case -915762911: return bem_onceDecsSet_1(bevd_0);
case 991743382: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1024533880: return bem_gcMarksSetDirect_1(bevd_0);
case -784394404: return bem_trueValueSetDirect_1(bevd_0);
case -61217962: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1400768154: return bem_constSet_1(bevd_0);
case 885548474: return bem_propertyDecsSet_1(bevd_0);
case 1165330213: return bem_csynSetDirect_1(bevd_0);
case -817931457: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1450609447: return bem_falseValueSet_1(bevd_0);
case 1517492265: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1878634706: return bem_instanceEqualSetDirect_1(bevd_0);
case 792107029: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 3772309: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -780041608: return bem_classEmitsSetDirect_1(bevd_0);
case 503017881: return bem_qSet_1(bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case 759896602: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 241718434: return bem_stringNpSet_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case 1586574871: return bem_instanceEqualSet_1(bevd_0);
case -247231398: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1467762296: return bem_returnTypeSet_1(bevd_0);
case 1810077029: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1803737356: return bem_methodCatchSetDirect_1(bevd_0);
case -1168795021: return bem_ntypesSet_1(bevd_0);
case -1282289091: return bem_nlSet_1(bevd_0);
case -1498050925: return bem_maxDynArgsSet_1(bevd_0);
case -961671254: return bem_maxSpillArgsLenSet_1(bevd_0);
case 2125274653: return bem_methodBodySet_1(bevd_0);
case 1701241404: return bem_methodBodySetDirect_1(bevd_0);
case -219444952: return bem_onceDecsSetDirect_1(bevd_0);
case -679520266: return bem_randSet_1(bevd_0);
case -2016972660: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -22979830: return bem_ccCacheSetDirect_1(bevd_0);
case 382129373: return bem_fileExtSet_1(bevd_0);
case 2055146498: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 573686312: return bem_cnodeSetDirect_1(bevd_0);
case -1917496892: return bem_lineCountSet_1(bevd_0);
case 2027366084: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 2032049116: return bem_smnlcsSetDirect_1(bevd_0);
case -1789737792: return bem_nameToIdPathSetDirect_1(bevd_0);
case -456931453: return bem_onceCountSet_1(bevd_0);
case 43251478: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1789648416: return bem_def_1(bevd_0);
case -907094703: return bem_methodCatchSet_1(bevd_0);
case -708747717: return bem_methodCallsSet_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 92818216: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1426432871: return bem_instOfSet_1(bevd_0);
case -1295638131: return bem_inClassSet_1(bevd_0);
case -848436537: return bem_classEmitsSet_1(bevd_0);
case -444952500: return bem_fileExtSetDirect_1(bevd_0);
case 2024238050: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1847954981: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1211948302: return bem_boolCcSet_1(bevd_0);
case -194410415: return bem_emitLangSet_1(bevd_0);
case 934026839: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case -1972900602: return bem_classCallsSet_1(bevd_0);
case -20293043: return bem_maxDynArgsSetDirect_1(bevd_0);
case 1414188593: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1165519089: return bem_dynMethodsSet_1(bevd_0);
case -1709589712: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 373531756: return bem_lastMethodsLinesSet_1(bevd_0);
case 1750589388: return bem_libEmitPathSet_1(bevd_0);
case -670836310: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -594204917: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1140351725: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -515787312: return bem_inClassSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 726285701: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -413741725: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1101759067: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1422314636: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1607375341: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -29950825: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -710600488: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 389677059: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 831042821: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -203706216: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1277785590: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1532359734: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1043070731: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -81289257: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1827214915: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1495260954: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1831215102: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -531522321: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 366574571: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1884613440: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -150513491: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
