package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(-471630496);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-1106745864);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(-428538870);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-1106745864);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(-428538870);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_ta_ph = bevl_bet.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_ta_ph);
bevl_tout.bemd_1(-498443605, bevl_bet);
bevl_tout.bemd_0(-985735394);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(2031208415);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-40732725);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_21));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_0_ta_ph = bevl_bc.bem_begins_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
beva_sdec.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 85*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
beva_sdec.bem_addValue_1(bevt_4_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 98*/
 else /* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 98*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 99*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 105*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 105*/
 else /* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 105*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 106*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_exceptDec);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_ms = bevt_0_ta_ph.bem_add_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_30));
bevt_6_ta_ph = bevl_ms.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_9_ta_ph = bevl_ms.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-1189089294);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_36));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 82, 83, 83, 84, 84, 85, 85, 87, 87, 88, 94, 94, 94, 94, 94, 94, 98, 98, 98, 0, 0, 0, 99, 99, 101, 101, 105, 105, 105, 0, 0, 0, 106, 106, 108, 108, 112, 112, 116, 116, 116, 116, 116, 117, 117, 117, 117, 117, 117, 118, 118, 118, 119, 119, 119, 119, 119, 119, 119, 119, 120, 124, 124, 124, 128, 128, 128, 128, 128, 128, 128, 132, 132, 136, 136, 140, 140, 140};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {51, 52, 53, 54, 112, 113, 114, 115, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 148, 151, 153, 155, 158, 159, 161, 162, 163, 164, 170, 171, 172, 173, 174, 175, 176, 177, 178, 178, 181, 183, 185, 188, 189, 191, 192, 193, 194, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 267, 268, 269, 270, 272, 273, 274, 275, 277, 278, 279, 288, 289, 290, 291, 292, 293, 301, 306, 307, 309, 312, 316, 319, 320, 322, 323, 331, 336, 337, 339, 342, 346, 349, 350, 352, 353, 357, 358, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 407, 408, 409, 418, 419, 420, 421, 422, 423, 424, 428, 429, 433, 434, 439, 440, 441};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 51
new 0 16 51
assign 1 17 52
new 0 17 52
assign 1 18 53
new 0 18 53
new 1 22 54
assign 1 26 112
classDirGet 0 26 112
assign 1 26 113
fileGet 0 26 113
assign 1 26 114
existsGet 0 26 114
assign 1 26 115
not 0 26 120
assign 1 27 121
classDirGet 0 27 121
assign 1 27 122
fileGet 0 27 122
makeDirs 0 27 123
assign 1 29 125
typePathGet 0 29 125
assign 1 29 126
fileGet 0 29 126
assign 1 29 127
writerGet 0 29 127
assign 1 29 128
open 0 29 128
assign 1 30 129
new 0 30 129
assign 1 31 130
new 0 31 130
addValue 1 31 131
assign 1 32 132
new 0 32 132
assign 1 32 133
addValue 1 32 133
assign 1 32 134
typeEmitNameGet 0 32 134
assign 1 32 135
addValue 1 32 135
assign 1 32 136
new 0 32 136
addValue 1 32 137
assign 1 33 138
new 0 33 138
assign 1 33 139
addValue 1 33 139
assign 1 33 140
typeEmitNameGet 0 33 140
assign 1 33 141
addValue 1 33 141
assign 1 33 142
new 0 33 142
addValue 1 33 143
assign 1 35 144
new 0 35 144
addValue 1 35 145
assign 1 36 146
new 0 36 146
assign 1 37 147
mtdListGet 0 37 147
assign 1 37 148
iteratorGet 0 0 148
assign 1 37 151
hasNextGet 0 37 151
assign 1 37 153
nextGet 0 37 153
assign 1 39 155
new 0 39 155
assign 1 41 158
new 0 41 158
addValue 1 41 159
assign 1 43 161
addValue 1 43 161
assign 1 43 162
nameGet 0 43 162
assign 1 43 163
addValue 1 43 163
addValue 1 43 164
assign 1 45 170
new 0 45 170
addValue 1 45 171
assign 1 46 172
new 0 46 172
addValue 1 46 173
assign 1 48 174
new 0 48 174
addValue 1 48 175
assign 1 49 176
new 0 49 176
assign 1 50 177
ptyListGet 0 50 177
assign 1 50 178
iteratorGet 0 0 178
assign 1 50 181
hasNextGet 0 50 181
assign 1 50 183
nextGet 0 50 183
assign 1 52 185
new 0 52 185
assign 1 54 188
new 0 54 188
addValue 1 54 189
assign 1 56 191
addValue 1 56 191
assign 1 56 192
nameGet 0 56 192
assign 1 56 193
addValue 1 56 193
addValue 1 56 194
assign 1 58 200
new 0 58 200
addValue 1 58 201
assign 1 60 202
new 0 60 202
addValue 1 60 203
assign 1 62 204
new 0 62 204
addValue 1 62 205
assign 1 63 206
new 0 63 206
assign 1 63 207
addValue 1 63 207
assign 1 63 208
emitNameGet 0 63 208
assign 1 63 209
addValue 1 63 209
assign 1 63 210
new 0 63 210
addValue 1 63 211
assign 1 64 212
new 0 64 212
addValue 1 64 213
assign 1 65 214
new 0 65 214
addValue 1 65 215
write 1 66 216
close 0 67 217
assign 1 71 238
new 0 71 238
assign 1 71 239
toString 0 71 239
assign 1 71 240
add 1 71 240
incrementValue 0 72 241
assign 1 73 242
new 0 73 242
assign 1 73 243
addValue 1 73 243
assign 1 73 244
addValue 1 73 244
assign 1 73 245
new 0 73 245
assign 1 73 246
addValue 1 73 246
addValue 1 73 247
assign 1 75 248
containedGet 0 75 248
assign 1 75 249
firstGet 0 75 249
assign 1 75 250
containedGet 0 75 250
assign 1 75 251
firstGet 0 75 251
assign 1 75 252
new 0 75 252
assign 1 75 253
add 1 75 253
assign 1 75 254
new 0 75 254
assign 1 75 255
add 1 75 255
assign 1 75 256
finalAssign 4 75 256
addValue 1 75 257
getInt 2 81 267
assign 1 82 268
toHexString 1 82 268
assign 1 83 269
new 0 83 269
assign 1 83 270
begins 1 83 270
assign 1 84 272
new 0 84 272
assign 1 84 273
substring 1 84 273
assign 1 85 274
new 0 85 274
addValue 1 85 275
assign 1 87 277
new 0 87 277
addValue 1 87 278
addValue 1 88 279
assign 1 94 288
new 0 94 288
assign 1 94 289
add 1 94 289
assign 1 94 290
new 0 94 290
assign 1 94 291
add 1 94 291
assign 1 94 292
add 1 94 292
return 1 94 293
assign 1 98 301
def 1 98 306
assign 1 98 307
isFinalGet 0 98 307
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 99 319
new 0 99 319
return 1 99 320
assign 1 101 322
new 0 101 322
return 1 101 323
assign 1 105 331
def 1 105 336
assign 1 105 337
isFinalGet 0 105 337
assign 1 0 339
assign 1 0 342
assign 1 0 346
assign 1 106 349
new 0 106 349
return 1 106 350
assign 1 108 352
new 0 108 352
return 1 108 353
assign 1 112 357
new 0 112 357
return 1 112 358
assign 1 116 380
new 0 116 380
assign 1 116 381
add 1 116 381
assign 1 116 382
new 0 116 382
assign 1 116 383
add 1 116 383
assign 1 116 384
add 1 116 384
assign 1 117 385
new 0 117 385
assign 1 117 386
addValue 1 117 386
assign 1 117 387
addValue 1 117 387
assign 1 117 388
new 0 117 388
assign 1 117 389
addValue 1 117 389
addValue 1 117 390
assign 1 118 391
new 0 118 391
assign 1 118 392
addValue 1 118 392
addValue 1 118 393
assign 1 119 394
new 0 119 394
assign 1 119 395
addValue 1 119 395
assign 1 119 396
outputPlatformGet 0 119 396
assign 1 119 397
nameGet 0 119 397
assign 1 119 398
addValue 1 119 398
assign 1 119 399
new 0 119 399
assign 1 119 400
addValue 1 119 400
addValue 1 119 401
return 1 120 402
assign 1 124 407
libNameGet 0 124 407
assign 1 124 408
beginNs 1 124 408
return 1 124 409
assign 1 128 418
new 0 128 418
assign 1 128 419
libNs 1 128 419
assign 1 128 420
add 1 128 420
assign 1 128 421
new 0 128 421
assign 1 128 422
add 1 128 422
assign 1 128 423
add 1 128 423
return 1 128 424
assign 1 132 428
getNameSpace 1 132 428
return 1 132 429
assign 1 136 433
new 0 136 433
return 1 136 434
assign 1 140 439
new 0 140 439
assign 1 140 440
add 1 140 440
return 1 140 441
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 342052450: return bem_covariantReturnsGet_0();
case 1514994811: return bem_afterCast_0();
case 521569595: return bem_saveIds_0();
case -2074089133: return bem_parentConfGet_0();
case 1570821197: return bem_methodCallsGet_0();
case -145208700: return bem_iteratorGet_0();
case -660251233: return bem_lastMethodsLinesGet_0();
case -506528447: return bem_ccCacheGet_0();
case 121873472: return bem_objectNpGet_0();
case -484065864: return bem_callNamesGet_0();
case -420386439: return bem_instOfGet_0();
case -867156117: return bem_buildGet_0();
case 2137825192: return bem_csynGet_0();
case 1584407770: return bem_baseSmtdDecGet_0();
case 1369358447: return bem_nlGet_0();
case 1605411829: return bem_copy_0();
case 421189359: return bem_trueValueGet_0();
case -1986890087: return bem_classEndGet_0();
case -694840317: return bem_lastCallGet_0();
case 678962900: return bem_methodCatchGet_0();
case -1323491657: return bem_returnTypeGet_0();
case -1373929434: return bem_idToNameGet_0();
case -147564022: return bem_typeDecGet_0();
case -1111213759: return bem_superNameGet_0();
case -1269309884: return bem_propDecGet_0();
case 372643418: return bem_floatNpGet_0();
case 469247954: return bem_inClassGet_0();
case 2074748829: return bem_classCallsGet_0();
case -684357757: return bem_constGet_0();
case -153747809: return bem_preClassGet_0();
case 464777013: return bem_initialDecGet_0();
case -1035313414: return bem_endNs_0();
case -409597792: return bem_exceptDecGet_0();
case 1580091142: return bem_instanceEqualGet_0();
case 615314571: return bem_runtimeInitGet_0();
case -1543633598: return bem_randGet_0();
case 58147699: return bem_classConfGet_0();
case 1706275876: return bem_mainEndGet_0();
case -1551190627: return bem_instanceNotEqualGet_0();
case -1855922192: return bem_overrideMtdDecGet_0();
case -909173667: return bem_nameToIdGet_0();
case 1149733675: return bem_boolCcGet_0();
case -667597655: return bem_libEmitPathGet_0();
case -51593560: return bem_msynGet_0();
case 974091562: return bem_libEmitNameGet_0();
case -522049566: return bem_saveSyns_0();
case 678509678: return bem_maxSpillArgsLenGet_0();
case -1167216931: return bem_nameToIdPathGet_0();
case 2109278257: return bem_spropDecGet_0();
case -1867558857: return bem_toString_0();
case -139018256: return bem_tagGet_0();
case -117530610: return bem_hashGet_0();
case -1860286294: return bem_emitLib_0();
case -419856591: return bem_buildCreate_0();
case -1989620642: return bem_methodBodyGet_0();
case -252105521: return bem_mainOutsideNsGet_0();
case 1128670048: return bem_newDecGet_0();
case 628008427: return bem_idToNamePathGet_0();
case -1621683978: return bem_smnlcsGet_0();
case 2105404879: return bem_propertyDecsGet_0();
case 1526722456: return bem_scvpGet_0();
case -1177319143: return bem_create_0();
case 91610023: return bem_useDynMethodsGet_0();
case -1374417162: return bem_synEmitPathGet_0();
case 1394174242: return bem_inFilePathedGet_0();
case 1226403802: return bem_fullLibEmitNameGet_0();
case -1603310331: return bem_getLibOutput_0();
case -1059990392: return bem_qGet_0();
case -1670704342: return bem_intNpGet_0();
case -1070504823: return bem_smnlecsGet_0();
case -2060693673: return bem_nativeCSlotsGet_0();
case 843801850: return bem_ccMethodsGet_0();
case 157300657: return bem_writeBET_0();
case -1788156411: return bem_getClassOutput_0();
case -1197484742: return bem_lastMethodsSizeGet_0();
case 520320747: return bem_transGet_0();
case -999151400: return bem_new_0();
case 246407092: return bem_print_0();
case 1025742442: return bem_mnodeGet_0();
case 1521858697: return bem_gcMarksGet_0();
case 2037285624: return bem_classEmitsGet_0();
case 2143726465: return bem_belslitsGet_0();
case -2087173172: return bem_falseValueGet_0();
case 532301526: return bem_superCallsGet_0();
case 1978965353: return bem_maxDynArgsGet_0();
case -1547574784: return bem_invpGet_0();
case 1417853754: return bem_boolNpGet_0();
case -2113350391: return bem_lastMethodBodySizeGet_0();
case 1842819600: return bem_classesInDepthOrderGet_0();
case -1851672454: return bem_objectCcGet_0();
case -1164032006: return bem_classNameGet_0();
case 868364083: return bem_ntypesGet_0();
case 658094193: return bem_lastMethodBodyLinesGet_0();
case -833497626: return bem_preClassOutput_0();
case -161252559: return bem_buildClassInfo_0();
case -1154580911: return bem_doEmit_0();
case 982760316: return bem_lineCountGet_0();
case -1019134948: return bem_onceDecsGet_0();
case -1506664222: return bem_fileExtGet_0();
case -1212218484: return bem_loadIds_0();
case -1156285184: return bem_nullValueGet_0();
case -2124054818: return bem_buildInitial_0();
case -1250277197: return bem_cnodeGet_0();
case 289876277: return bem_methodsGet_0();
case -1163528379: return bem_stringNpGet_0();
case 419261008: return bem_boolTypeGet_0();
case -262295610: return bem_beginNs_0();
case 1880173214: return bem_baseMtdDecGet_0();
case -1598285569: return bem_emitLangGet_0();
case -1573086453: return bem_mainStartGet_0();
case -821307784: return bem_mainInClassGet_0();
case 1955512538: return bem_dynMethodsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2059786864: return bem_classesInDepthOrderSet_1(bevd_0);
case -357136196: return bem_instOfSet_1(bevd_0);
case 1883572633: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1740124780: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1124671160: return bem_lastMethodsLinesSet_1(bevd_0);
case -11259638: return bem_methodsSet_1(bevd_0);
case -651261311: return bem_end_1(bevd_0);
case -1366404385: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -94125772: return bem_objectCcSet_1(bevd_0);
case 1295016164: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 419203204: return bem_sameObject_1(bevd_0);
case -1668212752: return bem_stringNpSet_1(bevd_0);
case 554949658: return bem_onceDecsSet_1(bevd_0);
case 1578417612: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1011774407: return bem_inFilePathedSet_1(bevd_0);
case -393776659: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -870881032: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1096766113: return bem_trueValueSet_1(bevd_0);
case 506062479: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -608308133: return bem_gcMarksSet_1(bevd_0);
case -171446320: return bem_transSet_1(bevd_0);
case -1514156960: return bem_classEmitsSet_1(bevd_0);
case -1492484442: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -586255928: return bem_belslitsSet_1(bevd_0);
case 1684340583: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1940749104: return bem_msynSet_1(bevd_0);
case 2111121706: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 435059204: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -369724063: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -540667110: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -611859433: return bem_lineCountSet_1(bevd_0);
case -1253324753: return bem_superCallsSet_1(bevd_0);
case 1170685617: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1551510268: return bem_methodCallsSet_1(bevd_0);
case -1540349094: return bem_begin_1(bevd_0);
case -1334882604: return bem_floatNpSet_1(bevd_0);
case 1450455566: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1292240915: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1558065631: return bem_idToNamePathSet_1(bevd_0);
case 862053579: return bem_ccCacheSet_1(bevd_0);
case 138481587: return bem_equals_1(bevd_0);
case -275796110: return bem_returnTypeSet_1(bevd_0);
case 742388284: return bem_callNamesSet_1(bevd_0);
case -1912105390: return bem_propertyDecsSet_1(bevd_0);
case -1716720482: return bem_copyTo_1(bevd_0);
case -698621279: return bem_randSet_1(bevd_0);
case 1361087718: return bem_inClassSet_1(bevd_0);
case 138041535: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1403205576: return bem_scvpSet_1(bevd_0);
case 620820139: return bem_undef_1(bevd_0);
case 433332529: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -2061571032: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -179387881: return bem_fullLibEmitNameSet_1(bevd_0);
case 886529231: return bem_ccMethodsSet_1(bevd_0);
case 1806107512: return bem_cnodeSet_1(bevd_0);
case 1379677639: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1417386426: return bem_ntypesSet_1(bevd_0);
case -971747898: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1939548038: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -12337001: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1632663514: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -131219569: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1799976779: return bem_instanceEqualSet_1(bevd_0);
case 1931737053: return bem_mnodeSet_1(bevd_0);
case -316754243: return bem_smnlcsSet_1(bevd_0);
case -1104769042: return bem_nameToIdPathSet_1(bevd_0);
case -1306802529: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 146371310: return bem_synEmitPathSet_1(bevd_0);
case 1455651057: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -810543029: return bem_methodCatchSet_1(bevd_0);
case 1129757243: return bem_libEmitNameSet_1(bevd_0);
case 169293479: return bem_idToNameSet_1(bevd_0);
case -967143886: return bem_nameToIdSet_1(bevd_0);
case 1377332966: return bem_nativeCSlotsSet_1(bevd_0);
case 1437172525: return bem_buildSet_1(bevd_0);
case 1263006184: return bem_objectNpSet_1(bevd_0);
case 717296766: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -779908279: return bem_libEmitPathSet_1(bevd_0);
case 623809715: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 902359363: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -596141076: return bem_lastMethodsSizeSet_1(bevd_0);
case -1520852488: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1892424908: return bem_methodBodySet_1(bevd_0);
case 488021012: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 399195011: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 36294893: return bem_falseValueSet_1(bevd_0);
case -992135572: return bem_qSet_1(bevd_0);
case 1179183927: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1258031927: return bem_dynMethodsSet_1(bevd_0);
case 574208866: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1684256428: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -236537683: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -969509474: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -780979369: return bem_emitLangSet_1(bevd_0);
case 1223463658: return bem_invpSet_1(bevd_0);
case 273809829: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 2127371599: return bem_intNpSet_1(bevd_0);
case -2124077532: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1939883991: return bem_classCallsSet_1(bevd_0);
case -1781579603: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 2099233509: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1566118712: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1061843648: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1615742075: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -2092920668: return bem_maxDynArgsSet_1(bevd_0);
case 203005903: return bem_lastCallSet_1(bevd_0);
case -1971209192: return bem_smnlecsSet_1(bevd_0);
case 1255433547: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -57967550: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 892572273: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1533289364: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 936090791: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -283096669: return bem_instanceNotEqualSet_1(bevd_0);
case -1361674070: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 719678886: return bem_constSet_1(bevd_0);
case 1343252503: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 505670446: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -888045035: return bem_lastMethodBodySizeSet_1(bevd_0);
case 2116417678: return bem_boolNpSet_1(bevd_0);
case -2074811592: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1626655699: return bem_fileExtSet_1(bevd_0);
case 1871856437: return bem_classConfSet_1(bevd_0);
case -1761650480: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2066831446: return bem_preClassSet_1(bevd_0);
case -774547634: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -363291025: return bem_boolCcSet_1(bevd_0);
case -1140398366: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1209038799: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -516596088: return bem_def_1(bevd_0);
case -1037046363: return bem_notEquals_1(bevd_0);
case -668450433: return bem_nullValueSet_1(bevd_0);
case -2071179268: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -257033318: return bem_nlSet_1(bevd_0);
case -1653560635: return bem_csynSet_1(bevd_0);
case -1056813398: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -809576845: return bem_exceptDecSet_1(bevd_0);
case 1135105623: return bem_parentConfSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1884340030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 799261417: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 82531209: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1232544036: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1252109150: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1696158010: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 757874548: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1874882330: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -816532338: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1603409019: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1212894534: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1049765149: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -583390687: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 857032303: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1652114762: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -583816373: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1071878826: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -860941920: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1116826581: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -578411053: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1716440773: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 2045310117: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 261010233: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1084711079: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1769708310: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 290303196: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
