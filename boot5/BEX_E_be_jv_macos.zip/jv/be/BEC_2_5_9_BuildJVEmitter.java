package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_24, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_26, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_27, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_28, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_31, 14));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_32, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_38, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_40 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_41 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_42 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_43 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_44 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_45 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_45, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_46 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_46, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_47 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_48 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_48, 9));
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(-1832327595);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_tmpany_phold = bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_tmpany_phold = bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1455331056);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1819620081);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 42 */
bevt_27_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 51 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1455331056);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(1819620081);
if (bevl_firstptsyn.bevi_bool) /* Line: 52 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 53 */
 else  /* Line: 54 */ {
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 55 */
bevt_36_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 57 */
 else  /* Line: 51 */ {
break;
} /* Line: 51 */
} /* Line: 51 */
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevt_42_tmpany_phold = bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_41_tmpany_phold.bem_addValue_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevl_bet.bem_addValue_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevl_bet.bem_addValue_1(bevt_47_tmpany_phold);
bevl_tout.bemd_1(885492581, bevl_bet);
bevl_tout.bemd_0(2101014680);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(759429462);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(777316345);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 89 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 91 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
 else  /* Line: 104 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 104 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
return bevt_3_tmpany_phold;
} /* Line: 105 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
 else  /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 111 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
return bevt_3_tmpany_phold;
} /* Line: 112 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_36));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_40));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_41));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_42));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_43));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(224764905);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_44));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_47));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 49, 49, 50, 51, 51, 0, 51, 51, 53, 55, 55, 57, 57, 57, 57, 59, 59, 61, 61, 63, 63, 64, 64, 64, 64, 64, 64, 65, 65, 66, 66, 67, 68, 72, 72, 72, 73, 74, 74, 74, 74, 74, 74, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 82, 82, 82, 82, 82, 87, 88, 89, 89, 90, 90, 91, 91, 93, 93, 93, 94, 100, 100, 100, 100, 100, 100, 104, 104, 104, 0, 0, 0, 105, 105, 107, 107, 111, 111, 111, 0, 0, 0, 112, 112, 114, 114, 118, 118, 122, 122, 122, 122, 122, 123, 123, 123, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 126, 130, 130, 130, 134, 134, 134, 134, 134, 134, 134, 138, 138, 142, 142, 146, 146, 146, 146};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {75, 76, 77, 78, 136, 137, 138, 139, 144, 145, 146, 147, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 172, 175, 177, 179, 182, 183, 185, 186, 187, 188, 194, 195, 196, 197, 198, 199, 200, 201, 202, 202, 205, 207, 209, 212, 213, 215, 216, 217, 218, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 289, 290, 291, 292, 293, 303, 304, 305, 306, 308, 309, 310, 311, 313, 314, 315, 316, 325, 326, 327, 328, 329, 330, 338, 343, 344, 346, 349, 353, 356, 357, 359, 360, 368, 373, 374, 376, 379, 383, 386, 387, 389, 390, 394, 395, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 444, 445, 446, 455, 456, 457, 458, 459, 460, 461, 465, 466, 470, 471, 477, 478, 479, 480};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 75
new 0 17 75
assign 1 18 76
new 0 18 76
assign 1 19 77
new 0 19 77
new 1 23 78
assign 1 27 136
classDirGet 0 27 136
assign 1 27 137
fileGet 0 27 137
assign 1 27 138
existsGet 0 27 138
assign 1 27 139
not 0 27 144
assign 1 28 145
classDirGet 0 28 145
assign 1 28 146
fileGet 0 28 146
makeDirs 0 28 147
assign 1 30 149
typePathGet 0 30 149
assign 1 30 150
fileGet 0 30 150
assign 1 30 151
writerGet 0 30 151
assign 1 30 152
open 0 30 152
assign 1 31 153
new 0 31 153
assign 1 32 154
new 0 32 154
addValue 1 32 155
assign 1 33 156
new 0 33 156
assign 1 33 157
addValue 1 33 157
assign 1 33 158
typeEmitNameGet 0 33 158
assign 1 33 159
addValue 1 33 159
assign 1 33 160
new 0 33 160
addValue 1 33 161
assign 1 34 162
new 0 34 162
assign 1 34 163
addValue 1 34 163
assign 1 34 164
typeEmitNameGet 0 34 164
assign 1 34 165
addValue 1 34 165
assign 1 34 166
new 0 34 166
addValue 1 34 167
assign 1 36 168
new 0 36 168
addValue 1 36 169
assign 1 37 170
new 0 37 170
assign 1 38 171
mtdListGet 0 38 171
assign 1 38 172
iteratorGet 0 0 172
assign 1 38 175
hasNextGet 0 38 175
assign 1 38 177
nextGet 0 38 177
assign 1 40 179
new 0 40 179
assign 1 42 182
new 0 42 182
addValue 1 42 183
assign 1 44 185
addValue 1 44 185
assign 1 44 186
nameGet 0 44 186
assign 1 44 187
addValue 1 44 187
addValue 1 44 188
assign 1 46 194
new 0 46 194
addValue 1 46 195
assign 1 47 196
new 0 47 196
addValue 1 47 197
assign 1 49 198
new 0 49 198
addValue 1 49 199
assign 1 50 200
new 0 50 200
assign 1 51 201
ptyListGet 0 51 201
assign 1 51 202
iteratorGet 0 0 202
assign 1 51 205
hasNextGet 0 51 205
assign 1 51 207
nextGet 0 51 207
assign 1 53 209
new 0 53 209
assign 1 55 212
new 0 55 212
addValue 1 55 213
assign 1 57 215
addValue 1 57 215
assign 1 57 216
nameGet 0 57 216
assign 1 57 217
addValue 1 57 217
addValue 1 57 218
assign 1 59 224
new 0 59 224
addValue 1 59 225
assign 1 61 226
new 0 61 226
addValue 1 61 227
assign 1 63 228
new 0 63 228
addValue 1 63 229
assign 1 64 230
new 0 64 230
assign 1 64 231
addValue 1 64 231
assign 1 64 232
emitNameGet 0 64 232
assign 1 64 233
addValue 1 64 233
assign 1 64 234
new 0 64 234
addValue 1 64 235
assign 1 65 236
new 0 65 236
addValue 1 65 237
assign 1 66 238
new 0 66 238
addValue 1 66 239
write 1 67 240
close 0 68 241
assign 1 72 262
new 0 72 262
assign 1 72 263
toString 0 72 263
assign 1 72 264
add 1 72 264
incrementValue 0 73 265
assign 1 74 266
new 0 74 266
assign 1 74 267
addValue 1 74 267
assign 1 74 268
addValue 1 74 268
assign 1 74 269
new 0 74 269
assign 1 74 270
addValue 1 74 270
addValue 1 74 271
assign 1 76 272
containedGet 0 76 272
assign 1 76 273
firstGet 0 76 273
assign 1 76 274
containedGet 0 76 274
assign 1 76 275
firstGet 0 76 275
assign 1 76 276
new 0 76 276
assign 1 76 277
add 1 76 277
assign 1 76 278
new 0 76 278
assign 1 76 279
add 1 76 279
assign 1 76 280
finalAssign 4 76 280
addValue 1 76 281
assign 1 82 289
new 0 82 289
assign 1 82 290
add 1 82 290
assign 1 82 291
new 0 82 291
assign 1 82 292
add 1 82 292
return 1 82 293
getInt 2 87 303
assign 1 88 304
toHexString 1 88 304
assign 1 89 305
new 0 89 305
assign 1 89 306
begins 1 89 306
assign 1 90 308
new 0 90 308
assign 1 90 309
substring 1 90 309
assign 1 91 310
new 0 91 310
addValue 1 91 311
assign 1 93 313
new 0 93 313
assign 1 93 314
once 0 93 314
addValue 1 93 315
addValue 1 94 316
assign 1 100 325
new 0 100 325
assign 1 100 326
add 1 100 326
assign 1 100 327
new 0 100 327
assign 1 100 328
add 1 100 328
assign 1 100 329
add 1 100 329
return 1 100 330
assign 1 104 338
def 1 104 343
assign 1 104 344
isFinalGet 0 104 344
assign 1 0 346
assign 1 0 349
assign 1 0 353
assign 1 105 356
new 0 105 356
return 1 105 357
assign 1 107 359
new 0 107 359
return 1 107 360
assign 1 111 368
def 1 111 373
assign 1 111 374
isFinalGet 0 111 374
assign 1 0 376
assign 1 0 379
assign 1 0 383
assign 1 112 386
new 0 112 386
return 1 112 387
assign 1 114 389
new 0 114 389
return 1 114 390
assign 1 118 394
new 0 118 394
return 1 118 395
assign 1 122 417
new 0 122 417
assign 1 122 418
add 1 122 418
assign 1 122 419
new 0 122 419
assign 1 122 420
add 1 122 420
assign 1 122 421
add 1 122 421
assign 1 123 422
new 0 123 422
assign 1 123 423
addValue 1 123 423
assign 1 123 424
addValue 1 123 424
assign 1 123 425
new 0 123 425
assign 1 123 426
addValue 1 123 426
addValue 1 123 427
assign 1 124 428
new 0 124 428
assign 1 124 429
addValue 1 124 429
addValue 1 124 430
assign 1 125 431
new 0 125 431
assign 1 125 432
addValue 1 125 432
assign 1 125 433
outputPlatformGet 0 125 433
assign 1 125 434
nameGet 0 125 434
assign 1 125 435
addValue 1 125 435
assign 1 125 436
new 0 125 436
assign 1 125 437
addValue 1 125 437
addValue 1 125 438
return 1 126 439
assign 1 130 444
libNameGet 0 130 444
assign 1 130 445
beginNs 1 130 445
return 1 130 446
assign 1 134 455
new 0 134 455
assign 1 134 456
libNs 1 134 456
assign 1 134 457
add 1 134 457
assign 1 134 458
new 0 134 458
assign 1 134 459
add 1 134 459
assign 1 134 460
add 1 134 460
return 1 134 461
assign 1 138 465
getNameSpace 1 138 465
return 1 138 466
assign 1 142 470
new 0 142 470
return 1 142 471
assign 1 146 477
new 0 146 477
assign 1 146 478
once 0 146 478
assign 1 146 479
add 1 146 479
return 1 146 480
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1370476051: return bem_fileExtGet_0();
case -1270920215: return bem_onceDecsGetDirect_0();
case -575152158: return bem_floatNpGet_0();
case -396080688: return bem_instOfGetDirect_0();
case 654468149: return bem_lastMethodsLinesGet_0();
case 1730360890: return bem_fullLibEmitNameGetDirect_0();
case -547935816: return bem_echo_0();
case -1549648969: return bem_lineCountGet_0();
case -121543772: return bem_buildGet_0();
case -25777259: return bem_preClassGet_0();
case -1152212076: return bem_endNs_0();
case 749850737: return bem_emitLib_0();
case 1461795953: return bem_toAny_0();
case 861972604: return bem_overrideMtdDecGet_0();
case -919308415: return bem_buildClassInfo_0();
case 1960206464: return bem_intNpGet_0();
case -94797444: return bem_tagGet_0();
case 1225777286: return bem_trueValueGetDirect_0();
case 327423126: return bem_lastCallGetDirect_0();
case -1721767078: return bem_floatNpGetDirect_0();
case 327699630: return bem_ntypesGetDirect_0();
case -9610949: return bem_ntypesGet_0();
case -2128486112: return bem_propertyDecsGet_0();
case -531749606: return bem_classesInDepthOrderGetDirect_0();
case 290847982: return bem_copy_0();
case 515736817: return bem_msynGetDirect_0();
case 188687098: return bem_baseSmtdDecGet_0();
case -1738620160: return bem_instanceNotEqualGet_0();
case 1189119248: return bem_callNamesGetDirect_0();
case -1325860114: return bem_beginNs_0();
case -700918564: return bem_classEndGet_0();
case -350653739: return bem_classConfGetDirect_0();
case -489566517: return bem_superCallsGet_0();
case 1802110774: return bem_mainEndGet_0();
case 293694262: return bem_buildGetDirect_0();
case 1834793784: return bem_emitLangGet_0();
case -2110468924: return bem_doEmit_0();
case 798900030: return bem_lastMethodBodyLinesGet_0();
case 782770507: return bem_toString_0();
case 114051410: return bem_invpGetDirect_0();
case 1580919123: return bem_lastCallGet_0();
case 1989610326: return bem_stringNpGetDirect_0();
case -352175961: return bem_afterCast_0();
case -2098114906: return bem_parentConfGetDirect_0();
case 235383138: return bem_maxSpillArgsLenGet_0();
case -574742381: return bem_onceCountGetDirect_0();
case 1078078836: return bem_instanceEqualGet_0();
case -1165554037: return bem_scvpGet_0();
case -1000822648: return bem_scvpGetDirect_0();
case -1076974459: return bem_once_0();
case -855492495: return bem_fileExtGetDirect_0();
case -198712722: return bem_boolCcGet_0();
case 1990495124: return bem_getClassOutput_0();
case -685678485: return bem_fullLibEmitNameGet_0();
case 553413537: return bem_idToNameGet_0();
case -557497764: return bem_deserializeClassNameGet_0();
case 1747664298: return bem_transGet_0();
case 309957548: return bem_boolNpGet_0();
case -1647398831: return bem_initialDecGet_0();
case -991331785: return bem_serializationIteratorGet_0();
case -1992180182: return bem_maxDynArgsGetDirect_0();
case 355644375: return bem_classConfGet_0();
case 1773920745: return bem_classesInDepthOrderGet_0();
case 1970313708: return bem_qGetDirect_0();
case 618670577: return bem_classNameGet_0();
case 806600190: return bem_stringNpGet_0();
case 1432850430: return bem_methodBodyGetDirect_0();
case -2145860116: return bem_onceDecsGet_0();
case 1084361236: return bem_nativeCSlotsGet_0();
case -1014918687: return bem_dynMethodsGetDirect_0();
case -1838847527: return bem_many_0();
case -1194481712: return bem_lastMethodBodySizeGet_0();
case -705961525: return bem_hashGet_0();
case -495684665: return bem_ccCacheGetDirect_0();
case -657483833: return bem_ccCacheGet_0();
case 882070085: return bem_maxSpillArgsLenGetDirect_0();
case 1288805960: return bem_randGet_0();
case 1177210953: return bem_synEmitPathGet_0();
case 1151234129: return bem_instanceEqualGetDirect_0();
case 690515538: return bem_csynGet_0();
case -485067865: return bem_nlGet_0();
case 281395803: return bem_instOfGet_0();
case 2011825755: return bem_smnlecsGet_0();
case -517500515: return bem_methodsGetDirect_0();
case -27504228: return bem_synEmitPathGetDirect_0();
case 149766759: return bem_lastMethodsSizeGetDirect_0();
case 804644973: return bem_methodCatchGet_0();
case -131637366: return bem_falseValueGet_0();
case -1782289019: return bem_buildCreate_0();
case 25077375: return bem_lastMethodBodySizeGetDirect_0();
case 1782250634: return bem_randGetDirect_0();
case 722412187: return bem_constGetDirect_0();
case 1514753185: return bem_classCallsGetDirect_0();
case 1547457702: return bem_instanceNotEqualGetDirect_0();
case 1339595438: return bem_transGetDirect_0();
case -1945052846: return bem_onceCountGet_0();
case 1441040566: return bem_sourceFileNameGet_0();
case 1902385855: return bem_smnlcsGetDirect_0();
case 1120246981: return bem_qGet_0();
case 907259080: return bem_callNamesGet_0();
case -312851663: return bem_nativeCSlotsGetDirect_0();
case -695481552: return bem_libEmitPathGet_0();
case 1388166869: return bem_smnlcsGet_0();
case 313512152: return bem_buildInitial_0();
case 1439997659: return bem_methodsGet_0();
case -324451566: return bem_mainStartGet_0();
case 1779493624: return bem_propertyDecsGetDirect_0();
case -985556749: return bem_lastMethodsSizeGet_0();
case -1021414675: return bem_nameToIdGet_0();
case 2114298647: return bem_inFilePathedGet_0();
case -1302286153: return bem_fieldNamesGet_0();
case 1654924105: return bem_objectCcGet_0();
case -174224718: return bem_coanyiantReturnsGet_0();
case -1680920919: return bem_nullValueGet_0();
case 1207687001: return bem_exceptDecGetDirect_0();
case -1582894954: return bem_print_0();
case 1005595529: return bem_nameToIdGetDirect_0();
case -858488204: return bem_mainInClassGet_0();
case -763349914: return bem_spropDecGet_0();
case -534943647: return bem_intNpGetDirect_0();
case 608674724: return bem_dynMethodsGet_0();
case 169215909: return bem_getLibOutput_0();
case 549214647: return bem_returnTypeGet_0();
case -741944257: return bem_serializeToString_0();
case 301479381: return bem_ccMethodsGetDirect_0();
case 754989529: return bem_methodCatchGetDirect_0();
case 1345804258: return bem_cnodeGet_0();
case 1485377510: return bem_boolTypeGet_0();
case -1353413645: return bem_csynGetDirect_0();
case -1678598672: return bem_cnodeGetDirect_0();
case 955287070: return bem_methodBodyGet_0();
case -2074396717: return bem_superCallsGetDirect_0();
case 728743988: return bem_maxDynArgsGet_0();
case -952282697: return bem_lastMethodBodyLinesGetDirect_0();
case -1849636939: return bem_mainOutsideNsGet_0();
case -692942936: return bem_mnodeGet_0();
case -929078363: return bem_constGet_0();
case -112196705: return bem_writeBET_0();
case 564848: return bem_classEmitsGet_0();
case 1834147955: return bem_objectNpGet_0();
case -749659777: return bem_serializeContents_0();
case -2079467146: return bem_boolCcGetDirect_0();
case 464363151: return bem_objectNpGetDirect_0();
case -1356046480: return bem_preClassGetDirect_0();
case -41906332: return bem_idToNameGetDirect_0();
case 1909345950: return bem_lineCountGetDirect_0();
case 582152872: return bem_saveSyns_0();
case 1686074545: return bem_returnTypeGetDirect_0();
case -1841553076: return bem_fieldIteratorGet_0();
case 1002417852: return bem_boolNpGetDirect_0();
case -450268865: return bem_mnodeGetDirect_0();
case -641821895: return bem_baseMtdDecGet_0();
case 898404557: return bem_superNameGet_0();
case 1840508630: return bem_lastMethodsLinesGetDirect_0();
case -1045636314: return bem_classEmitsGetDirect_0();
case -935373025: return bem_create_0();
case -145610994: return bem_parentConfGet_0();
case -1888097011: return bem_methodCallsGetDirect_0();
case -1925960956: return bem_nullValueGetDirect_0();
case 1355957500: return bem_smnlecsGetDirect_0();
case 1825090322: return bem_runtimeInitGet_0();
case 1756632377: return bem_invpGet_0();
case -725139267: return bem_libEmitPathGetDirect_0();
case 267455814: return bem_typeDecGet_0();
case -813612873: return bem_trueValueGet_0();
case -752630629: return bem_nlGetDirect_0();
case 537383271: return bem_new_0();
case 1716682611: return bem_inFilePathedGetDirect_0();
case 242952061: return bem_methodCallsGet_0();
case -1336822145: return bem_classCallsGet_0();
case -1130824577: return bem_msynGet_0();
case 524585348: return bem_exceptDecGet_0();
case 656380307: return bem_libEmitNameGetDirect_0();
case 49459098: return bem_falseValueGetDirect_0();
case 297335731: return bem_libEmitNameGet_0();
case 759739321: return bem_emitLangGetDirect_0();
case -1607921594: return bem_iteratorGet_0();
case -574832585: return bem_objectCcGetDirect_0();
case 657097676: return bem_propDecGet_0();
case 1411120096: return bem_useDynMethodsGet_0();
case -1874711025: return bem_ccMethodsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1867146996: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1572789753: return bem_instanceEqualSetDirect_1(bevd_0);
case -804258923: return bem_ccMethodsSet_1(bevd_0);
case -561313441: return bem_nullValueSetDirect_1(bevd_0);
case -1418701370: return bem_methodsSet_1(bevd_0);
case 1616772606: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -776610593: return bem_emitLangSetDirect_1(bevd_0);
case 2137121684: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1237105374: return bem_notEquals_1(bevd_0);
case 1165915226: return bem_propertyDecsSetDirect_1(bevd_0);
case -1321164122: return bem_superCallsSet_1(bevd_0);
case 1673871174: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 5274010: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 333241685: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1887604349: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -683555870: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -392886504: return bem_instOfSet_1(bevd_0);
case -975670488: return bem_objectNpSetDirect_1(bevd_0);
case 1483369915: return bem_sameObject_1(bevd_0);
case 2010541143: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -2057830256: return bem_libEmitNameSetDirect_1(bevd_0);
case -139208898: return bem_callNamesSetDirect_1(bevd_0);
case 97981859: return bem_undef_1(bevd_0);
case 364021390: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -2133540386: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1860913293: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1399242431: return bem_synEmitPathSet_1(bevd_0);
case 1594611098: return bem_methodCallsSetDirect_1(bevd_0);
case 1865186242: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1282408562: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1846749819: return bem_lastMethodsSizeSet_1(bevd_0);
case -19272151: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1782331842: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1079548448: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1878158151: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 2133068283: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -2107966089: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1494255625: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 592362545: return bem_trueValueSet_1(bevd_0);
case 1598580725: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 333429893: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1807803343: return bem_transSet_1(bevd_0);
case 928757146: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -48103157: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 529067620: return bem_sameType_1(bevd_0);
case -1409358770: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 584045355: return bem_boolCcSetDirect_1(bevd_0);
case -1011683620: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -259934509: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2015781021: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1188071559: return bem_falseValueSetDirect_1(bevd_0);
case -355889064: return bem_boolNpSetDirect_1(bevd_0);
case 2043354352: return bem_libEmitPathSetDirect_1(bevd_0);
case 1518013008: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 2131345023: return bem_parentConfSet_1(bevd_0);
case -2038574818: return bem_classCallsSet_1(bevd_0);
case -508654382: return bem_floatNpSet_1(bevd_0);
case -546493801: return bem_intNpSetDirect_1(bevd_0);
case -1776285771: return bem_dynMethodsSetDirect_1(bevd_0);
case -1829615048: return bem_ccMethodsSetDirect_1(bevd_0);
case -437598777: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 270479144: return bem_preClassSet_1(bevd_0);
case 1092617648: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1819774428: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1011252127: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 1616598333: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 382067458: return bem_nativeCSlotsSet_1(bevd_0);
case -139872710: return bem_intNpSet_1(bevd_0);
case -989925497: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1133754075: return bem_objectCcSetDirect_1(bevd_0);
case 2137670049: return bem_invpSet_1(bevd_0);
case 387028581: return bem_exceptDecSetDirect_1(bevd_0);
case -1769344982: return bem_boolNpSet_1(bevd_0);
case 293923702: return bem_def_1(bevd_0);
case 524066318: return bem_callNamesSet_1(bevd_0);
case -2127585490: return bem_propertyDecsSet_1(bevd_0);
case 493086637: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -654253744: return bem_ntypesSet_1(bevd_0);
case -1434736665: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1192398017: return bem_idToNameSet_1(bevd_0);
case -167158523: return bem_otherType_1(bevd_0);
case -2069429881: return bem_ntypesSetDirect_1(bevd_0);
case -25704185: return bem_nlSet_1(bevd_0);
case 2117181987: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 889920574: return bem_stringNpSet_1(bevd_0);
case 390951410: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1768807264: return bem_libEmitPathSet_1(bevd_0);
case 1945420414: return bem_methodCallsSet_1(bevd_0);
case -1999813218: return bem_inFilePathedSetDirect_1(bevd_0);
case -983507262: return bem_lineCountSetDirect_1(bevd_0);
case 1855452936: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 609279636: return bem_instanceEqualSet_1(bevd_0);
case 488204179: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -639514924: return bem_returnTypeSetDirect_1(bevd_0);
case -156495432: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -72605619: return bem_qSetDirect_1(bevd_0);
case 1748975894: return bem_smnlecsSetDirect_1(bevd_0);
case -1830241337: return bem_equals_1(bevd_0);
case 1385946476: return bem_scvpSet_1(bevd_0);
case -715572332: return bem_nullValueSet_1(bevd_0);
case -2105480375: return bem_objectNpSet_1(bevd_0);
case 1971942934: return bem_end_1(bevd_0);
case -1569948100: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 563895728: return bem_classCallsSetDirect_1(bevd_0);
case -50074825: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1898588345: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 957685950: return bem_onceDecsSet_1(bevd_0);
case -1036392689: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1124045517: return bem_maxSpillArgsLenSet_1(bevd_0);
case -301603618: return bem_inFilePathedSet_1(bevd_0);
case 1952465051: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1892554469: return bem_classConfSet_1(bevd_0);
case -2085686581: return bem_defined_1(bevd_0);
case 2035316402: return bem_lastMethodsLinesSet_1(bevd_0);
case 1196996781: return bem_fileExtSetDirect_1(bevd_0);
case -1289820183: return bem_floatNpSetDirect_1(bevd_0);
case -651924031: return bem_instOfSetDirect_1(bevd_0);
case -207807469: return bem_fullLibEmitNameSet_1(bevd_0);
case -1252712745: return bem_mnodeSetDirect_1(bevd_0);
case 1086888092: return bem_onceCountSetDirect_1(bevd_0);
case 1871252873: return bem_instanceNotEqualSet_1(bevd_0);
case 2070009132: return bem_objectCcSet_1(bevd_0);
case 949246746: return bem_randSetDirect_1(bevd_0);
case 239697519: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1704743287: return bem_methodCatchSetDirect_1(bevd_0);
case 1191882668: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 645608757: return bem_classEmitsSet_1(bevd_0);
case -1503059253: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1483218369: return bem_smnlecsSet_1(bevd_0);
case 785746342: return bem_msynSetDirect_1(bevd_0);
case -1961167423: return bem_smnlcsSetDirect_1(bevd_0);
case -1392415700: return bem_methodCatchSet_1(bevd_0);
case -1365036339: return bem_libEmitNameSet_1(bevd_0);
case -767719732: return bem_constSetDirect_1(bevd_0);
case -288050318: return bem_constSet_1(bevd_0);
case 183706504: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -433530483: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 2061885958: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 623997564: return bem_lastCallSetDirect_1(bevd_0);
case -1242396909: return bem_randSet_1(bevd_0);
case -926340668: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1330156098: return bem_copyTo_1(bevd_0);
case -158081994: return bem_buildSet_1(bevd_0);
case 1901619826: return bem_fileExtSet_1(bevd_0);
case 267108470: return bem_parentConfSetDirect_1(bevd_0);
case -1632045681: return bem_dynMethodsSet_1(bevd_0);
case -793760468: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1280508563: return bem_onceDecsSetDirect_1(bevd_0);
case 1737972322: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -141397341: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1837655444: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1471485508: return bem_lastCallSet_1(bevd_0);
case -2055530030: return bem_idToNameSetDirect_1(bevd_0);
case 233166615: return bem_trueValueSetDirect_1(bevd_0);
case 343682012: return bem_msynSet_1(bevd_0);
case 1070194428: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1824749389: return bem_cnodeSet_1(bevd_0);
case 609314944: return bem_boolCcSet_1(bevd_0);
case 1748491906: return bem_sameClass_1(bevd_0);
case 1855913687: return bem_nlSetDirect_1(bevd_0);
case -1164766451: return bem_preClassSetDirect_1(bevd_0);
case -471548500: return bem_ccCacheSetDirect_1(bevd_0);
case 2128406309: return bem_methodBodySetDirect_1(bevd_0);
case -228872039: return bem_otherClass_1(bevd_0);
case -639465866: return bem_nameToIdSetDirect_1(bevd_0);
case -304647897: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -990280473: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -3030501: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -473309678: return bem_methodsSetDirect_1(bevd_0);
case 494270408: return bem_cnodeSetDirect_1(bevd_0);
case 1681868832: return bem_methodBodySet_1(bevd_0);
case -587031313: return bem_maxDynArgsSetDirect_1(bevd_0);
case 1057983000: return bem_nameToIdSet_1(bevd_0);
case 659675994: return bem_undefined_1(bevd_0);
case -1486106108: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1565951468: return bem_exceptDecSet_1(bevd_0);
case -1550955843: return bem_onceCountSet_1(bevd_0);
case -1687380461: return bem_invpSetDirect_1(bevd_0);
case -295167093: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -721041190: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 245979374: return bem_emitLangSet_1(bevd_0);
case -531775375: return bem_lineCountSet_1(bevd_0);
case -427434681: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1392547808: return bem_csynSet_1(bevd_0);
case 1578854629: return bem_begin_1(bevd_0);
case 1013402984: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1866874657: return bem_classEmitsSetDirect_1(bevd_0);
case -869493094: return bem_qSet_1(bevd_0);
case 341126984: return bem_scvpSetDirect_1(bevd_0);
case 790292156: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -191280165: return bem_smnlcsSet_1(bevd_0);
case -971994568: return bem_falseValueSet_1(bevd_0);
case 377687085: return bem_superCallsSetDirect_1(bevd_0);
case 1799122234: return bem_synEmitPathSetDirect_1(bevd_0);
case -701704104: return bem_classesInDepthOrderSet_1(bevd_0);
case 107287138: return bem_maxDynArgsSet_1(bevd_0);
case 1946873323: return bem_returnTypeSet_1(bevd_0);
case 1300612886: return bem_ccCacheSet_1(bevd_0);
case -1084336724: return bem_mnodeSet_1(bevd_0);
case 2065555930: return bem_lastMethodBodySizeSet_1(bevd_0);
case -589537192: return bem_csynSetDirect_1(bevd_0);
case -790895950: return bem_buildSetDirect_1(bevd_0);
case 485130855: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1413249124: return bem_stringNpSetDirect_1(bevd_0);
case 1396370439: return bem_classConfSetDirect_1(bevd_0);
case -329688063: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 160794837: return bem_transSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1900266912: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 327810818: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1382151939: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 258023047: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1754482767: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1960362835: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1429448486: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -692749193: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1765513582: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1363285011: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 220295188: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 764010202: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 903789674: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1600914698: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 246296720: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1581599125: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1984157078: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1258452187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1846932381: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1342344363: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 9075823: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 750149289: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 988973130: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1541791748: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -998387646: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 146172619: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
