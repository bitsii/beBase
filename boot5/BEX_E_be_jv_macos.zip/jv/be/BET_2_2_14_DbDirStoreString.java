package be;
public class BET_2_2_14_DbDirStoreString extends BETS_Object {
public BET_2_2_14_DbDirStoreString() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_2", "new_1", "pathNew_1", "getStoreId_1", "getPath_1", "put_2", "get_1", "contains_1", "delete_1", "serGet_0", "serSet_1", "storageDirGet_0", "storageDirSet_1", "keyEncoderGet_0", "keyEncoderSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "ser", "storageDir", "keyEncoder" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_2_14_DbDirStoreString();
}
}
