package be;
public class BET_2_7_7_ReplaceRunStep extends BETS_Object {
public BET_2_7_7_ReplaceRunStep() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "new_2", "handle_1", "replaceGet_0", "replaceGetDirect_0", "replaceSet_1", "replaceSetDirect_1", "strGet_0", "strGetDirect_0", "strSet_1", "strSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "replace", "str" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_7_7_ReplaceRunStep();
}
}
