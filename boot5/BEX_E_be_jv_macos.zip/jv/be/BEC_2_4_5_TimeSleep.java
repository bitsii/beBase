package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeSleep extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_TimeSleep() { }
private static byte[] becc_BEC_2_4_5_TimeSleep_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x6C,0x65,0x65,0x70};
private static byte[] becc_BEC_2_4_5_TimeSleep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_0 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_1 = (new BEC_2_4_3_MathInt(1000));
public static BEC_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_inst;
public BEC_2_4_5_TimeSleep bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_sleep_1(BEC_2_4_8_TimeInterval beva_interval) throws Throwable {
BEC_2_4_3_MathInt bevl_secs = null;
BEC_2_4_3_MathInt bevl_millis = null;
BEC_2_4_3_MathInt bevl_sleepMillis = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
if (beva_interval == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevl_secs = beva_interval.bem_secsGet_0();
bevl_millis = beva_interval.bem_millisGet_0();
if (bevl_secs == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 38 */ {
if (bevl_millis == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 38 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 38 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_0;
bevt_4_tmpany_phold = bevl_secs.bem_multiply_1(bevt_5_tmpany_phold);
bevl_sleepMillis = bevt_4_tmpany_phold.bem_add_1(bevl_millis);
bem_sleepMilliseconds_1(bevl_sleepMillis);
} /* Line: 40 */
} /* Line: 38 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sleepSeconds_1(BEC_2_4_3_MathInt beva_secs) throws Throwable {
BEC_2_4_5_TimeSleep bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_1;
bevt_1_tmpany_phold = beva_secs.bem_multiply_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_sleepMilliseconds_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_sleepMilliseconds_1(BEC_2_4_3_MathInt beva_msecs) throws Throwable {

      Thread.sleep(beva_msecs.bevi_int);
      return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {35, 35, 36, 37, 38, 38, 38, 38, 0, 0, 0, 39, 39, 39, 40, 46, 46, 46, 46};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 31, 32, 33, 34, 39, 40, 45, 46, 49, 53, 56, 57, 58, 59, 68, 69, 70, 71};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 35 26
def 1 35 31
assign 1 36 32
secsGet 0 36 32
assign 1 37 33
millisGet 0 37 33
assign 1 38 34
def 1 38 39
assign 1 38 40
def 1 38 45
assign 1 0 46
assign 1 0 49
assign 1 0 53
assign 1 39 56
new 0 39 56
assign 1 39 57
multiply 1 39 57
assign 1 39 58
add 1 39 58
sleepMilliseconds 1 40 59
assign 1 46 68
new 0 46 68
assign 1 46 69
multiply 1 46 69
assign 1 46 70
sleepMilliseconds 1 46 70
return 1 46 71
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -1436664914: return bem_print_0();
case -373295708: return bem_serializeContents_0();
case -180143514: return bem_serializationIteratorGet_0();
case -1860146814: return bem_tagGet_0();
case -2116220804: return bem_new_0();
case -268338848: return bem_fieldIteratorGet_0();
case -454647513: return bem_once_0();
case -1021276807: return bem_copy_0();
case -453378259: return bem_deserializeClassNameGet_0();
case -2006878754: return bem_create_0();
case -1274969629: return bem_iteratorGet_0();
case 810650310: return bem_serializeToString_0();
case -1329156032: return bem_echo_0();
case -948992842: return bem_default_0();
case 1737839713: return bem_toString_0();
case -1682959242: return bem_many_0();
case -681406586: return bem_hashGet_0();
case -605259456: return bem_toAny_0();
case -1250381101: return bem_classNameGet_0();
case -416881840: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 14292419: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1468796062: return bem_sameType_1(bevd_0);
case -476510443: return bem_sleepSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -461593490: return bem_copyTo_1(bevd_0);
case -1196486530: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1688597634: return bem_sameClass_1(bevd_0);
case -935094060: return bem_undefined_1(bevd_0);
case -1480218954: return bem_def_1(bevd_0);
case -888403607: return bem_sameObject_1(bevd_0);
case -1728638213: return bem_otherClass_1(bevd_0);
case -1682487504: return bem_sleep_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1096308396: return bem_notEquals_1(bevd_0);
case -417583753: return bem_defined_1(bevd_0);
case 434478091: return bem_equals_1(bevd_0);
case 198442872: return bem_sleepMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 312688457: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -779433144: return bem_undef_1(bevd_0);
case 1922760127: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 98957888: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 811659277: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -140724102: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 565033879: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1767747865: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2047096971: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 656540134: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1888103: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeSleep_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeSleep_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_TimeSleep();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst = (BEC_2_4_5_TimeSleep) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst;
}
}
