package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeSleep extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_TimeSleep() { }
private static byte[] becc_BEC_2_4_5_TimeSleep_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x6C,0x65,0x65,0x70};
private static byte[] becc_BEC_2_4_5_TimeSleep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_0 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_1 = (new BEC_2_4_3_MathInt(1000));
public static BEC_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_inst;

public static BET_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_type;

public BEC_2_4_5_TimeSleep bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_sleep_1(BEC_2_4_8_TimeInterval beva_interval) throws Throwable {
BEC_2_4_3_MathInt bevl_secs = null;
BEC_2_4_3_MathInt bevl_millis = null;
BEC_2_4_3_MathInt bevl_sleepMillis = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
if (beva_interval == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevl_secs = beva_interval.bem_secsGet_0();
bevl_millis = beva_interval.bem_millisGet_0();
if (bevl_secs == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 38 */ {
if (bevl_millis == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 38 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 38 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_0;
bevt_4_tmpany_phold = bevl_secs.bem_multiply_1(bevt_5_tmpany_phold);
bevl_sleepMillis = bevt_4_tmpany_phold.bem_add_1(bevl_millis);
bem_sleepMilliseconds_1(bevl_sleepMillis);
} /* Line: 40 */
} /* Line: 38 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sleepSeconds_1(BEC_2_4_3_MathInt beva_secs) throws Throwable {
BEC_2_4_5_TimeSleep bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_1;
bevt_1_tmpany_phold = beva_secs.bem_multiply_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_sleepMilliseconds_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_5_TimeSleep bem_sleepMilliseconds_1(BEC_2_4_3_MathInt beva_msecs) throws Throwable {

      Thread.sleep(beva_msecs.bevi_int);
      return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {35, 35, 36, 37, 38, 38, 38, 38, 0, 0, 0, 39, 39, 39, 40, 46, 46, 46, 46};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {29, 34, 35, 36, 37, 42, 43, 48, 49, 52, 56, 59, 60, 61, 62, 71, 72, 73, 74};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 35 29
def 1 35 34
assign 1 36 35
secsGet 0 36 35
assign 1 37 36
millisGet 0 37 36
assign 1 38 37
def 1 38 42
assign 1 38 43
def 1 38 48
assign 1 0 49
assign 1 0 52
assign 1 0 56
assign 1 39 59
new 0 39 59
assign 1 39 60
multiply 1 39 60
assign 1 39 61
add 1 39 61
sleepMilliseconds 1 40 62
assign 1 46 71
new 0 46 71
assign 1 46 72
multiply 1 46 72
assign 1 46 73
sleepMilliseconds 1 46 73
return 1 46 74
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 520238370: return bem_print_0();
case 1754760186: return bem_iteratorGet_0();
case 1841075196: return bem_deserializeClassNameGet_0();
case 834974873: return bem_once_0();
case -1153621323: return bem_sourceFileNameGet_0();
case -516300936: return bem_many_0();
case -260016569: return bem_new_0();
case 1363596807: return bem_toAny_0();
case 1695553285: return bem_toString_0();
case 510740763: return bem_echo_0();
case -1906011811: return bem_classNameGet_0();
case -1481120: return bem_hashGet_0();
case 1934827441: return bem_tagGet_0();
case -2049404332: return bem_fieldIteratorGet_0();
case 1246525343: return bem_copy_0();
case 629513215: return bem_create_0();
case -1395512224: return bem_default_0();
case -1151122392: return bem_serializeToString_0();
case -319884304: return bem_serializationIteratorGet_0();
case 80505915: return bem_fieldNamesGet_0();
case -1784818407: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -218159859: return bem_sleep_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1219650476: return bem_sleepMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 462621647: return bem_def_1(bevd_0);
case -1512005598: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1177836823: return bem_sameType_1(bevd_0);
case -951929577: return bem_defined_1(bevd_0);
case 1049358928: return bem_equals_1(bevd_0);
case -1573802551: return bem_sameObject_1(bevd_0);
case 1632353878: return bem_undef_1(bevd_0);
case 216738391: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1430178609: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1503622406: return bem_sleepSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 482689426: return bem_otherClass_1(bevd_0);
case 1523343000: return bem_sameClass_1(bevd_0);
case -228195679: return bem_copyTo_1(bevd_0);
case 2122170094: return bem_otherType_1(bevd_0);
case -1144341678: return bem_notEquals_1(bevd_0);
case -395850459: return bem_undefined_1(bevd_0);
case 989721692: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1872811781: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 518732674: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1018924161: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 308804077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2072018670: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -357078730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -277637599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeSleep_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeSleep_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_TimeSleep();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst = (BEC_2_4_5_TimeSleep) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_type;
}
}
