package be;
/* IO:File: source/build/Pass2.be */
public final class BEC_3_5_5_5_BuildVisitPass2 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass2() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass2_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x32};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass2_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass2_bels_0 = {0x2E};
public static BEC_3_5_5_5_BuildVisitPass2 bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass2 bece_BEC_3_5_5_5_BuildVisitPass2_bevs_type;

public BEC_2_4_3_MathInt bevp_idType;
public BEC_2_4_3_MathInt bevp_intType;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public BEC_3_5_5_5_BuildVisitPass2 bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_ta_ph = null;
BEC_2_5_9_BuildConstants bevt_1_ta_ph = null;
super.bem_begin_1(beva_transi);
bevp_idType = bevp_ntypes.bem_IDGet_0();
bevp_intType = bevp_ntypes.bem_INTLGet_0();
bevt_0_ta_ph = bevp_build.bem_constantsGet_0();
bevp_matchMap = bevt_0_ta_ph.bem_matchMapGet_0();
bevt_1_ta_ph = bevp_build.bem_constantsGet_0();
bevp_rwords = bevt_1_ta_ph.bem_rwordsGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_held = null;
BEC_2_6_6_SystemObject bevl_type = null;
BEC_2_5_4_BuildNode bevl_nxp = null;
BEC_2_5_4_BuildNode bevl_nxp2 = null;
BEC_2_5_4_BuildNode bevl_nxp3 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_BuildNode bevt_27_ta_ph = null;
bevt_3_ta_ph = beva_node.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 29*/ {
bevt_5_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_5_ta_ph;
} /* Line: 30*/
bevl_held = beva_node.bem_heldGet_0();
if (bevl_held == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 33*/ {
bevl_type = bevp_matchMap.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 35*/ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 37*/
 else /* Line: 38*/ {
bevt_8_ta_ph = bevl_held.bemd_0(-449025746);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 40*/ {
bevl_nxp = beva_node.bem_nextPeerGet_0();
if (bevl_nxp == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_11_ta_ph = bevl_nxp.bem_heldGet_0();
if (bevt_11_ta_ph == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 42*/
 else /* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 42*/ {
bevt_13_ta_ph = bevl_nxp.bem_heldGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass2_bels_0));
bevt_12_ta_ph = bevt_13_ta_ph.bemd_1(-301008142, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 43*/ {
bevl_nxp2 = bevl_nxp.bem_nextPeerGet_0();
if (bevl_nxp2 == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 45*/ {
bevt_17_ta_ph = bevl_nxp2.bem_heldGet_0();
if (bevt_17_ta_ph == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 45*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 45*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 45*/
 else /* Line: 45*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 45*/ {
bevl_nxp3 = bevl_nxp2.bem_nextDescendGet_0();
bevt_19_ta_ph = bevl_nxp2.bem_heldGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-449025746);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 47*/ {
bevt_22_ta_ph = beva_node.bem_heldGet_0();
bevt_23_ta_ph = bevl_nxp.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(300457019, bevt_23_ta_ph);
bevt_24_ta_ph = bevl_nxp2.bem_heldGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_1(300457019, bevt_24_ta_ph);
beva_node.bem_heldSet_1(bevt_20_ta_ph);
bevt_25_ta_ph = bevp_ntypes.bem_FLOATLGet_0();
beva_node.bem_typenameSet_1(bevt_25_ta_ph);
bevl_nxp2.bem_delete_0();
bevl_nxp.bem_delete_0();
return bevl_nxp3;
} /* Line: 52*/
} /* Line: 47*/
} /* Line: 45*/
} /* Line: 43*/
beva_node.bem_typenameSet_1(bevp_intType);
} /* Line: 57*/
 else /* Line: 58*/ {
bevl_type = bevp_rwords.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 60*/ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 61*/
 else /* Line: 62*/ {
beva_node.bem_typenameSet_1(bevp_idType);
} /* Line: 63*/
} /* Line: 60*/
} /* Line: 40*/
} /* Line: 35*/
bevt_27_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_27_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_idTypeGet_0() throws Throwable {
return bevp_idType;
} /*method end*/
public final BEC_2_4_3_MathInt bem_idTypeGetDirect_0() throws Throwable {
return bevp_idType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_idTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass2 bem_idTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intTypeGet_0() throws Throwable {
return bevp_intType;
} /*method end*/
public final BEC_2_4_3_MathInt bem_intTypeGetDirect_0() throws Throwable {
return bevp_intType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_intTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass2 bem_intTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() throws Throwable {
return bevp_matchMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_matchMapGetDirect_0() throws Throwable {
return bevp_matchMap;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass2 bem_matchMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() throws Throwable {
return bevp_rwords;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_rwordsGetDirect_0() throws Throwable {
return bevp_rwords;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_5_5_5_BuildVisitPass2 bem_rwordsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15, 18, 19, 20, 20, 21, 21, 29, 29, 29, 29, 30, 30, 32, 33, 33, 34, 35, 35, 37, 40, 41, 42, 42, 42, 42, 42, 0, 0, 0, 43, 43, 43, 44, 45, 45, 45, 45, 45, 0, 0, 0, 46, 47, 47, 48, 48, 48, 48, 48, 48, 49, 49, 50, 51, 52, 57, 59, 60, 60, 61, 63, 68, 68, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 22, 23, 24, 25, 62, 63, 64, 69, 70, 71, 73, 74, 79, 80, 81, 86, 87, 90, 92, 93, 98, 99, 100, 105, 106, 109, 113, 116, 117, 118, 120, 121, 126, 127, 128, 133, 134, 137, 141, 144, 145, 146, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 163, 166, 167, 172, 173, 176, 181, 182, 185, 188, 191, 195, 199, 202, 205, 209, 213, 216, 219, 223, 227, 230, 233, 237};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 15 19
assign 1 18 20
IDGet 0 18 20
assign 1 19 21
INTLGet 0 19 21
assign 1 20 22
constantsGet 0 20 22
assign 1 20 23
matchMapGet 0 20 23
assign 1 21 24
constantsGet 0 21 24
assign 1 21 25
rwordsGet 0 21 25
assign 1 29 62
typenameGet 0 29 62
assign 1 29 63
TRANSUNITGet 0 29 63
assign 1 29 64
equals 1 29 69
assign 1 30 70
nextDescendGet 0 30 70
return 1 30 71
assign 1 32 73
heldGet 0 32 73
assign 1 33 74
def 1 33 79
assign 1 34 80
get 1 34 80
assign 1 35 81
def 1 35 86
typenameSet 1 37 87
assign 1 40 90
isInteger 0 40 90
assign 1 41 92
nextPeerGet 0 41 92
assign 1 42 93
def 1 42 98
assign 1 42 99
heldGet 0 42 99
assign 1 42 100
def 1 42 105
assign 1 0 106
assign 1 0 109
assign 1 0 113
assign 1 43 116
heldGet 0 43 116
assign 1 43 117
new 0 43 117
assign 1 43 118
equals 1 43 118
assign 1 44 120
nextPeerGet 0 44 120
assign 1 45 121
def 1 45 126
assign 1 45 127
heldGet 0 45 127
assign 1 45 128
def 1 45 133
assign 1 0 134
assign 1 0 137
assign 1 0 141
assign 1 46 144
nextDescendGet 0 46 144
assign 1 47 145
heldGet 0 47 145
assign 1 47 146
isInteger 0 47 146
assign 1 48 148
heldGet 0 48 148
assign 1 48 149
heldGet 0 48 149
assign 1 48 150
add 1 48 150
assign 1 48 151
heldGet 0 48 151
assign 1 48 152
add 1 48 152
heldSet 1 48 153
assign 1 49 154
FLOATLGet 0 49 154
typenameSet 1 49 155
delete 0 50 156
delete 0 51 157
return 1 52 158
typenameSet 1 57 163
assign 1 59 166
get 1 59 166
assign 1 60 167
def 1 60 172
typenameSet 1 61 173
typenameSet 1 63 176
assign 1 68 181
nextDescendGet 0 68 181
return 1 68 182
return 1 0 185
return 1 0 188
assign 1 0 191
assign 1 0 195
return 1 0 199
return 1 0 202
assign 1 0 205
assign 1 0 209
return 1 0 213
return 1 0 216
assign 1 0 219
assign 1 0 223
return 1 0 227
return 1 0 230
assign 1 0 233
assign 1 0 237
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -650715648: return bem_buildGetDirect_0();
case 2047666849: return bem_rwordsGetDirect_0();
case -562673954: return bem_matchMapGetDirect_0();
case 67700549: return bem_classNameGet_0();
case -1811482663: return bem_constGet_0();
case -1325598060: return bem_ntypesGet_0();
case 138302413: return bem_new_0();
case 1978769872: return bem_rwordsGet_0();
case -1627734356: return bem_serializeToString_0();
case 1930587: return bem_ntypesGetDirect_0();
case 556090396: return bem_sourceFileNameGet_0();
case 575700029: return bem_transGet_0();
case 432179744: return bem_fieldNamesGet_0();
case 178019168: return bem_toString_0();
case 1609612359: return bem_echo_0();
case 719900200: return bem_intTypeGetDirect_0();
case 2054369322: return bem_constGetDirect_0();
case 432917421: return bem_idTypeGet_0();
case 2036051475: return bem_iteratorGet_0();
case -2106036149: return bem_deserializeClassNameGet_0();
case -1855760887: return bem_intTypeGet_0();
case 1132429880: return bem_tagGet_0();
case -122021528: return bem_transGetDirect_0();
case 1267631579: return bem_serializationIteratorGet_0();
case 478950400: return bem_print_0();
case -811046848: return bem_copy_0();
case -1564975844: return bem_serializeContents_0();
case 1570205348: return bem_idTypeGetDirect_0();
case 712783465: return bem_hashGet_0();
case -1812965558: return bem_fieldIteratorGet_0();
case -1442246006: return bem_matchMapGet_0();
case -296401725: return bem_buildGet_0();
case -1747597055: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1420250336: return bem_matchMapSetDirect_1(bevd_0);
case 823299339: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 84457521: return bem_begin_1(bevd_0);
case 1184247111: return bem_sameClass_1(bevd_0);
case 950025189: return bem_transSetDirect_1(bevd_0);
case -1187014040: return bem_transSet_1(bevd_0);
case 465594002: return bem_def_1(bevd_0);
case 79830822: return bem_rwordsSetDirect_1(bevd_0);
case 808739847: return bem_intTypeSet_1(bevd_0);
case 658718874: return bem_constSetDirect_1(bevd_0);
case 2033271346: return bem_buildSetDirect_1(bevd_0);
case 229123535: return bem_ntypesSet_1(bevd_0);
case 2125167696: return bem_end_1(bevd_0);
case -225795861: return bem_sameType_1(bevd_0);
case 399670111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1383358174: return bem_idTypeSet_1(bevd_0);
case 1059784807: return bem_constSet_1(bevd_0);
case 606870566: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -60802666: return bem_otherClass_1(bevd_0);
case 1951774795: return bem_copyTo_1(bevd_0);
case 2059692827: return bem_sameObject_1(bevd_0);
case 2107311680: return bem_notEquals_1(bevd_0);
case -688801916: return bem_rwordsSet_1(bevd_0);
case 1964074985: return bem_otherType_1(bevd_0);
case -301008142: return bem_equals_1(bevd_0);
case 257683973: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 22307848: return bem_matchMapSet_1(bevd_0);
case -183169357: return bem_idTypeSetDirect_1(bevd_0);
case -1548733227: return bem_intTypeSetDirect_1(bevd_0);
case -1084952852: return bem_undef_1(bevd_0);
case 648983251: return bem_ntypesSetDirect_1(bevd_0);
case 1839754573: return bem_buildSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1035176912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1679235980: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1107212100: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 471675441: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1306506121: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass2_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass2_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass2();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst = (BEC_3_5_5_5_BuildVisitPass2) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_type;
}
}
