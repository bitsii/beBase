package be;
public class BET_2_8_6_TemplateRunner extends BETS_Object {
public BET_2_8_6_TemplateRunner() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "swapGet_0", "handOffGet_0", "new_2", "new_1", "load_1", "restart_0", "stepIterGet_0", "currentRunnerGet_0", "currentNodeGet_0", "currentNodeSet_1", "runToLabel_1", "skipToLabel_1", "run_0", "replaceGet_0", "replaceSet_1", "outputGet_0", "outputSet_1", "stepIterSet_1", "swapSet_1", "handOffSet_1", "batonGet_0", "batonSet_1", "runStepGet_0", "runStepSet_1", "stpGet_0", "stpSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "replace", "output", "stepIter", "swap", "handOff", "baton", "runStep", "stp" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_8_6_TemplateRunner();
}
}
