package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerSets extends BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerSets() { }
private static byte[] becc_BEC_2_9_4_ContainerSets_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x73};
private static byte[] becc_BEC_2_9_4_ContainerSets_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerSets_bevo_0 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_inst;

public static BET_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_type;

public BEC_2_9_4_ContainerSets bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_9_3_ContainerSet bevl_set = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_list.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerSets_bevo_0;
bevl_ssz = bevt_1_tmpany_phold.bem_multiply_1(bevt_2_tmpany_phold);
bevl_ssz.bevi_int++;
bevl_set = (new BEC_2_9_3_ContainerSet()).bem_new_1(bevl_ssz);
bevt_0_tmpany_loop = beva_list.bem_iteratorGet_0();
while (true)
 /* Line: 710 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1639542906);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 710 */ {
bevl_v = bevt_0_tmpany_loop.bemd_0(-1466225858);
bevl_set.bem_put_1(bevl_v);
} /* Line: 711 */
 else  /* Line: 710 */ {
break;
} /* Line: 710 */
} /* Line: 710 */
return bevl_set;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {707, 707, 707, 708, 709, 710, 0, 710, 710, 711, 713};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 28, 28, 31, 33, 34, 40};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 707 23
sizeGet 0 707 23
assign 1 707 24
new 0 707 24
assign 1 707 25
multiply 1 707 25
incrementValue 0 708 26
assign 1 709 27
new 1 709 27
assign 1 710 28
iteratorGet 0 0 28
assign 1 710 31
hasNextGet 0 710 31
assign 1 710 33
nextGet 0 710 33
put 1 711 34
return 1 713 40
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1045898755: return bem_classNameGet_0();
case 1568711247: return bem_fieldIteratorGet_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case -579194210: return bem_iteratorGet_0();
case -1489022328: return bem_once_0();
case 11313755: return bem_echo_0();
case -621270081: return bem_new_0();
case 448246445: return bem_fieldNamesGet_0();
case 577869439: return bem_serializeToString_0();
case -1430069919: return bem_serializeContents_0();
case -980602152: return bem_sourceFileNameGet_0();
case -1682958828: return bem_tagGet_0();
case 572016682: return bem_serializationIteratorGet_0();
case -165278261: return bem_hashGet_0();
case -1791746868: return bem_print_0();
case 102995179: return bem_default_0();
case -1168657718: return bem_create_0();
case 1476265575: return bem_toAny_0();
case 2079582721: return bem_toString_0();
case -1406264904: return bem_copy_0();
case 334571614: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case -1145012984: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerSets_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerSets_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerSets();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst = (BEC_2_9_4_ContainerSets) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_type;
}
}
