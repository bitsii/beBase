package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_10_JsonMarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_JsonMarshaller() { }
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x4D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_1 = {0x31,0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_2 = {0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_3 = {0x37};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_4 = {0x33,0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_5 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_6 = {0x5C,0x75};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_8 = {0x66,0x66,0x63,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_9 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_10 = {0x30,0x30,0x33,0x66,0x66};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_11 = {0x5B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_12 = {0x2C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_13 = {0x5D};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_14 = {0x7B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_15 = {0x3A};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_16 = {0x7D};
public static BEC_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_inst;

public static BET_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_9_4_ContainerList bevp_arr;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_boo;
public BEC_2_4_6_TextString bevp_q;
public BEC_2_4_17_TextMultiByteIterator bevp_mbi;
public BEC_2_4_6_TextString bevp_txtpt;
public BEC_2_4_6_TextString bevp_escaped;
public BEC_2_6_5_SystemTypes bevp_stp;
public BEC_2_4_10_JsonMarshaller bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevp_str = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_arr = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
bevp_boo = (new BEC_2_5_4_LogicBool()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_q = bevt_1_ta_ph.bem_quoteGet_0();
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_0();
bevp_txtpt = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_escaped = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_stp = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_marshall_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_4_6_TextString bevl_bb = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 318*/ {
bem_new_0();
} /* Line: 319*/
bevl_bb = (new BEC_2_4_6_TextString()).bem_new_0();
bem_marshallWriteInst_2(beva_inst, bevl_bb);
bevt_1_ta_ph = bevl_bb.bem_toString_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWrite_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 327*/ {
bem_new_0();
} /* Line: 328*/
bem_marshallWriteInst_2(beva_inst, beva_writer);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteInst_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (beva_inst == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 334*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_0));
beva_writer.bemd_1(-1128067899, bevt_1_ta_ph);
} /* Line: 335*/
 else /* Line: 334*/ {
bevt_2_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_str);
if (bevt_2_ta_ph.bevi_bool)/* Line: 336*/ {
bem_marshallWriteString_2((BEC_2_4_6_TextString) beva_inst , beva_writer);
} /* Line: 337*/
 else /* Line: 334*/ {
bevt_3_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_arr);
if (bevt_3_ta_ph.bevi_bool)/* Line: 338*/ {
bem_marshallWriteList_2(beva_inst, beva_writer);
} /* Line: 339*/
 else /* Line: 334*/ {
bevt_4_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_map);
if (bevt_4_ta_ph.bevi_bool)/* Line: 340*/ {
bem_marshallWriteMap_2(beva_inst, beva_writer);
} /* Line: 341*/
 else /* Line: 334*/ {
bevt_5_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_int);
if (bevt_5_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_6_ta_ph = beva_inst.bemd_0(1428575040);
beva_writer.bemd_1(-1128067899, bevt_6_ta_ph);
} /* Line: 343*/
 else /* Line: 334*/ {
bevt_7_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_boo);
if (bevt_7_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_8_ta_ph = beva_inst.bemd_0(1428575040);
beva_writer.bemd_1(-1128067899, bevt_8_ta_ph);
} /* Line: 345*/
 else /* Line: 346*/ {
bevt_9_ta_ph = beva_inst.bemd_0(1428575040);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_9_ta_ph , beva_writer);
} /* Line: 347*/
} /* Line: 334*/
} /* Line: 334*/
} /* Line: 334*/
} /* Line: 334*/
} /* Line: 334*/
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_jsonEscapePoint_2(BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_txt) throws Throwable {
BEC_2_4_3_MathInt bevl_rcap = null;
BEC_2_4_3_MathInt bevl_txtsznow = null;
BEC_2_4_3_MathInt bevl_length = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_u = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_7_JsonEscapes bevl_esc = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_first = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_4_3_MathInt bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
bevl_rcap = (new BEC_2_4_3_MathInt());
bevl_txtsznow = beva_txt.bem_lengthGet_0();
bevl_length = beva_txtpt.bem_lengthGet_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevl_u = beva_txtpt.bem_getInt_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_length.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 360*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_1));
bevt_4_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_5_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_4_ta_ph);
} /* Line: 361*/
 else /* Line: 359*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(3));
if (bevl_length.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 364*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_2));
bevt_8_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_9_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_8_ta_ph);
} /* Line: 365*/
 else /* Line: 359*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(4));
if (bevl_length.bevi_int == bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 368*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_3));
bevt_12_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_13_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_12_ta_ph);
} /* Line: 369*/
} /* Line: 359*/
} /* Line: 359*/
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_length.bevi_int > bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 371*/ {
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 372*/ {
if (bevl_i.bevi_int < bevl_length.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 373*/ {
beva_txtpt.bem_getInt_2(bevl_i, bevl_u);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_17_ta_ph = bevl_value.bem_shiftLeft_1(bevt_18_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_4));
bevt_20_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_21_ta_ph);
bevt_19_ta_ph = bevl_u.bem_and_1(bevt_20_ta_ph);
bevl_value = bevt_17_ta_ph.bem_add_1(bevt_19_ta_ph);
bevl_i.bevi_int++;
} /* Line: 372*/
 else /* Line: 372*/ {
break;
} /* Line: 372*/
} /* Line: 372*/
} /* Line: 372*/
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_length.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 379*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(0));
} /* Line: 380*/
 else /* Line: 379*/ {
bevt_25_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_length.bevi_int == bevt_25_ta_ph.bevi_int) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 381*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(2));
} /* Line: 382*/
 else /* Line: 383*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_27_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_28_ta_ph);
if (bevl_value.bevi_int < bevt_27_ta_ph.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 384*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(7));
} /* Line: 385*/
 else /* Line: 386*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(13));
} /* Line: 387*/
} /* Line: 384*/
} /* Line: 379*/
bevt_31_ta_ph = beva_txt.bem_capacityGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_subtract_1(bevl_txtsznow);
if (bevt_30_ta_ph.bevi_int < bevl_rcap.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 391*/ {
bevt_32_ta_ph = bevl_txtsznow.bem_add_1(bevl_rcap);
beva_txt.bem_capacitySet_1(bevt_32_ta_ph);
} /* Line: 392*/
bevt_34_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_rcap.bevi_int == bevt_34_ta_ph.bevi_int) {
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 395*/ {
bevl_esc = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevt_35_ta_ph = bevl_esc.bem_toEscapesGet_0();
bevl_escval = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_get_1(beva_txtpt);
if (bevl_escval == null) {
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 399*/ {
beva_txt.bem_addValue_1(bevl_escval);
} /* Line: 400*/
 else /* Line: 401*/ {
beva_txt.bem_addValue_1(beva_txtpt);
} /* Line: 403*/
} /* Line: 399*/
 else /* Line: 395*/ {
bevt_38_ta_ph = (new BEC_2_4_3_MathInt(3));
if (bevl_rcap.bevi_int > bevt_38_ta_ph.bevi_int) {
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 405*/ {
bevt_40_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_rcap.bevi_int == bevt_40_ta_ph.bevi_int) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 406*/ {
bevt_42_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_41_ta_ph = beva_txt.bem_addValue_1(bevt_42_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_44_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_47_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_48_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_43_ta_ph = bevl_value.bem_toString_4(bevt_44_ta_ph, bevt_46_ta_ph, bevt_47_ta_ph, bevt_48_ta_ph);
bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
} /* Line: 407*/
 else /* Line: 406*/ {
bevt_50_ta_ph = (new BEC_2_4_3_MathInt(13));
if (bevl_rcap.bevi_int == bevt_50_ta_ph.bevi_int) {
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 408*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_51_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_52_ta_ph);
bevl_value.bem_subtractValue_1(bevt_51_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_7));
bevt_53_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_54_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_8));
bevt_57_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_58_ta_ph);
bevt_56_ta_ph = bevl_value.bem_and_1(bevt_57_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_55_ta_ph = bevt_56_ta_ph.bem_shiftRight_1(bevt_59_ta_ph);
bevl_first = bevt_53_ta_ph.bem_or_1(bevt_55_ta_ph);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_9));
bevt_60_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_61_ta_ph);
bevt_64_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_10));
bevt_63_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_64_ta_ph);
bevt_62_ta_ph = bevl_value.bem_and_1(bevt_63_ta_ph);
bevl_last = bevt_60_ta_ph.bem_or_1(bevt_62_ta_ph);
bevt_66_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_65_ta_ph = beva_txt.bem_addValue_1(bevt_66_ta_ph);
bevt_69_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_68_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_69_ta_ph);
bevt_70_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_71_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_72_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_67_ta_ph = bevl_first.bem_toString_4(bevt_68_ta_ph, bevt_70_ta_ph, bevt_71_ta_ph, bevt_72_ta_ph);
bevt_65_ta_ph.bem_addValue_1(bevt_67_ta_ph);
bevt_74_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_73_ta_ph = beva_txt.bem_addValue_1(bevt_74_ta_ph);
bevt_77_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_76_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_79_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_80_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_75_ta_ph = bevl_last.bem_toString_4(bevt_76_ta_ph, bevt_78_ta_ph, bevt_79_ta_ph, bevt_80_ta_ph);
bevt_73_ta_ph.bem_addValue_1(bevt_75_ta_ph);
} /* Line: 413*/
} /* Line: 406*/
} /* Line: 406*/
} /* Line: 395*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_1(BEC_2_6_6_SystemObject beva_toEscape) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevp_escaped.bem_clear_0();
bevt_1_ta_ph = bevp_mbi.bem_new_1((BEC_2_4_6_TextString) beva_toEscape );
bevt_0_ta_ph = bem_jsonEscape_3(bevt_1_ta_ph, bevp_txtpt, bevp_escaped);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_3(BEC_2_4_17_TextMultiByteIterator beva_mbi, BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_escaped) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
while (true)
/* Line: 424*/ {
bevt_0_ta_ph = beva_mbi.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 424*/ {
beva_mbi.bem_next_1(beva_txtpt);
bem_jsonEscapePoint_2(beva_txtpt, beva_escaped);
} /* Line: 426*/
 else /* Line: 424*/ {
break;
} /* Line: 424*/
} /* Line: 424*/
return beva_escaped;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteString_2(BEC_2_4_6_TextString beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_writer.bemd_1(-1128067899, bevp_q);
bevt_0_ta_ph = bem_jsonEscape_1(beva_inst);
beva_writer.bemd_1(-1128067899, bevt_0_ta_ph);
beva_writer.bemd_1(-1128067899, bevp_q);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteList_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_instin = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_11));
beva_writer.bemd_1(-1128067899, bevt_1_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(1954876952);
while (true)
/* Line: 440*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 440*/ {
bevl_instin = bevt_0_ta_loop.bemd_0(-747250137);
if (bevl_first.bevi_bool)/* Line: 441*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 442*/
 else /* Line: 443*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(-1128067899, bevt_3_ta_ph);
} /* Line: 444*/
bem_marshallWriteInst_2(bevl_instin, beva_writer);
} /* Line: 446*/
 else /* Line: 440*/ {
break;
} /* Line: 440*/
} /* Line: 440*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_13));
beva_writer.bemd_1(-1128067899, bevt_4_ta_ph);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_14));
beva_writer.bemd_1(-1128067899, bevt_1_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(1954876952);
while (true)
/* Line: 454*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 454*/ {
bevl_kv = bevt_0_ta_loop.bemd_0(-747250137);
if (bevl_first.bevi_bool)/* Line: 456*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 457*/
 else /* Line: 458*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(-1128067899, bevt_3_ta_ph);
} /* Line: 459*/
bevt_4_ta_ph = bevl_kv.bemd_0(1101862009);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_4_ta_ph , beva_writer);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_15));
beva_writer.bemd_1(-1128067899, bevt_5_ta_ph);
bevt_6_ta_ph = bevl_kv.bemd_0(-1099483766);
bem_marshallWriteInst_2(bevt_6_ta_ph, beva_writer);
} /* Line: 463*/
 else /* Line: 454*/ {
break;
} /* Line: 454*/
} /* Line: 454*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_16));
beva_writer.bemd_1(-1128067899, bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_arrGet_0() throws Throwable {
return bevp_arr;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_arrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_booGet_0() throws Throwable {
return bevp_boo;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_booSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_qGet_0() throws Throwable {
return bevp_q;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_qSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_q = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiGet_0() throws Throwable {
return bevp_mbi;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mbiSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_txtptGet_0() throws Throwable {
return bevp_txtpt;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_txtptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_escapedGet_0() throws Throwable {
return bevp_escaped;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_escapedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stpGet_0() throws Throwable {
return bevp_stp;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_stpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stp = (BEC_2_6_5_SystemTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {297, 299, 299, 301, 303, 305, 307, 307, 309, 310, 311, 313, 318, 318, 319, 321, 322, 323, 323, 327, 327, 328, 330, 334, 334, 335, 335, 336, 337, 338, 339, 340, 341, 342, 343, 343, 344, 345, 345, 347, 347, 352, 353, 355, 358, 358, 358, 359, 359, 359, 361, 361, 361, 363, 363, 363, 365, 365, 365, 367, 367, 367, 369, 369, 369, 371, 371, 371, 372, 372, 372, 374, 376, 376, 376, 376, 376, 376, 372, 379, 379, 379, 380, 381, 381, 381, 382, 384, 384, 384, 384, 385, 387, 391, 391, 391, 391, 392, 392, 395, 395, 395, 397, 398, 398, 399, 399, 400, 403, 405, 405, 405, 406, 406, 406, 407, 407, 407, 407, 407, 407, 407, 407, 407, 408, 408, 408, 409, 409, 409, 410, 410, 410, 410, 410, 410, 410, 410, 411, 411, 411, 411, 411, 411, 412, 412, 412, 412, 412, 412, 412, 412, 412, 413, 413, 413, 413, 413, 413, 413, 413, 413, 419, 420, 420, 420, 424, 425, 426, 428, 432, 433, 433, 434, 438, 438, 439, 440, 0, 440, 440, 442, 444, 444, 446, 448, 448, 452, 452, 453, 454, 0, 454, 454, 457, 459, 459, 461, 461, 462, 462, 463, 463, 465, 465, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 59, 64, 65, 67, 68, 69, 70, 74, 79, 80, 82, 96, 101, 102, 103, 106, 108, 111, 113, 116, 118, 121, 123, 124, 127, 129, 130, 133, 134, 235, 236, 237, 238, 239, 240, 241, 242, 247, 248, 249, 250, 253, 254, 259, 260, 261, 262, 265, 266, 271, 272, 273, 274, 278, 279, 284, 285, 288, 293, 294, 295, 296, 297, 298, 299, 300, 301, 308, 309, 314, 315, 318, 319, 324, 325, 328, 329, 330, 335, 336, 339, 343, 344, 345, 350, 351, 352, 354, 355, 360, 361, 362, 363, 364, 369, 370, 373, 377, 378, 383, 384, 385, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 402, 403, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 453, 454, 455, 456, 462, 464, 465, 471, 475, 476, 477, 478, 489, 490, 491, 492, 492, 495, 497, 499, 502, 503, 505, 511, 512, 526, 527, 528, 529, 529, 532, 534, 536, 539, 540, 542, 543, 544, 545, 546, 547, 553, 554, 558, 561, 565, 568, 572, 575, 579, 582, 586, 589, 593, 596, 600, 603, 607, 610, 614, 617, 621, 624};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 297 41
new 0 297 41
assign 1 299 42
new 0 299 42
assign 1 299 43
new 1 299 43
assign 1 301 44
new 0 301 44
assign 1 303 45
new 0 303 45
assign 1 305 46
new 0 305 46
assign 1 307 47
new 0 307 47
assign 1 307 48
quoteGet 0 307 48
assign 1 309 49
new 0 309 49
assign 1 310 50
new 0 310 50
assign 1 311 51
new 0 311 51
assign 1 313 52
new 0 313 52
assign 1 318 59
undef 1 318 64
new 0 319 65
assign 1 321 67
new 0 321 67
marshallWriteInst 2 322 68
assign 1 323 69
toString 0 323 69
return 1 323 70
assign 1 327 74
undef 1 327 79
new 0 328 80
marshallWriteInst 2 330 82
assign 1 334 96
undef 1 334 101
assign 1 335 102
new 0 335 102
write 1 335 103
assign 1 336 106
sameType 2 336 106
marshallWriteString 2 337 108
assign 1 338 111
sameType 2 338 111
marshallWriteList 2 339 113
assign 1 340 116
sameType 2 340 116
marshallWriteMap 2 341 118
assign 1 342 121
sameType 2 342 121
assign 1 343 123
toString 0 343 123
write 1 343 124
assign 1 344 127
sameType 2 344 127
assign 1 345 129
toString 0 345 129
write 1 345 130
assign 1 347 133
toString 0 347 133
marshallWriteString 2 347 134
assign 1 352 235
new 0 352 235
assign 1 353 236
lengthGet 0 353 236
assign 1 355 237
lengthGet 0 355 237
assign 1 358 238
new 0 358 238
assign 1 358 239
new 0 358 239
assign 1 358 240
getInt 2 358 240
assign 1 359 241
new 0 359 241
assign 1 359 242
equals 1 359 247
assign 1 361 248
new 0 361 248
assign 1 361 249
hexNew 1 361 249
assign 1 361 250
and 1 361 250
assign 1 363 253
new 0 363 253
assign 1 363 254
equals 1 363 259
assign 1 365 260
new 0 365 260
assign 1 365 261
hexNew 1 365 261
assign 1 365 262
and 1 365 262
assign 1 367 265
new 0 367 265
assign 1 367 266
equals 1 367 271
assign 1 369 272
new 0 369 272
assign 1 369 273
hexNew 1 369 273
assign 1 369 274
and 1 369 274
assign 1 371 278
new 0 371 278
assign 1 371 279
greater 1 371 284
assign 1 372 285
new 0 372 285
assign 1 372 288
lesser 1 372 293
getInt 2 374 294
assign 1 376 295
new 0 376 295
assign 1 376 296
shiftLeft 1 376 296
assign 1 376 297
new 0 376 297
assign 1 376 298
hexNew 1 376 298
assign 1 376 299
and 1 376 299
assign 1 376 300
add 1 376 300
incrementValue 0 372 301
assign 1 379 308
new 0 379 308
assign 1 379 309
equals 1 379 314
assign 1 380 315
new 0 380 315
assign 1 381 318
new 0 381 318
assign 1 381 319
equals 1 381 324
assign 1 382 325
new 0 382 325
assign 1 384 328
new 0 384 328
assign 1 384 329
hexNew 1 384 329
assign 1 384 330
lesser 1 384 335
assign 1 385 336
new 0 385 336
assign 1 387 339
new 0 387 339
assign 1 391 343
capacityGet 0 391 343
assign 1 391 344
subtract 1 391 344
assign 1 391 345
lesser 1 391 350
assign 1 392 351
add 1 392 351
capacitySet 1 392 352
assign 1 395 354
new 0 395 354
assign 1 395 355
equals 1 395 360
assign 1 397 361
new 0 397 361
assign 1 398 362
toEscapesGet 0 398 362
assign 1 398 363
get 1 398 363
assign 1 399 364
def 1 399 369
addValue 1 400 370
addValue 1 403 373
assign 1 405 377
new 0 405 377
assign 1 405 378
greater 1 405 383
assign 1 406 384
new 0 406 384
assign 1 406 385
equals 1 406 390
assign 1 407 391
new 0 407 391
assign 1 407 392
addValue 1 407 392
assign 1 407 393
new 0 407 393
assign 1 407 394
new 1 407 394
assign 1 407 395
new 0 407 395
assign 1 407 396
new 0 407 396
assign 1 407 397
new 0 407 397
assign 1 407 398
toString 4 407 398
addValue 1 407 399
assign 1 408 402
new 0 408 402
assign 1 408 403
equals 1 408 408
assign 1 409 409
new 0 409 409
assign 1 409 410
hexNew 1 409 410
subtractValue 1 409 411
assign 1 410 412
new 0 410 412
assign 1 410 413
hexNew 1 410 413
assign 1 410 414
new 0 410 414
assign 1 410 415
hexNew 1 410 415
assign 1 410 416
and 1 410 416
assign 1 410 417
new 0 410 417
assign 1 410 418
shiftRight 1 410 418
assign 1 410 419
or 1 410 419
assign 1 411 420
new 0 411 420
assign 1 411 421
hexNew 1 411 421
assign 1 411 422
new 0 411 422
assign 1 411 423
hexNew 1 411 423
assign 1 411 424
and 1 411 424
assign 1 411 425
or 1 411 425
assign 1 412 426
new 0 412 426
assign 1 412 427
addValue 1 412 427
assign 1 412 428
new 0 412 428
assign 1 412 429
new 1 412 429
assign 1 412 430
new 0 412 430
assign 1 412 431
new 0 412 431
assign 1 412 432
new 0 412 432
assign 1 412 433
toString 4 412 433
addValue 1 412 434
assign 1 413 435
new 0 413 435
assign 1 413 436
addValue 1 413 436
assign 1 413 437
new 0 413 437
assign 1 413 438
new 1 413 438
assign 1 413 439
new 0 413 439
assign 1 413 440
new 0 413 440
assign 1 413 441
new 0 413 441
assign 1 413 442
toString 4 413 442
addValue 1 413 443
clear 0 419 453
assign 1 420 454
new 1 420 454
assign 1 420 455
jsonEscape 3 420 455
return 1 420 456
assign 1 424 462
hasNextGet 0 424 462
next 1 425 464
jsonEscapePoint 2 426 465
return 1 428 471
write 1 432 475
assign 1 433 476
jsonEscape 1 433 476
write 1 433 477
write 1 434 478
assign 1 438 489
new 0 438 489
write 1 438 490
assign 1 439 491
new 0 439 491
assign 1 440 492
iteratorGet 0 0 492
assign 1 440 495
hasNextGet 0 440 495
assign 1 440 497
nextGet 0 440 497
assign 1 442 499
new 0 442 499
assign 1 444 502
new 0 444 502
write 1 444 503
marshallWriteInst 2 446 505
assign 1 448 511
new 0 448 511
write 1 448 512
assign 1 452 526
new 0 452 526
write 1 452 527
assign 1 453 528
new 0 453 528
assign 1 454 529
iteratorGet 0 0 529
assign 1 454 532
hasNextGet 0 454 532
assign 1 454 534
nextGet 0 454 534
assign 1 457 536
new 0 457 536
assign 1 459 539
new 0 459 539
write 1 459 540
assign 1 461 542
keyGet 0 461 542
marshallWriteString 2 461 543
assign 1 462 544
new 0 462 544
write 1 462 545
assign 1 463 546
valueGet 0 463 546
marshallWriteInst 2 463 547
assign 1 465 553
new 0 465 553
write 1 465 554
return 1 0 558
assign 1 0 561
return 1 0 565
assign 1 0 568
return 1 0 572
assign 1 0 575
return 1 0 579
assign 1 0 582
return 1 0 586
assign 1 0 589
return 1 0 593
assign 1 0 596
return 1 0 600
assign 1 0 603
return 1 0 607
assign 1 0 610
return 1 0 614
assign 1 0 617
return 1 0 621
assign 1 0 624
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -43191778: return bem_hashGet_0();
case 1069615902: return bem_copy_0();
case -1124573007: return bem_arrGet_0();
case 392846692: return bem_stpGet_0();
case 1780466191: return bem_strGet_0();
case -1330742415: return bem_escapedGet_0();
case -1625714557: return bem_intGet_0();
case -1747567745: return bem_mbiGet_0();
case -935641853: return bem_print_0();
case 649240305: return bem_txtptGet_0();
case -597465201: return bem_mapGet_0();
case -521709333: return bem_qGet_0();
case 1428575040: return bem_toString_0();
case 1954876952: return bem_iteratorGet_0();
case 1356338585: return bem_new_0();
case -604604888: return bem_booGet_0();
case -1629771427: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1073716984: return bem_equals_1(bevd_0);
case -1705495452: return bem_mbiSet_1(bevd_0);
case -1637390713: return bem_stpSet_1(bevd_0);
case 484780340: return bem_notEquals_1(bevd_0);
case 408597760: return bem_strSet_1(bevd_0);
case -1187837133: return bem_booSet_1(bevd_0);
case 999932968: return bem_mapSet_1(bevd_0);
case -179556288: return bem_undef_1(bevd_0);
case -2090462317: return bem_txtptSet_1(bevd_0);
case 1388413072: return bem_copyTo_1(bevd_0);
case 643912628: return bem_qSet_1(bevd_0);
case -1713538395: return bem_escapedSet_1(bevd_0);
case -1752014758: return bem_marshall_1(bevd_0);
case -946351099: return bem_print_1(bevd_0);
case -1717644082: return bem_intSet_1(bevd_0);
case -1093801617: return bem_jsonEscape_1(bevd_0);
case -1366175642: return bem_def_1(bevd_0);
case -1174039037: return bem_arrSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -570336382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 159189467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2008767520: return bem_marshallWriteMap_2(bevd_0, bevd_1);
case -531647583: return bem_marshallWriteList_2(bevd_0, bevd_1);
case -1111008594: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 321264796: return bem_marshallWrite_2(bevd_0, bevd_1);
case 2047952583: return bem_marshallWriteInst_2(bevd_0, bevd_1);
case -1085183740: return bem_marshallWriteString_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 328556125: return bem_jsonEscapePoint_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -548042918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1536575911: return bem_jsonEscape_3((BEC_2_4_17_TextMultiByteIterator) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_JsonMarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_10_JsonMarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_JsonMarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst = (BEC_2_4_10_JsonMarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_type;
}
}
