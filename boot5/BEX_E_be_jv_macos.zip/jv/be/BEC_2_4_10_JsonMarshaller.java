package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_10_JsonMarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_JsonMarshaller() { }
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x4D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_1 = {0x31,0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_2 = {0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_3 = {0x37};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_4 = {0x33,0x46};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_5 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_6 = {0x5C,0x75};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_8 = {0x66,0x66,0x63,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_9 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_10 = {0x30,0x30,0x33,0x66,0x66};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_11 = {0x5B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_12 = {0x2C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_13 = {0x5D};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_14 = {0x7B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_15 = {0x3A};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_16 = {0x7D};
public static BEC_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_inst;

public static BET_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_9_4_ContainerList bevp_arr;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_boo;
public BEC_2_4_6_TextString bevp_q;
public BEC_2_4_17_TextMultiByteIterator bevp_mbi;
public BEC_2_4_6_TextString bevp_txtpt;
public BEC_2_4_6_TextString bevp_escaped;
public BEC_2_6_5_SystemTypes bevp_stp;
public BEC_2_4_10_JsonMarshaller bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevp_str = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_arr = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
bevp_boo = (new BEC_2_5_4_LogicBool()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_q = bevt_1_ta_ph.bem_quoteGet_0();
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_0();
bevp_txtpt = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_escaped = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_stp = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_marshall_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_4_6_TextString bevl_bb = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 312*/ {
bem_new_0();
} /* Line: 313*/
bevl_bb = (new BEC_2_4_6_TextString()).bem_new_0();
bem_marshallWriteInst_2(beva_inst, bevl_bb);
bevt_1_ta_ph = bevl_bb.bem_toString_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWrite_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 321*/ {
bem_new_0();
} /* Line: 322*/
bem_marshallWriteInst_2(beva_inst, beva_writer);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteInst_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (beva_inst == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 328*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_0));
beva_writer.bemd_1(801742083, bevt_1_ta_ph);
} /* Line: 329*/
 else /* Line: 328*/ {
bevt_2_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_str);
if (bevt_2_ta_ph.bevi_bool)/* Line: 330*/ {
bem_marshallWriteString_2((BEC_2_4_6_TextString) beva_inst , beva_writer);
} /* Line: 331*/
 else /* Line: 328*/ {
bevt_3_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_arr);
if (bevt_3_ta_ph.bevi_bool)/* Line: 332*/ {
bem_marshallWriteList_2(beva_inst, beva_writer);
} /* Line: 333*/
 else /* Line: 328*/ {
bevt_4_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_map);
if (bevt_4_ta_ph.bevi_bool)/* Line: 334*/ {
bem_marshallWriteMap_2(beva_inst, beva_writer);
} /* Line: 335*/
 else /* Line: 328*/ {
bevt_5_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_int);
if (bevt_5_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_6_ta_ph = beva_inst.bemd_0(1430882405);
beva_writer.bemd_1(801742083, bevt_6_ta_ph);
} /* Line: 337*/
 else /* Line: 328*/ {
bevt_7_ta_ph = bevp_stp.bem_sameType_2(beva_inst, bevp_boo);
if (bevt_7_ta_ph.bevi_bool)/* Line: 338*/ {
bevt_8_ta_ph = beva_inst.bemd_0(1430882405);
beva_writer.bemd_1(801742083, bevt_8_ta_ph);
} /* Line: 339*/
 else /* Line: 340*/ {
bevt_9_ta_ph = beva_inst.bemd_0(1430882405);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_9_ta_ph , beva_writer);
} /* Line: 341*/
} /* Line: 328*/
} /* Line: 328*/
} /* Line: 328*/
} /* Line: 328*/
} /* Line: 328*/
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_jsonEscapePoint_2(BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_txt) throws Throwable {
BEC_2_4_3_MathInt bevl_rcap = null;
BEC_2_4_3_MathInt bevl_txtsznow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_u = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_7_JsonEscapes bevl_esc = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_first = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_4_3_MathInt bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
bevl_rcap = (new BEC_2_4_3_MathInt());
bevl_txtsznow = beva_txt.bem_sizeGet_0();
bevl_size = beva_txtpt.bem_sizeGet_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevl_u = beva_txtpt.bem_getInt_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_size.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 354*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_1));
bevt_4_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_5_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_4_ta_ph);
} /* Line: 355*/
 else /* Line: 353*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(3));
if (bevl_size.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 358*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_2));
bevt_8_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_9_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_8_ta_ph);
} /* Line: 359*/
 else /* Line: 353*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(4));
if (bevl_size.bevi_int == bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 362*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_3));
bevt_12_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_13_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_12_ta_ph);
} /* Line: 363*/
} /* Line: 353*/
} /* Line: 353*/
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_size.bevi_int > bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 365*/ {
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 366*/ {
if (bevl_i.bevi_int < bevl_size.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 367*/ {
beva_txtpt.bem_getInt_2(bevl_i, bevl_u);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_17_ta_ph = bevl_value.bem_shiftLeft_1(bevt_18_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_4));
bevt_20_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_21_ta_ph);
bevt_19_ta_ph = bevl_u.bem_and_1(bevt_20_ta_ph);
bevl_value = bevt_17_ta_ph.bem_add_1(bevt_19_ta_ph);
bevl_i.bevi_int++;
} /* Line: 366*/
 else /* Line: 366*/ {
break;
} /* Line: 366*/
} /* Line: 366*/
} /* Line: 366*/
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_size.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 373*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(0));
} /* Line: 374*/
 else /* Line: 373*/ {
bevt_25_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_size.bevi_int == bevt_25_ta_ph.bevi_int) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 375*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(2));
} /* Line: 376*/
 else /* Line: 377*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_27_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_28_ta_ph);
if (bevl_value.bevi_int < bevt_27_ta_ph.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 378*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(7));
} /* Line: 379*/
 else /* Line: 380*/ {
bevl_rcap = (new BEC_2_4_3_MathInt(13));
} /* Line: 381*/
} /* Line: 378*/
} /* Line: 373*/
bevt_31_ta_ph = beva_txt.bem_capacityGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_subtract_1(bevl_txtsznow);
if (bevt_30_ta_ph.bevi_int < bevl_rcap.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 385*/ {
bevt_32_ta_ph = bevl_txtsznow.bem_add_1(bevl_rcap);
beva_txt.bem_capacitySet_1(bevt_32_ta_ph);
} /* Line: 386*/
bevt_34_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_rcap.bevi_int == bevt_34_ta_ph.bevi_int) {
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 389*/ {
bevl_esc = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevt_35_ta_ph = bevl_esc.bem_toEscapesGet_0();
bevl_escval = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_get_1(beva_txtpt);
if (bevl_escval == null) {
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 393*/ {
beva_txt.bem_addValue_1(bevl_escval);
} /* Line: 394*/
 else /* Line: 395*/ {
beva_txt.bem_addValue_1(beva_txtpt);
} /* Line: 397*/
} /* Line: 393*/
 else /* Line: 389*/ {
bevt_38_ta_ph = (new BEC_2_4_3_MathInt(3));
if (bevl_rcap.bevi_int > bevt_38_ta_ph.bevi_int) {
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 399*/ {
bevt_40_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_rcap.bevi_int == bevt_40_ta_ph.bevi_int) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_42_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_41_ta_ph = beva_txt.bem_addValue_1(bevt_42_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_44_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_47_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_48_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_43_ta_ph = bevl_value.bem_toString_4(bevt_44_ta_ph, bevt_46_ta_ph, bevt_47_ta_ph, bevt_48_ta_ph);
bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
} /* Line: 401*/
 else /* Line: 400*/ {
bevt_50_ta_ph = (new BEC_2_4_3_MathInt(13));
if (bevl_rcap.bevi_int == bevt_50_ta_ph.bevi_int) {
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 402*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_51_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_52_ta_ph);
bevl_value.bem_subtractValue_1(bevt_51_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_7));
bevt_53_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_54_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_8));
bevt_57_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_58_ta_ph);
bevt_56_ta_ph = bevl_value.bem_and_1(bevt_57_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_55_ta_ph = bevt_56_ta_ph.bem_shiftRight_1(bevt_59_ta_ph);
bevl_first = bevt_53_ta_ph.bem_or_1(bevt_55_ta_ph);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_9));
bevt_60_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_61_ta_ph);
bevt_64_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_10));
bevt_63_ta_ph = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_64_ta_ph);
bevt_62_ta_ph = bevl_value.bem_and_1(bevt_63_ta_ph);
bevl_last = bevt_60_ta_ph.bem_or_1(bevt_62_ta_ph);
bevt_66_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_65_ta_ph = beva_txt.bem_addValue_1(bevt_66_ta_ph);
bevt_69_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_68_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_69_ta_ph);
bevt_70_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_71_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_72_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_67_ta_ph = bevl_first.bem_toString_4(bevt_68_ta_ph, bevt_70_ta_ph, bevt_71_ta_ph, bevt_72_ta_ph);
bevt_65_ta_ph.bem_addValue_1(bevt_67_ta_ph);
bevt_74_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_73_ta_ph = beva_txt.bem_addValue_1(bevt_74_ta_ph);
bevt_77_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_76_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_79_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_80_ta_ph = (new BEC_2_4_3_MathInt(87));
bevt_75_ta_ph = bevl_last.bem_toString_4(bevt_76_ta_ph, bevt_78_ta_ph, bevt_79_ta_ph, bevt_80_ta_ph);
bevt_73_ta_ph.bem_addValue_1(bevt_75_ta_ph);
} /* Line: 407*/
} /* Line: 400*/
} /* Line: 400*/
} /* Line: 389*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_1(BEC_2_6_6_SystemObject beva_toEscape) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevp_escaped.bem_clear_0();
bevt_1_ta_ph = bevp_mbi.bem_new_1((BEC_2_4_6_TextString) beva_toEscape );
bevt_0_ta_ph = bem_jsonEscape_3(bevt_1_ta_ph, bevp_txtpt, bevp_escaped);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_3(BEC_2_4_17_TextMultiByteIterator beva_mbi, BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_escaped) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
while (true)
/* Line: 418*/ {
bevt_0_ta_ph = beva_mbi.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 418*/ {
beva_mbi.bem_next_1(beva_txtpt);
bem_jsonEscapePoint_2(beva_txtpt, beva_escaped);
} /* Line: 420*/
 else /* Line: 418*/ {
break;
} /* Line: 418*/
} /* Line: 418*/
return beva_escaped;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteString_2(BEC_2_4_6_TextString beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_writer.bemd_1(801742083, bevp_q);
bevt_0_ta_ph = bem_jsonEscape_1(beva_inst);
beva_writer.bemd_1(801742083, bevt_0_ta_ph);
beva_writer.bemd_1(801742083, bevp_q);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteList_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_instin = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_11));
beva_writer.bemd_1(801742083, bevt_1_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(-1169546676);
while (true)
/* Line: 434*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(237832993);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 434*/ {
bevl_instin = bevt_0_ta_loop.bemd_0(532590773);
if (bevl_first.bevi_bool)/* Line: 435*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 436*/
 else /* Line: 437*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(801742083, bevt_3_ta_ph);
} /* Line: 438*/
bem_marshallWriteInst_2(bevl_instin, beva_writer);
} /* Line: 440*/
 else /* Line: 434*/ {
break;
} /* Line: 434*/
} /* Line: 434*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_13));
beva_writer.bemd_1(801742083, bevt_4_ta_ph);
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_marshallWriteMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_14));
beva_writer.bemd_1(801742083, bevt_1_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(-1169546676);
while (true)
/* Line: 448*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(237832993);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 448*/ {
bevl_kv = bevt_0_ta_loop.bemd_0(532590773);
if (bevl_first.bevi_bool)/* Line: 450*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 451*/
 else /* Line: 452*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(801742083, bevt_3_ta_ph);
} /* Line: 453*/
bevt_4_ta_ph = bevl_kv.bemd_0(-120739058);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_4_ta_ph , beva_writer);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_15));
beva_writer.bemd_1(801742083, bevt_5_ta_ph);
bevt_6_ta_ph = bevl_kv.bemd_0(-147706867);
bem_marshallWriteInst_2(bevt_6_ta_ph, beva_writer);
} /* Line: 457*/
 else /* Line: 448*/ {
break;
} /* Line: 448*/
} /* Line: 448*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_16));
beva_writer.bemd_1(801742083, bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_arrGet_0() throws Throwable {
return bevp_arr;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_arrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_booGet_0() throws Throwable {
return bevp_boo;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_booSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_qGet_0() throws Throwable {
return bevp_q;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_qSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_q = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiGet_0() throws Throwable {
return bevp_mbi;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mbiSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_txtptGet_0() throws Throwable {
return bevp_txtpt;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_txtptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_escapedGet_0() throws Throwable {
return bevp_escaped;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_escapedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stpGet_0() throws Throwable {
return bevp_stp;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_stpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stp = (BEC_2_6_5_SystemTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {291, 293, 293, 295, 297, 299, 301, 301, 303, 304, 305, 307, 312, 312, 313, 315, 316, 317, 317, 321, 321, 322, 324, 328, 328, 329, 329, 330, 331, 332, 333, 334, 335, 336, 337, 337, 338, 339, 339, 341, 341, 346, 347, 349, 352, 352, 352, 353, 353, 353, 355, 355, 355, 357, 357, 357, 359, 359, 359, 361, 361, 361, 363, 363, 363, 365, 365, 365, 366, 366, 366, 368, 370, 370, 370, 370, 370, 370, 366, 373, 373, 373, 374, 375, 375, 375, 376, 378, 378, 378, 378, 379, 381, 385, 385, 385, 385, 386, 386, 389, 389, 389, 391, 392, 392, 393, 393, 394, 397, 399, 399, 399, 400, 400, 400, 401, 401, 401, 401, 401, 401, 401, 401, 401, 402, 402, 402, 403, 403, 403, 404, 404, 404, 404, 404, 404, 404, 404, 405, 405, 405, 405, 405, 405, 406, 406, 406, 406, 406, 406, 406, 406, 406, 407, 407, 407, 407, 407, 407, 407, 407, 407, 413, 414, 414, 414, 418, 419, 420, 422, 426, 427, 427, 428, 432, 432, 433, 434, 0, 434, 434, 436, 438, 438, 440, 442, 442, 446, 446, 447, 448, 0, 448, 448, 451, 453, 453, 455, 455, 456, 456, 457, 457, 459, 459, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 59, 64, 65, 67, 68, 69, 70, 74, 79, 80, 82, 96, 101, 102, 103, 106, 108, 111, 113, 116, 118, 121, 123, 124, 127, 129, 130, 133, 134, 235, 236, 237, 238, 239, 240, 241, 242, 247, 248, 249, 250, 253, 254, 259, 260, 261, 262, 265, 266, 271, 272, 273, 274, 278, 279, 284, 285, 288, 293, 294, 295, 296, 297, 298, 299, 300, 301, 308, 309, 314, 315, 318, 319, 324, 325, 328, 329, 330, 335, 336, 339, 343, 344, 345, 350, 351, 352, 354, 355, 360, 361, 362, 363, 364, 369, 370, 373, 377, 378, 383, 384, 385, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 402, 403, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 453, 454, 455, 456, 462, 464, 465, 471, 475, 476, 477, 478, 489, 490, 491, 492, 492, 495, 497, 499, 502, 503, 505, 511, 512, 526, 527, 528, 529, 529, 532, 534, 536, 539, 540, 542, 543, 544, 545, 546, 547, 553, 554, 558, 561, 565, 568, 572, 575, 579, 582, 586, 589, 593, 596, 600, 603, 607, 610, 614, 617, 621, 624};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 291 41
new 0 291 41
assign 1 293 42
new 0 293 42
assign 1 293 43
new 1 293 43
assign 1 295 44
new 0 295 44
assign 1 297 45
new 0 297 45
assign 1 299 46
new 0 299 46
assign 1 301 47
new 0 301 47
assign 1 301 48
quoteGet 0 301 48
assign 1 303 49
new 0 303 49
assign 1 304 50
new 0 304 50
assign 1 305 51
new 0 305 51
assign 1 307 52
new 0 307 52
assign 1 312 59
undef 1 312 64
new 0 313 65
assign 1 315 67
new 0 315 67
marshallWriteInst 2 316 68
assign 1 317 69
toString 0 317 69
return 1 317 70
assign 1 321 74
undef 1 321 79
new 0 322 80
marshallWriteInst 2 324 82
assign 1 328 96
undef 1 328 101
assign 1 329 102
new 0 329 102
write 1 329 103
assign 1 330 106
sameType 2 330 106
marshallWriteString 2 331 108
assign 1 332 111
sameType 2 332 111
marshallWriteList 2 333 113
assign 1 334 116
sameType 2 334 116
marshallWriteMap 2 335 118
assign 1 336 121
sameType 2 336 121
assign 1 337 123
toString 0 337 123
write 1 337 124
assign 1 338 127
sameType 2 338 127
assign 1 339 129
toString 0 339 129
write 1 339 130
assign 1 341 133
toString 0 341 133
marshallWriteString 2 341 134
assign 1 346 235
new 0 346 235
assign 1 347 236
sizeGet 0 347 236
assign 1 349 237
sizeGet 0 349 237
assign 1 352 238
new 0 352 238
assign 1 352 239
new 0 352 239
assign 1 352 240
getInt 2 352 240
assign 1 353 241
new 0 353 241
assign 1 353 242
equals 1 353 247
assign 1 355 248
new 0 355 248
assign 1 355 249
hexNew 1 355 249
assign 1 355 250
and 1 355 250
assign 1 357 253
new 0 357 253
assign 1 357 254
equals 1 357 259
assign 1 359 260
new 0 359 260
assign 1 359 261
hexNew 1 359 261
assign 1 359 262
and 1 359 262
assign 1 361 265
new 0 361 265
assign 1 361 266
equals 1 361 271
assign 1 363 272
new 0 363 272
assign 1 363 273
hexNew 1 363 273
assign 1 363 274
and 1 363 274
assign 1 365 278
new 0 365 278
assign 1 365 279
greater 1 365 284
assign 1 366 285
new 0 366 285
assign 1 366 288
lesser 1 366 293
getInt 2 368 294
assign 1 370 295
new 0 370 295
assign 1 370 296
shiftLeft 1 370 296
assign 1 370 297
new 0 370 297
assign 1 370 298
hexNew 1 370 298
assign 1 370 299
and 1 370 299
assign 1 370 300
add 1 370 300
incrementValue 0 366 301
assign 1 373 308
new 0 373 308
assign 1 373 309
equals 1 373 314
assign 1 374 315
new 0 374 315
assign 1 375 318
new 0 375 318
assign 1 375 319
equals 1 375 324
assign 1 376 325
new 0 376 325
assign 1 378 328
new 0 378 328
assign 1 378 329
hexNew 1 378 329
assign 1 378 330
lesser 1 378 335
assign 1 379 336
new 0 379 336
assign 1 381 339
new 0 381 339
assign 1 385 343
capacityGet 0 385 343
assign 1 385 344
subtract 1 385 344
assign 1 385 345
lesser 1 385 350
assign 1 386 351
add 1 386 351
capacitySet 1 386 352
assign 1 389 354
new 0 389 354
assign 1 389 355
equals 1 389 360
assign 1 391 361
new 0 391 361
assign 1 392 362
toEscapesGet 0 392 362
assign 1 392 363
get 1 392 363
assign 1 393 364
def 1 393 369
addValue 1 394 370
addValue 1 397 373
assign 1 399 377
new 0 399 377
assign 1 399 378
greater 1 399 383
assign 1 400 384
new 0 400 384
assign 1 400 385
equals 1 400 390
assign 1 401 391
new 0 401 391
assign 1 401 392
addValue 1 401 392
assign 1 401 393
new 0 401 393
assign 1 401 394
new 1 401 394
assign 1 401 395
new 0 401 395
assign 1 401 396
new 0 401 396
assign 1 401 397
new 0 401 397
assign 1 401 398
toString 4 401 398
addValue 1 401 399
assign 1 402 402
new 0 402 402
assign 1 402 403
equals 1 402 408
assign 1 403 409
new 0 403 409
assign 1 403 410
hexNew 1 403 410
subtractValue 1 403 411
assign 1 404 412
new 0 404 412
assign 1 404 413
hexNew 1 404 413
assign 1 404 414
new 0 404 414
assign 1 404 415
hexNew 1 404 415
assign 1 404 416
and 1 404 416
assign 1 404 417
new 0 404 417
assign 1 404 418
shiftRight 1 404 418
assign 1 404 419
or 1 404 419
assign 1 405 420
new 0 405 420
assign 1 405 421
hexNew 1 405 421
assign 1 405 422
new 0 405 422
assign 1 405 423
hexNew 1 405 423
assign 1 405 424
and 1 405 424
assign 1 405 425
or 1 405 425
assign 1 406 426
new 0 406 426
assign 1 406 427
addValue 1 406 427
assign 1 406 428
new 0 406 428
assign 1 406 429
new 1 406 429
assign 1 406 430
new 0 406 430
assign 1 406 431
new 0 406 431
assign 1 406 432
new 0 406 432
assign 1 406 433
toString 4 406 433
addValue 1 406 434
assign 1 407 435
new 0 407 435
assign 1 407 436
addValue 1 407 436
assign 1 407 437
new 0 407 437
assign 1 407 438
new 1 407 438
assign 1 407 439
new 0 407 439
assign 1 407 440
new 0 407 440
assign 1 407 441
new 0 407 441
assign 1 407 442
toString 4 407 442
addValue 1 407 443
clear 0 413 453
assign 1 414 454
new 1 414 454
assign 1 414 455
jsonEscape 3 414 455
return 1 414 456
assign 1 418 462
hasNextGet 0 418 462
next 1 419 464
jsonEscapePoint 2 420 465
return 1 422 471
write 1 426 475
assign 1 427 476
jsonEscape 1 427 476
write 1 427 477
write 1 428 478
assign 1 432 489
new 0 432 489
write 1 432 490
assign 1 433 491
new 0 433 491
assign 1 434 492
iteratorGet 0 0 492
assign 1 434 495
hasNextGet 0 434 495
assign 1 434 497
nextGet 0 434 497
assign 1 436 499
new 0 436 499
assign 1 438 502
new 0 438 502
write 1 438 503
marshallWriteInst 2 440 505
assign 1 442 511
new 0 442 511
write 1 442 512
assign 1 446 526
new 0 446 526
write 1 446 527
assign 1 447 528
new 0 447 528
assign 1 448 529
iteratorGet 0 0 529
assign 1 448 532
hasNextGet 0 448 532
assign 1 448 534
nextGet 0 448 534
assign 1 451 536
new 0 451 536
assign 1 453 539
new 0 453 539
write 1 453 540
assign 1 455 542
keyGet 0 455 542
marshallWriteString 2 455 543
assign 1 456 544
new 0 456 544
write 1 456 545
assign 1 457 546
valueGet 0 457 546
marshallWriteInst 2 457 547
assign 1 459 553
new 0 459 553
write 1 459 554
return 1 0 558
assign 1 0 561
return 1 0 565
assign 1 0 568
return 1 0 572
assign 1 0 575
return 1 0 579
assign 1 0 582
return 1 0 586
assign 1 0 589
return 1 0 593
assign 1 0 596
return 1 0 600
assign 1 0 603
return 1 0 607
assign 1 0 610
return 1 0 614
assign 1 0 617
return 1 0 621
assign 1 0 624
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1430882405: return bem_toString_0();
case 776617978: return bem_txtptGet_0();
case 820557385: return bem_intGet_0();
case -953507231: return bem_create_0();
case -1467274168: return bem_new_0();
case 553287343: return bem_booGet_0();
case 1842992619: return bem_mapGet_0();
case 260640151: return bem_strGet_0();
case 148494370: return bem_hashGet_0();
case -1169546676: return bem_iteratorGet_0();
case 447392967: return bem_copy_0();
case -776015162: return bem_print_0();
case -1409883383: return bem_arrGet_0();
case 257924213: return bem_mbiGet_0();
case -1595866706: return bem_qGet_0();
case 1330744510: return bem_escapedGet_0();
case 1471849534: return bem_stpGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 737222072: return bem_escapedSet_1(bevd_0);
case 195716696: return bem_marshall_1(bevd_0);
case -1078226251: return bem_strSet_1(bevd_0);
case -1751500508: return bem_booSet_1(bevd_0);
case -1059179702: return bem_copyTo_1(bevd_0);
case 1173188918: return bem_jsonEscape_1(bevd_0);
case 330875553: return bem_txtptSet_1(bevd_0);
case -633891840: return bem_intSet_1(bevd_0);
case 1716691663: return bem_mbiSet_1(bevd_0);
case -943174876: return bem_qSet_1(bevd_0);
case -534694211: return bem_stpSet_1(bevd_0);
case 1310591464: return bem_mapSet_1(bevd_0);
case 1747007145: return bem_equals_1(bevd_0);
case -440246922: return bem_notEquals_1(bevd_0);
case 1090166823: return bem_undef_1(bevd_0);
case 2037252872: return bem_arrSet_1(bevd_0);
case -310926947: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1571917853: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1690356127: return bem_marshallWriteString_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -163936016: return bem_marshallWriteList_2(bevd_0, bevd_1);
case -754298914: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1072039287: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1557789855: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -484640945: return bem_marshallWrite_2(bevd_0, bevd_1);
case -1209266441: return bem_marshallWriteInst_2(bevd_0, bevd_1);
case -1736883379: return bem_jsonEscapePoint_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1584054647: return bem_marshallWriteMap_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1256378526: return bem_jsonEscape_3((BEC_2_4_17_TextMultiByteIterator) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_JsonMarshaller_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_10_JsonMarshaller_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_JsonMarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst = (BEC_2_4_10_JsonMarshaller) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_type;
}
}
