package be;
/* IO:File: source/extended/Properties.be */
public final class BEC_2_6_3_SystemEnv extends BEC_2_9_11_ContainerPropertyMap {
public BEC_2_6_3_SystemEnv() { }
private static byte[] becc_BEC_2_6_3_SystemEnv_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x6E,0x76};
private static byte[] becc_BEC_2_6_3_SystemEnv_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_3_SystemEnv_bels_0 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_SystemEnv_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_SystemEnv_bels_0, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_SystemEnv_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_SystemEnv_bevo_2 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_3_SystemEnv bece_BEC_2_6_3_SystemEnv_bevs_inst;

public static BET_2_6_3_SystemEnv bece_BEC_2_6_3_SystemEnv_bevs_type;

public BEC_2_6_3_SystemEnv bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_default_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_set_2(BEC_2_4_6_TextString beva_key, BEC_2_4_6_TextString beva_value) throws Throwable {
bevp_map.bem_put_2(beva_key, beva_value);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_get_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevl_toRet == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 91 */ {
bevp_map.bem_put_2(beva_key, bevl_toRet);
} /* Line: 92 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_getCached_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_map.bem_has_1(beva_key);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_1_tmpany_phold = bevp_map.bem_get_1(beva_key);
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /* Line: 98 */
bevt_2_tmpany_phold = bem_get_1(beva_key);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_unset_1(BEC_2_4_6_TextString beva_key) throws Throwable {
bevp_map.bem_delete_1(beva_key);
return this;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_load_0() throws Throwable {
BEC_2_4_6_TextString bevl_next = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_6_TextString bevl_k = null;
BEC_2_4_6_TextString bevl_v = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_6_3_SystemEnv_bevo_0;
bevl_p = bevl_next.bem_find_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bece_BEC_2_6_3_SystemEnv_bevo_1;
bevl_k = bevl_next.bem_substring_2(bevt_1_tmpany_phold, bevl_p);
bevt_3_tmpany_phold = bece_BEC_2_6_3_SystemEnv_bevo_2;
bevt_2_tmpany_phold = bevl_p.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevl_next.bem_sizeGet_0();
bevl_v = bevl_next.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
bevp_map.bem_put_2(bevl_k, bevl_v);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bem_load_0();
bevt_0_tmpany_phold = bevp_map.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_cwdGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_cwd = null;
return bevl_cwd;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_workingDirectoryGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_cwdGet_0();
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {59, 70, 91, 91, 92, 94, 98, 98, 98, 99, 99, 110, 127, 127, 128, 128, 129, 129, 129, 129, 130, 139, 140, 140, 166, 170, 170, 170};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 26, 32, 37, 38, 40, 46, 48, 49, 51, 52, 55, 68, 69, 70, 71, 72, 73, 74, 75, 76, 81, 82, 83, 87, 92, 93, 94};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 59 22
put 2 70 26
assign 1 91 32
def 1 91 37
put 2 92 38
return 1 94 40
assign 1 98 46
has 1 98 46
assign 1 98 48
get 1 98 48
return 1 98 49
assign 1 99 51
get 1 99 51
return 1 99 52
delete 1 110 55
assign 1 127 68
new 0 127 68
assign 1 127 69
find 1 127 69
assign 1 128 70
new 0 128 70
assign 1 128 71
substring 2 128 71
assign 1 129 72
new 0 129 72
assign 1 129 73
add 1 129 73
assign 1 129 74
sizeGet 0 129 74
assign 1 129 75
substring 2 129 75
put 2 130 76
load 0 139 81
assign 1 140 82
iteratorGet 0 140 82
return 1 140 83
return 1 166 87
assign 1 170 92
cwdGet 0 170 92
assign 1 170 93
apNew 1 170 93
return 1 170 94
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2061412556: return bem_classNameGet_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case 605755759: return bem_fieldNamesGet_0();
case -39706070: return bem_serializeContents_0();
case 2069196027: return bem_print_0();
case 1359777543: return bem_toAny_0();
case 874968344: return bem_once_0();
case 344752250: return bem_hashGet_0();
case -1355749111: return bem_default_0();
case -244726213: return bem_load_0();
case 27033645: return bem_sourceFileNameGet_0();
case 502031978: return bem_iteratorGet_0();
case 1480415803: return bem_serializationIteratorGet_0();
case 325964466: return bem_echo_0();
case 1965613314: return bem_tagGet_0();
case -826291169: return bem_mapGetDirect_0();
case 1578098134: return bem_toString_0();
case 26417469: return bem_create_0();
case 962099177: return bem_fieldIteratorGet_0();
case -1878305271: return bem_many_0();
case 334767424: return bem_copy_0();
case 1728638279: return bem_workingDirectoryGet_0();
case -1322562396: return bem_cwdGet_0();
case 2132890711: return bem_new_0();
case 1875985535: return bem_mapGet_0();
case -799200084: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -726423172: return bem_getCached_1((BEC_2_4_6_TextString) bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case -1096034935: return bem_mapSetDirect_1(bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case -2020523101: return bem_unset_1((BEC_2_4_6_TextString) bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case 1672635146: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
case 118964541: return bem_mapSet_1((BEC_2_9_3_ContainerMap) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -339795486: return bem_set_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_SystemEnv_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_2_6_3_SystemEnv_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_SystemEnv();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_SystemEnv.bece_BEC_2_6_3_SystemEnv_bevs_inst = (BEC_2_6_3_SystemEnv) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_SystemEnv.bece_BEC_2_6_3_SystemEnv_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_SystemEnv.bece_BEC_2_6_3_SystemEnv_bevs_type;
}
}
