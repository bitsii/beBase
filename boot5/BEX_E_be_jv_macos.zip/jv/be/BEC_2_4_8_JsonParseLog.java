package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_8_JsonParseLog extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_JsonParseLog() { }
private static byte[] becc_BEC_2_4_8_JsonParseLog_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_4_8_JsonParseLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_0 = {0x47,0x6F,0x74,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_0, 12));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_1 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_1, 1));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_2 = {0x62,0x65,0x67,0x69,0x6E,0x4D,0x61,0x70};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_2, 8));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_3 = {0x65,0x6E,0x64,0x4D,0x61,0x70};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_3, 6));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_4 = {0x6B,0x76,0x4D,0x69,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_4, 5));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_5 = {0x62,0x65,0x67,0x69,0x6E,0x4C,0x69,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_5, 9));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_6 = {0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_6, 7));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_7 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x72,0x75,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_7, 10));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_8 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x46,0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_8, 11));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_9 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x4E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_9, 10));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_10 = {0x47,0x6F,0x74,0x20,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_10, 13));
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_1, 1));
public static BEC_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_inst;

public static BET_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_type;

public BEC_2_4_8_JsonParseLog bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_0;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_str);
bevt_3_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_beginMap_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_2;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_endMap_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_3;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_kvMid_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_4;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_beginList_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_5;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_endList_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_6;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleTrue_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_7;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleFalse_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_8;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleNull_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_9;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_int);
bevt_3_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {580, 580, 580, 580, 580, 584, 584, 588, 588, 592, 592, 596, 596, 600, 600, 604, 604, 608, 608, 612, 612, 616, 616, 616, 616, 616};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {42, 43, 44, 45, 46, 51, 52, 57, 58, 63, 64, 69, 70, 75, 76, 81, 82, 87, 88, 93, 94, 102, 103, 104, 105, 106};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 580 42
new 0 580 42
assign 1 580 43
add 1 580 43
assign 1 580 44
new 0 580 44
assign 1 580 45
add 1 580 45
print 0 580 46
assign 1 584 51
new 0 584 51
print 0 584 52
assign 1 588 57
new 0 588 57
print 0 588 58
assign 1 592 63
new 0 592 63
print 0 592 64
assign 1 596 69
new 0 596 69
print 0 596 70
assign 1 600 75
new 0 600 75
print 0 600 76
assign 1 604 81
new 0 604 81
print 0 604 82
assign 1 608 87
new 0 608 87
print 0 608 88
assign 1 612 93
new 0 612 93
print 0 612 94
assign 1 616 102
new 0 616 102
assign 1 616 103
add 1 616 103
assign 1 616 104
new 0 616 104
assign 1 616 105
add 1 616 105
print 0 616 106
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2079582721: return bem_toString_0();
case 572016682: return bem_serializationIteratorGet_0();
case -165278261: return bem_hashGet_0();
case -980602152: return bem_sourceFileNameGet_0();
case 577869439: return bem_serializeToString_0();
case 1702721127: return bem_endMap_0();
case -253572329: return bem_beginMap_0();
case -579194210: return bem_iteratorGet_0();
case -1519256103: return bem_handleFalse_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case -1168657718: return bem_create_0();
case 1476265575: return bem_toAny_0();
case 448246445: return bem_fieldNamesGet_0();
case 11313755: return bem_echo_0();
case -1791746868: return bem_print_0();
case -1045898755: return bem_classNameGet_0();
case 1568711247: return bem_fieldIteratorGet_0();
case -1489022328: return bem_once_0();
case -1406264904: return bem_copy_0();
case 334571614: return bem_many_0();
case 1077429775: return bem_kvMid_0();
case -1430069919: return bem_serializeContents_0();
case 1425053656: return bem_handleTrue_0();
case -673175268: return bem_handleNull_0();
case 242856887: return bem_endList_0();
case -1236884476: return bem_beginList_0();
case -1682958828: return bem_tagGet_0();
case -621270081: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case -1657715199: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case 1875257797: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_JsonParseLog_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_8_JsonParseLog_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_JsonParseLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst = (BEC_2_4_8_JsonParseLog) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_type;
}
}
