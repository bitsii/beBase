package be;
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError extends BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public BEC_2_5_10_BuildVisitError bem_new_1(BEC_2_6_6_SystemObject beva_msgi) throws Throwable {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) throws Throwable {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_7_TextStrings bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_1_ta_ph = bevl_toRet.bemd_1(-1920624455, bevp_msg);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_newlineGet_0();
bevl_toRet = bevt_1_ta_ph.bemd_1(-1920624455, bevt_2_ta_ph);
} /* Line: 24*/
if (bevp_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 26*/ {
bevl_nc = bevp_node;
while (true)
/* Line: 28*/ {
if (bevl_nc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 28*/ {
bevl_toRet.bemd_1(717777871, bevl_nc);
bevt_7_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_ta_ph = bevt_7_ta_ph.bem_newlineGet_0();
bevl_toRet.bemd_1(717777871, bevt_6_ta_ph);
bevl_nc = bevl_nc.bemd_0(-115136713);
} /* Line: 31*/
 else /* Line: 28*/ {
break;
} /* Line: 28*/
} /* Line: 28*/
} /* Line: 28*/
bevt_8_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(-1920624455, bevt_8_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGet_0() throws Throwable {
return bevp_msg;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msg = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGet_0() throws Throwable {
return bevp_node;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_node = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {10, 15, 16, 22, 23, 23, 24, 24, 24, 24, 26, 26, 27, 28, 28, 29, 30, 30, 30, 31, 34, 34, 35, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 20, 35, 36, 41, 42, 43, 44, 45, 47, 52, 53, 56, 61, 62, 63, 64, 65, 66, 73, 74, 75, 78, 81, 85, 88};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 10 15
assign 1 15 19
assign 1 16 20
assign 1 22 35
new 0 22 35
assign 1 23 36
def 1 23 41
assign 1 24 42
add 1 24 42
assign 1 24 43
new 0 24 43
assign 1 24 44
newlineGet 0 24 44
assign 1 24 45
add 1 24 45
assign 1 26 47
def 1 26 52
assign 1 27 53
assign 1 28 56
def 1 28 61
addValue 1 29 62
assign 1 30 63
new 0 30 63
assign 1 30 64
newlineGet 0 30 64
addValue 1 30 65
assign 1 31 66
containerGet 0 31 66
assign 1 34 73
getFrameText 0 34 73
assign 1 34 74
add 1 34 74
return 1 35 75
return 1 0 78
assign 1 0 81
return 1 0 85
assign 1 0 88
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -984604226: return bem_hashGet_0();
case -844106141: return bem_klassNameGet_0();
case 713686734: return bem_methodNameGet_0();
case -1376188355: return bem_toString_0();
case 1428983925: return bem_emitLangGet_0();
case -221471490: return bem_fileNameGet_0();
case -1300294592: return bem_new_0();
case 30862756: return bem_iteratorGet_0();
case -1425620799: return bem_framesGet_0();
case -820336986: return bem_translatedGet_0();
case 1290546373: return bem_nodeGet_0();
case -2147427485: return bem_msgGet_0();
case 471123982: return bem_framesTextGet_0();
case 1617519785: return bem_copy_0();
case -1247238560: return bem_getFrameText_0();
case -219492711: return bem_create_0();
case 600796896: return bem_lineNumberGet_0();
case -1619765125: return bem_langGet_0();
case 926204456: return bem_vvGet_0();
case -1606682728: return bem_print_0();
case -486286909: return bem_descriptionGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -819065857: return bem_lineNumberSet_1(bevd_0);
case 538829762: return bem_methodNameSet_1(bevd_0);
case 1652712723: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1998873987: return bem_vvSet_1(bevd_0);
case -941634151: return bem_framesSet_1(bevd_0);
case 25126761: return bem_def_1(bevd_0);
case 130493529: return bem_translatedSet_1(bevd_0);
case 144428460: return bem_equals_1(bevd_0);
case -382459987: return bem_undef_1(bevd_0);
case 651163363: return bem_nodeSet_1(bevd_0);
case 1616842678: return bem_notEquals_1(bevd_0);
case -1496660475: return bem_fileNameSet_1(bevd_0);
case 1064870573: return bem_framesTextSet_1(bevd_0);
case 1634599038: return bem_copyTo_1(bevd_0);
case 781385025: return bem_langSet_1(bevd_0);
case 1368875362: return bem_new_1(bevd_0);
case 1235111795: return bem_msgSet_1(bevd_0);
case -277469560: return bem_emitLangSet_1(bevd_0);
case -324580462: return bem_klassNameSet_1(bevd_0);
case -936016126: return bem_descriptionSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 120651597: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -159239392: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 845289889: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1813958638: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 760889457: return bem_new_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1879173044: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_10_BuildVisitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
