package be;
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError extends BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public BEC_2_5_10_BuildVisitError bem_new_1(BEC_2_6_6_SystemObject beva_msgi) throws Throwable {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) throws Throwable {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_7_TextStrings bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 29*/ {
bevt_1_ta_ph = bevl_toRet.bemd_1(1984158481, bevp_msg);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_newlineGet_0();
bevl_toRet = bevt_1_ta_ph.bemd_1(1984158481, bevt_2_ta_ph);
} /* Line: 30*/
if (bevp_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 32*/ {
bevl_nc = bevp_node;
while (true)
/* Line: 34*/ {
if (bevl_nc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 34*/ {
bevl_toRet.bemd_1(530358661, bevl_nc);
bevt_7_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_ta_ph = bevt_7_ta_ph.bem_newlineGet_0();
bevl_toRet.bemd_1(530358661, bevt_6_ta_ph);
bevl_nc = bevl_nc.bemd_0(1953259047);
} /* Line: 37*/
 else /* Line: 34*/ {
break;
} /* Line: 34*/
} /* Line: 34*/
} /* Line: 34*/
bevt_8_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(1984158481, bevt_8_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGet_0() throws Throwable {
return bevp_msg;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msg = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGet_0() throws Throwable {
return bevp_node;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_node = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 21, 22, 28, 29, 29, 30, 30, 30, 30, 32, 32, 33, 34, 34, 35, 36, 36, 36, 37, 40, 40, 41, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 20, 35, 36, 41, 42, 43, 44, 45, 47, 52, 53, 56, 61, 62, 63, 64, 65, 66, 73, 74, 75, 78, 81, 85, 88};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 15
assign 1 21 19
assign 1 22 20
assign 1 28 35
new 0 28 35
assign 1 29 36
def 1 29 41
assign 1 30 42
add 1 30 42
assign 1 30 43
new 0 30 43
assign 1 30 44
newlineGet 0 30 44
assign 1 30 45
add 1 30 45
assign 1 32 47
def 1 32 52
assign 1 33 53
assign 1 34 56
def 1 34 61
addValue 1 35 62
assign 1 36 63
new 0 36 63
assign 1 36 64
newlineGet 0 36 64
addValue 1 36 65
assign 1 37 66
containerGet 0 37 66
assign 1 40 73
getFrameText 0 40 73
assign 1 40 74
add 1 40 74
return 1 41 75
return 1 0 78
assign 1 0 81
return 1 0 85
assign 1 0 88
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1214459758: return bem_getFrameText_0();
case -150451224: return bem_nodeGet_0();
case 994063424: return bem_emitLangGet_0();
case -1477018360: return bem_toString_0();
case 1030336271: return bem_new_0();
case -662844650: return bem_iteratorGet_0();
case 400130425: return bem_vvGet_0();
case 310309721: return bem_hashGet_0();
case 1379821961: return bem_create_0();
case -2077848618: return bem_descriptionGet_0();
case -875064970: return bem_translatedGet_0();
case 1155069902: return bem_print_0();
case 1895064583: return bem_fileNameGet_0();
case 1684262434: return bem_lineNumberGet_0();
case -2144858188: return bem_langGet_0();
case 1811530619: return bem_klassNameGet_0();
case -1141241291: return bem_copy_0();
case -360531897: return bem_methodNameGet_0();
case -1246022944: return bem_framesTextGet_0();
case -1960515734: return bem_framesGet_0();
case 1587744028: return bem_msgGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1305126722: return bem_translatedSet_1(bevd_0);
case 1801291774: return bem_def_1(bevd_0);
case -280286674: return bem_langSet_1(bevd_0);
case 1738502576: return bem_copyTo_1(bevd_0);
case -1428346779: return bem_framesSet_1(bevd_0);
case -1536533357: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1486416107: return bem_descriptionSet_1(bevd_0);
case 1668642461: return bem_fileNameSet_1(bevd_0);
case 851150744: return bem_emitLangSet_1(bevd_0);
case -1063313773: return bem_klassNameSet_1(bevd_0);
case -1117209842: return bem_new_1(bevd_0);
case 278034565: return bem_equals_1(bevd_0);
case -1176436455: return bem_print_1(bevd_0);
case 1191663248: return bem_nodeSet_1(bevd_0);
case 1075706066: return bem_undef_1(bevd_0);
case -469637135: return bem_methodNameSet_1(bevd_0);
case -1099504144: return bem_lineNumberSet_1(bevd_0);
case 1232484766: return bem_framesTextSet_1(bevd_0);
case 1753654007: return bem_msgSet_1(bevd_0);
case 613529560: return bem_vvSet_1(bevd_0);
case -1264563233: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1657815698: return bem_new_2(bevd_0, bevd_1);
case -844523032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1584274286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 752466488: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -880661396: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1608813548: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_10_BuildVisitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
