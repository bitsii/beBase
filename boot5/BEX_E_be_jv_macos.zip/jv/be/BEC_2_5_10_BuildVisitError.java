package be;
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError extends BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public BEC_2_5_10_BuildVisitError bem_new_1(BEC_2_6_6_SystemObject beva_msgi) throws Throwable {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) throws Throwable {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_7_TextStrings bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 24*/ {
bevt_1_ta_ph = bevl_toRet.bemd_1(2087810673, bevp_msg);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_newlineGet_0();
bevl_toRet = bevt_1_ta_ph.bemd_1(2087810673, bevt_2_ta_ph);
} /* Line: 25*/
if (bevp_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 27*/ {
bevl_nc = bevp_node;
while (true)
/* Line: 29*/ {
if (bevl_nc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 29*/ {
bevl_toRet.bemd_1(1965005377, bevl_nc);
bevt_7_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_ta_ph = bevt_7_ta_ph.bem_newlineGet_0();
bevl_toRet.bemd_1(1965005377, bevt_6_ta_ph);
bevl_nc = bevl_nc.bemd_0(-1655871229);
} /* Line: 32*/
 else /* Line: 29*/ {
break;
} /* Line: 29*/
} /* Line: 29*/
} /* Line: 29*/
bevt_8_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(2087810673, bevt_8_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGet_0() throws Throwable {
return bevp_msg;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_msgGetDirect_0() throws Throwable {
return bevp_msg;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msg = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildVisitError bem_msgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msg = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGet_0() throws Throwable {
return bevp_node;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_nodeGetDirect_0() throws Throwable {
return bevp_node;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_node = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildVisitError bem_nodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_node = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {10, 15, 16, 23, 24, 24, 25, 25, 25, 25, 27, 27, 28, 29, 29, 30, 31, 31, 31, 32, 35, 35, 36, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 20, 35, 36, 41, 42, 43, 44, 45, 47, 52, 53, 56, 61, 62, 63, 64, 65, 66, 73, 74, 75, 78, 81, 84, 88, 92, 95, 98, 102};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 10 15
assign 1 15 19
assign 1 16 20
assign 1 23 35
new 0 23 35
assign 1 24 36
def 1 24 41
assign 1 25 42
add 1 25 42
assign 1 25 43
new 0 25 43
assign 1 25 44
newlineGet 0 25 44
assign 1 25 45
add 1 25 45
assign 1 27 47
def 1 27 52
assign 1 28 53
assign 1 29 56
def 1 29 61
addValue 1 30 62
assign 1 31 63
new 0 31 63
assign 1 31 64
newlineGet 0 31 64
addValue 1 31 65
assign 1 32 66
containerGet 0 32 66
assign 1 35 73
getFrameText 0 35 73
assign 1 35 74
add 1 35 74
return 1 36 75
return 1 0 78
return 1 0 81
assign 1 0 84
assign 1 0 88
return 1 0 92
return 1 0 95
assign 1 0 98
assign 1 0 102
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1092244444: return bem_klassNameGetDirect_0();
case -344688418: return bem_new_0();
case -1514184278: return bem_serializeContents_0();
case 1199613442: return bem_vvGetDirect_0();
case 826167413: return bem_classNameGet_0();
case 703575232: return bem_langGet_0();
case -1959899288: return bem_fieldIteratorGet_0();
case -556434115: return bem_translatedGetDirect_0();
case 818210964: return bem_toAny_0();
case 61067620: return bem_methodNameGetDirect_0();
case -1260225135: return bem_vvGet_0();
case -327712425: return bem_many_0();
case -553928998: return bem_emitLangGetDirect_0();
case 460274340: return bem_emitLangGet_0();
case -1961371045: return bem_lineNumberGetDirect_0();
case -749268313: return bem_copy_0();
case -792704504: return bem_translateEmittedExceptionInner_0();
case 1315725661: return bem_hashGet_0();
case -1238556728: return bem_klassNameGet_0();
case -1915666683: return bem_serializationIteratorGet_0();
case 1270756764: return bem_print_0();
case 1537622088: return bem_descriptionGetDirect_0();
case 1210407094: return bem_tagGet_0();
case 1293575145: return bem_serializeToString_0();
case -899256741: return bem_toString_0();
case 241290978: return bem_framesTextGetDirect_0();
case -2107562528: return bem_fileNameGetDirect_0();
case 1723182161: return bem_nodeGet_0();
case 1277659956: return bem_descriptionGet_0();
case 984019358: return bem_framesGetDirect_0();
case 1068740466: return bem_msgGetDirect_0();
case -156734141: return bem_framesGet_0();
case 482387492: return bem_msgGet_0();
case 1122833767: return bem_lineNumberGet_0();
case 887254713: return bem_sourceFileNameGet_0();
case -509699646: return bem_translatedGet_0();
case -9014382: return bem_nodeGetDirect_0();
case 846353007: return bem_echo_0();
case -404876081: return bem_translateEmittedException_0();
case -1022912205: return bem_fileNameGet_0();
case -479412451: return bem_iteratorGet_0();
case 580716253: return bem_methodNameGet_0();
case -407687427: return bem_fieldNamesGet_0();
case -519581463: return bem_deserializeClassNameGet_0();
case -1726253220: return bem_getFrameText_0();
case 770986263: return bem_create_0();
case 538502757: return bem_framesTextGet_0();
case -1036335715: return bem_langGetDirect_0();
case -1945570638: return bem_once_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1498119962: return bem_sameType_1(bevd_0);
case 1033789283: return bem_klassNameSet_1(bevd_0);
case 2011695784: return bem_new_1(bevd_0);
case 43760314: return bem_emitLangSetDirect_1(bevd_0);
case -1468949165: return bem_undefined_1(bevd_0);
case -734442156: return bem_translatedSet_1(bevd_0);
case -180182582: return bem_methodNameSet_1(bevd_0);
case -1550788913: return bem_msgSetDirect_1(bevd_0);
case 1785922348: return bem_vvSetDirect_1(bevd_0);
case 1946977825: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -349002851: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1220746835: return bem_klassNameSetDirect_1(bevd_0);
case 997331927: return bem_equals_1(bevd_0);
case -1343727458: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2142682416: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 668767624: return bem_lineNumberSetDirect_1(bevd_0);
case -200493562: return bem_framesSetDirect_1(bevd_0);
case 33010187: return bem_msgSet_1(bevd_0);
case -1385037482: return bem_descriptionSetDirect_1(bevd_0);
case 1772678539: return bem_notEquals_1(bevd_0);
case -233300707: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1769531159: return bem_vvSet_1(bevd_0);
case 143017201: return bem_framesTextSet_1(bevd_0);
case -597164057: return bem_defined_1(bevd_0);
case 755902182: return bem_fileNameSetDirect_1(bevd_0);
case 918955224: return bem_methodNameSetDirect_1(bevd_0);
case 1715370141: return bem_sameClass_1(bevd_0);
case 248598654: return bem_copyTo_1(bevd_0);
case -311679871: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1548523977: return bem_otherClass_1(bevd_0);
case 784918995: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1219877874: return bem_descriptionSet_1(bevd_0);
case -1334572722: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1899168562: return bem_langSetDirect_1(bevd_0);
case -1539166222: return bem_translatedSetDirect_1(bevd_0);
case 509252275: return bem_sameObject_1(bevd_0);
case 509956737: return bem_def_1(bevd_0);
case 2144395088: return bem_undef_1(bevd_0);
case 166544837: return bem_emitLangSet_1(bevd_0);
case 98519678: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1988703074: return bem_nodeSet_1(bevd_0);
case -1548799649: return bem_framesSet_1(bevd_0);
case 1716219745: return bem_langSet_1(bevd_0);
case 1477732575: return bem_otherType_1(bevd_0);
case -1945681275: return bem_framesTextSetDirect_1(bevd_0);
case -326027049: return bem_lineNumberSet_1(bevd_0);
case 1498164521: return bem_nodeSetDirect_1(bevd_0);
case 1735214518: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -744710733: return bem_fileNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -455603186: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -403771483: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 262774206: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1189130153: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -390764901: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1675736992: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1904308898: return bem_new_2(bevd_0, bevd_1);
case -319997805: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -83201963: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_10_BuildVisitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
