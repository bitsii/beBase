package be;
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError extends BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public BEC_2_5_10_BuildVisitError bem_new_1(BEC_2_6_6_SystemObject beva_msgi) throws Throwable {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) throws Throwable {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_7_TextStrings bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_1_ta_ph = bevl_toRet.bemd_1(1586592391, bevp_msg);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_newlineGet_0();
bevl_toRet = bevt_1_ta_ph.bemd_1(1586592391, bevt_2_ta_ph);
} /* Line: 24*/
if (bevp_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 26*/ {
bevl_nc = bevp_node;
while (true)
/* Line: 28*/ {
if (bevl_nc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 28*/ {
bevl_toRet.bemd_1(-2069120687, bevl_nc);
bevt_7_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_ta_ph = bevt_7_ta_ph.bem_newlineGet_0();
bevl_toRet.bemd_1(-2069120687, bevt_6_ta_ph);
bevl_nc = bevl_nc.bemd_0(-125764532);
} /* Line: 31*/
 else /* Line: 28*/ {
break;
} /* Line: 28*/
} /* Line: 28*/
} /* Line: 28*/
bevt_8_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(1586592391, bevt_8_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGet_0() throws Throwable {
return bevp_msg;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msg = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGet_0() throws Throwable {
return bevp_node;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_node = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {10, 15, 16, 22, 23, 23, 24, 24, 24, 24, 26, 26, 27, 28, 28, 29, 30, 30, 30, 31, 34, 34, 35, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 20, 35, 36, 41, 42, 43, 44, 45, 47, 52, 53, 56, 61, 62, 63, 64, 65, 66, 73, 74, 75, 78, 81, 85, 88};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 10 15
assign 1 15 19
assign 1 16 20
assign 1 22 35
new 0 22 35
assign 1 23 36
def 1 23 41
assign 1 24 42
add 1 24 42
assign 1 24 43
new 0 24 43
assign 1 24 44
newlineGet 0 24 44
assign 1 24 45
add 1 24 45
assign 1 26 47
def 1 26 52
assign 1 27 53
assign 1 28 56
def 1 28 61
addValue 1 29 62
assign 1 30 63
new 0 30 63
assign 1 30 64
newlineGet 0 30 64
addValue 1 30 65
assign 1 31 66
containerGet 0 31 66
assign 1 34 73
getFrameText 0 34 73
assign 1 34 74
add 1 34 74
return 1 35 75
return 1 0 78
assign 1 0 81
return 1 0 85
assign 1 0 88
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -370059105: return bem_descriptionGet_0();
case -1307062820: return bem_emitLangGet_0();
case -43108722: return bem_methodNameGet_0();
case 1861855516: return bem_copy_0();
case 1676715436: return bem_iteratorGet_0();
case -2042483961: return bem_toString_0();
case -1757033570: return bem_print_0();
case 316149953: return bem_langGet_0();
case 794985397: return bem_getFrameText_0();
case 1062915240: return bem_nodeGet_0();
case -1425898375: return bem_new_0();
case 1564719786: return bem_msgGet_0();
case 436863164: return bem_hashGet_0();
case -1388007915: return bem_lineNumberGet_0();
case -1335783956: return bem_framesGet_0();
case 536964872: return bem_vvGet_0();
case -1364288525: return bem_framesTextGet_0();
case 923768211: return bem_klassNameGet_0();
case -234912192: return bem_fileNameGet_0();
case -1844269288: return bem_create_0();
case 104942509: return bem_translatedGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -253052612: return bem_vvSet_1(bevd_0);
case -272587445: return bem_notEquals_1(bevd_0);
case -973366092: return bem_msgSet_1(bevd_0);
case 324846295: return bem_def_1(bevd_0);
case 1620854058: return bem_emitLangSet_1(bevd_0);
case -1207753239: return bem_descriptionSet_1(bevd_0);
case -371582843: return bem_copyTo_1(bevd_0);
case 2015800048: return bem_new_1(bevd_0);
case 1471602326: return bem_framesSet_1(bevd_0);
case -1897060507: return bem_framesTextSet_1(bevd_0);
case -185891428: return bem_klassNameSet_1(bevd_0);
case -323607937: return bem_nodeSet_1(bevd_0);
case 1051624606: return bem_undef_1(bevd_0);
case -184069906: return bem_methodNameSet_1(bevd_0);
case -479611644: return bem_translatedSet_1(bevd_0);
case 1306600423: return bem_equals_1(bevd_0);
case 52466788: return bem_fileNameSet_1(bevd_0);
case -503936376: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 2145315887: return bem_langSet_1(bevd_0);
case 342438507: return bem_lineNumberSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1263166407: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1704989212: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1182530297: return bem_new_2(bevd_0, bevd_1);
case -1725892051: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1176905374: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -356118342: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_10_BuildVisitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
