package be;
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError extends BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public BEC_2_5_10_BuildVisitError bem_new_1(BEC_2_6_6_SystemObject beva_msgi) throws Throwable {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) throws Throwable {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevt_1_tmpany_phold = bevl_toRet.bemd_1(1462458944, bevp_msg);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_newlineGet_0();
bevl_toRet = bevt_1_tmpany_phold.bemd_1(1462458944, bevt_2_tmpany_phold);
} /* Line: 26 */
if (bevp_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevl_nc = bevp_node;
while (true)
 /* Line: 30 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevl_toRet.bemd_1(-380820495, bevl_nc);
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_newlineGet_0();
bevl_toRet.bemd_1(-380820495, bevt_6_tmpany_phold);
bevl_nc = bevl_nc.bemd_0(-1757606239);
} /* Line: 33 */
 else  /* Line: 30 */ {
break;
} /* Line: 30 */
} /* Line: 30 */
} /* Line: 30 */
bevt_8_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(1462458944, bevt_8_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGet_0() throws Throwable {
return bevp_msg;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGet_0() throws Throwable {
return bevp_node;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {11, 16, 17, 24, 25, 25, 26, 26, 26, 26, 28, 28, 29, 30, 30, 31, 32, 32, 32, 33, 36, 36, 37, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 20, 35, 36, 41, 42, 43, 44, 45, 47, 52, 53, 56, 61, 62, 63, 64, 65, 66, 73, 74, 75, 78, 81, 85, 88};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 11 15
assign 1 16 19
assign 1 17 20
assign 1 24 35
new 0 24 35
assign 1 25 36
def 1 25 41
assign 1 26 42
add 1 26 42
assign 1 26 43
new 0 26 43
assign 1 26 44
newlineGet 0 26 44
assign 1 26 45
add 1 26 45
assign 1 28 47
def 1 28 52
assign 1 29 53
assign 1 30 56
def 1 30 61
addValue 1 31 62
assign 1 32 63
new 0 32 63
assign 1 32 64
newlineGet 0 32 64
addValue 1 32 65
assign 1 33 66
containerGet 0 33 66
assign 1 36 73
getFrameText 0 36 73
assign 1 36 74
add 1 36 74
return 1 37 75
return 1 0 78
assign 1 0 81
return 1 0 85
assign 1 0 88
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1604962015: return bem_sourceFileNameGet_0();
case 1310553601: return bem_toString_0();
case -732524867: return bem_tagGet_0();
case 1924413487: return bem_hashGet_0();
case 1652177595: return bem_translateEmittedException_0();
case 14222936: return bem_descriptionGet_0();
case -980884323: return bem_new_0();
case -1451203303: return bem_lineNumberGet_0();
case -1897026239: return bem_echo_0();
case -1565549870: return bem_print_0();
case 1793221455: return bem_copy_0();
case 1129053182: return bem_translateEmittedExceptionInner_0();
case 1110529799: return bem_emitLangGet_0();
case 950136265: return bem_vvGet_0();
case -1226625126: return bem_once_0();
case 1139084907: return bem_nodeGet_0();
case 215322388: return bem_fileNameGet_0();
case 489788599: return bem_serializeContents_0();
case -176246897: return bem_framesTextGet_0();
case -1920531733: return bem_serializationIteratorGet_0();
case -1535847383: return bem_toAny_0();
case -306303426: return bem_methodNameGet_0();
case 1150664853: return bem_create_0();
case -1081087328: return bem_langGet_0();
case -290041240: return bem_serializeToString_0();
case 2049066942: return bem_fieldIteratorGet_0();
case -1326718107: return bem_getFrameText_0();
case 2052709534: return bem_many_0();
case -1083008339: return bem_msgGet_0();
case -728210038: return bem_translatedGet_0();
case 194016774: return bem_iteratorGet_0();
case -259991050: return bem_klassNameGet_0();
case -525681067: return bem_classNameGet_0();
case 332981262: return bem_deserializeClassNameGet_0();
case 789313479: return bem_framesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1936074077: return bem_klassNameSet_1(bevd_0);
case -1545437990: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1966507736: return bem_undef_1(bevd_0);
case -1586463464: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 959360624: return bem_otherType_1(bevd_0);
case 863435643: return bem_equals_1(bevd_0);
case 978698391: return bem_fileNameSet_1(bevd_0);
case 279904401: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 257405303: return bem_copyTo_1(bevd_0);
case 420384947: return bem_def_1(bevd_0);
case 1091645150: return bem_emitLangSet_1(bevd_0);
case 386836188: return bem_otherClass_1(bevd_0);
case -1233990290: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -453401206: return bem_vvSet_1(bevd_0);
case 1868528499: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1181837366: return bem_translatedSet_1(bevd_0);
case 672577716: return bem_msgSet_1(bevd_0);
case 1693216688: return bem_sameClass_1(bevd_0);
case -2104330508: return bem_sameObject_1(bevd_0);
case -1021436824: return bem_sameType_1(bevd_0);
case 1858229799: return bem_descriptionSet_1(bevd_0);
case -1960812475: return bem_framesTextSet_1(bevd_0);
case -243829290: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1834098557: return bem_notEquals_1(bevd_0);
case -2075540734: return bem_langSet_1(bevd_0);
case -798191677: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -467299687: return bem_defined_1(bevd_0);
case 562081982: return bem_undefined_1(bevd_0);
case 1465161497: return bem_methodNameSet_1(bevd_0);
case -145738070: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1585694121: return bem_lineNumberSet_1(bevd_0);
case -1343499453: return bem_new_1(bevd_0);
case -475723519: return bem_framesSet_1(bevd_0);
case 1646450100: return bem_nodeSet_1(bevd_0);
case 1998776126: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2090513876: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1240676558: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -371043039: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1325559256: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1035622269: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -145115514: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1581426787: return bem_new_2(bevd_0, bevd_1);
case 686918154: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1895634211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1272540796: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_10_BuildVisitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
