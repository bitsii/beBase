package be;
/* IO:File: source/build/CEmitter.be */
public final class BEC_2_5_9_BuildClassInfo extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildClassInfo() { }
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_0, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_1, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_2 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_2, 1));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_4, 6));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_5 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_5, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_6 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_6, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_7 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_8 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_8, 11));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_9 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_9, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_10 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_10, 6));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_11 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_12, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_13 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_13, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_14 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_14, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_15 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_15, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_16 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_16, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_17 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_18 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_18, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_19 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_19, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_20 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_20, 17));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_21 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_22 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_22, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_23 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_23, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_24 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_24, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_25 = {0x42,0x45,0x58,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_25, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_26 = {0x42,0x45,0x4B,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_26, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_27 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_27, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_28 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_29 = {0x2E,0x6D,0x61,0x6B,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_29, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_30 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_31 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_31, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_32 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_32, 4));
public static BEC_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_inst;

public static BET_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_15_BuildCompilerProfile bevp_cpro;
public BEC_2_5_8_BuildNamePath bevp_npar;
public BEC_2_6_6_SystemObject bevp_nparSteps;
public BEC_2_4_6_TextString bevp_clName;
public BEC_2_4_6_TextString bevp_clBase;
public BEC_2_4_6_TextString bevp_midName;
public BEC_2_4_6_TextString bevp_incBlock;
public BEC_2_4_6_TextString bevp_mtdName;
public BEC_2_4_6_TextString bevp_cldefName;
public BEC_2_4_6_TextString bevp_shClassName;
public BEC_2_4_6_TextString bevp_shFileName;
public BEC_2_4_6_TextString bevp_cldefBuild;
public BEC_2_4_6_TextString bevp_libnameInit;
public BEC_2_4_6_TextString bevp_libnameInitDone;
public BEC_2_4_6_TextString bevp_libnameData;
public BEC_2_4_6_TextString bevp_libnameDataDone;
public BEC_2_4_6_TextString bevp_libnameDataClear;
public BEC_2_4_6_TextString bevp_libNotNullInit;
public BEC_2_4_6_TextString bevp_libNotNullInitDone;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_cuBase;
public BEC_3_2_4_4_IOFilePath bevp_nsDir;
public BEC_2_4_6_TextString bevp_xbase;
public BEC_2_4_6_TextString bevp_lbase;
public BEC_2_4_6_TextString bevp_nbase;
public BEC_2_4_6_TextString bevp_kbase;
public BEC_3_2_4_4_IOFilePath bevp_cuinitH;
public BEC_2_4_6_TextString bevp_namesIncH;
public BEC_3_2_4_4_IOFilePath bevp_cuinit;
public BEC_3_2_4_4_IOFilePath bevp_namesO;
public BEC_3_2_4_4_IOFilePath bevp_unitShlib;
public BEC_3_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_3_2_4_4_IOFilePath bevp_unitExe;
public BEC_3_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classExeO;
public BEC_3_2_4_4_IOFilePath bevp_makeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrcH;
public BEC_3_2_4_4_IOFilePath bevp_classIncH;
public BEC_3_2_4_4_IOFilePath bevp_classO;
public BEC_3_2_4_4_IOFilePath bevp_synSrc;
public BEC_2_5_9_BuildClassInfo bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_new_5(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) throws Throwable {
BEC_2_4_6_TextString bevl_cext = null;
BEC_2_4_6_TextString bevl_oext = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_tmpany_phold = bevp_emitter.bemd_0(-1245235447);
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_phold.bemd_0(-1730306785);
bevp_npar = (BEC_2_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_tmpany_phold = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lastGet_0();
bevp_midName = (BEC_2_4_6_TextString) bevp_emitter.bemd_2(1102137929, beva__libName, beva__np);
bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_0;
bevp_incBlock = bevt_2_tmpany_phold.bem_add_1(bevp_midName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevp_midName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_2;
bevp_mtdName = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_3;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_midName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_4;
bevp_cldefName = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_5;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_midName);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_6;
bevp_shClassName = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_7;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_midName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_8;
bevp_shFileName = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_9;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevp_midName);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_10;
bevp_cldefBuild = bevt_15_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_11;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevp_midName);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_12;
bevp_libnameInit = bevt_18_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_13;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevp_midName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_14;
bevp_libnameInitDone = bevt_21_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_15;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevp_midName);
bevt_26_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_16;
bevp_libnameData = bevt_24_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_17;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevp_midName);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_18;
bevp_libnameDataDone = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_19;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevp_midName);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_20;
bevp_libnameDataClear = bevt_30_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_21;
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevp_midName);
bevt_35_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_22;
bevp_libNotNullInit = bevt_33_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_23;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_midName);
bevt_38_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_24;
bevp_libNotNullInitDone = bevt_36_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = beva__emitPath.bem_copy_0();
bevt_39_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_25;
bevp_xbase = bevt_39_tmpany_phold.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_26;
bevp_kbase = bevt_40_tmpany_phold.bem_add_1(bevp_clBase);
bevt_41_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_27;
bevt_42_tmpany_phold = bevp_nbase.bem_add_1(bevt_43_tmpany_phold);
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_41_tmpany_phold.bem_addStep_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_28;
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_46_tmpany_phold = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_45_tmpany_phold.bem_addStep_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_48_tmpany_phold = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_47_tmpany_phold.bem_addStep_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_51_tmpany_phold = bevp_cpro.bem_libExtGet_0();
bevt_50_tmpany_phold = bevp_lbase.bem_add_1(bevt_51_tmpany_phold);
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_49_tmpany_phold.bem_addStep_1(bevt_50_tmpany_phold);
bevt_52_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_54_tmpany_phold = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_tmpany_phold = bevp_lbase.bem_add_1(bevt_54_tmpany_phold);
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_52_tmpany_phold.bem_addStep_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_57_tmpany_phold = bevp_cpro.bem_exeExtGet_0();
bevt_56_tmpany_phold = beva__exeName.bem_add_1(bevt_57_tmpany_phold);
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_55_tmpany_phold.bem_addStep_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_59_tmpany_phold = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_58_tmpany_phold.bem_addStep_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_61_tmpany_phold = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_60_tmpany_phold.bem_addStep_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_64_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_29;
bevt_63_tmpany_phold = bevp_xbase.bem_add_1(bevt_64_tmpany_phold);
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_62_tmpany_phold.bem_addStep_1(bevt_63_tmpany_phold);
bevt_65_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_66_tmpany_phold = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_65_tmpany_phold.bem_addStep_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_69_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_30;
bevt_68_tmpany_phold = bevp_kbase.bem_add_1(bevt_69_tmpany_phold);
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_67_tmpany_phold.bem_addStep_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = bevp_nsDir.bem_copy_0();
bevt_72_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_31;
bevt_71_tmpany_phold = bevp_kbase.bem_add_1(bevt_72_tmpany_phold);
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_70_tmpany_phold.bem_addStep_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_74_tmpany_phold = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_73_tmpany_phold.bem_addStep_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_77_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_32;
bevt_76_tmpany_phold = bevp_kbase.bem_add_1(bevt_77_tmpany_phold);
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_75_tmpany_phold.bem_addStep_1(bevt_76_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirDo_1(BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(502031978);
while (true)
 /* Line: 111 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(-1276472965);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 111 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(-868741030);
bevp_nsDir.bem_addStep_1(bevt_1_tmpany_phold);
} /* Line: 112 */
 else  /* Line: 111 */ {
break;
} /* Line: 111 */
} /* Line: 111 */
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_npGetDirect_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGet_0() throws Throwable {
return bevp_cpro;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_cproGetDirect_0() throws Throwable {
return bevp_cpro;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cproSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGet_0() throws Throwable {
return bevp_npar;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_nparGetDirect_0() throws Throwable {
return bevp_npar;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nparSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGet_0() throws Throwable {
return bevp_nparSteps;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_nparStepsGetDirect_0() throws Throwable {
return bevp_nparSteps;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nparSteps = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nparStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nparSteps = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGet_0() throws Throwable {
return bevp_clName;
} /*method end*/
public final BEC_2_4_6_TextString bem_clNameGetDirect_0() throws Throwable {
return bevp_clName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_clNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGet_0() throws Throwable {
return bevp_clBase;
} /*method end*/
public final BEC_2_4_6_TextString bem_clBaseGetDirect_0() throws Throwable {
return bevp_clBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_clBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGet_0() throws Throwable {
return bevp_midName;
} /*method end*/
public final BEC_2_4_6_TextString bem_midNameGetDirect_0() throws Throwable {
return bevp_midName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_midNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGet_0() throws Throwable {
return bevp_incBlock;
} /*method end*/
public final BEC_2_4_6_TextString bem_incBlockGetDirect_0() throws Throwable {
return bevp_incBlock;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_incBlockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGet_0() throws Throwable {
return bevp_mtdName;
} /*method end*/
public final BEC_2_4_6_TextString bem_mtdNameGetDirect_0() throws Throwable {
return bevp_mtdName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_mtdNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGet_0() throws Throwable {
return bevp_cldefName;
} /*method end*/
public final BEC_2_4_6_TextString bem_cldefNameGetDirect_0() throws Throwable {
return bevp_cldefName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cldefNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGet_0() throws Throwable {
return bevp_shClassName;
} /*method end*/
public final BEC_2_4_6_TextString bem_shClassNameGetDirect_0() throws Throwable {
return bevp_shClassName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_shClassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGet_0() throws Throwable {
return bevp_shFileName;
} /*method end*/
public final BEC_2_4_6_TextString bem_shFileNameGetDirect_0() throws Throwable {
return bevp_shFileName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_shFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGet_0() throws Throwable {
return bevp_cldefBuild;
} /*method end*/
public final BEC_2_4_6_TextString bem_cldefBuildGetDirect_0() throws Throwable {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cldefBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGet_0() throws Throwable {
return bevp_libnameInit;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameInitGetDirect_0() throws Throwable {
return bevp_libnameInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGet_0() throws Throwable {
return bevp_libnameInitDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameInitDoneGetDirect_0() throws Throwable {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGet_0() throws Throwable {
return bevp_libnameData;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataGetDirect_0() throws Throwable {
return bevp_libnameData;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGet_0() throws Throwable {
return bevp_libnameDataDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataDoneGetDirect_0() throws Throwable {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGet_0() throws Throwable {
return bevp_libnameDataClear;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataClearGetDirect_0() throws Throwable {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataClearSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGet_0() throws Throwable {
return bevp_libNotNullInit;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNotNullInitGetDirect_0() throws Throwable {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libNotNullInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGet_0() throws Throwable {
return bevp_libNotNullInitDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNotNullInitDoneGetDirect_0() throws Throwable {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_basePathGetDirect_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_basePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGet_0() throws Throwable {
return bevp_cuBase;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuBaseGetDirect_0() throws Throwable {
return bevp_cuBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGet_0() throws Throwable {
return bevp_nsDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_nsDirGetDirect_0() throws Throwable {
return bevp_nsDir;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nsDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGet_0() throws Throwable {
return bevp_xbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_xbaseGetDirect_0() throws Throwable {
return bevp_xbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_xbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGet_0() throws Throwable {
return bevp_lbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_lbaseGetDirect_0() throws Throwable {
return bevp_lbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_lbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGet_0() throws Throwable {
return bevp_nbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_nbaseGetDirect_0() throws Throwable {
return bevp_nbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGet_0() throws Throwable {
return bevp_kbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_kbaseGetDirect_0() throws Throwable {
return bevp_kbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_kbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGet_0() throws Throwable {
return bevp_cuinitH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuinitHGetDirect_0() throws Throwable {
return bevp_cuinitH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuinitHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGet_0() throws Throwable {
return bevp_namesIncH;
} /*method end*/
public final BEC_2_4_6_TextString bem_namesIncHGetDirect_0() throws Throwable {
return bevp_namesIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_namesIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGet_0() throws Throwable {
return bevp_cuinit;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuinitGetDirect_0() throws Throwable {
return bevp_cuinit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuinitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGet_0() throws Throwable {
return bevp_namesO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_namesOGetDirect_0() throws Throwable {
return bevp_namesO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_namesOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGet_0() throws Throwable {
return bevp_unitShlib;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitShlibGetDirect_0() throws Throwable {
return bevp_unitShlib;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitShlibSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGet_0() throws Throwable {
return bevp_unitExeLink;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitExeLinkGetDirect_0() throws Throwable {
return bevp_unitExeLink;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitExeLinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGet_0() throws Throwable {
return bevp_unitExe;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitExeGetDirect_0() throws Throwable {
return bevp_unitExe;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitExeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGet_0() throws Throwable {
return bevp_classExeSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classExeSrcGetDirect_0() throws Throwable {
return bevp_classExeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classExeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGet_0() throws Throwable {
return bevp_classExeO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classExeOGetDirect_0() throws Throwable {
return bevp_classExeO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classExeOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGet_0() throws Throwable {
return bevp_makeSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_makeSrcGetDirect_0() throws Throwable {
return bevp_makeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_makeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGet_0() throws Throwable {
return bevp_classSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classSrcGetDirect_0() throws Throwable {
return bevp_classSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGet_0() throws Throwable {
return bevp_classSrcH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classSrcHGetDirect_0() throws Throwable {
return bevp_classSrcH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classSrcHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGet_0() throws Throwable {
return bevp_classIncH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classIncHGetDirect_0() throws Throwable {
return bevp_classIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGet_0() throws Throwable {
return bevp_classO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classOGetDirect_0() throws Throwable {
return bevp_classO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGet_0() throws Throwable {
return bevp_synSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_synSrcGetDirect_0() throws Throwable {
return bevp_synSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_synSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 28, 29, 30, 30, 31, 32, 33, 35, 35, 37, 39, 40, 41, 44, 44, 46, 46, 46, 46, 48, 48, 48, 48, 50, 50, 50, 50, 52, 52, 52, 52, 54, 54, 54, 54, 56, 56, 56, 56, 58, 58, 58, 58, 60, 60, 60, 60, 62, 62, 62, 62, 64, 64, 64, 64, 66, 66, 66, 66, 67, 67, 67, 67, 69, 71, 72, 75, 75, 76, 77, 78, 78, 80, 80, 80, 80, 81, 81, 82, 82, 82, 83, 83, 83, 87, 87, 87, 87, 88, 88, 88, 88, 89, 89, 89, 89, 91, 91, 91, 92, 92, 92, 93, 93, 93, 93, 95, 95, 95, 96, 96, 96, 96, 97, 97, 97, 97, 98, 98, 98, 99, 99, 99, 99, 109, 110, 111, 111, 112, 112, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {122, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 336, 337, 338, 341, 343, 344, 353, 356, 359, 363, 367, 370, 373, 377, 381, 384, 387, 391, 395, 398, 401, 405, 409, 412, 415, 419, 423, 426, 429, 433, 437, 440, 443, 447, 451, 454, 457, 461, 465, 468, 471, 475, 479, 482, 485, 489, 493, 496, 499, 503, 507, 510, 513, 517, 521, 524, 527, 531, 535, 538, 541, 545, 549, 552, 555, 559, 563, 566, 569, 573, 577, 580, 583, 587, 591, 594, 597, 601, 605, 608, 611, 615, 619, 622, 625, 629, 633, 636, 639, 643, 647, 650, 653, 657, 661, 664, 667, 671, 675, 678, 681, 685, 689, 692, 695, 699, 703, 706, 709, 713, 717, 720, 723, 727, 731, 734, 737, 741, 745, 748, 751, 755, 759, 762, 765, 769, 773, 776, 779, 783, 787, 790, 793, 797, 801, 804, 807, 811, 815, 818, 821, 825, 829, 832, 835, 839, 843, 846, 849, 853, 857, 860, 863, 867, 871, 874, 877, 881, 885, 888, 891, 895, 899, 902, 905, 909, 913, 916, 919, 923, 927, 930, 933, 937, 941, 944, 947, 951, 955, 958, 961, 965};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 5 21 122
assign 1 28 206
assign 1 29 207
assign 1 30 208
buildGet 0 30 208
assign 1 30 209
compilerProfileGet 0 30 209
assign 1 31 210
parentGet 0 31 210
assign 1 32 211
stepsGet 0 32 211
assign 1 33 212
toString 0 33 212
assign 1 35 213
stepsGet 0 35 213
assign 1 35 214
lastGet 0 35 214
assign 1 37 215
midNameDo 2 37 215
nsDirDo 1 39 216
assign 1 40 217
cextGet 0 40 217
assign 1 41 218
oextGet 0 41 218
assign 1 44 219
new 0 44 219
assign 1 44 220
add 1 44 220
assign 1 46 221
new 0 46 221
assign 1 46 222
add 1 46 222
assign 1 46 223
new 0 46 223
assign 1 46 224
add 1 46 224
assign 1 48 225
new 0 48 225
assign 1 48 226
add 1 48 226
assign 1 48 227
new 0 48 227
assign 1 48 228
add 1 48 228
assign 1 50 229
new 0 50 229
assign 1 50 230
add 1 50 230
assign 1 50 231
new 0 50 231
assign 1 50 232
add 1 50 232
assign 1 52 233
new 0 52 233
assign 1 52 234
add 1 52 234
assign 1 52 235
new 0 52 235
assign 1 52 236
add 1 52 236
assign 1 54 237
new 0 54 237
assign 1 54 238
add 1 54 238
assign 1 54 239
new 0 54 239
assign 1 54 240
add 1 54 240
assign 1 56 241
new 0 56 241
assign 1 56 242
add 1 56 242
assign 1 56 243
new 0 56 243
assign 1 56 244
add 1 56 244
assign 1 58 245
new 0 58 245
assign 1 58 246
add 1 58 246
assign 1 58 247
new 0 58 247
assign 1 58 248
add 1 58 248
assign 1 60 249
new 0 60 249
assign 1 60 250
add 1 60 250
assign 1 60 251
new 0 60 251
assign 1 60 252
add 1 60 252
assign 1 62 253
new 0 62 253
assign 1 62 254
add 1 62 254
assign 1 62 255
new 0 62 255
assign 1 62 256
add 1 62 256
assign 1 64 257
new 0 64 257
assign 1 64 258
add 1 64 258
assign 1 64 259
new 0 64 259
assign 1 64 260
add 1 64 260
assign 1 66 261
new 0 66 261
assign 1 66 262
add 1 66 262
assign 1 66 263
new 0 66 263
assign 1 66 264
add 1 66 264
assign 1 67 265
new 0 67 265
assign 1 67 266
add 1 67 266
assign 1 67 267
new 0 67 267
assign 1 67 268
add 1 67 268
assign 1 69 269
assign 1 71 270
add 1 71 270
assign 1 72 271
copy 0 72 271
assign 1 75 272
new 0 75 272
assign 1 75 273
add 1 75 273
assign 1 76 274
assign 1 77 275
assign 1 78 276
new 0 78 276
assign 1 78 277
add 1 78 277
assign 1 80 278
copy 0 80 278
assign 1 80 279
new 0 80 279
assign 1 80 280
add 1 80 280
assign 1 80 281
addStep 1 80 281
assign 1 81 282
new 0 81 282
assign 1 81 283
add 1 81 283
assign 1 82 284
copy 0 82 284
assign 1 82 285
add 1 82 285
assign 1 82 286
addStep 1 82 286
assign 1 83 287
copy 0 83 287
assign 1 83 288
add 1 83 288
assign 1 83 289
addStep 1 83 289
assign 1 87 290
copy 0 87 290
assign 1 87 291
libExtGet 0 87 291
assign 1 87 292
add 1 87 292
assign 1 87 293
addStep 1 87 293
assign 1 88 294
copy 0 88 294
assign 1 88 295
exeLibExtGet 0 88 295
assign 1 88 296
add 1 88 296
assign 1 88 297
addStep 1 88 297
assign 1 89 298
copy 0 89 298
assign 1 89 299
exeExtGet 0 89 299
assign 1 89 300
add 1 89 300
assign 1 89 301
addStep 1 89 301
assign 1 91 302
copy 0 91 302
assign 1 91 303
add 1 91 303
assign 1 91 304
addStep 1 91 304
assign 1 92 305
copy 0 92 305
assign 1 92 306
add 1 92 306
assign 1 92 307
addStep 1 92 307
assign 1 93 308
copy 0 93 308
assign 1 93 309
new 0 93 309
assign 1 93 310
add 1 93 310
assign 1 93 311
addStep 1 93 311
assign 1 95 312
copy 0 95 312
assign 1 95 313
add 1 95 313
assign 1 95 314
addStep 1 95 314
assign 1 96 315
copy 0 96 315
assign 1 96 316
new 0 96 316
assign 1 96 317
add 1 96 317
assign 1 96 318
addStep 1 96 318
assign 1 97 319
copy 0 97 319
assign 1 97 320
new 0 97 320
assign 1 97 321
add 1 97 321
assign 1 97 322
addStep 1 97 322
assign 1 98 323
copy 0 98 323
assign 1 98 324
add 1 98 324
assign 1 98 325
addStep 1 98 325
assign 1 99 326
copy 0 99 326
assign 1 99 327
new 0 99 327
assign 1 99 328
add 1 99 328
assign 1 99 329
addStep 1 99 329
assign 1 109 336
new 0 109 336
addStep 1 110 337
assign 1 111 338
iteratorGet 0 111 338
assign 1 111 341
hasNextGet 0 111 341
assign 1 112 343
nextGet 0 112 343
addStep 1 112 344
return 1 0 353
return 1 0 356
assign 1 0 359
assign 1 0 363
return 1 0 367
return 1 0 370
assign 1 0 373
assign 1 0 377
return 1 0 381
return 1 0 384
assign 1 0 387
assign 1 0 391
return 1 0 395
return 1 0 398
assign 1 0 401
assign 1 0 405
return 1 0 409
return 1 0 412
assign 1 0 415
assign 1 0 419
return 1 0 423
return 1 0 426
assign 1 0 429
assign 1 0 433
return 1 0 437
return 1 0 440
assign 1 0 443
assign 1 0 447
return 1 0 451
return 1 0 454
assign 1 0 457
assign 1 0 461
return 1 0 465
return 1 0 468
assign 1 0 471
assign 1 0 475
return 1 0 479
return 1 0 482
assign 1 0 485
assign 1 0 489
return 1 0 493
return 1 0 496
assign 1 0 499
assign 1 0 503
return 1 0 507
return 1 0 510
assign 1 0 513
assign 1 0 517
return 1 0 521
return 1 0 524
assign 1 0 527
assign 1 0 531
return 1 0 535
return 1 0 538
assign 1 0 541
assign 1 0 545
return 1 0 549
return 1 0 552
assign 1 0 555
assign 1 0 559
return 1 0 563
return 1 0 566
assign 1 0 569
assign 1 0 573
return 1 0 577
return 1 0 580
assign 1 0 583
assign 1 0 587
return 1 0 591
return 1 0 594
assign 1 0 597
assign 1 0 601
return 1 0 605
return 1 0 608
assign 1 0 611
assign 1 0 615
return 1 0 619
return 1 0 622
assign 1 0 625
assign 1 0 629
return 1 0 633
return 1 0 636
assign 1 0 639
assign 1 0 643
return 1 0 647
return 1 0 650
assign 1 0 653
assign 1 0 657
return 1 0 661
return 1 0 664
assign 1 0 667
assign 1 0 671
return 1 0 675
return 1 0 678
assign 1 0 681
assign 1 0 685
return 1 0 689
return 1 0 692
assign 1 0 695
assign 1 0 699
return 1 0 703
return 1 0 706
assign 1 0 709
assign 1 0 713
return 1 0 717
return 1 0 720
assign 1 0 723
assign 1 0 727
return 1 0 731
return 1 0 734
assign 1 0 737
assign 1 0 741
return 1 0 745
return 1 0 748
assign 1 0 751
assign 1 0 755
return 1 0 759
return 1 0 762
assign 1 0 765
assign 1 0 769
return 1 0 773
return 1 0 776
assign 1 0 779
assign 1 0 783
return 1 0 787
return 1 0 790
assign 1 0 793
assign 1 0 797
return 1 0 801
return 1 0 804
assign 1 0 807
assign 1 0 811
return 1 0 815
return 1 0 818
assign 1 0 821
assign 1 0 825
return 1 0 829
return 1 0 832
assign 1 0 835
assign 1 0 839
return 1 0 843
return 1 0 846
assign 1 0 849
assign 1 0 853
return 1 0 857
return 1 0 860
assign 1 0 863
assign 1 0 867
return 1 0 871
return 1 0 874
assign 1 0 877
assign 1 0 881
return 1 0 885
return 1 0 888
assign 1 0 891
assign 1 0 895
return 1 0 899
return 1 0 902
assign 1 0 905
assign 1 0 909
return 1 0 913
return 1 0 916
assign 1 0 919
assign 1 0 923
return 1 0 927
return 1 0 930
assign 1 0 933
assign 1 0 937
return 1 0 941
return 1 0 944
assign 1 0 947
assign 1 0 951
return 1 0 955
return 1 0 958
assign 1 0 961
assign 1 0 965
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -964851457: return bem_classExeOGetDirect_0();
case -1346053541: return bem_shClassNameGetDirect_0();
case 874968344: return bem_once_0();
case -2085921494: return bem_basePathGetDirect_0();
case 1934691130: return bem_npGetDirect_0();
case 2061412556: return bem_classNameGet_0();
case 799743680: return bem_unitExeLinkGet_0();
case 189803568: return bem_makeSrcGet_0();
case 344752250: return bem_hashGet_0();
case -1417646361: return bem_midNameGetDirect_0();
case 1157340533: return bem_kbaseGet_0();
case 1001100569: return bem_shFileNameGetDirect_0();
case 1778795253: return bem_kbaseGetDirect_0();
case 565847978: return bem_libNotNullInitDoneGetDirect_0();
case -327578779: return bem_nparStepsGetDirect_0();
case 752911765: return bem_libnameInitGetDirect_0();
case -1922234283: return bem_classSrcGetDirect_0();
case 1354993882: return bem_namesOGet_0();
case 1480415803: return bem_serializationIteratorGet_0();
case -1238263699: return bem_libnameDataGetDirect_0();
case 786580729: return bem_clBaseGetDirect_0();
case 138608969: return bem_emitterGet_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case 466083986: return bem_classIncHGetDirect_0();
case 1708145728: return bem_libnameInitDoneGet_0();
case 1410689720: return bem_mtdNameGet_0();
case -2122443170: return bem_classExeSrcGetDirect_0();
case 1852272846: return bem_cuBaseGetDirect_0();
case 2016077835: return bem_nparStepsGet_0();
case 1344616826: return bem_libnameInitGet_0();
case 227713660: return bem_unitExeGet_0();
case -643295749: return bem_libnameDataClearGetDirect_0();
case -994541450: return bem_shFileNameGet_0();
case 223673582: return bem_cldefBuildGetDirect_0();
case -1767604312: return bem_lbaseGetDirect_0();
case 1776056536: return bem_midNameGet_0();
case 143278865: return bem_namesOGetDirect_0();
case 502031978: return bem_iteratorGet_0();
case -803928134: return bem_makeSrcGetDirect_0();
case 1690230829: return bem_cuinitHGet_0();
case -248718354: return bem_basePathGet_0();
case -1878305271: return bem_many_0();
case -1457774496: return bem_incBlockGetDirect_0();
case -517906034: return bem_classSrcHGet_0();
case 388377357: return bem_libNotNullInitGetDirect_0();
case 2069196027: return bem_print_0();
case 424716936: return bem_nsDirGetDirect_0();
case -795671845: return bem_libNotNullInitGet_0();
case 1335322005: return bem_libnameDataGet_0();
case -1564509417: return bem_cldefBuildGet_0();
case 1501576262: return bem_cldefNameGet_0();
case -799200084: return bem_serializeToString_0();
case 1855608645: return bem_nparGetDirect_0();
case -39706070: return bem_serializeContents_0();
case 1965613314: return bem_tagGet_0();
case 481926208: return bem_cuBaseGet_0();
case 1752818450: return bem_lbaseGet_0();
case -2121109316: return bem_shClassNameGet_0();
case 1735731341: return bem_cproGet_0();
case -364011732: return bem_classExeOGet_0();
case 1359777543: return bem_toAny_0();
case 325964466: return bem_echo_0();
case 412067554: return bem_xbaseGetDirect_0();
case -1664201156: return bem_namesIncHGetDirect_0();
case -710353217: return bem_clNameGet_0();
case 9242816: return bem_nbaseGetDirect_0();
case -1953197648: return bem_libnameDataClearGet_0();
case 27033645: return bem_sourceFileNameGet_0();
case 1578098134: return bem_toString_0();
case 1199957627: return bem_libnameInitDoneGetDirect_0();
case 717440961: return bem_synSrcGet_0();
case 2138603950: return bem_libnameDataDoneGet_0();
case -710741749: return bem_classExeSrcGet_0();
case 605755759: return bem_fieldNamesGet_0();
case -62277836: return bem_nsDirGet_0();
case -767993755: return bem_cuinitGetDirect_0();
case -2114774002: return bem_libNotNullInitDoneGet_0();
case -725301459: return bem_classOGetDirect_0();
case -2051503412: return bem_cldefNameGetDirect_0();
case -712833838: return bem_clBaseGet_0();
case 2132890711: return bem_new_0();
case -1494503604: return bem_npGet_0();
case -1684349136: return bem_incBlockGet_0();
case -844442256: return bem_libnameDataDoneGetDirect_0();
case 334767424: return bem_copy_0();
case 962099177: return bem_fieldIteratorGet_0();
case 2071057113: return bem_cuinitHGetDirect_0();
case 1625094817: return bem_emitPathGetDirect_0();
case -506551409: return bem_classOGet_0();
case 2022493545: return bem_unitShlibGet_0();
case 1665549395: return bem_mtdNameGetDirect_0();
case -611992530: return bem_classIncHGet_0();
case -962982284: return bem_nparGet_0();
case -75851658: return bem_namesIncHGet_0();
case -299256662: return bem_unitExeLinkGetDirect_0();
case -214536230: return bem_unitExeGetDirect_0();
case 1462521088: return bem_synSrcGetDirect_0();
case -778176021: return bem_cproGetDirect_0();
case 503635566: return bem_emitterGetDirect_0();
case -205971282: return bem_clNameGetDirect_0();
case -2117012678: return bem_xbaseGet_0();
case 141212724: return bem_classSrcGet_0();
case 1482443523: return bem_classSrcHGetDirect_0();
case 1670347592: return bem_emitPathGet_0();
case -1927461050: return bem_cuinitGet_0();
case 1047965395: return bem_unitShlibGetDirect_0();
case 26417469: return bem_create_0();
case -557961075: return bem_nbaseGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1019932532: return bem_nparSetDirect_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case 1306421122: return bem_classExeSrcSetDirect_1(bevd_0);
case -321023400: return bem_unitExeLinkSetDirect_1(bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case -1911400233: return bem_namesOSet_1(bevd_0);
case -1129302295: return bem_classExeSrcSet_1(bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case 1438441237: return bem_nparStepsSetDirect_1(bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case -933726762: return bem_cldefNameSet_1(bevd_0);
case 1010623145: return bem_libnameDataDoneSetDirect_1(bevd_0);
case -633236658: return bem_classIncHSetDirect_1(bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case 1534321471: return bem_shClassNameSetDirect_1(bevd_0);
case 1910041655: return bem_namesIncHSetDirect_1(bevd_0);
case 1900477813: return bem_libnameDataDoneSet_1(bevd_0);
case 141931468: return bem_cproSet_1(bevd_0);
case -333049473: return bem_libnameDataClearSet_1(bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case 1075277381: return bem_makeSrcSetDirect_1(bevd_0);
case 159737098: return bem_nbaseSet_1(bevd_0);
case 754473419: return bem_classExeOSetDirect_1(bevd_0);
case 1232334410: return bem_makeSrcSet_1(bevd_0);
case -918477157: return bem_emitPathSet_1(bevd_0);
case 2100999135: return bem_unitExeSet_1(bevd_0);
case 715743437: return bem_shClassNameSet_1(bevd_0);
case 58869919: return bem_libNotNullInitDoneSetDirect_1(bevd_0);
case -1033241022: return bem_libnameInitSet_1(bevd_0);
case 810643418: return bem_shFileNameSetDirect_1(bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case -1294692712: return bem_emitterSetDirect_1(bevd_0);
case -788580607: return bem_unitExeSetDirect_1(bevd_0);
case 820262158: return bem_basePathSet_1(bevd_0);
case 1423139295: return bem_nsDirDo_1((BEC_2_4_6_TextString) bevd_0);
case 836089039: return bem_xbaseSetDirect_1(bevd_0);
case -263069738: return bem_xbaseSet_1(bevd_0);
case -1058905290: return bem_unitShlibSet_1(bevd_0);
case 536552928: return bem_libNotNullInitSetDirect_1(bevd_0);
case -1946721549: return bem_mtdNameSetDirect_1(bevd_0);
case -313762134: return bem_cuinitSet_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1463476031: return bem_namesOSetDirect_1(bevd_0);
case -1060736197: return bem_incBlockSetDirect_1(bevd_0);
case -2137253660: return bem_emitPathSetDirect_1(bevd_0);
case 558368555: return bem_cproSetDirect_1(bevd_0);
case -2002356474: return bem_synSrcSet_1(bevd_0);
case -1787506939: return bem_libnameInitDoneSetDirect_1(bevd_0);
case 279255203: return bem_npSet_1(bevd_0);
case -1769662380: return bem_clBaseSet_1(bevd_0);
case 1682803091: return bem_libNotNullInitDoneSet_1(bevd_0);
case -500821747: return bem_cuinitHSetDirect_1(bevd_0);
case 397389884: return bem_classSrcSet_1(bevd_0);
case -2127179517: return bem_lbaseSetDirect_1(bevd_0);
case 2091193848: return bem_unitExeLinkSet_1(bevd_0);
case 1290854629: return bem_nbaseSetDirect_1(bevd_0);
case 1099805011: return bem_classOSetDirect_1(bevd_0);
case -1761743479: return bem_midNameSetDirect_1(bevd_0);
case 1011041696: return bem_classOSet_1(bevd_0);
case -991829737: return bem_cuinitSetDirect_1(bevd_0);
case -213965169: return bem_nsDirSetDirect_1(bevd_0);
case 651502175: return bem_kbaseSetDirect_1(bevd_0);
case 1992943851: return bem_cldefBuildSet_1(bevd_0);
case -707781841: return bem_classIncHSet_1(bevd_0);
case 277380771: return bem_libnameDataSet_1(bevd_0);
case 1436732454: return bem_incBlockSet_1(bevd_0);
case -47037478: return bem_nparStepsSet_1(bevd_0);
case 1487470968: return bem_clNameSet_1(bevd_0);
case -767442650: return bem_nsDirSet_1(bevd_0);
case -1351631717: return bem_classExeOSet_1(bevd_0);
case -527740636: return bem_nparSet_1(bevd_0);
case -241847508: return bem_libnameInitDoneSet_1(bevd_0);
case -1398904826: return bem_kbaseSet_1(bevd_0);
case 272307150: return bem_mtdNameSet_1(bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1523536209: return bem_libnameInitSetDirect_1(bevd_0);
case -1763963291: return bem_cuBaseSetDirect_1(bevd_0);
case -1658500194: return bem_clBaseSetDirect_1(bevd_0);
case 848523999: return bem_shFileNameSet_1(bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case 1516609446: return bem_cuBaseSet_1(bevd_0);
case -1702374714: return bem_lbaseSet_1(bevd_0);
case 1786949200: return bem_classSrcHSetDirect_1(bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case 1778627143: return bem_basePathSetDirect_1(bevd_0);
case 1596178620: return bem_cuinitHSet_1(bevd_0);
case -1162987097: return bem_namesIncHSet_1(bevd_0);
case -1953883308: return bem_synSrcSetDirect_1(bevd_0);
case 1588310519: return bem_libnameDataSetDirect_1(bevd_0);
case -164436899: return bem_libNotNullInitSet_1(bevd_0);
case 67646444: return bem_unitShlibSetDirect_1(bevd_0);
case 604645119: return bem_clNameSetDirect_1(bevd_0);
case -394013844: return bem_classSrcHSet_1(bevd_0);
case 702774370: return bem_midNameSet_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 100649331: return bem_npSetDirect_1(bevd_0);
case 1723521789: return bem_classSrcSetDirect_1(bevd_0);
case 216897416: return bem_emitterSet_1(bevd_0);
case 539432097: return bem_libnameDataClearSetDirect_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
case 1142070743: return bem_cldefBuildSetDirect_1(bevd_0);
case -124810210: return bem_cldefNameSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2132159308: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1602529568: return bem_new_5((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildClassInfo_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildClassInfo_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildClassInfo();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst = (BEC_2_5_9_BuildClassInfo) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_type;
}
}
