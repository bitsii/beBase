package be;
/* IO:File: source/build/CEmitter.be */
public final class BEC_2_5_9_BuildClassInfo extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildClassInfo() { }
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_2 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_5 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_6 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_7 = {0x42,0x45,0x55,0x46,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_8 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_9 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_10 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_11 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_13 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_14 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_15 = {0x42,0x45,0x58,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_16 = {0x42,0x45,0x4B,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_17 = {0x2E,0x68};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_18 = {0x2E,0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_19 = {0x2E,0x73,0x79,0x6E};
public static BEC_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_inst;

public static BET_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_15_BuildCompilerProfile bevp_cpro;
public BEC_2_5_8_BuildNamePath bevp_npar;
public BEC_2_6_6_SystemObject bevp_nparSteps;
public BEC_2_4_6_TextString bevp_clName;
public BEC_2_4_6_TextString bevp_clBase;
public BEC_2_4_6_TextString bevp_midName;
public BEC_2_4_6_TextString bevp_incBlock;
public BEC_2_4_6_TextString bevp_mtdName;
public BEC_2_4_6_TextString bevp_cldefName;
public BEC_2_4_6_TextString bevp_shClassName;
public BEC_2_4_6_TextString bevp_shFileName;
public BEC_2_4_6_TextString bevp_cldefBuild;
public BEC_2_4_6_TextString bevp_libnameInit;
public BEC_2_4_6_TextString bevp_libnameInitDone;
public BEC_2_4_6_TextString bevp_libnameData;
public BEC_2_4_6_TextString bevp_libnameDataDone;
public BEC_2_4_6_TextString bevp_libnameDataClear;
public BEC_2_4_6_TextString bevp_libNotNullInit;
public BEC_2_4_6_TextString bevp_libNotNullInitDone;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_cuBase;
public BEC_3_2_4_4_IOFilePath bevp_nsDir;
public BEC_2_4_6_TextString bevp_xbase;
public BEC_2_4_6_TextString bevp_lbase;
public BEC_2_4_6_TextString bevp_nbase;
public BEC_2_4_6_TextString bevp_kbase;
public BEC_3_2_4_4_IOFilePath bevp_cuinitH;
public BEC_2_4_6_TextString bevp_namesIncH;
public BEC_3_2_4_4_IOFilePath bevp_cuinit;
public BEC_3_2_4_4_IOFilePath bevp_namesO;
public BEC_3_2_4_4_IOFilePath bevp_unitShlib;
public BEC_3_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_3_2_4_4_IOFilePath bevp_unitExe;
public BEC_3_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classExeO;
public BEC_3_2_4_4_IOFilePath bevp_makeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrcH;
public BEC_3_2_4_4_IOFilePath bevp_classIncH;
public BEC_3_2_4_4_IOFilePath bevp_classO;
public BEC_3_2_4_4_IOFilePath bevp_synSrc;
public BEC_2_5_9_BuildClassInfo bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_new_5(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) throws Throwable {
BEC_2_4_6_TextString bevl_cext = null;
BEC_2_4_6_TextString bevl_oext = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_ta_ph = bevp_emitter.bemd_0(1621218705);
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_ph.bemd_0(-1300212075);
bevp_npar = (BEC_2_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_ta_ph = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lastGet_0();
bevp_midName = (BEC_2_4_6_TextString) bevp_emitter.bemd_2(-1717841838, beva__libName, beva__np);
bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_0));
bevp_incBlock = bevt_2_ta_ph.bem_add_1(bevp_midName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevp_midName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildClassInfo_bels_2));
bevp_mtdName = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevp_midName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildClassInfo_bels_4));
bevp_cldefName = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_midName);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_5));
bevp_shClassName = bevt_9_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevp_midName);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildClassInfo_bels_6));
bevp_shFileName = bevt_12_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_15_ta_ph = bevt_16_ta_ph.bem_add_1(bevp_midName);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildClassInfo_bels_4));
bevp_cldefBuild = bevt_15_ta_ph.bem_add_1(bevt_17_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevp_midName);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_8));
bevp_libnameInit = bevt_18_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevp_midName);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_9));
bevp_libnameInitDone = bevt_21_ta_ph.bem_add_1(bevt_23_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevp_midName);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_10));
bevp_libnameData = bevt_24_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(bevp_midName);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_11));
bevp_libnameDataDone = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevp_midName);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildClassInfo_bels_12));
bevp_libnameDataClear = bevt_30_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_34_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_33_ta_ph = bevt_34_ta_ph.bem_add_1(bevp_midName);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_13));
bevp_libNotNullInit = bevt_33_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_midName);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_14));
bevp_libNotNullInitDone = bevt_36_ta_ph.bem_add_1(bevt_38_ta_ph);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = beva__emitPath.bem_copy_0();
bevt_39_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_15));
bevp_xbase = bevt_39_ta_ph.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_16));
bevp_kbase = bevt_40_ta_ph.bem_add_1(bevp_clBase);
bevt_41_ta_ph = bevp_cuBase.bem_copy_0();
bevt_43_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_42_ta_ph = bevp_nbase.bem_add_1(bevt_43_ta_ph);
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_41_ta_ph.bem_addStep_1(bevt_42_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_ta_ph);
bevt_45_ta_ph = bevp_cuBase.bem_copy_0();
bevt_46_ta_ph = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_45_ta_ph.bem_addStep_1(bevt_46_ta_ph);
bevt_47_ta_ph = bevp_cuBase.bem_copy_0();
bevt_48_ta_ph = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_47_ta_ph.bem_addStep_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevp_cuBase.bem_copy_0();
bevt_51_ta_ph = bevp_cpro.bem_libExtGet_0();
bevt_50_ta_ph = bevp_lbase.bem_add_1(bevt_51_ta_ph);
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_49_ta_ph.bem_addStep_1(bevt_50_ta_ph);
bevt_52_ta_ph = bevp_cuBase.bem_copy_0();
bevt_54_ta_ph = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_ta_ph = bevp_lbase.bem_add_1(bevt_54_ta_ph);
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_52_ta_ph.bem_addStep_1(bevt_53_ta_ph);
bevt_55_ta_ph = bevp_cuBase.bem_copy_0();
bevt_57_ta_ph = bevp_cpro.bem_exeExtGet_0();
bevt_56_ta_ph = beva__exeName.bem_add_1(bevt_57_ta_ph);
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_55_ta_ph.bem_addStep_1(bevt_56_ta_ph);
bevt_58_ta_ph = bevp_basePath.bem_copy_0();
bevt_59_ta_ph = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_58_ta_ph.bem_addStep_1(bevt_59_ta_ph);
bevt_60_ta_ph = bevp_basePath.bem_copy_0();
bevt_61_ta_ph = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_60_ta_ph.bem_addStep_1(bevt_61_ta_ph);
bevt_62_ta_ph = bevp_basePath.bem_copy_0();
bevt_64_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_18));
bevt_63_ta_ph = bevp_xbase.bem_add_1(bevt_64_ta_ph);
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_62_ta_ph.bem_addStep_1(bevt_63_ta_ph);
bevt_65_ta_ph = bevp_basePath.bem_copy_0();
bevt_66_ta_ph = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_65_ta_ph.bem_addStep_1(bevt_66_ta_ph);
bevt_67_ta_ph = bevp_basePath.bem_copy_0();
bevt_69_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_68_ta_ph = bevp_kbase.bem_add_1(bevt_69_ta_ph);
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_67_ta_ph.bem_addStep_1(bevt_68_ta_ph);
bevt_70_ta_ph = bevp_nsDir.bem_copy_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_71_ta_ph = bevp_kbase.bem_add_1(bevt_72_ta_ph);
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_70_ta_ph.bem_addStep_1(bevt_71_ta_ph);
bevt_73_ta_ph = bevp_basePath.bem_copy_0();
bevt_74_ta_ph = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_73_ta_ph.bem_addStep_1(bevt_74_ta_ph);
bevt_75_ta_ph = bevp_basePath.bem_copy_0();
bevt_77_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_19));
bevt_76_ta_ph = bevp_kbase.bem_add_1(bevt_77_ta_ph);
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_75_ta_ph.bem_addStep_1(bevt_76_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirDo_1(BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(-1292167797);
while (true)
/* Line: 116*/ {
bevt_0_ta_ph = bevl_i.bemd_0(1936605887);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 116*/ {
bevt_1_ta_ph = bevl_i.bemd_0(404000237);
bevp_nsDir.bem_addStep_1(bevt_1_ta_ph);
} /* Line: 117*/
 else /* Line: 116*/ {
break;
} /* Line: 116*/
} /* Line: 116*/
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGet_0() throws Throwable {
return bevp_cpro;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGet_0() throws Throwable {
return bevp_npar;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGet_0() throws Throwable {
return bevp_nparSteps;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nparSteps = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGet_0() throws Throwable {
return bevp_clName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGet_0() throws Throwable {
return bevp_clBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGet_0() throws Throwable {
return bevp_midName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGet_0() throws Throwable {
return bevp_incBlock;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGet_0() throws Throwable {
return bevp_mtdName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGet_0() throws Throwable {
return bevp_cldefName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGet_0() throws Throwable {
return bevp_shClassName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGet_0() throws Throwable {
return bevp_shFileName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGet_0() throws Throwable {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGet_0() throws Throwable {
return bevp_libnameInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGet_0() throws Throwable {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGet_0() throws Throwable {
return bevp_libnameData;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGet_0() throws Throwable {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGet_0() throws Throwable {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGet_0() throws Throwable {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGet_0() throws Throwable {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGet_0() throws Throwable {
return bevp_cuBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGet_0() throws Throwable {
return bevp_nsDir;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGet_0() throws Throwable {
return bevp_xbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGet_0() throws Throwable {
return bevp_lbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGet_0() throws Throwable {
return bevp_nbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGet_0() throws Throwable {
return bevp_kbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGet_0() throws Throwable {
return bevp_cuinitH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGet_0() throws Throwable {
return bevp_namesIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGet_0() throws Throwable {
return bevp_cuinit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGet_0() throws Throwable {
return bevp_namesO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGet_0() throws Throwable {
return bevp_unitShlib;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGet_0() throws Throwable {
return bevp_unitExeLink;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGet_0() throws Throwable {
return bevp_unitExe;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGet_0() throws Throwable {
return bevp_classExeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGet_0() throws Throwable {
return bevp_classExeO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGet_0() throws Throwable {
return bevp_makeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGet_0() throws Throwable {
return bevp_classSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGet_0() throws Throwable {
return bevp_classSrcH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGet_0() throws Throwable {
return bevp_classIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGet_0() throws Throwable {
return bevp_classO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGet_0() throws Throwable {
return bevp_synSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 33, 34, 35, 35, 36, 37, 38, 40, 40, 42, 44, 45, 46, 49, 49, 51, 51, 51, 51, 53, 53, 53, 53, 55, 55, 55, 55, 57, 57, 57, 57, 59, 59, 59, 59, 61, 61, 61, 61, 63, 63, 63, 63, 65, 65, 65, 65, 67, 67, 67, 67, 69, 69, 69, 69, 71, 71, 71, 71, 72, 72, 72, 72, 74, 76, 77, 80, 80, 81, 82, 83, 83, 85, 85, 85, 85, 86, 86, 87, 87, 87, 88, 88, 88, 92, 92, 92, 92, 93, 93, 93, 93, 94, 94, 94, 94, 96, 96, 96, 97, 97, 97, 98, 98, 98, 98, 100, 100, 100, 101, 101, 101, 101, 102, 102, 102, 102, 103, 103, 103, 104, 104, 104, 104, 114, 115, 116, 116, 117, 117, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {76, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 290, 291, 292, 295, 297, 298, 307, 310, 314, 317, 321, 324, 328, 331, 335, 338, 342, 345, 349, 352, 356, 359, 363, 366, 370, 373, 377, 380, 384, 387, 391, 394, 398, 401, 405, 408, 412, 415, 419, 422, 426, 429, 433, 436, 440, 443, 447, 450, 454, 457, 461, 464, 468, 471, 475, 478, 482, 485, 489, 492, 496, 499, 503, 506, 510, 513, 517, 520, 524, 527, 531, 534, 538, 541, 545, 548, 552, 555, 559, 562, 566, 569, 573, 576, 580, 583, 587, 590, 594, 597, 601, 604, 608, 611};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 5 26 76
assign 1 33 160
assign 1 34 161
assign 1 35 162
buildGet 0 35 162
assign 1 35 163
compilerProfileGet 0 35 163
assign 1 36 164
parentGet 0 36 164
assign 1 37 165
stepsGet 0 37 165
assign 1 38 166
toString 0 38 166
assign 1 40 167
stepsGet 0 40 167
assign 1 40 168
lastGet 0 40 168
assign 1 42 169
midNameDo 2 42 169
nsDirDo 1 44 170
assign 1 45 171
cextGet 0 45 171
assign 1 46 172
oextGet 0 46 172
assign 1 49 173
new 0 49 173
assign 1 49 174
add 1 49 174
assign 1 51 175
new 0 51 175
assign 1 51 176
add 1 51 176
assign 1 51 177
new 0 51 177
assign 1 51 178
add 1 51 178
assign 1 53 179
new 0 53 179
assign 1 53 180
add 1 53 180
assign 1 53 181
new 0 53 181
assign 1 53 182
add 1 53 182
assign 1 55 183
new 0 55 183
assign 1 55 184
add 1 55 184
assign 1 55 185
new 0 55 185
assign 1 55 186
add 1 55 186
assign 1 57 187
new 0 57 187
assign 1 57 188
add 1 57 188
assign 1 57 189
new 0 57 189
assign 1 57 190
add 1 57 190
assign 1 59 191
new 0 59 191
assign 1 59 192
add 1 59 192
assign 1 59 193
new 0 59 193
assign 1 59 194
add 1 59 194
assign 1 61 195
new 0 61 195
assign 1 61 196
add 1 61 196
assign 1 61 197
new 0 61 197
assign 1 61 198
add 1 61 198
assign 1 63 199
new 0 63 199
assign 1 63 200
add 1 63 200
assign 1 63 201
new 0 63 201
assign 1 63 202
add 1 63 202
assign 1 65 203
new 0 65 203
assign 1 65 204
add 1 65 204
assign 1 65 205
new 0 65 205
assign 1 65 206
add 1 65 206
assign 1 67 207
new 0 67 207
assign 1 67 208
add 1 67 208
assign 1 67 209
new 0 67 209
assign 1 67 210
add 1 67 210
assign 1 69 211
new 0 69 211
assign 1 69 212
add 1 69 212
assign 1 69 213
new 0 69 213
assign 1 69 214
add 1 69 214
assign 1 71 215
new 0 71 215
assign 1 71 216
add 1 71 216
assign 1 71 217
new 0 71 217
assign 1 71 218
add 1 71 218
assign 1 72 219
new 0 72 219
assign 1 72 220
add 1 72 220
assign 1 72 221
new 0 72 221
assign 1 72 222
add 1 72 222
assign 1 74 223
assign 1 76 224
add 1 76 224
assign 1 77 225
copy 0 77 225
assign 1 80 226
new 0 80 226
assign 1 80 227
add 1 80 227
assign 1 81 228
assign 1 82 229
assign 1 83 230
new 0 83 230
assign 1 83 231
add 1 83 231
assign 1 85 232
copy 0 85 232
assign 1 85 233
new 0 85 233
assign 1 85 234
add 1 85 234
assign 1 85 235
addStep 1 85 235
assign 1 86 236
new 0 86 236
assign 1 86 237
add 1 86 237
assign 1 87 238
copy 0 87 238
assign 1 87 239
add 1 87 239
assign 1 87 240
addStep 1 87 240
assign 1 88 241
copy 0 88 241
assign 1 88 242
add 1 88 242
assign 1 88 243
addStep 1 88 243
assign 1 92 244
copy 0 92 244
assign 1 92 245
libExtGet 0 92 245
assign 1 92 246
add 1 92 246
assign 1 92 247
addStep 1 92 247
assign 1 93 248
copy 0 93 248
assign 1 93 249
exeLibExtGet 0 93 249
assign 1 93 250
add 1 93 250
assign 1 93 251
addStep 1 93 251
assign 1 94 252
copy 0 94 252
assign 1 94 253
exeExtGet 0 94 253
assign 1 94 254
add 1 94 254
assign 1 94 255
addStep 1 94 255
assign 1 96 256
copy 0 96 256
assign 1 96 257
add 1 96 257
assign 1 96 258
addStep 1 96 258
assign 1 97 259
copy 0 97 259
assign 1 97 260
add 1 97 260
assign 1 97 261
addStep 1 97 261
assign 1 98 262
copy 0 98 262
assign 1 98 263
new 0 98 263
assign 1 98 264
add 1 98 264
assign 1 98 265
addStep 1 98 265
assign 1 100 266
copy 0 100 266
assign 1 100 267
add 1 100 267
assign 1 100 268
addStep 1 100 268
assign 1 101 269
copy 0 101 269
assign 1 101 270
new 0 101 270
assign 1 101 271
add 1 101 271
assign 1 101 272
addStep 1 101 272
assign 1 102 273
copy 0 102 273
assign 1 102 274
new 0 102 274
assign 1 102 275
add 1 102 275
assign 1 102 276
addStep 1 102 276
assign 1 103 277
copy 0 103 277
assign 1 103 278
add 1 103 278
assign 1 103 279
addStep 1 103 279
assign 1 104 280
copy 0 104 280
assign 1 104 281
new 0 104 281
assign 1 104 282
add 1 104 282
assign 1 104 283
addStep 1 104 283
assign 1 114 290
new 0 114 290
addStep 1 115 291
assign 1 116 292
iteratorGet 0 116 292
assign 1 116 295
hasNextGet 0 116 295
assign 1 117 297
nextGet 0 117 297
addStep 1 117 298
return 1 0 307
assign 1 0 310
return 1 0 314
assign 1 0 317
return 1 0 321
assign 1 0 324
return 1 0 328
assign 1 0 331
return 1 0 335
assign 1 0 338
return 1 0 342
assign 1 0 345
return 1 0 349
assign 1 0 352
return 1 0 356
assign 1 0 359
return 1 0 363
assign 1 0 366
return 1 0 370
assign 1 0 373
return 1 0 377
assign 1 0 380
return 1 0 384
assign 1 0 387
return 1 0 391
assign 1 0 394
return 1 0 398
assign 1 0 401
return 1 0 405
assign 1 0 408
return 1 0 412
assign 1 0 415
return 1 0 419
assign 1 0 422
return 1 0 426
assign 1 0 429
return 1 0 433
assign 1 0 436
return 1 0 440
assign 1 0 443
return 1 0 447
assign 1 0 450
return 1 0 454
assign 1 0 457
return 1 0 461
assign 1 0 464
return 1 0 468
assign 1 0 471
return 1 0 475
assign 1 0 478
return 1 0 482
assign 1 0 485
return 1 0 489
assign 1 0 492
return 1 0 496
assign 1 0 499
return 1 0 503
assign 1 0 506
return 1 0 510
assign 1 0 513
return 1 0 517
assign 1 0 520
return 1 0 524
assign 1 0 527
return 1 0 531
assign 1 0 534
return 1 0 538
assign 1 0 541
return 1 0 545
assign 1 0 548
return 1 0 552
assign 1 0 555
return 1 0 559
assign 1 0 562
return 1 0 566
assign 1 0 569
return 1 0 573
assign 1 0 576
return 1 0 580
assign 1 0 583
return 1 0 587
assign 1 0 590
return 1 0 594
assign 1 0 597
return 1 0 601
assign 1 0 604
return 1 0 608
assign 1 0 611
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 840525394: return bem_npGet_0();
case 911243583: return bem_cldefNameGet_0();
case 1838691554: return bem_classExeOGet_0();
case -1204781417: return bem_shClassNameGet_0();
case -282345062: return bem_nparGet_0();
case 289803372: return bem_print_0();
case -997835657: return bem_nparStepsGet_0();
case 149331178: return bem_cuinitHGet_0();
case 1220633838: return bem_synSrcGet_0();
case -900494942: return bem_kbaseGet_0();
case -361216482: return bem_classOGet_0();
case 1422525889: return bem_lbaseGet_0();
case -322779852: return bem_new_0();
case 812438824: return bem_makeSrcGet_0();
case 1381359547: return bem_libnameDataClearGet_0();
case -891326329: return bem_incBlockGet_0();
case -1177350605: return bem_emitPathGet_0();
case -118612185: return bem_hashGet_0();
case 182162760: return bem_libNotNullInitDoneGet_0();
case -1218624437: return bem_classSrcGet_0();
case -903215656: return bem_copy_0();
case 1044379713: return bem_classSrcHGet_0();
case -1465854666: return bem_unitExeGet_0();
case -94622817: return bem_nbaseGet_0();
case 374787209: return bem_emitterGet_0();
case -1306292615: return bem_namesOGet_0();
case 660965692: return bem_namesIncHGet_0();
case -1127317805: return bem_classExeSrcGet_0();
case -280467032: return bem_libnameInitGet_0();
case -1876935383: return bem_clNameGet_0();
case 1411480672: return bem_cproGet_0();
case 849029620: return bem_create_0();
case 526443262: return bem_classIncHGet_0();
case 1759244670: return bem_cuinitGet_0();
case 1227682994: return bem_basePathGet_0();
case 507888013: return bem_xbaseGet_0();
case -2067034886: return bem_libNotNullInitGet_0();
case 801553162: return bem_unitShlibGet_0();
case -1394356725: return bem_midNameGet_0();
case -1227788870: return bem_libnameDataGet_0();
case 788675242: return bem_shFileNameGet_0();
case -1292167797: return bem_iteratorGet_0();
case -1471045267: return bem_cuBaseGet_0();
case 809725631: return bem_libnameDataDoneGet_0();
case -1511157111: return bem_unitExeLinkGet_0();
case 146549082: return bem_nsDirGet_0();
case 786596794: return bem_mtdNameGet_0();
case -652216101: return bem_libnameInitDoneGet_0();
case -770618669: return bem_cldefBuildGet_0();
case 1831549959: return bem_toString_0();
case 1861470633: return bem_clBaseGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2142068391: return bem_equals_1(bevd_0);
case -514975232: return bem_midNameSet_1(bevd_0);
case -905459173: return bem_libnameInitSet_1(bevd_0);
case -1630529294: return bem_def_1(bevd_0);
case -1309175189: return bem_libNotNullInitSet_1(bevd_0);
case 400226383: return bem_libNotNullInitDoneSet_1(bevd_0);
case -150017581: return bem_shFileNameSet_1(bevd_0);
case 1195880100: return bem_libnameDataClearSet_1(bevd_0);
case -1973917361: return bem_npSet_1(bevd_0);
case -264386849: return bem_basePathSet_1(bevd_0);
case -703668021: return bem_nparSet_1(bevd_0);
case -1779036558: return bem_classIncHSet_1(bevd_0);
case -993723956: return bem_mtdNameSet_1(bevd_0);
case 854462919: return bem_synSrcSet_1(bevd_0);
case 1824228262: return bem_emitterSet_1(bevd_0);
case 1688912697: return bem_classSrcSet_1(bevd_0);
case -1113153689: return bem_cldefNameSet_1(bevd_0);
case -1628845026: return bem_undef_1(bevd_0);
case 458037699: return bem_lbaseSet_1(bevd_0);
case -1152772153: return bem_cuinitHSet_1(bevd_0);
case -866368345: return bem_classOSet_1(bevd_0);
case 908724514: return bem_nsDirSet_1(bevd_0);
case -52626195: return bem_shClassNameSet_1(bevd_0);
case 1598506304: return bem_cproSet_1(bevd_0);
case -942582579: return bem_classSrcHSet_1(bevd_0);
case -2074303174: return bem_kbaseSet_1(bevd_0);
case -353664649: return bem_cldefBuildSet_1(bevd_0);
case 1437244455: return bem_notEquals_1(bevd_0);
case 811612914: return bem_cuinitSet_1(bevd_0);
case 138329537: return bem_namesIncHSet_1(bevd_0);
case -1980530677: return bem_emitPathSet_1(bevd_0);
case -403333522: return bem_unitExeSet_1(bevd_0);
case 1824824363: return bem_libnameDataDoneSet_1(bevd_0);
case -1837554786: return bem_copyTo_1(bevd_0);
case 1817381941: return bem_unitShlibSet_1(bevd_0);
case -186771808: return bem_nsDirDo_1((BEC_2_4_6_TextString) bevd_0);
case -88546389: return bem_classExeSrcSet_1(bevd_0);
case 51182539: return bem_clNameSet_1(bevd_0);
case 1174058147: return bem_unitExeLinkSet_1(bevd_0);
case 22509304: return bem_nparStepsSet_1(bevd_0);
case 873549500: return bem_print_1(bevd_0);
case -17773438: return bem_nbaseSet_1(bevd_0);
case 200082117: return bem_libnameInitDoneSet_1(bevd_0);
case 184287885: return bem_libnameDataSet_1(bevd_0);
case 509787683: return bem_namesOSet_1(bevd_0);
case 984386046: return bem_clBaseSet_1(bevd_0);
case -1594224510: return bem_cuBaseSet_1(bevd_0);
case -2056433186: return bem_makeSrcSet_1(bevd_0);
case -1436496181: return bem_xbaseSet_1(bevd_0);
case 139244842: return bem_incBlockSet_1(bevd_0);
case -1750590752: return bem_classExeOSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1272784505: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -420380206: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187012801: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -918627939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1548633360: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 2071175645: return bem_new_5((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildClassInfo_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildClassInfo_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildClassInfo();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst = (BEC_2_5_9_BuildClassInfo) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_type;
}
}
