package be;
/* IO:File: source/extended/Serialize.be */
public final class BEC_2_6_10_SystemSerializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemSerializer() { }
private static byte[] becc_BEC_2_6_10_SystemSerializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_10_SystemSerializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_0 = {0x7C};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_1 = {0x23};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_2 = {0x26};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_3 = {0x40};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_4 = {0x3B};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_5 = {0x3F};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_6 = {0x5E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_7 = {0x23};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_8 = {0x3B};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_9 = {0x7C};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_1 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_4 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_6 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_7 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_10 = {};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemSerializer_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemSerializer_bels_10, 0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_11 = {0x70,0x6F,0x73,0x74,0x44,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_10 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_12 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_12 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_13 = (new BEC_2_4_3_MathInt(8));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_14 = (new BEC_2_4_3_MathInt(4));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_13 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_15 = (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_16 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_17 = (new BEC_2_4_3_MathInt(9));
public static BEC_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_inst;

public static BET_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_type;

public BEC_2_4_6_TextString bevp_group;
public BEC_2_4_6_TextString bevp_defineReference;
public BEC_2_4_6_TextString bevp_getReference;
public BEC_2_4_6_TextString bevp_constructString;
public BEC_2_4_6_TextString bevp_nullMark;
public BEC_2_4_6_TextString bevp_getClassTag;
public BEC_2_4_6_TextString bevp_shift;
public BEC_2_4_6_TextString bevp_defineClassTag;
public BEC_2_4_6_TextString bevp_multiNullMark;
public BEC_2_4_6_TextString bevp_endGroup;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_6_3_EncodeHex bevp_encoder;
public BEC_2_5_4_LogicBool bevp_saveIdentity;
public BEC_2_6_10_SystemSerializer bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_2));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_3));
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_5));
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_6));
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_7));
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_9));
bem_new_10(bevt_0_tmpany_phold, bevt_1_tmpany_phold, bevt_2_tmpany_phold, bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevt_6_tmpany_phold, bevt_7_tmpany_phold, bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_new_10(BEC_2_4_6_TextString beva__group, BEC_2_4_6_TextString beva__defineReference, BEC_2_4_6_TextString beva__getReference, BEC_2_4_6_TextString beva__constructString, BEC_2_4_6_TextString beva__nullMark, BEC_2_4_6_TextString beva__getClassTag, BEC_2_4_6_TextString beva__shift, BEC_2_4_6_TextString beva__defineClassTag, BEC_2_4_6_TextString beva__multiNullMark, BEC_2_4_6_TextString beva__endGroup) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevp_group = beva__group;
bevp_defineReference = beva__defineReference;
bevp_getReference = beva__getReference;
bevp_constructString = beva__constructString;
bevp_nullMark = beva__nullMark;
bevp_getClassTag = beva__getClassTag;
bevp_shift = beva__shift;
bevp_defineClassTag = beva__defineClassTag;
bevp_multiNullMark = beva__multiNullMark;
bevp_endGroup = beva__endGroup;
bevt_6_tmpany_phold = bevp_group.bem_add_1(bevp_defineReference);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevp_getReference);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevp_constructString);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevp_nullMark);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_defineClassTag);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_getClassTag);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_shift);
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_toker = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpany_phold, bevt_7_tmpany_phold);
bevp_encoder = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevp_saveIdentity = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serialize_1(BEC_2_6_6_SystemObject beva_instance) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bem_serialize_2(beva_instance, bevl_res);
return bevl_res;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serialize_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_instWriter) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_6_10_7_SystemSerializerSession bevt_1_tmpany_phold = null;
if (beva_instance == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 93 */ {
bevt_1_tmpany_phold = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_1(beva_instWriter);
bem_serializeI_2(beva_instance, bevt_1_tmpany_phold);
} /* Line: 94 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeI_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bem_defineInstance_2(beva_instance, (BEC_3_6_10_7_SystemSerializerSession) beva_session );
bevt_0_tmpany_phold = beva_instance.bemd_0(-39706070);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 100 */ {
bem_serializeC_2(beva_instance, beva_session);
} /* Line: 101 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeC_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_3_MathInt bevl_multiNull = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
bevl_instWriter = beva_session.bemd_0(-1963603048);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
bevl_iter = beva_instance.bemd_0(1480415803);
bevt_0_tmpany_phold = bevl_iter.bemd_0(-1276472965);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 109 */ {
bevl_instWriter.bemd_1(473962165, bevp_group);
while (true)
 /* Line: 111 */ {
bevt_1_tmpany_phold = bevl_iter.bemd_0(-1276472965);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 111 */ {
bevl_i = bevl_iter.bemd_0(-868741030);
if (bevl_i == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevl_multiNull = bevl_multiNull.bem_increment_0();
} /* Line: 115 */
 else  /* Line: 116 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_0;
if (bevl_multiNull.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevl_instWriter.bemd_1(473962165, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 120 */
 else  /* Line: 118 */ {
bevt_6_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_1;
if (bevl_multiNull.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevl_instWriter.bemd_1(473962165, bevp_nullMark);
bevl_instWriter.bemd_1(473962165, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 124 */
 else  /* Line: 118 */ {
bevt_8_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_2;
if (bevl_multiNull.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevl_instWriter.bemd_1(473962165, bevp_shift);
bevl_instWriter.bemd_1(473962165, bevp_nullMark);
bevt_9_tmpany_phold = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(473962165, bevt_9_tmpany_phold);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 129 */
} /* Line: 118 */
} /* Line: 118 */
if (bevp_saveIdentity.bevi_bool) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevl_instSerial = null;
} /* Line: 132 */
 else  /* Line: 133 */ {
bevt_11_tmpany_phold = beva_session.bemd_0(-315699662);
bevl_instSerial = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bemd_1(1672635146, bevl_i);
} /* Line: 134 */
if (bevl_instSerial == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 136 */ {
bem_serializeI_2(bevl_i, beva_session);
} /* Line: 138 */
 else  /* Line: 139 */ {
bevl_instWriter.bemd_1(473962165, bevp_getReference);
bevt_13_tmpany_phold = bevl_instSerial.bem_toString_0();
bevl_instWriter.bemd_1(473962165, bevt_13_tmpany_phold);
} /* Line: 142 */
} /* Line: 136 */
} /* Line: 113 */
 else  /* Line: 111 */ {
break;
} /* Line: 111 */
} /* Line: 111 */
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_3;
if (bevl_multiNull.bevi_int == bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 147 */ {
bevl_instWriter.bemd_1(473962165, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 149 */
 else  /* Line: 147 */ {
bevt_17_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_4;
if (bevl_multiNull.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevl_instWriter.bemd_1(473962165, bevp_nullMark);
bevl_instWriter.bemd_1(473962165, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 153 */
 else  /* Line: 147 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_5;
if (bevl_multiNull.bevi_int > bevt_19_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevl_instWriter.bemd_1(473962165, bevp_shift);
bevl_instWriter.bemd_1(473962165, bevp_nullMark);
bevt_20_tmpany_phold = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(473962165, bevt_20_tmpany_phold);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 158 */
} /* Line: 147 */
} /* Line: 147 */
bevl_instWriter.bemd_1(473962165, bevp_shift);
bevl_instWriter.bemd_1(473962165, bevp_group);
} /* Line: 161 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineInstance_2(BEC_2_6_6_SystemObject beva_instance, BEC_3_6_10_7_SystemSerializerSession beva_session) throws Throwable {
BEC_2_4_3_MathInt bevl_scount = null;
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_6_TextString bevl_instClass = null;
BEC_2_4_3_MathInt bevl_instClassTag = null;
BEC_2_4_6_TextString bevl_instClassTagStr = null;
BEC_2_4_6_TextString bevl_serializedString = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_11_ContainerIdentityMap bevt_13_tmpany_phold = null;
bevl_scount = beva_session.bem_serialCountGet_0();
bevt_2_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_6;
bevt_1_tmpany_phold = bevl_scount.bem_add_1(bevt_2_tmpany_phold);
beva_session.bem_serialCountSet_1(bevt_1_tmpany_phold);
bevl_instWriter = beva_session.bem_instWriterGet_0();
bevl_instClass = (BEC_2_4_6_TextString) beva_instance.bemd_0(-1022157902);
bevt_3_tmpany_phold = beva_session.bem_classTagMapGet_0();
bevl_instClassTag = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_get_1(bevl_instClass);
if (bevl_instClassTag == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevl_instClassTag = beva_session.bem_classTagCountGet_0();
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
bevt_6_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_7;
bevt_5_tmpany_phold = bevl_instClassTag.bem_add_1(bevt_6_tmpany_phold);
beva_session.bem_classTagCountSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = beva_session.bem_classTagMapGet_0();
bevt_7_tmpany_phold.bem_put_2(bevl_instClass, bevl_instClassTag);
bevl_instWriter.bemd_1(473962165, bevp_shift);
bevl_instWriter.bemd_1(473962165, bevp_defineClassTag);
bevl_instWriter.bemd_1(473962165, bevl_instClass);
bevl_instWriter.bemd_1(473962165, bevp_shift);
bevl_instWriter.bemd_1(473962165, bevp_defineClassTag);
bevl_instWriter.bemd_1(473962165, bevl_instClassTagStr);
} /* Line: 182 */
 else  /* Line: 183 */ {
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
} /* Line: 184 */
if (bevp_saveIdentity.bevi_bool) /* Line: 186 */ {
bevl_instWriter.bemd_1(473962165, bevp_defineReference);
bevt_8_tmpany_phold = bevl_scount.bem_toString_0();
bevl_instWriter.bemd_1(473962165, bevt_8_tmpany_phold);
} /* Line: 188 */
bevl_serializedString = (BEC_2_4_6_TextString) beva_instance.bemd_0(-799200084);
if (bevl_serializedString == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevt_11_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_8;
bevt_10_tmpany_phold = bevl_serializedString.bem_notEquals_1(bevt_11_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 191 */ {
bevl_instWriter.bemd_1(473962165, bevp_constructString);
bevt_12_tmpany_phold = bevp_encoder.bem_encode_1(bevl_serializedString);
bevl_instWriter.bemd_1(473962165, bevt_12_tmpany_phold);
} /* Line: 193 */
bevl_instWriter.bemd_1(473962165, bevp_getClassTag);
bevl_instWriter.bemd_1(473962165, bevl_instClassTagStr);
if (bevp_saveIdentity.bevi_bool) /* Line: 197 */ {
bevt_13_tmpany_phold = beva_session.bem_uniqueGet_0();
bevt_13_tmpany_phold.bem_put_2(beva_instance, bevl_scount);
} /* Line: 198 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserialize_1(BEC_2_6_6_SystemObject beva_instReader) throws Throwable {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_9_4_ContainerList bevl_postDeserialize = null;
BEC_3_6_10_7_SystemSerializerSession bevl_session = null;
BEC_2_9_5_ContainerStack bevl_iterStack = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_9_3_ContainerMap bevl_instances = null;
BEC_2_6_6_SystemObject bevl_rootInst = null;
BEC_2_6_6_SystemObject bevl_groupInstIter = null;
BEC_2_4_6_TextString bevl_defineClassTagName = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_token = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_4_6_TextString bevl_instString = null;
BEC_2_4_3_MathInt bevl_glassTagVal = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_4_3_MathInt bevl_defineClassTagValue = null;
BEC_2_4_3_MathInt bevl_multiNullCount = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
bevl_postDeserialize = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_session = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_0();
bevl_iterStack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_1_tmpany_phold = beva_instReader.bemd_1(1489186141, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 207 */ {
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(beva_instReader);
} /* Line: 208 */
 else  /* Line: 209 */ {
bevt_4_tmpany_phold = beva_instReader.bemd_0(-340465418);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(bevt_4_tmpany_phold);
} /* Line: 210 */
bevl_instances = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_i = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 216 */ {
bevt_5_tmpany_phold = bevl_i.bemd_0(-1276472965);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 216 */ {
bevl_token = (BEC_2_4_6_TextString) bevl_i.bemd_0(-868741030);
bevt_7_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_9;
if (bevl_state.bevi_int == bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_8_tmpany_phold = bevl_token.bem_equals_1(bevp_defineReference);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevl_state = (new BEC_2_4_3_MathInt(1));
} /* Line: 220 */
 else  /* Line: 219 */ {
bevt_9_tmpany_phold = bevl_token.bem_equals_1(bevp_constructString);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevl_state = (new BEC_2_4_3_MathInt(2));
} /* Line: 222 */
 else  /* Line: 219 */ {
bevt_10_tmpany_phold = bevl_token.bem_equals_1(bevp_getClassTag);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevl_state = (new BEC_2_4_3_MathInt(8));
} /* Line: 224 */
 else  /* Line: 219 */ {
bevt_11_tmpany_phold = bevl_token.bem_equals_1(bevp_shift);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevl_state = (new BEC_2_4_3_MathInt(1000));
} /* Line: 226 */
 else  /* Line: 219 */ {
bevt_12_tmpany_phold = bevl_token.bem_equals_1(bevp_getReference);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevl_state = (new BEC_2_4_3_MathInt(4));
} /* Line: 228 */
 else  /* Line: 219 */ {
bevt_13_tmpany_phold = bevl_token.bem_equals_1(bevp_nullMark);
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 229 */ {
if (bevl_groupInstIter == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevl_groupInstIter.bemd_1(1551212143, null);
} /* Line: 232 */
} /* Line: 231 */
 else  /* Line: 219 */ {
bevt_15_tmpany_phold = bevl_token.bem_equals_1(bevp_group);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 234 */ {
if (bevl_inst == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 236 */ {
if (bevl_groupInstIter == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevl_iterStack.bem_push_1(bevl_groupInstIter);
} /* Line: 238 */
bevl_groupInstIter = bevl_inst.bemd_0(1480415803);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_10_SystemSerializer_bels_11));
bevt_20_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_18_tmpany_phold = bevl_groupInstIter.bemd_2(-1613321201, bevt_19_tmpany_phold, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 241 */ {
bevl_postDeserialize.bem_addValue_1(bevl_groupInstIter);
} /* Line: 242 */
} /* Line: 241 */
} /* Line: 236 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
 else  /* Line: 218 */ {
bevt_22_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_10;
if (bevl_state.bevi_int == bevt_22_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevt_23_tmpany_phold = bevl_token.bem_equals_1(bevp_defineClassTag);
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 248 */ {
if (bevl_defineClassTagName == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevl_state = (new BEC_2_4_3_MathInt(6));
} /* Line: 250 */
 else  /* Line: 251 */ {
bevl_state = (new BEC_2_4_3_MathInt(7));
} /* Line: 252 */
} /* Line: 249 */
 else  /* Line: 248 */ {
bevt_25_tmpany_phold = bevl_token.bem_equals_1(bevp_multiNullMark);
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevl_state = (new BEC_2_4_3_MathInt(9));
} /* Line: 255 */
 else  /* Line: 248 */ {
bevt_26_tmpany_phold = bevl_token.bem_equals_1(bevp_group);
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 256 */ {
bevl_groupInstIter = bevl_iterStack.bem_pop_0();
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 259 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
 else  /* Line: 261 */ {
bevt_28_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_11;
if (bevl_state.bevi_int == bevt_28_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 262 */ {
if (bevp_saveIdentity.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(73, bece_BEC_2_6_10_SystemSerializer_bels_12));
bevt_30_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_31_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_30_tmpany_phold);
} /* Line: 264 */
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 267 */
 else  /* Line: 262 */ {
bevt_33_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_12;
if (bevl_state.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevl_instString = bevp_encoder.bem_decode_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 270 */
 else  /* Line: 262 */ {
bevt_35_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_13;
if (bevl_state.bevi_int == bevt_35_tmpany_phold.bevi_int) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevl_glassTagVal = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_36_tmpany_phold = bevl_session.bem_classTagMapGet_0();
bevl_klass = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_get_1(bevl_glassTagVal);
bevt_38_tmpany_phold = bem_createInstance_1(bevl_klass);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(-2131512747, bevl_instString);
bevl_inst = bevt_37_tmpany_phold.bemd_1(-1135610540, bevl_instString);
if (bevl_rootInst == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevl_rootInst = bevl_inst;
} /* Line: 276 */
if (bevp_saveIdentity.bevi_bool) /* Line: 278 */ {
bevl_instances.bem_put_2(bevl_instSerial, bevl_inst);
} /* Line: 279 */
bevl_instString = null;
if (bevl_groupInstIter == null) {
bevt_40_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 283 */ {
bevl_groupInstIter.bemd_1(1551212143, bevl_inst);
} /* Line: 284 */
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 286 */
 else  /* Line: 262 */ {
bevt_42_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_14;
if (bevl_state.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 287 */ {
if (bevp_saveIdentity.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(66, bece_BEC_2_6_10_SystemSerializer_bels_13));
bevt_44_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_45_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_44_tmpany_phold);
} /* Line: 289 */
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_inst = bevl_instances.bem_get_1(bevl_instSerial);
if (bevl_groupInstIter == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevl_groupInstIter.bemd_1(1551212143, bevl_inst);
} /* Line: 294 */
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 296 */
 else  /* Line: 262 */ {
bevt_48_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_15;
if (bevl_state.bevi_int == bevt_48_tmpany_phold.bevi_int) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevl_defineClassTagName = bevl_token;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 299 */
 else  /* Line: 262 */ {
bevt_50_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_16;
if (bevl_state.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevl_defineClassTagValue = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_51_tmpany_phold = bevl_session.bem_classTagMapGet_0();
bevt_51_tmpany_phold.bem_put_2(bevl_defineClassTagValue, bevl_defineClassTagName);
bevl_defineClassTagName = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 305 */
 else  /* Line: 262 */ {
bevt_53_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_17;
if (bevl_state.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 306 */ {
if (bevl_groupInstIter == null) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 308 */ {
bevl_multiNullCount = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_groupInstIter.bemd_1(47371806, bevl_multiNullCount);
} /* Line: 310 */
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 312 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 218 */
} /* Line: 218 */
 else  /* Line: 216 */ {
break;
} /* Line: 216 */
} /* Line: 216 */
bevl_inst = null;
bevt_0_tmpany_loop = bevl_postDeserialize.bem_iteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_55_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1276472965);
if (((BEC_2_5_4_LogicBool) bevt_55_tmpany_phold).bevi_bool) /* Line: 317 */ {
bevl_groupInstIter = bevt_0_tmpany_loop.bemd_0(-868741030);
bevl_groupInstIter.bemd_0(-1926844033);
} /* Line: 318 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
return bevl_rootInst;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGet_0() throws Throwable {
return bevp_group;
} /*method end*/
public final BEC_2_4_6_TextString bem_groupGetDirect_0() throws Throwable {
return bevp_group;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_group = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_groupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_group = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGet_0() throws Throwable {
return bevp_defineReference;
} /*method end*/
public final BEC_2_4_6_TextString bem_defineReferenceGetDirect_0() throws Throwable {
return bevp_defineReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_defineReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGet_0() throws Throwable {
return bevp_getReference;
} /*method end*/
public final BEC_2_4_6_TextString bem_getReferenceGetDirect_0() throws Throwable {
return bevp_getReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_getReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGet_0() throws Throwable {
return bevp_constructString;
} /*method end*/
public final BEC_2_4_6_TextString bem_constructStringGetDirect_0() throws Throwable {
return bevp_constructString;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_constructStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGet_0() throws Throwable {
return bevp_nullMark;
} /*method end*/
public final BEC_2_4_6_TextString bem_nullMarkGetDirect_0() throws Throwable {
return bevp_nullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_nullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGet_0() throws Throwable {
return bevp_getClassTag;
} /*method end*/
public final BEC_2_4_6_TextString bem_getClassTagGetDirect_0() throws Throwable {
return bevp_getClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_getClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGet_0() throws Throwable {
return bevp_shift;
} /*method end*/
public final BEC_2_4_6_TextString bem_shiftGetDirect_0() throws Throwable {
return bevp_shift;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_shiftSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGet_0() throws Throwable {
return bevp_defineClassTag;
} /*method end*/
public final BEC_2_4_6_TextString bem_defineClassTagGetDirect_0() throws Throwable {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_defineClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGet_0() throws Throwable {
return bevp_multiNullMark;
} /*method end*/
public final BEC_2_4_6_TextString bem_multiNullMarkGetDirect_0() throws Throwable {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_multiNullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGet_0() throws Throwable {
return bevp_endGroup;
} /*method end*/
public final BEC_2_4_6_TextString bem_endGroupGetDirect_0() throws Throwable {
return bevp_endGroup;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_endGroupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() throws Throwable {
return bevp_toker;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() throws Throwable {
return bevp_toker;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGet_0() throws Throwable {
return bevp_encoder;
} /*method end*/
public final BEC_2_6_3_EncodeHex bem_encoderGetDirect_0() throws Throwable {
return bevp_encoder;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_encoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGet_0() throws Throwable {
return bevp_saveIdentity;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveIdentityGetDirect_0() throws Throwable {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_saveIdentitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 78, 78, 78, 78, 78, 78, 78, 79, 77, 81, 82, 87, 88, 89, 93, 93, 94, 94, 99, 100, 101, 106, 107, 108, 109, 110, 111, 112, 113, 113, 115, 118, 118, 118, 119, 120, 121, 121, 121, 122, 123, 124, 125, 125, 125, 126, 127, 128, 128, 129, 131, 131, 132, 134, 134, 136, 136, 138, 141, 142, 142, 147, 147, 147, 148, 149, 150, 150, 150, 151, 152, 153, 154, 154, 154, 155, 156, 157, 157, 158, 160, 161, 166, 167, 167, 167, 169, 170, 171, 171, 172, 172, 173, 174, 175, 175, 175, 176, 176, 177, 178, 179, 180, 181, 182, 184, 187, 188, 188, 190, 191, 191, 191, 191, 0, 0, 0, 192, 193, 193, 195, 196, 198, 198, 203, 204, 205, 206, 207, 207, 207, 208, 210, 210, 212, 216, 216, 217, 218, 218, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 231, 231, 232, 234, 236, 236, 237, 237, 238, 240, 241, 241, 241, 242, 246, 246, 246, 248, 249, 249, 250, 252, 254, 255, 256, 258, 259, 262, 262, 262, 263, 263, 264, 264, 264, 266, 267, 268, 268, 268, 269, 270, 271, 271, 271, 272, 273, 273, 274, 274, 274, 275, 275, 276, 279, 281, 283, 283, 284, 286, 287, 287, 287, 288, 288, 289, 289, 289, 291, 292, 293, 293, 294, 296, 297, 297, 297, 298, 299, 300, 300, 300, 302, 303, 303, 304, 305, 306, 306, 306, 308, 308, 309, 310, 312, 316, 317, 0, 317, 317, 318, 320, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 114, 115, 116, 121, 126, 127, 128, 134, 135, 137, 168, 169, 170, 171, 173, 176, 178, 179, 184, 185, 188, 189, 194, 195, 196, 199, 200, 205, 206, 207, 208, 211, 212, 217, 218, 219, 220, 221, 222, 226, 231, 232, 235, 236, 238, 243, 244, 247, 248, 249, 257, 258, 263, 264, 265, 268, 269, 274, 275, 276, 277, 280, 281, 286, 287, 288, 289, 290, 291, 295, 296, 321, 322, 323, 324, 325, 326, 327, 328, 329, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 350, 353, 354, 355, 357, 358, 363, 364, 365, 367, 370, 374, 377, 378, 379, 381, 382, 384, 385, 464, 465, 466, 467, 468, 469, 470, 472, 475, 476, 478, 479, 482, 484, 485, 486, 491, 492, 494, 497, 499, 502, 504, 507, 509, 512, 514, 517, 519, 524, 525, 529, 531, 536, 537, 542, 543, 545, 546, 547, 548, 550, 562, 563, 568, 569, 571, 576, 577, 580, 584, 586, 589, 591, 592, 598, 599, 604, 605, 610, 611, 612, 613, 615, 616, 619, 620, 625, 626, 627, 630, 631, 636, 637, 638, 639, 640, 641, 642, 643, 648, 649, 652, 654, 655, 660, 661, 663, 666, 667, 672, 673, 678, 679, 680, 681, 683, 684, 685, 690, 691, 693, 696, 697, 702, 703, 704, 707, 708, 713, 714, 715, 716, 717, 718, 721, 722, 727, 728, 733, 734, 735, 737, 752, 753, 753, 756, 758, 759, 765, 768, 771, 774, 778, 782, 785, 788, 792, 796, 799, 802, 806, 810, 813, 816, 820, 824, 827, 830, 834, 838, 841, 844, 848, 852, 855, 858, 862, 866, 869, 872, 876, 880, 883, 886, 890, 894, 897, 900, 904, 908, 911, 914, 918, 922, 925, 928, 932, 936, 939, 942, 946};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 61 67
new 0 61 67
assign 1 61 68
new 0 61 68
assign 1 61 69
new 0 61 69
assign 1 61 70
new 0 61 70
assign 1 61 71
new 0 61 71
assign 1 61 72
new 0 61 72
assign 1 61 73
new 0 61 73
assign 1 61 74
new 0 61 74
assign 1 61 75
new 0 61 75
assign 1 61 76
new 0 61 76
new 10 61 77
assign 1 67 89
assign 1 68 90
assign 1 69 91
assign 1 70 92
assign 1 71 93
assign 1 72 94
assign 1 73 95
assign 1 74 96
assign 1 75 97
assign 1 76 98
assign 1 78 99
add 1 78 99
assign 1 78 100
add 1 78 100
assign 1 78 101
add 1 78 101
assign 1 78 102
add 1 78 102
assign 1 78 103
add 1 78 103
assign 1 78 104
add 1 78 104
assign 1 78 105
add 1 78 105
assign 1 79 106
new 0 79 106
assign 1 77 107
new 2 77 107
assign 1 81 108
new 0 81 108
assign 1 82 109
new 0 82 109
assign 1 87 114
new 0 87 114
serialize 2 88 115
return 1 89 116
assign 1 93 121
def 1 93 126
assign 1 94 127
new 1 94 127
serializeI 2 94 128
defineInstance 2 99 134
assign 1 100 135
serializeContents 0 100 135
serializeC 2 101 137
assign 1 106 168
instWriterGet 0 106 168
assign 1 107 169
new 0 107 169
assign 1 108 170
serializationIteratorGet 0 108 170
assign 1 109 171
hasNextGet 0 109 171
write 1 110 173
assign 1 111 176
hasNextGet 0 111 176
assign 1 112 178
nextGet 0 112 178
assign 1 113 179
undef 1 113 184
assign 1 115 185
increment 0 115 185
assign 1 118 188
new 0 118 188
assign 1 118 189
equals 1 118 194
write 1 119 195
assign 1 120 196
new 0 120 196
assign 1 121 199
new 0 121 199
assign 1 121 200
equals 1 121 205
write 1 122 206
write 1 123 207
assign 1 124 208
new 0 124 208
assign 1 125 211
new 0 125 211
assign 1 125 212
greater 1 125 217
write 1 126 218
write 1 127 219
assign 1 128 220
toString 0 128 220
write 1 128 221
assign 1 129 222
new 0 129 222
assign 1 131 226
not 0 131 231
assign 1 132 232
assign 1 134 235
uniqueGet 0 134 235
assign 1 134 236
get 1 134 236
assign 1 136 238
undef 1 136 243
serializeI 2 138 244
write 1 141 247
assign 1 142 248
toString 0 142 248
write 1 142 249
assign 1 147 257
new 0 147 257
assign 1 147 258
equals 1 147 263
write 1 148 264
assign 1 149 265
new 0 149 265
assign 1 150 268
new 0 150 268
assign 1 150 269
equals 1 150 274
write 1 151 275
write 1 152 276
assign 1 153 277
new 0 153 277
assign 1 154 280
new 0 154 280
assign 1 154 281
greater 1 154 286
write 1 155 287
write 1 156 288
assign 1 157 289
toString 0 157 289
write 1 157 290
assign 1 158 291
new 0 158 291
write 1 160 295
write 1 161 296
assign 1 166 321
serialCountGet 0 166 321
assign 1 167 322
new 0 167 322
assign 1 167 323
add 1 167 323
serialCountSet 1 167 324
assign 1 169 325
instWriterGet 0 169 325
assign 1 170 326
deserializeClassNameGet 0 170 326
assign 1 171 327
classTagMapGet 0 171 327
assign 1 171 328
get 1 171 328
assign 1 172 329
undef 1 172 334
assign 1 173 335
classTagCountGet 0 173 335
assign 1 174 336
toString 0 174 336
assign 1 175 337
new 0 175 337
assign 1 175 338
add 1 175 338
classTagCountSet 1 175 339
assign 1 176 340
classTagMapGet 0 176 340
put 2 176 341
write 1 177 342
write 1 178 343
write 1 179 344
write 1 180 345
write 1 181 346
write 1 182 347
assign 1 184 350
toString 0 184 350
write 1 187 353
assign 1 188 354
toString 0 188 354
write 1 188 355
assign 1 190 357
serializeToString 0 190 357
assign 1 191 358
def 1 191 363
assign 1 191 364
new 0 191 364
assign 1 191 365
notEquals 1 191 365
assign 1 0 367
assign 1 0 370
assign 1 0 374
write 1 192 377
assign 1 193 378
encode 1 193 378
write 1 193 379
write 1 195 381
write 1 196 382
assign 1 198 384
uniqueGet 0 198 384
put 2 198 385
assign 1 203 464
new 0 203 464
assign 1 204 465
new 0 204 465
assign 1 205 466
new 0 205 466
assign 1 206 467
new 0 206 467
assign 1 207 468
new 0 207 468
assign 1 207 469
emptyGet 0 207 469
assign 1 207 470
sameType 1 207 470
assign 1 208 472
tokenize 1 208 472
assign 1 210 475
readString 0 210 475
assign 1 210 476
tokenize 1 210 476
assign 1 212 478
new 0 212 478
assign 1 216 479
linkedListIteratorGet 0 216 479
assign 1 216 482
hasNextGet 0 216 482
assign 1 217 484
nextGet 0 217 484
assign 1 218 485
new 0 218 485
assign 1 218 486
equals 1 218 491
assign 1 219 492
equals 1 219 492
assign 1 220 494
new 0 220 494
assign 1 221 497
equals 1 221 497
assign 1 222 499
new 0 222 499
assign 1 223 502
equals 1 223 502
assign 1 224 504
new 0 224 504
assign 1 225 507
equals 1 225 507
assign 1 226 509
new 0 226 509
assign 1 227 512
equals 1 227 512
assign 1 228 514
new 0 228 514
assign 1 229 517
equals 1 229 517
assign 1 231 519
def 1 231 524
nextSet 1 232 525
assign 1 234 529
equals 1 234 529
assign 1 236 531
def 1 236 536
assign 1 237 537
def 1 237 542
push 1 238 543
assign 1 240 545
serializationIteratorGet 0 240 545
assign 1 241 546
new 0 241 546
assign 1 241 547
new 0 241 547
assign 1 241 548
can 2 241 548
addValue 1 242 550
assign 1 246 562
new 0 246 562
assign 1 246 563
equals 1 246 568
assign 1 248 569
equals 1 248 569
assign 1 249 571
undef 1 249 576
assign 1 250 577
new 0 250 577
assign 1 252 580
new 0 252 580
assign 1 254 584
equals 1 254 584
assign 1 255 586
new 0 255 586
assign 1 256 589
equals 1 256 589
assign 1 258 591
pop 0 258 591
assign 1 259 592
new 0 259 592
assign 1 262 598
new 0 262 598
assign 1 262 599
equals 1 262 604
assign 1 263 605
not 0 263 610
assign 1 264 611
new 0 264 611
assign 1 264 612
new 1 264 612
throw 1 264 613
assign 1 266 615
new 1 266 615
assign 1 267 616
new 0 267 616
assign 1 268 619
new 0 268 619
assign 1 268 620
equals 1 268 625
assign 1 269 626
decode 1 269 626
assign 1 270 627
new 0 270 627
assign 1 271 630
new 0 271 630
assign 1 271 631
equals 1 271 636
assign 1 272 637
new 1 272 637
assign 1 273 638
classTagMapGet 0 273 638
assign 1 273 639
get 1 273 639
assign 1 274 640
createInstance 1 274 640
assign 1 274 641
deserializeFromStringNew 1 274 641
assign 1 274 642
deserializeFromString 1 274 642
assign 1 275 643
undef 1 275 648
assign 1 276 649
put 2 279 652
assign 1 281 654
assign 1 283 655
def 1 283 660
nextSet 1 284 661
assign 1 286 663
new 0 286 663
assign 1 287 666
new 0 287 666
assign 1 287 667
equals 1 287 672
assign 1 288 673
not 0 288 678
assign 1 289 679
new 0 289 679
assign 1 289 680
new 1 289 680
throw 1 289 681
assign 1 291 683
new 1 291 683
assign 1 292 684
get 1 292 684
assign 1 293 685
def 1 293 690
nextSet 1 294 691
assign 1 296 693
new 0 296 693
assign 1 297 696
new 0 297 696
assign 1 297 697
equals 1 297 702
assign 1 298 703
assign 1 299 704
new 0 299 704
assign 1 300 707
new 0 300 707
assign 1 300 708
equals 1 300 713
assign 1 302 714
new 1 302 714
assign 1 303 715
classTagMapGet 0 303 715
put 2 303 716
assign 1 304 717
assign 1 305 718
new 0 305 718
assign 1 306 721
new 0 306 721
assign 1 306 722
equals 1 306 727
assign 1 308 728
def 1 308 733
assign 1 309 734
new 1 309 734
skip 1 310 735
assign 1 312 737
new 0 312 737
assign 1 316 752
assign 1 317 753
iteratorGet 0 0 753
assign 1 317 756
hasNextGet 0 317 756
assign 1 317 758
nextGet 0 317 758
postDeserialize 0 318 759
return 1 320 765
return 1 0 768
return 1 0 771
assign 1 0 774
assign 1 0 778
return 1 0 782
return 1 0 785
assign 1 0 788
assign 1 0 792
return 1 0 796
return 1 0 799
assign 1 0 802
assign 1 0 806
return 1 0 810
return 1 0 813
assign 1 0 816
assign 1 0 820
return 1 0 824
return 1 0 827
assign 1 0 830
assign 1 0 834
return 1 0 838
return 1 0 841
assign 1 0 844
assign 1 0 848
return 1 0 852
return 1 0 855
assign 1 0 858
assign 1 0 862
return 1 0 866
return 1 0 869
assign 1 0 872
assign 1 0 876
return 1 0 880
return 1 0 883
assign 1 0 886
assign 1 0 890
return 1 0 894
return 1 0 897
assign 1 0 900
assign 1 0 904
return 1 0 908
return 1 0 911
assign 1 0 914
assign 1 0 918
return 1 0 922
return 1 0 925
assign 1 0 928
assign 1 0 932
return 1 0 936
return 1 0 939
assign 1 0 942
assign 1 0 946
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2061412556: return bem_classNameGet_0();
case -1323618582: return bem_constructStringGet_0();
case 1150507973: return bem_getReferenceGet_0();
case -1666341494: return bem_multiNullMarkGetDirect_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case -455888867: return bem_nullMarkGetDirect_0();
case 605755759: return bem_fieldNamesGet_0();
case -39706070: return bem_serializeContents_0();
case 2069196027: return bem_print_0();
case 849688750: return bem_shiftGet_0();
case 1359777543: return bem_toAny_0();
case 874968344: return bem_once_0();
case 344752250: return bem_hashGet_0();
case 149212592: return bem_defineReferenceGetDirect_0();
case -16750630: return bem_encoderGet_0();
case 27033645: return bem_sourceFileNameGet_0();
case -1633245548: return bem_groupGetDirect_0();
case 502031978: return bem_iteratorGet_0();
case -805426240: return bem_tokerGetDirect_0();
case 1480415803: return bem_serializationIteratorGet_0();
case 786353871: return bem_getClassTagGetDirect_0();
case -899226258: return bem_endGroupGet_0();
case -239141020: return bem_getClassTagGet_0();
case 325964466: return bem_echo_0();
case -1061273638: return bem_tokerGet_0();
case -614352731: return bem_defineClassTagGetDirect_0();
case 1413528627: return bem_encoderGetDirect_0();
case -1639350481: return bem_groupGet_0();
case 1965613314: return bem_tagGet_0();
case 624242351: return bem_getReferenceGetDirect_0();
case 1946011835: return bem_defineClassTagGet_0();
case 1578098134: return bem_toString_0();
case -577364193: return bem_saveIdentityGet_0();
case 26417469: return bem_create_0();
case 962099177: return bem_fieldIteratorGet_0();
case -1878305271: return bem_many_0();
case -474703894: return bem_endGroupGetDirect_0();
case 211122080: return bem_defineReferenceGet_0();
case 334767424: return bem_copy_0();
case 1525057702: return bem_multiNullMarkGet_0();
case 861308708: return bem_constructStringGetDirect_0();
case 1782020704: return bem_saveIdentityGetDirect_0();
case 2132890711: return bem_new_0();
case 724710665: return bem_nullMarkGet_0();
case 1865393191: return bem_shiftGetDirect_0();
case -799200084: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 775850737: return bem_getReferenceSetDirect_1(bevd_0);
case 1911281908: return bem_endGroupSet_1(bevd_0);
case 52647327: return bem_def_1(bevd_0);
case -729198990: return bem_encoderSet_1(bevd_0);
case 1536214211: return bem_saveIdentitySet_1(bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case 1375601158: return bem_defineClassTagSetDirect_1(bevd_0);
case -2127688775: return bem_serialize_1(bevd_0);
case 315974238: return bem_deserialize_1(bevd_0);
case -2043903245: return bem_endGroupSetDirect_1(bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case -1149676360: return bem_getClassTagSet_1(bevd_0);
case 174292001: return bem_groupSet_1(bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case -479568596: return bem_tokerSet_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -490072048: return bem_saveIdentitySetDirect_1(bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -631512295: return bem_nullMarkSet_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 40992705: return bem_multiNullMarkSet_1(bevd_0);
case 29095996: return bem_shiftSetDirect_1(bevd_0);
case 1466174775: return bem_multiNullMarkSetDirect_1(bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -403978438: return bem_defineClassTagSet_1(bevd_0);
case 1651750459: return bem_nullMarkSetDirect_1(bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1911909058: return bem_constructStringSetDirect_1(bevd_0);
case 133333579: return bem_getReferenceSet_1(bevd_0);
case -921275187: return bem_getClassTagSetDirect_1(bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case 830578512: return bem_constructStringSet_1(bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case -1587051313: return bem_encoderSetDirect_1(bevd_0);
case 116490518: return bem_groupSetDirect_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case -388648894: return bem_defineReferenceSet_1(bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
case 1763022947: return bem_defineReferenceSetDirect_1(bevd_0);
case 2111487542: return bem_shiftSet_1(bevd_0);
case -685388542: return bem_tokerSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1470026642: return bem_serializeC_2(bevd_0, bevd_1);
case -586875555: return bem_defineInstance_2(bevd_0, (BEC_3_6_10_7_SystemSerializerSession) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -49112415: return bem_serialize_2(bevd_0, bevd_1);
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1000269112: return bem_serializeI_2(bevd_0, bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_x(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5, BEC_2_6_6_SystemObject bevd_6, BEC_2_6_6_SystemObject[] bevd_x) throws Throwable {
switch (callId) {
case -1845036246: return bem_new_10((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4, (BEC_2_4_6_TextString) bevd_5, (BEC_2_4_6_TextString) bevd_6, (BEC_2_4_6_TextString) bevd_x[0], (BEC_2_4_6_TextString) bevd_x[1], (BEC_2_4_6_TextString) bevd_x[2]);
}
return super.bemd_x(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5, bevd_6, bevd_x);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemSerializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_10_SystemSerializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemSerializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst = (BEC_2_6_10_SystemSerializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_type;
}
}
