package be;
/* IO:File: source/extended/Serialize.be */
public final class BEC_2_6_10_SystemSerializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemSerializer() { }
private static byte[] becc_BEC_2_6_10_SystemSerializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_10_SystemSerializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_0 = {0x7C};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_1 = {0x23};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_2 = {0x26};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_3 = {0x40};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_4 = {0x3B};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_5 = {0x3F};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_6 = {0x5E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_7 = {0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x43,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x73,0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_8 = {0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_9 = {0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65,0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_10 = {0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x54,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_11 = {};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_12 = {0x70,0x6F,0x73,0x74,0x44,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_13 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_14 = {0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x46,0x72,0x6F,0x6D,0x53,0x74,0x72,0x69,0x6E,0x67,0x4E,0x65,0x77};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_15 = {0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x46,0x72,0x6F,0x6D,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
public static BEC_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_inst;

public static BET_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_type;

public BEC_2_4_6_TextString bevp_group;
public BEC_2_4_6_TextString bevp_defineReference;
public BEC_2_4_6_TextString bevp_getReference;
public BEC_2_4_6_TextString bevp_constructString;
public BEC_2_4_6_TextString bevp_nullMark;
public BEC_2_4_6_TextString bevp_getClassTag;
public BEC_2_4_6_TextString bevp_shift;
public BEC_2_4_6_TextString bevp_defineClassTag;
public BEC_2_4_6_TextString bevp_multiNullMark;
public BEC_2_4_6_TextString bevp_endGroup;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_6_3_EncodeHex bevp_encoder;
public BEC_2_5_4_LogicBool bevp_saveIdentity;
public BEC_2_6_10_SystemSerializer bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_2));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_3));
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_5));
bevt_6_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_6));
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bem_new_10(bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph, bevt_6_ta_ph, bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_new_10(BEC_2_4_6_TextString beva__group, BEC_2_4_6_TextString beva__defineReference, BEC_2_4_6_TextString beva__getReference, BEC_2_4_6_TextString beva__constructString, BEC_2_4_6_TextString beva__nullMark, BEC_2_4_6_TextString beva__getClassTag, BEC_2_4_6_TextString beva__shift, BEC_2_4_6_TextString beva__defineClassTag, BEC_2_4_6_TextString beva__multiNullMark, BEC_2_4_6_TextString beva__endGroup) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevp_group = beva__group;
bevp_defineReference = beva__defineReference;
bevp_getReference = beva__getReference;
bevp_constructString = beva__constructString;
bevp_nullMark = beva__nullMark;
bevp_getClassTag = beva__getClassTag;
bevp_shift = beva__shift;
bevp_defineClassTag = beva__defineClassTag;
bevp_multiNullMark = beva__multiNullMark;
bevp_endGroup = beva__endGroup;
bevt_6_ta_ph = bevp_group.bem_add_1(bevp_defineReference);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_getReference);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_constructString);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevp_nullMark);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_defineClassTag);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_getClassTag);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_shift);
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
bevp_toker = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_7_ta_ph);
bevp_encoder = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevp_saveIdentity = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serialize_1(BEC_2_6_6_SystemObject beva_instance) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bem_serialize_2(beva_instance, bevl_res);
return bevl_res;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serialize_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_instWriter) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_6_10_7_SystemSerializerSession bevt_1_ta_ph = null;
if (beva_instance == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 91*/ {
bevt_1_ta_ph = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_1(beva_instWriter);
bem_serializeI_2(beva_instance, bevt_1_ta_ph);
} /* Line: 92*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeI_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_5_4_LogicBool bevl_dosc = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bem_defineInstance_2(beva_instance, (BEC_3_6_10_7_SystemSerializerSession) beva_session );
bevt_1_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_6_10_SystemSerializer_bels_7));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = beva_instance.bemd_2(-1813958638, bevt_1_ta_ph, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 98*/ {
bevl_dosc = (BEC_2_5_4_LogicBool) beva_instance.bemd_0(-714916851);
} /* Line: 99*/
 else /* Line: 100*/ {
bevl_dosc = be.BECS_Runtime.boolTrue;
} /* Line: 101*/
if (bevl_dosc.bevi_bool)/* Line: 103*/ {
bem_serializeC_2(beva_instance, beva_session);
} /* Line: 104*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeC_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_3_MathInt bevl_multiNull = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevl_instWriter = beva_session.bemd_0(578587303);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = beva_instance.bemd_2(-1813958638, bevt_1_ta_ph, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 111*/ {
bevl_iter = beva_instance.bemd_0(1346975792);
} /* Line: 112*/
 else /* Line: 113*/ {
bevl_iter = beva_instance.bemd_0(30862756);
} /* Line: 114*/
bevt_3_ta_ph = bevl_iter.bemd_0(86655816);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 116*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_group);
while (true)
/* Line: 118*/ {
bevt_4_ta_ph = bevl_iter.bemd_0(86655816);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 118*/ {
bevl_i = bevl_iter.bemd_0(1034270849);
if (bevl_i == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 120*/ {
bevl_multiNull = bevl_multiNull.bem_increment_0();
} /* Line: 122*/
 else /* Line: 123*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_multiNull.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 125*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 127*/
 else /* Line: 125*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int == bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 128*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_nullMark);
bevl_instWriter.bemd_1(-1450558357, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 131*/
 else /* Line: 125*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 132*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_shift);
bevl_instWriter.bemd_1(-1450558357, bevp_nullMark);
bevt_12_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(-1450558357, bevt_12_ta_ph);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 136*/
} /* Line: 125*/
} /* Line: 125*/
if (bevp_saveIdentity.bevi_bool) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 138*/ {
bevl_instSerial = null;
} /* Line: 139*/
 else /* Line: 140*/ {
bevt_14_ta_ph = beva_session.bemd_0(2091585209);
bevl_instSerial = (BEC_2_4_3_MathInt) bevt_14_ta_ph.bemd_1(1950249653, bevl_i);
} /* Line: 141*/
if (bevl_instSerial == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 143*/ {
bem_serializeI_2(bevl_i, beva_session);
} /* Line: 145*/
 else /* Line: 146*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_getReference);
bevt_16_ta_ph = bevl_instSerial.bem_toString_0();
bevl_instWriter.bemd_1(-1450558357, bevt_16_ta_ph);
} /* Line: 149*/
} /* Line: 143*/
} /* Line: 120*/
 else /* Line: 118*/ {
break;
} /* Line: 118*/
} /* Line: 118*/
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_multiNull.bevi_int == bevt_18_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 154*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 156*/
 else /* Line: 154*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 157*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_nullMark);
bevl_instWriter.bemd_1(-1450558357, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 160*/
 else /* Line: 154*/ {
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int > bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 161*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_shift);
bevl_instWriter.bemd_1(-1450558357, bevp_nullMark);
bevt_23_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(-1450558357, bevt_23_ta_ph);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 165*/
} /* Line: 154*/
} /* Line: 154*/
bevl_instWriter.bemd_1(-1450558357, bevp_shift);
bevl_instWriter.bemd_1(-1450558357, bevp_group);
} /* Line: 168*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineInstance_2(BEC_2_6_6_SystemObject beva_instance, BEC_3_6_10_7_SystemSerializerSession beva_session) throws Throwable {
BEC_2_4_3_MathInt bevl_scount = null;
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_6_TextString bevl_instClass = null;
BEC_2_4_3_MathInt bevl_instClassTag = null;
BEC_2_4_6_TextString bevl_instClassTagStr = null;
BEC_2_4_6_TextString bevl_serializedString = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_6_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_9_11_ContainerIdentityMap bevt_20_ta_ph = null;
bevl_scount = beva_session.bem_serialCountGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevl_scount.bem_add_1(bevt_2_ta_ph);
beva_session.bem_serialCountSet_1(bevt_1_ta_ph);
bevl_instWriter = beva_session.bem_instWriterGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_10_SystemSerializer_bels_9));
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = beva_instance.bemd_2(-1813958638, bevt_4_ta_ph, bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 177*/ {
bevl_instClass = (BEC_2_4_6_TextString) beva_instance.bemd_0(-935899126);
} /* Line: 178*/
 else /* Line: 179*/ {
bevt_6_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_instClass = bevt_6_ta_ph.bem_className_1(beva_instance);
} /* Line: 180*/
bevt_7_ta_ph = beva_session.bem_classTagMapGet_0();
bevl_instClassTag = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bem_get_1(bevl_instClass);
if (bevl_instClassTag == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 183*/ {
bevl_instClassTag = beva_session.bem_classTagCountGet_0();
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_9_ta_ph = bevl_instClassTag.bem_add_1(bevt_10_ta_ph);
beva_session.bem_classTagCountSet_1(bevt_9_ta_ph);
bevt_11_ta_ph = beva_session.bem_classTagMapGet_0();
bevt_11_ta_ph.bem_put_2(bevl_instClass, bevl_instClassTag);
bevl_instWriter.bemd_1(-1450558357, bevp_shift);
bevl_instWriter.bemd_1(-1450558357, bevp_defineClassTag);
bevl_instWriter.bemd_1(-1450558357, bevl_instClass);
bevl_instWriter.bemd_1(-1450558357, bevp_shift);
bevl_instWriter.bemd_1(-1450558357, bevp_defineClassTag);
bevl_instWriter.bemd_1(-1450558357, bevl_instClassTagStr);
} /* Line: 193*/
 else /* Line: 194*/ {
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
} /* Line: 195*/
if (bevp_saveIdentity.bevi_bool)/* Line: 197*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_defineReference);
bevt_12_ta_ph = bevl_scount.bem_toString_0();
bevl_instWriter.bemd_1(-1450558357, bevt_12_ta_ph);
} /* Line: 199*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_6_10_SystemSerializer_bels_10));
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_13_ta_ph = beva_instance.bemd_2(-1813958638, bevt_14_ta_ph, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 202*/ {
bevl_serializedString = (BEC_2_4_6_TextString) beva_instance.bemd_0(-1551605768);
} /* Line: 203*/
 else /* Line: 204*/ {
bevl_serializedString = null;
} /* Line: 205*/
if (bevl_serializedString == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 207*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_6_10_SystemSerializer_bels_11));
bevt_17_ta_ph = bevl_serializedString.bem_notEquals_1(bevt_18_ta_ph);
if (bevt_17_ta_ph.bevi_bool)/* Line: 207*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 207*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 207*/
 else /* Line: 207*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 207*/ {
bevl_instWriter.bemd_1(-1450558357, bevp_constructString);
bevt_19_ta_ph = bevp_encoder.bem_encode_1(bevl_serializedString);
bevl_instWriter.bemd_1(-1450558357, bevt_19_ta_ph);
} /* Line: 209*/
bevl_instWriter.bemd_1(-1450558357, bevp_getClassTag);
bevl_instWriter.bemd_1(-1450558357, bevl_instClassTagStr);
if (bevp_saveIdentity.bevi_bool)/* Line: 213*/ {
bevt_20_ta_ph = beva_session.bem_uniqueGet_0();
bevt_20_ta_ph.bem_put_2(beva_instance, bevl_scount);
} /* Line: 214*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserialize_1(BEC_2_6_6_SystemObject beva_instReader) throws Throwable {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_9_4_ContainerList bevl_postDeserialize = null;
BEC_3_6_10_7_SystemSerializerSession bevl_session = null;
BEC_2_9_5_ContainerStack bevl_iterStack = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_9_3_ContainerMap bevl_instances = null;
BEC_2_6_6_SystemObject bevl_rootInst = null;
BEC_2_6_6_SystemObject bevl_groupInstIter = null;
BEC_2_4_6_TextString bevl_defineClassTagName = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_token = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_4_6_TextString bevl_instString = null;
BEC_2_4_3_MathInt bevl_glassTagVal = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_4_3_MathInt bevl_defineClassTagValue = null;
BEC_2_4_3_MathInt bevl_multiNullCount = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_7_TextStrings bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_6_9_SystemException bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_40_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_6_9_SystemException bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_5_4_LogicBool bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
bevl_postDeserialize = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_session = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_0();
bevl_iterStack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevt_2_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_4_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_3_ta_ph = bevt_4_ta_ph.bem_emptyGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_sameType_2(beva_instReader, bevt_3_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 223*/ {
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(beva_instReader);
} /* Line: 224*/
 else /* Line: 225*/ {
bevt_5_ta_ph = beva_instReader.bemd_0(957210142);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(bevt_5_ta_ph);
} /* Line: 226*/
bevl_instances = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_i = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 232*/ {
bevt_6_ta_ph = bevl_i.bemd_0(86655816);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 232*/ {
bevl_token = (BEC_2_4_6_TextString) bevl_i.bemd_0(1034270849);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_state.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_9_ta_ph = bevl_token.bem_equals_1(bevp_defineReference);
if (bevt_9_ta_ph.bevi_bool)/* Line: 235*/ {
bevl_state = (new BEC_2_4_3_MathInt(1));
} /* Line: 236*/
 else /* Line: 235*/ {
bevt_10_ta_ph = bevl_token.bem_equals_1(bevp_constructString);
if (bevt_10_ta_ph.bevi_bool)/* Line: 237*/ {
bevl_state = (new BEC_2_4_3_MathInt(2));
} /* Line: 238*/
 else /* Line: 235*/ {
bevt_11_ta_ph = bevl_token.bem_equals_1(bevp_getClassTag);
if (bevt_11_ta_ph.bevi_bool)/* Line: 239*/ {
bevl_state = (new BEC_2_4_3_MathInt(8));
} /* Line: 240*/
 else /* Line: 235*/ {
bevt_12_ta_ph = bevl_token.bem_equals_1(bevp_shift);
if (bevt_12_ta_ph.bevi_bool)/* Line: 241*/ {
bevl_state = (new BEC_2_4_3_MathInt(1000));
} /* Line: 242*/
 else /* Line: 235*/ {
bevt_13_ta_ph = bevl_token.bem_equals_1(bevp_getReference);
if (bevt_13_ta_ph.bevi_bool)/* Line: 243*/ {
bevl_state = (new BEC_2_4_3_MathInt(4));
} /* Line: 244*/
 else /* Line: 235*/ {
bevt_14_ta_ph = bevl_token.bem_equals_1(bevp_nullMark);
if (bevt_14_ta_ph.bevi_bool)/* Line: 245*/ {
if (bevl_groupInstIter == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 247*/ {
bevl_groupInstIter.bemd_1(244271027, null);
} /* Line: 248*/
} /* Line: 247*/
 else /* Line: 235*/ {
bevt_16_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_16_ta_ph.bevi_bool)/* Line: 250*/ {
if (bevl_inst == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 252*/ {
if (bevl_groupInstIter == null) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 253*/ {
bevl_iterStack.bem_push_1(bevl_groupInstIter);
} /* Line: 254*/
bevt_20_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_19_ta_ph = bevl_inst.bemd_2(-1813958638, bevt_20_ta_ph, bevt_21_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_19_ta_ph).bevi_bool)/* Line: 256*/ {
bevl_groupInstIter = bevl_inst.bemd_0(1346975792);
} /* Line: 257*/
 else /* Line: 258*/ {
bevl_groupInstIter = bevl_inst.bemd_0(30862756);
} /* Line: 259*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_10_SystemSerializer_bels_12));
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_22_ta_ph = bevl_groupInstIter.bemd_2(-1813958638, bevt_23_ta_ph, bevt_24_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_22_ta_ph).bevi_bool)/* Line: 261*/ {
bevl_postDeserialize.bem_addValue_1(bevl_groupInstIter);
} /* Line: 262*/
} /* Line: 261*/
} /* Line: 252*/
} /* Line: 235*/
} /* Line: 235*/
} /* Line: 235*/
} /* Line: 235*/
} /* Line: 235*/
} /* Line: 235*/
} /* Line: 235*/
 else /* Line: 234*/ {
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(1000));
if (bevl_state.bevi_int == bevt_26_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 266*/ {
bevt_27_ta_ph = bevl_token.bem_equals_1(bevp_defineClassTag);
if (bevt_27_ta_ph.bevi_bool)/* Line: 268*/ {
if (bevl_defineClassTagName == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 269*/ {
bevl_state = (new BEC_2_4_3_MathInt(6));
} /* Line: 270*/
 else /* Line: 271*/ {
bevl_state = (new BEC_2_4_3_MathInt(7));
} /* Line: 272*/
} /* Line: 269*/
 else /* Line: 268*/ {
bevt_29_ta_ph = bevl_token.bem_equals_1(bevp_multiNullMark);
if (bevt_29_ta_ph.bevi_bool)/* Line: 274*/ {
bevl_state = (new BEC_2_4_3_MathInt(9));
} /* Line: 275*/
 else /* Line: 268*/ {
bevt_30_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_30_ta_ph.bevi_bool)/* Line: 276*/ {
bevl_groupInstIter = bevl_iterStack.bem_pop_0();
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 279*/
} /* Line: 268*/
} /* Line: 268*/
} /* Line: 268*/
 else /* Line: 281*/ {
bevt_32_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_state.bevi_int == bevt_32_ta_ph.bevi_int) {
bevt_31_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_31_ta_ph.bevi_bool)/* Line: 282*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(73, bece_BEC_2_6_10_SystemSerializer_bels_13));
bevt_34_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_35_ta_ph);
throw new be.BECS_ThrowBack(bevt_34_ta_ph);
} /* Line: 284*/
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 287*/
 else /* Line: 282*/ {
bevt_37_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_state.bevi_int == bevt_37_ta_ph.bevi_int) {
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 288*/ {
bevl_instString = bevp_encoder.bem_decode_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 290*/
 else /* Line: 282*/ {
bevt_39_ta_ph = (new BEC_2_4_3_MathInt(8));
if (bevl_state.bevi_int == bevt_39_ta_ph.bevi_int) {
bevt_38_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_38_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_38_ta_ph.bevi_bool)/* Line: 291*/ {
bevl_glassTagVal = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_40_ta_ph = bevl_session.bem_classTagMapGet_0();
bevl_klass = (BEC_2_4_6_TextString) bevt_40_ta_ph.bem_get_1(bevl_glassTagVal);
bevt_41_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevl_inst = bevt_41_ta_ph.bem_createInstance_1(bevl_klass);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_6_10_SystemSerializer_bels_14));
bevt_44_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_42_ta_ph = bevl_inst.bemd_2(-1813958638, bevt_43_ta_ph, bevt_44_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 295*/ {
bevl_inst = bevl_inst.bemd_1(-1104436681, bevl_instString);
} /* Line: 296*/
bevt_46_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_10_SystemSerializer_bels_15));
bevt_47_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_45_ta_ph = bevl_inst.bemd_2(-1813958638, bevt_46_ta_ph, bevt_47_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 298*/ {
bevl_inst = bevl_inst.bemd_1(1692922441, bevl_instString);
} /* Line: 299*/
if (bevl_rootInst == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 301*/ {
bevl_rootInst = bevl_inst;
} /* Line: 302*/
if (bevp_saveIdentity.bevi_bool)/* Line: 304*/ {
bevl_instances.bem_put_2(bevl_instSerial, bevl_inst);
} /* Line: 305*/
bevl_instString = null;
if (bevl_groupInstIter == null) {
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 309*/ {
bevl_groupInstIter.bemd_1(244271027, bevl_inst);
} /* Line: 310*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 312*/
 else /* Line: 282*/ {
bevt_51_ta_ph = (new BEC_2_4_3_MathInt(4));
if (bevl_state.bevi_int == bevt_51_ta_ph.bevi_int) {
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 313*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_52_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_52_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_52_ta_ph.bevi_bool)/* Line: 314*/ {
bevt_54_ta_ph = (new BEC_2_4_6_TextString(66, bece_BEC_2_6_10_SystemSerializer_bels_16));
bevt_53_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_54_ta_ph);
throw new be.BECS_ThrowBack(bevt_53_ta_ph);
} /* Line: 315*/
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_inst = bevl_instances.bem_get_1(bevl_instSerial);
if (bevl_groupInstIter == null) {
bevt_55_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_55_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_55_ta_ph.bevi_bool)/* Line: 319*/ {
bevl_groupInstIter.bemd_1(244271027, bevl_inst);
} /* Line: 320*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 322*/
 else /* Line: 282*/ {
bevt_57_ta_ph = (new BEC_2_4_3_MathInt(6));
if (bevl_state.bevi_int == bevt_57_ta_ph.bevi_int) {
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 323*/ {
bevl_defineClassTagName = bevl_token;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 325*/
 else /* Line: 282*/ {
bevt_59_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_state.bevi_int == bevt_59_ta_ph.bevi_int) {
bevt_58_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_58_ta_ph.bevi_bool)/* Line: 326*/ {
bevl_defineClassTagValue = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_60_ta_ph = bevl_session.bem_classTagMapGet_0();
bevt_60_ta_ph.bem_put_2(bevl_defineClassTagValue, bevl_defineClassTagName);
bevl_defineClassTagName = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 331*/
 else /* Line: 282*/ {
bevt_62_ta_ph = (new BEC_2_4_3_MathInt(9));
if (bevl_state.bevi_int == bevt_62_ta_ph.bevi_int) {
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_61_ta_ph.bevi_bool)/* Line: 332*/ {
if (bevl_groupInstIter == null) {
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 334*/ {
bevl_multiNullCount = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_groupInstIter.bemd_1(1026881740, bevl_multiNullCount);
} /* Line: 336*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 338*/
} /* Line: 282*/
} /* Line: 282*/
} /* Line: 282*/
} /* Line: 282*/
} /* Line: 282*/
} /* Line: 282*/
} /* Line: 282*/
} /* Line: 234*/
} /* Line: 234*/
 else /* Line: 232*/ {
break;
} /* Line: 232*/
} /* Line: 232*/
bevl_inst = null;
bevt_0_ta_loop = bevl_postDeserialize.bem_iteratorGet_0();
while (true)
/* Line: 343*/ {
bevt_64_ta_ph = bevt_0_ta_loop.bemd_0(86655816);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 343*/ {
bevl_groupInstIter = bevt_0_ta_loop.bemd_0(1034270849);
bevl_groupInstIter.bemd_0(-1845182080);
} /* Line: 344*/
 else /* Line: 343*/ {
break;
} /* Line: 343*/
} /* Line: 343*/
return bevl_rootInst;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGet_0() throws Throwable {
return bevp_group;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_group = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGet_0() throws Throwable {
return bevp_defineReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGet_0() throws Throwable {
return bevp_getReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGet_0() throws Throwable {
return bevp_constructString;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGet_0() throws Throwable {
return bevp_nullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGet_0() throws Throwable {
return bevp_getClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGet_0() throws Throwable {
return bevp_shift;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGet_0() throws Throwable {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGet_0() throws Throwable {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGet_0() throws Throwable {
return bevp_endGroup;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() throws Throwable {
return bevp_toker;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGet_0() throws Throwable {
return bevp_encoder;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGet_0() throws Throwable {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 59, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 76, 76, 76, 76, 76, 76, 76, 77, 75, 79, 80, 85, 86, 87, 91, 91, 92, 92, 97, 98, 98, 98, 99, 101, 104, 109, 110, 111, 111, 111, 112, 114, 116, 117, 118, 119, 120, 120, 122, 125, 125, 125, 126, 127, 128, 128, 128, 129, 130, 131, 132, 132, 132, 133, 134, 135, 135, 136, 138, 138, 139, 141, 141, 143, 143, 145, 148, 149, 149, 154, 154, 154, 155, 156, 157, 157, 157, 158, 159, 160, 161, 161, 161, 162, 163, 164, 164, 165, 167, 168, 173, 174, 174, 174, 176, 177, 177, 177, 178, 180, 180, 182, 182, 183, 183, 184, 185, 186, 186, 186, 187, 187, 188, 189, 190, 191, 192, 193, 195, 198, 199, 199, 202, 202, 202, 203, 205, 207, 207, 207, 207, 0, 0, 0, 208, 209, 209, 211, 212, 214, 214, 219, 220, 221, 222, 223, 223, 223, 223, 224, 226, 226, 228, 232, 232, 233, 234, 234, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 247, 247, 248, 250, 252, 252, 253, 253, 254, 256, 256, 256, 257, 259, 261, 261, 261, 262, 266, 266, 266, 268, 269, 269, 270, 272, 274, 275, 276, 278, 279, 282, 282, 282, 283, 283, 284, 284, 284, 286, 287, 288, 288, 288, 289, 290, 291, 291, 291, 292, 293, 293, 294, 294, 295, 295, 295, 296, 298, 298, 298, 299, 301, 301, 302, 305, 307, 309, 309, 310, 312, 313, 313, 313, 314, 314, 315, 315, 315, 317, 318, 319, 319, 320, 322, 323, 323, 323, 324, 325, 326, 326, 326, 328, 329, 329, 330, 331, 332, 332, 332, 334, 334, 335, 336, 338, 342, 343, 0, 343, 343, 344, 346, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 99, 100, 101, 106, 111, 112, 113, 122, 123, 124, 125, 127, 130, 133, 167, 168, 169, 170, 171, 173, 176, 178, 180, 183, 185, 186, 191, 192, 195, 196, 201, 202, 203, 206, 207, 212, 213, 214, 215, 218, 219, 224, 225, 226, 227, 228, 229, 233, 238, 239, 242, 243, 245, 250, 251, 254, 255, 256, 264, 265, 270, 271, 272, 275, 276, 281, 282, 283, 284, 287, 288, 293, 294, 295, 296, 297, 298, 302, 303, 335, 336, 337, 338, 339, 340, 341, 342, 344, 347, 348, 350, 351, 352, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 373, 376, 377, 378, 380, 381, 382, 384, 387, 389, 394, 395, 396, 398, 401, 405, 408, 409, 410, 412, 413, 415, 416, 504, 505, 506, 507, 508, 509, 510, 511, 513, 516, 517, 519, 520, 523, 525, 526, 527, 532, 533, 535, 538, 540, 543, 545, 548, 550, 553, 555, 558, 560, 565, 566, 570, 572, 577, 578, 583, 584, 586, 587, 588, 590, 593, 595, 596, 597, 599, 611, 612, 617, 618, 620, 625, 626, 629, 633, 635, 638, 640, 641, 647, 648, 653, 654, 659, 660, 661, 662, 664, 665, 668, 669, 674, 675, 676, 679, 680, 685, 686, 687, 688, 689, 690, 691, 692, 693, 695, 697, 698, 699, 701, 703, 708, 709, 712, 714, 715, 720, 721, 723, 726, 727, 732, 733, 738, 739, 740, 741, 743, 744, 745, 750, 751, 753, 756, 757, 762, 763, 764, 767, 768, 773, 774, 775, 776, 777, 778, 781, 782, 787, 788, 793, 794, 795, 797, 812, 813, 813, 816, 818, 819, 825, 828, 831, 835, 838, 842, 845, 849, 852, 856, 859, 863, 866, 870, 873, 877, 880, 884, 887, 891, 894, 898, 901, 905, 908, 912, 915};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 59 52
new 0 59 52
assign 1 59 53
new 0 59 53
assign 1 59 54
new 0 59 54
assign 1 59 55
new 0 59 55
assign 1 59 56
new 0 59 56
assign 1 59 57
new 0 59 57
assign 1 59 58
new 0 59 58
assign 1 59 59
new 0 59 59
assign 1 59 60
new 0 59 60
assign 1 59 61
new 0 59 61
new 10 59 62
assign 1 65 74
assign 1 66 75
assign 1 67 76
assign 1 68 77
assign 1 69 78
assign 1 70 79
assign 1 71 80
assign 1 72 81
assign 1 73 82
assign 1 74 83
assign 1 76 84
add 1 76 84
assign 1 76 85
add 1 76 85
assign 1 76 86
add 1 76 86
assign 1 76 87
add 1 76 87
assign 1 76 88
add 1 76 88
assign 1 76 89
add 1 76 89
assign 1 76 90
add 1 76 90
assign 1 77 91
new 0 77 91
assign 1 75 92
new 2 75 92
assign 1 79 93
new 0 79 93
assign 1 80 94
new 0 80 94
assign 1 85 99
new 0 85 99
serialize 2 86 100
return 1 87 101
assign 1 91 106
def 1 91 111
assign 1 92 112
new 1 92 112
serializeI 2 92 113
defineInstance 2 97 122
assign 1 98 123
new 0 98 123
assign 1 98 124
new 0 98 124
assign 1 98 125
can 2 98 125
assign 1 99 127
serializeContentsGet 0 99 127
assign 1 101 130
new 0 101 130
serializeC 2 104 133
assign 1 109 167
instWriterGet 0 109 167
assign 1 110 168
new 0 110 168
assign 1 111 169
new 0 111 169
assign 1 111 170
new 0 111 170
assign 1 111 171
can 2 111 171
assign 1 112 173
serializationIteratorGet 0 112 173
assign 1 114 176
iteratorGet 0 114 176
assign 1 116 178
hasNextGet 0 116 178
write 1 117 180
assign 1 118 183
hasNextGet 0 118 183
assign 1 119 185
nextGet 0 119 185
assign 1 120 186
undef 1 120 191
assign 1 122 192
increment 0 122 192
assign 1 125 195
new 0 125 195
assign 1 125 196
equals 1 125 201
write 1 126 202
assign 1 127 203
new 0 127 203
assign 1 128 206
new 0 128 206
assign 1 128 207
equals 1 128 212
write 1 129 213
write 1 130 214
assign 1 131 215
new 0 131 215
assign 1 132 218
new 0 132 218
assign 1 132 219
greater 1 132 224
write 1 133 225
write 1 134 226
assign 1 135 227
toString 0 135 227
write 1 135 228
assign 1 136 229
new 0 136 229
assign 1 138 233
not 0 138 238
assign 1 139 239
assign 1 141 242
uniqueGet 0 141 242
assign 1 141 243
get 1 141 243
assign 1 143 245
undef 1 143 250
serializeI 2 145 251
write 1 148 254
assign 1 149 255
toString 0 149 255
write 1 149 256
assign 1 154 264
new 0 154 264
assign 1 154 265
equals 1 154 270
write 1 155 271
assign 1 156 272
new 0 156 272
assign 1 157 275
new 0 157 275
assign 1 157 276
equals 1 157 281
write 1 158 282
write 1 159 283
assign 1 160 284
new 0 160 284
assign 1 161 287
new 0 161 287
assign 1 161 288
greater 1 161 293
write 1 162 294
write 1 163 295
assign 1 164 296
toString 0 164 296
write 1 164 297
assign 1 165 298
new 0 165 298
write 1 167 302
write 1 168 303
assign 1 173 335
serialCountGet 0 173 335
assign 1 174 336
new 0 174 336
assign 1 174 337
add 1 174 337
serialCountSet 1 174 338
assign 1 176 339
instWriterGet 0 176 339
assign 1 177 340
new 0 177 340
assign 1 177 341
new 0 177 341
assign 1 177 342
can 2 177 342
assign 1 178 344
deserializeClassNameGet 0 178 344
assign 1 180 347
new 0 180 347
assign 1 180 348
className 1 180 348
assign 1 182 350
classTagMapGet 0 182 350
assign 1 182 351
get 1 182 351
assign 1 183 352
undef 1 183 357
assign 1 184 358
classTagCountGet 0 184 358
assign 1 185 359
toString 0 185 359
assign 1 186 360
new 0 186 360
assign 1 186 361
add 1 186 361
classTagCountSet 1 186 362
assign 1 187 363
classTagMapGet 0 187 363
put 2 187 364
write 1 188 365
write 1 189 366
write 1 190 367
write 1 191 368
write 1 192 369
write 1 193 370
assign 1 195 373
toString 0 195 373
write 1 198 376
assign 1 199 377
toString 0 199 377
write 1 199 378
assign 1 202 380
new 0 202 380
assign 1 202 381
new 0 202 381
assign 1 202 382
can 2 202 382
assign 1 203 384
serializeToString 0 203 384
assign 1 205 387
assign 1 207 389
def 1 207 394
assign 1 207 395
new 0 207 395
assign 1 207 396
notEquals 1 207 396
assign 1 0 398
assign 1 0 401
assign 1 0 405
write 1 208 408
assign 1 209 409
encode 1 209 409
write 1 209 410
write 1 211 412
write 1 212 413
assign 1 214 415
uniqueGet 0 214 415
put 2 214 416
assign 1 219 504
new 0 219 504
assign 1 220 505
new 0 220 505
assign 1 221 506
new 0 221 506
assign 1 222 507
new 0 222 507
assign 1 223 508
new 0 223 508
assign 1 223 509
new 0 223 509
assign 1 223 510
emptyGet 0 223 510
assign 1 223 511
sameType 2 223 511
assign 1 224 513
tokenize 1 224 513
assign 1 226 516
readString 0 226 516
assign 1 226 517
tokenize 1 226 517
assign 1 228 519
new 0 228 519
assign 1 232 520
linkedListIteratorGet 0 232 520
assign 1 232 523
hasNextGet 0 232 523
assign 1 233 525
nextGet 0 233 525
assign 1 234 526
new 0 234 526
assign 1 234 527
equals 1 234 532
assign 1 235 533
equals 1 235 533
assign 1 236 535
new 0 236 535
assign 1 237 538
equals 1 237 538
assign 1 238 540
new 0 238 540
assign 1 239 543
equals 1 239 543
assign 1 240 545
new 0 240 545
assign 1 241 548
equals 1 241 548
assign 1 242 550
new 0 242 550
assign 1 243 553
equals 1 243 553
assign 1 244 555
new 0 244 555
assign 1 245 558
equals 1 245 558
assign 1 247 560
def 1 247 565
nextSet 1 248 566
assign 1 250 570
equals 1 250 570
assign 1 252 572
def 1 252 577
assign 1 253 578
def 1 253 583
push 1 254 584
assign 1 256 586
new 0 256 586
assign 1 256 587
new 0 256 587
assign 1 256 588
can 2 256 588
assign 1 257 590
serializationIteratorGet 0 257 590
assign 1 259 593
iteratorGet 0 259 593
assign 1 261 595
new 0 261 595
assign 1 261 596
new 0 261 596
assign 1 261 597
can 2 261 597
addValue 1 262 599
assign 1 266 611
new 0 266 611
assign 1 266 612
equals 1 266 617
assign 1 268 618
equals 1 268 618
assign 1 269 620
undef 1 269 625
assign 1 270 626
new 0 270 626
assign 1 272 629
new 0 272 629
assign 1 274 633
equals 1 274 633
assign 1 275 635
new 0 275 635
assign 1 276 638
equals 1 276 638
assign 1 278 640
pop 0 278 640
assign 1 279 641
new 0 279 641
assign 1 282 647
new 0 282 647
assign 1 282 648
equals 1 282 653
assign 1 283 654
not 0 283 659
assign 1 284 660
new 0 284 660
assign 1 284 661
new 1 284 661
throw 1 284 662
assign 1 286 664
new 1 286 664
assign 1 287 665
new 0 287 665
assign 1 288 668
new 0 288 668
assign 1 288 669
equals 1 288 674
assign 1 289 675
decode 1 289 675
assign 1 290 676
new 0 290 676
assign 1 291 679
new 0 291 679
assign 1 291 680
equals 1 291 685
assign 1 292 686
new 1 292 686
assign 1 293 687
classTagMapGet 0 293 687
assign 1 293 688
get 1 293 688
assign 1 294 689
new 0 294 689
assign 1 294 690
createInstance 1 294 690
assign 1 295 691
new 0 295 691
assign 1 295 692
new 0 295 692
assign 1 295 693
can 2 295 693
assign 1 296 695
deserializeFromStringNew 1 296 695
assign 1 298 697
new 0 298 697
assign 1 298 698
new 0 298 698
assign 1 298 699
can 2 298 699
assign 1 299 701
deserializeFromString 1 299 701
assign 1 301 703
undef 1 301 708
assign 1 302 709
put 2 305 712
assign 1 307 714
assign 1 309 715
def 1 309 720
nextSet 1 310 721
assign 1 312 723
new 0 312 723
assign 1 313 726
new 0 313 726
assign 1 313 727
equals 1 313 732
assign 1 314 733
not 0 314 738
assign 1 315 739
new 0 315 739
assign 1 315 740
new 1 315 740
throw 1 315 741
assign 1 317 743
new 1 317 743
assign 1 318 744
get 1 318 744
assign 1 319 745
def 1 319 750
nextSet 1 320 751
assign 1 322 753
new 0 322 753
assign 1 323 756
new 0 323 756
assign 1 323 757
equals 1 323 762
assign 1 324 763
assign 1 325 764
new 0 325 764
assign 1 326 767
new 0 326 767
assign 1 326 768
equals 1 326 773
assign 1 328 774
new 1 328 774
assign 1 329 775
classTagMapGet 0 329 775
put 2 329 776
assign 1 330 777
assign 1 331 778
new 0 331 778
assign 1 332 781
new 0 332 781
assign 1 332 782
equals 1 332 787
assign 1 334 788
def 1 334 793
assign 1 335 794
new 1 335 794
skip 1 336 795
assign 1 338 797
new 0 338 797
assign 1 342 812
assign 1 343 813
iteratorGet 0 0 813
assign 1 343 816
hasNextGet 0 343 816
assign 1 343 818
nextGet 0 343 818
postDeserialize 0 344 819
return 1 346 825
return 1 0 828
assign 1 0 831
return 1 0 835
assign 1 0 838
return 1 0 842
assign 1 0 845
return 1 0 849
assign 1 0 852
return 1 0 856
assign 1 0 859
return 1 0 863
assign 1 0 866
return 1 0 870
assign 1 0 873
return 1 0 877
assign 1 0 880
return 1 0 884
assign 1 0 887
return 1 0 891
assign 1 0 894
return 1 0 898
assign 1 0 901
return 1 0 905
assign 1 0 908
return 1 0 912
assign 1 0 915
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 782799996: return bem_constructStringGet_0();
case 1953377908: return bem_groupGet_0();
case -984604226: return bem_hashGet_0();
case -1791628821: return bem_nullMarkGet_0();
case -273090264: return bem_multiNullMarkGet_0();
case -509507035: return bem_defineReferenceGet_0();
case -1376188355: return bem_toString_0();
case -288684590: return bem_getClassTagGet_0();
case -935991010: return bem_saveIdentityGet_0();
case -1300294592: return bem_new_0();
case 30862756: return bem_iteratorGet_0();
case -52854293: return bem_tokerGet_0();
case -1793408398: return bem_defineClassTagGet_0();
case 1617519785: return bem_copy_0();
case 730897638: return bem_encoderGet_0();
case -862059367: return bem_getReferenceGet_0();
case -219492711: return bem_create_0();
case 576766600: return bem_shiftGet_0();
case -1470346066: return bem_endGroupGet_0();
case -1606682728: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -502777542: return bem_nullMarkSet_1(bevd_0);
case 171568292: return bem_getClassTagSet_1(bevd_0);
case -382459987: return bem_undef_1(bevd_0);
case 1772569280: return bem_multiNullMarkSet_1(bevd_0);
case 982875386: return bem_groupSet_1(bevd_0);
case 1616842678: return bem_notEquals_1(bevd_0);
case 144428460: return bem_equals_1(bevd_0);
case 1387173186: return bem_tokerSet_1(bevd_0);
case 1634599038: return bem_copyTo_1(bevd_0);
case 505935287: return bem_defineClassTagSet_1(bevd_0);
case -1210407309: return bem_getReferenceSet_1(bevd_0);
case -2099800442: return bem_deserialize_1(bevd_0);
case -455337490: return bem_endGroupSet_1(bevd_0);
case 1854019194: return bem_serialize_1(bevd_0);
case 996178551: return bem_shiftSet_1(bevd_0);
case 25126761: return bem_def_1(bevd_0);
case 354553024: return bem_defineReferenceSet_1(bevd_0);
case -1171585878: return bem_constructStringSet_1(bevd_0);
case 166309092: return bem_encoderSet_1(bevd_0);
case 2137513145: return bem_saveIdentitySet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -391874696: return bem_serializeI_2(bevd_0, bevd_1);
case 845289889: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1896256581: return bem_serialize_2(bevd_0, bevd_1);
case 107201170: return bem_serializeC_2(bevd_0, bevd_1);
case 2048415364: return bem_defineInstance_2(bevd_0, (BEC_3_6_10_7_SystemSerializerSession) bevd_1);
case 120651597: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -159239392: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1813958638: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_x(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5, BEC_2_6_6_SystemObject bevd_6, BEC_2_6_6_SystemObject[] bevd_x) throws Throwable {
switch (callId) {
case -155354677: return bem_new_10((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4, (BEC_2_4_6_TextString) bevd_5, (BEC_2_4_6_TextString) bevd_6, (BEC_2_4_6_TextString) bevd_x[0], (BEC_2_4_6_TextString) bevd_x[1], (BEC_2_4_6_TextString) bevd_x[2]);
}
return super.bemd_x(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5, bevd_6, bevd_x);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemSerializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_10_SystemSerializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemSerializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst = (BEC_2_6_10_SystemSerializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_type;
}
}
