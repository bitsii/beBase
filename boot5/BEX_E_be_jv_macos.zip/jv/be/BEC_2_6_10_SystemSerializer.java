package be;
/* IO:File: source/extended/Serialize.be */
public final class BEC_2_6_10_SystemSerializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemSerializer() { }
private static byte[] becc_BEC_2_6_10_SystemSerializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_10_SystemSerializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_0 = {0x7C};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_1 = {0x23};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_2 = {0x26};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_3 = {0x40};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_4 = {0x3B};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_5 = {0x3F};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_6 = {0x5E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_1 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_4 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_6 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_7 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_7 = {};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemSerializer_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemSerializer_bels_7, 0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_8 = {0x70,0x6F,0x73,0x74,0x44,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_10 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_9 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_12 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_13 = (new BEC_2_4_3_MathInt(8));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_14 = (new BEC_2_4_3_MathInt(4));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_10 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_15 = (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_16 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_17 = (new BEC_2_4_3_MathInt(9));
public static BEC_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_inst;

public static BET_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_type;

public BEC_2_4_6_TextString bevp_group;
public BEC_2_4_6_TextString bevp_defineReference;
public BEC_2_4_6_TextString bevp_getReference;
public BEC_2_4_6_TextString bevp_constructString;
public BEC_2_4_6_TextString bevp_nullMark;
public BEC_2_4_6_TextString bevp_getClassTag;
public BEC_2_4_6_TextString bevp_shift;
public BEC_2_4_6_TextString bevp_defineClassTag;
public BEC_2_4_6_TextString bevp_multiNullMark;
public BEC_2_4_6_TextString bevp_endGroup;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_6_3_EncodeHex bevp_encoder;
public BEC_2_5_4_LogicBool bevp_saveIdentity;
public BEC_2_6_10_SystemSerializer bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_2));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_3));
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_5));
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_6));
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bem_new_10(bevt_0_tmpany_phold, bevt_1_tmpany_phold, bevt_2_tmpany_phold, bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevt_6_tmpany_phold, bevt_7_tmpany_phold, bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_new_10(BEC_2_4_6_TextString beva__group, BEC_2_4_6_TextString beva__defineReference, BEC_2_4_6_TextString beva__getReference, BEC_2_4_6_TextString beva__constructString, BEC_2_4_6_TextString beva__nullMark, BEC_2_4_6_TextString beva__getClassTag, BEC_2_4_6_TextString beva__shift, BEC_2_4_6_TextString beva__defineClassTag, BEC_2_4_6_TextString beva__multiNullMark, BEC_2_4_6_TextString beva__endGroup) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevp_group = beva__group;
bevp_defineReference = beva__defineReference;
bevp_getReference = beva__getReference;
bevp_constructString = beva__constructString;
bevp_nullMark = beva__nullMark;
bevp_getClassTag = beva__getClassTag;
bevp_shift = beva__shift;
bevp_defineClassTag = beva__defineClassTag;
bevp_multiNullMark = beva__multiNullMark;
bevp_endGroup = beva__endGroup;
bevt_6_tmpany_phold = bevp_group.bem_add_1(bevp_defineReference);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevp_getReference);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevp_constructString);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevp_nullMark);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_defineClassTag);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_getClassTag);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_shift);
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_toker = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpany_phold, bevt_7_tmpany_phold);
bevp_encoder = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevp_saveIdentity = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serialize_1(BEC_2_6_6_SystemObject beva_instance) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bem_serialize_2(beva_instance, bevl_res);
return bevl_res;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serialize_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_instWriter) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_6_10_7_SystemSerializerSession bevt_1_tmpany_phold = null;
if (beva_instance == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 92 */ {
bevt_1_tmpany_phold = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_1(beva_instWriter);
bem_serializeI_2(beva_instance, bevt_1_tmpany_phold);
} /* Line: 93 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeI_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bem_defineInstance_2(beva_instance, (BEC_3_6_10_7_SystemSerializerSession) beva_session );
bevt_0_tmpany_phold = beva_instance.bemd_0(1464556610);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 99 */ {
bem_serializeC_2(beva_instance, beva_session);
} /* Line: 100 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeC_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_3_MathInt bevl_multiNull = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
bevl_instWriter = beva_session.bemd_0(1992120641);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
bevl_iter = beva_instance.bemd_0(1640160430);
bevt_0_tmpany_phold = bevl_iter.bemd_0(1239585548);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 108 */ {
bevl_instWriter.bemd_1(749345659, bevp_group);
while (true)
 /* Line: 110 */ {
bevt_1_tmpany_phold = bevl_iter.bemd_0(1239585548);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 110 */ {
bevl_i = bevl_iter.bemd_0(-1161084880);
if (bevl_i == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevl_multiNull = bevl_multiNull.bem_increment_0();
} /* Line: 114 */
 else  /* Line: 115 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_0;
if (bevl_multiNull.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_instWriter.bemd_1(749345659, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 119 */
 else  /* Line: 117 */ {
bevt_6_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_1;
if (bevl_multiNull.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevl_instWriter.bemd_1(749345659, bevp_nullMark);
bevl_instWriter.bemd_1(749345659, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 123 */
 else  /* Line: 117 */ {
bevt_8_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_2;
if (bevl_multiNull.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevl_instWriter.bemd_1(749345659, bevp_shift);
bevl_instWriter.bemd_1(749345659, bevp_nullMark);
bevt_9_tmpany_phold = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(749345659, bevt_9_tmpany_phold);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 128 */
} /* Line: 117 */
} /* Line: 117 */
if (bevp_saveIdentity.bevi_bool) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevl_instSerial = null;
} /* Line: 131 */
 else  /* Line: 132 */ {
bevt_11_tmpany_phold = beva_session.bemd_0(-194894665);
bevl_instSerial = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bemd_1(-1289225920, bevl_i);
} /* Line: 133 */
if (bevl_instSerial == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 135 */ {
bem_serializeI_2(bevl_i, beva_session);
} /* Line: 137 */
 else  /* Line: 138 */ {
bevl_instWriter.bemd_1(749345659, bevp_getReference);
bevt_13_tmpany_phold = bevl_instSerial.bem_toString_0();
bevl_instWriter.bemd_1(749345659, bevt_13_tmpany_phold);
} /* Line: 141 */
} /* Line: 135 */
} /* Line: 112 */
 else  /* Line: 110 */ {
break;
} /* Line: 110 */
} /* Line: 110 */
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_3;
if (bevl_multiNull.bevi_int == bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 146 */ {
bevl_instWriter.bemd_1(749345659, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 148 */
 else  /* Line: 146 */ {
bevt_17_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_4;
if (bevl_multiNull.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 149 */ {
bevl_instWriter.bemd_1(749345659, bevp_nullMark);
bevl_instWriter.bemd_1(749345659, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 152 */
 else  /* Line: 146 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_5;
if (bevl_multiNull.bevi_int > bevt_19_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevl_instWriter.bemd_1(749345659, bevp_shift);
bevl_instWriter.bemd_1(749345659, bevp_nullMark);
bevt_20_tmpany_phold = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(749345659, bevt_20_tmpany_phold);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 157 */
} /* Line: 146 */
} /* Line: 146 */
bevl_instWriter.bemd_1(749345659, bevp_shift);
bevl_instWriter.bemd_1(749345659, bevp_group);
} /* Line: 160 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineInstance_2(BEC_2_6_6_SystemObject beva_instance, BEC_3_6_10_7_SystemSerializerSession beva_session) throws Throwable {
BEC_2_4_3_MathInt bevl_scount = null;
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_6_TextString bevl_instClass = null;
BEC_2_4_3_MathInt bevl_instClassTag = null;
BEC_2_4_6_TextString bevl_instClassTagStr = null;
BEC_2_4_6_TextString bevl_serializedString = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_11_ContainerIdentityMap bevt_13_tmpany_phold = null;
bevl_scount = beva_session.bem_serialCountGet_0();
bevt_2_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_6;
bevt_1_tmpany_phold = bevl_scount.bem_add_1(bevt_2_tmpany_phold);
beva_session.bem_serialCountSet_1(bevt_1_tmpany_phold);
bevl_instWriter = beva_session.bem_instWriterGet_0();
bevl_instClass = (BEC_2_4_6_TextString) beva_instance.bemd_0(1966604989);
bevt_3_tmpany_phold = beva_session.bem_classTagMapGet_0();
bevl_instClassTag = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_get_1(bevl_instClass);
if (bevl_instClassTag == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevl_instClassTag = beva_session.bem_classTagCountGet_0();
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
bevt_6_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_7;
bevt_5_tmpany_phold = bevl_instClassTag.bem_add_1(bevt_6_tmpany_phold);
beva_session.bem_classTagCountSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = beva_session.bem_classTagMapGet_0();
bevt_7_tmpany_phold.bem_put_2(bevl_instClass, bevl_instClassTag);
bevl_instWriter.bemd_1(749345659, bevp_shift);
bevl_instWriter.bemd_1(749345659, bevp_defineClassTag);
bevl_instWriter.bemd_1(749345659, bevl_instClass);
bevl_instWriter.bemd_1(749345659, bevp_shift);
bevl_instWriter.bemd_1(749345659, bevp_defineClassTag);
bevl_instWriter.bemd_1(749345659, bevl_instClassTagStr);
} /* Line: 181 */
 else  /* Line: 182 */ {
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
} /* Line: 183 */
if (bevp_saveIdentity.bevi_bool) /* Line: 185 */ {
bevl_instWriter.bemd_1(749345659, bevp_defineReference);
bevt_8_tmpany_phold = bevl_scount.bem_toString_0();
bevl_instWriter.bemd_1(749345659, bevt_8_tmpany_phold);
} /* Line: 187 */
bevl_serializedString = (BEC_2_4_6_TextString) beva_instance.bemd_0(-916808790);
if (bevl_serializedString == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevt_11_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_8;
bevt_10_tmpany_phold = bevl_serializedString.bem_notEquals_1(bevt_11_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 190 */
 else  /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 190 */ {
bevl_instWriter.bemd_1(749345659, bevp_constructString);
bevt_12_tmpany_phold = bevp_encoder.bem_encode_1(bevl_serializedString);
bevl_instWriter.bemd_1(749345659, bevt_12_tmpany_phold);
} /* Line: 192 */
bevl_instWriter.bemd_1(749345659, bevp_getClassTag);
bevl_instWriter.bemd_1(749345659, bevl_instClassTagStr);
if (bevp_saveIdentity.bevi_bool) /* Line: 196 */ {
bevt_13_tmpany_phold = beva_session.bem_uniqueGet_0();
bevt_13_tmpany_phold.bem_put_2(beva_instance, bevl_scount);
} /* Line: 197 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserialize_1(BEC_2_6_6_SystemObject beva_instReader) throws Throwable {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_9_4_ContainerList bevl_postDeserialize = null;
BEC_3_6_10_7_SystemSerializerSession bevl_session = null;
BEC_2_9_5_ContainerStack bevl_iterStack = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_9_3_ContainerMap bevl_instances = null;
BEC_2_6_6_SystemObject bevl_rootInst = null;
BEC_2_6_6_SystemObject bevl_groupInstIter = null;
BEC_2_4_6_TextString bevl_defineClassTagName = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_token = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_4_6_TextString bevl_instString = null;
BEC_2_4_3_MathInt bevl_glassTagVal = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_4_3_MathInt bevl_defineClassTagValue = null;
BEC_2_4_3_MathInt bevl_multiNullCount = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
bevl_postDeserialize = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_session = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_0();
bevl_iterStack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_1_tmpany_phold = beva_instReader.bemd_1(1686689499, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 206 */ {
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(beva_instReader);
} /* Line: 207 */
 else  /* Line: 208 */ {
bevt_4_tmpany_phold = beva_instReader.bemd_0(-905628595);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(bevt_4_tmpany_phold);
} /* Line: 209 */
bevl_instances = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_i = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 215 */ {
bevt_5_tmpany_phold = bevl_i.bemd_0(1239585548);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 215 */ {
bevl_token = (BEC_2_4_6_TextString) bevl_i.bemd_0(-1161084880);
bevt_7_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_9;
if (bevl_state.bevi_int == bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevt_8_tmpany_phold = bevl_token.bem_equals_1(bevp_defineReference);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevl_state = (new BEC_2_4_3_MathInt(1));
} /* Line: 219 */
 else  /* Line: 218 */ {
bevt_9_tmpany_phold = bevl_token.bem_equals_1(bevp_constructString);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevl_state = (new BEC_2_4_3_MathInt(2));
} /* Line: 221 */
 else  /* Line: 218 */ {
bevt_10_tmpany_phold = bevl_token.bem_equals_1(bevp_getClassTag);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevl_state = (new BEC_2_4_3_MathInt(8));
} /* Line: 223 */
 else  /* Line: 218 */ {
bevt_11_tmpany_phold = bevl_token.bem_equals_1(bevp_shift);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevl_state = (new BEC_2_4_3_MathInt(1000));
} /* Line: 225 */
 else  /* Line: 218 */ {
bevt_12_tmpany_phold = bevl_token.bem_equals_1(bevp_getReference);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 226 */ {
bevl_state = (new BEC_2_4_3_MathInt(4));
} /* Line: 227 */
 else  /* Line: 218 */ {
bevt_13_tmpany_phold = bevl_token.bem_equals_1(bevp_nullMark);
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 228 */ {
if (bevl_groupInstIter == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevl_groupInstIter.bemd_1(1079415198, null);
} /* Line: 231 */
} /* Line: 230 */
 else  /* Line: 218 */ {
bevt_15_tmpany_phold = bevl_token.bem_equals_1(bevp_group);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 233 */ {
if (bevl_inst == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 235 */ {
if (bevl_groupInstIter == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 236 */ {
bevl_iterStack.bem_push_1(bevl_groupInstIter);
} /* Line: 237 */
bevl_groupInstIter = bevl_inst.bemd_0(1640160430);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_20_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_18_tmpany_phold = bevl_groupInstIter.bemd_2(1058450326, bevt_19_tmpany_phold, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 240 */ {
bevl_postDeserialize.bem_addValue_1(bevl_groupInstIter);
} /* Line: 241 */
} /* Line: 240 */
} /* Line: 235 */
} /* Line: 218 */
} /* Line: 218 */
} /* Line: 218 */
} /* Line: 218 */
} /* Line: 218 */
} /* Line: 218 */
} /* Line: 218 */
 else  /* Line: 217 */ {
bevt_22_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_10;
if (bevl_state.bevi_int == bevt_22_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 245 */ {
bevt_23_tmpany_phold = bevl_token.bem_equals_1(bevp_defineClassTag);
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 247 */ {
if (bevl_defineClassTagName == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 248 */ {
bevl_state = (new BEC_2_4_3_MathInt(6));
} /* Line: 249 */
 else  /* Line: 250 */ {
bevl_state = (new BEC_2_4_3_MathInt(7));
} /* Line: 251 */
} /* Line: 248 */
 else  /* Line: 247 */ {
bevt_25_tmpany_phold = bevl_token.bem_equals_1(bevp_multiNullMark);
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevl_state = (new BEC_2_4_3_MathInt(9));
} /* Line: 254 */
 else  /* Line: 247 */ {
bevt_26_tmpany_phold = bevl_token.bem_equals_1(bevp_group);
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevl_groupInstIter = bevl_iterStack.bem_pop_0();
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 258 */
} /* Line: 247 */
} /* Line: 247 */
} /* Line: 247 */
 else  /* Line: 260 */ {
bevt_28_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_11;
if (bevl_state.bevi_int == bevt_28_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 261 */ {
if (bevp_saveIdentity.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(73, bece_BEC_2_6_10_SystemSerializer_bels_9));
bevt_30_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_31_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_30_tmpany_phold);
} /* Line: 263 */
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 266 */
 else  /* Line: 261 */ {
bevt_33_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_12;
if (bevl_state.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevl_instString = bevp_encoder.bem_decode_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 269 */
 else  /* Line: 261 */ {
bevt_35_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_13;
if (bevl_state.bevi_int == bevt_35_tmpany_phold.bevi_int) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevl_glassTagVal = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_36_tmpany_phold = bevl_session.bem_classTagMapGet_0();
bevl_klass = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_get_1(bevl_glassTagVal);
bevt_38_tmpany_phold = bem_createInstance_1(bevl_klass);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(1303995883, bevl_instString);
bevl_inst = bevt_37_tmpany_phold.bemd_1(-1103921791, bevl_instString);
if (bevl_rootInst == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 274 */ {
bevl_rootInst = bevl_inst;
} /* Line: 275 */
if (bevp_saveIdentity.bevi_bool) /* Line: 277 */ {
bevl_instances.bem_put_2(bevl_instSerial, bevl_inst);
} /* Line: 278 */
bevl_instString = null;
if (bevl_groupInstIter == null) {
bevt_40_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevl_groupInstIter.bemd_1(1079415198, bevl_inst);
} /* Line: 283 */
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 285 */
 else  /* Line: 261 */ {
bevt_42_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_14;
if (bevl_state.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 286 */ {
if (bevp_saveIdentity.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 287 */ {
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(66, bece_BEC_2_6_10_SystemSerializer_bels_10));
bevt_44_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_45_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_44_tmpany_phold);
} /* Line: 288 */
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_inst = bevl_instances.bem_get_1(bevl_instSerial);
if (bevl_groupInstIter == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevl_groupInstIter.bemd_1(1079415198, bevl_inst);
} /* Line: 293 */
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 295 */
 else  /* Line: 261 */ {
bevt_48_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_15;
if (bevl_state.bevi_int == bevt_48_tmpany_phold.bevi_int) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 296 */ {
bevl_defineClassTagName = bevl_token;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 298 */
 else  /* Line: 261 */ {
bevt_50_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_16;
if (bevl_state.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 299 */ {
bevl_defineClassTagValue = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_51_tmpany_phold = bevl_session.bem_classTagMapGet_0();
bevt_51_tmpany_phold.bem_put_2(bevl_defineClassTagValue, bevl_defineClassTagName);
bevl_defineClassTagName = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 304 */
 else  /* Line: 261 */ {
bevt_53_tmpany_phold = bece_BEC_2_6_10_SystemSerializer_bevo_17;
if (bevl_state.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 305 */ {
if (bevl_groupInstIter == null) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevl_multiNullCount = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_groupInstIter.bemd_1(264439241, bevl_multiNullCount);
} /* Line: 309 */
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 311 */
} /* Line: 261 */
} /* Line: 261 */
} /* Line: 261 */
} /* Line: 261 */
} /* Line: 261 */
} /* Line: 261 */
} /* Line: 261 */
} /* Line: 217 */
} /* Line: 217 */
 else  /* Line: 215 */ {
break;
} /* Line: 215 */
} /* Line: 215 */
bevl_inst = null;
bevt_0_tmpany_loop = bevl_postDeserialize.bem_iteratorGet_0();
while (true)
 /* Line: 316 */ {
bevt_55_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1239585548);
if (((BEC_2_5_4_LogicBool) bevt_55_tmpany_phold).bevi_bool) /* Line: 316 */ {
bevl_groupInstIter = bevt_0_tmpany_loop.bemd_0(-1161084880);
bevl_groupInstIter.bemd_0(502634549);
} /* Line: 317 */
 else  /* Line: 316 */ {
break;
} /* Line: 316 */
} /* Line: 316 */
return bevl_rootInst;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGet_0() throws Throwable {
return bevp_group;
} /*method end*/
public final BEC_2_4_6_TextString bem_groupGetDirect_0() throws Throwable {
return bevp_group;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_group = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_groupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_group = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGet_0() throws Throwable {
return bevp_defineReference;
} /*method end*/
public final BEC_2_4_6_TextString bem_defineReferenceGetDirect_0() throws Throwable {
return bevp_defineReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_defineReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGet_0() throws Throwable {
return bevp_getReference;
} /*method end*/
public final BEC_2_4_6_TextString bem_getReferenceGetDirect_0() throws Throwable {
return bevp_getReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_getReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGet_0() throws Throwable {
return bevp_constructString;
} /*method end*/
public final BEC_2_4_6_TextString bem_constructStringGetDirect_0() throws Throwable {
return bevp_constructString;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_constructStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGet_0() throws Throwable {
return bevp_nullMark;
} /*method end*/
public final BEC_2_4_6_TextString bem_nullMarkGetDirect_0() throws Throwable {
return bevp_nullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_nullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGet_0() throws Throwable {
return bevp_getClassTag;
} /*method end*/
public final BEC_2_4_6_TextString bem_getClassTagGetDirect_0() throws Throwable {
return bevp_getClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_getClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGet_0() throws Throwable {
return bevp_shift;
} /*method end*/
public final BEC_2_4_6_TextString bem_shiftGetDirect_0() throws Throwable {
return bevp_shift;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_shiftSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGet_0() throws Throwable {
return bevp_defineClassTag;
} /*method end*/
public final BEC_2_4_6_TextString bem_defineClassTagGetDirect_0() throws Throwable {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_defineClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGet_0() throws Throwable {
return bevp_multiNullMark;
} /*method end*/
public final BEC_2_4_6_TextString bem_multiNullMarkGetDirect_0() throws Throwable {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_multiNullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGet_0() throws Throwable {
return bevp_endGroup;
} /*method end*/
public final BEC_2_4_6_TextString bem_endGroupGetDirect_0() throws Throwable {
return bevp_endGroup;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_endGroupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() throws Throwable {
return bevp_toker;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() throws Throwable {
return bevp_toker;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGet_0() throws Throwable {
return bevp_encoder;
} /*method end*/
public final BEC_2_6_3_EncodeHex bem_encoderGetDirect_0() throws Throwable {
return bevp_encoder;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_encoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGet_0() throws Throwable {
return bevp_saveIdentity;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveIdentityGetDirect_0() throws Throwable {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_saveIdentitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 77, 77, 77, 77, 77, 77, 77, 78, 76, 80, 81, 86, 87, 88, 92, 92, 93, 93, 98, 99, 100, 105, 106, 107, 108, 109, 110, 111, 112, 112, 114, 117, 117, 117, 118, 119, 120, 120, 120, 121, 122, 123, 124, 124, 124, 125, 126, 127, 127, 128, 130, 130, 131, 133, 133, 135, 135, 137, 140, 141, 141, 146, 146, 146, 147, 148, 149, 149, 149, 150, 151, 152, 153, 153, 153, 154, 155, 156, 156, 157, 159, 160, 165, 166, 166, 166, 168, 169, 170, 170, 171, 171, 172, 173, 174, 174, 174, 175, 175, 176, 177, 178, 179, 180, 181, 183, 186, 187, 187, 189, 190, 190, 190, 190, 0, 0, 0, 191, 192, 192, 194, 195, 197, 197, 202, 203, 204, 205, 206, 206, 206, 207, 209, 209, 211, 215, 215, 216, 217, 217, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 230, 230, 231, 233, 235, 235, 236, 236, 237, 239, 240, 240, 240, 241, 245, 245, 245, 247, 248, 248, 249, 251, 253, 254, 255, 257, 258, 261, 261, 261, 262, 262, 263, 263, 263, 265, 266, 267, 267, 267, 268, 269, 270, 270, 270, 271, 272, 272, 273, 273, 273, 274, 274, 275, 278, 280, 282, 282, 283, 285, 286, 286, 286, 287, 287, 288, 288, 288, 290, 291, 292, 292, 293, 295, 296, 296, 296, 297, 298, 299, 299, 299, 301, 302, 302, 303, 304, 305, 305, 305, 307, 307, 308, 309, 311, 315, 316, 0, 316, 316, 317, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 111, 112, 113, 118, 123, 124, 125, 131, 132, 134, 165, 166, 167, 168, 170, 173, 175, 176, 181, 182, 185, 186, 191, 192, 193, 196, 197, 202, 203, 204, 205, 208, 209, 214, 215, 216, 217, 218, 219, 223, 228, 229, 232, 233, 235, 240, 241, 244, 245, 246, 254, 255, 260, 261, 262, 265, 266, 271, 272, 273, 274, 277, 278, 283, 284, 285, 286, 287, 288, 292, 293, 318, 319, 320, 321, 322, 323, 324, 325, 326, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 347, 350, 351, 352, 354, 355, 360, 361, 362, 364, 367, 371, 374, 375, 376, 378, 379, 381, 382, 461, 462, 463, 464, 465, 466, 467, 469, 472, 473, 475, 476, 479, 481, 482, 483, 488, 489, 491, 494, 496, 499, 501, 504, 506, 509, 511, 514, 516, 521, 522, 526, 528, 533, 534, 539, 540, 542, 543, 544, 545, 547, 559, 560, 565, 566, 568, 573, 574, 577, 581, 583, 586, 588, 589, 595, 596, 601, 602, 607, 608, 609, 610, 612, 613, 616, 617, 622, 623, 624, 627, 628, 633, 634, 635, 636, 637, 638, 639, 640, 645, 646, 649, 651, 652, 657, 658, 660, 663, 664, 669, 670, 675, 676, 677, 678, 680, 681, 682, 687, 688, 690, 693, 694, 699, 700, 701, 704, 705, 710, 711, 712, 713, 714, 715, 718, 719, 724, 725, 730, 731, 732, 734, 749, 750, 750, 753, 755, 756, 762, 765, 768, 771, 775, 779, 782, 785, 789, 793, 796, 799, 803, 807, 810, 813, 817, 821, 824, 827, 831, 835, 838, 841, 845, 849, 852, 855, 859, 863, 866, 869, 873, 877, 880, 883, 887, 891, 894, 897, 901, 905, 908, 911, 915, 919, 922, 925, 929, 933, 936, 939, 943};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 60 64
new 0 60 64
assign 1 60 65
new 0 60 65
assign 1 60 66
new 0 60 66
assign 1 60 67
new 0 60 67
assign 1 60 68
new 0 60 68
assign 1 60 69
new 0 60 69
assign 1 60 70
new 0 60 70
assign 1 60 71
new 0 60 71
assign 1 60 72
new 0 60 72
assign 1 60 73
new 0 60 73
new 10 60 74
assign 1 66 86
assign 1 67 87
assign 1 68 88
assign 1 69 89
assign 1 70 90
assign 1 71 91
assign 1 72 92
assign 1 73 93
assign 1 74 94
assign 1 75 95
assign 1 77 96
add 1 77 96
assign 1 77 97
add 1 77 97
assign 1 77 98
add 1 77 98
assign 1 77 99
add 1 77 99
assign 1 77 100
add 1 77 100
assign 1 77 101
add 1 77 101
assign 1 77 102
add 1 77 102
assign 1 78 103
new 0 78 103
assign 1 76 104
new 2 76 104
assign 1 80 105
new 0 80 105
assign 1 81 106
new 0 81 106
assign 1 86 111
new 0 86 111
serialize 2 87 112
return 1 88 113
assign 1 92 118
def 1 92 123
assign 1 93 124
new 1 93 124
serializeI 2 93 125
defineInstance 2 98 131
assign 1 99 132
serializeContents 0 99 132
serializeC 2 100 134
assign 1 105 165
instWriterGet 0 105 165
assign 1 106 166
new 0 106 166
assign 1 107 167
serializationIteratorGet 0 107 167
assign 1 108 168
hasNextGet 0 108 168
write 1 109 170
assign 1 110 173
hasNextGet 0 110 173
assign 1 111 175
nextGet 0 111 175
assign 1 112 176
undef 1 112 181
assign 1 114 182
increment 0 114 182
assign 1 117 185
new 0 117 185
assign 1 117 186
equals 1 117 191
write 1 118 192
assign 1 119 193
new 0 119 193
assign 1 120 196
new 0 120 196
assign 1 120 197
equals 1 120 202
write 1 121 203
write 1 122 204
assign 1 123 205
new 0 123 205
assign 1 124 208
new 0 124 208
assign 1 124 209
greater 1 124 214
write 1 125 215
write 1 126 216
assign 1 127 217
toString 0 127 217
write 1 127 218
assign 1 128 219
new 0 128 219
assign 1 130 223
not 0 130 228
assign 1 131 229
assign 1 133 232
uniqueGet 0 133 232
assign 1 133 233
get 1 133 233
assign 1 135 235
undef 1 135 240
serializeI 2 137 241
write 1 140 244
assign 1 141 245
toString 0 141 245
write 1 141 246
assign 1 146 254
new 0 146 254
assign 1 146 255
equals 1 146 260
write 1 147 261
assign 1 148 262
new 0 148 262
assign 1 149 265
new 0 149 265
assign 1 149 266
equals 1 149 271
write 1 150 272
write 1 151 273
assign 1 152 274
new 0 152 274
assign 1 153 277
new 0 153 277
assign 1 153 278
greater 1 153 283
write 1 154 284
write 1 155 285
assign 1 156 286
toString 0 156 286
write 1 156 287
assign 1 157 288
new 0 157 288
write 1 159 292
write 1 160 293
assign 1 165 318
serialCountGet 0 165 318
assign 1 166 319
new 0 166 319
assign 1 166 320
add 1 166 320
serialCountSet 1 166 321
assign 1 168 322
instWriterGet 0 168 322
assign 1 169 323
deserializeClassNameGet 0 169 323
assign 1 170 324
classTagMapGet 0 170 324
assign 1 170 325
get 1 170 325
assign 1 171 326
undef 1 171 331
assign 1 172 332
classTagCountGet 0 172 332
assign 1 173 333
toString 0 173 333
assign 1 174 334
new 0 174 334
assign 1 174 335
add 1 174 335
classTagCountSet 1 174 336
assign 1 175 337
classTagMapGet 0 175 337
put 2 175 338
write 1 176 339
write 1 177 340
write 1 178 341
write 1 179 342
write 1 180 343
write 1 181 344
assign 1 183 347
toString 0 183 347
write 1 186 350
assign 1 187 351
toString 0 187 351
write 1 187 352
assign 1 189 354
serializeToString 0 189 354
assign 1 190 355
def 1 190 360
assign 1 190 361
new 0 190 361
assign 1 190 362
notEquals 1 190 362
assign 1 0 364
assign 1 0 367
assign 1 0 371
write 1 191 374
assign 1 192 375
encode 1 192 375
write 1 192 376
write 1 194 378
write 1 195 379
assign 1 197 381
uniqueGet 0 197 381
put 2 197 382
assign 1 202 461
new 0 202 461
assign 1 203 462
new 0 203 462
assign 1 204 463
new 0 204 463
assign 1 205 464
new 0 205 464
assign 1 206 465
new 0 206 465
assign 1 206 466
emptyGet 0 206 466
assign 1 206 467
sameType 1 206 467
assign 1 207 469
tokenize 1 207 469
assign 1 209 472
readString 0 209 472
assign 1 209 473
tokenize 1 209 473
assign 1 211 475
new 0 211 475
assign 1 215 476
linkedListIteratorGet 0 215 476
assign 1 215 479
hasNextGet 0 215 479
assign 1 216 481
nextGet 0 216 481
assign 1 217 482
new 0 217 482
assign 1 217 483
equals 1 217 488
assign 1 218 489
equals 1 218 489
assign 1 219 491
new 0 219 491
assign 1 220 494
equals 1 220 494
assign 1 221 496
new 0 221 496
assign 1 222 499
equals 1 222 499
assign 1 223 501
new 0 223 501
assign 1 224 504
equals 1 224 504
assign 1 225 506
new 0 225 506
assign 1 226 509
equals 1 226 509
assign 1 227 511
new 0 227 511
assign 1 228 514
equals 1 228 514
assign 1 230 516
def 1 230 521
nextSet 1 231 522
assign 1 233 526
equals 1 233 526
assign 1 235 528
def 1 235 533
assign 1 236 534
def 1 236 539
push 1 237 540
assign 1 239 542
serializationIteratorGet 0 239 542
assign 1 240 543
new 0 240 543
assign 1 240 544
new 0 240 544
assign 1 240 545
can 2 240 545
addValue 1 241 547
assign 1 245 559
new 0 245 559
assign 1 245 560
equals 1 245 565
assign 1 247 566
equals 1 247 566
assign 1 248 568
undef 1 248 573
assign 1 249 574
new 0 249 574
assign 1 251 577
new 0 251 577
assign 1 253 581
equals 1 253 581
assign 1 254 583
new 0 254 583
assign 1 255 586
equals 1 255 586
assign 1 257 588
pop 0 257 588
assign 1 258 589
new 0 258 589
assign 1 261 595
new 0 261 595
assign 1 261 596
equals 1 261 601
assign 1 262 602
not 0 262 607
assign 1 263 608
new 0 263 608
assign 1 263 609
new 1 263 609
throw 1 263 610
assign 1 265 612
new 1 265 612
assign 1 266 613
new 0 266 613
assign 1 267 616
new 0 267 616
assign 1 267 617
equals 1 267 622
assign 1 268 623
decode 1 268 623
assign 1 269 624
new 0 269 624
assign 1 270 627
new 0 270 627
assign 1 270 628
equals 1 270 633
assign 1 271 634
new 1 271 634
assign 1 272 635
classTagMapGet 0 272 635
assign 1 272 636
get 1 272 636
assign 1 273 637
createInstance 1 273 637
assign 1 273 638
deserializeFromStringNew 1 273 638
assign 1 273 639
deserializeFromString 1 273 639
assign 1 274 640
undef 1 274 645
assign 1 275 646
put 2 278 649
assign 1 280 651
assign 1 282 652
def 1 282 657
nextSet 1 283 658
assign 1 285 660
new 0 285 660
assign 1 286 663
new 0 286 663
assign 1 286 664
equals 1 286 669
assign 1 287 670
not 0 287 675
assign 1 288 676
new 0 288 676
assign 1 288 677
new 1 288 677
throw 1 288 678
assign 1 290 680
new 1 290 680
assign 1 291 681
get 1 291 681
assign 1 292 682
def 1 292 687
nextSet 1 293 688
assign 1 295 690
new 0 295 690
assign 1 296 693
new 0 296 693
assign 1 296 694
equals 1 296 699
assign 1 297 700
assign 1 298 701
new 0 298 701
assign 1 299 704
new 0 299 704
assign 1 299 705
equals 1 299 710
assign 1 301 711
new 1 301 711
assign 1 302 712
classTagMapGet 0 302 712
put 2 302 713
assign 1 303 714
assign 1 304 715
new 0 304 715
assign 1 305 718
new 0 305 718
assign 1 305 719
equals 1 305 724
assign 1 307 725
def 1 307 730
assign 1 308 731
new 1 308 731
skip 1 309 732
assign 1 311 734
new 0 311 734
assign 1 315 749
assign 1 316 750
iteratorGet 0 0 750
assign 1 316 753
hasNextGet 0 316 753
assign 1 316 755
nextGet 0 316 755
postDeserialize 0 317 756
return 1 319 762
return 1 0 765
return 1 0 768
assign 1 0 771
assign 1 0 775
return 1 0 779
return 1 0 782
assign 1 0 785
assign 1 0 789
return 1 0 793
return 1 0 796
assign 1 0 799
assign 1 0 803
return 1 0 807
return 1 0 810
assign 1 0 813
assign 1 0 817
return 1 0 821
return 1 0 824
assign 1 0 827
assign 1 0 831
return 1 0 835
return 1 0 838
assign 1 0 841
assign 1 0 845
return 1 0 849
return 1 0 852
assign 1 0 855
assign 1 0 859
return 1 0 863
return 1 0 866
assign 1 0 869
assign 1 0 873
return 1 0 877
return 1 0 880
assign 1 0 883
assign 1 0 887
return 1 0 891
return 1 0 894
assign 1 0 897
assign 1 0 901
return 1 0 905
return 1 0 908
assign 1 0 911
assign 1 0 915
return 1 0 919
return 1 0 922
assign 1 0 925
assign 1 0 929
return 1 0 933
return 1 0 936
assign 1 0 939
assign 1 0 943
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1733096947: return bem_saveIdentityGet_0();
case 1544637441: return bem_fieldIteratorGet_0();
case -916808790: return bem_serializeToString_0();
case -1440519528: return bem_new_0();
case 1516528362: return bem_copy_0();
case -352222734: return bem_echo_0();
case -1857169421: return bem_print_0();
case -1019129421: return bem_iteratorGet_0();
case 1256493526: return bem_create_0();
case -501726849: return bem_getClassTagGet_0();
case 1966604989: return bem_deserializeClassNameGet_0();
case -1503359702: return bem_nullMarkGet_0();
case -346792439: return bem_getClassTagGetDirect_0();
case 415444144: return bem_many_0();
case 1762446635: return bem_endGroupGet_0();
case -1154620079: return bem_defineReferenceGetDirect_0();
case 1977268733: return bem_toAny_0();
case -343521585: return bem_multiNullMarkGetDirect_0();
case 1640160430: return bem_serializationIteratorGet_0();
case 662718506: return bem_groupGet_0();
case 216561417: return bem_groupGetDirect_0();
case -913782287: return bem_shiftGet_0();
case 1811879950: return bem_multiNullMarkGet_0();
case 1865788370: return bem_saveIdentityGetDirect_0();
case -1732883702: return bem_encoderGetDirect_0();
case -1459660688: return bem_once_0();
case 883360591: return bem_nullMarkGetDirect_0();
case 764111846: return bem_classNameGet_0();
case -793011103: return bem_getReferenceGet_0();
case -2027075098: return bem_sourceFileNameGet_0();
case -1541828331: return bem_tokerGetDirect_0();
case 1464556610: return bem_serializeContents_0();
case 647733846: return bem_hashGet_0();
case -1439981222: return bem_tokerGet_0();
case -1322750582: return bem_fieldNamesGet_0();
case 810516096: return bem_tagGet_0();
case 108003389: return bem_encoderGet_0();
case -442635965: return bem_constructStringGetDirect_0();
case -1471293028: return bem_defineClassTagGet_0();
case 2022616058: return bem_getReferenceGetDirect_0();
case 283280862: return bem_defineClassTagGetDirect_0();
case -2042019182: return bem_toString_0();
case 250421039: return bem_defineReferenceGet_0();
case -1126496022: return bem_constructStringGet_0();
case 372068947: return bem_shiftGetDirect_0();
case 1066698320: return bem_endGroupGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 368922423: return bem_nullMarkSet_1(bevd_0);
case -1451816788: return bem_otherType_1(bevd_0);
case 2104241657: return bem_groupSetDirect_1(bevd_0);
case -1066262854: return bem_copyTo_1(bevd_0);
case -2113151813: return bem_otherClass_1(bevd_0);
case 1686689499: return bem_sameType_1(bevd_0);
case 500492024: return bem_encoderSetDirect_1(bevd_0);
case 129664577: return bem_undefined_1(bevd_0);
case 858949566: return bem_sameObject_1(bevd_0);
case 1146330462: return bem_defineClassTagSetDirect_1(bevd_0);
case -1042960117: return bem_deserialize_1(bevd_0);
case 1149328783: return bem_equals_1(bevd_0);
case -1904931664: return bem_encoderSet_1(bevd_0);
case -1103921791: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1726382580: return bem_undef_1(bevd_0);
case 1424824714: return bem_shiftSet_1(bevd_0);
case -603391976: return bem_getReferenceSetDirect_1(bevd_0);
case -585347653: return bem_endGroupSet_1(bevd_0);
case -62499290: return bem_notEquals_1(bevd_0);
case -634938323: return bem_saveIdentitySet_1(bevd_0);
case 1990284454: return bem_groupSet_1(bevd_0);
case 173437066: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1392282178: return bem_constructStringSet_1(bevd_0);
case -199914827: return bem_multiNullMarkSetDirect_1(bevd_0);
case -352871447: return bem_tokerSet_1(bevd_0);
case -1884560238: return bem_sameClass_1(bevd_0);
case -1471347591: return bem_serialize_1(bevd_0);
case -1832758366: return bem_saveIdentitySetDirect_1(bevd_0);
case -1693595005: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1303995883: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1529930548: return bem_def_1(bevd_0);
case 901453455: return bem_shiftSetDirect_1(bevd_0);
case -1962438594: return bem_defineReferenceSet_1(bevd_0);
case 456604916: return bem_defined_1(bevd_0);
case -1933841709: return bem_tokerSetDirect_1(bevd_0);
case 1533725559: return bem_multiNullMarkSet_1(bevd_0);
case 1342742753: return bem_getClassTagSet_1(bevd_0);
case -1734101764: return bem_getClassTagSetDirect_1(bevd_0);
case -831231204: return bem_defineClassTagSet_1(bevd_0);
case 748448560: return bem_nullMarkSetDirect_1(bevd_0);
case 206777718: return bem_endGroupSetDirect_1(bevd_0);
case -1081068956: return bem_getReferenceSet_1(bevd_0);
case 1273064642: return bem_defineReferenceSetDirect_1(bevd_0);
case -1133841310: return bem_constructStringSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -840184945: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1081220460: return bem_serializeC_2(bevd_0, bevd_1);
case 2113325337: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1732137967: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1058450326: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 478643257: return bem_defineInstance_2(bevd_0, (BEC_3_6_10_7_SystemSerializerSession) bevd_1);
case -1752849240: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2146731395: return bem_serializeI_2(bevd_0, bevd_1);
case 1337367239: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 572204899: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 628290584: return bem_serialize_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_x(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5, BEC_2_6_6_SystemObject bevd_6, BEC_2_6_6_SystemObject[] bevd_x) throws Throwable {
switch (callId) {
case 1164638476: return bem_new_10((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4, (BEC_2_4_6_TextString) bevd_5, (BEC_2_4_6_TextString) bevd_6, (BEC_2_4_6_TextString) bevd_x[0], (BEC_2_4_6_TextString) bevd_x[1], (BEC_2_4_6_TextString) bevd_x[2]);
}
return super.bemd_x(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5, bevd_6, bevd_x);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemSerializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_10_SystemSerializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemSerializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst = (BEC_2_6_10_SystemSerializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_type;
}
}
