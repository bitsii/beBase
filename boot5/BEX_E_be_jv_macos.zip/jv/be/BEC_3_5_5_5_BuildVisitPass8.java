package be;
/* IO:File: source/build/Pass8.be */
public final class BEC_3_5_5_5_BuildVisitPass8 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass8() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_24 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_25 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_26 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_27 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
public static BEC_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;

public BEC_3_5_5_5_BuildVisitPass8 bem_acceptClass_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_8_BuildEmitData bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_0_ta_ph.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepOps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(10));
bevl_ops = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 25*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = bevl_i.bemd_1(-486844982, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 25*/ {
bevt_3_ta_ph = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(-1456712468, bevl_i, bevt_3_ta_ph);
bevl_i = bevl_i.bemd_0(-1544419689);
} /* Line: 25*/
 else /* Line: 25*/ {
break;
} /* Line: 25*/
} /* Line: 25*/
return bevl_ops;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_prec = null;
BEC_2_6_6_SystemObject bevl_cont = null;
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_onode = null;
BEC_2_6_6_SystemObject bevl_mo = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_mt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
bevt_3_ta_ph = beva_node.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 35*/ {
bem_acceptClass_1(beva_node);
bevt_5_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_5_ta_ph;
} /* Line: 37*/
bevt_6_ta_ph = bevp_const.bem_operGet_0();
bevt_7_ta_ph = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_ta_ph.bem_get_1(bevt_7_ta_ph);
if (bevl_prec == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 40*/ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
/* Line: 50*/ {
if (bevl_onode == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 50*/ {
if (bevl_prec == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 50*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 50*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 50*/
 else /* Line: 50*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 50*/ {
bevt_12_ta_ph = bevl_onode.bemd_0(-1265514742);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(1724089654, bevl_cont);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 50*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 50*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 50*/
 else /* Line: 50*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 50*/ {
bevt_13_ta_ph = bevl_ops.bemd_1(-1177381470, bevl_prec);
bevt_13_ta_ph.bemd_1(867243956, bevl_onode);
bevl_inode = bevl_onode.bemd_0(-1692530467);
if (bevl_inode == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 53*/ {
bevl_inode = bevl_inode.bemd_0(-1692530467);
if (bevl_inode == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_17_ta_ph = bevl_inode.bemd_0(-1339371905);
bevt_18_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(1724089654, bevt_18_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 56*/ {
bevl_inode = bevl_inode.bemd_0(-1692530467);
if (bevl_inode == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 58*/ {
bevl_inode = bevl_inode.bemd_0(-1692530467);
} /* Line: 59*/
} /* Line: 58*/
} /* Line: 56*/
} /* Line: 55*/
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 65*/ {
bevt_21_ta_ph = bevp_const.bem_operGet_0();
bevt_22_ta_ph = bevl_onode.bemd_0(-1339371905);
bevl_prec = bevt_21_ta_ph.bem_get_1(bevt_22_ta_ph);
} /* Line: 66*/
 else /* Line: 67*/ {
bevl_prec = null;
} /* Line: 68*/
} /* Line: 65*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevl_prec = (new BEC_2_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(-2133146908);
while (true)
/* Line: 72*/ {
bevt_23_ta_ph = bevl_it.bemd_0(2118062146);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 72*/ {
bevl_i = bevl_it.bemd_0(127020587);
bevt_25_ta_ph = bevl_i.bemd_0(-1852232311);
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(-1714528971, bevt_26_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 74*/ {
bevl_mt = bevl_i.bemd_0(-2133146908);
while (true)
/* Line: 75*/ {
bevt_27_ta_ph = bevl_mt.bemd_0(2118062146);
if (((BEC_2_5_4_LogicBool) bevt_27_ta_ph).bevi_bool)/* Line: 75*/ {
bevl_mo = bevl_mt.bemd_0(127020587);
bevt_28_ta_ph = bevl_mo.bemd_0(-770388171);
bevt_29_ta_ph = bevl_mo.bemd_0(-1692530467);
bevl_mo = bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_ta_ph, bevt_29_ta_ph);
beva_node = (BEC_2_5_4_BuildNode) bevl_mo;
} /* Line: 78*/
 else /* Line: 75*/ {
break;
} /* Line: 75*/
} /* Line: 75*/
} /* Line: 75*/
bevl_prec = bevl_prec.bemd_0(-1544419689);
} /* Line: 81*/
 else /* Line: 72*/ {
break;
} /* Line: 72*/
} /* Line: 72*/
} /* Line: 72*/
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callFromOper_4(BEC_2_6_6_SystemObject beva_op, BEC_2_6_6_SystemObject beva_prec, BEC_2_6_6_SystemObject beva_pr, BEC_2_6_6_SystemObject beva_nx) throws Throwable {
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(877315004, bevt_0_ta_ph);
bevt_3_ta_ph = bevp_const.bem_operNamesGet_0();
bevt_4_ta_ph = beva_op.bemd_0(-1339371905);
bevt_2_ta_ph = bevt_3_ta_ph.bem_get_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1495883122);
bevl_gc.bemd_1(-473162788, bevt_1_ta_ph);
bevt_6_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_0));
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(1724089654, bevt_7_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 93*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_1));
bevl_gc.bemd_1(-473162788, bevt_8_ta_ph);
} /* Line: 94*/
bevt_10_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_2));
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(1724089654, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 96*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_3));
bevl_gc.bemd_1(-473162788, bevt_12_ta_ph);
} /* Line: 97*/
bevt_14_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_4));
bevt_13_ta_ph = bevt_14_ta_ph.bemd_1(1724089654, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 99*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_5));
bevl_gc.bemd_1(-473162788, bevt_16_ta_ph);
} /* Line: 100*/
bevt_18_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_6));
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(1724089654, bevt_19_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 102*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_7));
bevl_gc.bemd_1(-473162788, bevt_20_ta_ph);
} /* Line: 103*/
bevt_22_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_8));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1724089654, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 105*/ {
bevt_24_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_9));
bevl_gc.bemd_1(-473162788, bevt_24_ta_ph);
} /* Line: 106*/
bevt_26_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_10));
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(1724089654, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 108*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_11));
bevl_gc.bemd_1(-473162788, bevt_28_ta_ph);
} /* Line: 109*/
bevt_30_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_12));
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(1724089654, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_29_ta_ph).bevi_bool)/* Line: 111*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_13));
bevl_gc.bemd_1(-473162788, bevt_32_ta_ph);
} /* Line: 112*/
bevt_34_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_14));
bevt_33_ta_ph = bevt_34_ta_ph.bemd_1(1724089654, bevt_35_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 114*/ {
bevt_36_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_15));
bevl_gc.bemd_1(-473162788, bevt_36_ta_ph);
} /* Line: 115*/
bevt_38_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_16));
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(1724089654, bevt_39_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_37_ta_ph).bevi_bool)/* Line: 117*/ {
bevt_40_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_17));
bevl_gc.bemd_1(-473162788, bevt_40_ta_ph);
} /* Line: 118*/
bevt_42_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_18));
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(1724089654, bevt_43_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 120*/ {
bevt_44_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_19));
bevl_gc.bemd_1(-473162788, bevt_44_ta_ph);
} /* Line: 121*/
bevt_46_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_20));
bevt_45_ta_ph = bevt_46_ta_ph.bemd_1(1724089654, bevt_47_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 123*/ {
bevt_48_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_21));
bevl_gc.bemd_1(-473162788, bevt_48_ta_ph);
} /* Line: 124*/
bevt_50_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_51_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_22));
bevt_49_ta_ph = bevt_50_ta_ph.bemd_1(1724089654, bevt_51_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_49_ta_ph).bevi_bool)/* Line: 126*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_23));
bevl_gc.bemd_1(-473162788, bevt_52_ta_ph);
} /* Line: 127*/
bevt_54_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_55_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(1724089654, bevt_55_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 129*/ {
bevt_56_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_25));
bevl_gc.bemd_1(-473162788, bevt_56_ta_ph);
} /* Line: 130*/
bevt_58_ta_ph = bevl_gc.bemd_0(-1505887458);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_26));
bevt_57_ta_ph = bevt_58_ta_ph.bemd_1(1724089654, bevt_59_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_57_ta_ph).bevi_bool)/* Line: 132*/ {
bevt_60_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass8_bels_27));
bevl_gc.bemd_1(-473162788, bevt_60_ta_ph);
} /* Line: 133*/
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(142257412, bevt_61_ta_ph);
bevt_62_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(-114885074, bevt_62_ta_ph);
beva_op.bemd_1(590756066, bevl_gc);
beva_pr.bemd_0(-1795009863);
beva_op.bemd_1(867243956, beva_pr);
bevt_64_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_63_ta_ph = beva_prec.bemd_1(-1714528971, bevt_64_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 141*/ {
beva_nx.bemd_0(-1795009863);
beva_op.bemd_1(867243956, beva_nx);
} /* Line: 143*/
return beva_op;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 20, 24, 24, 25, 25, 25, 26, 26, 25, 28, 35, 35, 35, 35, 36, 37, 37, 39, 39, 39, 40, 40, 45, 46, 47, 49, 50, 50, 50, 50, 0, 0, 0, 50, 50, 0, 0, 0, 51, 51, 52, 53, 53, 54, 55, 55, 56, 56, 56, 57, 58, 58, 59, 64, 65, 65, 66, 66, 66, 68, 71, 72, 72, 73, 74, 74, 74, 75, 75, 76, 77, 77, 77, 78, 81, 86, 86, 90, 91, 91, 92, 92, 92, 92, 92, 93, 93, 93, 94, 94, 96, 96, 96, 97, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 109, 109, 111, 111, 111, 112, 112, 114, 114, 114, 115, 115, 117, 117, 117, 118, 118, 120, 120, 120, 121, 121, 123, 123, 123, 124, 124, 126, 126, 126, 127, 127, 129, 129, 129, 130, 130, 132, 132, 132, 133, 133, 136, 136, 137, 137, 138, 139, 140, 141, 141, 142, 143, 145};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 52, 53, 54, 57, 58, 60, 61, 62, 68, 111, 112, 113, 118, 119, 120, 121, 123, 124, 125, 126, 131, 132, 133, 134, 135, 138, 143, 144, 149, 150, 153, 157, 160, 161, 163, 166, 170, 173, 174, 175, 176, 181, 182, 183, 188, 189, 190, 191, 193, 194, 199, 200, 205, 206, 211, 212, 213, 214, 217, 224, 225, 228, 230, 231, 232, 233, 235, 238, 240, 241, 242, 243, 244, 251, 258, 259, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 340, 341, 343, 344, 345, 347, 348, 350, 351, 352, 354, 355, 357, 358, 359, 361, 362, 364, 365, 366, 368, 369, 371, 372, 373, 375, 376, 378, 379, 380, 382, 383, 385, 386, 387, 389, 390, 392, 393, 394, 396, 397, 399, 400, 401, 403, 404, 406, 407, 408, 410, 411, 413, 414, 415, 417, 418, 420, 421, 422, 424, 425, 427, 428, 429, 431, 432, 434, 435, 436, 437, 438, 439, 440, 441, 442, 444, 445, 447};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 41
emitDataGet 0 20 41
addParsedClass 1 20 42
assign 1 24 52
new 0 24 52
assign 1 24 53
new 1 24 53
assign 1 25 54
new 0 25 54
assign 1 25 57
new 0 25 57
assign 1 25 58
lesser 1 25 58
assign 1 26 60
new 0 26 60
put 2 26 61
assign 1 25 62
increment 0 25 62
return 1 28 68
assign 1 35 111
typenameGet 0 35 111
assign 1 35 112
CLASSGet 0 35 112
assign 1 35 113
equals 1 35 118
acceptClass 1 36 119
assign 1 37 120
nextDescendGet 0 37 120
return 1 37 121
assign 1 39 123
operGet 0 39 123
assign 1 39 124
typenameGet 0 39 124
assign 1 39 125
get 1 39 125
assign 1 40 126
def 1 40 131
assign 1 45 132
containerGet 0 45 132
assign 1 46 133
prepOps 0 46 133
assign 1 47 134
assign 1 49 135
assign 1 50 138
def 1 50 143
assign 1 50 144
def 1 50 149
assign 1 0 150
assign 1 0 153
assign 1 0 157
assign 1 50 160
containerGet 0 50 160
assign 1 50 161
equals 1 50 161
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 51 173
get 1 51 173
addValue 1 51 174
assign 1 52 175
nextPeerGet 0 52 175
assign 1 53 176
def 1 53 181
assign 1 54 182
nextPeerGet 0 54 182
assign 1 55 183
def 1 55 188
assign 1 56 189
typenameGet 0 56 189
assign 1 56 190
COMMAGet 0 56 190
assign 1 56 191
equals 1 56 191
assign 1 57 193
nextPeerGet 0 57 193
assign 1 58 194
def 1 58 199
assign 1 59 200
nextPeerGet 0 59 200
assign 1 64 205
assign 1 65 206
def 1 65 211
assign 1 66 212
operGet 0 66 212
assign 1 66 213
typenameGet 0 66 213
assign 1 66 214
get 1 66 214
assign 1 68 217
assign 1 71 224
new 0 71 224
assign 1 72 225
iteratorGet 0 72 225
assign 1 72 228
hasNextGet 0 72 228
assign 1 73 230
nextGet 0 73 230
assign 1 74 231
lengthGet 0 74 231
assign 1 74 232
new 0 74 232
assign 1 74 233
greater 1 74 233
assign 1 75 235
iteratorGet 0 75 235
assign 1 75 238
hasNextGet 0 75 238
assign 1 76 240
nextGet 0 76 240
assign 1 77 241
priorPeerGet 0 77 241
assign 1 77 242
nextPeerGet 0 77 242
assign 1 77 243
callFromOper 4 77 243
assign 1 78 244
assign 1 81 251
increment 0 81 251
assign 1 86 258
nextDescendGet 0 86 258
return 1 86 259
assign 1 90 328
new 0 90 328
assign 1 91 329
new 0 91 329
wasOperSet 1 91 330
assign 1 92 331
operNamesGet 0 92 331
assign 1 92 332
typenameGet 0 92 332
assign 1 92 333
get 1 92 333
assign 1 92 334
lower 0 92 334
nameSet 1 92 335
assign 1 93 336
nameGet 0 93 336
assign 1 93 337
new 0 93 337
assign 1 93 338
equals 1 93 338
assign 1 94 340
new 0 94 340
nameSet 1 94 341
assign 1 96 343
nameGet 0 96 343
assign 1 96 344
new 0 96 344
assign 1 96 345
equals 1 96 345
assign 1 97 347
new 0 97 347
nameSet 1 97 348
assign 1 99 350
nameGet 0 99 350
assign 1 99 351
new 0 99 351
assign 1 99 352
equals 1 99 352
assign 1 100 354
new 0 100 354
nameSet 1 100 355
assign 1 102 357
nameGet 0 102 357
assign 1 102 358
new 0 102 358
assign 1 102 359
equals 1 102 359
assign 1 103 361
new 0 103 361
nameSet 1 103 362
assign 1 105 364
nameGet 0 105 364
assign 1 105 365
new 0 105 365
assign 1 105 366
equals 1 105 366
assign 1 106 368
new 0 106 368
nameSet 1 106 369
assign 1 108 371
nameGet 0 108 371
assign 1 108 372
new 0 108 372
assign 1 108 373
equals 1 108 373
assign 1 109 375
new 0 109 375
nameSet 1 109 376
assign 1 111 378
nameGet 0 111 378
assign 1 111 379
new 0 111 379
assign 1 111 380
equals 1 111 380
assign 1 112 382
new 0 112 382
nameSet 1 112 383
assign 1 114 385
nameGet 0 114 385
assign 1 114 386
new 0 114 386
assign 1 114 387
equals 1 114 387
assign 1 115 389
new 0 115 389
nameSet 1 115 390
assign 1 117 392
nameGet 0 117 392
assign 1 117 393
new 0 117 393
assign 1 117 394
equals 1 117 394
assign 1 118 396
new 0 118 396
nameSet 1 118 397
assign 1 120 399
nameGet 0 120 399
assign 1 120 400
new 0 120 400
assign 1 120 401
equals 1 120 401
assign 1 121 403
new 0 121 403
nameSet 1 121 404
assign 1 123 406
nameGet 0 123 406
assign 1 123 407
new 0 123 407
assign 1 123 408
equals 1 123 408
assign 1 124 410
new 0 124 410
nameSet 1 124 411
assign 1 126 413
nameGet 0 126 413
assign 1 126 414
new 0 126 414
assign 1 126 415
equals 1 126 415
assign 1 127 417
new 0 127 417
nameSet 1 127 418
assign 1 129 420
nameGet 0 129 420
assign 1 129 421
new 0 129 421
assign 1 129 422
equals 1 129 422
assign 1 130 424
new 0 130 424
nameSet 1 130 425
assign 1 132 427
nameGet 0 132 427
assign 1 132 428
new 0 132 428
assign 1 132 429
equals 1 132 429
assign 1 133 431
new 0 133 431
nameSet 1 133 432
assign 1 136 434
new 0 136 434
wasBoundSet 1 136 435
assign 1 137 436
CALLGet 0 137 436
typenameSet 1 137 437
heldSet 1 138 438
delete 0 139 439
addValue 1 140 440
assign 1 141 441
new 0 141 441
assign 1 141 442
greater 1 141 442
delete 0 142 444
addValue 1 143 445
return 1 145 447
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2134993308: return bem_new_0();
case -2096331826: return bem_copy_0();
case 1461900082: return bem_prepOps_0();
case 420796529: return bem_toString_0();
case -999123940: return bem_create_0();
case 2105446481: return bem_print_0();
case -525159192: return bem_buildGet_0();
case 97869199: return bem_hashGet_0();
case -2133146908: return bem_iteratorGet_0();
case 1171807031: return bem_transGet_0();
case -1748430304: return bem_constGet_0();
case 1717872757: return bem_ntypesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -199176115: return bem_undef_1(bevd_0);
case -1845239358: return bem_copyTo_1(bevd_0);
case 1085927064: return bem_end_1(bevd_0);
case 414270992: return bem_acceptClass_1(bevd_0);
case 1229792712: return bem_ntypesSet_1(bevd_0);
case 1016050541: return bem_notEquals_1(bevd_0);
case 128712658: return bem_begin_1(bevd_0);
case -1267394016: return bem_constSet_1(bevd_0);
case -561946826: return bem_def_1(bevd_0);
case 1724089654: return bem_equals_1(bevd_0);
case -1224760276: return bem_transSet_1(bevd_0);
case 2051232364: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1532348940: return bem_buildSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 861111505: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 150001987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1560972769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -444420730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2053560751: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass8_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass8_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass8();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst = (BEC_3_5_5_5_BuildVisitPass8) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;
}
}
