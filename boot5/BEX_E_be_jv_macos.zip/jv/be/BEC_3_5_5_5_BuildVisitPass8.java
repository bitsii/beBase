package be;
/* IO:File: source/build/Pass8.be */
public final class BEC_3_5_5_5_BuildVisitPass8 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass8() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_24 = {0x67,0x65,0x74,0x5F,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_25 = {0x67,0x65,0x74,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_26 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_27 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_28 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_29 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_30 = {0x3D,0x40};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_31 = {0x3D,0x23};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_32 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
public static BEC_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;

public BEC_3_5_5_5_BuildVisitPass8 bem_acceptClass_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_8_BuildEmitData bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_0_ta_ph.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepOps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(10));
bevl_ops = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 19*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = bevl_i.bemd_1(-325071657, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 19*/ {
bevt_3_ta_ph = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(-1350687310, bevl_i, bevt_3_ta_ph);
bevl_i = bevl_i.bemd_0(1169573854);
} /* Line: 19*/
 else /* Line: 19*/ {
break;
} /* Line: 19*/
} /* Line: 19*/
return bevl_ops;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_prec = null;
BEC_2_6_6_SystemObject bevl_cont = null;
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_onode = null;
BEC_2_6_6_SystemObject bevl_mo = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_mt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
bevt_3_ta_ph = beva_node.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 29*/ {
bem_acceptClass_1(beva_node);
bevt_5_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_5_ta_ph;
} /* Line: 31*/
bevt_6_ta_ph = bevp_const.bem_operGet_0();
bevt_7_ta_ph = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_ta_ph.bem_get_1(bevt_7_ta_ph);
if (bevl_prec == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 34*/ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
/* Line: 44*/ {
if (bevl_onode == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevl_prec == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_12_ta_ph = bevl_onode.bemd_0(1845595557);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(447224999, bevl_cont);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_13_ta_ph = bevl_ops.bemd_1(971676728, bevl_prec);
bevt_13_ta_ph.bemd_1(1553169033, bevl_onode);
bevl_inode = bevl_onode.bemd_0(-1444894676);
if (bevl_inode == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 47*/ {
bevl_inode = bevl_inode.bemd_0(-1444894676);
if (bevl_inode == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_17_ta_ph = bevl_inode.bemd_0(-1909241900);
bevt_18_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(447224999, bevt_18_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_inode = bevl_inode.bemd_0(-1444894676);
if (bevl_inode == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 52*/ {
bevl_inode = bevl_inode.bemd_0(-1444894676);
} /* Line: 53*/
} /* Line: 52*/
} /* Line: 50*/
} /* Line: 49*/
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_21_ta_ph = bevp_const.bem_operGet_0();
bevt_22_ta_ph = bevl_onode.bemd_0(-1909241900);
bevl_prec = bevt_21_ta_ph.bem_get_1(bevt_22_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
bevl_prec = null;
} /* Line: 62*/
} /* Line: 59*/
 else /* Line: 44*/ {
break;
} /* Line: 44*/
} /* Line: 44*/
bevl_prec = (new BEC_2_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(-1660007365);
while (true)
/* Line: 66*/ {
bevt_23_ta_ph = bevl_it.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 66*/ {
bevl_i = bevl_it.bemd_0(-190996314);
bevt_25_ta_ph = bevl_i.bemd_0(245797063);
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(-1989431768, bevt_26_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 68*/ {
bevl_mt = bevl_i.bemd_0(-1660007365);
while (true)
/* Line: 69*/ {
bevt_27_ta_ph = bevl_mt.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_27_ta_ph).bevi_bool)/* Line: 69*/ {
bevl_mo = bevl_mt.bemd_0(-190996314);
bevt_28_ta_ph = bevl_mo.bemd_0(-1103191424);
bevt_29_ta_ph = bevl_mo.bemd_0(-1444894676);
bevl_mo = bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_ta_ph, bevt_29_ta_ph);
beva_node = (BEC_2_5_4_BuildNode) bevl_mo;
} /* Line: 72*/
 else /* Line: 69*/ {
break;
} /* Line: 69*/
} /* Line: 69*/
} /* Line: 69*/
bevl_prec = bevl_prec.bemd_0(1169573854);
} /* Line: 75*/
 else /* Line: 66*/ {
break;
} /* Line: 66*/
} /* Line: 66*/
} /* Line: 66*/
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callFromOper_4(BEC_2_6_6_SystemObject beva_op, BEC_2_6_6_SystemObject beva_prec, BEC_2_6_6_SystemObject beva_pr, BEC_2_6_6_SystemObject beva_nx) throws Throwable {
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_5_4_LogicBool bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_6_6_SystemObject bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1209003892, bevt_2_ta_ph);
bevt_5_ta_ph = bevp_const.bem_operNamesGet_0();
bevt_6_ta_ph = beva_op.bemd_0(-1909241900);
bevt_4_ta_ph = bevt_5_ta_ph.bem_get_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-277220848);
bevl_gc.bemd_1(-541150916, bevt_3_ta_ph);
bevt_8_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_0));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(447224999, bevt_9_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 87*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_1));
bevl_gc.bemd_1(-541150916, bevt_10_ta_ph);
} /* Line: 88*/
bevt_12_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_2));
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(447224999, bevt_13_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 90*/ {
bevt_14_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_3));
bevl_gc.bemd_1(-541150916, bevt_14_ta_ph);
} /* Line: 91*/
bevt_16_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_4));
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(447224999, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 93*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_5));
bevl_gc.bemd_1(-541150916, bevt_18_ta_ph);
} /* Line: 94*/
bevt_20_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_6));
bevt_19_ta_ph = bevt_20_ta_ph.bemd_1(447224999, bevt_21_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_19_ta_ph).bevi_bool)/* Line: 96*/ {
bevt_22_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_7));
bevl_gc.bemd_1(-541150916, bevt_22_ta_ph);
} /* Line: 97*/
bevt_24_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_8));
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(447224999, bevt_25_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 99*/ {
bevt_26_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_9));
bevl_gc.bemd_1(-541150916, bevt_26_ta_ph);
} /* Line: 100*/
bevt_28_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_10));
bevt_27_ta_ph = bevt_28_ta_ph.bemd_1(447224999, bevt_29_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_27_ta_ph).bevi_bool)/* Line: 102*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_11));
bevl_gc.bemd_1(-541150916, bevt_30_ta_ph);
} /* Line: 103*/
bevt_32_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_12));
bevt_31_ta_ph = bevt_32_ta_ph.bemd_1(447224999, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_31_ta_ph).bevi_bool)/* Line: 105*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_13));
bevl_gc.bemd_1(-541150916, bevt_34_ta_ph);
} /* Line: 106*/
bevt_36_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_14));
bevt_35_ta_ph = bevt_36_ta_ph.bemd_1(447224999, bevt_37_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_35_ta_ph).bevi_bool)/* Line: 108*/ {
bevt_38_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_15));
bevl_gc.bemd_1(-541150916, bevt_38_ta_ph);
} /* Line: 109*/
bevt_40_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_16));
bevt_39_ta_ph = bevt_40_ta_ph.bemd_1(447224999, bevt_41_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_39_ta_ph).bevi_bool)/* Line: 111*/ {
bevt_42_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_17));
bevl_gc.bemd_1(-541150916, bevt_42_ta_ph);
} /* Line: 112*/
bevt_44_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_18));
bevt_43_ta_ph = bevt_44_ta_ph.bemd_1(447224999, bevt_45_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_43_ta_ph).bevi_bool)/* Line: 114*/ {
bevt_46_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_19));
bevl_gc.bemd_1(-541150916, bevt_46_ta_ph);
} /* Line: 115*/
bevt_48_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_49_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_20));
bevt_47_ta_ph = bevt_48_ta_ph.bemd_1(447224999, bevt_49_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 117*/ {
bevt_50_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_21));
bevl_gc.bemd_1(-541150916, bevt_50_ta_ph);
} /* Line: 118*/
bevt_52_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_22));
bevt_51_ta_ph = bevt_52_ta_ph.bemd_1(447224999, bevt_53_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 120*/ {
bevt_54_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_23));
bevl_gc.bemd_1(-541150916, bevt_54_ta_ph);
} /* Line: 121*/
bevt_56_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_24));
bevt_55_ta_ph = bevt_56_ta_ph.bemd_1(447224999, bevt_57_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_55_ta_ph).bevi_bool)/* Line: 123*/ {
bevt_58_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_25));
bevl_gc.bemd_1(-541150916, bevt_58_ta_ph);
} /* Line: 125*/
bevt_60_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_26));
bevt_59_ta_ph = bevt_60_ta_ph.bemd_1(447224999, bevt_61_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 127*/ {
bevt_62_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_27));
bevl_gc.bemd_1(-541150916, bevt_62_ta_ph);
} /* Line: 128*/
bevt_64_ta_ph = bevl_gc.bemd_0(-433553307);
bevt_65_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_28));
bevt_63_ta_ph = bevt_64_ta_ph.bemd_1(447224999, bevt_65_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 130*/ {
bevt_66_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass8_bels_29));
bevl_gc.bemd_1(-541150916, bevt_66_ta_ph);
} /* Line: 131*/
bevt_67_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-1586086407, bevt_67_ta_ph);
bevt_69_ta_ph = beva_op.bemd_0(-1909241900);
bevt_70_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bemd_1(447224999, bevt_70_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_68_ta_ph).bevi_bool)/* Line: 135*/ {
bevt_72_ta_ph = beva_op.bemd_0(299463704);
bevt_73_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_5_BuildVisitPass8_bels_30));
bevt_71_ta_ph = bevt_72_ta_ph.bemd_1(447224999, bevt_73_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_71_ta_ph).bevi_bool)/* Line: 135*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 135*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 135*/
 else /* Line: 135*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 135*/ {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-1001444764, bevt_74_ta_ph);
} /* Line: 137*/
bevt_76_ta_ph = beva_op.bemd_0(-1909241900);
bevt_77_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bemd_1(447224999, bevt_77_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_75_ta_ph).bevi_bool)/* Line: 139*/ {
bevt_79_ta_ph = beva_op.bemd_0(299463704);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_5_BuildVisitPass8_bels_31));
bevt_78_ta_ph = bevt_79_ta_ph.bemd_1(447224999, bevt_80_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_78_ta_ph).bevi_bool)/* Line: 139*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 139*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 139*/
 else /* Line: 139*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 139*/ {
bevt_81_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(851735818, bevt_81_ta_ph);
} /* Line: 141*/
bevt_83_ta_ph = beva_op.bemd_0(-1909241900);
bevt_84_ta_ph = bevp_ntypes.bem_GET_METHODGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bemd_1(447224999, bevt_84_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 143*/ {
bevt_85_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_32));
bevp_build.bem_buildLiteral_2(beva_nx, bevt_85_ta_ph);
} /* Line: 144*/
bevt_86_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(395458646, bevt_86_ta_ph);
beva_op.bemd_1(2011791348, bevl_gc);
beva_pr.bemd_0(67754487);
beva_op.bemd_1(1553169033, beva_pr);
bevt_88_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_87_ta_ph = beva_prec.bemd_1(-1989431768, bevt_88_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_87_ta_ph).bevi_bool)/* Line: 150*/ {
beva_nx.bemd_0(67754487);
beva_op.bemd_1(1553169033, beva_nx);
} /* Line: 152*/
return beva_op;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 14, 18, 18, 19, 19, 19, 20, 20, 19, 22, 29, 29, 29, 29, 30, 31, 31, 33, 33, 33, 34, 34, 39, 40, 41, 43, 44, 44, 44, 44, 0, 0, 0, 44, 44, 0, 0, 0, 45, 45, 46, 47, 47, 48, 49, 49, 50, 50, 50, 51, 52, 52, 53, 58, 59, 59, 60, 60, 60, 62, 65, 66, 66, 67, 68, 68, 68, 69, 69, 70, 71, 71, 71, 72, 75, 80, 80, 84, 85, 85, 86, 86, 86, 86, 86, 87, 87, 87, 88, 88, 90, 90, 90, 91, 91, 93, 93, 93, 94, 94, 96, 96, 96, 97, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 109, 109, 111, 111, 111, 112, 112, 114, 114, 114, 115, 115, 117, 117, 117, 118, 118, 120, 120, 120, 121, 121, 123, 123, 123, 125, 125, 127, 127, 127, 128, 128, 130, 130, 130, 131, 131, 134, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 137, 137, 139, 139, 139, 139, 139, 139, 0, 0, 0, 141, 141, 143, 143, 143, 144, 144, 146, 146, 147, 148, 149, 150, 150, 151, 152, 154};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {46, 47, 57, 58, 59, 62, 63, 65, 66, 67, 73, 116, 117, 118, 123, 124, 125, 126, 128, 129, 130, 131, 136, 137, 138, 139, 140, 143, 148, 149, 154, 155, 158, 162, 165, 166, 168, 171, 175, 178, 179, 180, 181, 186, 187, 188, 193, 194, 195, 196, 198, 199, 204, 205, 210, 211, 216, 217, 218, 219, 222, 229, 230, 233, 235, 236, 237, 238, 240, 243, 245, 246, 247, 248, 249, 256, 263, 264, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 369, 370, 372, 373, 374, 376, 377, 379, 380, 381, 383, 384, 386, 387, 388, 390, 391, 393, 394, 395, 397, 398, 400, 401, 402, 404, 405, 407, 408, 409, 411, 412, 414, 415, 416, 418, 419, 421, 422, 423, 425, 426, 428, 429, 430, 432, 433, 435, 436, 437, 439, 440, 442, 443, 444, 446, 447, 449, 450, 451, 453, 454, 456, 457, 458, 460, 461, 463, 464, 465, 467, 468, 470, 471, 472, 473, 474, 476, 477, 478, 480, 483, 487, 490, 491, 493, 494, 495, 497, 498, 499, 501, 504, 508, 511, 512, 514, 515, 516, 518, 519, 521, 522, 523, 524, 525, 526, 527, 529, 530, 532};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 46
emitDataGet 0 14 46
addParsedClass 1 14 47
assign 1 18 57
new 0 18 57
assign 1 18 58
new 1 18 58
assign 1 19 59
new 0 19 59
assign 1 19 62
new 0 19 62
assign 1 19 63
lesser 1 19 63
assign 1 20 65
new 0 20 65
put 2 20 66
assign 1 19 67
increment 0 19 67
return 1 22 73
assign 1 29 116
typenameGet 0 29 116
assign 1 29 117
CLASSGet 0 29 117
assign 1 29 118
equals 1 29 123
acceptClass 1 30 124
assign 1 31 125
nextDescendGet 0 31 125
return 1 31 126
assign 1 33 128
operGet 0 33 128
assign 1 33 129
typenameGet 0 33 129
assign 1 33 130
get 1 33 130
assign 1 34 131
def 1 34 136
assign 1 39 137
containerGet 0 39 137
assign 1 40 138
prepOps 0 40 138
assign 1 41 139
assign 1 43 140
assign 1 44 143
def 1 44 148
assign 1 44 149
def 1 44 154
assign 1 0 155
assign 1 0 158
assign 1 0 162
assign 1 44 165
containerGet 0 44 165
assign 1 44 166
equals 1 44 166
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 45 178
get 1 45 178
addValue 1 45 179
assign 1 46 180
nextPeerGet 0 46 180
assign 1 47 181
def 1 47 186
assign 1 48 187
nextPeerGet 0 48 187
assign 1 49 188
def 1 49 193
assign 1 50 194
typenameGet 0 50 194
assign 1 50 195
COMMAGet 0 50 195
assign 1 50 196
equals 1 50 196
assign 1 51 198
nextPeerGet 0 51 198
assign 1 52 199
def 1 52 204
assign 1 53 205
nextPeerGet 0 53 205
assign 1 58 210
assign 1 59 211
def 1 59 216
assign 1 60 217
operGet 0 60 217
assign 1 60 218
typenameGet 0 60 218
assign 1 60 219
get 1 60 219
assign 1 62 222
assign 1 65 229
new 0 65 229
assign 1 66 230
iteratorGet 0 66 230
assign 1 66 233
hasNextGet 0 66 233
assign 1 67 235
nextGet 0 67 235
assign 1 68 236
lengthGet 0 68 236
assign 1 68 237
new 0 68 237
assign 1 68 238
greater 1 68 238
assign 1 69 240
iteratorGet 0 69 240
assign 1 69 243
hasNextGet 0 69 243
assign 1 70 245
nextGet 0 70 245
assign 1 71 246
priorPeerGet 0 71 246
assign 1 71 247
nextPeerGet 0 71 247
assign 1 71 248
callFromOper 4 71 248
assign 1 72 249
assign 1 75 256
increment 0 75 256
assign 1 80 263
nextDescendGet 0 80 263
return 1 80 264
assign 1 84 357
new 0 84 357
assign 1 85 358
new 0 85 358
wasOperSet 1 85 359
assign 1 86 360
operNamesGet 0 86 360
assign 1 86 361
typenameGet 0 86 361
assign 1 86 362
get 1 86 362
assign 1 86 363
lower 0 86 363
nameSet 1 86 364
assign 1 87 365
nameGet 0 87 365
assign 1 87 366
new 0 87 366
assign 1 87 367
equals 1 87 367
assign 1 88 369
new 0 88 369
nameSet 1 88 370
assign 1 90 372
nameGet 0 90 372
assign 1 90 373
new 0 90 373
assign 1 90 374
equals 1 90 374
assign 1 91 376
new 0 91 376
nameSet 1 91 377
assign 1 93 379
nameGet 0 93 379
assign 1 93 380
new 0 93 380
assign 1 93 381
equals 1 93 381
assign 1 94 383
new 0 94 383
nameSet 1 94 384
assign 1 96 386
nameGet 0 96 386
assign 1 96 387
new 0 96 387
assign 1 96 388
equals 1 96 388
assign 1 97 390
new 0 97 390
nameSet 1 97 391
assign 1 99 393
nameGet 0 99 393
assign 1 99 394
new 0 99 394
assign 1 99 395
equals 1 99 395
assign 1 100 397
new 0 100 397
nameSet 1 100 398
assign 1 102 400
nameGet 0 102 400
assign 1 102 401
new 0 102 401
assign 1 102 402
equals 1 102 402
assign 1 103 404
new 0 103 404
nameSet 1 103 405
assign 1 105 407
nameGet 0 105 407
assign 1 105 408
new 0 105 408
assign 1 105 409
equals 1 105 409
assign 1 106 411
new 0 106 411
nameSet 1 106 412
assign 1 108 414
nameGet 0 108 414
assign 1 108 415
new 0 108 415
assign 1 108 416
equals 1 108 416
assign 1 109 418
new 0 109 418
nameSet 1 109 419
assign 1 111 421
nameGet 0 111 421
assign 1 111 422
new 0 111 422
assign 1 111 423
equals 1 111 423
assign 1 112 425
new 0 112 425
nameSet 1 112 426
assign 1 114 428
nameGet 0 114 428
assign 1 114 429
new 0 114 429
assign 1 114 430
equals 1 114 430
assign 1 115 432
new 0 115 432
nameSet 1 115 433
assign 1 117 435
nameGet 0 117 435
assign 1 117 436
new 0 117 436
assign 1 117 437
equals 1 117 437
assign 1 118 439
new 0 118 439
nameSet 1 118 440
assign 1 120 442
nameGet 0 120 442
assign 1 120 443
new 0 120 443
assign 1 120 444
equals 1 120 444
assign 1 121 446
new 0 121 446
nameSet 1 121 447
assign 1 123 449
nameGet 0 123 449
assign 1 123 450
new 0 123 450
assign 1 123 451
equals 1 123 451
assign 1 125 453
new 0 125 453
nameSet 1 125 454
assign 1 127 456
nameGet 0 127 456
assign 1 127 457
new 0 127 457
assign 1 127 458
equals 1 127 458
assign 1 128 460
new 0 128 460
nameSet 1 128 461
assign 1 130 463
nameGet 0 130 463
assign 1 130 464
new 0 130 464
assign 1 130 465
equals 1 130 465
assign 1 131 467
new 0 131 467
nameSet 1 131 468
assign 1 134 470
new 0 134 470
wasBoundSet 1 134 471
assign 1 135 472
typenameGet 0 135 472
assign 1 135 473
ASSIGNGet 0 135 473
assign 1 135 474
equals 1 135 474
assign 1 135 476
heldGet 0 135 476
assign 1 135 477
new 0 135 477
assign 1 135 478
equals 1 135 478
assign 1 0 480
assign 1 0 483
assign 1 0 487
assign 1 137 490
new 0 137 490
isOnceSet 1 137 491
assign 1 139 493
typenameGet 0 139 493
assign 1 139 494
ASSIGNGet 0 139 494
assign 1 139 495
equals 1 139 495
assign 1 139 497
heldGet 0 139 497
assign 1 139 498
new 0 139 498
assign 1 139 499
equals 1 139 499
assign 1 0 501
assign 1 0 504
assign 1 0 508
assign 1 141 511
new 0 141 511
isManySet 1 141 512
assign 1 143 514
typenameGet 0 143 514
assign 1 143 515
GET_METHODGet 0 143 515
assign 1 143 516
equals 1 143 516
assign 1 144 518
new 0 144 518
buildLiteral 2 144 519
assign 1 146 521
CALLGet 0 146 521
typenameSet 1 146 522
heldSet 1 147 523
delete 0 148 524
addValue 1 149 525
assign 1 150 526
new 0 150 526
assign 1 150 527
greater 1 150 527
delete 0 151 529
addValue 1 152 530
return 1 154 532
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1938521961: return bem_create_0();
case 1428196909: return bem_deserializeClassNameGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case 1469761457: return bem_serializeToString_0();
case -1120775249: return bem_classNameGet_0();
case 474962230: return bem_buildGetDirect_0();
case -559654393: return bem_sourceFileNameGet_0();
case 976077722: return bem_new_0();
case -1359840989: return bem_toAny_0();
case -129765629: return bem_print_0();
case -1677294751: return bem_hashGet_0();
case -1660007365: return bem_iteratorGet_0();
case 126164297: return bem_serializationIteratorGet_0();
case -1640020074: return bem_toString_0();
case 1285405295: return bem_transGetDirect_0();
case -374496050: return bem_tagGet_0();
case 2069874486: return bem_constGetDirect_0();
case -1530492540: return bem_many_0();
case 921209725: return bem_echo_0();
case -1606863806: return bem_fieldIteratorGet_0();
case 1342564574: return bem_ntypesGet_0();
case 1323621667: return bem_prepOps_0();
case 918163558: return bem_buildGet_0();
case -489715464: return bem_ntypesGetDirect_0();
case -1483834827: return bem_copy_0();
case 2028199664: return bem_once_0();
case 1963846645: return bem_serializeContents_0();
case 78342517: return bem_transGet_0();
case -1451184761: return bem_constGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -943060017: return bem_ntypesSetDirect_1(bevd_0);
case 1414981672: return bem_defined_1(bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case 175516239: return bem_end_1(bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1233102724: return bem_begin_1(bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case -872100885: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1838687907: return bem_buildSetDirect_1(bevd_0);
case 1251610635: return bem_transSet_1(bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case 232561331: return bem_buildSet_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case 1662145724: return bem_constSetDirect_1(bevd_0);
case -1168795021: return bem_ntypesSet_1(bevd_0);
case -1400768154: return bem_constSet_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1383582564: return bem_transSetDirect_1(bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case 934026839: return bem_acceptClass_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1789648416: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 668414825: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass8_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass8_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass8();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst = (BEC_3_5_5_5_BuildVisitPass8) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;
}
}
