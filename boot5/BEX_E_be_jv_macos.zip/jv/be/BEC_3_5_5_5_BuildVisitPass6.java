package be;
/* IO:File: source/build/Pass6.be */
public final class BEC_3_5_5_5_BuildVisitPass6 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_5_BuildVisitPass6_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_5_BuildVisitPass6_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_0 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_1 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_2 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_3 = {0x5F};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_4 = {0x74,0x68,0x69,0x73};
public static BEC_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;

public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_38_ta_ph = null;
BEC_2_5_4_BuildNode bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_5_4_BuildEmit bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_5_6_BuildIfEmit bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_5_4_LogicBool bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_5_4_LogicBool bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_5_4_BuildNode bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
BEC_2_5_4_LogicBool bevt_102_ta_ph = null;
BEC_2_4_3_MathInt bevt_103_ta_ph = null;
BEC_2_6_6_SystemObject bevt_104_ta_ph = null;
BEC_2_6_6_SystemObject bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_6_6_SystemObject bevt_108_ta_ph = null;
BEC_2_4_3_MathInt bevt_109_ta_ph = null;
BEC_2_4_3_MathInt bevt_110_ta_ph = null;
BEC_2_6_6_SystemObject bevt_111_ta_ph = null;
BEC_2_6_6_SystemObject bevt_112_ta_ph = null;
BEC_2_6_6_SystemObject bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_4_3_MathInt bevt_115_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_6_6_SystemObject bevt_118_ta_ph = null;
BEC_2_6_6_SystemObject bevt_119_ta_ph = null;
BEC_2_4_3_MathInt bevt_120_ta_ph = null;
BEC_2_6_6_SystemObject bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_6_6_SystemObject bevt_123_ta_ph = null;
BEC_2_6_6_SystemObject bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_6_6_SystemObject bevt_126_ta_ph = null;
BEC_2_6_6_SystemObject bevt_127_ta_ph = null;
BEC_2_6_6_SystemObject bevt_128_ta_ph = null;
BEC_2_6_6_SystemObject bevt_129_ta_ph = null;
BEC_2_4_3_MathInt bevt_130_ta_ph = null;
BEC_2_6_6_SystemObject bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_6_6_SystemObject bevt_133_ta_ph = null;
BEC_2_6_6_SystemObject bevt_134_ta_ph = null;
BEC_2_6_6_SystemObject bevt_135_ta_ph = null;
BEC_2_6_6_SystemObject bevt_136_ta_ph = null;
BEC_2_6_6_SystemObject bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
BEC_2_4_6_TextString bevt_139_ta_ph = null;
BEC_2_6_6_SystemObject bevt_140_ta_ph = null;
BEC_2_5_4_LogicBool bevt_141_ta_ph = null;
BEC_2_6_6_SystemObject bevt_142_ta_ph = null;
BEC_2_5_4_LogicBool bevt_143_ta_ph = null;
BEC_2_6_6_SystemObject bevt_144_ta_ph = null;
BEC_2_5_4_LogicBool bevt_145_ta_ph = null;
BEC_2_6_6_SystemObject bevt_146_ta_ph = null;
BEC_2_6_6_SystemObject bevt_147_ta_ph = null;
BEC_2_4_6_TextString bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_6_6_SystemObject bevt_150_ta_ph = null;
BEC_2_6_6_SystemObject bevt_151_ta_ph = null;
BEC_2_6_6_SystemObject bevt_152_ta_ph = null;
BEC_2_4_6_TextString bevt_153_ta_ph = null;
BEC_2_6_6_SystemObject bevt_154_ta_ph = null;
BEC_2_5_4_LogicBool bevt_155_ta_ph = null;
BEC_2_6_6_SystemObject bevt_156_ta_ph = null;
BEC_2_5_4_LogicBool bevt_157_ta_ph = null;
BEC_2_5_3_BuildVar bevt_158_ta_ph = null;
BEC_2_6_6_SystemObject bevt_159_ta_ph = null;
BEC_2_5_4_LogicBool bevt_160_ta_ph = null;
BEC_2_6_6_SystemObject bevt_161_ta_ph = null;
BEC_2_5_4_LogicBool bevt_162_ta_ph = null;
BEC_2_6_6_SystemObject bevt_163_ta_ph = null;
BEC_2_5_4_LogicBool bevt_164_ta_ph = null;
BEC_2_6_6_SystemObject bevt_165_ta_ph = null;
BEC_2_5_4_LogicBool bevt_166_ta_ph = null;
BEC_2_6_6_SystemObject bevt_167_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_168_ta_ph = null;
BEC_2_4_6_TextString bevt_169_ta_ph = null;
BEC_2_6_6_SystemObject bevt_170_ta_ph = null;
BEC_2_6_6_SystemObject bevt_171_ta_ph = null;
BEC_2_6_6_SystemObject bevt_172_ta_ph = null;
BEC_2_6_6_SystemObject bevt_173_ta_ph = null;
BEC_2_6_6_SystemObject bevt_174_ta_ph = null;
BEC_2_5_4_BuildNode bevt_175_ta_ph = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 21*/ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_ta_ph = beva_node.bem_containedGet_0();
if (bevt_12_ta_ph == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_15_ta_ph = beva_node.bem_containedGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_lengthGet_0();
bevt_16_ta_ph = bece_BEC_3_5_5_5_BuildVisitPass6_bevo_0;
if (bevt_14_ta_ph.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_20_ta_ph = beva_node.bem_containedGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_firstGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(279606262);
if (bevt_18_ta_ph == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_25_ta_ph = beva_node.bem_containedGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_firstGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_0(279606262);
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(245797063);
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(-1989431768, bevt_26_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_30_ta_ph = beva_node.bem_secondGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bem_containedGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_lengthGet_0();
bevt_31_ta_ph = bece_BEC_3_5_5_5_BuildVisitPass6_bevo_1;
if (bevt_28_ta_ph.bevi_int > bevt_31_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 23*/ {
bevl_langs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_ta_ph = beva_node.bem_containedGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(279606262);
bevt_0_ta_loop = bevt_32_ta_ph.bemd_0(-1660007365);
while (true)
/* Line: 26*/ {
bevt_35_ta_ph = bevt_0_ta_loop.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_35_ta_ph).bevi_bool)/* Line: 26*/ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_ta_loop.bemd_0(-190996314);
bevt_36_ta_ph = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_ta_ph);
} /* Line: 28*/
 else /* Line: 26*/ {
break;
} /* Line: 26*/
} /* Line: 26*/
bevt_37_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_37_ta_ph);
bevl_doit = be.BECS_Runtime.boolTrue;
if (((BEC_2_5_4_LogicBool) bevl_doit).bevi_bool)/* Line: 32*/ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_39_ta_ph = beva_node.bem_secondGet_0();
bevt_38_ta_ph = bevt_39_ta_ph.bem_containedGet_0();
bevl_i = bevt_38_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 34*/ {
bevt_40_ta_ph = bevl_i.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 34*/ {
bevl_si = bevl_i.bemd_0(-190996314);
bevt_42_ta_ph = bevl_si.bemd_0(-1909241900);
bevt_43_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(447224999, bevt_43_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 36*/ {
bevt_44_ta_ph = bevl_si.bemd_0(299463704);
beva_node.bem_heldSet_1(bevt_44_ta_ph);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 40*/
} /* Line: 36*/
 else /* Line: 34*/ {
break;
} /* Line: 34*/
} /* Line: 34*/
} /* Line: 34*/
bevt_45_ta_ph = bevl_doit.bemd_0(1952167229);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 44*/ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 46*/
beva_node.bem_containedSet_1(null);
bevt_47_ta_ph = beva_node.bem_heldGet_0();
bevt_46_ta_ph = (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_ta_ph , bevl_langs);
beva_node.bem_heldSet_1(bevt_46_ta_ph);
} /* Line: 49*/
 else /* Line: 50*/ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 52*/
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_ta_ph = bevl_snode.bemd_0(-1909241900);
bevt_50_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_48_ta_ph = bevt_49_ta_ph.bemd_1(447224999, bevt_50_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 56*/ {
bevl_snode = null;
} /* Line: 57*/
if (bevl_snode == null) {
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 60*/ {
beva_node.bem_delete_0();
bevt_52_ta_ph = bevl_snode.bemd_0(299463704);
bevt_52_ta_ph.bemd_1(-1119963179, beva_node);
} /* Line: 62*/
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 65*/
 else /* Line: 21*/ {
bevt_54_ta_ph = beva_node.bem_typenameGet_0();
bevt_55_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_ta_ph.bevi_int == bevt_55_ta_ph.bevi_int) {
bevt_53_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_53_ta_ph.bevi_bool)/* Line: 66*/ {
bevl_langs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_ta_ph = beva_node.bem_containedGet_0();
bevt_57_ta_ph = bevt_58_ta_ph.bem_firstGet_0();
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(279606262);
bevt_1_ta_loop = bevt_56_ta_ph.bemd_0(-1660007365);
while (true)
/* Line: 69*/ {
bevt_59_ta_ph = bevt_1_ta_loop.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 69*/ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_ta_loop.bemd_0(-190996314);
bevt_60_ta_ph = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_ta_ph);
bevl_toremove.bemd_1(1553169033, bevl_lang);
} /* Line: 72*/
 else /* Line: 69*/ {
break;
} /* Line: 69*/
} /* Line: 69*/
bevt_61_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_61_ta_ph);
bevt_63_ta_ph = beva_node.bem_heldGet_0();
bevt_62_ta_ph = (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_ta_ph );
beva_node.bem_heldSet_1(bevt_62_ta_ph);
bevl_ii = bevl_toremove.bemd_0(-1660007365);
while (true)
/* Line: 76*/ {
bevt_64_ta_ph = bevl_ii.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 76*/ {
bevl_i = bevl_ii.bemd_0(-190996314);
bevl_i.bemd_0(67754487);
} /* Line: 78*/
 else /* Line: 76*/ {
break;
} /* Line: 76*/
} /* Line: 76*/
} /* Line: 76*/
 else /* Line: 21*/ {
bevt_66_ta_ph = beva_node.bem_typenameGet_0();
bevt_67_ta_ph = bevp_ntypes.bem_IFGet_0();
if (bevt_66_ta_ph.bevi_int == bevt_67_ta_ph.bevi_int) {
bevt_65_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_65_ta_ph.bevi_bool)/* Line: 80*/ {
if (bevl_nnode == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 81*/ {
bevl_lnode = beva_node;
while (true)
/* Line: 83*/ {
if (bevl_nnode == null) {
bevt_69_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_69_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_71_ta_ph = bevl_nnode.bemd_0(-1909241900);
bevt_72_ta_ph = bevp_ntypes.bem_ELIFGet_0();
bevt_70_ta_ph = bevt_71_ta_ph.bemd_1(447224999, bevt_72_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_70_ta_ph).bevi_bool)/* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 83*/
 else /* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 83*/ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(395458646, bevt_73_ta_ph);
bevl_enode.bemd_1(2062632843, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(2062632843, beva_node);
bevt_74_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(395458646, bevt_74_ta_ph);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(2062632843, beva_node);
bevt_75_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(395458646, bevt_75_ta_ph);
bevl_brnode.bemd_1(1553169033, bevl_inode);
bevl_enode.bemd_1(1553169033, bevl_brnode);
bevt_77_ta_ph = bevl_nnode.bemd_0(279606262);
if (bevt_77_ta_ph == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_78_ta_ph = bevl_nnode.bemd_0(279606262);
bevl_i = bevt_78_ta_ph.bemd_0(-1660007365);
while (true)
/* Line: 96*/ {
bevt_79_ta_ph = bevl_i.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_79_ta_ph).bevi_bool)/* Line: 96*/ {
bevt_80_ta_ph = bevl_i.bemd_0(-190996314);
bevl_inode.bemd_1(1553169033, bevt_80_ta_ph);
} /* Line: 97*/
 else /* Line: 96*/ {
break;
} /* Line: 96*/
} /* Line: 96*/
} /* Line: 96*/
bevl_lnode.bemd_1(1553169033, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(-1444894676);
bevl_nnode.bemd_0(67754487);
bevl_nnode = bevl_nxnode;
} /* Line: 108*/
 else /* Line: 83*/ {
break;
} /* Line: 83*/
} /* Line: 83*/
if (bevl_nnode == null) {
bevt_81_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_81_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_83_ta_ph = bevl_nnode.bemd_0(-1909241900);
bevt_84_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bemd_1(447224999, bevt_84_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 110*/
 else /* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 110*/ {
bevl_nnode.bemd_0(67754487);
bevl_lnode.bemd_1(1553169033, bevl_nnode);
} /* Line: 112*/
} /* Line: 110*/
bevt_85_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_85_ta_ph;
} /* Line: 115*/
 else /* Line: 21*/ {
bevt_87_ta_ph = beva_node.bem_typenameGet_0();
bevt_88_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_ta_ph.bevi_int == bevt_88_ta_ph.bevi_int) {
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 116*/ {
bevt_89_ta_ph = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_ta_ph.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(2062632843, beva_node);
bevt_90_ta_ph = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(395458646, bevt_90_ta_ph);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevl_nd.bemd_1(2011791348, bevt_91_ta_ph);
bevl_parens.bemd_1(1669544691, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_ta_ph = bevl_parens.bemd_0(279606262);
bevl_ii = bevt_92_ta_ph.bemd_0(-1660007365);
while (true)
/* Line: 125*/ {
bevt_93_ta_ph = bevl_ii.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_93_ta_ph).bevi_bool)/* Line: 125*/ {
bevl_i = bevl_ii.bemd_0(-190996314);
bevl_ix = bevl_i.bemd_0(-1444894676);
bevt_95_ta_ph = bevl_i.bemd_0(-1909241900);
bevt_96_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_94_ta_ph = bevt_95_ta_ph.bemd_1(447224999, bevt_96_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_94_ta_ph).bevi_bool)/* Line: 130*/ {
bevl_toremove.bemd_1(1553169033, bevl_i);
} /* Line: 131*/
 else /* Line: 130*/ {
bevt_98_ta_ph = bevl_i.bemd_0(-1909241900);
bevt_99_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_97_ta_ph = bevt_98_ta_ph.bemd_1(447224999, bevt_99_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 132*/ {
bevt_100_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(68397535, bevt_100_ta_ph);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_ta_ph = bevl_i.bemd_0(299463704);
bevl_v.bemd_1(-541150916, bevt_101_ta_ph);
bevt_102_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1208193110, bevt_102_ta_ph);
bevl_i.bemd_1(2011791348, bevl_v);
bevt_103_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(395458646, bevt_103_ta_ph);
bevl_i.bemd_0(-361561388);
} /* Line: 139*/
 else /* Line: 130*/ {
bevt_105_ta_ph = bevl_i.bemd_0(-1909241900);
bevt_106_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_104_ta_ph = bevt_105_ta_ph.bemd_1(447224999, bevt_106_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_104_ta_ph).bevi_bool)/* Line: 140*/ {
bevt_108_ta_ph = bevl_ix.bemd_0(-1909241900);
bevt_109_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_107_ta_ph = bevt_108_ta_ph.bemd_1(447224999, bevt_109_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 141*/ {
bevt_110_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(68397535, bevt_110_ta_ph);
bevt_111_ta_ph = bevl_i.bemd_0(299463704);
bevt_112_ta_ph = bevl_ix.bemd_0(299463704);
bevt_111_ta_ph.bemd_1(-541150916, bevt_112_ta_ph);
bevt_113_ta_ph = bevl_i.bemd_0(299463704);
bevt_114_ta_ph = be.BECS_Runtime.boolTrue;
bevt_113_ta_ph.bemd_1(-1208193110, bevt_114_ta_ph);
bevl_i.bemd_0(-361561388);
bevt_115_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(395458646, bevt_115_ta_ph);
} /* Line: 146*/
 else /* Line: 147*/ {
bevt_117_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevt_116_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_ta_ph, bevl_i);
throw new be.BECS_ThrowBack(bevt_116_ta_ph);
} /* Line: 148*/
} /* Line: 141*/
} /* Line: 130*/
} /* Line: 130*/
} /* Line: 130*/
 else /* Line: 125*/ {
break;
} /* Line: 125*/
} /* Line: 125*/
bevl_ii = bevl_toremove.bemd_0(-1660007365);
while (true)
/* Line: 152*/ {
bevt_118_ta_ph = bevl_ii.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_118_ta_ph).bevi_bool)/* Line: 152*/ {
bevl_i = bevl_ii.bemd_0(-190996314);
bevl_i.bemd_0(67754487);
} /* Line: 154*/
 else /* Line: 152*/ {
break;
} /* Line: 152*/
} /* Line: 152*/
bevl_s = beva_node.bem_heldGet_0();
bevt_120_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_119_ta_ph = bevl_numargs.bemd_1(-2094792806, bevt_120_ta_ph);
bevl_s.bemd_1(-94168706, bevt_119_ta_ph);
bevt_121_ta_ph = bevl_s.bemd_0(-433553307);
bevl_s.bemd_1(-1827165896, bevt_121_ta_ph);
bevt_124_ta_ph = bevl_s.bemd_0(-433553307);
bevt_125_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_3));
bevt_123_ta_ph = bevt_124_ta_ph.bemd_1(68397535, bevt_125_ta_ph);
bevt_127_ta_ph = bevl_s.bemd_0(908350952);
bevt_126_ta_ph = bevt_127_ta_ph.bemd_0(-1640020074);
bevt_122_ta_ph = bevt_123_ta_ph.bemd_1(68397535, bevt_126_ta_ph);
bevl_s.bemd_1(-541150916, bevt_122_ta_ph);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_ta_ph = bevl_i.bemd_0(-1909241900);
bevt_130_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_128_ta_ph = bevt_129_ta_ph.bemd_1(447224999, bevt_130_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_128_ta_ph).bevi_bool)/* Line: 161*/ {
bevl_i.bemd_0(-1660501292);
bevt_131_ta_ph = bevl_i.bemd_0(299463704);
bevl_s.bemd_1(-409799289, bevt_131_ta_ph);
bevt_134_ta_ph = bevl_s.bemd_0(-642658547);
bevt_133_ta_ph = bevt_134_ta_ph.bemd_0(-1020099819);
if (bevt_133_ta_ph == null) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 165*/ {
bevl_s.bemd_1(-409799289, null);
} /* Line: 167*/
 else /* Line: 165*/ {
bevt_138_ta_ph = bevl_s.bemd_0(-642658547);
bevt_137_ta_ph = bevt_138_ta_ph.bemd_0(-1020099819);
bevt_136_ta_ph = bevt_137_ta_ph.bemd_0(-1640020074);
bevt_139_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_4));
bevt_135_ta_ph = bevt_136_ta_ph.bemd_1(447224999, bevt_139_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_135_ta_ph).bevi_bool)/* Line: 168*/ {
bevt_140_ta_ph = bevl_s.bemd_0(-642658547);
bevt_141_ta_ph = be.BECS_Runtime.boolTrue;
bevt_140_ta_ph.bemd_1(276169561, bevt_141_ta_ph);
bevt_142_ta_ph = bevl_s.bemd_0(-642658547);
bevt_143_ta_ph = be.BECS_Runtime.boolTrue;
bevt_142_ta_ph.bemd_1(-203299974, bevt_143_ta_ph);
bevt_144_ta_ph = bevl_s.bemd_0(-642658547);
bevt_145_ta_ph = be.BECS_Runtime.boolTrue;
bevt_144_ta_ph.bemd_1(513511634, bevt_145_ta_ph);
bevt_147_ta_ph = bevl_s.bemd_0(-642658547);
bevt_146_ta_ph = bevt_147_ta_ph.bemd_0(-1020099819);
bevt_148_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_146_ta_ph.bemd_1(1300903399, bevt_148_ta_ph);
} /* Line: 173*/
 else /* Line: 165*/ {
bevt_152_ta_ph = bevl_s.bemd_0(-642658547);
bevt_151_ta_ph = bevt_152_ta_ph.bemd_0(-1020099819);
bevt_150_ta_ph = bevt_151_ta_ph.bemd_0(-1640020074);
bevt_153_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_149_ta_ph = bevt_150_ta_ph.bemd_1(447224999, bevt_153_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_149_ta_ph).bevi_bool)/* Line: 174*/ {
bevt_154_ta_ph = bevl_s.bemd_0(-642658547);
bevt_155_ta_ph = be.BECS_Runtime.boolTrue;
bevt_154_ta_ph.bemd_1(276169561, bevt_155_ta_ph);
bevt_156_ta_ph = bevl_s.bemd_0(-642658547);
bevt_157_ta_ph = be.BECS_Runtime.boolTrue;
bevt_156_ta_ph.bemd_1(-203299974, bevt_157_ta_ph);
} /* Line: 176*/
} /* Line: 165*/
} /* Line: 165*/
bevl_i.bemd_0(67754487);
} /* Line: 178*/
 else /* Line: 179*/ {
bevt_158_ta_ph = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(-409799289, bevt_158_ta_ph);
bevt_159_ta_ph = bevl_s.bemd_0(-642658547);
bevt_160_ta_ph = be.BECS_Runtime.boolTrue;
bevt_159_ta_ph.bemd_1(276169561, bevt_160_ta_ph);
bevt_161_ta_ph = bevl_s.bemd_0(-642658547);
bevt_162_ta_ph = be.BECS_Runtime.boolTrue;
bevt_161_ta_ph.bemd_1(-203299974, bevt_162_ta_ph);
bevt_163_ta_ph = bevl_s.bemd_0(-642658547);
bevt_164_ta_ph = be.BECS_Runtime.boolTrue;
bevt_163_ta_ph.bemd_1(513511634, bevt_164_ta_ph);
bevt_165_ta_ph = bevl_s.bemd_0(-642658547);
bevt_166_ta_ph = be.BECS_Runtime.boolTrue;
bevt_165_ta_ph.bemd_1(-72717444, bevt_166_ta_ph);
bevt_167_ta_ph = bevl_s.bemd_0(-642658547);
bevt_169_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_168_ta_ph = (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_169_ta_ph);
bevt_167_ta_ph.bemd_1(-234180349, bevt_168_ta_ph);
} /* Line: 185*/
bevl_clnode = beva_node.bem_classGet_0();
bevt_171_ta_ph = bevl_clnode.bemd_0(299463704);
bevt_170_ta_ph = bevt_171_ta_ph.bemd_0(-2071858757);
bevt_172_ta_ph = bevl_s.bemd_0(-433553307);
bevt_170_ta_ph.bemd_2(-1350687310, bevt_172_ta_ph, beva_node);
bevt_174_ta_ph = bevl_clnode.bemd_0(299463704);
bevt_173_ta_ph = bevt_174_ta_ph.bemd_0(422773807);
bevt_173_ta_ph.bemd_1(1553169033, beva_node);
} /* Line: 189*/
} /* Line: 21*/
} /* Line: 21*/
} /* Line: 21*/
bevt_175_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_175_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 20, 21, 21, 21, 21, 22, 23, 23, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 25, 26, 26, 26, 26, 0, 26, 26, 28, 28, 30, 30, 31, 33, 34, 34, 34, 34, 35, 36, 36, 36, 37, 37, 40, 44, 45, 46, 48, 49, 49, 49, 51, 52, 55, 56, 56, 56, 57, 60, 60, 61, 62, 62, 65, 66, 66, 66, 66, 67, 68, 69, 69, 69, 69, 0, 69, 69, 71, 71, 72, 74, 74, 75, 75, 75, 76, 76, 77, 78, 80, 80, 80, 80, 81, 81, 82, 83, 83, 83, 83, 83, 0, 0, 0, 84, 85, 85, 86, 87, 88, 89, 89, 90, 91, 92, 92, 93, 94, 95, 95, 95, 96, 96, 96, 97, 97, 104, 105, 106, 107, 108, 110, 110, 110, 110, 110, 0, 0, 0, 111, 112, 115, 115, 116, 116, 116, 116, 117, 117, 118, 119, 120, 120, 121, 121, 122, 123, 124, 125, 125, 125, 126, 127, 130, 130, 130, 131, 132, 132, 132, 133, 133, 134, 135, 135, 136, 136, 137, 138, 138, 139, 140, 140, 140, 141, 141, 141, 142, 142, 143, 143, 143, 144, 144, 144, 145, 146, 146, 148, 148, 148, 152, 152, 153, 154, 156, 157, 157, 157, 158, 158, 159, 159, 159, 159, 159, 159, 159, 160, 161, 161, 161, 162, 164, 164, 165, 165, 165, 165, 167, 168, 168, 168, 168, 168, 170, 170, 170, 171, 171, 171, 172, 172, 172, 173, 173, 173, 173, 174, 174, 174, 174, 174, 175, 175, 175, 176, 176, 176, 178, 180, 180, 181, 181, 181, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 185, 187, 188, 188, 188, 188, 189, 189, 189, 191, 191};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {219, 220, 221, 222, 223, 228, 229, 230, 231, 236, 237, 238, 239, 240, 245, 246, 249, 253, 256, 257, 258, 259, 264, 265, 268, 272, 275, 276, 277, 278, 279, 280, 282, 285, 289, 292, 293, 294, 295, 296, 301, 302, 305, 309, 312, 313, 314, 315, 316, 316, 319, 321, 322, 323, 329, 330, 331, 333, 334, 335, 336, 339, 341, 342, 343, 344, 346, 347, 348, 356, 358, 359, 361, 362, 363, 364, 367, 368, 370, 371, 372, 373, 375, 377, 382, 383, 384, 385, 387, 390, 391, 392, 397, 398, 399, 400, 401, 402, 403, 403, 406, 408, 409, 410, 411, 417, 418, 419, 420, 421, 422, 425, 427, 428, 436, 437, 438, 443, 444, 449, 450, 453, 458, 459, 460, 461, 463, 466, 470, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 493, 494, 495, 498, 500, 501, 508, 509, 510, 511, 512, 518, 523, 524, 525, 526, 528, 531, 535, 538, 539, 542, 543, 546, 547, 548, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 569, 571, 572, 573, 574, 575, 577, 580, 581, 582, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 597, 598, 599, 601, 602, 603, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 618, 619, 620, 630, 633, 635, 636, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 660, 661, 662, 663, 664, 665, 670, 671, 674, 675, 676, 677, 678, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 695, 696, 697, 698, 699, 701, 702, 703, 704, 705, 706, 710, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 732, 733, 734, 735, 736, 737, 738, 739, 744, 745};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
resolveNp 0 17 219
assign 1 20 220
nextPeerGet 0 20 220
assign 1 21 221
typenameGet 0 21 221
assign 1 21 222
EMITGet 0 21 222
assign 1 21 223
equals 1 21 228
assign 1 22 229
nextAscendGet 0 22 229
assign 1 23 230
containedGet 0 23 230
assign 1 23 231
def 1 23 236
assign 1 23 237
containedGet 0 23 237
assign 1 23 238
lengthGet 0 23 238
assign 1 23 239
new 0 23 239
assign 1 23 240
greater 1 23 245
assign 1 0 246
assign 1 0 249
assign 1 0 253
assign 1 23 256
containedGet 0 23 256
assign 1 23 257
firstGet 0 23 257
assign 1 23 258
containedGet 0 23 258
assign 1 23 259
def 1 23 264
assign 1 0 265
assign 1 0 268
assign 1 0 272
assign 1 23 275
containedGet 0 23 275
assign 1 23 276
firstGet 0 23 276
assign 1 23 277
containedGet 0 23 277
assign 1 23 278
lengthGet 0 23 278
assign 1 23 279
new 0 23 279
assign 1 23 280
greater 1 23 280
assign 1 0 282
assign 1 0 285
assign 1 0 289
assign 1 23 292
secondGet 0 23 292
assign 1 23 293
containedGet 0 23 293
assign 1 23 294
lengthGet 0 23 294
assign 1 23 295
new 0 23 295
assign 1 23 296
greater 1 23 301
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 25 312
new 0 25 312
assign 1 26 313
containedGet 0 26 313
assign 1 26 314
firstGet 0 26 314
assign 1 26 315
containedGet 0 26 315
assign 1 26 316
iteratorGet 0 0 316
assign 1 26 319
hasNextGet 0 26 319
assign 1 26 321
nextGet 0 26 321
assign 1 28 322
heldGet 0 28 322
addValue 1 28 323
assign 1 30 329
new 0 30 329
delete 1 30 330
assign 1 31 331
new 0 31 331
assign 1 33 333
new 0 33 333
assign 1 34 334
secondGet 0 34 334
assign 1 34 335
containedGet 0 34 335
assign 1 34 336
iteratorGet 0 34 336
assign 1 34 339
hasNextGet 0 34 339
assign 1 35 341
nextGet 0 35 341
assign 1 36 342
typenameGet 0 36 342
assign 1 36 343
STRINGLGet 0 36 343
assign 1 36 344
equals 1 36 344
assign 1 37 346
heldGet 0 37 346
heldSet 1 37 347
assign 1 40 348
new 0 40 348
assign 1 44 356
not 0 44 356
delete 0 45 358
return 1 46 359
containedSet 1 48 361
assign 1 49 362
heldGet 0 49 362
assign 1 49 363
new 2 49 363
heldSet 1 49 364
delete 0 51 367
return 1 52 368
assign 1 55 370
scopeGet 0 55 370
assign 1 56 371
typenameGet 0 56 371
assign 1 56 372
METHODGet 0 56 372
assign 1 56 373
equals 1 56 373
assign 1 57 375
assign 1 60 377
def 1 60 382
delete 0 61 383
assign 1 62 384
heldGet 0 62 384
addEmit 1 62 385
return 1 65 387
assign 1 66 390
typenameGet 0 66 390
assign 1 66 391
IFEMITGet 0 66 391
assign 1 66 392
equals 1 66 397
assign 1 67 398
new 0 67 398
assign 1 68 399
new 0 68 399
assign 1 69 400
containedGet 0 69 400
assign 1 69 401
firstGet 0 69 401
assign 1 69 402
containedGet 0 69 402
assign 1 69 403
iteratorGet 0 0 403
assign 1 69 406
hasNextGet 0 69 406
assign 1 69 408
nextGet 0 69 408
assign 1 71 409
heldGet 0 71 409
addValue 1 71 410
addValue 1 72 411
assign 1 74 417
new 0 74 417
delete 1 74 418
assign 1 75 419
heldGet 0 75 419
assign 1 75 420
new 2 75 420
heldSet 1 75 421
assign 1 76 422
iteratorGet 0 76 422
assign 1 76 425
hasNextGet 0 76 425
assign 1 77 427
nextGet 0 77 427
delete 0 78 428
assign 1 80 436
typenameGet 0 80 436
assign 1 80 437
IFGet 0 80 437
assign 1 80 438
equals 1 80 443
assign 1 81 444
def 1 81 449
assign 1 82 450
assign 1 83 453
def 1 83 458
assign 1 83 459
typenameGet 0 83 459
assign 1 83 460
ELIFGet 0 83 460
assign 1 83 461
equals 1 83 461
assign 1 0 463
assign 1 0 466
assign 1 0 470
assign 1 84 473
new 1 84 473
assign 1 85 474
ELSEGet 0 85 474
typenameSet 1 85 475
copyLoc 1 86 476
assign 1 87 477
new 1 87 477
copyLoc 1 88 478
assign 1 89 479
BRACESGet 0 89 479
typenameSet 1 89 480
assign 1 90 481
new 1 90 481
copyLoc 1 91 482
assign 1 92 483
IFGet 0 92 483
typenameSet 1 92 484
addValue 1 93 485
addValue 1 94 486
assign 1 95 487
containedGet 0 95 487
assign 1 95 488
def 1 95 493
assign 1 96 494
containedGet 0 96 494
assign 1 96 495
iteratorGet 0 96 495
assign 1 96 498
hasNextGet 0 96 498
assign 1 97 500
nextGet 0 97 500
addValue 1 97 501
addValue 1 104 508
assign 1 105 509
assign 1 106 510
nextPeerGet 0 106 510
delete 0 107 511
assign 1 108 512
assign 1 110 518
def 1 110 523
assign 1 110 524
typenameGet 0 110 524
assign 1 110 525
ELSEGet 0 110 525
assign 1 110 526
equals 1 110 526
assign 1 0 528
assign 1 0 531
assign 1 0 535
delete 0 111 538
addValue 1 112 539
assign 1 115 542
nextDescendGet 0 115 542
return 1 115 543
assign 1 116 546
typenameGet 0 116 546
assign 1 116 547
METHODGet 0 116 547
assign 1 116 548
equals 1 116 553
assign 1 117 554
containedGet 0 117 554
assign 1 117 555
firstGet 0 117 555
assign 1 118 556
new 1 118 556
copyLoc 1 119 557
assign 1 120 558
IDGet 0 120 558
typenameSet 1 120 559
assign 1 121 560
new 0 121 560
heldSet 1 121 561
prepend 1 122 562
assign 1 123 563
new 0 123 563
assign 1 124 564
new 0 124 564
assign 1 125 565
containedGet 0 125 565
assign 1 125 566
iteratorGet 0 125 566
assign 1 125 569
hasNextGet 0 125 569
assign 1 126 571
nextGet 0 126 571
assign 1 127 572
nextPeerGet 0 127 572
assign 1 130 573
typenameGet 0 130 573
assign 1 130 574
COMMAGet 0 130 574
assign 1 130 575
equals 1 130 575
addValue 1 131 577
assign 1 132 580
typenameGet 0 132 580
assign 1 132 581
IDGet 0 132 581
assign 1 132 582
equals 1 132 582
assign 1 133 584
new 0 133 584
assign 1 133 585
add 1 133 585
assign 1 134 586
new 0 134 586
assign 1 135 587
heldGet 0 135 587
nameSet 1 135 588
assign 1 136 589
new 0 136 589
isArgSet 1 136 590
heldSet 1 137 591
assign 1 138 592
VARGet 0 138 592
typenameSet 1 138 593
addVariable 0 139 594
assign 1 140 597
typenameGet 0 140 597
assign 1 140 598
VARGet 0 140 598
assign 1 140 599
equals 1 140 599
assign 1 141 601
typenameGet 0 141 601
assign 1 141 602
IDGet 0 141 602
assign 1 141 603
equals 1 141 603
assign 1 142 605
new 0 142 605
assign 1 142 606
add 1 142 606
assign 1 143 607
heldGet 0 143 607
assign 1 143 608
heldGet 0 143 608
nameSet 1 143 609
assign 1 144 610
heldGet 0 144 610
assign 1 144 611
new 0 144 611
isArgSet 1 144 612
addVariable 0 145 613
assign 1 146 614
COMMAGet 0 146 614
typenameSet 1 146 615
assign 1 148 618
new 0 148 618
assign 1 148 619
new 2 148 619
throw 1 148 620
assign 1 152 630
iteratorGet 0 152 630
assign 1 152 633
hasNextGet 0 152 633
assign 1 153 635
nextGet 0 153 635
delete 0 154 636
assign 1 156 642
heldGet 0 156 642
assign 1 157 643
new 0 157 643
assign 1 157 644
subtract 1 157 644
numargsSet 1 157 645
assign 1 158 646
nameGet 0 158 646
orgNameSet 1 158 647
assign 1 159 648
nameGet 0 159 648
assign 1 159 649
new 0 159 649
assign 1 159 650
add 1 159 650
assign 1 159 651
numargsGet 0 159 651
assign 1 159 652
toString 0 159 652
assign 1 159 653
add 1 159 653
nameSet 1 159 654
assign 1 160 655
secondGet 0 160 655
assign 1 161 656
typenameGet 0 161 656
assign 1 161 657
VARGet 0 161 657
assign 1 161 658
equals 1 161 658
resolveNp 0 162 660
assign 1 164 661
heldGet 0 164 661
rtypeSet 1 164 662
assign 1 165 663
rtypeGet 0 165 663
assign 1 165 664
namepathGet 0 165 664
assign 1 165 665
undef 1 165 670
rtypeSet 1 167 671
assign 1 168 674
rtypeGet 0 168 674
assign 1 168 675
namepathGet 0 168 675
assign 1 168 676
toString 0 168 676
assign 1 168 677
new 0 168 677
assign 1 168 678
equals 1 168 678
assign 1 170 680
rtypeGet 0 170 680
assign 1 170 681
new 0 170 681
isTypedSet 1 170 682
assign 1 171 683
rtypeGet 0 171 683
assign 1 171 684
new 0 171 684
isSelfSet 1 171 685
assign 1 172 686
rtypeGet 0 172 686
assign 1 172 687
new 0 172 687
isThisSet 1 172 688
assign 1 173 689
rtypeGet 0 173 689
assign 1 173 690
namepathGet 0 173 690
assign 1 173 691
new 0 173 691
pathSet 1 173 692
assign 1 174 695
rtypeGet 0 174 695
assign 1 174 696
namepathGet 0 174 696
assign 1 174 697
toString 0 174 697
assign 1 174 698
new 0 174 698
assign 1 174 699
equals 1 174 699
assign 1 175 701
rtypeGet 0 175 701
assign 1 175 702
new 0 175 702
isTypedSet 1 175 703
assign 1 176 704
rtypeGet 0 176 704
assign 1 176 705
new 0 176 705
isSelfSet 1 176 706
delete 0 178 710
assign 1 180 713
new 0 180 713
rtypeSet 1 180 714
assign 1 181 715
rtypeGet 0 181 715
assign 1 181 716
new 0 181 716
isTypedSet 1 181 717
assign 1 182 718
rtypeGet 0 182 718
assign 1 182 719
new 0 182 719
isSelfSet 1 182 720
assign 1 183 721
rtypeGet 0 183 721
assign 1 183 722
new 0 183 722
isThisSet 1 183 723
assign 1 184 724
rtypeGet 0 184 724
assign 1 184 725
new 0 184 725
impliedSet 1 184 726
assign 1 185 727
rtypeGet 0 185 727
assign 1 185 728
new 0 185 728
assign 1 185 729
new 1 185 729
namepathSet 1 185 730
assign 1 187 732
classGet 0 187 732
assign 1 188 733
heldGet 0 188 733
assign 1 188 734
methodsGet 0 188 734
assign 1 188 735
nameGet 0 188 735
put 2 188 736
assign 1 189 737
heldGet 0 189 737
assign 1 189 738
orderedMethodsGet 0 189 738
addValue 1 189 739
assign 1 191 744
nextDescendGet 0 191 744
return 1 191 745
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1938521961: return bem_create_0();
case 1428196909: return bem_deserializeClassNameGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case 1469761457: return bem_serializeToString_0();
case -1120775249: return bem_classNameGet_0();
case 474962230: return bem_buildGetDirect_0();
case -559654393: return bem_sourceFileNameGet_0();
case 976077722: return bem_new_0();
case -1359840989: return bem_toAny_0();
case -129765629: return bem_print_0();
case -1677294751: return bem_hashGet_0();
case -1660007365: return bem_iteratorGet_0();
case 126164297: return bem_serializationIteratorGet_0();
case -1640020074: return bem_toString_0();
case 1285405295: return bem_transGetDirect_0();
case -374496050: return bem_tagGet_0();
case 2069874486: return bem_constGetDirect_0();
case -1530492540: return bem_many_0();
case 921209725: return bem_echo_0();
case -1606863806: return bem_fieldIteratorGet_0();
case 1342564574: return bem_ntypesGet_0();
case 918163558: return bem_buildGet_0();
case -489715464: return bem_ntypesGetDirect_0();
case -1483834827: return bem_copy_0();
case 2028199664: return bem_once_0();
case 1963846645: return bem_serializeContents_0();
case 78342517: return bem_transGet_0();
case -1451184761: return bem_constGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -943060017: return bem_ntypesSetDirect_1(bevd_0);
case 1414981672: return bem_defined_1(bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case 175516239: return bem_end_1(bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1233102724: return bem_begin_1(bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case -872100885: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1838687907: return bem_buildSetDirect_1(bevd_0);
case 1251610635: return bem_transSet_1(bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case 232561331: return bem_buildSet_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case 1662145724: return bem_constSetDirect_1(bevd_0);
case -1168795021: return bem_ntypesSet_1(bevd_0);
case -1400768154: return bem_constSet_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1383582564: return bem_transSetDirect_1(bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1789648416: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass6_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass6_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst = (BEC_3_5_5_5_BuildVisitPass6) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;
}
}
