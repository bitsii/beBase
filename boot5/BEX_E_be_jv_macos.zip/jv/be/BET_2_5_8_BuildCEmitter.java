package be;
public class BET_2_5_8_BuildCEmitter extends BETS_Object {
public BET_2_5_8_BuildCEmitter() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "midNameDo_2", "removeEmitted_1", "getInfo_1", "getInfoNoCache_1", "getInfoSearch_1", "prepBasePath_1", "loadSyn_1", "saveSyn_1", "emitMtd_2", "emitInitialClass_2", "doEmit_1", "emitSyn_1", "libnameNpGet_0", "registerName_1", "foreignClass_2", "getPropertyIndexName_1", "getMethodIndexName_1", "libnameInfoGet_0", "emitCUInit_0", "classDefTarget_2", "resolveConflicts_0", "make_1", "run_2", "prepMake_1", "emitMain_0", "deployLibrary_1", "deployFile_2", "classInfoGet_0", "classInfoSet_1", "cEmitFGet_0", "cEmitFSet_1", "mainClassNpGet_0", "mainClassNpSet_1", "mainClassInfoGet_0", "mainClassInfoSet_1", "libnameNpSet_1", "libnameInfoSet_1", "allIncGet_0", "allIncSet_1", "ccObjArgsStrGet_0", "ccObjArgsStrSet_1", "extLibGet_0", "extLibSet_1", "linkLibArgsStrGet_0", "linkLibArgsStrSet_1", "cprofileGet_0", "cprofileSet_1", "pciGet_0", "pciSet_1", "buildGet_0", "buildSet_1", "nlGet_0", "nlSet_1", "ciCacheGet_0", "ciCacheSet_1", "emitDataGet_0", "emitDataSet_1", "textQuoteGet_0", "textQuoteSet_1", "libNameGet_0", "libNameSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "classInfo", "cEmitF", "mainClassNp", "mainClassInfo", "libnameNp", "libnameInfo", "allInc", "ccObjArgsStr", "extLib", "linkLibArgsStr", "cprofile", "pci", "build", "nl", "ciCache", "emitData", "textQuote", "libName" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_8_BuildCEmitter();
}
}
