package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_0 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_1 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_2 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_3 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_5 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_6 = (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_7 = (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_9 = (new BEC_2_4_3_MathInt(24));
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_0, 39));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_11 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_12 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_13 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_14 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_15 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_17 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_18 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_19 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_20 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_21 = (new BEC_2_4_3_MathInt(43));
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_1, 21));
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_25 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_26 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_27 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_28 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_29 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_30 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_31 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_32 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_33 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_34 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_35 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_36 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_38 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt());
return (BEC_2_4_3_MathInt) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_2;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_3;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_4;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_5;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_7;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_8;
if (beva_radix.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_9;
if (beva_radix.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 96 */ {
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_10;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_radix);
bevt_5_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 97 */
bevt_9_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_11;
if (beva_radix.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 100 */
 else  /* Line: 101 */ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 102 */
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_11_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_12;
bevt_13_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_13;
bevt_12_tmpany_phold = beva_radix.bem_subtract_1(bevt_13_tmpany_phold);
bevl_maxA = bevt_11_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_14;
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_15;
bevt_15_tmpany_phold = beva_radix.bem_subtract_1(bevt_16_tmpany_phold);
bevl_maxa = bevt_14_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_j = bevt_4_tmpany_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 116 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_16;
if (bevl_j.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 116 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_17;
if (bevl_ic.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 120 */ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 123 */
 else  /* Line: 120 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_18;
if (bevl_ic.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 124 */ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
 else  /* Line: 124 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 124 */ {
bevt_14_tmpany_phold = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 127 */
 else  /* Line: 120 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_19;
if (bevl_ic.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 128 */ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 128 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 128 */
 else  /* Line: 128 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 128 */ {
bevt_18_tmpany_phold = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 131 */
 else  /* Line: 120 */ {
bevt_20_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_20;
if (bevl_ic.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_21_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_tmpany_phold);
} /* Line: 134 */
 else  /* Line: 120 */ {
bevt_23_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_21;
if (bevl_ic.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 135 */ {
} /* Line: 135 */
 else  /* Line: 137 */ {
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_22;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(beva_str);
bevt_29_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_23;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevl_ic);
bevt_24_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 138 */
} /* Line: 120 */
} /* Line: 120 */
} /* Line: 120 */
} /* Line: 120 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 141 */
 else  /* Line: 116 */ {
break;
} /* Line: 116 */
} /* Line: 116 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_24;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_25;
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) bevt_6_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, bevt_3_tmpany_phold, bevt_5_tmpany_phold, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_toHexString_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_26;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_27;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_3(beva_res, bevt_1_tmpany_phold, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_28;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, beva_zeroPad, beva_radix, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_29;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 219 */ {
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_30;
if (bevl_ts.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_31;
if (bevl_val.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_tmpany_phold.bevi_int;
} /* Line: 223 */
 else  /* Line: 224 */ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 225 */
bevt_6_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int <= bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_9_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_32;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpany_phold);
} /* Line: 229 */
bevt_11_tmpany_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpany_phold, bevl_val);
bevt_13_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_33;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 236 */
 else  /* Line: 219 */ {
break;
} /* Line: 219 */
} /* Line: 219 */
while (true)
 /* Line: 239 */ {
bevt_19_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_19_tmpany_phold.bevi_int < beva_zeroPad.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_21_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_21_tmpany_phold.bevi_int <= bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_24_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_34;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpany_phold);
} /* Line: 241 */
bevt_26_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_35;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_36;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpany_phold);
} /* Line: 245 */
 else  /* Line: 239 */ {
break;
} /* Line: 239 */
} /* Line: 239 */
bevt_36_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_37;
if (bevi_int < bevt_36_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 250 */
bevt_38_tmpany_phold = beva_res.bem_reverseBytes_0();
return bevt_38_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_absValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_38;
if (bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 266 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_tmpany_phold);
} /* Line: 267 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 699 */ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 699 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 699 */
 else  /* Line: 699 */ {
break;
} /* Line: 699 */
} /* Line: 699 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {77, 77, 80, 84, 88, 88, 88, 88, 88, 88, 88, 88, 88, 92, 92, 92, 92, 92, 92, 92, 92, 92, 96, 96, 96, 0, 96, 96, 96, 0, 0, 97, 97, 97, 97, 99, 99, 99, 100, 102, 104, 104, 105, 105, 105, 105, 106, 106, 106, 106, 107, 111, 111, 112, 112, 113, 114, 115, 116, 116, 116, 118, 120, 120, 120, 120, 120, 0, 0, 0, 121, 121, 122, 123, 124, 124, 124, 124, 124, 0, 0, 0, 125, 125, 126, 127, 128, 128, 128, 128, 128, 0, 0, 0, 129, 129, 130, 131, 132, 132, 132, 134, 134, 135, 135, 135, 138, 138, 138, 138, 138, 138, 138, 140, 141, 146, 146, 150, 154, 154, 158, 169, 192, 196, 196, 196, 196, 196, 196, 196, 196, 200, 200, 200, 200, 204, 204, 204, 204, 204, 204, 208, 208, 208, 208, 208, 212, 212, 212, 212, 216, 217, 218, 219, 219, 219, 220, 221, 222, 222, 222, 223, 223, 225, 228, 228, 228, 228, 229, 229, 229, 229, 231, 231, 232, 232, 232, 232, 236, 239, 239, 239, 240, 240, 240, 240, 241, 241, 241, 241, 243, 243, 243, 243, 244, 244, 244, 244, 249, 249, 249, 250, 250, 252, 252, 256, 257, 258, 262, 262, 262, 266, 266, 266, 267, 267, 288, 292, 303, 307, 318, 337, 356, 360, 371, 390, 394, 405, 424, 428, 439, 458, 462, 478, 502, 506, 517, 536, 540, 556, 575, 579, 595, 614, 618, 634, 653, 657, 673, 692, 697, 699, 699, 699, 700, 699, 702, 741, 741, 777, 777, 805, 805, 833, 833, 861, 861, 889, 889};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {70, 71, 74, 78, 90, 91, 92, 93, 94, 95, 96, 97, 98, 110, 111, 112, 113, 114, 115, 116, 117, 118, 142, 143, 148, 149, 152, 153, 158, 159, 162, 166, 167, 168, 169, 171, 172, 177, 178, 181, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 230, 231, 232, 233, 234, 235, 236, 239, 240, 245, 246, 247, 248, 253, 254, 259, 260, 263, 267, 270, 271, 272, 273, 276, 277, 282, 283, 288, 289, 292, 296, 299, 300, 301, 302, 305, 306, 311, 312, 317, 318, 321, 325, 328, 329, 330, 331, 334, 335, 340, 341, 342, 345, 346, 351, 354, 355, 356, 357, 358, 359, 360, 366, 367, 377, 378, 381, 386, 387, 390, 394, 397, 407, 408, 409, 410, 411, 412, 413, 414, 420, 421, 422, 423, 431, 432, 433, 434, 435, 436, 443, 444, 445, 446, 447, 453, 454, 455, 456, 500, 501, 502, 505, 506, 511, 512, 513, 514, 515, 520, 521, 522, 525, 527, 528, 529, 534, 535, 536, 537, 538, 540, 541, 542, 543, 544, 545, 546, 554, 555, 560, 561, 562, 563, 568, 569, 570, 571, 572, 574, 575, 576, 577, 578, 579, 580, 581, 587, 588, 593, 594, 595, 597, 598, 602, 603, 604, 609, 610, 611, 617, 618, 623, 624, 625, 632, 636, 639, 643, 646, 651, 656, 660, 663, 668, 672, 675, 680, 684, 687, 692, 696, 699, 704, 708, 711, 716, 720, 723, 728, 732, 735, 740, 744, 747, 752, 756, 759, 764, 770, 771, 774, 779, 780, 781, 787, 796, 797, 806, 807, 816, 817, 826, 827, 836, 837, 846, 847};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 77 70
new 0 77 70
return 1 77 71
setStringValueDec 1 80 74
setStringValueHex 1 84 78
assign 1 88 90
new 0 88 90
assign 1 88 91
once 0 88 91
assign 1 88 92
new 0 88 92
assign 1 88 93
once 0 88 93
assign 1 88 94
new 0 88 94
assign 1 88 95
once 0 88 95
assign 1 88 96
new 0 88 96
assign 1 88 97
once 0 88 97
setStringValue 5 88 98
assign 1 92 110
new 0 92 110
assign 1 92 111
once 0 92 111
assign 1 92 112
new 0 92 112
assign 1 92 113
once 0 92 113
assign 1 92 114
new 0 92 114
assign 1 92 115
once 0 92 115
assign 1 92 116
new 0 92 116
assign 1 92 117
once 0 92 117
setStringValue 5 92 118
assign 1 96 142
new 0 96 142
assign 1 96 143
lesser 1 96 148
assign 1 0 149
assign 1 96 152
new 0 96 152
assign 1 96 153
greater 1 96 158
assign 1 0 159
assign 1 0 162
assign 1 97 166
new 0 97 166
assign 1 97 167
add 1 97 167
assign 1 97 168
new 1 97 168
throw 1 97 169
assign 1 99 171
new 0 99 171
assign 1 99 172
lesser 1 99 177
assign 1 100 178
copy 0 100 178
assign 1 102 181
new 0 102 181
assign 1 104 183
new 0 104 183
addValue 1 104 184
assign 1 105 185
new 0 105 185
assign 1 105 186
new 0 105 186
assign 1 105 187
subtract 1 105 187
assign 1 105 188
add 1 105 188
assign 1 106 189
new 0 106 189
assign 1 106 190
new 0 106 190
assign 1 106 191
subtract 1 106 191
assign 1 106 192
add 1 106 192
setStringValue 5 107 193
assign 1 111 230
new 0 111 230
setValue 1 111 231
assign 1 112 232
sizeGet 0 112 232
assign 1 112 233
copy 0 112 233
decrementValue 0 113 234
assign 1 114 235
new 0 114 235
assign 1 115 236
new 0 115 236
assign 1 116 239
new 0 116 239
assign 1 116 240
greaterEquals 1 116 245
getInt 2 118 246
assign 1 120 247
new 0 120 247
assign 1 120 248
greater 1 120 253
assign 1 120 254
lesser 1 120 259
assign 1 0 260
assign 1 0 263
assign 1 0 267
assign 1 121 270
new 0 121 270
subtractValue 1 121 271
multiplyValue 1 122 272
addValue 1 123 273
assign 1 124 276
new 0 124 276
assign 1 124 277
greater 1 124 282
assign 1 124 283
lesser 1 124 288
assign 1 0 289
assign 1 0 292
assign 1 0 296
assign 1 125 299
new 0 125 299
subtractValue 1 125 300
multiplyValue 1 126 301
addValue 1 127 302
assign 1 128 305
new 0 128 305
assign 1 128 306
greater 1 128 311
assign 1 128 312
lesser 1 128 317
assign 1 0 318
assign 1 0 321
assign 1 0 325
assign 1 129 328
new 0 129 328
subtractValue 1 129 329
multiplyValue 1 130 330
addValue 1 131 331
assign 1 132 334
new 0 132 334
assign 1 132 335
equals 1 132 340
assign 1 134 341
new 0 134 341
multiplyValue 1 134 342
assign 1 135 345
new 0 135 345
assign 1 135 346
equals 1 135 351
assign 1 138 354
new 0 138 354
assign 1 138 355
add 1 138 355
assign 1 138 356
new 0 138 356
assign 1 138 357
add 1 138 357
assign 1 138 358
add 1 138 358
assign 1 138 359
new 1 138 359
throw 1 138 360
decrementValue 0 140 366
multiplyValue 1 141 367
assign 1 146 377
toString 0 146 377
return 1 146 378
new 1 150 381
assign 1 154 386
new 0 154 386
return 1 154 387
return 1 158 390
assign 1 169 394
new 0 169 394
return 1 192 397
assign 1 196 407
new 0 196 407
assign 1 196 408
new 1 196 408
assign 1 196 409
new 0 196 409
assign 1 196 410
once 0 196 410
assign 1 196 411
new 0 196 411
assign 1 196 412
once 0 196 412
assign 1 196 413
toString 4 196 413
return 1 196 414
assign 1 200 420
new 0 200 420
assign 1 200 421
new 1 200 421
assign 1 200 422
toHexString 1 200 422
return 1 200 423
assign 1 204 431
new 0 204 431
assign 1 204 432
once 0 204 432
assign 1 204 433
new 0 204 433
assign 1 204 434
once 0 204 434
assign 1 204 435
toString 3 204 435
return 1 204 436
assign 1 208 443
new 1 208 443
assign 1 208 444
new 0 208 444
assign 1 208 445
once 0 208 445
assign 1 208 446
toString 4 208 446
return 1 208 447
assign 1 212 453
new 0 212 453
assign 1 212 454
once 0 212 454
assign 1 212 455
toString 4 212 455
return 1 212 456
clear 0 216 500
assign 1 217 501
abs 0 217 501
assign 1 218 502
new 0 218 502
assign 1 219 505
new 0 219 505
assign 1 219 506
greater 1 219 511
setValue 1 220 512
modulusValue 1 221 513
assign 1 222 514
new 0 222 514
assign 1 222 515
lesser 1 222 520
assign 1 223 521
new 0 223 521
addValue 1 223 522
addValue 1 225 525
assign 1 228 527
capacityGet 0 228 527
assign 1 228 528
sizeGet 0 228 528
assign 1 228 529
lesserEquals 1 228 534
assign 1 229 535
capacityGet 0 229 535
assign 1 229 536
new 0 229 536
assign 1 229 537
add 1 229 537
capacitySet 1 229 538
assign 1 231 540
sizeGet 0 231 540
setIntUnchecked 2 231 541
assign 1 232 542
sizeGet 0 232 542
assign 1 232 543
new 0 232 543
assign 1 232 544
add 1 232 544
sizeSet 1 232 545
divideValue 1 236 546
assign 1 239 554
sizeGet 0 239 554
assign 1 239 555
lesser 1 239 560
assign 1 240 561
capacityGet 0 240 561
assign 1 240 562
sizeGet 0 240 562
assign 1 240 563
lesserEquals 1 240 568
assign 1 241 569
capacityGet 0 241 569
assign 1 241 570
new 0 241 570
assign 1 241 571
add 1 241 571
capacitySet 1 241 572
assign 1 243 574
sizeGet 0 243 574
assign 1 243 575
new 0 243 575
assign 1 243 576
once 0 243 576
setIntUnchecked 2 243 577
assign 1 244 578
sizeGet 0 244 578
assign 1 244 579
new 0 244 579
assign 1 244 580
add 1 244 580
sizeSet 1 244 581
assign 1 249 587
new 0 249 587
assign 1 249 588
lesser 1 249 593
assign 1 250 594
new 0 250 594
addValue 1 250 595
assign 1 252 597
reverseBytes 0 252 597
return 1 252 598
assign 1 256 602
new 0 256 602
setValue 1 257 603
return 1 258 604
assign 1 262 609
copy 0 262 609
assign 1 262 610
absValue 0 262 610
return 1 262 611
assign 1 266 617
new 0 266 617
assign 1 266 618
lesser 1 266 623
assign 1 267 624
new 0 267 624
multiplyValue 1 267 625
return 1 288 632
assign 1 292 636
new 0 292 636
return 1 303 639
assign 1 307 643
new 0 307 643
return 1 318 646
return 1 337 651
return 1 356 656
assign 1 360 660
new 0 360 660
return 1 371 663
return 1 390 668
assign 1 394 672
new 0 394 672
return 1 405 675
return 1 424 680
assign 1 428 684
new 0 428 684
return 1 439 687
return 1 458 692
assign 1 462 696
new 0 462 696
return 1 478 699
return 1 502 704
assign 1 506 708
new 0 506 708
return 1 517 711
return 1 536 716
assign 1 540 720
new 0 540 720
return 1 556 723
return 1 575 728
assign 1 579 732
new 0 579 732
return 1 595 735
return 1 614 740
assign 1 618 744
new 0 618 744
return 1 634 747
return 1 653 752
assign 1 657 756
new 0 657 756
return 1 673 759
return 1 692 764
assign 1 697 770
new 0 697 770
assign 1 699 771
new 0 699 771
assign 1 699 774
lesser 1 699 779
multiplyValue 1 700 780
incrementValue 0 699 781
return 1 702 787
assign 1 741 796
new 0 741 796
return 1 741 797
assign 1 777 806
new 0 777 806
return 1 777 807
assign 1 805 816
new 0 805 816
return 1 805 817
assign 1 833 826
new 0 833 826
return 1 833 827
assign 1 861 836
new 0 861 836
return 1 861 837
assign 1 889 846
new 0 889 846
return 1 889 847
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2061412556: return bem_classNameGet_0();
case -2139694474: return bem_toHexString_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case 605755759: return bem_fieldNamesGet_0();
case -39706070: return bem_serializeContents_0();
case 2069196027: return bem_print_0();
case -1490592754: return bem_toFloat_0();
case 1359777543: return bem_toAny_0();
case -102914561: return bem_abs_0();
case 874968344: return bem_once_0();
case -1417957999: return bem_decrementValue_0();
case 344752250: return bem_hashGet_0();
case -881038620: return bem_absValue_0();
case -345091134: return bem_vintSet_0();
case 27033645: return bem_sourceFileNameGet_0();
case 502031978: return bem_iteratorGet_0();
case 1480415803: return bem_serializationIteratorGet_0();
case 325964466: return bem_echo_0();
case 1965613314: return bem_tagGet_0();
case 1578098134: return bem_toString_0();
case 26417469: return bem_create_0();
case 962099177: return bem_fieldIteratorGet_0();
case -8417244: return bem_vintGet_0();
case -1878305271: return bem_many_0();
case -758913843: return bem_decrement_0();
case 334767424: return bem_copy_0();
case 682361124: return bem_incrementValue_0();
case -1172729948: return bem_increment_0();
case 2132890711: return bem_new_0();
case -799200084: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1041507138: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 941545888: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -965923916: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case -302004312: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case -362308523: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1915914523: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 1848144504: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case 419124452: return bem_new_1(bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1974364793: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -1188302043: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1443944253: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 487595867: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1383911612: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -472166108: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case -1543942220: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case 768593489: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case -101990988: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -1529953995: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -1480040335: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case -387623669: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case -1664368470: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case -733399971: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case -1621246488: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
case 339575761: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1000972094: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case -416396325: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case -1420251088: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case 623201813: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case 1531212395: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1021885707: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 857646349: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -424960901: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -960377419: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1227296219: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
