package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
public static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt());
return (BEC_2_4_3_MathInt) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(97));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(71));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(103));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_9_SystemException bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
if (beva_radix.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 95*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(24));
if (beva_radix.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 95*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 95*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_4_3_MathInt_bels_0));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_radix);
bevt_5_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_ta_ph);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 96*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(10));
if (beva_radix.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 98*/ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 99*/
 else /* Line: 100*/ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 101*/
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_ta_ph.bevi_int;
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_12_ta_ph = beva_radix.bem_subtract_1(bevt_13_ta_ph);
bevl_maxA = bevt_11_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(97));
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_15_ta_ph = beva_radix.bem_subtract_1(bevt_16_ta_ph);
bevl_maxa = bevt_14_ta_ph.bem_add_1(bevt_15_ta_ph);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_9_SystemException bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_ta_ph.bevi_int;
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevl_j = bevt_4_ta_ph.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 115*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 115*/ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 119*/ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 119*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 119*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 119*/
 else /* Line: 119*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 119*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 122*/
 else /* Line: 119*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 123*/ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 123*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 123*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 123*/
 else /* Line: 123*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 123*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 126*/
 else /* Line: 119*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 127*/ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 127*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 127*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 127*/
 else /* Line: 127*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 127*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 130*/
 else /* Line: 119*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_ta_ph);
} /* Line: 133*/
 else /* Line: 119*/ {
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 134*/ {
} /* Line: 134*/
 else /* Line: 136*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_3_MathInt_bels_1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(beva_str);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_2));
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevl_ic);
bevt_24_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 137*/
} /* Line: 119*/
} /* Line: 119*/
} /* Line: 119*/
} /* Line: 119*/
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 140*/
 else /* Line: 115*/ {
break;
} /* Line: 115*/
} /* Line: 115*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_toHexString_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bem_toString_3(beva_res, bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, beva_zeroPad, beva_radix, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 218*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_ts.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 218*/ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(10));
if (bevl_val.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_ta_ph.bevi_int;
} /* Line: 222*/
 else /* Line: 223*/ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 224*/
bevt_6_ta_ph = beva_res.bem_capacityGet_0();
bevt_7_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_6_ta_ph.bevi_int <= bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_9_ta_ph = beva_res.bem_capacityGet_0();
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_10_ta_ph);
beva_res.bem_capacitySet_1(bevt_8_ta_ph);
} /* Line: 228*/
bevt_11_ta_ph = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_ta_ph, bevl_val);
bevt_13_ta_ph = beva_res.bem_sizeGet_0();
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
beva_res.bem_sizeSet_1(bevt_12_ta_ph);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 235*/
 else /* Line: 218*/ {
break;
} /* Line: 218*/
} /* Line: 218*/
while (true)
/* Line: 238*/ {
bevt_18_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_18_ta_ph.bevi_int < beva_zeroPad.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_20_ta_ph = beva_res.bem_capacityGet_0();
bevt_21_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_20_ta_ph.bevi_int <= bevt_21_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_23_ta_ph = beva_res.bem_capacityGet_0();
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
beva_res.bem_capacitySet_1(bevt_22_ta_ph);
} /* Line: 240*/
bevt_25_ta_ph = beva_res.bem_sizeGet_0();
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(48));
beva_res.bem_setIntUnchecked_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_28_ta_ph = beva_res.bem_sizeGet_0();
bevt_29_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(bevt_29_ta_ph);
beva_res.bem_sizeSet_1(bevt_27_ta_ph);
} /* Line: 244*/
 else /* Line: 238*/ {
break;
} /* Line: 238*/
} /* Line: 238*/
bevt_33_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_33_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 249*/
bevt_35_ta_ph = beva_res.bem_reverseBytes_0();
return bevt_35_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_absValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 265*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_ta_ph);
} /* Line: 266*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 700*/ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 700*/ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 700*/
 else /* Line: 700*/ {
break;
} /* Line: 700*/
} /* Line: 700*/
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {76, 76, 79, 83, 87, 87, 87, 87, 87, 91, 91, 91, 91, 91, 95, 95, 95, 0, 95, 95, 95, 0, 0, 96, 96, 96, 96, 98, 98, 98, 99, 101, 103, 103, 104, 104, 104, 104, 105, 105, 105, 105, 106, 110, 110, 111, 111, 112, 113, 114, 115, 115, 115, 117, 119, 119, 119, 119, 119, 0, 0, 0, 120, 120, 121, 122, 123, 123, 123, 123, 123, 0, 0, 0, 124, 124, 125, 126, 127, 127, 127, 127, 127, 0, 0, 0, 128, 128, 129, 130, 131, 131, 131, 133, 133, 134, 134, 134, 137, 137, 137, 137, 137, 137, 137, 139, 140, 145, 145, 149, 153, 153, 157, 168, 191, 195, 195, 195, 195, 195, 195, 199, 199, 199, 199, 203, 203, 203, 203, 207, 207, 207, 207, 211, 211, 211, 215, 216, 217, 218, 218, 218, 219, 220, 221, 221, 221, 222, 222, 224, 227, 227, 227, 227, 228, 228, 228, 228, 230, 230, 231, 231, 231, 231, 235, 238, 238, 238, 239, 239, 239, 239, 240, 240, 240, 240, 242, 242, 242, 243, 243, 243, 243, 248, 248, 248, 249, 249, 251, 251, 255, 256, 257, 261, 261, 261, 265, 265, 265, 266, 266, 287, 291, 302, 306, 317, 336, 355, 359, 370, 389, 393, 404, 423, 427, 438, 457, 461, 478, 503, 507, 518, 537, 541, 557, 576, 580, 596, 615, 619, 635, 654, 658, 674, 693, 698, 700, 700, 700, 701, 700, 703, 748, 748, 790, 790, 818, 818, 846, 846, 874, 874, 902, 902};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 35, 39, 47, 48, 49, 50, 51, 59, 60, 61, 62, 63, 87, 88, 93, 94, 97, 98, 103, 104, 107, 111, 112, 113, 114, 116, 117, 122, 123, 126, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 175, 176, 177, 178, 179, 180, 181, 184, 185, 190, 191, 192, 193, 198, 199, 204, 205, 208, 212, 215, 216, 217, 218, 221, 222, 227, 228, 233, 234, 237, 241, 244, 245, 246, 247, 250, 251, 256, 257, 262, 263, 266, 270, 273, 274, 275, 276, 279, 280, 285, 286, 287, 290, 291, 296, 299, 300, 301, 302, 303, 304, 305, 311, 312, 322, 323, 326, 331, 332, 335, 339, 342, 350, 351, 352, 353, 354, 355, 361, 362, 363, 364, 370, 371, 372, 373, 379, 380, 381, 382, 387, 388, 389, 430, 431, 432, 435, 436, 441, 442, 443, 444, 445, 450, 451, 452, 455, 457, 458, 459, 464, 465, 466, 467, 468, 470, 471, 472, 473, 474, 475, 476, 484, 485, 490, 491, 492, 493, 498, 499, 500, 501, 502, 504, 505, 506, 507, 508, 509, 510, 516, 517, 522, 523, 524, 526, 527, 531, 532, 533, 538, 539, 540, 546, 547, 552, 553, 554, 561, 565, 568, 572, 575, 580, 585, 589, 592, 597, 601, 604, 609, 613, 616, 621, 625, 628, 633, 637, 640, 645, 649, 652, 657, 661, 664, 669, 673, 676, 681, 685, 688, 693, 699, 700, 703, 708, 709, 710, 716, 725, 726, 735, 736, 745, 746, 755, 756, 765, 766, 775, 776};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 76 31
new 0 76 31
return 1 76 32
setStringValueDec 1 79 35
setStringValueHex 1 83 39
assign 1 87 47
new 0 87 47
assign 1 87 48
new 0 87 48
assign 1 87 49
new 0 87 49
assign 1 87 50
new 0 87 50
setStringValue 5 87 51
assign 1 91 59
new 0 91 59
assign 1 91 60
new 0 91 60
assign 1 91 61
new 0 91 61
assign 1 91 62
new 0 91 62
setStringValue 5 91 63
assign 1 95 87
new 0 95 87
assign 1 95 88
lesser 1 95 93
assign 1 0 94
assign 1 95 97
new 0 95 97
assign 1 95 98
greater 1 95 103
assign 1 0 104
assign 1 0 107
assign 1 96 111
new 0 96 111
assign 1 96 112
add 1 96 112
assign 1 96 113
new 1 96 113
throw 1 96 114
assign 1 98 116
new 0 98 116
assign 1 98 117
lesser 1 98 122
assign 1 99 123
copy 0 99 123
assign 1 101 126
new 0 101 126
assign 1 103 128
new 0 103 128
addValue 1 103 129
assign 1 104 130
new 0 104 130
assign 1 104 131
new 0 104 131
assign 1 104 132
subtract 1 104 132
assign 1 104 133
add 1 104 133
assign 1 105 134
new 0 105 134
assign 1 105 135
new 0 105 135
assign 1 105 136
subtract 1 105 136
assign 1 105 137
add 1 105 137
setStringValue 5 106 138
assign 1 110 175
new 0 110 175
setValue 1 110 176
assign 1 111 177
sizeGet 0 111 177
assign 1 111 178
copy 0 111 178
decrementValue 0 112 179
assign 1 113 180
new 0 113 180
assign 1 114 181
new 0 114 181
assign 1 115 184
new 0 115 184
assign 1 115 185
greaterEquals 1 115 190
getInt 2 117 191
assign 1 119 192
new 0 119 192
assign 1 119 193
greater 1 119 198
assign 1 119 199
lesser 1 119 204
assign 1 0 205
assign 1 0 208
assign 1 0 212
assign 1 120 215
new 0 120 215
subtractValue 1 120 216
multiplyValue 1 121 217
addValue 1 122 218
assign 1 123 221
new 0 123 221
assign 1 123 222
greater 1 123 227
assign 1 123 228
lesser 1 123 233
assign 1 0 234
assign 1 0 237
assign 1 0 241
assign 1 124 244
new 0 124 244
subtractValue 1 124 245
multiplyValue 1 125 246
addValue 1 126 247
assign 1 127 250
new 0 127 250
assign 1 127 251
greater 1 127 256
assign 1 127 257
lesser 1 127 262
assign 1 0 263
assign 1 0 266
assign 1 0 270
assign 1 128 273
new 0 128 273
subtractValue 1 128 274
multiplyValue 1 129 275
addValue 1 130 276
assign 1 131 279
new 0 131 279
assign 1 131 280
equals 1 131 285
assign 1 133 286
new 0 133 286
multiplyValue 1 133 287
assign 1 134 290
new 0 134 290
assign 1 134 291
equals 1 134 296
assign 1 137 299
new 0 137 299
assign 1 137 300
add 1 137 300
assign 1 137 301
new 0 137 301
assign 1 137 302
add 1 137 302
assign 1 137 303
add 1 137 303
assign 1 137 304
new 1 137 304
throw 1 137 305
decrementValue 0 139 311
multiplyValue 1 140 312
assign 1 145 322
toString 0 145 322
return 1 145 323
new 1 149 326
assign 1 153 331
new 0 153 331
return 1 153 332
return 1 157 335
assign 1 168 339
new 0 168 339
return 1 191 342
assign 1 195 350
new 0 195 350
assign 1 195 351
new 1 195 351
assign 1 195 352
new 0 195 352
assign 1 195 353
new 0 195 353
assign 1 195 354
toString 4 195 354
return 1 195 355
assign 1 199 361
new 0 199 361
assign 1 199 362
new 1 199 362
assign 1 199 363
toHexString 1 199 363
return 1 199 364
assign 1 203 370
new 0 203 370
assign 1 203 371
new 0 203 371
assign 1 203 372
toString 3 203 372
return 1 203 373
assign 1 207 379
new 1 207 379
assign 1 207 380
new 0 207 380
assign 1 207 381
toString 4 207 381
return 1 207 382
assign 1 211 387
new 0 211 387
assign 1 211 388
toString 4 211 388
return 1 211 389
clear 0 215 430
assign 1 216 431
abs 0 216 431
assign 1 217 432
new 0 217 432
assign 1 218 435
new 0 218 435
assign 1 218 436
greater 1 218 441
setValue 1 219 442
modulusValue 1 220 443
assign 1 221 444
new 0 221 444
assign 1 221 445
lesser 1 221 450
assign 1 222 451
new 0 222 451
addValue 1 222 452
addValue 1 224 455
assign 1 227 457
capacityGet 0 227 457
assign 1 227 458
sizeGet 0 227 458
assign 1 227 459
lesserEquals 1 227 464
assign 1 228 465
capacityGet 0 228 465
assign 1 228 466
new 0 228 466
assign 1 228 467
add 1 228 467
capacitySet 1 228 468
assign 1 230 470
sizeGet 0 230 470
setIntUnchecked 2 230 471
assign 1 231 472
sizeGet 0 231 472
assign 1 231 473
new 0 231 473
assign 1 231 474
add 1 231 474
sizeSet 1 231 475
divideValue 1 235 476
assign 1 238 484
sizeGet 0 238 484
assign 1 238 485
lesser 1 238 490
assign 1 239 491
capacityGet 0 239 491
assign 1 239 492
sizeGet 0 239 492
assign 1 239 493
lesserEquals 1 239 498
assign 1 240 499
capacityGet 0 240 499
assign 1 240 500
new 0 240 500
assign 1 240 501
add 1 240 501
capacitySet 1 240 502
assign 1 242 504
sizeGet 0 242 504
assign 1 242 505
new 0 242 505
setIntUnchecked 2 242 506
assign 1 243 507
sizeGet 0 243 507
assign 1 243 508
new 0 243 508
assign 1 243 509
add 1 243 509
sizeSet 1 243 510
assign 1 248 516
new 0 248 516
assign 1 248 517
lesser 1 248 522
assign 1 249 523
new 0 249 523
addValue 1 249 524
assign 1 251 526
reverseBytes 0 251 526
return 1 251 527
assign 1 255 531
new 0 255 531
setValue 1 256 532
return 1 257 533
assign 1 261 538
copy 0 261 538
assign 1 261 539
absValue 0 261 539
return 1 261 540
assign 1 265 546
new 0 265 546
assign 1 265 547
lesser 1 265 552
assign 1 266 553
new 0 266 553
multiplyValue 1 266 554
return 1 287 561
assign 1 291 565
new 0 291 565
return 1 302 568
assign 1 306 572
new 0 306 572
return 1 317 575
return 1 336 580
return 1 355 585
assign 1 359 589
new 0 359 589
return 1 370 592
return 1 389 597
assign 1 393 601
new 0 393 601
return 1 404 604
return 1 423 609
assign 1 427 613
new 0 427 613
return 1 438 616
return 1 457 621
assign 1 461 625
new 0 461 625
return 1 478 628
return 1 503 633
assign 1 507 637
new 0 507 637
return 1 518 640
return 1 537 645
assign 1 541 649
new 0 541 649
return 1 557 652
return 1 576 657
assign 1 580 661
new 0 580 661
return 1 596 664
return 1 615 669
assign 1 619 673
new 0 619 673
return 1 635 676
return 1 654 681
assign 1 658 685
new 0 658 685
return 1 674 688
return 1 693 693
assign 1 698 699
new 0 698 699
assign 1 700 700
new 0 700 700
assign 1 700 703
lesser 1 700 708
multiplyValue 1 701 709
incrementValue 0 700 710
return 1 703 716
assign 1 748 725
new 0 748 725
return 1 748 726
assign 1 790 735
new 0 790 735
return 1 790 736
assign 1 818 745
new 0 818 745
return 1 818 746
assign 1 846 755
new 0 846 755
return 1 846 756
assign 1 874 765
new 0 874 765
return 1 874 766
assign 1 902 775
new 0 902 775
return 1 902 776
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1692630073: return bem_absValue_0();
case 818210964: return bem_toAny_0();
case 817871289: return bem_incrementValue_0();
case -407687427: return bem_fieldNamesGet_0();
case -1709781614: return bem_vintSet_0();
case -1915666683: return bem_serializationIteratorGet_0();
case 1310473306: return bem_toHexString_0();
case 826167413: return bem_classNameGet_0();
case -749268313: return bem_copy_0();
case 2059714582: return bem_toFloat_0();
case 157412208: return bem_increment_0();
case -479412451: return bem_iteratorGet_0();
case 1210407094: return bem_tagGet_0();
case -344688418: return bem_new_0();
case -899256741: return bem_toString_0();
case -1514184278: return bem_serializeContents_0();
case 1315725661: return bem_hashGet_0();
case 770986263: return bem_create_0();
case -1959899288: return bem_fieldIteratorGet_0();
case 1298469763: return bem_vintGet_0();
case 887254713: return bem_sourceFileNameGet_0();
case 846353007: return bem_echo_0();
case -461163615: return bem_abs_0();
case -2062765816: return bem_decrement_0();
case -327712425: return bem_many_0();
case -1945570638: return bem_once_0();
case 1293575145: return bem_serializeToString_0();
case -1705442749: return bem_decrementValue_0();
case -519581463: return bem_deserializeClassNameGet_0();
case 1270756764: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 509956737: return bem_def_1(bevd_0);
case -827103883: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case -1795613741: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 2011695784: return bem_new_1(bevd_0);
case 1818610148: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 1778570900: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -819624675: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 2087810673: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1498396708: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 745727100: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1857454821: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1669600038: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case 248598654: return bem_copyTo_1(bevd_0);
case 1715370141: return bem_sameClass_1(bevd_0);
case 863067844: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case 620037361: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1772678539: return bem_notEquals_1(bevd_0);
case -1274600464: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 1477732575: return bem_otherType_1(bevd_0);
case 1426723630: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case -1548523977: return bem_otherClass_1(bevd_0);
case 509252275: return bem_sameObject_1(bevd_0);
case 1965005377: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case 358728336: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 784918995: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -687581350: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case 788259826: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -233300707: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1010172473: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case -51173981: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -1873982344: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 1498119962: return bem_sameType_1(bevd_0);
case -504197397: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 764679775: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 333207561: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 1946977825: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 997331927: return bem_equals_1(bevd_0);
case -597164057: return bem_defined_1(bevd_0);
case 2144395088: return bem_undef_1(bevd_0);
case -1468949165: return bem_undefined_1(bevd_0);
case 903111721: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -615236020: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 2100763695: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case 896053820: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1343727458: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1189130153: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -319997805: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1675736992: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -455603186: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 494382108: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -390764901: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 262774206: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403771483: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 898144410: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -779175378: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1688080822: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 810769703: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
