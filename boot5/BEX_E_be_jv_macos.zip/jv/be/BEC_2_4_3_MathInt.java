package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
public static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt());
return (BEC_2_4_3_MathInt) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(97));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(71));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(103));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_9_SystemException bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
if (beva_radix.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 110*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(24));
if (beva_radix.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 110*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 110*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_4_3_MathInt_bels_0));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_radix);
bevt_5_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_ta_ph);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 111*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(10));
if (beva_radix.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 113*/ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 114*/
 else /* Line: 115*/ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 116*/
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_ta_ph.bevi_int;
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_12_ta_ph = beva_radix.bem_subtract_1(bevt_13_ta_ph);
bevl_maxA = bevt_11_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(97));
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_15_ta_ph = beva_radix.bem_subtract_1(bevt_16_ta_ph);
bevl_maxa = bevt_14_ta_ph.bem_add_1(bevt_15_ta_ph);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_9_SystemException bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_ta_ph.bevi_int;
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevl_j = bevt_4_ta_ph.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 130*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 130*/ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 134*/ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 134*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 134*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 134*/
 else /* Line: 134*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 134*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 137*/
 else /* Line: 134*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 138*/ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 138*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 138*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 138*/
 else /* Line: 138*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 138*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 141*/
 else /* Line: 134*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 142*/ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 142*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 142*/
 else /* Line: 142*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 142*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 145*/
 else /* Line: 134*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 146*/ {
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_ta_ph);
} /* Line: 148*/
 else /* Line: 134*/ {
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 149*/ {
} /* Line: 149*/
 else /* Line: 151*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_3_MathInt_bels_1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(beva_str);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_2));
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevl_ic);
bevt_24_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 152*/
} /* Line: 134*/
} /* Line: 134*/
} /* Line: 134*/
} /* Line: 134*/
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 155*/
 else /* Line: 130*/ {
break;
} /* Line: 130*/
} /* Line: 130*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_toHexString_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bem_toString_3(beva_res, bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, beva_zeroPad, beva_radix, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 199*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_ts.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 199*/ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(10));
if (bevl_val.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 202*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_ta_ph.bevi_int;
} /* Line: 203*/
 else /* Line: 204*/ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 205*/
bevt_6_ta_ph = beva_res.bem_capacityGet_0();
bevt_7_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_6_ta_ph.bevi_int <= bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 208*/ {
bevt_9_ta_ph = beva_res.bem_capacityGet_0();
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_10_ta_ph);
beva_res.bem_capacitySet_1(bevt_8_ta_ph);
} /* Line: 209*/
bevt_11_ta_ph = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_ta_ph, bevl_val);
bevt_13_ta_ph = beva_res.bem_sizeGet_0();
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
beva_res.bem_sizeSet_1(bevt_12_ta_ph);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 216*/
 else /* Line: 199*/ {
break;
} /* Line: 199*/
} /* Line: 199*/
while (true)
/* Line: 219*/ {
bevt_16_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_16_ta_ph.bevi_int < beva_zeroPad.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_18_ta_ph = beva_res.bem_capacityGet_0();
bevt_19_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_18_ta_ph.bevi_int <= bevt_19_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 220*/ {
bevt_21_ta_ph = beva_res.bem_capacityGet_0();
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_22_ta_ph);
beva_res.bem_capacitySet_1(bevt_20_ta_ph);
} /* Line: 221*/
bevt_23_ta_ph = beva_res.bem_sizeGet_0();
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(48));
beva_res.bem_setIntUnchecked_2(bevt_23_ta_ph, bevt_24_ta_ph);
bevt_26_ta_ph = beva_res.bem_sizeGet_0();
bevt_27_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevt_27_ta_ph);
beva_res.bem_sizeSet_1(bevt_25_ta_ph);
} /* Line: 225*/
 else /* Line: 219*/ {
break;
} /* Line: 219*/
} /* Line: 219*/
bevt_29_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_29_ta_ph.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 229*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_30_ta_ph);
} /* Line: 230*/
bevt_31_ta_ph = beva_res.bem_reverseBytes_0();
return bevt_31_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_absValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 246*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_ta_ph);
} /* Line: 247*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 681*/ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 681*/ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 681*/
 else /* Line: 681*/ {
break;
} /* Line: 681*/
} /* Line: 681*/
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {91, 91, 94, 98, 102, 102, 102, 102, 102, 106, 106, 106, 106, 106, 110, 110, 110, 0, 110, 110, 110, 0, 0, 111, 111, 111, 111, 113, 113, 113, 114, 116, 118, 118, 119, 119, 119, 119, 120, 120, 120, 120, 121, 125, 125, 126, 126, 127, 128, 129, 130, 130, 130, 132, 134, 134, 134, 134, 134, 0, 0, 0, 135, 135, 136, 137, 138, 138, 138, 138, 138, 0, 0, 0, 139, 139, 140, 141, 142, 142, 142, 142, 142, 0, 0, 0, 143, 143, 144, 145, 146, 146, 146, 148, 148, 149, 149, 149, 152, 152, 152, 152, 152, 152, 152, 154, 155, 160, 160, 164, 168, 168, 172, 176, 176, 176, 176, 176, 176, 180, 180, 180, 180, 184, 184, 184, 184, 188, 188, 188, 188, 192, 192, 192, 196, 197, 198, 199, 199, 199, 200, 201, 202, 202, 202, 203, 203, 205, 208, 208, 208, 208, 209, 209, 209, 209, 211, 211, 212, 212, 212, 212, 216, 219, 219, 219, 220, 220, 220, 220, 221, 221, 221, 221, 223, 223, 223, 224, 224, 224, 224, 229, 229, 229, 230, 230, 232, 232, 236, 237, 238, 242, 242, 242, 246, 246, 246, 247, 247, 268, 272, 283, 287, 298, 317, 336, 340, 351, 370, 374, 385, 404, 408, 419, 438, 442, 459, 484, 488, 499, 518, 522, 538, 557, 561, 577, 596, 600, 616, 635, 639, 655, 674, 679, 681, 681, 681, 682, 681, 684, 729, 729, 771, 771, 799, 799, 827, 827, 855, 855, 883, 883};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 35, 39, 47, 48, 49, 50, 51, 59, 60, 61, 62, 63, 87, 88, 93, 94, 97, 98, 103, 104, 107, 111, 112, 113, 114, 116, 117, 122, 123, 126, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 175, 176, 177, 178, 179, 180, 181, 184, 185, 190, 191, 192, 193, 198, 199, 204, 205, 208, 212, 215, 216, 217, 218, 221, 222, 227, 228, 233, 234, 237, 241, 244, 245, 246, 247, 250, 251, 256, 257, 262, 263, 266, 270, 273, 274, 275, 276, 279, 280, 285, 286, 287, 290, 291, 296, 299, 300, 301, 302, 303, 304, 305, 311, 312, 322, 323, 326, 331, 332, 335, 343, 344, 345, 346, 347, 348, 354, 355, 356, 357, 363, 364, 365, 366, 372, 373, 374, 375, 380, 381, 382, 419, 420, 421, 424, 425, 430, 431, 432, 433, 434, 439, 440, 441, 444, 446, 447, 448, 453, 454, 455, 456, 457, 459, 460, 461, 462, 463, 464, 465, 473, 474, 479, 480, 481, 482, 487, 488, 489, 490, 491, 493, 494, 495, 496, 497, 498, 499, 505, 506, 511, 512, 513, 515, 516, 520, 521, 522, 527, 528, 529, 535, 536, 541, 542, 543, 550, 554, 557, 561, 564, 569, 574, 578, 581, 586, 590, 593, 598, 602, 605, 610, 614, 617, 622, 626, 629, 634, 638, 641, 646, 650, 653, 658, 662, 665, 670, 674, 677, 682, 688, 689, 692, 697, 698, 699, 705, 713, 714, 722, 723, 731, 732, 740, 741, 749, 750, 758, 759};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 91 31
new 0 91 31
return 1 91 32
setStringValueDec 1 94 35
setStringValueHex 1 98 39
assign 1 102 47
new 0 102 47
assign 1 102 48
new 0 102 48
assign 1 102 49
new 0 102 49
assign 1 102 50
new 0 102 50
setStringValue 5 102 51
assign 1 106 59
new 0 106 59
assign 1 106 60
new 0 106 60
assign 1 106 61
new 0 106 61
assign 1 106 62
new 0 106 62
setStringValue 5 106 63
assign 1 110 87
new 0 110 87
assign 1 110 88
lesser 1 110 93
assign 1 0 94
assign 1 110 97
new 0 110 97
assign 1 110 98
greater 1 110 103
assign 1 0 104
assign 1 0 107
assign 1 111 111
new 0 111 111
assign 1 111 112
add 1 111 112
assign 1 111 113
new 1 111 113
throw 1 111 114
assign 1 113 116
new 0 113 116
assign 1 113 117
lesser 1 113 122
assign 1 114 123
copy 0 114 123
assign 1 116 126
new 0 116 126
assign 1 118 128
new 0 118 128
addValue 1 118 129
assign 1 119 130
new 0 119 130
assign 1 119 131
new 0 119 131
assign 1 119 132
subtract 1 119 132
assign 1 119 133
add 1 119 133
assign 1 120 134
new 0 120 134
assign 1 120 135
new 0 120 135
assign 1 120 136
subtract 1 120 136
assign 1 120 137
add 1 120 137
setStringValue 5 121 138
assign 1 125 175
new 0 125 175
setValue 1 125 176
assign 1 126 177
sizeGet 0 126 177
assign 1 126 178
copy 0 126 178
decrementValue 0 127 179
assign 1 128 180
new 0 128 180
assign 1 129 181
new 0 129 181
assign 1 130 184
new 0 130 184
assign 1 130 185
greaterEquals 1 130 190
getInt 2 132 191
assign 1 134 192
new 0 134 192
assign 1 134 193
greater 1 134 198
assign 1 134 199
lesser 1 134 204
assign 1 0 205
assign 1 0 208
assign 1 0 212
assign 1 135 215
new 0 135 215
subtractValue 1 135 216
multiplyValue 1 136 217
addValue 1 137 218
assign 1 138 221
new 0 138 221
assign 1 138 222
greater 1 138 227
assign 1 138 228
lesser 1 138 233
assign 1 0 234
assign 1 0 237
assign 1 0 241
assign 1 139 244
new 0 139 244
subtractValue 1 139 245
multiplyValue 1 140 246
addValue 1 141 247
assign 1 142 250
new 0 142 250
assign 1 142 251
greater 1 142 256
assign 1 142 257
lesser 1 142 262
assign 1 0 263
assign 1 0 266
assign 1 0 270
assign 1 143 273
new 0 143 273
subtractValue 1 143 274
multiplyValue 1 144 275
addValue 1 145 276
assign 1 146 279
new 0 146 279
assign 1 146 280
equals 1 146 285
assign 1 148 286
new 0 148 286
multiplyValue 1 148 287
assign 1 149 290
new 0 149 290
assign 1 149 291
equals 1 149 296
assign 1 152 299
new 0 152 299
assign 1 152 300
add 1 152 300
assign 1 152 301
new 0 152 301
assign 1 152 302
add 1 152 302
assign 1 152 303
add 1 152 303
assign 1 152 304
new 1 152 304
throw 1 152 305
decrementValue 0 154 311
multiplyValue 1 155 312
assign 1 160 322
toString 0 160 322
return 1 160 323
new 1 164 326
assign 1 168 331
new 0 168 331
return 1 168 332
return 1 172 335
assign 1 176 343
new 0 176 343
assign 1 176 344
new 1 176 344
assign 1 176 345
new 0 176 345
assign 1 176 346
new 0 176 346
assign 1 176 347
toString 4 176 347
return 1 176 348
assign 1 180 354
new 0 180 354
assign 1 180 355
new 1 180 355
assign 1 180 356
toHexString 1 180 356
return 1 180 357
assign 1 184 363
new 0 184 363
assign 1 184 364
new 0 184 364
assign 1 184 365
toString 3 184 365
return 1 184 366
assign 1 188 372
new 1 188 372
assign 1 188 373
new 0 188 373
assign 1 188 374
toString 4 188 374
return 1 188 375
assign 1 192 380
new 0 192 380
assign 1 192 381
toString 4 192 381
return 1 192 382
clear 0 196 419
assign 1 197 420
abs 0 197 420
assign 1 198 421
new 0 198 421
assign 1 199 424
new 0 199 424
assign 1 199 425
greater 1 199 430
setValue 1 200 431
modulusValue 1 201 432
assign 1 202 433
new 0 202 433
assign 1 202 434
lesser 1 202 439
assign 1 203 440
new 0 203 440
addValue 1 203 441
addValue 1 205 444
assign 1 208 446
capacityGet 0 208 446
assign 1 208 447
sizeGet 0 208 447
assign 1 208 448
lesserEquals 1 208 453
assign 1 209 454
capacityGet 0 209 454
assign 1 209 455
new 0 209 455
assign 1 209 456
add 1 209 456
capacitySet 1 209 457
assign 1 211 459
sizeGet 0 211 459
setIntUnchecked 2 211 460
assign 1 212 461
sizeGet 0 212 461
assign 1 212 462
new 0 212 462
assign 1 212 463
add 1 212 463
sizeSet 1 212 464
divideValue 1 216 465
assign 1 219 473
sizeGet 0 219 473
assign 1 219 474
lesser 1 219 479
assign 1 220 480
capacityGet 0 220 480
assign 1 220 481
sizeGet 0 220 481
assign 1 220 482
lesserEquals 1 220 487
assign 1 221 488
capacityGet 0 221 488
assign 1 221 489
new 0 221 489
assign 1 221 490
add 1 221 490
capacitySet 1 221 491
assign 1 223 493
sizeGet 0 223 493
assign 1 223 494
new 0 223 494
setIntUnchecked 2 223 495
assign 1 224 496
sizeGet 0 224 496
assign 1 224 497
new 0 224 497
assign 1 224 498
add 1 224 498
sizeSet 1 224 499
assign 1 229 505
new 0 229 505
assign 1 229 506
lesser 1 229 511
assign 1 230 512
new 0 230 512
addValue 1 230 513
assign 1 232 515
reverseBytes 0 232 515
return 1 232 516
assign 1 236 520
new 0 236 520
setValue 1 237 521
return 1 238 522
assign 1 242 527
copy 0 242 527
assign 1 242 528
absValue 0 242 528
return 1 242 529
assign 1 246 535
new 0 246 535
assign 1 246 536
lesser 1 246 541
assign 1 247 542
new 0 247 542
multiplyValue 1 247 543
return 1 268 550
assign 1 272 554
new 0 272 554
return 1 283 557
assign 1 287 561
new 0 287 561
return 1 298 564
return 1 317 569
return 1 336 574
assign 1 340 578
new 0 340 578
return 1 351 581
return 1 370 586
assign 1 374 590
new 0 374 590
return 1 385 593
return 1 404 598
assign 1 408 602
new 0 408 602
return 1 419 605
return 1 438 610
assign 1 442 614
new 0 442 614
return 1 459 617
return 1 484 622
assign 1 488 626
new 0 488 626
return 1 499 629
return 1 518 634
assign 1 522 638
new 0 522 638
return 1 538 641
return 1 557 646
assign 1 561 650
new 0 561 650
return 1 577 653
return 1 596 658
assign 1 600 662
new 0 600 662
return 1 616 665
return 1 635 670
assign 1 639 674
new 0 639 674
return 1 655 677
return 1 674 682
assign 1 679 688
new 0 679 688
assign 1 681 689
new 0 681 689
assign 1 681 692
lesser 1 681 697
multiplyValue 1 682 698
incrementValue 0 681 699
return 1 684 705
assign 1 729 713
new 0 729 713
return 1 729 714
assign 1 771 722
new 0 771 722
return 1 771 723
assign 1 799 731
new 0 799 731
return 1 799 732
assign 1 827 740
new 0 827 740
return 1 827 741
assign 1 855 749
new 0 855 749
return 1 855 750
assign 1 883 758
new 0 883 758
return 1 883 759
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1777879387: return bem_absValue_0();
case -709158469: return bem_toHexString_0();
case -1844269288: return bem_create_0();
case 1198989510: return bem_incrementValue_0();
case 1861855516: return bem_copy_0();
case 100424814: return bem_decrementValue_0();
case -1710764197: return bem_vintGet_0();
case -1425898375: return bem_new_0();
case -1876046565: return bem_abs_0();
case -1717921599: return bem_serializeToString_0();
case 1788527916: return bem_decrement_0();
case 1676715436: return bem_iteratorGet_0();
case -2042483961: return bem_toString_0();
case 1876953354: return bem_serializeContentsGet_0();
case 1314037741: return bem_vintSet_0();
case 1313758565: return bem_increment_0();
case 436863164: return bem_hashGet_0();
case -1757033570: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1328304995: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case 1408376488: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1067548198: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -1243687912: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case -272587445: return bem_notEquals_1(bevd_0);
case 1898916166: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case -2115989641: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 1089170059: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case -342530123: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2015800048: return bem_new_1(bevd_0);
case 644069523: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case -1243516374: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -720139703: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 1406061091: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case 151315471: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1371556380: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1306600423: return bem_equals_1(bevd_0);
case 1955405002: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1722224142: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1888336048: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 324846295: return bem_def_1(bevd_0);
case -1082695866: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case 268105310: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1051624606: return bem_undef_1(bevd_0);
case 1586592391: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1423618965: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -959236957: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 1784922692: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1439829637: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1107038442: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -2086891498: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case -2069120687: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1031379539: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -371582843: return bem_copyTo_1(bevd_0);
case -1500390972: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1988377034: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1779260160: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1263166407: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1704989212: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1725892051: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1176905374: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 90392107: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 832418685: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 6740985: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
