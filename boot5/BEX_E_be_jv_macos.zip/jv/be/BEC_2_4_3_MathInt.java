package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
public static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt());
return (BEC_2_4_3_MathInt) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(97));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(71));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(103));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_9_SystemException bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
if (beva_radix.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 116*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 116*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(24));
if (beva_radix.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 116*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 116*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 116*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 116*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_4_3_MathInt_bels_0));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_radix);
bevt_5_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_ta_ph);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 117*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(10));
if (beva_radix.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 119*/ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 120*/
 else /* Line: 121*/ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 122*/
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_ta_ph.bevi_int;
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_12_ta_ph = beva_radix.bem_subtract_1(bevt_13_ta_ph);
bevl_maxA = bevt_11_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(97));
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_15_ta_ph = beva_radix.bem_subtract_1(bevt_16_ta_ph);
bevl_maxa = bevt_14_ta_ph.bem_add_1(bevt_15_ta_ph);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_9_SystemException bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_ta_ph.bevi_int;
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevl_j = bevt_4_ta_ph.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 136*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 136*/ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 140*/ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 140*/
 else /* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 140*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 143*/
 else /* Line: 140*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 144*/ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 144*/
 else /* Line: 144*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 144*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 147*/
 else /* Line: 140*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 148*/ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 148*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 148*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 148*/
 else /* Line: 148*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 148*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 151*/
 else /* Line: 140*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_ta_ph);
} /* Line: 154*/
 else /* Line: 140*/ {
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 155*/ {
} /* Line: 155*/
 else /* Line: 157*/ {
bevt_28_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_4_3_MathInt_bels_1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(beva_str);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_2));
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevl_ic);
bevt_24_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 158*/
} /* Line: 140*/
} /* Line: 140*/
} /* Line: 140*/
} /* Line: 140*/
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 161*/
 else /* Line: 136*/ {
break;
} /* Line: 136*/
} /* Line: 136*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_toHexString_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bem_toString_3(beva_res, bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, beva_zeroPad, beva_radix, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt());
while (true)
/* Line: 205*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_ts.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 205*/ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(10));
if (bevl_val.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 208*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_ta_ph.bevi_int;
} /* Line: 209*/
 else /* Line: 210*/ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 211*/
bevt_6_ta_ph = beva_res.bem_capacityGet_0();
bevt_7_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_6_ta_ph.bevi_int <= bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 214*/ {
bevt_9_ta_ph = beva_res.bem_capacityGet_0();
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_10_ta_ph);
beva_res.bem_capacitySet_1(bevt_8_ta_ph);
} /* Line: 215*/
bevt_11_ta_ph = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_ta_ph, bevl_val);
bevt_13_ta_ph = beva_res.bem_sizeGet_0();
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
beva_res.bem_sizeSet_1(bevt_12_ta_ph);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 222*/
 else /* Line: 205*/ {
break;
} /* Line: 205*/
} /* Line: 205*/
while (true)
/* Line: 225*/ {
bevt_16_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_16_ta_ph.bevi_int < beva_zeroPad.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 225*/ {
bevt_18_ta_ph = beva_res.bem_capacityGet_0();
bevt_19_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_18_ta_ph.bevi_int <= bevt_19_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 226*/ {
bevt_21_ta_ph = beva_res.bem_capacityGet_0();
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_22_ta_ph);
beva_res.bem_capacitySet_1(bevt_20_ta_ph);
} /* Line: 227*/
bevt_23_ta_ph = beva_res.bem_sizeGet_0();
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(48));
beva_res.bem_setIntUnchecked_2(bevt_23_ta_ph, bevt_24_ta_ph);
bevt_26_ta_ph = beva_res.bem_sizeGet_0();
bevt_27_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevt_27_ta_ph);
beva_res.bem_sizeSet_1(bevt_25_ta_ph);
} /* Line: 231*/
 else /* Line: 225*/ {
break;
} /* Line: 225*/
} /* Line: 225*/
bevt_29_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_29_ta_ph.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 235*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_30_ta_ph);
} /* Line: 236*/
bevt_31_ta_ph = beva_res.bem_reverseBytes_0();
return bevt_31_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_absValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 252*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_ta_ph);
} /* Line: 253*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 687*/ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 687*/ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 687*/
 else /* Line: 687*/ {
break;
} /* Line: 687*/
} /* Line: 687*/
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {97, 97, 100, 104, 108, 108, 108, 108, 108, 112, 112, 112, 112, 112, 116, 116, 116, 0, 116, 116, 116, 0, 0, 117, 117, 117, 117, 119, 119, 119, 120, 122, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 127, 131, 131, 132, 132, 133, 134, 135, 136, 136, 136, 138, 140, 140, 140, 140, 140, 0, 0, 0, 141, 141, 142, 143, 144, 144, 144, 144, 144, 0, 0, 0, 145, 145, 146, 147, 148, 148, 148, 148, 148, 0, 0, 0, 149, 149, 150, 151, 152, 152, 152, 154, 154, 155, 155, 155, 158, 158, 158, 158, 158, 158, 158, 160, 161, 166, 166, 170, 174, 174, 178, 182, 182, 182, 182, 182, 182, 186, 186, 186, 186, 190, 190, 190, 190, 194, 194, 194, 194, 198, 198, 198, 202, 203, 204, 205, 205, 205, 206, 207, 208, 208, 208, 209, 209, 211, 214, 214, 214, 214, 215, 215, 215, 215, 217, 217, 218, 218, 218, 218, 222, 225, 225, 225, 226, 226, 226, 226, 227, 227, 227, 227, 229, 229, 229, 230, 230, 230, 230, 235, 235, 235, 236, 236, 238, 238, 242, 243, 244, 248, 248, 248, 252, 252, 252, 253, 253, 274, 278, 289, 293, 304, 323, 342, 346, 357, 376, 380, 391, 410, 414, 425, 444, 448, 465, 490, 494, 505, 524, 528, 544, 563, 567, 583, 602, 606, 622, 641, 645, 661, 680, 685, 687, 687, 687, 688, 687, 690, 735, 735, 777, 777, 805, 805, 833, 833, 861, 861, 889, 889};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 35, 39, 47, 48, 49, 50, 51, 59, 60, 61, 62, 63, 87, 88, 93, 94, 97, 98, 103, 104, 107, 111, 112, 113, 114, 116, 117, 122, 123, 126, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 175, 176, 177, 178, 179, 180, 181, 184, 185, 190, 191, 192, 193, 198, 199, 204, 205, 208, 212, 215, 216, 217, 218, 221, 222, 227, 228, 233, 234, 237, 241, 244, 245, 246, 247, 250, 251, 256, 257, 262, 263, 266, 270, 273, 274, 275, 276, 279, 280, 285, 286, 287, 290, 291, 296, 299, 300, 301, 302, 303, 304, 305, 311, 312, 322, 323, 326, 331, 332, 335, 343, 344, 345, 346, 347, 348, 354, 355, 356, 357, 363, 364, 365, 366, 372, 373, 374, 375, 380, 381, 382, 419, 420, 421, 424, 425, 430, 431, 432, 433, 434, 439, 440, 441, 444, 446, 447, 448, 453, 454, 455, 456, 457, 459, 460, 461, 462, 463, 464, 465, 473, 474, 479, 480, 481, 482, 487, 488, 489, 490, 491, 493, 494, 495, 496, 497, 498, 499, 505, 506, 511, 512, 513, 515, 516, 520, 521, 522, 527, 528, 529, 535, 536, 541, 542, 543, 550, 554, 557, 561, 564, 569, 574, 578, 581, 586, 590, 593, 598, 602, 605, 610, 614, 617, 622, 626, 629, 634, 638, 641, 646, 650, 653, 658, 662, 665, 670, 674, 677, 682, 688, 689, 692, 697, 698, 699, 705, 713, 714, 722, 723, 731, 732, 740, 741, 749, 750, 758, 759};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 97 31
new 0 97 31
return 1 97 32
setStringValueDec 1 100 35
setStringValueHex 1 104 39
assign 1 108 47
new 0 108 47
assign 1 108 48
new 0 108 48
assign 1 108 49
new 0 108 49
assign 1 108 50
new 0 108 50
setStringValue 5 108 51
assign 1 112 59
new 0 112 59
assign 1 112 60
new 0 112 60
assign 1 112 61
new 0 112 61
assign 1 112 62
new 0 112 62
setStringValue 5 112 63
assign 1 116 87
new 0 116 87
assign 1 116 88
lesser 1 116 93
assign 1 0 94
assign 1 116 97
new 0 116 97
assign 1 116 98
greater 1 116 103
assign 1 0 104
assign 1 0 107
assign 1 117 111
new 0 117 111
assign 1 117 112
add 1 117 112
assign 1 117 113
new 1 117 113
throw 1 117 114
assign 1 119 116
new 0 119 116
assign 1 119 117
lesser 1 119 122
assign 1 120 123
copy 0 120 123
assign 1 122 126
new 0 122 126
assign 1 124 128
new 0 124 128
addValue 1 124 129
assign 1 125 130
new 0 125 130
assign 1 125 131
new 0 125 131
assign 1 125 132
subtract 1 125 132
assign 1 125 133
add 1 125 133
assign 1 126 134
new 0 126 134
assign 1 126 135
new 0 126 135
assign 1 126 136
subtract 1 126 136
assign 1 126 137
add 1 126 137
setStringValue 5 127 138
assign 1 131 175
new 0 131 175
setValue 1 131 176
assign 1 132 177
sizeGet 0 132 177
assign 1 132 178
copy 0 132 178
decrementValue 0 133 179
assign 1 134 180
new 0 134 180
assign 1 135 181
new 0 135 181
assign 1 136 184
new 0 136 184
assign 1 136 185
greaterEquals 1 136 190
getInt 2 138 191
assign 1 140 192
new 0 140 192
assign 1 140 193
greater 1 140 198
assign 1 140 199
lesser 1 140 204
assign 1 0 205
assign 1 0 208
assign 1 0 212
assign 1 141 215
new 0 141 215
subtractValue 1 141 216
multiplyValue 1 142 217
addValue 1 143 218
assign 1 144 221
new 0 144 221
assign 1 144 222
greater 1 144 227
assign 1 144 228
lesser 1 144 233
assign 1 0 234
assign 1 0 237
assign 1 0 241
assign 1 145 244
new 0 145 244
subtractValue 1 145 245
multiplyValue 1 146 246
addValue 1 147 247
assign 1 148 250
new 0 148 250
assign 1 148 251
greater 1 148 256
assign 1 148 257
lesser 1 148 262
assign 1 0 263
assign 1 0 266
assign 1 0 270
assign 1 149 273
new 0 149 273
subtractValue 1 149 274
multiplyValue 1 150 275
addValue 1 151 276
assign 1 152 279
new 0 152 279
assign 1 152 280
equals 1 152 285
assign 1 154 286
new 0 154 286
multiplyValue 1 154 287
assign 1 155 290
new 0 155 290
assign 1 155 291
equals 1 155 296
assign 1 158 299
new 0 158 299
assign 1 158 300
add 1 158 300
assign 1 158 301
new 0 158 301
assign 1 158 302
add 1 158 302
assign 1 158 303
add 1 158 303
assign 1 158 304
new 1 158 304
throw 1 158 305
decrementValue 0 160 311
multiplyValue 1 161 312
assign 1 166 322
toString 0 166 322
return 1 166 323
new 1 170 326
assign 1 174 331
new 0 174 331
return 1 174 332
return 1 178 335
assign 1 182 343
new 0 182 343
assign 1 182 344
new 1 182 344
assign 1 182 345
new 0 182 345
assign 1 182 346
new 0 182 346
assign 1 182 347
toString 4 182 347
return 1 182 348
assign 1 186 354
new 0 186 354
assign 1 186 355
new 1 186 355
assign 1 186 356
toHexString 1 186 356
return 1 186 357
assign 1 190 363
new 0 190 363
assign 1 190 364
new 0 190 364
assign 1 190 365
toString 3 190 365
return 1 190 366
assign 1 194 372
new 1 194 372
assign 1 194 373
new 0 194 373
assign 1 194 374
toString 4 194 374
return 1 194 375
assign 1 198 380
new 0 198 380
assign 1 198 381
toString 4 198 381
return 1 198 382
clear 0 202 419
assign 1 203 420
abs 0 203 420
assign 1 204 421
new 0 204 421
assign 1 205 424
new 0 205 424
assign 1 205 425
greater 1 205 430
setValue 1 206 431
modulusValue 1 207 432
assign 1 208 433
new 0 208 433
assign 1 208 434
lesser 1 208 439
assign 1 209 440
new 0 209 440
addValue 1 209 441
addValue 1 211 444
assign 1 214 446
capacityGet 0 214 446
assign 1 214 447
sizeGet 0 214 447
assign 1 214 448
lesserEquals 1 214 453
assign 1 215 454
capacityGet 0 215 454
assign 1 215 455
new 0 215 455
assign 1 215 456
add 1 215 456
capacitySet 1 215 457
assign 1 217 459
sizeGet 0 217 459
setIntUnchecked 2 217 460
assign 1 218 461
sizeGet 0 218 461
assign 1 218 462
new 0 218 462
assign 1 218 463
add 1 218 463
sizeSet 1 218 464
divideValue 1 222 465
assign 1 225 473
sizeGet 0 225 473
assign 1 225 474
lesser 1 225 479
assign 1 226 480
capacityGet 0 226 480
assign 1 226 481
sizeGet 0 226 481
assign 1 226 482
lesserEquals 1 226 487
assign 1 227 488
capacityGet 0 227 488
assign 1 227 489
new 0 227 489
assign 1 227 490
add 1 227 490
capacitySet 1 227 491
assign 1 229 493
sizeGet 0 229 493
assign 1 229 494
new 0 229 494
setIntUnchecked 2 229 495
assign 1 230 496
sizeGet 0 230 496
assign 1 230 497
new 0 230 497
assign 1 230 498
add 1 230 498
sizeSet 1 230 499
assign 1 235 505
new 0 235 505
assign 1 235 506
lesser 1 235 511
assign 1 236 512
new 0 236 512
addValue 1 236 513
assign 1 238 515
reverseBytes 0 238 515
return 1 238 516
assign 1 242 520
new 0 242 520
setValue 1 243 521
return 1 244 522
assign 1 248 527
copy 0 248 527
assign 1 248 528
absValue 0 248 528
return 1 248 529
assign 1 252 535
new 0 252 535
assign 1 252 536
lesser 1 252 541
assign 1 253 542
new 0 253 542
multiplyValue 1 253 543
return 1 274 550
assign 1 278 554
new 0 278 554
return 1 289 557
assign 1 293 561
new 0 293 561
return 1 304 564
return 1 323 569
return 1 342 574
assign 1 346 578
new 0 346 578
return 1 357 581
return 1 376 586
assign 1 380 590
new 0 380 590
return 1 391 593
return 1 410 598
assign 1 414 602
new 0 414 602
return 1 425 605
return 1 444 610
assign 1 448 614
new 0 448 614
return 1 465 617
return 1 490 622
assign 1 494 626
new 0 494 626
return 1 505 629
return 1 524 634
assign 1 528 638
new 0 528 638
return 1 544 641
return 1 563 646
assign 1 567 650
new 0 567 650
return 1 583 653
return 1 602 658
assign 1 606 662
new 0 606 662
return 1 622 665
return 1 641 670
assign 1 645 674
new 0 645 674
return 1 661 677
return 1 680 682
assign 1 685 688
new 0 685 688
assign 1 687 689
new 0 687 689
assign 1 687 692
lesser 1 687 697
multiplyValue 1 688 698
incrementValue 0 687 699
return 1 690 705
assign 1 735 713
new 0 735 713
return 1 735 714
assign 1 777 722
new 0 777 722
return 1 777 723
assign 1 805 731
new 0 805 731
return 1 805 732
assign 1 833 740
new 0 833 740
return 1 833 741
assign 1 861 749
new 0 861 749
return 1 861 750
assign 1 889 758
new 0 889 758
return 1 889 759
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 241641629: return bem_serializeToString_0();
case 355872954: return bem_abs_0();
case 688799135: return bem_iteratorGet_0();
case -56849162: return bem_vintSet_0();
case 1680733853: return bem_print_0();
case -1891682779: return bem_increment_0();
case -1961999222: return bem_incrementValue_0();
case -1201402150: return bem_toHexString_0();
case -1006644560: return bem_vintGet_0();
case 77150031: return bem_decrement_0();
case 1479557703: return bem_hashGet_0();
case 1620622728: return bem_serializeContentsGet_0();
case -814788939: return bem_create_0();
case -758107855: return bem_new_0();
case -1115782861: return bem_absValue_0();
case -18711843: return bem_decrementValue_0();
case -303434167: return bem_copy_0();
case 694867988: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 361233160: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case 1624412616: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 1132408466: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 825834562: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1336736643: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -337101477: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 2064744240: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case 599170692: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case 848580023: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case -66846246: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1888177940: return bem_notEquals_1(bevd_0);
case -13855024: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -355178146: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -1242284523: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1437666263: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1678805865: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case -1291263237: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 342133054: return bem_undef_1(bevd_0);
case -1294810885: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 1025733525: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1341593857: return bem_new_1(bevd_0);
case -1597395771: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -2065124594: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1721664005: return bem_copyTo_1(bevd_0);
case -376840077: return bem_def_1(bevd_0);
case 669382554: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -737782143: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 532872569: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -1891848466: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case -2067032143: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1509256374: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case -1571586940: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case -89900049: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -906625808: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case 283685995: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1773263525: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 671480249: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1240491676: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 807856101: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -739362181: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1388702842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -230750159: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1184853729: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 386180779: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
