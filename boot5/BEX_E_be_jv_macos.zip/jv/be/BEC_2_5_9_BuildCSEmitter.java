package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_24, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_27, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_38, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_39, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_40, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_41, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_42, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_46 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_47 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_48 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_48, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_49 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_49, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_50 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_50, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_51 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_51, 3));
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(288971190);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_tmpany_phold = bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_tmpany_phold = bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(772185969);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 42 */
bevt_27_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 51 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(772185969);
if (bevl_firstptsyn.bevi_bool) /* Line: 52 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 53 */
 else  /* Line: 54 */ {
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 55 */
bevt_36_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 57 */
 else  /* Line: 51 */ {
break;
} /* Line: 51 */
} /* Line: 51 */
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevt_41_tmpany_phold = bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_40_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevl_bet.bem_addValue_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_47_tmpany_phold = bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_addValue_1(bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_46_tmpany_phold.bem_addValue_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevl_bet.bem_addValue_1(bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevl_bet.bem_addValue_1(bevt_53_tmpany_phold);
bevl_tout.bemd_1(-1108682476, bevl_bet);
bevl_tout.bemd_0(9597572);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-565741670);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(2114928542);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
return bevt_4_tmpany_phold;
} /* Line: 88 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
return bevt_3_tmpany_phold;
} /* Line: 95 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_45));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_46));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1871413753);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_47));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 49, 49, 50, 51, 51, 0, 51, 51, 53, 55, 55, 57, 57, 57, 57, 59, 59, 61, 61, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 65, 65, 65, 65, 66, 66, 67, 67, 68, 68, 69, 70, 74, 74, 74, 75, 76, 76, 76, 76, 76, 76, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 83, 83, 87, 0, 87, 87, 87, 0, 0, 0, 0, 0, 88, 88, 90, 90, 94, 94, 94, 0, 0, 0, 95, 95, 97, 97, 101, 101, 105, 105, 105, 105, 105, 110, 111, 112, 112, 112, 113, 119, 119, 119, 119, 119, 119, 123, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 127, 131, 131, 131, 135, 135, 135, 135, 135, 135, 135, 139, 139, 143, 143, 143, 147, 147, 147, 147, 151, 151};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {78, 79, 80, 81, 145, 146, 147, 148, 153, 154, 155, 156, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 181, 184, 186, 188, 191, 192, 194, 195, 196, 197, 203, 204, 205, 206, 207, 208, 209, 210, 211, 211, 214, 216, 218, 221, 222, 224, 225, 226, 227, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 305, 306, 315, 317, 320, 325, 326, 328, 331, 335, 338, 341, 345, 346, 348, 349, 357, 362, 363, 365, 368, 372, 375, 376, 378, 379, 383, 384, 391, 392, 393, 394, 395, 401, 402, 403, 404, 405, 406, 415, 416, 417, 418, 419, 420, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 469, 470, 471, 480, 481, 482, 483, 484, 485, 486, 490, 491, 496, 497, 498, 504, 505, 506, 507, 511, 512};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 78
new 0 17 78
assign 1 18 79
new 0 18 79
assign 1 19 80
new 0 19 80
new 1 23 81
assign 1 27 145
classDirGet 0 27 145
assign 1 27 146
fileGet 0 27 146
assign 1 27 147
existsGet 0 27 147
assign 1 27 148
not 0 27 153
assign 1 28 154
classDirGet 0 28 154
assign 1 28 155
fileGet 0 28 155
makeDirs 0 28 156
assign 1 30 158
typePathGet 0 30 158
assign 1 30 159
fileGet 0 30 159
assign 1 30 160
writerGet 0 30 160
assign 1 30 161
open 0 30 161
assign 1 31 162
new 0 31 162
assign 1 32 163
new 0 32 163
addValue 1 32 164
assign 1 33 165
new 0 33 165
assign 1 33 166
addValue 1 33 166
assign 1 33 167
typeEmitNameGet 0 33 167
assign 1 33 168
addValue 1 33 168
assign 1 33 169
new 0 33 169
addValue 1 33 170
assign 1 34 171
new 0 34 171
assign 1 34 172
addValue 1 34 172
assign 1 34 173
typeEmitNameGet 0 34 173
assign 1 34 174
addValue 1 34 174
assign 1 34 175
new 0 34 175
addValue 1 34 176
assign 1 36 177
new 0 36 177
addValue 1 36 178
assign 1 37 179
new 0 37 179
assign 1 38 180
mtdListGet 0 38 180
assign 1 38 181
iteratorGet 0 0 181
assign 1 38 184
hasNextGet 0 38 184
assign 1 38 186
nextGet 0 38 186
assign 1 40 188
new 0 40 188
assign 1 42 191
new 0 42 191
addValue 1 42 192
assign 1 44 194
addValue 1 44 194
assign 1 44 195
nameGet 0 44 195
assign 1 44 196
addValue 1 44 196
addValue 1 44 197
assign 1 46 203
new 0 46 203
addValue 1 46 204
assign 1 47 205
new 0 47 205
addValue 1 47 206
assign 1 49 207
new 0 49 207
addValue 1 49 208
assign 1 50 209
new 0 50 209
assign 1 51 210
ptyListGet 0 51 210
assign 1 51 211
iteratorGet 0 0 211
assign 1 51 214
hasNextGet 0 51 214
assign 1 51 216
nextGet 0 51 216
assign 1 53 218
new 0 53 218
assign 1 55 221
new 0 55 221
addValue 1 55 222
assign 1 57 224
addValue 1 57 224
assign 1 57 225
nameGet 0 57 225
assign 1 57 226
addValue 1 57 226
addValue 1 57 227
assign 1 59 233
new 0 59 233
addValue 1 59 234
assign 1 61 235
new 0 61 235
addValue 1 61 236
assign 1 63 237
new 0 63 237
assign 1 63 238
addValue 1 63 238
assign 1 63 239
typeEmitNameGet 0 63 239
assign 1 63 240
addValue 1 63 240
assign 1 63 241
new 0 63 241
addValue 1 63 242
assign 1 64 243
new 0 64 243
addValue 1 64 244
assign 1 65 245
new 0 65 245
assign 1 65 246
addValue 1 65 246
assign 1 65 247
emitNameGet 0 65 247
assign 1 65 248
addValue 1 65 248
assign 1 65 249
new 0 65 249
addValue 1 65 250
assign 1 66 251
new 0 66 251
addValue 1 66 252
assign 1 67 253
new 0 67 253
addValue 1 67 254
assign 1 68 255
new 0 68 255
addValue 1 68 256
write 1 69 257
close 0 70 258
assign 1 74 280
new 0 74 280
assign 1 74 281
toString 0 74 281
assign 1 74 282
add 1 74 282
incrementValue 0 75 283
assign 1 76 284
new 0 76 284
assign 1 76 285
addValue 1 76 285
assign 1 76 286
addValue 1 76 286
assign 1 76 287
new 0 76 287
assign 1 76 288
addValue 1 76 288
addValue 1 76 289
assign 1 78 290
containedGet 0 78 290
assign 1 78 291
firstGet 0 78 291
assign 1 78 292
containedGet 0 78 292
assign 1 78 293
firstGet 0 78 293
assign 1 78 294
new 0 78 294
assign 1 78 295
add 1 78 295
assign 1 78 296
new 0 78 296
assign 1 78 297
add 1 78 297
assign 1 78 298
new 0 78 298
assign 1 78 299
finalAssign 4 78 299
addValue 1 78 300
assign 1 83 305
new 0 83 305
return 1 83 306
assign 1 87 315
isFinalGet 0 87 315
assign 1 0 317
assign 1 87 320
def 1 87 325
assign 1 87 326
isFinalGet 0 87 326
assign 1 0 328
assign 1 0 331
assign 1 0 335
assign 1 0 338
assign 1 0 341
assign 1 88 345
new 0 88 345
return 1 88 346
assign 1 90 348
new 0 90 348
return 1 90 349
assign 1 94 357
def 1 94 362
assign 1 94 363
isFinalGet 0 94 363
assign 1 0 365
assign 1 0 368
assign 1 0 372
assign 1 95 375
new 0 95 375
return 1 95 376
assign 1 97 378
new 0 97 378
return 1 97 379
assign 1 101 383
new 0 101 383
return 1 101 384
assign 1 105 391
new 0 105 391
assign 1 105 392
add 1 105 392
assign 1 105 393
new 0 105 393
assign 1 105 394
add 1 105 394
return 1 105 395
getCode 2 110 401
assign 1 111 402
toHexString 1 111 402
assign 1 112 403
new 0 112 403
assign 1 112 404
once 0 112 404
addValue 1 112 405
addValue 1 113 406
assign 1 119 415
new 0 119 415
assign 1 119 416
add 1 119 416
assign 1 119 417
new 0 119 417
assign 1 119 418
add 1 119 418
assign 1 119 419
add 1 119 419
return 1 119 420
assign 1 123 442
new 0 123 442
assign 1 123 443
add 1 123 443
assign 1 123 444
new 0 123 444
assign 1 123 445
add 1 123 445
assign 1 123 446
add 1 123 446
assign 1 124 447
new 0 124 447
assign 1 124 448
addValue 1 124 448
assign 1 124 449
addValue 1 124 449
assign 1 124 450
new 0 124 450
assign 1 124 451
addValue 1 124 451
addValue 1 124 452
assign 1 125 453
new 0 125 453
assign 1 125 454
addValue 1 125 454
addValue 1 125 455
assign 1 126 456
new 0 126 456
assign 1 126 457
addValue 1 126 457
assign 1 126 458
outputPlatformGet 0 126 458
assign 1 126 459
nameGet 0 126 459
assign 1 126 460
addValue 1 126 460
assign 1 126 461
new 0 126 461
assign 1 126 462
addValue 1 126 462
addValue 1 126 463
return 1 127 464
assign 1 131 469
libNameGet 0 131 469
assign 1 131 470
beginNs 1 131 470
return 1 131 471
assign 1 135 480
new 0 135 480
assign 1 135 481
libNs 1 135 481
assign 1 135 482
add 1 135 482
assign 1 135 483
new 0 135 483
assign 1 135 484
add 1 135 484
assign 1 135 485
add 1 135 485
return 1 135 486
assign 1 139 490
getNameSpace 1 139 490
return 1 139 491
assign 1 143 496
new 0 143 496
assign 1 143 497
add 1 143 497
return 1 143 498
assign 1 147 504
new 0 147 504
assign 1 147 505
once 0 147 505
assign 1 147 506
add 1 147 506
return 1 147 507
assign 1 151 511
new 0 151 511
return 1 151 512
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -641930861: return bem_lastMethodBodyLinesGetDirect_0();
case 1415223971: return bem_stringNpGet_0();
case -1118187657: return bem_useDynMethodsGet_0();
case -138374155: return bem_nativeCSlotsGetDirect_0();
case 51201540: return bem_lastMethodsLinesGetDirect_0();
case 1409489274: return bem_smnlecsGetDirect_0();
case 861905678: return bem_falseValueGetDirect_0();
case 1496083257: return bem_nativeCSlotsGet_0();
case 1724218028: return bem_nameToIdGet_0();
case -1158413980: return bem_buildGetDirect_0();
case 546251375: return bem_onceCountGet_0();
case 1641099347: return bem_getLibOutput_0();
case -1965805577: return bem_methodCallsGetDirect_0();
case 634917601: return bem_boolNpGet_0();
case 1701128611: return bem_classEndGet_0();
case -323317224: return bem_superCallsGet_0();
case -842081223: return bem_emitLangGet_0();
case 268950612: return bem_classesInDepthOrderGetDirect_0();
case -452734639: return bem_nameToIdPathGetDirect_0();
case 805049377: return bem_inClassGet_0();
case 510740763: return bem_echo_0();
case -1311613209: return bem_dynMethodsGet_0();
case -1784818407: return bem_serializeContents_0();
case 539964113: return bem_mainOutsideNsGet_0();
case 155727536: return bem_ccMethodsGetDirect_0();
case 2066607592: return bem_smnlcsGet_0();
case -578397480: return bem_ntypesGetDirect_0();
case 1994147939: return bem_emitLib_0();
case 969122546: return bem_maxDynArgsGetDirect_0();
case 834367967: return bem_propertyDecsGetDirect_0();
case 1506082444: return bem_methodsGet_0();
case 1543553352: return bem_propertyDecsGet_0();
case 247244319: return bem_lastCallGet_0();
case 294416408: return bem_boolTypeGet_0();
case 172640264: return bem_stringNpGetDirect_0();
case -883765858: return bem_libEmitPathGet_0();
case -844377762: return bem_methodCatchGet_0();
case 248294284: return bem_smnlcsGetDirect_0();
case -1647044627: return bem_mnodeGet_0();
case 1754760186: return bem_iteratorGet_0();
case 1076055334: return bem_nameToIdGetDirect_0();
case -1569137248: return bem_baseSmtdDecGet_0();
case 1297893564: return bem_libEmitPathGetDirect_0();
case -1660492811: return bem_returnTypeGetDirect_0();
case 1925505968: return bem_inFilePathedGet_0();
case -677880994: return bem_preClassGet_0();
case 2053313156: return bem_returnTypeGet_0();
case 1826423279: return bem_fullLibEmitNameGet_0();
case -273667940: return bem_baseMtdDecGet_0();
case 1644468992: return bem_objectNpGet_0();
case -261216024: return bem_instOfGetDirect_0();
case 620713025: return bem_nullValueGetDirect_0();
case 2053632457: return bem_synEmitPathGet_0();
case 1553771989: return bem_maxSpillArgsLenGetDirect_0();
case 1600953285: return bem_saveSyns_0();
case 911970070: return bem_lastMethodsLinesGet_0();
case -833893835: return bem_libEmitNameGet_0();
case -146507031: return bem_exceptDecGet_0();
case -509474669: return bem_lastMethodBodyLinesGet_0();
case -441332951: return bem_smnlecsGet_0();
case 629513215: return bem_create_0();
case -857317967: return bem_methodsGetDirect_0();
case -555656699: return bem_objectNpGetDirect_0();
case -2021586315: return bem_transGet_0();
case -1336572611: return bem_qGetDirect_0();
case 258153758: return bem_constGetDirect_0();
case 27905295: return bem_nullValueGet_0();
case -455711370: return bem_methodCallsGet_0();
case -1566168767: return bem_methodBodyGet_0();
case -1893136051: return bem_instanceNotEqualGetDirect_0();
case 353423613: return bem_trueValueGetDirect_0();
case -516300936: return bem_many_0();
case -199826941: return bem_msynGetDirect_0();
case -420636718: return bem_callNamesGet_0();
case 1319001609: return bem_classesInDepthOrderGet_0();
case -2069212926: return bem_callNamesGetDirect_0();
case -304688982: return bem_nlGet_0();
case -329032549: return bem_instOfGet_0();
case 12210090: return bem_classCallsGetDirect_0();
case 1440739422: return bem_idToNameGet_0();
case -1219240461: return bem_msynGet_0();
case -1288777512: return bem_transGetDirect_0();
case 1260060741: return bem_constGet_0();
case -121898153: return bem_instanceEqualGetDirect_0();
case 18744621: return bem_boolNpGetDirect_0();
case 2016645363: return bem_boolCcGet_0();
case 1914514147: return bem_afterCast_0();
case 1875004790: return bem_preClassGetDirect_0();
case 1374986220: return bem_ccCacheGet_0();
case 520238370: return bem_print_0();
case -1906011811: return bem_classNameGet_0();
case 1612179044: return bem_endNs_0();
case 1846185190: return bem_fileExtGet_0();
case -149985636: return bem_parentConfGet_0();
case -479949239: return bem_lineCountGetDirect_0();
case 1841075196: return bem_deserializeClassNameGet_0();
case 1774744776: return bem_ccMethodsGet_0();
case -1773246632: return bem_invpGetDirect_0();
case -1221489348: return bem_trueValueGet_0();
case 495991554: return bem_methodCatchGetDirect_0();
case 1311114940: return bem_maxSpillArgsLenGet_0();
case -499469881: return bem_superNameGet_0();
case 837374047: return bem_fullLibEmitNameGetDirect_0();
case -1781488090: return bem_buildInitial_0();
case 834974873: return bem_once_0();
case -71637796: return bem_intNpGetDirect_0();
case 630175193: return bem_classConfGetDirect_0();
case -586347877: return bem_spropDecGet_0();
case 2014462765: return bem_inClassGetDirect_0();
case -2126470188: return bem_objectCcGetDirect_0();
case -1774384173: return bem_randGetDirect_0();
case -1333636563: return bem_csynGet_0();
case 1246525343: return bem_copy_0();
case 2146615586: return bem_emitLangGetDirect_0();
case -1583394924: return bem_mnodeGetDirect_0();
case 1522977325: return bem_mainInClassGet_0();
case -1618181095: return bem_objectCcGet_0();
case -951361758: return bem_buildGet_0();
case -121425639: return bem_classEmitsGet_0();
case -1963450201: return bem_intNpGet_0();
case 355548466: return bem_classConfGet_0();
case -21306841: return bem_ccCacheGetDirect_0();
case 878091655: return bem_instanceEqualGet_0();
case 1363596807: return bem_toAny_0();
case -319884304: return bem_serializationIteratorGet_0();
case 1448453145: return bem_lineCountGet_0();
case -19560021: return bem_fileExtGetDirect_0();
case -1981833424: return bem_inFilePathedGetDirect_0();
case 752640732: return bem_nameToIdPathGet_0();
case -1759370483: return bem_beginNs_0();
case 1842661129: return bem_maxDynArgsGet_0();
case 1985347066: return bem_libEmitNameGetDirect_0();
case 1264368313: return bem_classEmitsGetDirect_0();
case -31734150: return bem_dynMethodsGetDirect_0();
case 891707168: return bem_superCallsGetDirect_0();
case 865440274: return bem_lastMethodsSizeGet_0();
case -1160930852: return bem_cnodeGetDirect_0();
case -283205576: return bem_overrideMtdDecGet_0();
case -179169425: return bem_exceptDecGetDirect_0();
case 1195479112: return bem_runtimeInitGet_0();
case 2051591602: return bem_cnodeGet_0();
case -665319302: return bem_scvpGet_0();
case 1233890983: return bem_onceCountGetDirect_0();
case 912170343: return bem_falseValueGet_0();
case -1806453680: return bem_preClassOutput_0();
case 572556217: return bem_nlGetDirect_0();
case 672371133: return bem_floatNpGet_0();
case -955176467: return bem_scvpGetDirect_0();
case -845933593: return bem_synEmitPathGetDirect_0();
case 181924838: return bem_saveIds_0();
case 654534455: return bem_invpGet_0();
case -1849076065: return bem_initialDecGet_0();
case 1512034580: return bem_lastMethodsSizeGetDirect_0();
case -2049404332: return bem_fieldIteratorGet_0();
case 1971073283: return bem_loadIds_0();
case -1360935346: return bem_csynGetDirect_0();
case -1963287770: return bem_idToNamePathGetDirect_0();
case -1153621323: return bem_sourceFileNameGet_0();
case 2137709829: return bem_boolCcGetDirect_0();
case 1963631625: return bem_mainEndGet_0();
case 80505915: return bem_fieldNamesGet_0();
case -1150052491: return bem_idToNameGetDirect_0();
case 1250439957: return bem_buildClassInfo_0();
case -266686088: return bem_lastMethodBodySizeGetDirect_0();
case -1151122392: return bem_serializeToString_0();
case 1325005685: return bem_qGet_0();
case -1598531944: return bem_parentConfGetDirect_0();
case -671361255: return bem_onceDecsGetDirect_0();
case -1481120: return bem_hashGet_0();
case -260016569: return bem_new_0();
case 1934827441: return bem_tagGet_0();
case -1501728727: return bem_floatNpGetDirect_0();
case 1383546009: return bem_propDecGet_0();
case 1607651413: return bem_randGet_0();
case -2041322689: return bem_onceDecsGet_0();
case 1920068436: return bem_mainStartGet_0();
case 40312046: return bem_idToNamePathGet_0();
case -1968612821: return bem_buildCreate_0();
case -1787706936: return bem_typeDecGet_0();
case 1090384071: return bem_writeBET_0();
case 1376159633: return bem_coanyiantReturnsGet_0();
case 1197659104: return bem_getClassOutput_0();
case -1794573020: return bem_lastMethodBodySizeGet_0();
case -1700654062: return bem_methodBodyGetDirect_0();
case -1803893565: return bem_instanceNotEqualGet_0();
case -973374147: return bem_doEmit_0();
case 1695553285: return bem_toString_0();
case -1882407318: return bem_ntypesGet_0();
case 80036415: return bem_classCallsGet_0();
case -727421147: return bem_lastCallGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -361889096: return bem_nullValueSet_1(bevd_0);
case 1493862628: return bem_maxDynArgsSetDirect_1(bevd_0);
case 1773759648: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -899071506: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 925743769: return bem_ccCacheSetDirect_1(bevd_0);
case 2041503820: return bem_floatNpSet_1(bevd_0);
case -1575644728: return bem_intNpSet_1(bevd_0);
case -1942108524: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 989721692: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -503675708: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -162060766: return bem_falseValueSet_1(bevd_0);
case -450964904: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -252196833: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1274490834: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1812248660: return bem_methodsSet_1(bevd_0);
case 2022041279: return bem_msynSetDirect_1(bevd_0);
case 1221767125: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 187291232: return bem_boolCcSetDirect_1(bevd_0);
case 1398337470: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 305880936: return bem_constSet_1(bevd_0);
case 343163904: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1329768815: return bem_superCallsSet_1(bevd_0);
case 791490513: return bem_classesInDepthOrderSet_1(bevd_0);
case 1994024270: return bem_preClassSet_1(bevd_0);
case -462739699: return bem_qSet_1(bevd_0);
case 51207908: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 978878462: return bem_lastMethodBodySizeSet_1(bevd_0);
case -126662905: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -597911462: return bem_lineCountSetDirect_1(bevd_0);
case -2139347686: return bem_nlSetDirect_1(bevd_0);
case 853722608: return bem_mnodeSet_1(bevd_0);
case -367081752: return bem_nameToIdPathSet_1(bevd_0);
case -1622491216: return bem_methodBodySetDirect_1(bevd_0);
case -52824489: return bem_idToNameSetDirect_1(bevd_0);
case 1113478042: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -85461654: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1664943824: return bem_stringNpSetDirect_1(bevd_0);
case 1413348548: return bem_fileExtSetDirect_1(bevd_0);
case 1445064280: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1934407928: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1727017466: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1405980579: return bem_instOfSet_1(bevd_0);
case -1559803506: return bem_csynSetDirect_1(bevd_0);
case -198910958: return bem_boolNpSet_1(bevd_0);
case 995929518: return bem_instanceEqualSetDirect_1(bevd_0);
case -662154603: return bem_inFilePathedSetDirect_1(bevd_0);
case 1075962476: return bem_methodCatchSet_1(bevd_0);
case -333584865: return bem_smnlecsSet_1(bevd_0);
case -1057356581: return bem_superCallsSetDirect_1(bevd_0);
case 1830379820: return bem_invpSet_1(bevd_0);
case 1233024916: return bem_cnodeSet_1(bevd_0);
case -472125460: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1573802551: return bem_sameObject_1(bevd_0);
case 796059176: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -1479201792: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -2134107370: return bem_nameToIdSet_1(bevd_0);
case -228195679: return bem_copyTo_1(bevd_0);
case 239863586: return bem_boolNpSetDirect_1(bevd_0);
case 1542840183: return bem_msynSet_1(bevd_0);
case 1533031284: return bem_smnlcsSetDirect_1(bevd_0);
case 835146207: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1031344048: return bem_trueValueSetDirect_1(bevd_0);
case 1830919913: return bem_lastMethodsLinesSet_1(bevd_0);
case -199363867: return bem_fullLibEmitNameSet_1(bevd_0);
case 1955316107: return bem_fileExtSet_1(bevd_0);
case 704439319: return bem_propertyDecsSet_1(bevd_0);
case -557111565: return bem_onceDecsSetDirect_1(bevd_0);
case 270596679: return bem_objectNpSetDirect_1(bevd_0);
case -1902563353: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 380056381: return bem_mnodeSetDirect_1(bevd_0);
case -1416633773: return bem_propertyDecsSetDirect_1(bevd_0);
case -320915117: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1661973231: return bem_ntypesSet_1(bevd_0);
case 1303666333: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1341964461: return bem_maxDynArgsSet_1(bevd_0);
case 1847518384: return bem_idToNamePathSetDirect_1(bevd_0);
case 150710665: return bem_randSet_1(bevd_0);
case -108287278: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -761725127: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1459652262: return bem_objectNpSet_1(bevd_0);
case 496004891: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 216738391: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1392586967: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -383182953: return bem_scvpSet_1(bevd_0);
case 1892971336: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -740907965: return bem_floatNpSetDirect_1(bevd_0);
case -1081294418: return bem_lineCountSet_1(bevd_0);
case 428946154: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1512301827: return bem_ccCacheSet_1(bevd_0);
case 1005658398: return bem_buildSetDirect_1(bevd_0);
case 1811082774: return bem_onceDecsSet_1(bevd_0);
case 1580000870: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 2069619325: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1632233231: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -15694464: return bem_methodCatchSetDirect_1(bevd_0);
case 1049358928: return bem_equals_1(bevd_0);
case 1543826887: return bem_buildSet_1(bevd_0);
case -849106920: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 143336558: return bem_inClassSet_1(bevd_0);
case -1051909796: return bem_csynSet_1(bevd_0);
case -1545304414: return bem_instanceEqualSet_1(bevd_0);
case 29716091: return bem_begin_1(bevd_0);
case -580910278: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 653032052: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -884644191: return bem_nullValueSetDirect_1(bevd_0);
case 253811563: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -1253122165: return bem_idToNamePathSet_1(bevd_0);
case 375921982: return bem_constSetDirect_1(bevd_0);
case 1697979752: return bem_cnodeSetDirect_1(bevd_0);
case -119328487: return bem_ccMethodsSetDirect_1(bevd_0);
case 436013790: return bem_trueValueSet_1(bevd_0);
case 1122576928: return bem_objectCcSet_1(bevd_0);
case -310987252: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 188440393: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1440607164: return bem_parentConfSet_1(bevd_0);
case -1725133819: return bem_objectCcSetDirect_1(bevd_0);
case 506528829: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -439996951: return bem_dynMethodsSetDirect_1(bevd_0);
case -951929577: return bem_defined_1(bevd_0);
case -761153528: return bem_dynMethodsSet_1(bevd_0);
case 1172452558: return bem_emitLangSetDirect_1(bevd_0);
case 685317069: return bem_libEmitNameSet_1(bevd_0);
case 1523343000: return bem_sameClass_1(bevd_0);
case 408504379: return bem_methodCallsSet_1(bevd_0);
case -111572750: return bem_falseValueSetDirect_1(bevd_0);
case 273138700: return bem_onceCountSet_1(bevd_0);
case -1144341678: return bem_notEquals_1(bevd_0);
case -395850459: return bem_undefined_1(bevd_0);
case -1606159574: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -2005202313: return bem_ccMethodsSet_1(bevd_0);
case 11223702: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1132667350: return bem_end_1(bevd_0);
case 652227392: return bem_transSet_1(bevd_0);
case 462621647: return bem_def_1(bevd_0);
case 1632372796: return bem_lastCallSet_1(bevd_0);
case -450442959: return bem_ntypesSetDirect_1(bevd_0);
case -200739020: return bem_synEmitPathSet_1(bevd_0);
case 1456536465: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -770277295: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 775340194: return bem_smnlecsSetDirect_1(bevd_0);
case -109180546: return bem_nameToIdSetDirect_1(bevd_0);
case -1752795756: return bem_parentConfSetDirect_1(bevd_0);
case -1386138002: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -429063360: return bem_idToNameSet_1(bevd_0);
case 929098549: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1707475669: return bem_callNamesSet_1(bevd_0);
case -541225887: return bem_nlSet_1(bevd_0);
case -1625671102: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -85945164: return bem_classCallsSetDirect_1(bevd_0);
case 115468921: return bem_exceptDecSet_1(bevd_0);
case -1430533719: return bem_onceCountSetDirect_1(bevd_0);
case -1152586245: return bem_maxSpillArgsLenSet_1(bevd_0);
case 831015921: return bem_classConfSetDirect_1(bevd_0);
case -1445635087: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -192963993: return bem_methodCallsSetDirect_1(bevd_0);
case 605068050: return bem_libEmitPathSet_1(bevd_0);
case -951926936: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 221275419: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 660459075: return bem_intNpSetDirect_1(bevd_0);
case 279269002: return bem_lastMethodsSizeSet_1(bevd_0);
case -1940429677: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1632353878: return bem_undef_1(bevd_0);
case -184684396: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -703273772: return bem_methodBodySet_1(bevd_0);
case 482689426: return bem_otherClass_1(bevd_0);
case -2132039974: return bem_nativeCSlotsSet_1(bevd_0);
case -1088754113: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1909373597: return bem_transSetDirect_1(bevd_0);
case -2003321362: return bem_libEmitNameSetDirect_1(bevd_0);
case -491486505: return bem_emitLangSet_1(bevd_0);
case -1512005598: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 275328152: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 7609893: return bem_classCallsSet_1(bevd_0);
case 138455881: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1675184841: return bem_lastCallSetDirect_1(bevd_0);
case 757142161: return bem_returnTypeSetDirect_1(bevd_0);
case 45497442: return bem_randSetDirect_1(bevd_0);
case -1149023819: return bem_classEmitsSetDirect_1(bevd_0);
case 320742165: return bem_stringNpSet_1(bevd_0);
case -1294149975: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 118692631: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -23054072: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1441432622: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 58982469: return bem_methodsSetDirect_1(bevd_0);
case -1430178609: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -892750554: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -747947725: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 223461373: return bem_instOfSetDirect_1(bevd_0);
case -648943571: return bem_instanceNotEqualSet_1(bevd_0);
case 1803658040: return bem_smnlcsSet_1(bevd_0);
case -769696169: return bem_classEmitsSet_1(bevd_0);
case -2000647991: return bem_invpSetDirect_1(bevd_0);
case 1540517734: return bem_synEmitPathSetDirect_1(bevd_0);
case -2112752268: return bem_inFilePathedSet_1(bevd_0);
case 310115535: return bem_boolCcSet_1(bevd_0);
case -924139841: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1943740753: return bem_inClassSetDirect_1(bevd_0);
case -1605087258: return bem_preClassSetDirect_1(bevd_0);
case -1355561103: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1997751310: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1233250267: return bem_libEmitPathSetDirect_1(bevd_0);
case 2122170094: return bem_otherType_1(bevd_0);
case -484639434: return bem_qSetDirect_1(bevd_0);
case -753793171: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1759935113: return bem_exceptDecSetDirect_1(bevd_0);
case -1281842328: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1012979594: return bem_callNamesSetDirect_1(bevd_0);
case -1533130519: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -998599251: return bem_scvpSetDirect_1(bevd_0);
case 2033324165: return bem_returnTypeSet_1(bevd_0);
case -1560805052: return bem_classConfSet_1(bevd_0);
case -1177836823: return bem_sameType_1(bevd_0);
case 476621767: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1134278648: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1768894021: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1967117180: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1872811781: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1207013071: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 595016345: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -2045271612: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 518732674: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1018924161: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -42068313: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 308804077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -222561805: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 802263707: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 2072018670: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1518228438: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -357078730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1010026607: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 185369359: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2084764755: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -277637599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1244524360: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -366494025: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 2121739188: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -704710659: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -988800189: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 2139213926: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 482770847: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
