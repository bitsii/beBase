package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x20,0x3A,0x20};
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(-994848752);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-1182092368);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(233311811);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-1182092368);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(233311811);
bevt_34_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_34_ta_ph.bevi_bool))/* Line: 51*/ {
if (bevl_firstptsyn.bevi_bool)/* Line: 52*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 53*/
 else /* Line: 54*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_35_ta_ph);
} /* Line: 55*/
bevt_37_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_38_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_36_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 57*/
} /* Line: 51*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_42_ta_ph = bevl_bet.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevt_41_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_46_ta_ph);
bevt_49_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_48_ta_ph = bevl_bet.bem_addValue_1(bevt_49_ta_ph);
bevt_50_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_47_ta_ph = bevt_48_ta_ph.bem_addValue_1(bevt_50_ta_ph);
bevt_51_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevt_47_ta_ph.bem_addValue_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_54_ta_ph);
bevl_tout.bemd_1(424999288, bevl_bet);
bevl_tout.bemd_0(-307743931);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-807521791);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-188836119);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, bevt_16_ta_ph);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_1_ta_ph = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 88*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 88*/ {
if (beva_msyn == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 88*/ {
bevt_3_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 88*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 88*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 88*/
 else /* Line: 88*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 88*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 88*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 88*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 88*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
return bevt_4_ta_ph;
} /* Line: 89*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 95*/
 else /* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 95*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 96*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 120*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(48, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_exceptDec);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevl_ms = bevt_3_ta_ph.bem_add_1(bevp_nl);
} /* Line: 121*/
 else /* Line: 122*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildCSEmitter_bels_36));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_exceptDec);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_10_ta_ph);
bevl_ms = bevt_7_ta_ph.bem_add_1(bevp_nl);
} /* Line: 123*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_37));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_38));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_39));
bevt_16_ta_ph = bevl_ms.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_20_ta_ph = bevl_ms.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(450675272);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_18_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 51, 53, 55, 55, 57, 57, 57, 57, 60, 60, 62, 62, 64, 64, 64, 64, 64, 64, 65, 65, 66, 66, 66, 66, 66, 66, 67, 67, 68, 68, 69, 69, 70, 71, 75, 75, 75, 76, 77, 77, 77, 77, 77, 77, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 84, 84, 88, 0, 88, 88, 88, 0, 0, 0, 0, 0, 89, 89, 91, 91, 95, 95, 95, 0, 0, 0, 96, 96, 98, 98, 102, 102, 107, 108, 109, 109, 110, 116, 116, 116, 116, 116, 116, 120, 120, 120, 121, 121, 121, 121, 121, 123, 123, 123, 123, 123, 125, 125, 125, 125, 125, 125, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 128, 132, 132, 132, 136, 136, 136, 136, 136, 136, 136, 140, 140, 144, 144, 144, 148, 148, 148, 152, 152};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {57, 58, 59, 60, 125, 126, 127, 128, 133, 134, 135, 136, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 161, 164, 166, 168, 171, 172, 174, 175, 176, 177, 183, 184, 185, 186, 187, 188, 189, 190, 191, 191, 194, 196, 197, 200, 203, 204, 206, 207, 208, 209, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 288, 289, 298, 300, 303, 308, 309, 311, 314, 318, 321, 324, 328, 329, 331, 332, 340, 345, 346, 348, 351, 355, 358, 359, 361, 362, 366, 367, 372, 373, 374, 375, 376, 385, 386, 387, 388, 389, 390, 419, 420, 421, 423, 424, 425, 426, 427, 430, 431, 432, 433, 434, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 458, 459, 460, 469, 470, 471, 472, 473, 474, 475, 479, 480, 485, 486, 487, 492, 493, 494, 498, 499};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 57
new 0 16 57
assign 1 17 58
new 0 17 58
assign 1 18 59
new 0 18 59
new 1 22 60
assign 1 26 125
classDirGet 0 26 125
assign 1 26 126
fileGet 0 26 126
assign 1 26 127
existsGet 0 26 127
assign 1 26 128
not 0 26 133
assign 1 27 134
classDirGet 0 27 134
assign 1 27 135
fileGet 0 27 135
makeDirs 0 27 136
assign 1 29 138
typePathGet 0 29 138
assign 1 29 139
fileGet 0 29 139
assign 1 29 140
writerGet 0 29 140
assign 1 29 141
open 0 29 141
assign 1 30 142
new 0 30 142
assign 1 31 143
new 0 31 143
addValue 1 31 144
assign 1 32 145
new 0 32 145
assign 1 32 146
addValue 1 32 146
assign 1 32 147
typeEmitNameGet 0 32 147
assign 1 32 148
addValue 1 32 148
assign 1 32 149
new 0 32 149
addValue 1 32 150
assign 1 33 151
new 0 33 151
assign 1 33 152
addValue 1 33 152
assign 1 33 153
typeEmitNameGet 0 33 153
assign 1 33 154
addValue 1 33 154
assign 1 33 155
new 0 33 155
addValue 1 33 156
assign 1 35 157
new 0 35 157
addValue 1 35 158
assign 1 36 159
new 0 36 159
assign 1 37 160
mtdListGet 0 37 160
assign 1 37 161
iteratorGet 0 0 161
assign 1 37 164
hasNextGet 0 37 164
assign 1 37 166
nextGet 0 37 166
assign 1 39 168
new 0 39 168
assign 1 41 171
new 0 41 171
addValue 1 41 172
assign 1 43 174
addValue 1 43 174
assign 1 43 175
nameGet 0 43 175
assign 1 43 176
addValue 1 43 176
addValue 1 43 177
assign 1 45 183
new 0 45 183
addValue 1 45 184
assign 1 46 185
new 0 46 185
addValue 1 46 186
assign 1 48 187
new 0 48 187
addValue 1 48 188
assign 1 49 189
new 0 49 189
assign 1 50 190
ptyListGet 0 50 190
assign 1 50 191
iteratorGet 0 0 191
assign 1 50 194
hasNextGet 0 50 194
assign 1 50 196
nextGet 0 50 196
assign 1 51 197
isSlotGet 0 51 197
assign 1 53 200
new 0 53 200
assign 1 55 203
new 0 55 203
addValue 1 55 204
assign 1 57 206
addValue 1 57 206
assign 1 57 207
nameGet 0 57 207
assign 1 57 208
addValue 1 57 208
addValue 1 57 209
assign 1 60 216
new 0 60 216
addValue 1 60 217
assign 1 62 218
new 0 62 218
addValue 1 62 219
assign 1 64 220
new 0 64 220
assign 1 64 221
addValue 1 64 221
assign 1 64 222
typeEmitNameGet 0 64 222
assign 1 64 223
addValue 1 64 223
assign 1 64 224
new 0 64 224
addValue 1 64 225
assign 1 65 226
new 0 65 226
addValue 1 65 227
assign 1 66 228
new 0 66 228
assign 1 66 229
addValue 1 66 229
assign 1 66 230
emitNameGet 0 66 230
assign 1 66 231
addValue 1 66 231
assign 1 66 232
new 0 66 232
addValue 1 66 233
assign 1 67 234
new 0 67 234
addValue 1 67 235
assign 1 68 236
new 0 68 236
addValue 1 68 237
assign 1 69 238
new 0 69 238
addValue 1 69 239
write 1 70 240
close 0 71 241
assign 1 75 263
new 0 75 263
assign 1 75 264
toString 0 75 264
assign 1 75 265
add 1 75 265
incrementValue 0 76 266
assign 1 77 267
new 0 77 267
assign 1 77 268
addValue 1 77 268
assign 1 77 269
addValue 1 77 269
assign 1 77 270
new 0 77 270
assign 1 77 271
addValue 1 77 271
addValue 1 77 272
assign 1 79 273
containedGet 0 79 273
assign 1 79 274
firstGet 0 79 274
assign 1 79 275
containedGet 0 79 275
assign 1 79 276
firstGet 0 79 276
assign 1 79 277
new 0 79 277
assign 1 79 278
add 1 79 278
assign 1 79 279
new 0 79 279
assign 1 79 280
add 1 79 280
assign 1 79 281
new 0 79 281
assign 1 79 282
finalAssign 4 79 282
addValue 1 79 283
assign 1 84 288
new 0 84 288
return 1 84 289
assign 1 88 298
isFinalGet 0 88 298
assign 1 0 300
assign 1 88 303
def 1 88 308
assign 1 88 309
isFinalGet 0 88 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 0 321
assign 1 0 324
assign 1 89 328
new 0 89 328
return 1 89 329
assign 1 91 331
new 0 91 331
return 1 91 332
assign 1 95 340
def 1 95 345
assign 1 95 346
isFinalGet 0 95 346
assign 1 0 348
assign 1 0 351
assign 1 0 355
assign 1 96 358
new 0 96 358
return 1 96 359
assign 1 98 361
new 0 98 361
return 1 98 362
assign 1 102 366
new 0 102 366
return 1 102 367
getCode 2 107 372
assign 1 108 373
toHexString 1 108 373
assign 1 109 374
new 0 109 374
addValue 1 109 375
addValue 1 110 376
assign 1 116 385
new 0 116 385
assign 1 116 386
add 1 116 386
assign 1 116 387
new 0 116 387
assign 1 116 388
add 1 116 388
assign 1 116 389
add 1 116 389
return 1 116 390
assign 1 120 419
emitChecksGet 0 120 419
assign 1 120 420
new 0 120 420
assign 1 120 421
has 1 120 421
assign 1 121 423
new 0 121 423
assign 1 121 424
add 1 121 424
assign 1 121 425
new 0 121 425
assign 1 121 426
add 1 121 426
assign 1 121 427
add 1 121 427
assign 1 123 430
new 0 123 430
assign 1 123 431
add 1 123 431
assign 1 123 432
new 0 123 432
assign 1 123 433
add 1 123 433
assign 1 123 434
add 1 123 434
assign 1 125 436
new 0 125 436
assign 1 125 437
addValue 1 125 437
assign 1 125 438
addValue 1 125 438
assign 1 125 439
new 0 125 439
assign 1 125 440
addValue 1 125 440
addValue 1 125 441
assign 1 126 442
new 0 126 442
assign 1 126 443
addValue 1 126 443
addValue 1 126 444
assign 1 127 445
new 0 127 445
assign 1 127 446
addValue 1 127 446
assign 1 127 447
outputPlatformGet 0 127 447
assign 1 127 448
nameGet 0 127 448
assign 1 127 449
addValue 1 127 449
assign 1 127 450
new 0 127 450
assign 1 127 451
addValue 1 127 451
addValue 1 127 452
return 1 128 453
assign 1 132 458
libNameGet 0 132 458
assign 1 132 459
beginNs 1 132 459
return 1 132 460
assign 1 136 469
new 0 136 469
assign 1 136 470
libNs 1 136 470
assign 1 136 471
add 1 136 471
assign 1 136 472
new 0 136 472
assign 1 136 473
add 1 136 473
assign 1 136 474
add 1 136 474
return 1 136 475
assign 1 140 479
getNameSpace 1 140 479
return 1 140 480
assign 1 144 485
new 0 144 485
assign 1 144 486
add 1 144 486
return 1 144 487
assign 1 148 492
new 0 148 492
assign 1 148 493
add 1 148 493
return 1 148 494
assign 1 152 498
new 0 152 498
return 1 152 499
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1165314350: return bem_doEmit_0();
case -1547436103: return bem_transGet_0();
case 648799219: return bem_mnodeGet_0();
case -1577168510: return bem_overrideMtdDecGet_0();
case -1496487093: return bem_returnTypeGet_0();
case 1803222407: return bem_smnlcsGet_0();
case -205504458: return bem_lastMethodBodyLinesGet_0();
case 1689985735: return bem_nativeCSlotsGet_0();
case -453384626: return bem_idToNameGet_0();
case -2124730431: return bem_stringNpGet_0();
case -1241948897: return bem_runtimeInitGet_0();
case 1227779447: return bem_exceptDecGet_0();
case 276542786: return bem_mainStartGet_0();
case 1558491944: return bem_getLibOutput_0();
case -1115843556: return bem_preClassOutput_0();
case 1816122319: return bem_newDecGet_0();
case -492244851: return bem_qGet_0();
case -144340278: return bem_mainInClassGet_0();
case 815038459: return bem_intNpGet_0();
case -1319517478: return bem_new_0();
case -354682665: return bem_fileExtGet_0();
case -684450742: return bem_classCallsGet_0();
case 1956610557: return bem_instanceNotEqualGet_0();
case -578627998: return bem_instanceEqualGet_0();
case 265547048: return bem_boolNpGet_0();
case 268960376: return bem_belslitsGet_0();
case -1634578420: return bem_falseValueGet_0();
case -1148508368: return bem_inClassGet_0();
case -289462721: return bem_baseSmtdDecGet_0();
case 725216552: return bem_nameToIdGet_0();
case 1188247446: return bem_objectNpGet_0();
case -1547663214: return bem_gcMarksGet_0();
case -1144797830: return bem_ntypesGet_0();
case 1908977415: return bem_buildGet_0();
case -1403915940: return bem_useDynMethodsGet_0();
case 2067320051: return bem_emitLib_0();
case -644722126: return bem_buildClassInfo_0();
case 1751635159: return bem_libEmitPathGet_0();
case -1181638954: return bem_csynGet_0();
case -2014185781: return bem_superCallsGet_0();
case 392125523: return bem_invpGet_0();
case 557947587: return bem_smnlecsGet_0();
case -335228740: return bem_loadIds_0();
case -249739740: return bem_nullValueGet_0();
case -1240040319: return bem_ccMethodsGet_0();
case 1915413453: return bem_saveIds_0();
case 1177289273: return bem_covariantReturnsGet_0();
case 909002660: return bem_buildInitial_0();
case 42767625: return bem_propDecGet_0();
case -906287676: return bem_lastMethodBodySizeGet_0();
case 145653269: return bem_onceDecsGet_0();
case 705842558: return bem_lastMethodsSizeGet_0();
case -205191558: return bem_parentConfGet_0();
case -632349746: return bem_afterCast_0();
case -472739914: return bem_beginNs_0();
case -370531044: return bem_saveSyns_0();
case 279677554: return bem_propertyDecsGet_0();
case 898909748: return bem_lineCountGet_0();
case 1179962804: return bem_maxSpillArgsLenGet_0();
case -2030989698: return bem_getClassOutput_0();
case -171580085: return bem_dynMethodsGet_0();
case 524745294: return bem_lastMethodsLinesGet_0();
case -452064266: return bem_baseMtdDecGet_0();
case -326759502: return bem_writeBET_0();
case -369118516: return bem_print_0();
case -28302694: return bem_classEmitsGet_0();
case 386274673: return bem_libEmitNameGet_0();
case -615880915: return bem_hashGet_0();
case -1440094159: return bem_boolCcGet_0();
case -1561513407: return bem_randGet_0();
case -1471013874: return bem_instOfGet_0();
case -1324622709: return bem_create_0();
case 1418896720: return bem_classConfGet_0();
case -644049693: return bem_nameToIdPathGet_0();
case 503416911: return bem_initialDecGet_0();
case -770656049: return bem_msynGet_0();
case 2039880337: return bem_maxDynArgsGet_0();
case 1235086790: return bem_superNameGet_0();
case 498340889: return bem_inFilePathedGet_0();
case 1033705249: return bem_endNs_0();
case -37227611: return bem_floatNpGet_0();
case 1458596676: return bem_trueValueGet_0();
case 1532111877: return bem_mainEndGet_0();
case 567988956: return bem_objectCcGet_0();
case 702972030: return bem_mainOutsideNsGet_0();
case -939988190: return bem_fullLibEmitNameGet_0();
case 302435734: return bem_ccCacheGet_0();
case 1186177693: return bem_synEmitPathGet_0();
case 1368784350: return bem_spropDecGet_0();
case -628598758: return bem_classEndGet_0();
case -1314108802: return bem_methodCallsGet_0();
case -421926232: return bem_cnodeGet_0();
case -734828229: return bem_callNamesGet_0();
case -219382951: return bem_iteratorGet_0();
case 675634345: return bem_typeDecGet_0();
case 137053214: return bem_methodCatchGet_0();
case -1794695373: return bem_constGet_0();
case 1467057435: return bem_nlGet_0();
case 1787222330: return bem_toString_0();
case 1402546981: return bem_emitLangGet_0();
case -1512391106: return bem_scvpGet_0();
case 1743907751: return bem_boolTypeGet_0();
case -366967081: return bem_methodsGet_0();
case 1388256074: return bem_classesInDepthOrderGet_0();
case 1672497129: return bem_idToNamePathGet_0();
case 1370120373: return bem_buildCreate_0();
case 815212484: return bem_lastCallGet_0();
case 716353022: return bem_copy_0();
case 820054441: return bem_preClassGet_0();
case -1403252534: return bem_methodBodyGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1105770711: return bem_objectNpSet_1(bevd_0);
case 1985843632: return bem_fileExtSet_1(bevd_0);
case -218593173: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1254710410: return bem_notEquals_1(bevd_0);
case -1496344692: return bem_gcMarksSet_1(bevd_0);
case 1073835775: return bem_copyTo_1(bevd_0);
case 885527060: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -267170990: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1273480052: return bem_instOfSet_1(bevd_0);
case 1352234541: return bem_transSet_1(bevd_0);
case -180701922: return bem_mnodeSet_1(bevd_0);
case -1540060505: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1326541406: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -989177223: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1678423167: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -923800247: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1274677278: return bem_inClassSet_1(bevd_0);
case 1499174649: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 389810861: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1753380688: return bem_returnTypeSet_1(bevd_0);
case -532138458: return bem_floatNpSet_1(bevd_0);
case 200549651: return bem_instanceNotEqualSet_1(bevd_0);
case -1329354966: return bem_nullValueSet_1(bevd_0);
case -2115664993: return bem_lastMethodsSizeSet_1(bevd_0);
case 1557530282: return bem_smnlecsSet_1(bevd_0);
case -268214996: return bem_cnodeSet_1(bevd_0);
case 1982061664: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1371723524: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -952936549: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -522969076: return bem_nlSet_1(bevd_0);
case 886155273: return bem_intNpSet_1(bevd_0);
case -1235199083: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1190242206: return bem_fullLibEmitNameSet_1(bevd_0);
case -1604082419: return bem_buildSet_1(bevd_0);
case -1717301548: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -491755103: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -67760358: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1253115717: return bem_smnlcsSet_1(bevd_0);
case -506789697: return bem_onceDecsSet_1(bevd_0);
case 1236766583: return bem_randSet_1(bevd_0);
case 556143763: return bem_begin_1(bevd_0);
case -1056267082: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -273214201: return bem_lastMethodsLinesSet_1(bevd_0);
case 1784051913: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -511421760: return bem_methodCatchSet_1(bevd_0);
case 1028311759: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -264754227: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1069843559: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1253561034: return bem_superCallsSet_1(bevd_0);
case 2102881454: return bem_classEmitsSet_1(bevd_0);
case 1603919423: return bem_equals_1(bevd_0);
case -1788961273: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1005078215: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -130739924: return bem_idToNameSet_1(bevd_0);
case 214540725: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -101364013: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1808347415: return bem_objectCcSet_1(bevd_0);
case -136945921: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1503603234: return bem_libEmitPathSet_1(bevd_0);
case -915198802: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1419073425: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1904023555: return bem_parentConfSet_1(bevd_0);
case -1480465903: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1536190663: return bem_synEmitPathSet_1(bevd_0);
case 1657786616: return bem_def_1(bevd_0);
case -583138671: return bem_qSet_1(bevd_0);
case -2086552078: return bem_decNameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1722300851: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -8984293: return bem_maxSpillArgsLenSet_1(bevd_0);
case 2078464007: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 160130746: return bem_nameToIdPathSet_1(bevd_0);
case 700404398: return bem_propertyDecsSet_1(bevd_0);
case -2116604965: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -809356835: return bem_classCallsSet_1(bevd_0);
case 718395969: return bem_classesInDepthOrderSet_1(bevd_0);
case 613684141: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -374145702: return bem_csynSet_1(bevd_0);
case 1465837618: return bem_invpSet_1(bevd_0);
case -896038000: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -632378742: return bem_ccMethodsSet_1(bevd_0);
case 789148869: return bem_dynMethodsSet_1(bevd_0);
case -245693162: return bem_end_1(bevd_0);
case -508758794: return bem_undef_1(bevd_0);
case 1703934394: return bem_msynSet_1(bevd_0);
case 776462988: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1733375600: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 412051952: return bem_ntypesSet_1(bevd_0);
case 480015740: return bem_instanceEqualSet_1(bevd_0);
case -791248116: return bem_belslitsSet_1(bevd_0);
case -686485735: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1048269288: return bem_boolNpSet_1(bevd_0);
case -1073184446: return bem_stringNpSet_1(bevd_0);
case 418897432: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1970058358: return bem_idToNamePathSet_1(bevd_0);
case -1038765528: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1668372306: return bem_callNamesSet_1(bevd_0);
case -2005700624: return bem_emitLangSet_1(bevd_0);
case -197200526: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1700455740: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1659124570: return bem_falseValueSet_1(bevd_0);
case -1706921036: return bem_methodBodySet_1(bevd_0);
case -405141683: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -778665153: return bem_classConfSet_1(bevd_0);
case 1079258470: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1992760369: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -338331058: return bem_ccCacheSet_1(bevd_0);
case -538722247: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -637764763: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1059859409: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1863330784: return bem_nameToIdSet_1(bevd_0);
case -1434816537: return bem_inFilePathedSet_1(bevd_0);
case -540906237: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -390528042: return bem_boolCcSet_1(bevd_0);
case 44087342: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 194679214: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1694592496: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -141935974: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1718429601: return bem_maxDynArgsSet_1(bevd_0);
case -55579454: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -337540213: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1328495046: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -183873945: return bem_methodCallsSet_1(bevd_0);
case -1232049143: return bem_lastMethodBodySizeSet_1(bevd_0);
case -364676823: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -359395648: return bem_constSet_1(bevd_0);
case -1925258405: return bem_nativeCSlotsSet_1(bevd_0);
case -723633845: return bem_scvpSet_1(bevd_0);
case -694977180: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1019265649: return bem_lineCountSet_1(bevd_0);
case 390192212: return bem_trueValueSet_1(bevd_0);
case 1453961403: return bem_exceptDecSet_1(bevd_0);
case 894094580: return bem_preClassSet_1(bevd_0);
case 1362768957: return bem_libEmitNameSet_1(bevd_0);
case 1943685501: return bem_lastCallSet_1(bevd_0);
case 408434990: return bem_methodsSet_1(bevd_0);
case 1313571493: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1956825510: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 437716910: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1907425768: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -572725695: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1167513561: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1114186520: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1721480364: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 900181049: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1049563888: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1038602389: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1398840074: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1361437844: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 238044200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 395313509: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1200107316: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1885291949: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1917901164: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1911379895: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1258985593: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1733142134: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1905541736: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1972306229: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1501364018: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1194973233: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -420670947: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
