package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_6, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_7, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_15, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_16, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_17, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_18, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_19, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_20, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_27, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_29, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_30, 3));
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-668962143);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1065393688);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
return bevt_4_tmpany_phold;
} /* Line: 41 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 47 */
 else  /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 47 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
return bevt_3_tmpany_phold;
} /* Line: 48 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1427319780);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 36, 36, 40, 0, 40, 40, 40, 0, 0, 0, 0, 0, 41, 41, 43, 43, 47, 47, 47, 0, 0, 0, 48, 48, 50, 50, 54, 54, 58, 58, 58, 58, 58, 63, 64, 65, 65, 65, 66, 72, 72, 72, 72, 72, 72, 76, 76, 76, 76, 76, 77, 77, 77, 77, 77, 77, 78, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 80, 84, 84, 84, 88, 88, 88, 88, 88, 88, 88, 92, 92, 96, 96, 96, 100, 100, 100, 100, 104, 104};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {54, 55, 56, 57, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 104, 105, 114, 116, 119, 124, 125, 127, 130, 134, 137, 140, 144, 145, 147, 148, 156, 161, 162, 164, 167, 171, 174, 175, 177, 178, 182, 183, 190, 191, 192, 193, 194, 200, 201, 202, 203, 204, 205, 214, 215, 216, 217, 218, 219, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 268, 269, 270, 279, 280, 281, 282, 283, 284, 285, 289, 290, 295, 296, 297, 303, 304, 305, 306, 310, 311};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 54
new 0 17 54
assign 1 18 55
new 0 18 55
assign 1 19 56
new 0 19 56
new 1 23 57
assign 1 27 79
new 0 27 79
assign 1 27 80
toString 0 27 80
assign 1 27 81
add 1 27 81
incrementValue 0 28 82
assign 1 29 83
new 0 29 83
assign 1 29 84
addValue 1 29 84
assign 1 29 85
addValue 1 29 85
assign 1 29 86
new 0 29 86
assign 1 29 87
addValue 1 29 87
addValue 1 29 88
assign 1 31 89
containedGet 0 31 89
assign 1 31 90
firstGet 0 31 90
assign 1 31 91
containedGet 0 31 91
assign 1 31 92
firstGet 0 31 92
assign 1 31 93
new 0 31 93
assign 1 31 94
add 1 31 94
assign 1 31 95
new 0 31 95
assign 1 31 96
add 1 31 96
assign 1 31 97
new 0 31 97
assign 1 31 98
finalAssign 4 31 98
addValue 1 31 99
assign 1 36 104
new 0 36 104
return 1 36 105
assign 1 40 114
isFinalGet 0 40 114
assign 1 0 116
assign 1 40 119
def 1 40 124
assign 1 40 125
isFinalGet 0 40 125
assign 1 0 127
assign 1 0 130
assign 1 0 134
assign 1 0 137
assign 1 0 140
assign 1 41 144
new 0 41 144
return 1 41 145
assign 1 43 147
new 0 43 147
return 1 43 148
assign 1 47 156
def 1 47 161
assign 1 47 162
isFinalGet 0 47 162
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 48 174
new 0 48 174
return 1 48 175
assign 1 50 177
new 0 50 177
return 1 50 178
assign 1 54 182
new 0 54 182
return 1 54 183
assign 1 58 190
new 0 58 190
assign 1 58 191
add 1 58 191
assign 1 58 192
new 0 58 192
assign 1 58 193
add 1 58 193
return 1 58 194
getCode 2 63 200
assign 1 64 201
toHexString 1 64 201
assign 1 65 202
new 0 65 202
assign 1 65 203
once 0 65 203
addValue 1 65 204
addValue 1 66 205
assign 1 72 214
new 0 72 214
assign 1 72 215
add 1 72 215
assign 1 72 216
new 0 72 216
assign 1 72 217
add 1 72 217
assign 1 72 218
add 1 72 218
return 1 72 219
assign 1 76 241
new 0 76 241
assign 1 76 242
add 1 76 242
assign 1 76 243
new 0 76 243
assign 1 76 244
add 1 76 244
assign 1 76 245
add 1 76 245
assign 1 77 246
new 0 77 246
assign 1 77 247
addValue 1 77 247
assign 1 77 248
addValue 1 77 248
assign 1 77 249
new 0 77 249
assign 1 77 250
addValue 1 77 250
addValue 1 77 251
assign 1 78 252
new 0 78 252
assign 1 78 253
addValue 1 78 253
addValue 1 78 254
assign 1 79 255
new 0 79 255
assign 1 79 256
addValue 1 79 256
assign 1 79 257
outputPlatformGet 0 79 257
assign 1 79 258
nameGet 0 79 258
assign 1 79 259
addValue 1 79 259
assign 1 79 260
new 0 79 260
assign 1 79 261
addValue 1 79 261
addValue 1 79 262
return 1 80 263
assign 1 84 268
libNameGet 0 84 268
assign 1 84 269
beginNs 1 84 269
return 1 84 270
assign 1 88 279
new 0 88 279
assign 1 88 280
libNs 1 88 280
assign 1 88 281
add 1 88 281
assign 1 88 282
new 0 88 282
assign 1 88 283
add 1 88 283
assign 1 88 284
add 1 88 284
return 1 88 285
assign 1 92 289
getNameSpace 1 92 289
return 1 92 290
assign 1 96 295
new 0 96 295
assign 1 96 296
add 1 96 296
return 1 96 297
assign 1 100 303
new 0 100 303
assign 1 100 304
once 0 100 304
assign 1 100 305
add 1 100 305
return 1 100 306
assign 1 104 310
new 0 104 310
return 1 104 311
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1034708225: return bem_stringNpGet_0();
case -55606947: return bem_lastMethodBodyLinesGet_0();
case -576685743: return bem_superCallsGet_0();
case -1479976450: return bem_doEmit_0();
case 1782640106: return bem_classEndGet_0();
case 770542492: return bem_csynGet_0();
case 1553810053: return bem_fullLibEmitNameGet_0();
case -708061897: return bem_nlGet_0();
case 1647560184: return bem_propertyDecsGet_0();
case -1666844393: return bem_maxSpillArgsLenGet_0();
case -1758674258: return bem_randGet_0();
case -1466976675: return bem_lastMethodsSizeGet_0();
case -1564283416: return bem_boolTypeGet_0();
case 1540590715: return bem_trueValueGet_0();
case 1677489699: return bem_methodBodyGet_0();
case -893953561: return bem_falseValueGet_0();
case 677989809: return bem_qGet_0();
case -1866917929: return bem_serializeToString_0();
case 2049440178: return bem_buildInitial_0();
case -1720162742: return bem_preClassGet_0();
case -1429418396: return bem_mainInClassGet_0();
case 1452879382: return bem_sourceFileNameGet_0();
case 1222310146: return bem_many_0();
case 550360827: return bem_nameToIdGet_0();
case 737353003: return bem_new_0();
case 1634376306: return bem_nativeCSlotsGet_0();
case 1467534092: return bem_lineCountGet_0();
case 128613462: return bem_afterCast_0();
case -2053360729: return bem_endNs_0();
case 275182989: return bem_mainOutsideNsGet_0();
case -742309585: return bem_parentConfGet_0();
case 1520239938: return bem_ntypesGet_0();
case -14888464: return bem_instanceNotEqualGet_0();
case -1661711686: return bem_inFilePathedGet_0();
case -929341704: return bem_floatNpGet_0();
case -162974557: return bem_lastCallGet_0();
case 2102133928: return bem_coanyiantReturnsGet_0();
case 366164054: return bem_serializeContents_0();
case -1907902717: return bem_dynMethodsGet_0();
case -543852598: return bem_spropDecGet_0();
case -1134690991: return bem_libEmitPathGet_0();
case -70500062: return bem_fieldIteratorGet_0();
case 1476572350: return bem_callNamesGet_0();
case 907029032: return bem_methodsGet_0();
case -982494241: return bem_smnlecsGet_0();
case 620748482: return bem_baseSmtdDecGet_0();
case -1980796873: return bem_copy_0();
case -76420615: return bem_scvpGet_0();
case 641471023: return bem_boolCcGet_0();
case 1099527338: return bem_fileExtGet_0();
case -1726670013: return bem_objectCcGet_0();
case 111274393: return bem_getLibOutput_0();
case 1396092452: return bem_onceDecsGet_0();
case 1863891380: return bem_onceCountGet_0();
case -1529622107: return bem_mnodeGet_0();
case -1516284520: return bem_intNpGet_0();
case 1899310009: return bem_ccCacheGet_0();
case -800483339: return bem_saveSyns_0();
case 2033657832: return bem_hashGet_0();
case 473955146: return bem_smnlcsGet_0();
case 717380082: return bem_invpGet_0();
case 293623377: return bem_instanceEqualGet_0();
case 529084722: return bem_superNameGet_0();
case 1015480182: return bem_propDecGet_0();
case -302965453: return bem_tagGet_0();
case 559299734: return bem_transGet_0();
case 1775715094: return bem_once_0();
case 404252471: return bem_objectNpGet_0();
case 997723391: return bem_iteratorGet_0();
case -342416547: return bem_returnTypeGet_0();
case 1728154703: return bem_runtimeInitGet_0();
case 2011845734: return bem_libEmitNameGet_0();
case 301206433: return bem_echo_0();
case 1275925293: return bem_msynGet_0();
case 1732876397: return bem_serializationIteratorGet_0();
case 1539345133: return bem_buildGet_0();
case 885657712: return bem_lastMethodBodySizeGet_0();
case -1281353113: return bem_mainEndGet_0();
case -191516928: return bem_instOfGet_0();
case 437107729: return bem_buildCreate_0();
case 1147399822: return bem_methodCallsGet_0();
case 600316619: return bem_mainStartGet_0();
case -420235024: return bem_classNameGet_0();
case -1240423942: return bem_boolNpGet_0();
case -842033112: return bem_maxDynArgsGet_0();
case -1980068306: return bem_emitLangGet_0();
case -545805767: return bem_exceptDecGet_0();
case 957985508: return bem_methodCatchGet_0();
case -1757858659: return bem_synEmitPathGet_0();
case -1854824621: return bem_beginNs_0();
case 737771364: return bem_toString_0();
case -1447816317: return bem_constGet_0();
case 366143279: return bem_buildClassInfo_0();
case 942225712: return bem_useDynMethodsGet_0();
case 1314576819: return bem_print_0();
case 87771052: return bem_getClassOutput_0();
case 1886540867: return bem_classCallsGet_0();
case 482356666: return bem_toAny_0();
case 978101813: return bem_lastMethodsLinesGet_0();
case 1023783415: return bem_create_0();
case -747529470: return bem_classConfGet_0();
case -1576437151: return bem_classesInDepthOrderGet_0();
case -1763965034: return bem_emitLib_0();
case -64311724: return bem_baseMtdDecGet_0();
case -1655409886: return bem_classEmitsGet_0();
case 459872068: return bem_idToNameGet_0();
case 628909354: return bem_cnodeGet_0();
case -2021923401: return bem_initialDecGet_0();
case -803388239: return bem_deserializeClassNameGet_0();
case -792027705: return bem_nullValueGet_0();
case -953457532: return bem_overrideMtdDecGet_0();
case -597919309: return bem_ccMethodsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1918573846: return bem_cnodeSet_1(bevd_0);
case -1458727376: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -135223658: return bem_begin_1(bevd_0);
case 1374627237: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -369272378: return bem_undefined_1(bevd_0);
case -1291917144: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -259359520: return bem_ntypesSet_1(bevd_0);
case -1849636873: return bem_intNpSet_1(bevd_0);
case 948517342: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 995877829: return bem_buildSet_1(bevd_0);
case -875516646: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -10325606: return bem_undef_1(bevd_0);
case 1901690465: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1452810576: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -770697820: return bem_dynMethodsSet_1(bevd_0);
case 147893474: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1210677960: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 736209909: return bem_parentConfSet_1(bevd_0);
case -815589786: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1180364095: return bem_propertyDecsSet_1(bevd_0);
case -1632237004: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1327973909: return bem_invpSet_1(bevd_0);
case -1320294822: return bem_nullValueSet_1(bevd_0);
case 2023587825: return bem_objectCcSet_1(bevd_0);
case 644376313: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -251329313: return bem_falseValueSet_1(bevd_0);
case 1189172204: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -49306994: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1661359773: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1323250555: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1411102844: return bem_constSet_1(bevd_0);
case 1302568380: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1940225088: return bem_sameClass_1(bevd_0);
case -2139039966: return bem_idToNameSet_1(bevd_0);
case 1107846755: return bem_otherClass_1(bevd_0);
case 446618201: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -354435701: return bem_methodCatchSet_1(bevd_0);
case 1737684516: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1735205112: return bem_sameType_1(bevd_0);
case 178096341: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1865983556: return bem_lineCountSet_1(bevd_0);
case -1154824990: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1796006946: return bem_trueValueSet_1(bevd_0);
case -736786566: return bem_methodBodySet_1(bevd_0);
case -1561255829: return bem_exceptDecSet_1(bevd_0);
case 641362438: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1078688343: return bem_copyTo_1(bevd_0);
case 1417970066: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2076759618: return bem_nlSet_1(bevd_0);
case 659480543: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 808158717: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1507740774: return bem_lastMethodsLinesSet_1(bevd_0);
case 1613878198: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 711776540: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 162993099: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1358043188: return bem_inFilePathedSet_1(bevd_0);
case -671420723: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -851570513: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -526585602: return bem_transSet_1(bevd_0);
case -136268200: return bem_smnlcsSet_1(bevd_0);
case 1732014863: return bem_equals_1(bevd_0);
case 1739418913: return bem_superCallsSet_1(bevd_0);
case 1764706380: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 966582082: return bem_instanceEqualSet_1(bevd_0);
case -1940456791: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -2051863052: return bem_preClassSet_1(bevd_0);
case -598741753: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1694445398: return bem_nativeCSlotsSet_1(bevd_0);
case 254712574: return bem_def_1(bevd_0);
case -1405050205: return bem_mnodeSet_1(bevd_0);
case -1599809920: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 722075762: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1892915307: return bem_boolNpSet_1(bevd_0);
case -948143920: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -549619067: return bem_csynSet_1(bevd_0);
case -1732568943: return bem_sameObject_1(bevd_0);
case -1087719550: return bem_msynSet_1(bevd_0);
case 1935564864: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 382856250: return bem_nameToIdSet_1(bevd_0);
case 1060168710: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1112750632: return bem_otherType_1(bevd_0);
case 1297950141: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1295644794: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 728371857: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1676755531: return bem_randSet_1(bevd_0);
case 1783045262: return bem_classesInDepthOrderSet_1(bevd_0);
case -510237704: return bem_emitLangSet_1(bevd_0);
case -1196233928: return bem_instOfSet_1(bevd_0);
case -287067785: return bem_fullLibEmitNameSet_1(bevd_0);
case -1004592326: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 307503673: return bem_callNamesSet_1(bevd_0);
case -1162214555: return bem_methodCallsSet_1(bevd_0);
case 452525298: return bem_maxDynArgsSet_1(bevd_0);
case 619029421: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1781299450: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 98758787: return bem_ccCacheSet_1(bevd_0);
case -680525107: return bem_stringNpSet_1(bevd_0);
case 575200426: return bem_libEmitPathSet_1(bevd_0);
case -840719981: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1487275674: return bem_fileExtSet_1(bevd_0);
case 1224843927: return bem_objectNpSet_1(bevd_0);
case 1994472538: return bem_floatNpSet_1(bevd_0);
case 1061070211: return bem_smnlecsSet_1(bevd_0);
case -2136013974: return bem_classConfSet_1(bevd_0);
case -1588213448: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 611202770: return bem_libEmitNameSet_1(bevd_0);
case 2075365257: return bem_classEmitsSet_1(bevd_0);
case 1513515004: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1474892672: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -936735481: return bem_scvpSet_1(bevd_0);
case 1235111255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 759791606: return bem_onceCountSet_1(bevd_0);
case -893590241: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 948788338: return bem_instanceNotEqualSet_1(bevd_0);
case -957304266: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -942371887: return bem_ccMethodsSet_1(bevd_0);
case -906831913: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 692481700: return bem_boolCcSet_1(bevd_0);
case 1138797496: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -2011689398: return bem_lastCallSet_1(bevd_0);
case 228693515: return bem_notEquals_1(bevd_0);
case -1502127364: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -493920143: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1472419576: return bem_synEmitPathSet_1(bevd_0);
case 624488803: return bem_classCallsSet_1(bevd_0);
case 63748884: return bem_qSet_1(bevd_0);
case -149586408: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -530186651: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -678108808: return bem_onceDecsSet_1(bevd_0);
case 37722507: return bem_lastMethodsSizeSet_1(bevd_0);
case 1642340180: return bem_methodsSet_1(bevd_0);
case -2091737557: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1499779332: return bem_returnTypeSet_1(bevd_0);
case -85908175: return bem_end_1(bevd_0);
case 679024947: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 235706821: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1658992372: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -146482130: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -90730260: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1437812444: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -753177827: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 120705177: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -164742720: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1654692407: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1990568085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 672373703: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1395427392: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1610791920: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1605593581: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1815656517: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1342105813: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1629656373: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1747848637: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -303274357: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -70659423: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 2055581228: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 3239311: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 803281951: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1245559662: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -439133565: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -508212062: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 95519686: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
}
