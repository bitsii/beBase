package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x20,0x3A,0x20};
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(-1411988100);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-1469355336);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(242021854);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-1469355336);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(242021854);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_41_ta_ph = bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_43_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_ta_ph = bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevt_40_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_45_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_47_ta_ph = bevl_bet.bem_addValue_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_46_ta_ph = bevt_47_ta_ph.bem_addValue_1(bevt_49_ta_ph);
bevt_50_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevt_46_ta_ph.bem_addValue_1(bevt_50_ta_ph);
bevt_51_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevl_tout.bemd_1(549783704, bevl_bet);
bevl_tout.bemd_0(2038148888);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-165515159);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-862134819);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, bevt_16_ta_ph);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_1_ta_ph = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
if (beva_msyn == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_3_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
return bevt_4_ta_ph;
} /* Line: 87*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 93*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 93*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 94*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 118*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(48, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_exceptDec);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevl_ms = bevt_3_ta_ph.bem_add_1(bevp_nl);
} /* Line: 119*/
 else /* Line: 120*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildCSEmitter_bels_36));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_exceptDec);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_10_ta_ph);
bevl_ms = bevt_7_ta_ph.bem_add_1(bevp_nl);
} /* Line: 121*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_37));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_38));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_39));
bevt_16_ta_ph = bevl_ms.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_20_ta_ph = bevl_ms.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(1686249444);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_18_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 62, 62, 62, 62, 63, 63, 64, 64, 64, 64, 64, 64, 65, 65, 66, 66, 67, 67, 68, 69, 73, 73, 73, 74, 75, 75, 75, 75, 75, 75, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 82, 82, 86, 0, 86, 86, 86, 0, 0, 0, 0, 0, 87, 87, 89, 89, 93, 93, 93, 0, 0, 0, 94, 94, 96, 96, 100, 100, 105, 106, 107, 107, 108, 114, 114, 114, 114, 114, 114, 118, 118, 118, 119, 119, 119, 119, 119, 121, 121, 121, 121, 121, 123, 123, 123, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 126, 130, 130, 130, 134, 134, 134, 134, 134, 134, 134, 138, 138, 142, 142, 142, 146, 146, 146, 150, 150};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {57, 58, 59, 60, 124, 125, 126, 127, 132, 133, 134, 135, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 160, 163, 165, 167, 170, 171, 173, 174, 175, 176, 182, 183, 184, 185, 186, 187, 188, 189, 190, 190, 193, 195, 197, 200, 201, 203, 204, 205, 206, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 284, 285, 294, 296, 299, 304, 305, 307, 310, 314, 317, 320, 324, 325, 327, 328, 336, 341, 342, 344, 347, 351, 354, 355, 357, 358, 362, 363, 368, 369, 370, 371, 372, 381, 382, 383, 384, 385, 386, 415, 416, 417, 419, 420, 421, 422, 423, 426, 427, 428, 429, 430, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 454, 455, 456, 465, 466, 467, 468, 469, 470, 471, 475, 476, 481, 482, 483, 488, 489, 490, 494, 495};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 57
new 0 16 57
assign 1 17 58
new 0 17 58
assign 1 18 59
new 0 18 59
new 1 22 60
assign 1 26 124
classDirGet 0 26 124
assign 1 26 125
fileGet 0 26 125
assign 1 26 126
existsGet 0 26 126
assign 1 26 127
not 0 26 132
assign 1 27 133
classDirGet 0 27 133
assign 1 27 134
fileGet 0 27 134
makeDirs 0 27 135
assign 1 29 137
typePathGet 0 29 137
assign 1 29 138
fileGet 0 29 138
assign 1 29 139
writerGet 0 29 139
assign 1 29 140
open 0 29 140
assign 1 30 141
new 0 30 141
assign 1 31 142
new 0 31 142
addValue 1 31 143
assign 1 32 144
new 0 32 144
assign 1 32 145
addValue 1 32 145
assign 1 32 146
typeEmitNameGet 0 32 146
assign 1 32 147
addValue 1 32 147
assign 1 32 148
new 0 32 148
addValue 1 32 149
assign 1 33 150
new 0 33 150
assign 1 33 151
addValue 1 33 151
assign 1 33 152
typeEmitNameGet 0 33 152
assign 1 33 153
addValue 1 33 153
assign 1 33 154
new 0 33 154
addValue 1 33 155
assign 1 35 156
new 0 35 156
addValue 1 35 157
assign 1 36 158
new 0 36 158
assign 1 37 159
mtdListGet 0 37 159
assign 1 37 160
iteratorGet 0 0 160
assign 1 37 163
hasNextGet 0 37 163
assign 1 37 165
nextGet 0 37 165
assign 1 39 167
new 0 39 167
assign 1 41 170
new 0 41 170
addValue 1 41 171
assign 1 43 173
addValue 1 43 173
assign 1 43 174
nameGet 0 43 174
assign 1 43 175
addValue 1 43 175
addValue 1 43 176
assign 1 45 182
new 0 45 182
addValue 1 45 183
assign 1 46 184
new 0 46 184
addValue 1 46 185
assign 1 48 186
new 0 48 186
addValue 1 48 187
assign 1 49 188
new 0 49 188
assign 1 50 189
ptyListGet 0 50 189
assign 1 50 190
iteratorGet 0 0 190
assign 1 50 193
hasNextGet 0 50 193
assign 1 50 195
nextGet 0 50 195
assign 1 52 197
new 0 52 197
assign 1 54 200
new 0 54 200
addValue 1 54 201
assign 1 56 203
addValue 1 56 203
assign 1 56 204
nameGet 0 56 204
assign 1 56 205
addValue 1 56 205
addValue 1 56 206
assign 1 58 212
new 0 58 212
addValue 1 58 213
assign 1 60 214
new 0 60 214
addValue 1 60 215
assign 1 62 216
new 0 62 216
assign 1 62 217
addValue 1 62 217
assign 1 62 218
typeEmitNameGet 0 62 218
assign 1 62 219
addValue 1 62 219
assign 1 62 220
new 0 62 220
addValue 1 62 221
assign 1 63 222
new 0 63 222
addValue 1 63 223
assign 1 64 224
new 0 64 224
assign 1 64 225
addValue 1 64 225
assign 1 64 226
emitNameGet 0 64 226
assign 1 64 227
addValue 1 64 227
assign 1 64 228
new 0 64 228
addValue 1 64 229
assign 1 65 230
new 0 65 230
addValue 1 65 231
assign 1 66 232
new 0 66 232
addValue 1 66 233
assign 1 67 234
new 0 67 234
addValue 1 67 235
write 1 68 236
close 0 69 237
assign 1 73 259
new 0 73 259
assign 1 73 260
toString 0 73 260
assign 1 73 261
add 1 73 261
incrementValue 0 74 262
assign 1 75 263
new 0 75 263
assign 1 75 264
addValue 1 75 264
assign 1 75 265
addValue 1 75 265
assign 1 75 266
new 0 75 266
assign 1 75 267
addValue 1 75 267
addValue 1 75 268
assign 1 77 269
containedGet 0 77 269
assign 1 77 270
firstGet 0 77 270
assign 1 77 271
containedGet 0 77 271
assign 1 77 272
firstGet 0 77 272
assign 1 77 273
new 0 77 273
assign 1 77 274
add 1 77 274
assign 1 77 275
new 0 77 275
assign 1 77 276
add 1 77 276
assign 1 77 277
new 0 77 277
assign 1 77 278
finalAssign 4 77 278
addValue 1 77 279
assign 1 82 284
new 0 82 284
return 1 82 285
assign 1 86 294
isFinalGet 0 86 294
assign 1 0 296
assign 1 86 299
def 1 86 304
assign 1 86 305
isFinalGet 0 86 305
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 0 317
assign 1 0 320
assign 1 87 324
new 0 87 324
return 1 87 325
assign 1 89 327
new 0 89 327
return 1 89 328
assign 1 93 336
def 1 93 341
assign 1 93 342
isFinalGet 0 93 342
assign 1 0 344
assign 1 0 347
assign 1 0 351
assign 1 94 354
new 0 94 354
return 1 94 355
assign 1 96 357
new 0 96 357
return 1 96 358
assign 1 100 362
new 0 100 362
return 1 100 363
getCode 2 105 368
assign 1 106 369
toHexString 1 106 369
assign 1 107 370
new 0 107 370
addValue 1 107 371
addValue 1 108 372
assign 1 114 381
new 0 114 381
assign 1 114 382
add 1 114 382
assign 1 114 383
new 0 114 383
assign 1 114 384
add 1 114 384
assign 1 114 385
add 1 114 385
return 1 114 386
assign 1 118 415
emitChecksGet 0 118 415
assign 1 118 416
new 0 118 416
assign 1 118 417
has 1 118 417
assign 1 119 419
new 0 119 419
assign 1 119 420
add 1 119 420
assign 1 119 421
new 0 119 421
assign 1 119 422
add 1 119 422
assign 1 119 423
add 1 119 423
assign 1 121 426
new 0 121 426
assign 1 121 427
add 1 121 427
assign 1 121 428
new 0 121 428
assign 1 121 429
add 1 121 429
assign 1 121 430
add 1 121 430
assign 1 123 432
new 0 123 432
assign 1 123 433
addValue 1 123 433
assign 1 123 434
addValue 1 123 434
assign 1 123 435
new 0 123 435
assign 1 123 436
addValue 1 123 436
addValue 1 123 437
assign 1 124 438
new 0 124 438
assign 1 124 439
addValue 1 124 439
addValue 1 124 440
assign 1 125 441
new 0 125 441
assign 1 125 442
addValue 1 125 442
assign 1 125 443
outputPlatformGet 0 125 443
assign 1 125 444
nameGet 0 125 444
assign 1 125 445
addValue 1 125 445
assign 1 125 446
new 0 125 446
assign 1 125 447
addValue 1 125 447
addValue 1 125 448
return 1 126 449
assign 1 130 454
libNameGet 0 130 454
assign 1 130 455
beginNs 1 130 455
return 1 130 456
assign 1 134 465
new 0 134 465
assign 1 134 466
libNs 1 134 466
assign 1 134 467
add 1 134 467
assign 1 134 468
new 0 134 468
assign 1 134 469
add 1 134 469
assign 1 134 470
add 1 134 470
return 1 134 471
assign 1 138 475
getNameSpace 1 138 475
return 1 138 476
assign 1 142 481
new 0 142 481
assign 1 142 482
add 1 142 482
return 1 142 483
assign 1 146 488
new 0 146 488
assign 1 146 489
add 1 146 489
return 1 146 490
assign 1 150 494
new 0 150 494
return 1 150 495
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1687959246: return bem_mnodeGetDirect_0();
case -323823591: return bem_lastMethodBodySizeGetDirect_0();
case -1612750632: return bem_buildGet_0();
case 957595232: return bem_preClassOutput_0();
case -216384068: return bem_instOfGet_0();
case 1362728182: return bem_mnodeGet_0();
case -1475958127: return bem_buildCreate_0();
case 1099030811: return bem_invpGetDirect_0();
case -873824966: return bem_objectCcGet_0();
case -482956309: return bem_nameToIdPathGetDirect_0();
case 755262409: return bem_floatNpGet_0();
case 2013883413: return bem_boolNpGet_0();
case 785587296: return bem_methodBodyGet_0();
case 1577124637: return bem_deserializeClassNameGet_0();
case -24095800: return bem_scvpGet_0();
case 1418079830: return bem_libEmitPathGetDirect_0();
case -1283312469: return bem_mainEndGet_0();
case 968740301: return bem_methodsGetDirect_0();
case -1530839532: return bem_msynGetDirect_0();
case -1433485255: return bem_idToNamePathGetDirect_0();
case 386417211: return bem_buildClassInfo_0();
case -1274804122: return bem_intNpGet_0();
case 1205994045: return bem_trueValueGet_0();
case -1263154564: return bem_new_0();
case -1995358920: return bem_dynMethodsGet_0();
case -1699342844: return bem_maxDynArgsGetDirect_0();
case -733994839: return bem_trueValueGetDirect_0();
case -204267652: return bem_lineCountGet_0();
case -800146552: return bem_serializeContents_0();
case 171290638: return bem_boolCcGetDirect_0();
case 1203251176: return bem_classesInDepthOrderGetDirect_0();
case 705805069: return bem_beginNs_0();
case -496546957: return bem_emitLib_0();
case -609801973: return bem_belslitsGetDirect_0();
case -391747050: return bem_mainOutsideNsGet_0();
case -1529610986: return bem_baseMtdDecGet_0();
case 471821236: return bem_getLibOutput_0();
case 930722538: return bem_afterCast_0();
case -395966789: return bem_inClassGetDirect_0();
case -706538709: return bem_emitLangGetDirect_0();
case 1810704521: return bem_superCallsGetDirect_0();
case 221381790: return bem_transGet_0();
case 1891386906: return bem_randGet_0();
case -614347848: return bem_ccCacheGet_0();
case -385787554: return bem_onceDecsGetDirect_0();
case 221109168: return bem_classConfGetDirect_0();
case 1031500412: return bem_newDecGet_0();
case -497885830: return bem_nativeCSlotsGet_0();
case 1265916944: return bem_methodBodyGetDirect_0();
case 417551459: return bem_dynMethodsGetDirect_0();
case -2078596730: return bem_nullValueGet_0();
case -713777620: return bem_objectCcGetDirect_0();
case 946190852: return bem_lastCallGet_0();
case 1761996230: return bem_maxSpillArgsLenGetDirect_0();
case 196113905: return bem_lastMethodBodySizeGet_0();
case 638572179: return bem_smnlcsGet_0();
case 350776056: return bem_idToNamePathGet_0();
case 1221033283: return bem_propertyDecsGetDirect_0();
case 1179961651: return bem_serializeToString_0();
case -1001743190: return bem_fieldNamesGet_0();
case 1546951043: return bem_nativeCSlotsGetDirect_0();
case -1368973965: return bem_nameToIdPathGet_0();
case 524881489: return bem_parentConfGet_0();
case -233201100: return bem_methodCatchGetDirect_0();
case -533549775: return bem_constGetDirect_0();
case 28654928: return bem_falseValueGet_0();
case 1354910439: return bem_libEmitPathGet_0();
case -1938910782: return bem_ccMethodsGet_0();
case 1193028448: return bem_lastMethodBodyLinesGet_0();
case -676070096: return bem_sourceFileNameGet_0();
case -485700359: return bem_returnTypeGetDirect_0();
case -166171760: return bem_lastMethodsLinesGetDirect_0();
case 1729934842: return bem_smnlcsGetDirect_0();
case -1144677370: return bem_mainInClassGet_0();
case -1605324871: return bem_emitLangGet_0();
case 831399973: return bem_nameToIdGet_0();
case -277652394: return bem_constGet_0();
case -1346681154: return bem_lastMethodsSizeGetDirect_0();
case -1960802581: return bem_lineCountGetDirect_0();
case -1208289738: return bem_stringNpGetDirect_0();
case 2075493450: return bem_objectNpGetDirect_0();
case -528207947: return bem_objectNpGet_0();
case 563091117: return bem_classEmitsGet_0();
case -654147193: return bem_methodCallsGetDirect_0();
case -750288284: return bem_classCallsGetDirect_0();
case 1070616367: return bem_nameToIdGetDirect_0();
case -1224961845: return bem_instanceNotEqualGetDirect_0();
case 1593565753: return bem_synEmitPathGetDirect_0();
case -1732615543: return bem_idToNameGetDirect_0();
case -90446125: return bem_scvpGetDirect_0();
case 219112807: return bem_toString_0();
case -723982620: return bem_exceptDecGetDirect_0();
case -1573238446: return bem_lastMethodBodyLinesGetDirect_0();
case 1333799692: return bem_tagGet_0();
case 793074896: return bem_instanceEqualGet_0();
case 1025215381: return bem_useDynMethodsGet_0();
case 952097777: return bem_randGetDirect_0();
case -2133926946: return bem_returnTypeGet_0();
case -828058379: return bem_fileExtGet_0();
case 901533405: return bem_callNamesGetDirect_0();
case -1611911880: return bem_gcMarksGet_0();
case -228821990: return bem_preClassGet_0();
case -784770372: return bem_csynGetDirect_0();
case 1385113468: return bem_stringNpGet_0();
case 1916690343: return bem_msynGet_0();
case 734262401: return bem_ntypesGetDirect_0();
case 886350660: return bem_inFilePathedGetDirect_0();
case 490415838: return bem_nlGetDirect_0();
case -141462125: return bem_cnodeGet_0();
case 110535362: return bem_propDecGet_0();
case -1469457567: return bem_ccCacheGetDirect_0();
case -770499917: return bem_lastMethodsSizeGet_0();
case 1034002981: return bem_loadIds_0();
case -773754113: return bem_gcMarksGetDirect_0();
case 524954261: return bem_ntypesGet_0();
case 523549794: return bem_maxDynArgsGet_0();
case 865559487: return bem_classEmitsGetDirect_0();
case 147497190: return bem_iteratorGet_0();
case 1782813525: return bem_mainStartGet_0();
case -607680753: return bem_smnlecsGet_0();
case -1180833994: return bem_endNs_0();
case -717571931: return bem_floatNpGetDirect_0();
case -113952803: return bem_boolCcGet_0();
case -880027674: return bem_libEmitNameGet_0();
case 1445801145: return bem_serializationIteratorGet_0();
case -794062933: return bem_hashGet_0();
case 879460358: return bem_saveSyns_0();
case -1464974924: return bem_overrideMtdDecGet_0();
case -1871427692: return bem_boolTypeGet_0();
case 879347557: return bem_transGetDirect_0();
case -587632691: return bem_typeDecGet_0();
case -1678220842: return bem_buildInitial_0();
case -1512435836: return bem_onceDecsGet_0();
case -1214867913: return bem_qGetDirect_0();
case 1247152173: return bem_intNpGetDirect_0();
case 340030523: return bem_classNameGet_0();
case -1021344398: return bem_csynGet_0();
case 858963987: return bem_classConfGet_0();
case 2139529993: return bem_inFilePathedGet_0();
case 49002279: return bem_libEmitNameGetDirect_0();
case -27847346: return bem_runtimeInitGet_0();
case 37637962: return bem_print_0();
case -190763906: return bem_classCallsGet_0();
case 1286013779: return bem_parentConfGetDirect_0();
case -1188712790: return bem_fileExtGetDirect_0();
case -2085774245: return bem_inClassGet_0();
case 1615402015: return bem_create_0();
case 143942771: return bem_exceptDecGet_0();
case 1822048714: return bem_callNamesGet_0();
case -1645150086: return bem_classEndGet_0();
case 1546143657: return bem_echo_0();
case 15736987: return bem_doEmit_0();
case -1088258109: return bem_instanceEqualGetDirect_0();
case -582140588: return bem_classesInDepthOrderGet_0();
case -1909320909: return bem_superNameGet_0();
case -577190443: return bem_belslitsGet_0();
case -772689055: return bem_smnlecsGetDirect_0();
case 1563251430: return bem_lastCallGetDirect_0();
case -2095499202: return bem_fieldIteratorGet_0();
case -1986871518: return bem_methodCallsGet_0();
case 1546667417: return bem_nlGet_0();
case 1768747702: return bem_nullValueGetDirect_0();
case -791953818: return bem_spropDecGet_0();
case -1160984093: return bem_saveIds_0();
case -794718926: return bem_copy_0();
case 1847458211: return bem_instOfGetDirect_0();
case 2024190723: return bem_qGet_0();
case -17944348: return bem_maxSpillArgsLenGet_0();
case 1222173102: return bem_cnodeGetDirect_0();
case 1792075350: return bem_methodsGet_0();
case 1476844865: return bem_instanceNotEqualGet_0();
case -564584966: return bem_invpGet_0();
case -528504274: return bem_writeBET_0();
case 1124354919: return bem_initialDecGet_0();
case -323443951: return bem_baseSmtdDecGet_0();
case -1267947347: return bem_propertyDecsGet_0();
case 1001939490: return bem_preClassGetDirect_0();
case 200950127: return bem_falseValueGetDirect_0();
case 163214134: return bem_covariantReturnsGet_0();
case -699176876: return bem_synEmitPathGet_0();
case 569224888: return bem_lastMethodsLinesGet_0();
case 1905590753: return bem_boolNpGetDirect_0();
case 2116789457: return bem_fullLibEmitNameGet_0();
case -1897057311: return bem_fullLibEmitNameGetDirect_0();
case 1943903635: return bem_buildGetDirect_0();
case 722877587: return bem_getClassOutput_0();
case 1896953909: return bem_ccMethodsGetDirect_0();
case 842904212: return bem_idToNameGet_0();
case -925329659: return bem_methodCatchGet_0();
case -1304696040: return bem_superCallsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1368400756: return bem_end_1(bevd_0);
case 1518772276: return bem_preClassSet_1(bevd_0);
case 1127096947: return bem_superCallsSet_1(bevd_0);
case 738658441: return bem_superCallsSetDirect_1(bevd_0);
case -1424111792: return bem_lastMethodBodySizeSet_1(bevd_0);
case 171245138: return bem_inClassSet_1(bevd_0);
case -1014121039: return bem_boolCcSetDirect_1(bevd_0);
case 1681805586: return bem_belslitsSet_1(bevd_0);
case -2111616612: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1190998374: return bem_stringNpSetDirect_1(bevd_0);
case -1570312965: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -409588595: return bem_idToNamePathSet_1(bevd_0);
case 1419152209: return bem_falseValueSet_1(bevd_0);
case 2085396447: return bem_classEmitsSetDirect_1(bevd_0);
case 1071189511: return bem_nullValueSet_1(bevd_0);
case 250302014: return bem_equals_1(bevd_0);
case -1636840104: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 215949837: return bem_qSet_1(bevd_0);
case -454311655: return bem_cnodeSetDirect_1(bevd_0);
case -739874739: return bem_buildSetDirect_1(bevd_0);
case -1082994502: return bem_libEmitPathSet_1(bevd_0);
case 1836230983: return bem_classCallsSet_1(bevd_0);
case -1589122970: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -1700904300: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 19365969: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1661150226: return bem_def_1(bevd_0);
case -1491542024: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 7736177: return bem_methodCallsSetDirect_1(bevd_0);
case -864818508: return bem_qSetDirect_1(bevd_0);
case 300580607: return bem_callNamesSet_1(bevd_0);
case -1103352296: return bem_falseValueSetDirect_1(bevd_0);
case 709822083: return bem_floatNpSetDirect_1(bevd_0);
case -1868129616: return bem_copyTo_1(bevd_0);
case -976830222: return bem_scvpSet_1(bevd_0);
case 1126965272: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 485722069: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 115568340: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1323064047: return bem_fullLibEmitNameSet_1(bevd_0);
case 584132317: return bem_callNamesSetDirect_1(bevd_0);
case 487042660: return bem_constSetDirect_1(bevd_0);
case 1303796607: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -809685020: return bem_inFilePathedSet_1(bevd_0);
case -207962529: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1010973820: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1707058970: return bem_nameToIdSet_1(bevd_0);
case -766583660: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1124671486: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case 1053838944: return bem_boolNpSet_1(bevd_0);
case -541470257: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -383611661: return bem_cnodeSet_1(bevd_0);
case 1453179550: return bem_maxDynArgsSet_1(bevd_0);
case -1403874670: return bem_nameToIdPathSet_1(bevd_0);
case 614406558: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1143444660: return bem_inClassSetDirect_1(bevd_0);
case 21430245: return bem_exceptDecSetDirect_1(bevd_0);
case -1412980191: return bem_smnlecsSetDirect_1(bevd_0);
case -571044078: return bem_ccCacheSetDirect_1(bevd_0);
case -1686041271: return bem_emitLangSet_1(bevd_0);
case 1780720215: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -946166753: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -2026212887: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -946486146: return bem_mnodeSet_1(bevd_0);
case -1534545800: return bem_otherType_1(bevd_0);
case -761621165: return bem_instanceEqualSetDirect_1(bevd_0);
case -2448488: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -181245188: return bem_transSet_1(bevd_0);
case 596705471: return bem_inFilePathedSetDirect_1(bevd_0);
case 275558752: return bem_synEmitPathSet_1(bevd_0);
case 1419064041: return bem_sameObject_1(bevd_0);
case -501510676: return bem_msynSet_1(bevd_0);
case -1800691088: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1805881116: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1390856988: return bem_methodCatchSet_1(bevd_0);
case -1466649268: return bem_objectCcSetDirect_1(bevd_0);
case 171789757: return bem_ccMethodsSet_1(bevd_0);
case 1535980169: return bem_gcMarksSet_1(bevd_0);
case 622207194: return bem_exceptDecSet_1(bevd_0);
case 1020119747: return bem_methodCallsSet_1(bevd_0);
case 386851912: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 590161372: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1174397628: return bem_intNpSet_1(bevd_0);
case -95039403: return bem_classConfSet_1(bevd_0);
case -718784076: return bem_synEmitPathSetDirect_1(bevd_0);
case -1046564195: return bem_belslitsSetDirect_1(bevd_0);
case -1034114390: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1678118458: return bem_smnlecsSet_1(bevd_0);
case 286402689: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -73318317: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 545512221: return bem_methodCatchSetDirect_1(bevd_0);
case -1639466931: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1182351652: return bem_instOfSetDirect_1(bevd_0);
case -1684411018: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -2020249476: return bem_gcMarksSetDirect_1(bevd_0);
case -1998859969: return bem_trueValueSet_1(bevd_0);
case -1594940557: return bem_fileExtSet_1(bevd_0);
case 1321784324: return bem_libEmitNameSetDirect_1(bevd_0);
case -271456260: return bem_parentConfSet_1(bevd_0);
case 741749240: return bem_objectNpSet_1(bevd_0);
case 504827822: return bem_nlSetDirect_1(bevd_0);
case 1952408163: return bem_methodsSet_1(bevd_0);
case 1035091274: return bem_ntypesSetDirect_1(bevd_0);
case 1270345230: return bem_smnlcsSet_1(bevd_0);
case 1560536318: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -823094024: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1435340880: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -375511145: return bem_mnodeSetDirect_1(bevd_0);
case -1866033281: return bem_idToNamePathSetDirect_1(bevd_0);
case -978213337: return bem_lastMethodsSizeSet_1(bevd_0);
case -1131689639: return bem_methodsSetDirect_1(bevd_0);
case 739117568: return bem_otherClass_1(bevd_0);
case 1029265652: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 929332254: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1129530753: return bem_lineCountSetDirect_1(bevd_0);
case 1723637258: return bem_returnTypeSet_1(bevd_0);
case 1834159481: return bem_classConfSetDirect_1(bevd_0);
case 1306644644: return bem_nameToIdPathSetDirect_1(bevd_0);
case -932513957: return bem_idToNameSetDirect_1(bevd_0);
case -319057175: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1113491098: return bem_fileExtSetDirect_1(bevd_0);
case -621839358: return bem_buildSet_1(bevd_0);
case 1981346500: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -210107332: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1563828704: return bem_preClassSetDirect_1(bevd_0);
case 1132254934: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1054398949: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1334888759: return bem_methodBodySet_1(bevd_0);
case 326965075: return bem_onceDecsSetDirect_1(bevd_0);
case 1147309033: return bem_boolNpSetDirect_1(bevd_0);
case -2085149442: return bem_randSet_1(bevd_0);
case 733255353: return bem_nullValueSetDirect_1(bevd_0);
case -2072960691: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1279567851: return bem_scvpSetDirect_1(bevd_0);
case 97453982: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -867528767: return bem_dynMethodsSetDirect_1(bevd_0);
case 2117333647: return bem_propertyDecsSet_1(bevd_0);
case 1784053374: return bem_objectNpSetDirect_1(bevd_0);
case 2101656201: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 550061094: return bem_undef_1(bevd_0);
case -1274288891: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 192704192: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -906097494: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -2136340103: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1191209179: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1073792571: return bem_returnTypeSetDirect_1(bevd_0);
case -1664505565: return bem_propertyDecsSetDirect_1(bevd_0);
case 366952802: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -38251388: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1519342484: return bem_smnlcsSetDirect_1(bevd_0);
case 1405755430: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -849465277: return bem_ccMethodsSetDirect_1(bevd_0);
case -1990516842: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1282230633: return bem_intNpSetDirect_1(bevd_0);
case 349497350: return bem_instOfSet_1(bevd_0);
case -1615848781: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -976911886: return bem_classesInDepthOrderSet_1(bevd_0);
case -1100323114: return bem_ccCacheSet_1(bevd_0);
case -1732896908: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 1595193325: return bem_lastCallSet_1(bevd_0);
case 1736139951: return bem_parentConfSetDirect_1(bevd_0);
case -1635408093: return bem_constSet_1(bevd_0);
case 1507887902: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1835188942: return bem_invpSet_1(bevd_0);
case 232974543: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2059829538: return bem_invpSetDirect_1(bevd_0);
case 1672886612: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1428281479: return bem_dynMethodsSet_1(bevd_0);
case -19945451: return bem_notEquals_1(bevd_0);
case 304277065: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1928725524: return bem_methodBodySetDirect_1(bevd_0);
case 1891673909: return bem_nativeCSlotsSet_1(bevd_0);
case 1720662209: return bem_csynSet_1(bevd_0);
case -1275186023: return bem_nlSet_1(bevd_0);
case -1009713436: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1810231029: return bem_nameToIdSetDirect_1(bevd_0);
case -317347299: return bem_csynSetDirect_1(bevd_0);
case 1289453931: return bem_lastMethodsLinesSet_1(bevd_0);
case -1331148912: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1355179533: return bem_ntypesSet_1(bevd_0);
case 710982035: return bem_lastCallSetDirect_1(bevd_0);
case 487508468: return bem_emitLangSetDirect_1(bevd_0);
case -2022815028: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2044993814: return bem_sameClass_1(bevd_0);
case -607133208: return bem_objectCcSet_1(bevd_0);
case 807988904: return bem_msynSetDirect_1(bevd_0);
case 1032208766: return bem_classCallsSetDirect_1(bevd_0);
case -1859674382: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 977707769: return bem_instanceNotEqualSet_1(bevd_0);
case -1042315469: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1283840424: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1601246702: return bem_maxDynArgsSetDirect_1(bevd_0);
case -579405239: return bem_stringNpSet_1(bevd_0);
case -1736410633: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -416921738: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1143326865: return bem_lineCountSet_1(bevd_0);
case 159028377: return bem_trueValueSetDirect_1(bevd_0);
case 11786214: return bem_onceDecsSet_1(bevd_0);
case -1935405349: return bem_sameType_1(bevd_0);
case 855795307: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1257666375: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 888265025: return bem_libEmitPathSetDirect_1(bevd_0);
case -993241020: return bem_boolCcSet_1(bevd_0);
case 1415472827: return bem_instanceEqualSet_1(bevd_0);
case 1241927559: return bem_randSetDirect_1(bevd_0);
case 1741388883: return bem_transSetDirect_1(bevd_0);
case -1200478310: return bem_idToNameSet_1(bevd_0);
case -209724578: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1064663351: return bem_libEmitNameSet_1(bevd_0);
case -380487563: return bem_floatNpSet_1(bevd_0);
case -479994130: return bem_begin_1(bevd_0);
case 277529267: return bem_classEmitsSet_1(bevd_0);
case 1738146024: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1480378585: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -249626216: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 542168455: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2112740717: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2043877682: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1571342318: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 63102125: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -716902816: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 737459961: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1708873965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1147646402: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 853768892: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1738406137: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -938540681: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1993288927: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -605085889: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -827010913: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1315891381: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1662082732: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 927050468: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1642107107: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 724762998: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 889018402: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -933110131: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 75233440: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1982571943: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1085571438: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1779739594: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
