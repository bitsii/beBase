package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildCall extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildCall() { }
private static byte[] becc_BEC_2_5_4_BuildCall_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C};
private static byte[] becc_BEC_2_5_4_BuildCall_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_0 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_2 = {0x20,0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_3 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_4 = {0x20,0x6E,0x6F,0x74,0x42,0x6F,0x75,0x6E,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_5 = {0x20,0x77,0x61,0x73,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_6 = {0x47,0x45,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_7 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_8 = {0x53,0x45,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_9 = {0x53,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_10 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72,0x20,0x74,0x79,0x70,0x65,0x20};
public static BEC_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_inst;

public static BET_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_6_TextString bevp_accessorType;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_literalValue;
public BEC_2_5_8_BuildNamePath bevp_newNp;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_2_5_4_LogicBool bevp_isConstruct;
public BEC_2_5_4_LogicBool bevp_bound;
public BEC_2_5_4_LogicBool bevp_wasBound;
public BEC_2_5_4_LogicBool bevp_wasAccessor;
public BEC_2_5_4_LogicBool bevp_wasOper;
public BEC_2_5_4_LogicBool bevp_isLiteral;
public BEC_2_5_4_LogicBool bevp_checkTypes;
public BEC_2_4_6_TextString bevp_checkTypesType;
public BEC_2_5_4_LogicBool bevp_superCall;
public BEC_2_5_4_LogicBool bevp_wasImpliedConstruct;
public BEC_2_5_4_LogicBool bevp_wasForeachGenned;
public BEC_2_5_4_LogicBool bevp_untyped;
public BEC_2_5_4_LogicBool bevp_isForward;
public BEC_2_9_4_ContainerList bevp_argCasts;
public BEC_2_5_4_BuildCall bem_new_0() throws Throwable {
bevp_isConstruct = be.BECS_Runtime.boolFalse;
bevp_bound = be.BECS_Runtime.boolTrue;
bevp_wasBound = be.BECS_Runtime.boolTrue;
bevp_wasAccessor = be.BECS_Runtime.boolFalse;
bevp_wasOper = be.BECS_Runtime.boolFalse;
bevp_isLiteral = be.BECS_Runtime.boolFalse;
bevp_checkTypes = be.BECS_Runtime.boolTrue;
bevp_checkTypesType = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_0));
bevp_superCall = be.BECS_Runtime.boolFalse;
bevp_wasImpliedConstruct = be.BECS_Runtime.boolFalse;
bevp_wasForeachGenned = be.BECS_Runtime.boolFalse;
bevp_untyped = be.BECS_Runtime.boolFalse;
bevp_isForward = be.BECS_Runtime.boolFalse;
bevp_argCasts = (new BEC_2_9_4_ContainerList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_7_SystemClasses bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_ret = bevt_0_ta_ph.bem_className_1(this);
if (bevp_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_1));
bevt_2_ta_ph = bevl_ret.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
} /* Line: 331*/
if (bevp_orgName == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildCall_bels_2));
bevt_6_ta_ph = bevl_ret.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevp_orgName.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
} /* Line: 334*/
if (bevp_numargs == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildCall_bels_3));
bevt_10_ta_ph = bevl_ret.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_numargs.bem_toString_0();
bevl_ret = bevt_10_ta_ph.bem_add_1(bevt_12_ta_ph);
} /* Line: 337*/
if (bevp_bound.bevi_bool) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 339*/ {
bevt_14_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_4));
bevl_ret = bevl_ret.bem_add_1(bevt_14_ta_ph);
} /* Line: 340*/
if (bevp_wasAccessor.bevi_bool)/* Line: 342*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_4_BuildCall_bels_5));
bevl_ret = bevl_ret.bem_add_1(bevt_15_ta_ph);
} /* Line: 343*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildCall bem_toAccessorName_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_9_SystemException bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_6));
bevt_0_ta_ph = bevp_accessorType.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 349*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_7));
bevp_name = bevp_name.bem_add_1(bevt_2_ta_ph);
} /* Line: 350*/
 else /* Line: 349*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_8));
bevt_3_ta_ph = bevp_accessorType.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_9));
bevp_name = bevp_name.bem_add_1(bevt_5_ta_ph);
} /* Line: 352*/
 else /* Line: 353*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildCall_bels_10));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevp_accessorType);
bevt_6_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_ta_ph);
throw new be.BECS_ThrowBack(bevt_6_ta_ph);
} /* Line: 354*/
} /* Line: 349*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGet_0() throws Throwable {
return bevp_accessorType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGet_0() throws Throwable {
return bevp_literalValue;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGet_0() throws Throwable {
return bevp_newNp;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGet_0() throws Throwable {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGet_0() throws Throwable {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGet_0() throws Throwable {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGet_0() throws Throwable {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGet_0() throws Throwable {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGet_0() throws Throwable {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGet_0() throws Throwable {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_checkTypesTypeGet_0() throws Throwable {
return bevp_checkTypesType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGet_0() throws Throwable {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGet_0() throws Throwable {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGet_0() throws Throwable {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGet_0() throws Throwable {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGet_0() throws Throwable {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGet_0() throws Throwable {
return bevp_argCasts;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 322, 329, 329, 330, 330, 331, 331, 331, 331, 333, 333, 334, 334, 334, 334, 336, 336, 337, 337, 337, 337, 339, 339, 340, 340, 343, 343, 345, 349, 349, 350, 350, 351, 351, 352, 352, 354, 354, 354, 354, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 78, 79, 80, 85, 86, 87, 88, 89, 91, 96, 97, 98, 99, 100, 102, 107, 108, 109, 110, 111, 113, 118, 119, 120, 123, 124, 126, 138, 139, 141, 142, 145, 146, 148, 149, 152, 153, 154, 155, 161, 164, 168, 171, 175, 178, 182, 185, 189, 192, 196, 199, 203, 206, 210, 213, 217, 220, 224, 227, 231, 234, 238, 241, 245, 248, 252, 255, 259, 262, 266, 269, 273, 276, 280, 283, 287, 290, 294, 297, 301, 304};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 308 44
new 0 308 44
assign 1 309 45
new 0 309 45
assign 1 310 46
new 0 310 46
assign 1 311 47
new 0 311 47
assign 1 312 48
new 0 312 48
assign 1 313 49
new 0 313 49
assign 1 314 50
new 0 314 50
assign 1 315 51
new 0 315 51
assign 1 316 52
new 0 316 52
assign 1 317 53
new 0 317 53
assign 1 318 54
new 0 318 54
assign 1 319 55
new 0 319 55
assign 1 320 56
new 0 320 56
assign 1 322 57
new 0 322 57
assign 1 329 78
new 0 329 78
assign 1 329 79
className 1 329 79
assign 1 330 80
def 1 330 85
assign 1 331 86
new 0 331 86
assign 1 331 87
add 1 331 87
assign 1 331 88
toString 0 331 88
assign 1 331 89
add 1 331 89
assign 1 333 91
def 1 333 96
assign 1 334 97
new 0 334 97
assign 1 334 98
add 1 334 98
assign 1 334 99
toString 0 334 99
assign 1 334 100
add 1 334 100
assign 1 336 102
def 1 336 107
assign 1 337 108
new 0 337 108
assign 1 337 109
add 1 337 109
assign 1 337 110
toString 0 337 110
assign 1 337 111
add 1 337 111
assign 1 339 113
not 0 339 118
assign 1 340 119
new 0 340 119
assign 1 340 120
add 1 340 120
assign 1 343 123
new 0 343 123
assign 1 343 124
add 1 343 124
return 1 345 126
assign 1 349 138
new 0 349 138
assign 1 349 139
equals 1 349 139
assign 1 350 141
new 0 350 141
assign 1 350 142
add 1 350 142
assign 1 351 145
new 0 351 145
assign 1 351 146
equals 1 351 146
assign 1 352 148
new 0 352 148
assign 1 352 149
add 1 352 149
assign 1 354 152
new 0 354 152
assign 1 354 153
add 1 354 153
assign 1 354 154
new 1 354 154
throw 1 354 155
return 1 0 161
assign 1 0 164
return 1 0 168
assign 1 0 171
return 1 0 175
assign 1 0 178
return 1 0 182
assign 1 0 185
return 1 0 189
assign 1 0 192
return 1 0 196
assign 1 0 199
return 1 0 203
assign 1 0 206
return 1 0 210
assign 1 0 213
return 1 0 217
assign 1 0 220
return 1 0 224
assign 1 0 227
return 1 0 231
assign 1 0 234
return 1 0 238
assign 1 0 241
return 1 0 245
assign 1 0 248
return 1 0 252
assign 1 0 255
return 1 0 259
assign 1 0 262
return 1 0 266
assign 1 0 269
return 1 0 273
assign 1 0 276
return 1 0 280
assign 1 0 283
return 1 0 287
assign 1 0 290
return 1 0 294
assign 1 0 297
return 1 0 301
assign 1 0 304
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 822474506: return bem_wasAccessorGet_0();
case -1008624040: return bem_literalValueGet_0();
case 1265008506: return bem_nameGet_0();
case 1924266071: return bem_boundGet_0();
case -1337014400: return bem_copy_0();
case -150143853: return bem_argCastsGet_0();
case -2091527580: return bem_checkTypesGet_0();
case -424614227: return bem_print_0();
case -1185905671: return bem_numargsGet_0();
case 21170282: return bem_untypedGet_0();
case -1149735740: return bem_orgNameGet_0();
case 1990740779: return bem_isForwardGet_0();
case 42738335: return bem_newNpGet_0();
case 1293705497: return bem_iteratorGet_0();
case -1537103983: return bem_isLiteralGet_0();
case -1881496369: return bem_wasForeachGennedGet_0();
case 1301173886: return bem_wasImpliedConstructGet_0();
case -676802561: return bem_create_0();
case -1295075941: return bem_toAccessorName_0();
case 1117573736: return bem_isConstructGet_0();
case -234441937: return bem_wasOperGet_0();
case 717532055: return bem_checkTypesTypeGet_0();
case -1309254003: return bem_cposGet_0();
case -2046929697: return bem_toString_0();
case 996392438: return bem_accessorTypeGet_0();
case -52976429: return bem_new_0();
case 1672732583: return bem_superCallGet_0();
case -1865800924: return bem_wasBoundGet_0();
case -1648793551: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 698123854: return bem_wasBoundSet_1(bevd_0);
case -1855457816: return bem_boundSet_1(bevd_0);
case -251951949: return bem_literalValueSet_1(bevd_0);
case -1683927949: return bem_accessorTypeSet_1(bevd_0);
case -2079650949: return bem_checkTypesSet_1(bevd_0);
case 1036416871: return bem_cposSet_1(bevd_0);
case 396762923: return bem_wasAccessorSet_1(bevd_0);
case 481014303: return bem_isConstructSet_1(bevd_0);
case -19948831: return bem_checkTypesTypeSet_1(bevd_0);
case 2098742814: return bem_newNpSet_1(bevd_0);
case -1337452029: return bem_notEquals_1(bevd_0);
case 1346074140: return bem_equals_1(bevd_0);
case 526222373: return bem_def_1(bevd_0);
case -516448896: return bem_nameSet_1(bevd_0);
case -310206556: return bem_numargsSet_1(bevd_0);
case 597731068: return bem_wasOperSet_1(bevd_0);
case 2001132402: return bem_wasForeachGennedSet_1(bevd_0);
case 322005879: return bem_copyTo_1(bevd_0);
case 670074633: return bem_superCallSet_1(bevd_0);
case -163353145: return bem_wasImpliedConstructSet_1(bevd_0);
case 761889823: return bem_argCastsSet_1(bevd_0);
case -1510262009: return bem_untypedSet_1(bevd_0);
case 1133343372: return bem_isLiteralSet_1(bevd_0);
case -955185845: return bem_isForwardSet_1(bevd_0);
case 1651082390: return bem_undef_1(bevd_0);
case 253235960: return bem_orgNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 964580200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1649942408: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -628094110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1488275060: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildCall_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildCall_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildCall();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst = (BEC_2_5_4_BuildCall) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_type;
}
}
