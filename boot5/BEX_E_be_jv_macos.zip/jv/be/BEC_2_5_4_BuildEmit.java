package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildEmit extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildEmit() { }
private static byte[] becc_BEC_2_5_4_BuildEmit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74};
private static byte[] becc_BEC_2_5_4_BuildEmit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_inst;

public static BET_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_type;

public BEC_2_4_6_TextString bevp_text;
public BEC_2_9_3_ContainerSet bevp_langs;
public BEC_2_5_4_BuildEmit bem_new_2(BEC_2_4_6_TextString beva__text, BEC_2_9_3_ContainerSet beva__langs) throws Throwable {
bevp_text = beva__text;
bevp_langs = beva__langs;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_textGet_0() throws Throwable {
return bevp_text;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_text = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGet_0() throws Throwable {
return bevp_langs;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {74, 75, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 19, 22, 26, 29};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 74 14
assign 1 75 15
return 1 0 19
assign 1 0 22
return 1 0 26
assign 1 0 29
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1604962015: return bem_sourceFileNameGet_0();
case 1310553601: return bem_toString_0();
case -732524867: return bem_tagGet_0();
case 1924413487: return bem_hashGet_0();
case -980884323: return bem_new_0();
case -1897026239: return bem_echo_0();
case -1565549870: return bem_print_0();
case 1793221455: return bem_copy_0();
case 1028376271: return bem_langsGet_0();
case -1226625126: return bem_once_0();
case 649783133: return bem_textGet_0();
case 489788599: return bem_serializeContents_0();
case -1920531733: return bem_serializationIteratorGet_0();
case -1535847383: return bem_toAny_0();
case 1150664853: return bem_create_0();
case -290041240: return bem_serializeToString_0();
case 2049066942: return bem_fieldIteratorGet_0();
case 2052709534: return bem_many_0();
case 194016774: return bem_iteratorGet_0();
case -525681067: return bem_classNameGet_0();
case 332981262: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 463860193: return bem_langsSet_1(bevd_0);
case 1868528499: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -850605413: return bem_textSet_1(bevd_0);
case -467299687: return bem_defined_1(bevd_0);
case -1966507736: return bem_undef_1(bevd_0);
case 386836188: return bem_otherClass_1(bevd_0);
case 562081982: return bem_undefined_1(bevd_0);
case 1998776126: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 257405303: return bem_copyTo_1(bevd_0);
case 863435643: return bem_equals_1(bevd_0);
case -1834098557: return bem_notEquals_1(bevd_0);
case 1693216688: return bem_sameClass_1(bevd_0);
case 959360624: return bem_otherType_1(bevd_0);
case 420384947: return bem_def_1(bevd_0);
case -1545437990: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -145738070: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1021436824: return bem_sameType_1(bevd_0);
case -2104330508: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1240676558: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -371043039: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1325559256: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1035622269: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -145115514: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1581426787: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_3_ContainerSet) bevd_1);
case 686918154: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1895634211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildEmit_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildEmit_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildEmit();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst = (BEC_2_5_4_BuildEmit) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_type;
}
}
