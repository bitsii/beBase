package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildEmit extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildEmit() { }
private static byte[] becc_BEC_2_5_4_BuildEmit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74};
private static byte[] becc_BEC_2_5_4_BuildEmit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_inst;

public static BET_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_type;

public BEC_2_4_6_TextString bevp_text;
public BEC_2_9_3_ContainerSet bevp_langs;
public BEC_2_5_4_BuildEmit bem_new_2(BEC_2_4_6_TextString beva__text, BEC_2_9_3_ContainerSet beva__langs) throws Throwable {
bevp_text = beva__text;
bevp_langs = beva__langs;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_textGet_0() throws Throwable {
return bevp_text;
} /*method end*/
public final BEC_2_4_6_TextString bem_textGetDirect_0() throws Throwable {
return bevp_text;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_text = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildEmit bem_textSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_text = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGet_0() throws Throwable {
return bevp_langs;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_langsGetDirect_0() throws Throwable {
return bevp_langs;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_4_BuildEmit bem_langsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {74, 75, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 19, 22, 25, 29, 33, 36, 39, 43};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 74 14
assign 1 75 15
return 1 0 19
return 1 0 22
assign 1 0 25
assign 1 0 29
return 1 0 33
return 1 0 36
assign 1 0 39
assign 1 0 43
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2061412556: return bem_classNameGet_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case 605755759: return bem_fieldNamesGet_0();
case -39706070: return bem_serializeContents_0();
case 2069196027: return bem_print_0();
case 1359777543: return bem_toAny_0();
case 874968344: return bem_once_0();
case 344752250: return bem_hashGet_0();
case 1849268389: return bem_langsGetDirect_0();
case 27033645: return bem_sourceFileNameGet_0();
case 502031978: return bem_iteratorGet_0();
case 1480415803: return bem_serializationIteratorGet_0();
case -1943106750: return bem_textGetDirect_0();
case 325964466: return bem_echo_0();
case 1965613314: return bem_tagGet_0();
case 1578098134: return bem_toString_0();
case 26417469: return bem_create_0();
case 962099177: return bem_fieldIteratorGet_0();
case -1878305271: return bem_many_0();
case 705608101: return bem_textGet_0();
case -2013037844: return bem_langsGet_0();
case 334767424: return bem_copy_0();
case 2132890711: return bem_new_0();
case -799200084: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 45736029: return bem_langsSet_1(bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case -1891113914: return bem_langsSetDirect_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case -1104398517: return bem_textSet_1(bevd_0);
case 188911465: return bem_textSetDirect_1(bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 140119030: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_3_ContainerSet) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildEmit_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildEmit_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildEmit();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst = (BEC_2_5_4_BuildEmit) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_type;
}
}
