package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_5_SystemThing extends BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemThing() { }
private static byte[] becc_BEC_2_6_5_SystemThing_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_6_5_SystemThing_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_5_SystemThing bece_BEC_2_6_5_SystemThing_bevs_inst;

public static BET_2_6_5_SystemThing bece_BEC_2_6_5_SystemThing_bevs_type;

public BEC_2_6_5_SystemThing bem_vthingGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_vthingSet_1(BEC_2_6_6_SystemObject beva_vthing) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_new_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -451287241: return bem_iteratorGet_0();
case 1260713952: return bem_fieldNamesGet_0();
case -512173810: return bem_tagGet_0();
case 166156356: return bem_hashGet_0();
case 1012944178: return bem_create_0();
case 243534716: return bem_vthingGet_0();
case -1360047774: return bem_serializeToString_0();
case -794542805: return bem_fieldIteratorGet_0();
case 1712919396: return bem_serializationIteratorGet_0();
case 1010970574: return bem_deserializeClassNameGet_0();
case 368405588: return bem_echo_0();
case 652618710: return bem_print_0();
case 938978826: return bem_serializeContents_0();
case -131396274: return bem_classNameGet_0();
case 373871049: return bem_copy_0();
case 657440259: return bem_many_0();
case 37115722: return bem_toAny_0();
case 149300560: return bem_sourceFileNameGet_0();
case -1497736169: return bem_new_0();
case 884758076: return bem_toString_0();
case 144782273: return bem_once_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1849842647: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1450913634: return bem_defined_1(bevd_0);
case -2033993347: return bem_sameObject_1(bevd_0);
case 46811792: return bem_otherType_1(bevd_0);
case 2044588239: return bem_otherClass_1(bevd_0);
case 773892154: return bem_sameClass_1(bevd_0);
case 974930963: return bem_undefined_1(bevd_0);
case -926157429: return bem_equals_1(bevd_0);
case -1418198617: return bem_def_1(bevd_0);
case -1434589659: return bem_undef_1(bevd_0);
case -596753155: return bem_vthingSet_1(bevd_0);
case 1184632884: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1691038775: return bem_notEquals_1(bevd_0);
case -1340973491: return bem_sameType_1(bevd_0);
case -1952204646: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -442448216: return bem_copyTo_1(bevd_0);
case -675060011: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -330880231: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1368517810: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1351268593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1842958248: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 840782676: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 498622947: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1807714621: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemThing_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_5_SystemThing_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_5_SystemThing();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_5_SystemThing.bece_BEC_2_6_5_SystemThing_bevs_inst = (BEC_2_6_5_SystemThing) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_5_SystemThing.bece_BEC_2_6_5_SystemThing_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_5_SystemThing.bece_BEC_2_6_5_SystemThing_bevs_type;
}
}
