package be;
/* IO:File: source/base/System.be */
public final class BEC_2_6_5_SystemThing extends BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemThing() { }
private static byte[] becc_BEC_2_6_5_SystemThing_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_6_5_SystemThing_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_5_SystemThing bece_BEC_2_6_5_SystemThing_bevs_inst;

public static BET_2_6_5_SystemThing bece_BEC_2_6_5_SystemThing_bevs_type;

public BEC_2_6_5_SystemThing bem_vthingGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_vthingSet_1(BEC_2_6_6_SystemObject beva_vthing) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_new_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1087891034: return bem_copy_0();
case -615427058: return bem_iteratorGet_0();
case 1031887720: return bem_vthingGet_0();
case 380806302: return bem_new_0();
case -716837866: return bem_hashGet_0();
case -1147088242: return bem_create_0();
case 603718350: return bem_print_0();
case 53308341: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1554282063: return bem_notEquals_1(bevd_0);
case 1368081775: return bem_vthingSet_1(bevd_0);
case 1209125372: return bem_undef_1(bevd_0);
case -1237306698: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1462940865: return bem_copyTo_1(bevd_0);
case 1738005159: return bem_equals_1(bevd_0);
case 971589665: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -29663031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1505420135: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2021917335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 559223927: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1581466981: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemThing_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_5_SystemThing_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_5_SystemThing();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_5_SystemThing.bece_BEC_2_6_5_SystemThing_bevs_inst = (BEC_2_6_5_SystemThing) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_5_SystemThing.bece_BEC_2_6_5_SystemThing_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_5_SystemThing.bece_BEC_2_6_5_SystemThing_bevs_type;
}
}
