package be;
/* IO:File: source/base/List.be */
public final class BEC_2_9_4_ContainerList extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_1 = (new BEC_2_4_3_MathInt(16));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_7 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_9 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_15 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_4_ContainerList bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bem_new_2(bevt_0_tmpany_phold, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_leni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
if (beva_capi == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 196 */
if (bevp_length == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 198 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 201 */ {
return this;
} /* Line: 202 */
} /* Line: 201 */

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = bece_BEC_2_9_4_ContainerList_bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 238 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_length.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_4;
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_5;
bevt_1_tmpany_phold = bevp_length.bem_subtract_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 271 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_7;
bevt_5_tmpany_phold = beva_posi.bem_add_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
} /* Line: 274 */

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 290 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 290 */ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 296 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_10;
bevl_j = beva_pos.bem_add_1(bevt_2_tmpany_phold);
bevl_i = beva_pos.bem_copy_0();
while (true)
 /* Line: 309 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevt_4_tmpany_phold = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 309 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bem_put_2(bevl_fl, null);
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_11;
bevt_5_tmpany_phold = bevp_length.bem_subtract_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 315 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 329 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 329 */ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 329 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_copy_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_n = bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 337 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 337 */ {
bevt_1_tmpany_phold = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 337 */
 else  /* Line: 337 */ {
break;
} /* Line: 337 */
} /* Line: 337 */
return (BEC_2_9_4_ContainerList) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_create_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) throws Throwable {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_4_tmpany_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpany_phold = bevp_length.bem_add_1(bevt_4_tmpany_phold);
bevl_yi = (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_loop = bem_iteratorGet_0();
while (true)
 /* Line: 349 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1276472965);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 349 */ {
bevl_c = bevt_0_tmpany_loop.bemd_0(-868741030);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 350 */
 else  /* Line: 349 */ {
break;
} /* Line: 349 */
} /* Line: 349 */
bevt_1_tmpany_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 352 */ {
bevt_6_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1276472965);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 352 */ {
bevl_c = bevt_1_tmpany_loop.bemd_0(-868741030);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 353 */
 else  /* Line: 352 */ {
break;
} /* Line: 352 */
} /* Line: 352 */
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_tmpany_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_start.bem_copy_0();
while (true)
 /* Line: 367 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 367 */ {
bevl_c = bevl_i.bem_copy_0();
bevl_j = bevl_i.bem_copy_0();
while (true)
 /* Line: 369 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 369 */ {
bevt_3_tmpany_phold = bem_get_1(bevl_j);
bevt_4_tmpany_phold = bem_get_1(bevl_c);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-387623669, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 370 */ {
bevl_c = bevl_j.bem_copy_0();
} /* Line: 371 */
bevl_j.bevi_int++;
} /* Line: 369 */
 else  /* Line: 369 */ {
break;
} /* Line: 369 */
} /* Line: 369 */
bevl_hold = bem_get_1(bevl_i);
bevt_5_tmpany_phold = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_tmpany_phold);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 367 */
 else  /* Line: 367 */ {
break;
} /* Line: 367 */
} /* Line: 367 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 386 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 386 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 387 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 387 */
 else  /* Line: 387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 387 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpany_phold = bevl_so.bemd_1(-387623669, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 390 */ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 392 */
 else  /* Line: 393 */ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 395 */
} /* Line: 390 */
 else  /* Line: 387 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 400 */
 else  /* Line: 387 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 404 */
} /* Line: 387 */
} /* Line: 387 */
bevl_i.bevi_int++;
} /* Line: 406 */
 else  /* Line: 386 */ {
break;
} /* Line: 386 */
} /* Line: 386 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bem_mergeSort_2(bevt_1_tmpany_phold, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_2_tmpany_phold = bem_create_1(bevt_3_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevt_2_tmpany_phold;
} /* Line: 417 */
 else  /* Line: 416 */ {
bevt_5_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 418 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_8_tmpany_phold = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 421 */
 else  /* Line: 422 */ {
bevt_9_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpany_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 430 */
} /* Line: 416 */
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 435 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 436 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 442 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_list = java.util.Arrays.copyOf(this.bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 464 */
while (true)
 /* Line: 467 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 467 */ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 478 */
 else  /* Line: 467 */ {
break;
} /* Line: 467 */
} /* Line: 467 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
while (true)
 /* Line: 485 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-1276472965);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 485 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(-868741030);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 486 */
 else  /* Line: 485 */ {
break;
} /* Line: 485 */
} /* Line: 485 */
} /* Line: 485 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 492 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(502031978);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 493 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 498 */ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 509 */
 else  /* Line: 510 */ {
bevt_1_tmpany_phold = bevp_length.bem_copy_0();
bem_put_2(bevt_1_tmpany_phold, beva_val);
} /* Line: 512 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 517 */ {
bevt_2_tmpany_phold = beva_val.bemd_1(1489186141, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 517 */
 else  /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 517 */ {
bem_addAll_1(beva_val);
} /* Line: 518 */
 else  /* Line: 519 */ {
bem_addValueWhole_1(beva_val);
} /* Line: 520 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 526 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 526 */ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 528 */ {
bevt_3_tmpany_phold = beva_value.bemd_1(1669065184, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 528 */
 else  /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 528 */ {
return bevl_i;
} /* Line: 529 */
bevl_i.bevi_int++;
} /* Line: 526 */
 else  /* Line: 526 */ {
break;
} /* Line: 526 */
} /* Line: 526 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_find_1(beva_value);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 536 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 537 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_sortedFind_2(beva_value, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 556 */ {
bevt_3_tmpany_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_divide_1(bevt_4_tmpany_phold);
bevl_mid = bevt_2_tmpany_phold.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_tmpany_phold = beva_value.bemd_1(1669065184, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 559 */ {
return bevl_mid;
} /* Line: 560 */
 else  /* Line: 559 */ {
bevt_6_tmpany_phold = beva_value.bemd_1(-416396325, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 561 */ {
bevl_low = bevl_mid;
} /* Line: 563 */
 else  /* Line: 559 */ {
bevt_7_tmpany_phold = beva_value.bemd_1(-387623669, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 564 */ {
bevl_high = bevl_mid;
} /* Line: 566 */
} /* Line: 559 */
} /* Line: 559 */
if (bevl_lastMid == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 569 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 569 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 569 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 569 */
 else  /* Line: 569 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 569 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 570 */ {
bevt_11_tmpany_phold = bem_get_1(bevl_low);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(-387623669, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 570 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 570 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 570 */
 else  /* Line: 570 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 570 */ {
return bevl_low;
} /* Line: 571 */
return null;
} /* Line: 573 */
bevl_lastMid = bevl_mid;
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 576 */ {
return null;
} /* Line: 577 */
} /* Line: 576 */
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public final BEC_2_4_3_MathInt bem_lengthGetDirect_0() throws Throwable {
return bevp_length;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_lengthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_4_3_MathInt bem_capacityGetDirect_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public final BEC_2_4_3_MathInt bem_multiplierGetDirect_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_multiplierSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {187, 187, 187, 187, 187, 191, 195, 195, 0, 195, 195, 0, 0, 196, 196, 196, 198, 198, 201, 201, 202, 226, 227, 228, 233, 237, 237, 237, 238, 238, 240, 240, 250, 250, 254, 254, 258, 258, 262, 262, 262, 266, 266, 266, 266, 270, 270, 270, 271, 271, 271, 273, 273, 274, 274, 274, 290, 290, 290, 290, 290, 0, 0, 0, 302, 306, 306, 307, 307, 308, 308, 309, 309, 309, 310, 310, 311, 309, 313, 314, 314, 314, 315, 315, 317, 317, 321, 321, 325, 325, 329, 329, 329, 330, 329, 332, 336, 337, 337, 337, 338, 338, 337, 340, 343, 343, 345, 345, 348, 348, 348, 348, 349, 0, 349, 349, 350, 352, 0, 352, 352, 353, 355, 359, 359, 363, 363, 367, 367, 367, 368, 369, 369, 369, 370, 370, 370, 371, 369, 374, 375, 375, 376, 367, 381, 382, 383, 384, 385, 386, 386, 387, 387, 387, 387, 0, 0, 0, 388, 389, 390, 391, 392, 394, 395, 397, 397, 398, 399, 400, 401, 401, 402, 403, 404, 406, 411, 411, 411, 415, 416, 416, 416, 417, 417, 417, 418, 418, 418, 419, 419, 420, 420, 420, 421, 423, 423, 424, 425, 426, 427, 428, 429, 430, 435, 436, 436, 436, 442, 442, 443, 464, 467, 467, 478, 480, 484, 484, 485, 486, 486, 492, 492, 493, 493, 498, 498, 509, 512, 512, 517, 517, 517, 0, 0, 0, 518, 520, 526, 526, 526, 527, 528, 528, 528, 0, 0, 0, 529, 526, 532, 536, 536, 536, 537, 537, 539, 539, 545, 545, 545, 552, 553, 557, 557, 557, 557, 558, 559, 560, 561, 563, 564, 566, 569, 569, 569, 569, 0, 0, 0, 570, 570, 0, 0, 0, 571, 573, 575, 576, 577, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {58, 59, 60, 61, 62, 66, 77, 82, 83, 86, 91, 92, 95, 99, 100, 101, 103, 108, 109, 114, 115, 120, 121, 122, 126, 133, 134, 139, 140, 141, 143, 144, 154, 155, 159, 160, 165, 166, 171, 172, 173, 179, 180, 181, 182, 192, 193, 198, 199, 200, 201, 203, 208, 209, 210, 211, 223, 224, 229, 230, 235, 236, 239, 243, 249, 264, 269, 270, 271, 272, 273, 274, 277, 282, 283, 284, 285, 286, 292, 293, 294, 295, 296, 297, 299, 300, 304, 305, 309, 310, 315, 318, 323, 324, 325, 331, 339, 340, 343, 348, 349, 350, 351, 357, 361, 362, 366, 367, 379, 380, 381, 382, 383, 383, 386, 388, 389, 395, 395, 398, 400, 401, 407, 411, 412, 416, 417, 431, 434, 439, 440, 441, 444, 449, 450, 451, 452, 454, 456, 462, 463, 464, 465, 466, 489, 490, 491, 492, 493, 496, 501, 502, 507, 508, 513, 514, 517, 521, 524, 525, 526, 528, 529, 532, 533, 537, 542, 543, 544, 545, 548, 553, 554, 555, 556, 560, 571, 572, 573, 593, 594, 595, 600, 601, 602, 603, 606, 607, 612, 613, 614, 615, 616, 617, 618, 621, 622, 623, 624, 625, 626, 627, 628, 629, 637, 639, 640, 641, 649, 654, 655, 658, 662, 667, 670, 676, 683, 688, 691, 693, 694, 706, 711, 712, 713, 720, 725, 728, 731, 732, 740, 745, 746, 748, 751, 755, 758, 761, 772, 775, 780, 781, 782, 787, 788, 790, 793, 797, 800, 802, 808, 815, 816, 821, 822, 823, 825, 826, 831, 832, 833, 854, 855, 858, 859, 860, 861, 862, 863, 865, 868, 870, 873, 875, 879, 884, 885, 890, 891, 894, 898, 902, 903, 905, 908, 912, 915, 917, 919, 920, 922, 927, 930, 933, 937, 940, 943, 947, 950, 953, 957};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 187 58
new 0 187 58
assign 1 187 59
once 0 187 59
assign 1 187 60
new 0 187 60
assign 1 187 61
once 0 187 61
new 2 187 62
new 2 191 66
assign 1 195 77
undef 1 195 82
assign 1 0 83
assign 1 195 86
undef 1 195 91
assign 1 0 92
assign 1 0 95
assign 1 196 99
new 0 196 99
assign 1 196 100
new 1 196 100
throw 1 196 101
assign 1 198 103
def 1 198 108
assign 1 201 109
equals 1 201 114
return 1 202 115
assign 1 226 120
copy 0 226 120
assign 1 227 121
copy 0 227 121
assign 1 228 122
new 0 228 122
return 1 233 126
assign 1 237 133
new 0 237 133
assign 1 237 134
equals 1 237 139
assign 1 238 140
new 0 238 140
return 1 238 141
assign 1 240 143
new 0 240 143
return 1 240 144
assign 1 250 154
toString 0 250 154
return 1 250 155
assign 1 254 159
new 1 254 159
new 1 254 160
assign 1 258 165
iteratorGet 0 258 165
return 1 258 166
assign 1 262 171
new 0 262 171
assign 1 262 172
get 1 262 172
return 1 262 173
assign 1 266 179
new 0 266 179
assign 1 266 180
subtract 1 266 180
assign 1 266 181
get 1 266 181
return 1 266 182
assign 1 270 192
new 0 270 192
assign 1 270 193
lesser 1 270 198
assign 1 271 199
new 0 271 199
assign 1 271 200
new 1 271 200
throw 1 271 201
assign 1 273 203
greaterEquals 1 273 208
assign 1 274 209
new 0 274 209
assign 1 274 210
add 1 274 210
lengthSet 1 274 211
assign 1 290 223
new 0 290 223
assign 1 290 224
greaterEquals 1 290 229
assign 1 290 230
lesser 1 290 235
assign 1 0 236
assign 1 0 239
assign 1 0 243
return 1 302 249
assign 1 306 264
lesser 1 306 269
assign 1 307 270
new 0 307 270
assign 1 307 271
subtract 1 307 271
assign 1 308 272
new 0 308 272
assign 1 308 273
add 1 308 273
assign 1 309 274
copy 0 309 274
assign 1 309 277
lesser 1 309 282
assign 1 310 283
get 1 310 283
put 2 310 284
incrementValue 0 311 285
incrementValue 0 309 286
put 2 313 292
assign 1 314 293
new 0 314 293
assign 1 314 294
subtract 1 314 294
lengthSet 1 314 295
assign 1 315 296
new 0 315 296
return 1 315 297
assign 1 317 299
new 0 317 299
return 1 317 300
assign 1 321 304
new 1 321 304
return 1 321 305
assign 1 325 309
new 1 325 309
return 1 325 310
assign 1 329 315
new 0 329 315
assign 1 329 318
lesser 1 329 323
put 2 330 324
incrementValue 0 329 325
assign 1 332 331
new 0 332 331
assign 1 336 339
create 0 336 339
assign 1 337 340
new 0 337 340
assign 1 337 343
lesser 1 337 348
assign 1 338 349
get 1 338 349
put 2 338 350
incrementValue 0 337 351
return 1 340 357
assign 1 343 361
new 1 343 361
return 1 343 362
assign 1 345 366
new 1 345 366
return 1 345 367
assign 1 348 379
new 0 348 379
assign 1 348 380
lengthGet 0 348 380
assign 1 348 381
add 1 348 381
assign 1 348 382
new 2 348 382
assign 1 349 383
iteratorGet 0 0 383
assign 1 349 386
hasNextGet 0 349 386
assign 1 349 388
nextGet 0 349 388
addValueWhole 1 350 389
assign 1 352 395
iteratorGet 0 0 395
assign 1 352 398
hasNextGet 0 352 398
assign 1 352 400
nextGet 0 352 400
addValueWhole 1 353 401
return 1 355 407
assign 1 359 411
mergeSort 0 359 411
return 1 359 412
assign 1 363 416
new 0 363 416
sortValue 2 363 417
assign 1 367 431
copy 0 367 431
assign 1 367 434
lesser 1 367 439
assign 1 368 440
copy 0 368 440
assign 1 369 441
copy 0 369 441
assign 1 369 444
lesser 1 369 449
assign 1 370 450
get 1 370 450
assign 1 370 451
get 1 370 451
assign 1 370 452
lesser 1 370 452
assign 1 371 454
copy 0 371 454
incrementValue 0 369 456
assign 1 374 462
get 1 374 462
assign 1 375 463
get 1 375 463
put 2 375 464
put 2 376 465
incrementValue 0 367 466
assign 1 381 489
new 0 381 489
assign 1 382 490
new 0 382 490
assign 1 383 491
new 0 383 491
assign 1 384 492
lengthGet 0 384 492
assign 1 385 493
lengthGet 0 385 493
assign 1 386 496
lesser 1 386 501
assign 1 387 502
lesser 1 387 507
assign 1 387 508
lesser 1 387 513
assign 1 0 514
assign 1 0 517
assign 1 0 521
assign 1 388 524
get 1 388 524
assign 1 389 525
get 1 389 525
assign 1 390 526
lesser 1 390 526
incrementValue 0 391 528
put 2 392 529
incrementValue 0 394 532
put 2 395 533
assign 1 397 537
lesser 1 397 542
assign 1 398 543
get 1 398 543
incrementValue 0 399 544
put 2 400 545
assign 1 401 548
lesser 1 401 553
assign 1 402 554
get 1 402 554
incrementValue 0 403 555
put 2 404 556
incrementValue 0 406 560
assign 1 411 571
new 0 411 571
assign 1 411 572
mergeSort 2 411 572
return 1 411 573
assign 1 415 593
subtract 1 415 593
assign 1 416 594
new 0 416 594
assign 1 416 595
equals 1 416 600
assign 1 417 601
new 0 417 601
assign 1 417 602
create 1 417 602
return 1 417 603
assign 1 418 606
new 0 418 606
assign 1 418 607
equals 1 418 612
assign 1 419 613
new 0 419 613
assign 1 419 614
create 1 419 614
assign 1 420 615
new 0 420 615
assign 1 420 616
get 1 420 616
put 2 420 617
return 1 421 618
assign 1 423 621
new 0 423 621
assign 1 423 622
divide 1 423 622
assign 1 424 623
subtract 1 424 623
assign 1 425 624
add 1 425 624
assign 1 426 625
mergeSort 2 426 625
assign 1 427 626
mergeSort 2 427 626
assign 1 428 627
create 1 428 627
mergeIn 2 429 628
return 1 430 629
assign 1 435 637
new 0 435 637
assign 1 436 639
new 0 436 639
assign 1 436 640
new 1 436 640
throw 1 436 641
assign 1 442 649
greater 1 442 654
assign 1 443 655
multiply 1 443 655
assign 1 464 658
assign 1 467 662
lesser 1 467 667
incrementValue 0 478 670
setValue 1 480 676
assign 1 484 683
def 1 484 688
assign 1 485 691
hasNextGet 0 485 691
assign 1 486 693
nextGet 0 486 693
addValueWhole 1 486 694
assign 1 492 706
def 1 492 711
assign 1 493 712
iteratorGet 0 493 712
iterateAdd 1 493 713
assign 1 498 720
lesser 1 498 725
incrementValue 0 509 728
assign 1 512 731
copy 0 512 731
put 2 512 732
assign 1 517 740
def 1 517 745
assign 1 517 746
sameType 1 517 746
assign 1 0 748
assign 1 0 751
assign 1 0 755
addAll 1 518 758
addValueWhole 1 520 761
assign 1 526 772
new 0 526 772
assign 1 526 775
lesser 1 526 780
assign 1 527 781
get 1 527 781
assign 1 528 782
def 1 528 787
assign 1 528 788
equals 1 528 788
assign 1 0 790
assign 1 0 793
assign 1 0 797
return 1 529 800
incrementValue 0 526 802
return 1 532 808
assign 1 536 815
find 1 536 815
assign 1 536 816
def 1 536 821
assign 1 537 822
new 0 537 822
return 1 537 823
assign 1 539 825
new 0 539 825
return 1 539 826
assign 1 545 831
new 0 545 831
assign 1 545 832
sortedFind 2 545 832
return 1 545 833
assign 1 552 854
assign 1 553 855
new 0 553 855
assign 1 557 858
subtract 1 557 858
assign 1 557 859
new 0 557 859
assign 1 557 860
divide 1 557 860
assign 1 557 861
add 1 557 861
assign 1 558 862
get 1 558 862
assign 1 559 863
equals 1 559 863
return 1 560 865
assign 1 561 868
greater 1 561 868
assign 1 563 870
assign 1 564 873
lesser 1 564 873
assign 1 566 875
assign 1 569 879
def 1 569 884
assign 1 569 885
equals 1 569 890
assign 1 0 891
assign 1 0 894
assign 1 0 898
assign 1 570 902
get 1 570 902
assign 1 570 903
lesser 1 570 903
assign 1 0 905
assign 1 0 908
assign 1 0 912
return 1 571 915
return 1 573 917
assign 1 575 919
assign 1 576 920
new 0 576 920
return 1 577 922
return 1 0 927
return 1 0 930
assign 1 0 933
return 1 0 937
return 1 0 940
assign 1 0 943
return 1 0 947
return 1 0 950
assign 1 0 953
assign 1 0 957
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2061412556: return bem_classNameGet_0();
case 1574513169: return bem_capacityGetDirect_0();
case -1839217989: return bem_sortValue_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case 605755759: return bem_fieldNamesGet_0();
case -39706070: return bem_serializeContents_0();
case 2069196027: return bem_print_0();
case 1359777543: return bem_toAny_0();
case -196275245: return bem_anyrayGet_0();
case 874968344: return bem_once_0();
case 344752250: return bem_hashGet_0();
case 706233674: return bem_lastGet_0();
case -655379144: return bem_mergeSort_0();
case 27033645: return bem_sourceFileNameGet_0();
case 502031978: return bem_iteratorGet_0();
case 1480415803: return bem_serializationIteratorGet_0();
case 232383390: return bem_capacityGet_0();
case 1328707815: return bem_lengthGet_0();
case 325964466: return bem_echo_0();
case 1915585928: return bem_firstGet_0();
case -338374354: return bem_multiplierGet_0();
case -548777950: return bem_multiplierGetDirect_0();
case 1965613314: return bem_tagGet_0();
case 1578098134: return bem_toString_0();
case 522424394: return bem_arrayIteratorGet_0();
case 26417469: return bem_create_0();
case -1895764501: return bem_sizeGet_0();
case 962099177: return bem_fieldIteratorGet_0();
case -1652060912: return bem_lengthGetDirect_0();
case 1496905434: return bem_clear_0();
case -1878305271: return bem_many_0();
case 334767424: return bem_copy_0();
case -415497873: return bem_anyraySet_0();
case 2132890711: return bem_new_0();
case -329012078: return bem_isEmptyGet_0();
case 1974394768: return bem_sort_0();
case -799200084: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -620031996: return bem_iterateAdd_1(bevd_0);
case -1649799708: return bem_find_1(bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 185003454: return bem_sortedFind_1(bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case -1651052693: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case 419124452: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1187423490: return bem_addValueWhole_1(bevd_0);
case 1672635146: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1747400838: return bem_addAll_1(bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case 529040672: return bem_multiplierSetDirect_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1146121505: return bem_multiplierSet_1(bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 901006691: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1209792023: return bem_lengthSetDirect_1(bevd_0);
case -119064495: return bem_has_1(bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case 1772898739: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -1664368470: return bem_addValue_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case -1719370969: return bem_capacitySetDirect_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
case 339575761: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case 998669025: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1610974025: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 429414946: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1496249485: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 435015435: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -634128116: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 140119030: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
