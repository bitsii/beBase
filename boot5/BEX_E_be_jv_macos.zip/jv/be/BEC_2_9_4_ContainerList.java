package be;
/* IO:File: source/base/List.be */
public final class BEC_2_9_4_ContainerList extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_1 = (new BEC_2_4_3_MathInt(16));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_7 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_9 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_15 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_4_ContainerList bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bem_new_2(bevt_0_tmpany_phold, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_leni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
if (beva_capi == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 213 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 213 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 214 */
if (bevp_length == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 216 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 219 */ {
return this;
} /* Line: 220 */
} /* Line: 219 */

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = bece_BEC_2_9_4_ContainerList_bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sizeSet_1(BEC_2_4_3_MathInt beva_val) throws Throwable {
bem_lengthSet_1(beva_val);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 260 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_length.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_4;
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_5;
bevt_1_tmpany_phold = bevp_length.bem_subtract_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 293 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_7;
bevt_5_tmpany_phold = beva_posi.bem_add_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
} /* Line: 296 */

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 312 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 312 */
 else  /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 312 */ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 318 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_10;
bevl_j = beva_pos.bem_add_1(bevt_2_tmpany_phold);
bevl_i = beva_pos.bem_copy_0();
while (true)
 /* Line: 331 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_4_tmpany_phold = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 331 */
 else  /* Line: 331 */ {
break;
} /* Line: 331 */
} /* Line: 331 */
bem_put_2(bevl_fl, null);
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_11;
bevt_5_tmpany_phold = bevp_length.bem_subtract_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 337 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 351 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 351 */ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 351 */
 else  /* Line: 351 */ {
break;
} /* Line: 351 */
} /* Line: 351 */
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_copy_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_n = bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 359 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 359 */ {
bevt_1_tmpany_phold = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 359 */
 else  /* Line: 359 */ {
break;
} /* Line: 359 */
} /* Line: 359 */
return (BEC_2_9_4_ContainerList) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_create_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) throws Throwable {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_4_tmpany_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpany_phold = bevp_length.bem_add_1(bevt_4_tmpany_phold);
bevl_yi = (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_loop = bem_iteratorGet_0();
while (true)
 /* Line: 371 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-861082790);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 371 */ {
bevl_c = bevt_0_tmpany_loop.bemd_0(-1770055311);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 372 */
 else  /* Line: 371 */ {
break;
} /* Line: 371 */
} /* Line: 371 */
bevt_1_tmpany_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 374 */ {
bevt_6_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-861082790);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 374 */ {
bevl_c = bevt_1_tmpany_loop.bemd_0(-1770055311);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 375 */
 else  /* Line: 374 */ {
break;
} /* Line: 374 */
} /* Line: 374 */
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_tmpany_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_start.bem_copy_0();
while (true)
 /* Line: 389 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 389 */ {
bevl_c = bevl_i.bem_copy_0();
bevl_j = bevl_i.bem_copy_0();
while (true)
 /* Line: 391 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevt_3_tmpany_phold = bem_get_1(bevl_j);
bevt_4_tmpany_phold = bem_get_1(bevl_c);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(418713924, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 392 */ {
bevl_c = bevl_j.bem_copy_0();
} /* Line: 393 */
bevl_j.bevi_int++;
} /* Line: 391 */
 else  /* Line: 391 */ {
break;
} /* Line: 391 */
} /* Line: 391 */
bevl_hold = bem_get_1(bevl_i);
bevt_5_tmpany_phold = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_tmpany_phold);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 389 */
 else  /* Line: 389 */ {
break;
} /* Line: 389 */
} /* Line: 389 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 408 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 408 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 409 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 409 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 409 */
 else  /* Line: 409 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 409 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpany_phold = bevl_so.bemd_1(418713924, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 412 */ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 414 */
 else  /* Line: 415 */ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 417 */
} /* Line: 412 */
 else  /* Line: 409 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 422 */
 else  /* Line: 409 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 423 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 426 */
} /* Line: 409 */
} /* Line: 409 */
bevl_i.bevi_int++;
} /* Line: 428 */
 else  /* Line: 408 */ {
break;
} /* Line: 408 */
} /* Line: 408 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bem_mergeSort_2(bevt_1_tmpany_phold, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 438 */ {
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_2_tmpany_phold = bem_create_1(bevt_3_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevt_2_tmpany_phold;
} /* Line: 439 */
 else  /* Line: 438 */ {
bevt_5_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 440 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_8_tmpany_phold = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 443 */
 else  /* Line: 444 */ {
bevt_9_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpany_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 452 */
} /* Line: 438 */
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 458 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 464 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_list = java.util.Arrays.copyOf(this.bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 486 */
while (true)
 /* Line: 489 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 489 */ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 500 */
 else  /* Line: 489 */ {
break;
} /* Line: 489 */
} /* Line: 489 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 506 */ {
while (true)
 /* Line: 507 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-861082790);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 507 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(-1770055311);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 508 */
 else  /* Line: 507 */ {
break;
} /* Line: 507 */
} /* Line: 507 */
} /* Line: 507 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 514 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-1706743432);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 515 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 520 */ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 531 */
 else  /* Line: 532 */ {
bevt_1_tmpany_phold = bevp_length.bem_copy_0();
bem_put_2(bevt_1_tmpany_phold, beva_val);
} /* Line: 534 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 539 */ {
bevt_2_tmpany_phold = beva_val.bemd_1(-194482552, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 539 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 539 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 539 */
 else  /* Line: 539 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 539 */ {
bem_addAll_1(beva_val);
} /* Line: 540 */
 else  /* Line: 541 */ {
bem_addValueWhole_1(beva_val);
} /* Line: 542 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 548 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 548 */ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 550 */ {
bevt_3_tmpany_phold = beva_value.bemd_1(53407038, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 550 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 550 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 550 */
 else  /* Line: 550 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 550 */ {
return bevl_i;
} /* Line: 551 */
bevl_i.bevi_int++;
} /* Line: 548 */
 else  /* Line: 548 */ {
break;
} /* Line: 548 */
} /* Line: 548 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_find_1(beva_value);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 558 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 559 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_sortedFind_2(beva_value, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 578 */ {
bevt_3_tmpany_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_divide_1(bevt_4_tmpany_phold);
bevl_mid = bevt_2_tmpany_phold.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_tmpany_phold = beva_value.bemd_1(53407038, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 581 */ {
return bevl_mid;
} /* Line: 582 */
 else  /* Line: 581 */ {
bevt_6_tmpany_phold = beva_value.bemd_1(-1302857942, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 583 */ {
bevl_low = bevl_mid;
} /* Line: 585 */
 else  /* Line: 581 */ {
bevt_7_tmpany_phold = beva_value.bemd_1(418713924, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 586 */ {
bevl_high = bevl_mid;
} /* Line: 588 */
} /* Line: 581 */
} /* Line: 581 */
if (bevl_lastMid == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 591 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 591 */
 else  /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 591 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 592 */ {
bevt_11_tmpany_phold = bem_get_1(bevl_low);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(418713924, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 592 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 592 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 592 */
 else  /* Line: 592 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 592 */ {
return bevl_low;
} /* Line: 593 */
return null;
} /* Line: 595 */
bevl_lastMid = bevl_mid;
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 598 */ {
return null;
} /* Line: 599 */
} /* Line: 598 */
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public final BEC_2_4_3_MathInt bem_lengthGetDirect_0() throws Throwable {
return bevp_length;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_lengthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_4_3_MathInt bem_capacityGetDirect_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public final BEC_2_4_3_MathInt bem_multiplierGetDirect_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_multiplierSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {205, 205, 205, 205, 205, 209, 213, 213, 0, 213, 213, 0, 0, 214, 214, 214, 216, 216, 219, 219, 220, 244, 245, 246, 251, 255, 259, 259, 259, 260, 260, 262, 262, 272, 272, 276, 276, 280, 280, 284, 284, 284, 288, 288, 288, 288, 292, 292, 292, 293, 293, 293, 295, 295, 296, 296, 296, 312, 312, 312, 312, 312, 0, 0, 0, 324, 328, 328, 329, 329, 330, 330, 331, 331, 331, 332, 332, 333, 331, 335, 336, 336, 336, 337, 337, 339, 339, 343, 343, 347, 347, 351, 351, 351, 352, 351, 354, 358, 359, 359, 359, 360, 360, 359, 362, 365, 365, 367, 367, 370, 370, 370, 370, 371, 0, 371, 371, 372, 374, 0, 374, 374, 375, 377, 381, 381, 385, 385, 389, 389, 389, 390, 391, 391, 391, 392, 392, 392, 393, 391, 396, 397, 397, 398, 389, 403, 404, 405, 406, 407, 408, 408, 409, 409, 409, 409, 0, 0, 0, 410, 411, 412, 413, 414, 416, 417, 419, 419, 420, 421, 422, 423, 423, 424, 425, 426, 428, 433, 433, 433, 437, 438, 438, 438, 439, 439, 439, 440, 440, 440, 441, 441, 442, 442, 442, 443, 445, 445, 446, 447, 448, 449, 450, 451, 452, 457, 458, 458, 458, 464, 464, 465, 486, 489, 489, 500, 502, 506, 506, 507, 508, 508, 514, 514, 515, 515, 520, 520, 531, 534, 534, 539, 539, 539, 0, 0, 0, 540, 542, 548, 548, 548, 549, 550, 550, 550, 0, 0, 0, 551, 548, 554, 558, 558, 558, 559, 559, 561, 561, 567, 567, 567, 574, 575, 579, 579, 579, 579, 580, 581, 582, 583, 585, 586, 588, 591, 591, 591, 591, 0, 0, 0, 592, 592, 0, 0, 0, 593, 595, 597, 598, 599, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {58, 59, 60, 61, 62, 66, 77, 82, 83, 86, 91, 92, 95, 99, 100, 101, 103, 108, 109, 114, 115, 120, 121, 122, 126, 129, 137, 138, 143, 144, 145, 147, 148, 158, 159, 163, 164, 169, 170, 175, 176, 177, 183, 184, 185, 186, 196, 197, 202, 203, 204, 205, 207, 212, 213, 214, 215, 227, 228, 233, 234, 239, 240, 243, 247, 253, 268, 273, 274, 275, 276, 277, 278, 281, 286, 287, 288, 289, 290, 296, 297, 298, 299, 300, 301, 303, 304, 308, 309, 313, 314, 319, 322, 327, 328, 329, 335, 343, 344, 347, 352, 353, 354, 355, 361, 365, 366, 370, 371, 383, 384, 385, 386, 387, 387, 390, 392, 393, 399, 399, 402, 404, 405, 411, 415, 416, 420, 421, 435, 438, 443, 444, 445, 448, 453, 454, 455, 456, 458, 460, 466, 467, 468, 469, 470, 493, 494, 495, 496, 497, 500, 505, 506, 511, 512, 517, 518, 521, 525, 528, 529, 530, 532, 533, 536, 537, 541, 546, 547, 548, 549, 552, 557, 558, 559, 560, 564, 575, 576, 577, 597, 598, 599, 604, 605, 606, 607, 610, 611, 616, 617, 618, 619, 620, 621, 622, 625, 626, 627, 628, 629, 630, 631, 632, 633, 641, 643, 644, 645, 653, 658, 659, 662, 666, 671, 674, 680, 687, 692, 695, 697, 698, 710, 715, 716, 717, 724, 729, 732, 735, 736, 744, 749, 750, 752, 755, 759, 762, 765, 776, 779, 784, 785, 786, 791, 792, 794, 797, 801, 804, 806, 812, 819, 820, 825, 826, 827, 829, 830, 835, 836, 837, 858, 859, 862, 863, 864, 865, 866, 867, 869, 872, 874, 877, 879, 883, 888, 889, 894, 895, 898, 902, 906, 907, 909, 912, 916, 919, 921, 923, 924, 926, 931, 934, 937, 941, 944, 947, 951, 954, 957, 961};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 205 58
new 0 205 58
assign 1 205 59
once 0 205 59
assign 1 205 60
new 0 205 60
assign 1 205 61
once 0 205 61
new 2 205 62
new 2 209 66
assign 1 213 77
undef 1 213 82
assign 1 0 83
assign 1 213 86
undef 1 213 91
assign 1 0 92
assign 1 0 95
assign 1 214 99
new 0 214 99
assign 1 214 100
new 1 214 100
throw 1 214 101
assign 1 216 103
def 1 216 108
assign 1 219 109
equals 1 219 114
return 1 220 115
assign 1 244 120
copy 0 244 120
assign 1 245 121
copy 0 245 121
assign 1 246 122
new 0 246 122
return 1 251 126
lengthSet 1 255 129
assign 1 259 137
new 0 259 137
assign 1 259 138
equals 1 259 143
assign 1 260 144
new 0 260 144
return 1 260 145
assign 1 262 147
new 0 262 147
return 1 262 148
assign 1 272 158
toString 0 272 158
return 1 272 159
assign 1 276 163
new 1 276 163
new 1 276 164
assign 1 280 169
iteratorGet 0 280 169
return 1 280 170
assign 1 284 175
new 0 284 175
assign 1 284 176
get 1 284 176
return 1 284 177
assign 1 288 183
new 0 288 183
assign 1 288 184
subtract 1 288 184
assign 1 288 185
get 1 288 185
return 1 288 186
assign 1 292 196
new 0 292 196
assign 1 292 197
lesser 1 292 202
assign 1 293 203
new 0 293 203
assign 1 293 204
new 1 293 204
throw 1 293 205
assign 1 295 207
greaterEquals 1 295 212
assign 1 296 213
new 0 296 213
assign 1 296 214
add 1 296 214
lengthSet 1 296 215
assign 1 312 227
new 0 312 227
assign 1 312 228
greaterEquals 1 312 233
assign 1 312 234
lesser 1 312 239
assign 1 0 240
assign 1 0 243
assign 1 0 247
return 1 324 253
assign 1 328 268
lesser 1 328 273
assign 1 329 274
new 0 329 274
assign 1 329 275
subtract 1 329 275
assign 1 330 276
new 0 330 276
assign 1 330 277
add 1 330 277
assign 1 331 278
copy 0 331 278
assign 1 331 281
lesser 1 331 286
assign 1 332 287
get 1 332 287
put 2 332 288
incrementValue 0 333 289
incrementValue 0 331 290
put 2 335 296
assign 1 336 297
new 0 336 297
assign 1 336 298
subtract 1 336 298
lengthSet 1 336 299
assign 1 337 300
new 0 337 300
return 1 337 301
assign 1 339 303
new 0 339 303
return 1 339 304
assign 1 343 308
new 1 343 308
return 1 343 309
assign 1 347 313
new 1 347 313
return 1 347 314
assign 1 351 319
new 0 351 319
assign 1 351 322
lesser 1 351 327
put 2 352 328
incrementValue 0 351 329
assign 1 354 335
new 0 354 335
assign 1 358 343
create 0 358 343
assign 1 359 344
new 0 359 344
assign 1 359 347
lesser 1 359 352
assign 1 360 353
get 1 360 353
put 2 360 354
incrementValue 0 359 355
return 1 362 361
assign 1 365 365
new 1 365 365
return 1 365 366
assign 1 367 370
new 1 367 370
return 1 367 371
assign 1 370 383
new 0 370 383
assign 1 370 384
lengthGet 0 370 384
assign 1 370 385
add 1 370 385
assign 1 370 386
new 2 370 386
assign 1 371 387
iteratorGet 0 0 387
assign 1 371 390
hasNextGet 0 371 390
assign 1 371 392
nextGet 0 371 392
addValueWhole 1 372 393
assign 1 374 399
iteratorGet 0 0 399
assign 1 374 402
hasNextGet 0 374 402
assign 1 374 404
nextGet 0 374 404
addValueWhole 1 375 405
return 1 377 411
assign 1 381 415
mergeSort 0 381 415
return 1 381 416
assign 1 385 420
new 0 385 420
sortValue 2 385 421
assign 1 389 435
copy 0 389 435
assign 1 389 438
lesser 1 389 443
assign 1 390 444
copy 0 390 444
assign 1 391 445
copy 0 391 445
assign 1 391 448
lesser 1 391 453
assign 1 392 454
get 1 392 454
assign 1 392 455
get 1 392 455
assign 1 392 456
lesser 1 392 456
assign 1 393 458
copy 0 393 458
incrementValue 0 391 460
assign 1 396 466
get 1 396 466
assign 1 397 467
get 1 397 467
put 2 397 468
put 2 398 469
incrementValue 0 389 470
assign 1 403 493
new 0 403 493
assign 1 404 494
new 0 404 494
assign 1 405 495
new 0 405 495
assign 1 406 496
lengthGet 0 406 496
assign 1 407 497
lengthGet 0 407 497
assign 1 408 500
lesser 1 408 505
assign 1 409 506
lesser 1 409 511
assign 1 409 512
lesser 1 409 517
assign 1 0 518
assign 1 0 521
assign 1 0 525
assign 1 410 528
get 1 410 528
assign 1 411 529
get 1 411 529
assign 1 412 530
lesser 1 412 530
incrementValue 0 413 532
put 2 414 533
incrementValue 0 416 536
put 2 417 537
assign 1 419 541
lesser 1 419 546
assign 1 420 547
get 1 420 547
incrementValue 0 421 548
put 2 422 549
assign 1 423 552
lesser 1 423 557
assign 1 424 558
get 1 424 558
incrementValue 0 425 559
put 2 426 560
incrementValue 0 428 564
assign 1 433 575
new 0 433 575
assign 1 433 576
mergeSort 2 433 576
return 1 433 577
assign 1 437 597
subtract 1 437 597
assign 1 438 598
new 0 438 598
assign 1 438 599
equals 1 438 604
assign 1 439 605
new 0 439 605
assign 1 439 606
create 1 439 606
return 1 439 607
assign 1 440 610
new 0 440 610
assign 1 440 611
equals 1 440 616
assign 1 441 617
new 0 441 617
assign 1 441 618
create 1 441 618
assign 1 442 619
new 0 442 619
assign 1 442 620
get 1 442 620
put 2 442 621
return 1 443 622
assign 1 445 625
new 0 445 625
assign 1 445 626
divide 1 445 626
assign 1 446 627
subtract 1 446 627
assign 1 447 628
add 1 447 628
assign 1 448 629
mergeSort 2 448 629
assign 1 449 630
mergeSort 2 449 630
assign 1 450 631
create 1 450 631
mergeIn 2 451 632
return 1 452 633
assign 1 457 641
new 0 457 641
assign 1 458 643
new 0 458 643
assign 1 458 644
new 1 458 644
throw 1 458 645
assign 1 464 653
greater 1 464 658
assign 1 465 659
multiply 1 465 659
assign 1 486 662
assign 1 489 666
lesser 1 489 671
incrementValue 0 500 674
setValue 1 502 680
assign 1 506 687
def 1 506 692
assign 1 507 695
hasNextGet 0 507 695
assign 1 508 697
nextGet 0 508 697
addValueWhole 1 508 698
assign 1 514 710
def 1 514 715
assign 1 515 716
iteratorGet 0 515 716
iterateAdd 1 515 717
assign 1 520 724
lesser 1 520 729
incrementValue 0 531 732
assign 1 534 735
copy 0 534 735
put 2 534 736
assign 1 539 744
def 1 539 749
assign 1 539 750
sameType 1 539 750
assign 1 0 752
assign 1 0 755
assign 1 0 759
addAll 1 540 762
addValueWhole 1 542 765
assign 1 548 776
new 0 548 776
assign 1 548 779
lesser 1 548 784
assign 1 549 785
get 1 549 785
assign 1 550 786
def 1 550 791
assign 1 550 792
equals 1 550 792
assign 1 0 794
assign 1 0 797
assign 1 0 801
return 1 551 804
incrementValue 0 548 806
return 1 554 812
assign 1 558 819
find 1 558 819
assign 1 558 820
def 1 558 825
assign 1 559 826
new 0 559 826
return 1 559 827
assign 1 561 829
new 0 561 829
return 1 561 830
assign 1 567 835
new 0 567 835
assign 1 567 836
sortedFind 2 567 836
return 1 567 837
assign 1 574 858
assign 1 575 859
new 0 575 859
assign 1 579 862
subtract 1 579 862
assign 1 579 863
new 0 579 863
assign 1 579 864
divide 1 579 864
assign 1 579 865
add 1 579 865
assign 1 580 866
get 1 580 866
assign 1 581 867
equals 1 581 867
return 1 582 869
assign 1 583 872
greater 1 583 872
assign 1 585 874
assign 1 586 877
lesser 1 586 877
assign 1 588 879
assign 1 591 883
def 1 591 888
assign 1 591 889
equals 1 591 894
assign 1 0 895
assign 1 0 898
assign 1 0 902
assign 1 592 906
get 1 592 906
assign 1 592 907
lesser 1 592 907
assign 1 0 909
assign 1 0 912
assign 1 0 916
return 1 593 919
return 1 595 921
assign 1 597 923
assign 1 598 924
new 0 598 924
return 1 599 926
return 1 0 931
return 1 0 934
assign 1 0 937
return 1 0 941
return 1 0 944
assign 1 0 947
return 1 0 951
return 1 0 954
assign 1 0 957
assign 1 0 961
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1894090923: return bem_toString_0();
case -808123537: return bem_hashGet_0();
case -1706743432: return bem_iteratorGet_0();
case -1602615308: return bem_fieldIteratorGet_0();
case 1606613844: return bem_echo_0();
case 1377047095: return bem_serializeToString_0();
case -789283429: return bem_capacityGetDirect_0();
case -1442653865: return bem_serializationIteratorGet_0();
case 2054492918: return bem_anyraySet_0();
case 299120428: return bem_lastGet_0();
case 2009810245: return bem_lengthGet_0();
case -295553573: return bem_new_0();
case 587979444: return bem_sort_0();
case 48892022: return bem_multiplierGetDirect_0();
case -859348755: return bem_anyrayGet_0();
case 867070422: return bem_mergeSort_0();
case -1460543860: return bem_fieldNamesGet_0();
case -493975186: return bem_create_0();
case -1118569296: return bem_multiplierGet_0();
case -41381797: return bem_copy_0();
case -802767414: return bem_deserializeClassNameGet_0();
case 853279026: return bem_sizeGet_0();
case -1396413274: return bem_classNameGet_0();
case 1485931867: return bem_sortValue_0();
case 899896295: return bem_print_0();
case -2071452709: return bem_serializeContents_0();
case 85669346: return bem_once_0();
case -2077175513: return bem_isEmptyGet_0();
case 874569701: return bem_toAny_0();
case -577630184: return bem_capacityGet_0();
case -1794506213: return bem_many_0();
case 1686776750: return bem_lengthGetDirect_0();
case -1333837278: return bem_tagGet_0();
case 1523861211: return bem_sourceFileNameGet_0();
case -287436106: return bem_arrayIteratorGet_0();
case -302359707: return bem_firstGet_0();
case 1893892468: return bem_clear_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1450157142: return bem_sizeSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1915172172: return bem_addValue_1(bevd_0);
case -1140712704: return bem_multiplierSetDirect_1(bevd_0);
case 298669757: return bem_capacitySetDirect_1(bevd_0);
case 1328285078: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -920243169: return bem_sameObject_1(bevd_0);
case -2123613587: return bem_notEquals_1(bevd_0);
case -125779744: return bem_addValueWhole_1(bevd_0);
case 1213137777: return bem_undef_1(bevd_0);
case 53407038: return bem_equals_1(bevd_0);
case -308225636: return bem_sortedFind_1(bevd_0);
case -134976227: return bem_find_1(bevd_0);
case 251588443: return bem_otherType_1(bevd_0);
case -477512600: return bem_lengthSetDirect_1(bevd_0);
case 1967125712: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -467808258: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -666596898: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -600776341: return bem_has_1(bevd_0);
case 966131902: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 847095864: return bem_iterateAdd_1(bevd_0);
case 1346697926: return bem_addAll_1(bevd_0);
case 1829433968: return bem_otherClass_1(bevd_0);
case -1152576261: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case -2090317749: return bem_multiplierSet_1(bevd_0);
case -319164445: return bem_undefined_1(bevd_0);
case 391192402: return bem_copyTo_1(bevd_0);
case -194482552: return bem_sameType_1(bevd_0);
case 652115224: return bem_def_1(bevd_0);
case 1380048260: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1989300932: return bem_sameClass_1(bevd_0);
case 694682640: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 284248916: return bem_defined_1(bevd_0);
case -794252146: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -374420930: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -2011612172: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1457011613: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1221539498: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 981994417: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1865862746: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1057911785: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1126000923: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1736065910: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1043246902: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -620653407: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1158884482: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -735547174: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1874085610: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1766660250: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
