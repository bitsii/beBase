package be;
/* IO:File: source/base/List.be */
public final class BEC_2_9_4_ContainerList extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
public static BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_4_ContainerList bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(16));
bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_9_SystemException bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_leni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
if (beva_capi == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_ta_ph);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 220*/
if (bevp_length == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 222*/ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 225*/ {
return this;
} /* Line: 226*/
} /* Line: 225*/

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = (new BEC_2_4_3_MathInt(2));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sizeSet_1(BEC_2_4_3_MathInt beva_val) throws Throwable {
bem_lengthSet_1(beva_val);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 265*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 266*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_length.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevp_length.bem_subtract_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_9_SystemException bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 294*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_ta_ph);
throw new be.BECS_ThrowBack(bevt_2_ta_ph);
} /* Line: 295*/
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 297*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_posi.bem_add_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
} /* Line: 298*/

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 314*/ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 314*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 314*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 314*/
 else /* Line: 314*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 314*/ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 320*/
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_fl = bevp_length.bem_subtract_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_j = beva_pos.bem_add_1(bevt_2_ta_ph);
bevl_i = beva_pos.bem_copy_0();
while (true)
/* Line: 333*/ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_4_ta_ph = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_ta_ph);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 333*/
 else /* Line: 333*/ {
break;
} /* Line: 333*/
} /* Line: 333*/
bem_put_2(bevl_fl, null);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = bevp_length.bem_subtract_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 339*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 353*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 353*/ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 353*/
 else /* Line: 353*/ {
break;
} /* Line: 353*/
} /* Line: 353*/
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_copy_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_n = bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 361*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 361*/ {
bevt_1_ta_ph = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_ta_ph);
bevl_i.bevi_int++;
} /* Line: 361*/
 else /* Line: 361*/ {
break;
} /* Line: 361*/
} /* Line: 361*/
return (BEC_2_9_4_ContainerList) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_create_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) throws Throwable {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = beva_xi.bem_lengthGet_0();
bevt_3_ta_ph = bevp_length.bem_add_1(bevt_4_ta_ph);
bevl_yi = (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_loop = bem_iteratorGet_0();
while (true)
/* Line: 373*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(1031776864);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 373*/ {
bevl_c = bevt_0_ta_loop.bemd_0(-430730425);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 374*/
 else /* Line: 373*/ {
break;
} /* Line: 373*/
} /* Line: 373*/
bevt_1_ta_loop = beva_xi.bem_iteratorGet_0();
while (true)
/* Line: 376*/ {
bevt_6_ta_ph = bevt_1_ta_loop.bemd_0(1031776864);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 376*/ {
bevl_c = bevt_1_ta_loop.bemd_0(-430730425);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 377*/
 else /* Line: 376*/ {
break;
} /* Line: 376*/
} /* Line: 376*/
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_ta_ph, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_start.bem_copy_0();
while (true)
/* Line: 391*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 391*/ {
bevl_c = bevl_i.bem_copy_0();
bevl_j = bevl_i.bem_copy_0();
while (true)
/* Line: 393*/ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 393*/ {
bevt_3_ta_ph = bem_get_1(bevl_j);
bevt_4_ta_ph = bem_get_1(bevl_c);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(-2086891498, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 394*/ {
bevl_c = bevl_j.bem_copy_0();
} /* Line: 395*/
bevl_j.bevi_int++;
} /* Line: 393*/
 else /* Line: 393*/ {
break;
} /* Line: 393*/
} /* Line: 393*/
bevl_hold = bem_get_1(bevl_i);
bevt_5_ta_ph = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_ta_ph);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 391*/
 else /* Line: 391*/ {
break;
} /* Line: 391*/
} /* Line: 391*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
/* Line: 410*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 410*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 411*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 411*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 411*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 411*/
 else /* Line: 411*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 411*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_ta_ph = bevl_so.bemd_1(-2086891498, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 414*/ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 416*/
 else /* Line: 417*/ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 419*/
} /* Line: 414*/
 else /* Line: 411*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 421*/ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 424*/
 else /* Line: 411*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 425*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 428*/
} /* Line: 411*/
} /* Line: 411*/
bevl_i.bevi_int++;
} /* Line: 430*/
 else /* Line: 410*/ {
break;
} /* Line: 410*/
} /* Line: 410*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_mergeSort_2(bevt_1_ta_ph, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_mlen.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_2_ta_ph = bem_create_1(bevt_3_ta_ph);
return (BEC_2_9_4_ContainerList) bevt_2_ta_ph;
} /* Line: 441*/
 else /* Line: 440*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_mlen.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 442*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_ta_ph, bevt_8_ta_ph);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 445*/
 else /* Line: 446*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_ta_ph);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 454*/
} /* Line: 440*/
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 459*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 460*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 466*/ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_list = java.util.Arrays.copyOf(this.bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 488*/
while (true)
/* Line: 491*/ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 491*/ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 502*/
 else /* Line: 491*/ {
break;
} /* Line: 491*/
} /* Line: 491*/
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 508*/ {
while (true)
/* Line: 509*/ {
bevt_1_ta_ph = beva_val.bemd_0(1031776864);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 509*/ {
bevt_2_ta_ph = beva_val.bemd_0(-430730425);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 510*/
 else /* Line: 509*/ {
break;
} /* Line: 509*/
} /* Line: 509*/
} /* Line: 509*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 516*/ {
bevt_1_ta_ph = beva_val.bemd_0(1676715436);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 517*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 522*/ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 533*/
 else /* Line: 534*/ {
bevt_1_ta_ph = bevp_length.bem_copy_0();
bem_put_2(bevt_1_ta_ph, beva_val);
} /* Line: 536*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_val == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 541*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_val, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 541*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 541*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 541*/
 else /* Line: 541*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 541*/ {
bem_addAll_1(beva_val);
} /* Line: 542*/
 else /* Line: 543*/ {
bem_addValueWhole_1(beva_val);
} /* Line: 544*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 550*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 550*/ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 552*/ {
bevt_3_ta_ph = beva_value.bemd_1(1306600423, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 552*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 552*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 552*/
 else /* Line: 552*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 552*/ {
return bevl_i;
} /* Line: 553*/
bevl_i.bevi_int++;
} /* Line: 550*/
 else /* Line: 550*/ {
break;
} /* Line: 550*/
} /* Line: 550*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_find_1(beva_value);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 560*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 561*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_sortedFind_2(beva_value, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 580*/ {
bevt_3_ta_ph = bevl_high.bem_subtract_1(bevl_low);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = bevt_3_ta_ph.bem_divide_1(bevt_4_ta_ph);
bevl_mid = bevt_2_ta_ph.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_ta_ph = beva_value.bemd_1(1306600423, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 583*/ {
return bevl_mid;
} /* Line: 584*/
 else /* Line: 583*/ {
bevt_6_ta_ph = beva_value.bemd_1(1089170059, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 585*/ {
bevl_low = bevl_mid;
} /* Line: 587*/
 else /* Line: 583*/ {
bevt_7_ta_ph = beva_value.bemd_1(-2086891498, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 588*/ {
bevl_high = bevl_mid;
} /* Line: 590*/
} /* Line: 583*/
} /* Line: 583*/
if (bevl_lastMid == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 593*/ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 593*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 593*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 593*/
 else /* Line: 593*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 593*/ {
if (beva_returnNoMatch.bevi_bool)/* Line: 594*/ {
bevt_11_ta_ph = bem_get_1(bevl_low);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(-2086891498, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 594*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 594*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 594*/
 else /* Line: 594*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 594*/ {
return bevl_low;
} /* Line: 595*/
return null;
} /* Line: 597*/
bevl_lastMid = bevl_mid;
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_12_ta_ph.bevi_bool)/* Line: 600*/ {
return null;
} /* Line: 601*/
} /* Line: 600*/
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {211, 211, 211, 215, 219, 219, 0, 219, 219, 0, 0, 220, 220, 220, 222, 222, 225, 225, 226, 250, 251, 252, 257, 261, 265, 265, 265, 266, 266, 268, 268, 278, 278, 282, 282, 286, 286, 286, 290, 290, 290, 290, 294, 294, 294, 295, 295, 295, 297, 297, 298, 298, 298, 314, 314, 314, 314, 314, 0, 0, 0, 326, 330, 330, 331, 331, 332, 332, 333, 333, 333, 334, 334, 335, 333, 337, 338, 338, 338, 339, 339, 341, 341, 345, 345, 349, 349, 353, 353, 353, 354, 353, 356, 360, 361, 361, 361, 362, 362, 361, 364, 367, 367, 369, 369, 372, 372, 372, 372, 373, 0, 373, 373, 374, 376, 0, 376, 376, 377, 379, 383, 383, 387, 387, 391, 391, 391, 392, 393, 393, 393, 394, 394, 394, 395, 393, 398, 399, 399, 400, 391, 405, 406, 407, 408, 409, 410, 410, 411, 411, 411, 411, 0, 0, 0, 412, 413, 414, 415, 416, 418, 419, 421, 421, 422, 423, 424, 425, 425, 426, 427, 428, 430, 435, 435, 435, 439, 440, 440, 440, 441, 441, 441, 442, 442, 442, 443, 443, 444, 444, 444, 445, 447, 447, 448, 449, 450, 451, 452, 453, 454, 459, 460, 460, 460, 466, 466, 467, 488, 491, 491, 502, 504, 508, 508, 509, 510, 510, 516, 516, 517, 517, 522, 522, 533, 536, 536, 541, 541, 541, 541, 0, 0, 0, 542, 544, 550, 550, 550, 551, 552, 552, 552, 0, 0, 0, 553, 550, 556, 560, 560, 560, 561, 561, 563, 563, 569, 569, 569, 576, 577, 581, 581, 581, 581, 582, 583, 584, 585, 587, 588, 590, 593, 593, 593, 593, 0, 0, 0, 594, 594, 0, 0, 0, 595, 597, 599, 600, 601, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 42, 46, 57, 62, 63, 66, 71, 72, 75, 79, 80, 81, 83, 88, 89, 94, 95, 100, 101, 102, 106, 109, 117, 118, 123, 124, 125, 127, 128, 138, 139, 143, 144, 150, 151, 152, 158, 159, 160, 161, 171, 172, 177, 178, 179, 180, 182, 187, 188, 189, 190, 202, 203, 208, 209, 214, 215, 218, 222, 228, 243, 248, 249, 250, 251, 252, 253, 256, 261, 262, 263, 264, 265, 271, 272, 273, 274, 275, 276, 278, 279, 283, 284, 288, 289, 294, 297, 302, 303, 304, 310, 318, 319, 322, 327, 328, 329, 330, 336, 340, 341, 345, 346, 358, 359, 360, 361, 362, 362, 365, 367, 368, 374, 374, 377, 379, 380, 386, 390, 391, 395, 396, 410, 413, 418, 419, 420, 423, 428, 429, 430, 431, 433, 435, 441, 442, 443, 444, 445, 468, 469, 470, 471, 472, 475, 480, 481, 486, 487, 492, 493, 496, 500, 503, 504, 505, 507, 508, 511, 512, 516, 521, 522, 523, 524, 527, 532, 533, 534, 535, 539, 550, 551, 552, 572, 573, 574, 579, 580, 581, 582, 585, 586, 591, 592, 593, 594, 595, 596, 597, 600, 601, 602, 603, 604, 605, 606, 607, 608, 616, 618, 619, 620, 628, 633, 634, 637, 641, 646, 649, 655, 662, 667, 670, 672, 673, 685, 690, 691, 692, 699, 704, 707, 710, 711, 720, 725, 726, 727, 729, 732, 736, 739, 742, 753, 756, 761, 762, 763, 768, 769, 771, 774, 778, 781, 783, 789, 796, 797, 802, 803, 804, 806, 807, 812, 813, 814, 835, 836, 839, 840, 841, 842, 843, 844, 846, 849, 851, 854, 856, 860, 865, 866, 871, 872, 875, 879, 883, 884, 886, 889, 893, 896, 898, 900, 901, 903, 908, 911, 914, 917};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 211 40
new 0 211 40
assign 1 211 41
new 0 211 41
new 2 211 42
new 2 215 46
assign 1 219 57
undef 1 219 62
assign 1 0 63
assign 1 219 66
undef 1 219 71
assign 1 0 72
assign 1 0 75
assign 1 220 79
new 0 220 79
assign 1 220 80
new 1 220 80
throw 1 220 81
assign 1 222 83
def 1 222 88
assign 1 225 89
equals 1 225 94
return 1 226 95
assign 1 250 100
copy 0 250 100
assign 1 251 101
copy 0 251 101
assign 1 252 102
new 0 252 102
return 1 257 106
lengthSet 1 261 109
assign 1 265 117
new 0 265 117
assign 1 265 118
equals 1 265 123
assign 1 266 124
new 0 266 124
return 1 266 125
assign 1 268 127
new 0 268 127
return 1 268 128
assign 1 278 138
toString 0 278 138
return 1 278 139
assign 1 282 143
new 1 282 143
new 1 282 144
assign 1 286 150
new 0 286 150
assign 1 286 151
get 1 286 151
return 1 286 152
assign 1 290 158
new 0 290 158
assign 1 290 159
subtract 1 290 159
assign 1 290 160
get 1 290 160
return 1 290 161
assign 1 294 171
new 0 294 171
assign 1 294 172
lesser 1 294 177
assign 1 295 178
new 0 295 178
assign 1 295 179
new 1 295 179
throw 1 295 180
assign 1 297 182
greaterEquals 1 297 187
assign 1 298 188
new 0 298 188
assign 1 298 189
add 1 298 189
lengthSet 1 298 190
assign 1 314 202
new 0 314 202
assign 1 314 203
greaterEquals 1 314 208
assign 1 314 209
lesser 1 314 214
assign 1 0 215
assign 1 0 218
assign 1 0 222
return 1 326 228
assign 1 330 243
lesser 1 330 248
assign 1 331 249
new 0 331 249
assign 1 331 250
subtract 1 331 250
assign 1 332 251
new 0 332 251
assign 1 332 252
add 1 332 252
assign 1 333 253
copy 0 333 253
assign 1 333 256
lesser 1 333 261
assign 1 334 262
get 1 334 262
put 2 334 263
incrementValue 0 335 264
incrementValue 0 333 265
put 2 337 271
assign 1 338 272
new 0 338 272
assign 1 338 273
subtract 1 338 273
lengthSet 1 338 274
assign 1 339 275
new 0 339 275
return 1 339 276
assign 1 341 278
new 0 341 278
return 1 341 279
assign 1 345 283
new 1 345 283
return 1 345 284
assign 1 349 288
new 1 349 288
return 1 349 289
assign 1 353 294
new 0 353 294
assign 1 353 297
lesser 1 353 302
put 2 354 303
incrementValue 0 353 304
assign 1 356 310
new 0 356 310
assign 1 360 318
create 0 360 318
assign 1 361 319
new 0 361 319
assign 1 361 322
lesser 1 361 327
assign 1 362 328
get 1 362 328
put 2 362 329
incrementValue 0 361 330
return 1 364 336
assign 1 367 340
new 1 367 340
return 1 367 341
assign 1 369 345
new 1 369 345
return 1 369 346
assign 1 372 358
new 0 372 358
assign 1 372 359
lengthGet 0 372 359
assign 1 372 360
add 1 372 360
assign 1 372 361
new 2 372 361
assign 1 373 362
iteratorGet 0 0 362
assign 1 373 365
hasNextGet 0 373 365
assign 1 373 367
nextGet 0 373 367
addValueWhole 1 374 368
assign 1 376 374
iteratorGet 0 0 374
assign 1 376 377
hasNextGet 0 376 377
assign 1 376 379
nextGet 0 376 379
addValueWhole 1 377 380
return 1 379 386
assign 1 383 390
mergeSort 0 383 390
return 1 383 391
assign 1 387 395
new 0 387 395
sortValue 2 387 396
assign 1 391 410
copy 0 391 410
assign 1 391 413
lesser 1 391 418
assign 1 392 419
copy 0 392 419
assign 1 393 420
copy 0 393 420
assign 1 393 423
lesser 1 393 428
assign 1 394 429
get 1 394 429
assign 1 394 430
get 1 394 430
assign 1 394 431
lesser 1 394 431
assign 1 395 433
copy 0 395 433
incrementValue 0 393 435
assign 1 398 441
get 1 398 441
assign 1 399 442
get 1 399 442
put 2 399 443
put 2 400 444
incrementValue 0 391 445
assign 1 405 468
new 0 405 468
assign 1 406 469
new 0 406 469
assign 1 407 470
new 0 407 470
assign 1 408 471
lengthGet 0 408 471
assign 1 409 472
lengthGet 0 409 472
assign 1 410 475
lesser 1 410 480
assign 1 411 481
lesser 1 411 486
assign 1 411 487
lesser 1 411 492
assign 1 0 493
assign 1 0 496
assign 1 0 500
assign 1 412 503
get 1 412 503
assign 1 413 504
get 1 413 504
assign 1 414 505
lesser 1 414 505
incrementValue 0 415 507
put 2 416 508
incrementValue 0 418 511
put 2 419 512
assign 1 421 516
lesser 1 421 521
assign 1 422 522
get 1 422 522
incrementValue 0 423 523
put 2 424 524
assign 1 425 527
lesser 1 425 532
assign 1 426 533
get 1 426 533
incrementValue 0 427 534
put 2 428 535
incrementValue 0 430 539
assign 1 435 550
new 0 435 550
assign 1 435 551
mergeSort 2 435 551
return 1 435 552
assign 1 439 572
subtract 1 439 572
assign 1 440 573
new 0 440 573
assign 1 440 574
equals 1 440 579
assign 1 441 580
new 0 441 580
assign 1 441 581
create 1 441 581
return 1 441 582
assign 1 442 585
new 0 442 585
assign 1 442 586
equals 1 442 591
assign 1 443 592
new 0 443 592
assign 1 443 593
create 1 443 593
assign 1 444 594
new 0 444 594
assign 1 444 595
get 1 444 595
put 2 444 596
return 1 445 597
assign 1 447 600
new 0 447 600
assign 1 447 601
divide 1 447 601
assign 1 448 602
subtract 1 448 602
assign 1 449 603
add 1 449 603
assign 1 450 604
mergeSort 2 450 604
assign 1 451 605
mergeSort 2 451 605
assign 1 452 606
create 1 452 606
mergeIn 2 453 607
return 1 454 608
assign 1 459 616
new 0 459 616
assign 1 460 618
new 0 460 618
assign 1 460 619
new 1 460 619
throw 1 460 620
assign 1 466 628
greater 1 466 633
assign 1 467 634
multiply 1 467 634
assign 1 488 637
assign 1 491 641
lesser 1 491 646
incrementValue 0 502 649
setValue 1 504 655
assign 1 508 662
def 1 508 667
assign 1 509 670
hasNextGet 0 509 670
assign 1 510 672
nextGet 0 510 672
addValueWhole 1 510 673
assign 1 516 685
def 1 516 690
assign 1 517 691
iteratorGet 0 517 691
iterateAdd 1 517 692
assign 1 522 699
lesser 1 522 704
incrementValue 0 533 707
assign 1 536 710
copy 0 536 710
put 2 536 711
assign 1 541 720
def 1 541 725
assign 1 541 726
new 0 541 726
assign 1 541 727
sameType 2 541 727
assign 1 0 729
assign 1 0 732
assign 1 0 736
addAll 1 542 739
addValueWhole 1 544 742
assign 1 550 753
new 0 550 753
assign 1 550 756
lesser 1 550 761
assign 1 551 762
get 1 551 762
assign 1 552 763
def 1 552 768
assign 1 552 769
equals 1 552 769
assign 1 0 771
assign 1 0 774
assign 1 0 778
return 1 553 781
incrementValue 0 550 783
return 1 556 789
assign 1 560 796
find 1 560 796
assign 1 560 797
def 1 560 802
assign 1 561 803
new 0 561 803
return 1 561 804
assign 1 563 806
new 0 563 806
return 1 563 807
assign 1 569 812
new 0 569 812
assign 1 569 813
sortedFind 2 569 813
return 1 569 814
assign 1 576 835
assign 1 577 836
new 0 577 836
assign 1 581 839
subtract 1 581 839
assign 1 581 840
new 0 581 840
assign 1 581 841
divide 1 581 841
assign 1 581 842
add 1 581 842
assign 1 582 843
get 1 582 843
assign 1 583 844
equals 1 583 844
return 1 584 846
assign 1 585 849
greater 1 585 849
assign 1 587 851
assign 1 588 854
lesser 1 588 854
assign 1 590 856
assign 1 593 860
def 1 593 865
assign 1 593 866
equals 1 593 871
assign 1 0 872
assign 1 0 875
assign 1 0 879
assign 1 594 883
get 1 594 883
assign 1 594 884
lesser 1 594 884
assign 1 0 886
assign 1 0 889
assign 1 0 893
return 1 595 896
return 1 597 898
assign 1 599 900
assign 1 600 901
new 0 600 901
return 1 601 903
return 1 0 908
return 1 0 911
return 1 0 914
assign 1 0 917
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1478028338: return bem_multiplierGet_0();
case 270679232: return bem_anyrayGet_0();
case 1861855516: return bem_copy_0();
case 1676715436: return bem_iteratorGet_0();
case -2042483961: return bem_toString_0();
case 1155283144: return bem_sort_0();
case -1757033570: return bem_print_0();
case -1717921599: return bem_serializeToString_0();
case 728971519: return bem_arrayIteratorGet_0();
case 1019671148: return bem_firstGet_0();
case -1425898375: return bem_new_0();
case 436863164: return bem_hashGet_0();
case 1842712020: return bem_sortValue_0();
case -1338263544: return bem_lastGet_0();
case -286965052: return bem_mergeSort_0();
case -909310911: return bem_sizeGet_0();
case 854088647: return bem_anyraySet_0();
case 1329221269: return bem_clear_0();
case -174969274: return bem_capacityGet_0();
case 69186396: return bem_lengthGet_0();
case -928276816: return bem_isEmptyGet_0();
case -1844269288: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1710447221: return bem_sizeSet_1((BEC_2_4_3_MathInt) bevd_0);
case -371582843: return bem_copyTo_1(bevd_0);
case -479605274: return bem_find_1(bevd_0);
case -1927943064: return bem_iterateAdd_1(bevd_0);
case -895626412: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case -1894214624: return bem_has_1(bevd_0);
case 1065626383: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1707985475: return bem_addAll_1(bevd_0);
case 521527567: return bem_sortedFind_1(bevd_0);
case 2015800048: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -2069120687: return bem_addValue_1(bevd_0);
case -1531367911: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case 1586592391: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case -272587445: return bem_notEquals_1(bevd_0);
case 1040700224: return bem_multiplierSet_1(bevd_0);
case -334586917: return bem_addValueWhole_1(bevd_0);
case 1051624606: return bem_undef_1(bevd_0);
case 1548214943: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1306600423: return bem_equals_1(bevd_0);
case 1102722232: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1784922692: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 324846295: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2141767897: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1875922630: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1263166407: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1482811280: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -847805315: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1704989212: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1182530297: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1725892051: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1176905374: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 22606030: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
