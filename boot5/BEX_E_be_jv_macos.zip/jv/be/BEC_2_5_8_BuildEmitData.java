package be;
/* IO:File: source/build/EmitData.be */
public final class BEC_2_5_8_BuildEmitData extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildEmitData() { }
private static byte[] becc_BEC_2_5_8_BuildEmitData_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61};
private static byte[] becc_BEC_2_5_8_BuildEmitData_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static BEC_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_inst;

public static BET_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_type;

public BEC_2_9_3_ContainerMap bevp_ptsp;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_9_3_ContainerMap bevp_nameEntries;
public BEC_2_9_3_ContainerMap bevp_classes;
public BEC_2_9_10_ContainerLinkedList bevp_parseOrderClassNames;
public BEC_2_9_3_ContainerMap bevp_justParsed;
public BEC_2_9_3_ContainerMap bevp_synClasses;
public BEC_2_9_3_ContainerMap bevp_midNames;
public BEC_2_9_3_ContainerMap bevp_usedBy;
public BEC_2_9_3_ContainerMap bevp_subClasses;
public BEC_2_9_3_ContainerSet bevp_propertyIndexes;
public BEC_2_9_3_ContainerSet bevp_methodIndexes;
public BEC_2_9_3_ContainerSet bevp_shouldEmit;
public BEC_2_9_3_ContainerMap bevp_aliased;
public BEC_2_5_8_BuildEmitData bem_new_0() throws Throwable {
bevp_ptsp = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_nameEntries = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parseOrderClassNames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_justParsed = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_synClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_midNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_usedBy = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_subClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_propertyIndexes = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_methodIndexes = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_aliased = (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addSynClass_2(BEC_2_4_6_TextString beva_npstr, BEC_2_5_8_BuildClassSyn beva_syn) throws Throwable {
BEC_2_4_6_TextString bevl_myname = null;
BEC_2_4_6_TextString bevl_s = null;
BEC_2_9_3_ContainerSet bevl_ub = null;
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_8_BuildNamePath bevt_1_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevp_synClasses.bem_put_2(beva_npstr, beva_syn);
bevt_1_ta_ph = beva_syn.bem_namepathGet_0();
bevl_myname = bevt_1_ta_ph.bem_toString_0();
bevt_2_ta_ph = beva_syn.bem_usesGet_0();
bevt_0_ta_loop = bevt_2_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 40*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(-1469355336);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 40*/ {
bevl_s = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(242021854);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_usedBy.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 42*/ {
bevl_ub = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_usedBy.bem_put_2(bevl_s, bevl_ub);
} /* Line: 44*/
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 46*/
 else /* Line: 40*/ {
break;
} /* Line: 40*/
} /* Line: 40*/
bevt_5_ta_ph = beva_syn.bem_superListGet_0();
bevl_iu = bevt_5_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 48*/ {
bevt_6_ta_ph = bevl_iu.bemd_0(-1469355336);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 48*/ {
bevt_7_ta_ph = bevl_iu.bemd_0(242021854);
bevl_s = (BEC_2_4_6_TextString) bevt_7_ta_ph.bemd_0(219112807);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_subClasses.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 51*/ {
bevl_ub = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_subClasses.bem_put_2(bevl_s, bevl_ub);
} /* Line: 53*/
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 55*/
 else /* Line: 48*/ {
break;
} /* Line: 48*/
} /* Line: 48*/
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addParsedClass_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
bevt_3_ta_ph = beva_node.bemd_0(-623707485);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(1686249444);
bevt_1_ta_ph = bevp_classes.bem_has_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_5_ta_ph = beva_node.bemd_0(-623707485);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(1686249444);
bevp_parseOrderClassNames.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 61*/
bevt_7_ta_ph = beva_node.bemd_0(-623707485);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(1686249444);
bevp_classes.bem_put_2(bevt_6_ta_ph, beva_node);
bevt_9_ta_ph = beva_node.bemd_0(-623707485);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1686249444);
bevp_justParsed.bem_put_2(bevt_8_ta_ph, beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGet_0() throws Throwable {
return bevp_ptsp;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_ptspGetDirect_0() throws Throwable {
return bevp_ptsp;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_ptspSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_allNamesGetDirect_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_allNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_foreignClassesGetDirect_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_foreignClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGet_0() throws Throwable {
return bevp_nameEntries;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_nameEntriesGetDirect_0() throws Throwable {
return bevp_nameEntries;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_nameEntriesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGet_0() throws Throwable {
return bevp_classes;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_classesGetDirect_0() throws Throwable {
return bevp_classes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_classesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGet_0() throws Throwable {
return bevp_parseOrderClassNames;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGetDirect_0() throws Throwable {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGet_0() throws Throwable {
return bevp_justParsed;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_justParsedGetDirect_0() throws Throwable {
return bevp_justParsed;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_justParsedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGet_0() throws Throwable {
return bevp_synClasses;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_synClassesGetDirect_0() throws Throwable {
return bevp_synClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_synClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGet_0() throws Throwable {
return bevp_midNames;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_midNamesGetDirect_0() throws Throwable {
return bevp_midNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_midNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGet_0() throws Throwable {
return bevp_usedBy;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_usedByGetDirect_0() throws Throwable {
return bevp_usedBy;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_usedBySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGet_0() throws Throwable {
return bevp_subClasses;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_subClassesGetDirect_0() throws Throwable {
return bevp_subClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_subClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGet_0() throws Throwable {
return bevp_propertyIndexes;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_propertyIndexesGetDirect_0() throws Throwable {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_propertyIndexesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGet_0() throws Throwable {
return bevp_methodIndexes;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_methodIndexesGetDirect_0() throws Throwable {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_methodIndexesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGet_0() throws Throwable {
return bevp_shouldEmit;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_shouldEmitGetDirect_0() throws Throwable {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_shouldEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() throws Throwable {
return bevp_aliased;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_aliasedGetDirect_0() throws Throwable {
return bevp_aliased;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_8_BuildEmitData bem_aliasedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 29, 30, 31, 32, 33, 38, 39, 39, 40, 40, 0, 40, 40, 41, 42, 42, 43, 44, 46, 48, 48, 48, 49, 49, 50, 51, 51, 52, 53, 55, 60, 60, 60, 60, 60, 61, 61, 61, 63, 63, 63, 64, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 58, 59, 60, 61, 62, 62, 65, 67, 68, 69, 74, 75, 76, 78, 84, 85, 88, 90, 91, 92, 93, 98, 99, 100, 102, 121, 122, 123, 124, 129, 130, 131, 132, 134, 135, 136, 137, 138, 139, 143, 146, 149, 153, 157, 160, 163, 167, 171, 174, 177, 181, 185, 188, 191, 195, 199, 202, 205, 209, 213, 216, 219, 223, 227, 230, 233, 237, 241, 244, 247, 251, 255, 258, 261, 265, 269, 272, 275, 279, 283, 286, 289, 293, 297, 300, 303, 307, 311, 314, 317, 321, 325, 328, 331, 335, 339, 342, 345, 349};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 27
new 0 17 27
assign 1 18 28
new 0 18 28
assign 1 19 29
new 0 19 29
assign 1 20 30
new 0 20 30
assign 1 21 31
new 0 21 31
assign 1 22 32
new 0 22 32
assign 1 23 33
new 0 23 33
assign 1 24 34
new 0 24 34
assign 1 25 35
new 0 25 35
assign 1 27 36
new 0 27 36
assign 1 29 37
new 0 29 37
assign 1 30 38
new 0 30 38
assign 1 31 39
new 0 31 39
assign 1 32 40
new 0 32 40
assign 1 33 41
new 0 33 41
put 2 38 58
assign 1 39 59
namepathGet 0 39 59
assign 1 39 60
toString 0 39 60
assign 1 40 61
usesGet 0 40 61
assign 1 40 62
iteratorGet 0 0 62
assign 1 40 65
hasNextGet 0 40 65
assign 1 40 67
nextGet 0 40 67
assign 1 41 68
get 1 41 68
assign 1 42 69
undef 1 42 74
assign 1 43 75
new 0 43 75
put 2 44 76
put 1 46 78
assign 1 48 84
superListGet 0 48 84
assign 1 48 85
iteratorGet 0 48 85
assign 1 48 88
hasNextGet 0 48 88
assign 1 49 90
nextGet 0 49 90
assign 1 49 91
toString 0 49 91
assign 1 50 92
get 1 50 92
assign 1 51 93
undef 1 51 98
assign 1 52 99
new 0 52 99
put 2 53 100
put 1 55 102
assign 1 60 121
heldGet 0 60 121
assign 1 60 122
nameGet 0 60 122
assign 1 60 123
has 1 60 123
assign 1 60 124
not 0 60 129
assign 1 61 130
heldGet 0 61 130
assign 1 61 131
nameGet 0 61 131
addValue 1 61 132
assign 1 63 134
heldGet 0 63 134
assign 1 63 135
nameGet 0 63 135
put 2 63 136
assign 1 64 137
heldGet 0 64 137
assign 1 64 138
nameGet 0 64 138
put 2 64 139
return 1 0 143
return 1 0 146
assign 1 0 149
assign 1 0 153
return 1 0 157
return 1 0 160
assign 1 0 163
assign 1 0 167
return 1 0 171
return 1 0 174
assign 1 0 177
assign 1 0 181
return 1 0 185
return 1 0 188
assign 1 0 191
assign 1 0 195
return 1 0 199
return 1 0 202
assign 1 0 205
assign 1 0 209
return 1 0 213
return 1 0 216
assign 1 0 219
assign 1 0 223
return 1 0 227
return 1 0 230
assign 1 0 233
assign 1 0 237
return 1 0 241
return 1 0 244
assign 1 0 247
assign 1 0 251
return 1 0 255
return 1 0 258
assign 1 0 261
assign 1 0 265
return 1 0 269
return 1 0 272
assign 1 0 275
assign 1 0 279
return 1 0 283
return 1 0 286
assign 1 0 289
assign 1 0 293
return 1 0 297
return 1 0 300
assign 1 0 303
assign 1 0 307
return 1 0 311
return 1 0 314
assign 1 0 317
assign 1 0 321
return 1 0 325
return 1 0 328
assign 1 0 331
assign 1 0 335
return 1 0 339
return 1 0 342
assign 1 0 345
assign 1 0 349
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1615402015: return bem_create_0();
case 1546143657: return bem_echo_0();
case 1673735739: return bem_allNamesGet_0();
case -1281636959: return bem_subClassesGetDirect_0();
case -651391709: return bem_shouldEmitGetDirect_0();
case -44293087: return bem_foreignClassesGet_0();
case -1263154564: return bem_new_0();
case -261000496: return bem_usedByGet_0();
case -613955925: return bem_ptspGet_0();
case -636402825: return bem_methodIndexesGetDirect_0();
case 1519477692: return bem_synClassesGet_0();
case -1326298724: return bem_classesGetDirect_0();
case -676070096: return bem_sourceFileNameGet_0();
case -1217699047: return bem_nameEntriesGetDirect_0();
case 1577124637: return bem_deserializeClassNameGet_0();
case 977094355: return bem_usedByGetDirect_0();
case -1179300120: return bem_nameEntriesGet_0();
case -1064531146: return bem_ptspGetDirect_0();
case -800146552: return bem_serializeContents_0();
case -794718926: return bem_copy_0();
case 299479653: return bem_allNamesGetDirect_0();
case 37637962: return bem_print_0();
case 1338730846: return bem_parseOrderClassNamesGet_0();
case 1445801145: return bem_serializationIteratorGet_0();
case -2095499202: return bem_fieldIteratorGet_0();
case 1333799692: return bem_tagGet_0();
case 219112807: return bem_toString_0();
case -1108687228: return bem_justParsedGet_0();
case -794062933: return bem_hashGet_0();
case 1179961651: return bem_serializeToString_0();
case 285362973: return bem_propertyIndexesGetDirect_0();
case 1199059311: return bem_methodIndexesGet_0();
case 340030523: return bem_classNameGet_0();
case -897346920: return bem_midNamesGetDirect_0();
case 1262323228: return bem_subClassesGet_0();
case -1001743190: return bem_fieldNamesGet_0();
case -2067181557: return bem_aliasedGet_0();
case 147497190: return bem_iteratorGet_0();
case 1522194549: return bem_classesGet_0();
case 1174943126: return bem_parseOrderClassNamesGetDirect_0();
case -975906697: return bem_aliasedGetDirect_0();
case -1346252429: return bem_synClassesGetDirect_0();
case -969430082: return bem_foreignClassesGetDirect_0();
case -241257744: return bem_midNamesGet_0();
case -525333299: return bem_justParsedGetDirect_0();
case -1787298507: return bem_shouldEmitGet_0();
case -679449677: return bem_propertyIndexesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1405755430: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -986267097: return bem_ptspSetDirect_1(bevd_0);
case 1661150226: return bem_def_1(bevd_0);
case 866218543: return bem_synClassesSetDirect_1(bevd_0);
case 2085396993: return bem_methodIndexesSetDirect_1(bevd_0);
case 1055823671: return bem_nameEntriesSet_1(bevd_0);
case 1419064041: return bem_sameObject_1(bevd_0);
case -1868129616: return bem_copyTo_1(bevd_0);
case -24242461: return bem_usedBySetDirect_1(bevd_0);
case 579299160: return bem_classesSetDirect_1(bevd_0);
case 1640401948: return bem_parseOrderClassNamesSetDirect_1(bevd_0);
case -1394976239: return bem_aliasedSetDirect_1(bevd_0);
case -441061752: return bem_justParsedSetDirect_1(bevd_0);
case 1143661082: return bem_aliasedSet_1(bevd_0);
case 2044993814: return bem_sameClass_1(bevd_0);
case -1935405349: return bem_sameType_1(bevd_0);
case -207267708: return bem_shouldEmitSetDirect_1(bevd_0);
case 1981346500: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -667389740: return bem_subClassesSet_1(bevd_0);
case 1753538521: return bem_synClassesSet_1(bevd_0);
case 739117568: return bem_otherClass_1(bevd_0);
case 1358045080: return bem_methodIndexesSet_1(bevd_0);
case 192528395: return bem_usedBySet_1(bevd_0);
case 550061094: return bem_undef_1(bevd_0);
case 539450852: return bem_subClassesSetDirect_1(bevd_0);
case -1515861009: return bem_addParsedClass_1(bevd_0);
case -236349728: return bem_nameEntriesSetDirect_1(bevd_0);
case 250302014: return bem_equals_1(bevd_0);
case -2022815028: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -542450110: return bem_midNamesSet_1(bevd_0);
case -19945451: return bem_notEquals_1(bevd_0);
case -1116540928: return bem_classesSet_1(bevd_0);
case -358907104: return bem_foreignClassesSet_1(bevd_0);
case -175151469: return bem_propertyIndexesSetDirect_1(bevd_0);
case 2048322738: return bem_allNamesSet_1(bevd_0);
case 67140421: return bem_propertyIndexesSet_1(bevd_0);
case 1896126064: return bem_shouldEmitSet_1(bevd_0);
case -878033085: return bem_parseOrderClassNamesSet_1(bevd_0);
case 774579104: return bem_foreignClassesSetDirect_1(bevd_0);
case -611629969: return bem_ptspSet_1(bevd_0);
case 1597521294: return bem_allNamesSetDirect_1(bevd_0);
case 1593026514: return bem_justParsedSet_1(bevd_0);
case -1534545800: return bem_otherType_1(bevd_0);
case 1691679788: return bem_midNamesSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -938540681: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1028188363: return bem_addSynClass_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_8_BuildClassSyn) bevd_1);
case -1738406137: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1708873965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 853768892: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2112740717: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildEmitData_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_8_BuildEmitData_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildEmitData();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst = (BEC_2_5_8_BuildEmitData) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_type;
}
}
