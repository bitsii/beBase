package be;
/* IO:File: source/build/EmitData.be */
public final class BEC_2_5_8_BuildEmitData extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildEmitData() { }
private static byte[] becc_BEC_2_5_8_BuildEmitData_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61};
private static byte[] becc_BEC_2_5_8_BuildEmitData_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static BEC_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_inst;

public static BET_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_type;

public BEC_2_9_3_ContainerMap bevp_ptsp;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_9_3_ContainerMap bevp_nameEntries;
public BEC_2_9_3_ContainerMap bevp_classes;
public BEC_2_9_10_ContainerLinkedList bevp_parseOrderClassNames;
public BEC_2_9_3_ContainerMap bevp_justParsed;
public BEC_2_9_3_ContainerMap bevp_synClasses;
public BEC_2_9_3_ContainerMap bevp_midNames;
public BEC_2_9_3_ContainerMap bevp_usedBy;
public BEC_2_9_3_ContainerMap bevp_subClasses;
public BEC_2_9_3_ContainerSet bevp_propertyIndexes;
public BEC_2_9_3_ContainerSet bevp_methodIndexes;
public BEC_2_9_3_ContainerSet bevp_shouldEmit;
public BEC_2_9_3_ContainerMap bevp_aliased;
public BEC_2_5_8_BuildEmitData bem_new_0() throws Throwable {
bevp_ptsp = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_nameEntries = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parseOrderClassNames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_justParsed = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_synClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_midNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_usedBy = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_subClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_propertyIndexes = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_methodIndexes = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_aliased = (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addSynClass_2(BEC_2_4_6_TextString beva_npstr, BEC_2_5_8_BuildClassSyn beva_syn) throws Throwable {
BEC_2_4_6_TextString bevl_myname = null;
BEC_2_4_6_TextString bevl_s = null;
BEC_2_9_3_ContainerSet bevl_ub = null;
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_8_BuildNamePath bevt_1_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevp_synClasses.bem_put_2(beva_npstr, beva_syn);
bevt_1_ta_ph = beva_syn.bem_namepathGet_0();
bevl_myname = bevt_1_ta_ph.bem_toString_0();
bevt_2_ta_ph = beva_syn.bem_usesGet_0();
bevt_0_ta_loop = bevt_2_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 46*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(193124196);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 46*/ {
bevl_s = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(221202628);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_usedBy.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 48*/ {
bevl_ub = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_usedBy.bem_put_2(bevl_s, bevl_ub);
} /* Line: 50*/
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 52*/
 else /* Line: 46*/ {
break;
} /* Line: 46*/
} /* Line: 46*/
bevt_5_ta_ph = beva_syn.bem_superListGet_0();
bevl_iu = bevt_5_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 54*/ {
bevt_6_ta_ph = bevl_iu.bemd_0(193124196);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 54*/ {
bevt_7_ta_ph = bevl_iu.bemd_0(221202628);
bevl_s = (BEC_2_4_6_TextString) bevt_7_ta_ph.bemd_0(1461169107);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_subClasses.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 57*/ {
bevl_ub = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_subClasses.bem_put_2(bevl_s, bevl_ub);
} /* Line: 59*/
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 61*/
 else /* Line: 54*/ {
break;
} /* Line: 54*/
} /* Line: 54*/
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addParsedClass_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
bevt_3_ta_ph = beva_node.bemd_0(2048750543);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1364348522);
bevt_1_ta_ph = bevp_classes.bem_has_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 66*/ {
bevt_5_ta_ph = beva_node.bemd_0(2048750543);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-1364348522);
bevp_parseOrderClassNames.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 67*/
bevt_7_ta_ph = beva_node.bemd_0(2048750543);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-1364348522);
bevp_classes.bem_put_2(bevt_6_ta_ph, beva_node);
bevt_9_ta_ph = beva_node.bemd_0(2048750543);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1364348522);
bevp_justParsed.bem_put_2(bevt_8_ta_ph, beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGet_0() throws Throwable {
return bevp_ptsp;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGet_0() throws Throwable {
return bevp_nameEntries;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGet_0() throws Throwable {
return bevp_classes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGet_0() throws Throwable {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGet_0() throws Throwable {
return bevp_justParsed;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGet_0() throws Throwable {
return bevp_synClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGet_0() throws Throwable {
return bevp_midNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGet_0() throws Throwable {
return bevp_usedBy;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGet_0() throws Throwable {
return bevp_subClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGet_0() throws Throwable {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGet_0() throws Throwable {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGet_0() throws Throwable {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() throws Throwable {
return bevp_aliased;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 26, 27, 28, 29, 30, 31, 33, 35, 36, 37, 38, 39, 44, 45, 45, 46, 46, 0, 46, 46, 47, 48, 48, 49, 50, 52, 54, 54, 54, 55, 55, 56, 57, 57, 58, 59, 61, 66, 66, 66, 66, 66, 67, 67, 67, 69, 69, 69, 70, 70, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 58, 59, 60, 61, 62, 62, 65, 67, 68, 69, 74, 75, 76, 78, 84, 85, 88, 90, 91, 92, 93, 98, 99, 100, 102, 121, 122, 123, 124, 129, 130, 131, 132, 134, 135, 136, 137, 138, 139, 143, 146, 150, 153, 157, 160, 164, 167, 171, 174, 178, 181, 185, 188, 192, 195, 199, 202, 206, 209, 213, 216, 220, 223, 227, 230, 234, 237, 241, 244};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 27
new 0 23 27
assign 1 24 28
new 0 24 28
assign 1 25 29
new 0 25 29
assign 1 26 30
new 0 26 30
assign 1 27 31
new 0 27 31
assign 1 28 32
new 0 28 32
assign 1 29 33
new 0 29 33
assign 1 30 34
new 0 30 34
assign 1 31 35
new 0 31 35
assign 1 33 36
new 0 33 36
assign 1 35 37
new 0 35 37
assign 1 36 38
new 0 36 38
assign 1 37 39
new 0 37 39
assign 1 38 40
new 0 38 40
assign 1 39 41
new 0 39 41
put 2 44 58
assign 1 45 59
namepathGet 0 45 59
assign 1 45 60
toString 0 45 60
assign 1 46 61
usesGet 0 46 61
assign 1 46 62
iteratorGet 0 0 62
assign 1 46 65
hasNextGet 0 46 65
assign 1 46 67
nextGet 0 46 67
assign 1 47 68
get 1 47 68
assign 1 48 69
undef 1 48 74
assign 1 49 75
new 0 49 75
put 2 50 76
put 1 52 78
assign 1 54 84
superListGet 0 54 84
assign 1 54 85
iteratorGet 0 54 85
assign 1 54 88
hasNextGet 0 54 88
assign 1 55 90
nextGet 0 55 90
assign 1 55 91
toString 0 55 91
assign 1 56 92
get 1 56 92
assign 1 57 93
undef 1 57 98
assign 1 58 99
new 0 58 99
put 2 59 100
put 1 61 102
assign 1 66 121
heldGet 0 66 121
assign 1 66 122
nameGet 0 66 122
assign 1 66 123
has 1 66 123
assign 1 66 124
not 0 66 129
assign 1 67 130
heldGet 0 67 130
assign 1 67 131
nameGet 0 67 131
addValue 1 67 132
assign 1 69 134
heldGet 0 69 134
assign 1 69 135
nameGet 0 69 135
put 2 69 136
assign 1 70 137
heldGet 0 70 137
assign 1 70 138
nameGet 0 70 138
put 2 70 139
return 1 0 143
assign 1 0 146
return 1 0 150
assign 1 0 153
return 1 0 157
assign 1 0 160
return 1 0 164
assign 1 0 167
return 1 0 171
assign 1 0 174
return 1 0 178
assign 1 0 181
return 1 0 185
assign 1 0 188
return 1 0 192
assign 1 0 195
return 1 0 199
assign 1 0 202
return 1 0 206
assign 1 0 209
return 1 0 213
assign 1 0 216
return 1 0 220
assign 1 0 223
return 1 0 227
assign 1 0 230
return 1 0 234
assign 1 0 237
return 1 0 241
assign 1 0 244
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -598527742: return bem_foreignClassesGet_0();
case 1540466140: return bem_propertyIndexesGet_0();
case -734441873: return bem_parseOrderClassNamesGet_0();
case 801630910: return bem_methodIndexesGet_0();
case -826795842: return bem_shouldEmitGet_0();
case 178721427: return bem_hashGet_0();
case 1125757906: return bem_new_0();
case 567699788: return bem_usedByGet_0();
case -1428092086: return bem_classesGet_0();
case 125318231: return bem_subClassesGet_0();
case 1394550537: return bem_copy_0();
case -1792644526: return bem_nameEntriesGet_0();
case 1370586601: return bem_midNamesGet_0();
case 1324893030: return bem_print_0();
case 1461169107: return bem_toString_0();
case -2133650264: return bem_ptspGet_0();
case -398093942: return bem_allNamesGet_0();
case -602236411: return bem_justParsedGet_0();
case -2055603985: return bem_synClassesGet_0();
case -246278640: return bem_create_0();
case -1618073132: return bem_iteratorGet_0();
case 1874833920: return bem_aliasedGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1915797651: return bem_notEquals_1(bevd_0);
case 392781782: return bem_equals_1(bevd_0);
case 1224990908: return bem_aliasedSet_1(bevd_0);
case 1579908543: return bem_justParsedSet_1(bevd_0);
case -1214415241: return bem_usedBySet_1(bevd_0);
case -1048928473: return bem_classesSet_1(bevd_0);
case 1404041705: return bem_shouldEmitSet_1(bevd_0);
case 146904141: return bem_methodIndexesSet_1(bevd_0);
case 1629327178: return bem_foreignClassesSet_1(bevd_0);
case -1693499204: return bem_ptspSet_1(bevd_0);
case -2025525725: return bem_copyTo_1(bevd_0);
case 594043501: return bem_print_1(bevd_0);
case -1186182304: return bem_allNamesSet_1(bevd_0);
case -1191501354: return bem_addParsedClass_1(bevd_0);
case 244340630: return bem_def_1(bevd_0);
case -306634610: return bem_synClassesSet_1(bevd_0);
case 2112275870: return bem_nameEntriesSet_1(bevd_0);
case -1915285105: return bem_subClassesSet_1(bevd_0);
case 666628192: return bem_midNamesSet_1(bevd_0);
case -482098203: return bem_undef_1(bevd_0);
case 480555596: return bem_parseOrderClassNamesSet_1(bevd_0);
case -1341240493: return bem_propertyIndexesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1729000428: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1685769165: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -675790118: return bem_addSynClass_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_8_BuildClassSyn) bevd_1);
case -96915223: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -726117523: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildEmitData_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_8_BuildEmitData_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildEmitData();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst = (BEC_2_5_8_BuildEmitData) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_type;
}
}
