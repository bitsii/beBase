package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {112, 112};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 11};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 112 10
new 2 112 10
return 1 112 11
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 301206433: return bem_echo_0();
case -2088752134: return bem_toList_0();
case -803388239: return bem_deserializeClassNameGet_0();
case 1314576819: return bem_print_0();
case 2033657832: return bem_hashGet_0();
case -648405123: return bem_firstNodeGet_0();
case -1980796873: return bem_copy_0();
case -70500062: return bem_fieldIteratorGet_0();
case 366164054: return bem_serializeContents_0();
case 1732876397: return bem_serializationIteratorGet_0();
case 737771364: return bem_toString_0();
case 1452879382: return bem_sourceFileNameGet_0();
case -420235024: return bem_classNameGet_0();
case -1393006619: return bem_lastGet_0();
case -1866917929: return bem_serializeToString_0();
case 1065393688: return bem_firstGet_0();
case -302965453: return bem_tagGet_0();
case 1222310146: return bem_many_0();
case 482356666: return bem_toAny_0();
case -196299024: return bem_toNodeList_0();
case 1023783415: return bem_create_0();
case 1775715094: return bem_once_0();
case 997723391: return bem_iteratorGet_0();
case -152146528: return bem_lastNodeGet_0();
case 823429596: return bem_lengthGet_0();
case 1740522405: return bem_sizeGet_0();
case -1319859422: return bem_secondGet_0();
case 149557156: return bem_reverse_0();
case 1780323182: return bem_linkedListIteratorGet_0();
case -1894948982: return bem_thirdGet_0();
case 737353003: return bem_new_0();
case 1968685700: return bem_isEmptyGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1732568943: return bem_sameObject_1(bevd_0);
case -1787564914: return bem_newNode_1(bevd_0);
case 1732014863: return bem_equals_1(bevd_0);
case -369272378: return bem_undefined_1(bevd_0);
case -886793844: return bem_prepend_1(bevd_0);
case 215129863: return bem_firstNodeSet_1(bevd_0);
case 261660478: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -1653025498: return bem_prependNode_1(bevd_0);
case 1452810576: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 808158717: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1112750632: return bem_otherType_1(bevd_0);
case 446433936: return bem_addAll_1(bevd_0);
case 398463624: return bem_addValueWhole_1(bevd_0);
case 228693515: return bem_notEquals_1(bevd_0);
case 254712574: return bem_def_1(bevd_0);
case 1210677960: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1107846755: return bem_otherClass_1(bevd_0);
case -396768715: return bem_addValue_1(bevd_0);
case -1006891413: return bem_lastNodeSet_1(bevd_0);
case 721039721: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 140393120: return bem_getNode_1(bevd_0);
case 1735205112: return bem_sameType_1(bevd_0);
case -10325606: return bem_undef_1(bevd_0);
case 235706821: return bem_defined_1(bevd_0);
case -1078688343: return bem_copyTo_1(bevd_0);
case 1940225088: return bem_sameClass_1(bevd_0);
case 1235111255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -138885841: return bem_iterateAdd_1(bevd_0);
case 1067681324: return bem_appendNode_1(bevd_0);
case -265844688: return bem_deleteNode_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1979854931: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1437812444: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -164742720: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -735369440: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1990568085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815656517: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1354377183: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 1747848637: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -303274357: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -70659423: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
}
