package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {117, 117};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 117 13
new 2 117 13
return 1 117 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 97869199: return bem_hashGet_0();
case -999123940: return bem_create_0();
case 420796529: return bem_toString_0();
case -1852232311: return bem_lengthGet_0();
case -172537789: return bem_serializationIteratorGet_0();
case -96653499: return bem_firstNodeGet_0();
case -1793301062: return bem_isEmptyGet_0();
case -17338098: return bem_lastNodeGet_0();
case 1697209043: return bem_firstGet_0();
case 292813123: return bem_reverse_0();
case 1481666025: return bem_linkedListIteratorGet_0();
case 1108116623: return bem_toList_0();
case 2105446481: return bem_print_0();
case 1954800902: return bem_sizeGet_0();
case -2134993308: return bem_new_0();
case -2096331826: return bem_copy_0();
case -257464906: return bem_toNodeList_0();
case 1191981523: return bem_secondGet_0();
case 1019847417: return bem_thirdGet_0();
case -2133146908: return bem_iteratorGet_0();
case -1957607524: return bem_lastGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1251624631: return bem_newNode_1(bevd_0);
case 1724089654: return bem_equals_1(bevd_0);
case -1177381470: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1845239358: return bem_copyTo_1(bevd_0);
case 1265043961: return bem_firstNodeSet_1(bevd_0);
case 300549907: return bem_getNode_1(bevd_0);
case -847954254: return bem_iterateAdd_1(bevd_0);
case 1807450671: return bem_addAll_1(bevd_0);
case -199176115: return bem_undef_1(bevd_0);
case -1499986418: return bem_prepend_1(bevd_0);
case -561946826: return bem_def_1(bevd_0);
case 867243956: return bem_addValue_1(bevd_0);
case 167653604: return bem_lastNodeSet_1(bevd_0);
case -1039946930: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -1487424295: return bem_appendNode_1(bevd_0);
case 1016050541: return bem_notEquals_1(bevd_0);
case 1437569443: return bem_prependNode_1(bevd_0);
case -628632190: return bem_deleteNode_1(bevd_0);
case 344551317: return bem_addValueWhole_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1560972769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -444420730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 902080136: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 150001987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1168459766: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 861111505: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1456712468: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
