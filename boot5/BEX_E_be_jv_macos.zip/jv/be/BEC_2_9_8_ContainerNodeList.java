package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 111};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 13
new 2 111 13
return 1 111 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1821328449: return bem_lengthGet_0();
case 235554219: return bem_iteratorGet_0();
case 1493698151: return bem_lastGet_0();
case 2074652546: return bem_firstNodeGet_0();
case 956564530: return bem_toString_0();
case -6785712: return bem_copy_0();
case -1593720868: return bem_toList_0();
case 536000307: return bem_sizeGet_0();
case 115332378: return bem_lastNodeGet_0();
case 1631198925: return bem_print_0();
case -543484680: return bem_firstGet_0();
case 1717768738: return bem_reverse_0();
case -356284838: return bem_toNodeList_0();
case 450737207: return bem_thirdGet_0();
case -854129615: return bem_classNameGet_0();
case 49169285: return bem_create_0();
case -2129238938: return bem_fieldNamesGet_0();
case -1703081654: return bem_isEmptyGet_0();
case 744789579: return bem_tagGet_0();
case -1452138406: return bem_secondGet_0();
case -7476103: return bem_hashGet_0();
case 655402544: return bem_linkedListIteratorGet_0();
case 2115475884: return bem_new_0();
case -648849725: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1702085860: return bem_lastNodeSet_1(bevd_0);
case 1338190085: return bem_def_1(bevd_0);
case -1005385637: return bem_copyTo_1(bevd_0);
case 1149746123: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2142487980: return bem_sameType_1(bevd_0);
case -522131822: return bem_firstNodeSet_1(bevd_0);
case 133446258: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 635933496: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 2082809017: return bem_prepend_1(bevd_0);
case -1256020058: return bem_otherType_1(bevd_0);
case -1109864667: return bem_getNode_1(bevd_0);
case -2052423771: return bem_notEquals_1(bevd_0);
case 1803219106: return bem_prependNode_1(bevd_0);
case 479329091: return bem_addValueWhole_1(bevd_0);
case -1184273709: return bem_undef_1(bevd_0);
case -76922352: return bem_equals_1(bevd_0);
case -863126832: return bem_addAll_1(bevd_0);
case 460588276: return bem_newNode_1(bevd_0);
case 527653112: return bem_addValue_1(bevd_0);
case -1185886336: return bem_appendNode_1(bevd_0);
case 1680201389: return bem_deleteNode_1(bevd_0);
case -879931579: return bem_iterateAdd_1(bevd_0);
case -1554337727: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -829590487: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -744751889: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 740839508: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -630337943: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 1116067959: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -383996467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1378849249: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1363599577: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
