package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 111};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 13
new 2 111 13
return 1 111 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -960578481: return bem_firstGet_0();
case -1500345660: return bem_new_0();
case -1251449970: return bem_secondGet_0();
case 1515640643: return bem_thirdGet_0();
case 1914698093: return bem_copy_0();
case 532709200: return bem_reverse_0();
case -2084894963: return bem_firstNodeGet_0();
case -411352811: return bem_iteratorGet_0();
case 1203430888: return bem_isEmptyGet_0();
case 298679762: return bem_lengthGet_0();
case -1175743378: return bem_toList_0();
case -2044808959: return bem_create_0();
case -1009562380: return bem_lastGet_0();
case 701056781: return bem_print_0();
case 1564508116: return bem_lastNodeGet_0();
case -1418204122: return bem_toNodeList_0();
case -1708969815: return bem_linkedListIteratorGet_0();
case 332374972: return bem_toString_0();
case 1777123341: return bem_serializationIteratorGet_0();
case 403207358: return bem_hashGet_0();
case -541233528: return bem_sizeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1670448947: return bem_prependNode_1(bevd_0);
case -1708067111: return bem_firstNodeSet_1(bevd_0);
case 1101131282: return bem_prepend_1(bevd_0);
case -75363891: return bem_addAll_1(bevd_0);
case -183213474: return bem_copyTo_1(bevd_0);
case -1073250307: return bem_newNode_1(bevd_0);
case -68111971: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -1665769964: return bem_appendNode_1(bevd_0);
case -361142495: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 672105181: return bem_getNode_1(bevd_0);
case -1848981970: return bem_lastNodeSet_1(bevd_0);
case -854047153: return bem_addValueWhole_1(bevd_0);
case 2093081199: return bem_equals_1(bevd_0);
case 782259850: return bem_addValue_1(bevd_0);
case 242448501: return bem_undef_1(bevd_0);
case -2091475700: return bem_def_1(bevd_0);
case -186958185: return bem_iterateAdd_1(bevd_0);
case -1562657882: return bem_deleteNode_1(bevd_0);
case 1056390040: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1734287964: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1748111499: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1000591055: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 1483971403: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1968238059: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 596315904: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1944821118: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
