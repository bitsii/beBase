package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_17_TextMultiByteIterator extends BEC_2_4_12_TextByteIterator {
public BEC_2_4_17_TextMultiByteIterator() { }
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x4D,0x75,0x6C,0x74,0x69,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(127));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(-64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(-32));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(-16));
private static byte[] bece_BEC_2_4_17_TextMultiByteIterator_bels_0 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x2C,0x20,0x75,0x74,0x66,0x2D,0x38,0x20,0x6D,0x75,0x6C,0x74,0x69,0x62,0x79,0x74,0x65,0x20,0x73,0x65,0x71,0x75,0x65,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x20,0x74,0x68,0x61,0x6E,0x20,0x34,0x20,0x62,0x79,0x74,0x65,0x73};
public static BEC_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;

public static BET_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_bcount;
public BEC_2_4_3_MathInt bevp_ival;
public BEC_2_4_17_TextMultiByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_bcount = (new BEC_2_4_3_MathInt());
bevp_ival = (new BEC_2_4_3_MathInt());
super.bem_new_1(beva__str);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1373 */ {
bevp_str.bem_getInt_2(bevp_pos, bevp_ival);
bevt_4_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_0;
if (bevp_ival.bevi_int >= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1375 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_1;
if (bevp_ival.bevi_int <= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 1375 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1375 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1375 */
 else  /* Line: 1375 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1375 */ {
bevp_bcount = (new BEC_2_4_3_MathInt(1));
} /* Line: 1376 */
 else  /* Line: 1375 */ {
bevt_9_tmpany_phold = (new BEC_2_4_3_MathInt(-32));
bevt_8_tmpany_phold = bevp_ival.bem_and_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_2;
if (bevt_8_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1377 */ {
bevp_bcount = (new BEC_2_4_3_MathInt(2));
} /* Line: 1378 */
 else  /* Line: 1375 */ {
bevt_13_tmpany_phold = (new BEC_2_4_3_MathInt(-16));
bevt_12_tmpany_phold = bevp_ival.bem_and_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_3;
if (bevt_12_tmpany_phold.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 1379 */ {
bevp_bcount = (new BEC_2_4_3_MathInt(3));
} /* Line: 1380 */
 else  /* Line: 1375 */ {
bevt_17_tmpany_phold = (new BEC_2_4_3_MathInt(-8));
bevt_16_tmpany_phold = bevp_ival.bem_and_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_4;
if (bevt_16_tmpany_phold.bevi_int == bevt_18_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 1381 */ {
bevp_bcount = (new BEC_2_4_3_MathInt(4));
} /* Line: 1382 */
 else  /* Line: 1383 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(66, bece_BEC_2_4_17_TextMultiByteIterator_bels_0));
bevt_19_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_20_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 1384 */
} /* Line: 1375 */
} /* Line: 1375 */
} /* Line: 1375 */
bevt_22_tmpany_phold = beva_buf.bem_sizeGet_0();
if (bevt_22_tmpany_phold.bevi_int != bevp_bcount.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 1386 */ {
bevt_23_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_23_tmpany_phold.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1387 */
bevp_bcount.bevi_int += bevp_pos.bevi_int;
bevt_24_tmpany_phold = (new BEC_2_4_3_MathInt(0));
beva_buf.bem_copyValue_4(bevp_str, bevp_pos, bevp_bcount, bevt_24_tmpany_phold);
bevp_pos.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1391 */
return beva_buf;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_bcountGet_0() throws Throwable {
return bevp_bcount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_bcountGetDirect_0() throws Throwable {
return bevp_bcount;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_bcountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_bcountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ivalGet_0() throws Throwable {
return bevp_ival;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ivalGetDirect_0() throws Throwable {
return bevp_ival;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_ivalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_17_TextMultiByteIterator bem_ivalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1362, 1363, 1365, 1369, 1369, 1369, 1369, 1373, 1373, 1373, 1374, 1375, 1375, 1375, 1375, 1375, 1375, 0, 0, 0, 1376, 1377, 1377, 1377, 1377, 1377, 1378, 1379, 1379, 1379, 1379, 1379, 1380, 1381, 1381, 1381, 1381, 1381, 1382, 1384, 1384, 1384, 1386, 1386, 1386, 1387, 1387, 1389, 1390, 1390, 1391, 1393, 1397, 1401, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 22, 29, 30, 31, 32, 60, 61, 66, 67, 68, 69, 74, 75, 76, 81, 82, 85, 89, 92, 95, 96, 97, 98, 103, 104, 107, 108, 109, 110, 115, 116, 119, 120, 121, 122, 127, 128, 131, 132, 133, 138, 139, 144, 145, 146, 148, 149, 150, 151, 153, 156, 159, 162, 165, 168, 172, 176, 179, 182, 186};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1362 20
new 0 1362 20
assign 1 1363 21
new 0 1363 21
new 1 1365 22
assign 1 1369 29
new 0 1369 29
assign 1 1369 30
new 1 1369 30
assign 1 1369 31
next 1 1369 31
return 1 1369 32
assign 1 1373 60
sizeGet 0 1373 60
assign 1 1373 61
greater 1 1373 66
getInt 2 1374 67
assign 1 1375 68
new 0 1375 68
assign 1 1375 69
greaterEquals 1 1375 74
assign 1 1375 75
new 0 1375 75
assign 1 1375 76
lesserEquals 1 1375 81
assign 1 0 82
assign 1 0 85
assign 1 0 89
assign 1 1376 92
new 0 1376 92
assign 1 1377 95
new 0 1377 95
assign 1 1377 96
and 1 1377 96
assign 1 1377 97
new 0 1377 97
assign 1 1377 98
equals 1 1377 103
assign 1 1378 104
new 0 1378 104
assign 1 1379 107
new 0 1379 107
assign 1 1379 108
and 1 1379 108
assign 1 1379 109
new 0 1379 109
assign 1 1379 110
equals 1 1379 115
assign 1 1380 116
new 0 1380 116
assign 1 1381 119
new 0 1381 119
assign 1 1381 120
and 1 1381 120
assign 1 1381 121
new 0 1381 121
assign 1 1381 122
equals 1 1381 127
assign 1 1382 128
new 0 1382 128
assign 1 1384 131
new 0 1384 131
assign 1 1384 132
new 1 1384 132
throw 1 1384 133
assign 1 1386 138
sizeGet 0 1386 138
assign 1 1386 139
notEquals 1 1386 144
assign 1 1387 145
sizeGet 0 1387 145
setValue 1 1387 146
addValue 1 1389 148
assign 1 1390 149
new 0 1390 149
copyValue 4 1390 150
setValue 1 1391 151
return 1 1393 153
return 1 1397 156
return 1 1401 159
return 1 0 162
return 1 0 165
assign 1 0 168
assign 1 0 172
return 1 0 176
return 1 0 179
assign 1 0 182
assign 1 0 186
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1229115512: return bem_bcountGetDirect_0();
case -1333696208: return bem_toString_0();
case 511565889: return bem_bcountGet_0();
case 1521004371: return bem_copy_0();
case -1422933374: return bem_ivalGetDirect_0();
case 2057652625: return bem_fieldNamesGet_0();
case -1018946318: return bem_multiByteIteratorIteratorGet_0();
case 1388210855: return bem_strGet_0();
case 1160667941: return bem_byteIteratorIteratorGet_0();
case 1121605448: return bem_serializeToString_0();
case 444413474: return bem_toAny_0();
case 1523724038: return bem_sourceFileNameGet_0();
case -2079748922: return bem_nextGet_0();
case -649199060: return bem_serializeContents_0();
case 1927478153: return bem_posGet_0();
case 84009197: return bem_deserializeClassNameGet_0();
case 885128203: return bem_create_0();
case 1294757574: return bem_tagGet_0();
case -44130384: return bem_vcopyGetDirect_0();
case -2010885181: return bem_many_0();
case 58977586: return bem_containerGet_0();
case 268640521: return bem_hashGet_0();
case -2060917023: return bem_classNameGet_0();
case -907702096: return bem_once_0();
case -843126344: return bem_serializationIteratorGet_0();
case -1546519862: return bem_ivalGet_0();
case -846095317: return bem_strGetDirect_0();
case 1097464934: return bem_print_0();
case 1854104225: return bem_hasNextGet_0();
case -765777488: return bem_posGetDirect_0();
case 831513957: return bem_iteratorGet_0();
case 1159622845: return bem_echo_0();
case 415746803: return bem_vcopyGet_0();
case 2143550869: return bem_new_0();
case -730552231: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1863207166: return bem_def_1(bevd_0);
case -1634362909: return bem_ivalSetDirect_1(bevd_0);
case -1114550651: return bem_undefined_1(bevd_0);
case -51654076: return bem_ivalSet_1(bevd_0);
case -1393440918: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case -1035577062: return bem_equals_1(bevd_0);
case 899961531: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 707803037: return bem_bcountSetDirect_1(bevd_0);
case -597660038: return bem_strSet_1(bevd_0);
case -351226620: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1417473277: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2070464708: return bem_vcopySet_1(bevd_0);
case -933911215: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 629325257: return bem_posSetDirect_1(bevd_0);
case -1776510589: return bem_copyTo_1(bevd_0);
case -1844531825: return bem_posSet_1(bevd_0);
case 2123468926: return bem_sameObject_1(bevd_0);
case 775033796: return bem_sameClass_1(bevd_0);
case 544363262: return bem_otherClass_1(bevd_0);
case -2056338520: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 459298083: return bem_otherType_1(bevd_0);
case 1189274855: return bem_sameType_1(bevd_0);
case -1405484691: return bem_vcopySetDirect_1(bevd_0);
case 1719411527: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 462232067: return bem_strSetDirect_1(bevd_0);
case 171056025: return bem_defined_1(bevd_0);
case -839680850: return bem_undef_1(bevd_0);
case -571354968: return bem_notEquals_1(bevd_0);
case 694432124: return bem_bcountSet_1(bevd_0);
case 1600099615: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -766978411: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 661608167: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 319580096: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -111616333: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -87616259: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 710208868: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 520958435: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -842656681: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_4_17_TextMultiByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_17_TextMultiByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_17_TextMultiByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst = (BEC_2_4_17_TextMultiByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;
}
}
