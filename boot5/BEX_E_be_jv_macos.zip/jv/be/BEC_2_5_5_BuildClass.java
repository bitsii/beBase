package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_5_BuildClass extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
public static BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;

public static BET_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public BEC_2_5_5_BuildClass bem_new_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevp_methods = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_isLocal = be.BECS_Runtime.boolFalse;
bevp_isNotNull = be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (new BEC_2_4_3_MathInt(0));
bevp_isList = be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = be.BECS_Runtime.boolFalse;
bevp_belsCount = (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_ta_ph);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_ta_ph);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) throws Throwable {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_emits == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 143*/ {
bevp_emits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 144*/
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_7_SystemClasses bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_ret = bevt_0_ta_ph.bem_className_1(this);
if (bevp_namepath == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 151*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_2));
bevt_2_ta_ph = bevl_ret.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_namepath.bem_toString_0();
bevl_ret = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
if (bevp_extends == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 153*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_3));
bevt_6_ta_ph = bevl_ret.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevp_extends.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
} /* Line: 154*/
} /* Line: 153*/
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() throws Throwable {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() throws Throwable {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() throws Throwable {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() throws Throwable {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() throws Throwable {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() throws Throwable {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() throws Throwable {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() throws Throwable {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() throws Throwable {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() throws Throwable {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() throws Throwable {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() throws Throwable {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() throws Throwable {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 129, 130, 130, 131, 133, 134, 134, 135, 139, 143, 143, 144, 146, 150, 150, 151, 151, 152, 152, 152, 152, 153, 153, 154, 154, 154, 154, 157, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 69, 74, 79, 80, 82, 96, 97, 98, 103, 104, 105, 106, 107, 108, 113, 114, 115, 116, 117, 120, 123, 126, 130, 133, 137, 140, 144, 147, 151, 154, 158, 161, 165, 168, 172, 175, 179, 182, 186, 189, 193, 196, 200, 203, 207, 210, 214, 217, 221, 224, 228, 231, 235, 238, 242, 245, 249, 252, 256, 259, 263, 266, 270, 273, 277, 280};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 109 42
new 0 109 42
assign 1 110 43
new 0 110 43
assign 1 111 44
new 0 111 44
assign 1 112 45
new 0 112 45
assign 1 113 46
new 0 113 46
assign 1 114 47
new 0 114 47
assign 1 115 48
new 0 115 48
assign 1 116 49
new 0 116 49
assign 1 117 50
new 0 117 50
assign 1 118 51
new 0 118 51
assign 1 119 52
new 0 119 52
assign 1 120 53
new 0 120 53
assign 1 121 54
new 0 121 54
assign 1 122 55
new 0 122 55
assign 1 123 56
new 0 123 56
assign 1 124 57
new 0 124 57
assign 1 129 58
new 0 129 58
assign 1 130 59
new 0 130 59
fromString 1 130 60
addUsed 1 131 61
assign 1 133 62
new 0 133 62
assign 1 134 63
new 0 134 63
fromString 1 134 64
addUsed 1 135 65
addValue 1 139 69
assign 1 143 74
undef 1 143 79
assign 1 144 80
new 0 144 80
addValue 1 146 82
assign 1 150 96
new 0 150 96
assign 1 150 97
className 1 150 97
assign 1 151 98
def 1 151 103
assign 1 152 104
new 0 152 104
assign 1 152 105
add 1 152 105
assign 1 152 106
toString 0 152 106
assign 1 152 107
add 1 152 107
assign 1 153 108
def 1 153 113
assign 1 154 114
new 0 154 114
assign 1 154 115
add 1 154 115
assign 1 154 116
toString 0 154 116
assign 1 154 117
add 1 154 117
return 1 157 120
return 1 0 123
assign 1 0 126
return 1 0 130
assign 1 0 133
return 1 0 137
assign 1 0 140
return 1 0 144
assign 1 0 147
return 1 0 151
assign 1 0 154
return 1 0 158
assign 1 0 161
return 1 0 165
assign 1 0 168
return 1 0 172
assign 1 0 175
return 1 0 179
assign 1 0 182
return 1 0 186
assign 1 0 189
return 1 0 193
assign 1 0 196
return 1 0 200
assign 1 0 203
return 1 0 207
assign 1 0 210
return 1 0 214
assign 1 0 217
return 1 0 221
assign 1 0 224
return 1 0 228
assign 1 0 231
return 1 0 235
assign 1 0 238
return 1 0 242
assign 1 0 245
return 1 0 249
assign 1 0 252
return 1 0 256
assign 1 0 259
return 1 0 263
assign 1 0 266
return 1 0 270
assign 1 0 273
return 1 0 277
assign 1 0 280
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 241703914: return bem_fromFileGet_0();
case -628064769: return bem_usedGet_0();
case -556619698: return bem_orderedVarsGet_0();
case -1477018360: return bem_toString_0();
case -1092074742: return bem_methodsGet_0();
case 1030336271: return bem_new_0();
case -1808613390: return bem_freeFirstSlotGet_0();
case 1735465254: return bem_extendsGet_0();
case -1240990566: return bem_libNameGet_0();
case -662844650: return bem_iteratorGet_0();
case 2095632369: return bem_belsCountGet_0();
case 1499728835: return bem_onceEvalCountGet_0();
case -1884060601: return bem_synGet_0();
case -1029937: return bem_orderedMethodsGet_0();
case -1807213748: return bem_isFinalGet_0();
case -201859351: return bem_nativeSlotsGet_0();
case 310309721: return bem_hashGet_0();
case 1379821961: return bem_create_0();
case 1266056978: return bem_shouldWriteGet_0();
case -1003067220: return bem_isLocalGet_0();
case -25213904: return bem_referencedPropertiesGet_0();
case 1155069902: return bem_print_0();
case 784149826: return bem_isNotNullGet_0();
case -1141241291: return bem_copy_0();
case -2138239361: return bem_anyMapGet_0();
case -2007051172: return bem_isListGet_0();
case -1596649092: return bem_nameGet_0();
case -1953024062: return bem_emitsGet_0();
case 880079148: return bem_firstSlotNativeGet_0();
case 1287065723: return bem_namepathGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1801291774: return bem_def_1(bevd_0);
case -849916041: return bem_shouldWriteSet_1(bevd_0);
case -1264563233: return bem_notEquals_1(bevd_0);
case -484230468: return bem_nameSet_1(bevd_0);
case -1500173786: return bem_methodsSet_1(bevd_0);
case -953366007: return bem_addEmit_1(bevd_0);
case -1943102243: return bem_isNotNullSet_1(bevd_0);
case -420186336: return bem_extendsSet_1(bevd_0);
case -296252741: return bem_libNameSet_1(bevd_0);
case 995611795: return bem_isFinalSet_1(bevd_0);
case 1695379231: return bem_referencedPropertiesSet_1(bevd_0);
case 1738502576: return bem_copyTo_1(bevd_0);
case 1036355460: return bem_isListSet_1(bevd_0);
case 725016549: return bem_fromFileSet_1(bevd_0);
case 486888133: return bem_synSet_1(bevd_0);
case 1278813453: return bem_orderedMethodsSet_1(bevd_0);
case -872045498: return bem_namepathSet_1(bevd_0);
case 1356744556: return bem_addUsed_1(bevd_0);
case 1075706066: return bem_undef_1(bevd_0);
case 1008605178: return bem_anyMapSet_1(bevd_0);
case -242077889: return bem_freeFirstSlotSet_1(bevd_0);
case -1624446761: return bem_firstSlotNativeSet_1(bevd_0);
case 278034565: return bem_equals_1(bevd_0);
case 1461960836: return bem_belsCountSet_1(bevd_0);
case -1176436455: return bem_print_1(bevd_0);
case 794181246: return bem_onceEvalCountSet_1(bevd_0);
case 1552587488: return bem_usedSet_1(bevd_0);
case 480888983: return bem_emitsSet_1(bevd_0);
case 975171829: return bem_isLocalSet_1(bevd_0);
case 1320716931: return bem_nativeSlotsSet_1(bevd_0);
case 1274344834: return bem_orderedVarsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -844523032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1584274286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 752466488: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -880661396: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildClass();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_type;
}
}
