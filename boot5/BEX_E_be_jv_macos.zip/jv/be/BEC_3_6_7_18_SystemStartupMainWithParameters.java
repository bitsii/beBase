package be;
/* IO:File: source/extended/Startup.be */
public class BEC_3_6_7_18_SystemStartupMainWithParameters extends BEC_2_6_6_SystemObject {
public BEC_3_6_7_18_SystemStartupMainWithParameters() { }
private static byte[] becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x3A,0x4D,0x61,0x69,0x6E,0x57,0x69,0x74,0x68,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevo_0 = (new BEC_2_4_3_MathInt(0));
public static BEC_3_6_7_18_SystemStartupMainWithParameters bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst;

public static BET_3_6_7_18_SystemStartupMainWithParameters bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_type;

public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_3_ta_ph = null;
bevt_3_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_main_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_6_10_SystemParameters beva_params) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_2_ta_ph = beva_params.bem_orderedGet_0();
bevt_3_ta_ph = bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevo_0;
bevt_1_ta_ph = bevt_2_ta_ph.bem_get_1(bevt_3_ta_ph);
bevt_0_ta_ph = bem_createInstance_1((BEC_2_4_6_TextString) bevt_1_ta_ph );
bevl_x = bevt_0_ta_ph.bemd_0(976077722);
bevt_4_ta_ph = bevl_x.bemd_1(-803683878, beva_params);
return bevt_4_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {309, 309, 309, 309, 309, 316, 316, 316, 316, 316, 317, 317};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 20, 21, 30, 31, 32, 33, 34, 35, 36};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 309 17
new 0 309 17
assign 1 309 18
argsGet 0 309 18
assign 1 309 19
new 1 309 19
assign 1 309 20
main 1 309 20
return 1 309 21
assign 1 316 30
orderedGet 0 316 30
assign 1 316 31
new 0 316 31
assign 1 316 32
get 1 316 32
assign 1 316 33
createInstance 1 316 33
assign 1 316 34
new 0 316 34
assign 1 317 35
main 1 317 35
return 1 317 36
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1938521961: return bem_create_0();
case 1428196909: return bem_deserializeClassNameGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case 1469761457: return bem_serializeToString_0();
case -1120775249: return bem_classNameGet_0();
case -559654393: return bem_sourceFileNameGet_0();
case 976077722: return bem_new_0();
case -1359840989: return bem_toAny_0();
case -129765629: return bem_print_0();
case -1677294751: return bem_hashGet_0();
case -1660007365: return bem_iteratorGet_0();
case 126164297: return bem_serializationIteratorGet_0();
case -1640020074: return bem_toString_0();
case -374496050: return bem_tagGet_0();
case -1530492540: return bem_many_0();
case 921209725: return bem_echo_0();
case -1606863806: return bem_fieldIteratorGet_0();
case -1483834827: return bem_copy_0();
case -1754862223: return bem_main_0();
case 2028199664: return bem_once_0();
case 1963846645: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1414981672: return bem_defined_1(bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case -1789648416: return bem_def_1(bevd_0);
case -803683878: return bem_main_1((BEC_2_6_10_SystemParameters) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(33, becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_7_18_SystemStartupMainWithParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst = (BEC_3_6_7_18_SystemStartupMainWithParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_type;
}
}
