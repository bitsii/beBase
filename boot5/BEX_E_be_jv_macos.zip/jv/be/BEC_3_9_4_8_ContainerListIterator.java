package be;
/* IO:File: source/base/List.be */
public final class BEC_3_9_4_8_ContainerListIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_4_8_ContainerListIterator() { }
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_9_4_8_ContainerListIterator_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_9_4_8_ContainerListIterator_bevo_1 = (new BEC_2_4_3_MathInt(-1));
public static BEC_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;

public static BET_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_4_3_MathInt bevp_npos;
public BEC_3_9_4_8_ContainerListIterator bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevp_npos = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) throws Throwable {
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_4_ContainerList) beva_a;
bevp_npos = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_containerGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_3_9_4_8_ContainerListIterator_bevo_0;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_4_tmpany_phold = bevp_list.bem_lengthGet_0();
if (bevp_pos.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 34 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 34 */
 else  /* Line: 34 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 34 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 35 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_currentGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevp_npos.bevi_int = bevp_pos.bevi_int;
bevp_npos.bevi_int++;
bevt_2_tmpany_phold = bece_BEC_3_9_4_8_ContainerListIterator_bevo_1;
if (bevp_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_4_tmpany_phold = bevp_list.bem_lengthGet_0();
if (bevp_npos.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
 else  /* Line: 51 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 51 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 52 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_pos.bevi_int++;
bevt_0_tmpany_phold = bevp_list.bem_get_1(bevp_pos);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevp_pos.bevi_int++;
bevt_0_tmpany_phold = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
bevp_pos.bevi_int += beva_multiNullCount.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_posGetDirect_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_4_8_ContainerListIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_listGetDirect_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_4_8_ContainerListIterator bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nposGet_0() throws Throwable {
return bevp_npos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_nposGetDirect_0() throws Throwable {
return bevp_npos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_nposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_npos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_4_8_ContainerListIterator bem_nposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_npos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 18, 19, 24, 25, 26, 30, 34, 34, 34, 34, 34, 34, 0, 0, 0, 35, 35, 37, 37, 41, 41, 45, 45, 49, 50, 51, 51, 51, 51, 51, 51, 0, 0, 0, 52, 52, 54, 54, 58, 59, 59, 63, 64, 64, 68, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 21, 25, 26, 27, 31, 41, 42, 47, 48, 49, 54, 55, 58, 62, 65, 66, 68, 69, 73, 74, 78, 79, 89, 90, 91, 92, 97, 98, 99, 104, 105, 108, 112, 115, 116, 118, 119, 123, 124, 125, 129, 130, 131, 134, 138, 141, 144, 148, 152, 155, 158, 162, 166, 169, 172, 176};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 18
new 0 17 18
assign 1 18 19
new 0 18 19
assign 1 18 20
new 1 18 20
assign 1 19 21
new 0 19 21
assign 1 24 25
new 0 24 25
assign 1 25 26
assign 1 26 27
new 0 26 27
return 1 30 31
assign 1 34 41
new 0 34 41
assign 1 34 42
greater 1 34 47
assign 1 34 48
lengthGet 0 34 48
assign 1 34 49
lesser 1 34 54
assign 1 0 55
assign 1 0 58
assign 1 0 62
assign 1 35 65
new 0 35 65
return 1 35 66
assign 1 37 68
new 0 37 68
return 1 37 69
assign 1 41 73
get 1 41 73
return 1 41 74
assign 1 45 78
put 2 45 78
return 1 45 79
setValue 1 49 89
incrementValue 0 50 90
assign 1 51 91
new 0 51 91
assign 1 51 92
greaterEquals 1 51 97
assign 1 51 98
lengthGet 0 51 98
assign 1 51 99
lesser 1 51 104
assign 1 0 105
assign 1 0 108
assign 1 0 112
assign 1 52 115
new 0 52 115
return 1 52 116
assign 1 54 118
new 0 54 118
return 1 54 119
incrementValue 0 58 123
assign 1 59 124
get 1 59 124
return 1 59 125
incrementValue 0 63 129
assign 1 64 130
put 2 64 130
return 1 64 131
addValue 1 68 134
return 1 0 138
return 1 0 141
assign 1 0 144
assign 1 0 148
return 1 0 152
return 1 0 155
assign 1 0 158
assign 1 0 162
return 1 0 166
return 1 0 169
assign 1 0 172
assign 1 0 176
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 381461124: return bem_posGetDirect_0();
case -1203535797: return bem_toAny_0();
case -1166462165: return bem_iteratorGet_0();
case -1191299721: return bem_deserializeClassNameGet_0();
case -260111055: return bem_print_0();
case 1227289471: return bem_hashGet_0();
case 740465458: return bem_new_0();
case -1348350074: return bem_create_0();
case 1121016978: return bem_currentGet_0();
case 1492509752: return bem_listGetDirect_0();
case -736476180: return bem_serializeContents_0();
case -977329190: return bem_nposGetDirect_0();
case 1567955799: return bem_fieldIteratorGet_0();
case 1840305191: return bem_serializeToString_0();
case -844497155: return bem_tagGet_0();
case 351178267: return bem_echo_0();
case -383147285: return bem_serializationIteratorGet_0();
case -557938157: return bem_toString_0();
case -2039624597: return bem_sourceFileNameGet_0();
case -888878530: return bem_listGet_0();
case 1385317771: return bem_hasCurrentGet_0();
case 119772031: return bem_posGet_0();
case 748701321: return bem_nposGet_0();
case 1540627001: return bem_classNameGet_0();
case 861390686: return bem_hasNextGet_0();
case -295279542: return bem_once_0();
case 1796376822: return bem_containerGet_0();
case -1486852325: return bem_copy_0();
case -5604421: return bem_many_0();
case -243903584: return bem_fieldNamesGet_0();
case -1237394863: return bem_nextGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 681538010: return bem_notEquals_1(bevd_0);
case -1429869274: return bem_nextSet_1(bevd_0);
case -1073473368: return bem_listSetDirect_1(bevd_0);
case 533476555: return bem_listSet_1(bevd_0);
case -1452100978: return bem_nposSetDirect_1(bevd_0);
case -1258811879: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2039711690: return bem_undef_1(bevd_0);
case 1982162578: return bem_nposSet_1(bevd_0);
case -578081598: return bem_posSet_1(bevd_0);
case 1839755987: return bem_otherType_1(bevd_0);
case 1544353280: return bem_otherClass_1(bevd_0);
case -1833499715: return bem_currentSet_1(bevd_0);
case 958315163: return bem_sameType_1(bevd_0);
case 1647627603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -593937181: return bem_copyTo_1(bevd_0);
case -1153918774: return bem_posSetDirect_1(bevd_0);
case -218864081: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1748281966: return bem_sameObject_1(bevd_0);
case 1724749097: return bem_undefined_1(bevd_0);
case -1670790162: return bem_sameClass_1(bevd_0);
case -387830191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2100440987: return bem_def_1(bevd_0);
case 551786219: return bem_new_1(bevd_0);
case -67300059: return bem_equals_1(bevd_0);
case -323742444: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1187046692: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1783125070: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1046047039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1868703996: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -528171684: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1304899076: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1671846119: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 520681709: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_4_8_ContainerListIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_9_4_8_ContainerListIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_4_8_ContainerListIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst = (BEC_3_9_4_8_ContainerListIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;
}
}
