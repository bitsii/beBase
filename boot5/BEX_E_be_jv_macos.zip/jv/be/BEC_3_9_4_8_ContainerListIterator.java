package be;
/* IO:File: source/base/List.be */
public final class BEC_3_9_4_8_ContainerListIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_4_8_ContainerListIterator() { }
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;

public static BET_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_4_3_MathInt bevp_npos;
public BEC_2_4_3_MathInt bevp_none;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_3_9_4_8_ContainerListIterator bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_npos = (new BEC_2_4_3_MathInt());
bevp_none = (new BEC_2_4_3_MathInt(-1));
bevp_zero = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) throws Throwable {
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_4_ContainerList) beva_a;
bevp_npos = (new BEC_2_4_3_MathInt());
bevp_none = (new BEC_2_4_3_MathInt(-1));
bevp_zero = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_containerGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (bevp_pos.bevi_int > bevp_zero.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_3_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_pos.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 45*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_currentGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevp_npos.bevi_int = bevp_pos.bevi_int;
bevp_npos.bevi_int++;
if (bevp_pos.bevi_int >= bevp_none.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 61*/ {
bevt_3_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_npos.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 61*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 61*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 61*/
 else /* Line: 61*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 61*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 62*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
bevp_pos.bevi_int += beva_multiNullCount.bevi_int;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 24, 25, 26, 27, 32, 33, 34, 35, 36, 40, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 47, 47, 51, 51, 55, 55, 59, 60, 61, 61, 61, 61, 61, 0, 0, 0, 62, 62, 64, 64, 68, 69, 69, 73, 74, 74, 78};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 21, 22, 23, 27, 28, 29, 30, 31, 35, 44, 49, 50, 51, 56, 57, 60, 64, 67, 68, 70, 71, 75, 76, 80, 81, 90, 91, 92, 97, 98, 99, 104, 105, 108, 112, 115, 116, 118, 119, 123, 124, 125, 129, 130, 131, 134};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 18
new 0 23 18
assign 1 24 19
new 0 24 19
assign 1 24 20
new 1 24 20
assign 1 25 21
new 0 25 21
assign 1 26 22
new 0 26 22
assign 1 27 23
new 0 27 23
assign 1 32 27
new 0 32 27
assign 1 33 28
assign 1 34 29
new 0 34 29
assign 1 35 30
new 0 35 30
assign 1 36 31
new 0 36 31
return 1 40 35
assign 1 44 44
greater 1 44 49
assign 1 44 50
lengthGet 0 44 50
assign 1 44 51
lesser 1 44 56
assign 1 0 57
assign 1 0 60
assign 1 0 64
assign 1 45 67
new 0 45 67
return 1 45 68
assign 1 47 70
new 0 47 70
return 1 47 71
assign 1 51 75
get 1 51 75
return 1 51 76
assign 1 55 80
put 2 55 80
return 1 55 81
setValue 1 59 90
incrementValue 0 60 91
assign 1 61 92
greaterEquals 1 61 97
assign 1 61 98
lengthGet 0 61 98
assign 1 61 99
lesser 1 61 104
assign 1 0 105
assign 1 0 108
assign 1 0 112
assign 1 62 115
new 0 62 115
return 1 62 116
assign 1 64 118
new 0 64 118
return 1 64 119
incrementValue 0 68 123
assign 1 69 124
get 1 69 124
return 1 69 125
incrementValue 0 73 129
assign 1 74 130
put 2 74 130
return 1 74 131
addValue 1 78 134
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1116049816: return bem_toString_0();
case -1454436377: return bem_hasCurrentGet_0();
case -764759782: return bem_containerGet_0();
case 2021446686: return bem_create_0();
case -939507828: return bem_currentGet_0();
case 201436634: return bem_print_0();
case -877152576: return bem_hasNextGet_0();
case -1602239310: return bem_new_0();
case -907463432: return bem_copy_0();
case 1407534539: return bem_iteratorGet_0();
case -1827671744: return bem_hashGet_0();
case -581425072: return bem_nextGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -286938938: return bem_nextSet_1(bevd_0);
case 1729413977: return bem_print_1(bevd_0);
case 1989503752: return bem_copyTo_1(bevd_0);
case -26650563: return bem_new_1(bevd_0);
case 1546367217: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 2018243061: return bem_currentSet_1(bevd_0);
case -1291367990: return bem_equals_1(bevd_0);
case -1812901017: return bem_def_1(bevd_0);
case -471447072: return bem_notEquals_1(bevd_0);
case 505990086: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1018458287: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -994154646: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 241691596: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -993790175: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_4_8_ContainerListIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_9_4_8_ContainerListIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_4_8_ContainerListIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst = (BEC_3_9_4_8_ContainerListIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;
}
}
