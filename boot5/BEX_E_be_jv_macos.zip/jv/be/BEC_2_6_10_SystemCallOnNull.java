package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_10_SystemCallOnNull extends BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public BEC_2_6_10_SystemCallOnNull bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {391};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 391 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2079582721: return bem_toString_0();
case 642715944: return bem_emitLangGetDirect_0();
case -1791746868: return bem_print_0();
case -221938536: return bem_framesTextGetDirect_0();
case -579194210: return bem_iteratorGet_0();
case -980602152: return bem_sourceFileNameGet_0();
case 1476265575: return bem_toAny_0();
case 423498542: return bem_lineNumberGetDirect_0();
case 11313755: return bem_echo_0();
case -57021657: return bem_lineNumberGet_0();
case 334571614: return bem_many_0();
case -1380185335: return bem_klassNameGet_0();
case -1430069919: return bem_serializeContents_0();
case 1532260226: return bem_langGetDirect_0();
case -1682958828: return bem_tagGet_0();
case -621270081: return bem_new_0();
case 245621341: return bem_getFrameText_0();
case 334819431: return bem_fileNameGetDirect_0();
case -1110905180: return bem_methodNameGet_0();
case -1160220672: return bem_framesTextGet_0();
case 1978095141: return bem_descriptionGet_0();
case 1005589307: return bem_translateEmittedExceptionInner_0();
case -1168657718: return bem_create_0();
case 448246445: return bem_fieldNamesGet_0();
case 577869439: return bem_serializeToString_0();
case 74208968: return bem_langGet_0();
case 1360695782: return bem_framesGet_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case -2051299175: return bem_descriptionGetDirect_0();
case -1830288833: return bem_translatedGet_0();
case -1527749920: return bem_methodNameGetDirect_0();
case -630860247: return bem_klassNameGetDirect_0();
case 515581655: return bem_framesGetDirect_0();
case 1568711247: return bem_fieldIteratorGet_0();
case -1045898755: return bem_classNameGet_0();
case -1780119566: return bem_fileNameGet_0();
case -165278261: return bem_hashGet_0();
case -1453283329: return bem_vvGetDirect_0();
case 1644034151: return bem_translatedGetDirect_0();
case -1406264904: return bem_copy_0();
case -1105389359: return bem_translateEmittedException_0();
case -1489022328: return bem_once_0();
case 572016682: return bem_serializationIteratorGet_0();
case -1003747168: return bem_vvGet_0();
case -787016625: return bem_emitLangGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -599428669: return bem_otherType_1(bevd_0);
case -151024052: return bem_klassNameSet_1(bevd_0);
case 407961876: return bem_klassNameSetDirect_1(bevd_0);
case -1527340651: return bem_translatedSet_1(bevd_0);
case -2132524576: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1813695153: return bem_vvSetDirect_1(bevd_0);
case -2132348963: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 727957446: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -554533832: return bem_langSet_1(bevd_0);
case -552335183: return bem_lineNumberSet_1(bevd_0);
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case -577020283: return bem_fileNameSetDirect_1(bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -679358539: return bem_methodNameSetDirect_1(bevd_0);
case 1049915463: return bem_lineNumberSetDirect_1(bevd_0);
case 1452948486: return bem_fileNameSet_1(bevd_0);
case 1077167076: return bem_langSetDirect_1(bevd_0);
case -871774941: return bem_methodNameSet_1(bevd_0);
case -201325754: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 729511565: return bem_vvSet_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case -962786841: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 366739155: return bem_framesTextSetDirect_1(bevd_0);
case -27149117: return bem_descriptionSet_1(bevd_0);
case 1008991845: return bem_descriptionSetDirect_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case -1074533146: return bem_emitLangSet_1(bevd_0);
case 1171039333: return bem_new_1(bevd_0);
case 482118886: return bem_emitLangSetDirect_1(bevd_0);
case -1631882034: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case 1959298846: return bem_translatedSetDirect_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1449504830: return bem_framesSetDirect_1(bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case 1292863348: return bem_framesSet_1(bevd_0);
case 507437527: return bem_framesTextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -813229685: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemCallOnNull();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
