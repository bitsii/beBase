package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_10_SystemCallOnNull extends BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public BEC_2_6_10_SystemCallOnNull bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {366};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 366 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -550828992: return bem_descriptionGetDirect_0();
case 657440259: return bem_many_0();
case -2026315780: return bem_getFrameText_0();
case -2113709188: return bem_fileNameGetDirect_0();
case 373871049: return bem_copy_0();
case 37115722: return bem_toAny_0();
case 149300560: return bem_sourceFileNameGet_0();
case 80893459: return bem_langGetDirect_0();
case 368405588: return bem_echo_0();
case -119078806: return bem_methodNameGet_0();
case -105000797: return bem_framesTextGetDirect_0();
case -1360047774: return bem_serializeToString_0();
case 1515770339: return bem_langGet_0();
case 1712919396: return bem_serializationIteratorGet_0();
case 2021293669: return bem_translatedGetDirect_0();
case -1497736169: return bem_new_0();
case 1401146539: return bem_klassNameGet_0();
case -1722753261: return bem_klassNameGetDirect_0();
case 2127251181: return bem_fileNameGet_0();
case 1090346168: return bem_lineNumberGet_0();
case 599867576: return bem_translatedGet_0();
case 1949327102: return bem_emitLangGetDirect_0();
case 144782273: return bem_once_0();
case -451287241: return bem_iteratorGet_0();
case 1891972683: return bem_translateEmittedException_0();
case 405076684: return bem_vvGetDirect_0();
case -502261135: return bem_lineNumberGetDirect_0();
case 1260713952: return bem_fieldNamesGet_0();
case -131396274: return bem_classNameGet_0();
case 1727874164: return bem_emitLangGet_0();
case -462620097: return bem_framesGetDirect_0();
case 1194402370: return bem_descriptionGet_0();
case 166156356: return bem_hashGet_0();
case 351181957: return bem_vvGet_0();
case 2126472329: return bem_framesGet_0();
case 938978826: return bem_serializeContents_0();
case 1010970574: return bem_deserializeClassNameGet_0();
case -794542805: return bem_fieldIteratorGet_0();
case 652618710: return bem_print_0();
case -320063974: return bem_framesTextGet_0();
case -574764269: return bem_methodNameGetDirect_0();
case -512173810: return bem_tagGet_0();
case 1012944178: return bem_create_0();
case 874045436: return bem_translateEmittedExceptionInner_0();
case 884758076: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -675060011: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -442448216: return bem_copyTo_1(bevd_0);
case -1418198617: return bem_def_1(bevd_0);
case 1054812617: return bem_lineNumberSetDirect_1(bevd_0);
case -1188339227: return bem_framesTextSet_1(bevd_0);
case -926157429: return bem_equals_1(bevd_0);
case 1450913634: return bem_defined_1(bevd_0);
case -85263635: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 2044588239: return bem_otherClass_1(bevd_0);
case 1606350042: return bem_descriptionSetDirect_1(bevd_0);
case -1952204646: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1849842647: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 210827851: return bem_framesSet_1(bevd_0);
case -1987104456: return bem_langSet_1(bevd_0);
case -1434589659: return bem_undef_1(bevd_0);
case 921447060: return bem_emitLangSetDirect_1(bevd_0);
case 151182661: return bem_klassNameSet_1(bevd_0);
case -142579862: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -428093264: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1811624466: return bem_translatedSet_1(bevd_0);
case -125059667: return bem_fileNameSet_1(bevd_0);
case 1184632884: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 197784087: return bem_methodNameSetDirect_1(bevd_0);
case -1340973491: return bem_sameType_1(bevd_0);
case -1727514691: return bem_vvSet_1(bevd_0);
case -1546327294: return bem_emitLangSet_1(bevd_0);
case 1261659295: return bem_framesSetDirect_1(bevd_0);
case 838715895: return bem_vvSetDirect_1(bevd_0);
case 2147106503: return bem_methodNameSet_1(bevd_0);
case -33323511: return bem_framesTextSetDirect_1(bevd_0);
case -367147919: return bem_new_1(bevd_0);
case 151335923: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -110133729: return bem_langSetDirect_1(bevd_0);
case 1627884339: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1122540139: return bem_fileNameSetDirect_1(bevd_0);
case -2033993347: return bem_sameObject_1(bevd_0);
case -1300198350: return bem_descriptionSet_1(bevd_0);
case 773892154: return bem_sameClass_1(bevd_0);
case -2026703354: return bem_translatedSetDirect_1(bevd_0);
case 974930963: return bem_undefined_1(bevd_0);
case 729330370: return bem_lineNumberSet_1(bevd_0);
case -1404757774: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1691038775: return bem_notEquals_1(bevd_0);
case 1759130775: return bem_klassNameSetDirect_1(bevd_0);
case 46811792: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -330880231: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1368517810: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1351268593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1842958248: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 840782676: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 498622947: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1807714621: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -766999630: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemCallOnNull();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
