package be;
/* IO:File: source/base/Functions.be */
public class BEC_2_6_6_SystemMethod extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemMethod() { }
private static byte[] becc_BEC_2_6_6_SystemMethod_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_6_6_SystemMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemMethod_bels_0 = {0x5F};
public static BEC_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_inst;

public static BET_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_4_3_MathInt bevp_ac;
public BEC_2_6_6_SystemMethod bem_new_2(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva_nameac) throws Throwable {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl__ac = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemMethod bevt_5_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemMethod_bels_0));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_name = beva_nameac.bem_substring_2(bevt_1_ta_ph, bevl_cd);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_3_ta_ph = bevl_cd.bem_add_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_nameac.bem_substring_1(bevt_3_ta_ph);
bevl__ac = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_ta_ph);
bevt_5_ta_ph = bem_new_3(beva__target, bevl_name, bevl__ac);
return (BEC_2_6_6_SystemMethod) bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_4_3_MathInt beva__ac) throws Throwable {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_ac = beva__ac;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-1738406137, bevp_callName, beva_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_targetGetDirect_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGet_0() throws Throwable {
return bevp_callName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_callNameGetDirect_0() throws Throwable {
return bevp_callName;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acGet_0() throws Throwable {
return bevp_ac;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_acGetDirect_0() throws Throwable {
return bevp_ac;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_acSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_acSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {35, 35, 36, 36, 37, 37, 37, 37, 38, 38, 43, 44, 45, 54, 55, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 44, 45, 48, 51, 54, 58, 62, 65, 68, 72, 76, 79, 82, 86};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 35 25
new 0 35 25
assign 1 35 26
rfind 1 35 26
assign 1 36 27
new 0 36 27
assign 1 36 28
substring 2 36 28
assign 1 37 29
new 0 37 29
assign 1 37 30
add 1 37 30
assign 1 37 31
substring 1 37 31
assign 1 37 32
new 1 37 32
assign 1 38 33
new 3 38 33
return 1 38 34
assign 1 43 37
assign 1 44 38
assign 1 45 39
assign 1 54 44
invoke 2 54 44
return 1 55 45
return 1 0 48
return 1 0 51
assign 1 0 54
assign 1 0 58
return 1 0 62
return 1 0 65
assign 1 0 68
assign 1 0 72
return 1 0 76
return 1 0 79
assign 1 0 82
assign 1 0 86
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1263154564: return bem_new_0();
case 1615402015: return bem_create_0();
case 1478297754: return bem_callNameGet_0();
case 1179961651: return bem_serializeToString_0();
case 1390308585: return bem_targetGet_0();
case 37637962: return bem_print_0();
case 1333799692: return bem_tagGet_0();
case 340030523: return bem_classNameGet_0();
case 1546143657: return bem_echo_0();
case -1001743190: return bem_fieldNamesGet_0();
case 1445801145: return bem_serializationIteratorGet_0();
case 187459333: return bem_targetGetDirect_0();
case -800146552: return bem_serializeContents_0();
case -2095499202: return bem_fieldIteratorGet_0();
case 147497190: return bem_iteratorGet_0();
case -794718926: return bem_copy_0();
case 2083061688: return bem_callNameGetDirect_0();
case 677199271: return bem_acGetDirect_0();
case -676070096: return bem_sourceFileNameGet_0();
case -794062933: return bem_hashGet_0();
case 1577124637: return bem_deserializeClassNameGet_0();
case 219112807: return bem_toString_0();
case -1830841046: return bem_acGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1981346500: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 550061094: return bem_undef_1(bevd_0);
case -1534545800: return bem_otherType_1(bevd_0);
case 1419064041: return bem_sameObject_1(bevd_0);
case 725927434: return bem_acSetDirect_1(bevd_0);
case -19945451: return bem_notEquals_1(bevd_0);
case 1661150226: return bem_def_1(bevd_0);
case 1051782355: return bem_targetSet_1(bevd_0);
case -1516197240: return bem_targetSetDirect_1(bevd_0);
case 739117568: return bem_otherClass_1(bevd_0);
case -1935405349: return bem_sameType_1(bevd_0);
case -1868129616: return bem_copyTo_1(bevd_0);
case 1313580542: return bem_callNameSetDirect_1(bevd_0);
case 250302014: return bem_equals_1(bevd_0);
case 1405755430: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1241179176: return bem_acSet_1(bevd_0);
case -2022815028: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2044993814: return bem_sameClass_1(bevd_0);
case 1929553629: return bem_callNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -938540681: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2115080364: return bem_new_2(bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1738406137: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1708873965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 853768892: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2112740717: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1135875822: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemMethod_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_6_SystemMethod_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemMethod();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst = (BEC_2_6_6_SystemMethod) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_type;
}
}
