package be;
/* IO:File: source/base/Functions.be */
public class BEC_2_6_6_SystemMethod extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemMethod() { }
private static byte[] becc_BEC_2_6_6_SystemMethod_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_6_6_SystemMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_inst;

public static BET_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_4_3_MathInt bevp_ac;
public BEC_2_6_6_SystemMethod bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_4_3_MathInt beva__ac) throws Throwable {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_ac = beva__ac;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(475074339, bevp_callName, beva_args);
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_targetGetDirect_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGet_0() throws Throwable {
return bevp_callName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_callNameGetDirect_0() throws Throwable {
return bevp_callName;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acGet_0() throws Throwable {
return bevp_ac;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_acGetDirect_0() throws Throwable {
return bevp_ac;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_acSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_acSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {36, 37, 38, 47, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 22, 23, 26, 29, 32, 36, 40, 43, 46, 50, 54, 57, 60, 64};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 36 15
assign 1 37 16
assign 1 38 17
assign 1 47 22
invoke 2 47 22
return 1 48 23
return 1 0 26
return 1 0 29
assign 1 0 32
assign 1 0 36
return 1 0 40
return 1 0 43
assign 1 0 46
assign 1 0 50
return 1 0 54
return 1 0 57
assign 1 0 60
assign 1 0 64
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2079582721: return bem_toString_0();
case -579194210: return bem_iteratorGet_0();
case 572016682: return bem_serializationIteratorGet_0();
case -1682958828: return bem_tagGet_0();
case 1568711247: return bem_fieldIteratorGet_0();
case -1489022328: return bem_once_0();
case 1331939931: return bem_callNameGetDirect_0();
case -877991742: return bem_acGet_0();
case 577869439: return bem_serializeToString_0();
case -621270081: return bem_new_0();
case 1476265575: return bem_toAny_0();
case 543209227: return bem_callNameGet_0();
case 1319988239: return bem_targetGet_0();
case -165278261: return bem_hashGet_0();
case 11313755: return bem_echo_0();
case -1430069919: return bem_serializeContents_0();
case 1058487615: return bem_acGetDirect_0();
case -1045898755: return bem_classNameGet_0();
case -980602152: return bem_sourceFileNameGet_0();
case -1406264904: return bem_copy_0();
case 448246445: return bem_fieldNamesGet_0();
case 817806515: return bem_targetGetDirect_0();
case -1791746868: return bem_print_0();
case -1168657718: return bem_create_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case 334571614: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case -135829505: return bem_acSet_1(bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case 382700034: return bem_callNameSetDirect_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case -1514043733: return bem_targetSet_1(bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
case -1853420133: return bem_acSetDirect_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case 689976132: return bem_callNameSet_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case 1820140508: return bem_targetSetDirect_1(bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 189248150: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemMethod_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_6_SystemMethod_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemMethod();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst = (BEC_2_6_6_SystemMethod) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_type;
}
}
