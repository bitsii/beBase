package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOWriter extends BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOWriter() { }

   
    public java.io.OutputStream bevi_os;
    
   private static byte[] becc_BEC_2_2_6_IOWriter_clname = {0x49,0x4F,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_2_6_IOWriter bece_BEC_2_2_6_IOWriter_bevs_inst;
public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_2_6_IOWriter bem_new_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_vfileGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_extOpen_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_close_0() throws Throwable {

      if (this.bevi_os != null) {
        this.bevi_os.close();
        this.bevi_os = null;
      }
      bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOWriter bem_write_1(BEC_2_4_6_TextString beva_stri) throws Throwable {

      this.bevi_os.write(beva_stri.bevi_bytes, 0, beva_stri.bevp_size.bevi_int);
      return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {469, 480, 517, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 25, 34, 43, 46};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 469 15
new 0 469 15
assign 1 480 25
new 0 480 25
assign 1 517 34
new 0 517 34
return 1 0 43
assign 1 0 46
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1704001450: return bem_serializationIteratorGet_0();
case -868754815: return bem_serializeContents_0();
case -1615155660: return bem_sourceFileNameGet_0();
case 1724993772: return bem_many_0();
case -1207227016: return bem_toAny_0();
case 1107063436: return bem_create_0();
case 765609192: return bem_close_0();
case 408952750: return bem_isClosedGet_0();
case 331067077: return bem_iteratorGet_0();
case 1586265763: return bem_copy_0();
case -1408773835: return bem_extOpen_0();
case 1550782506: return bem_print_0();
case 1618197244: return bem_new_0();
case 755005070: return bem_echo_0();
case 353744263: return bem_once_0();
case 1710183535: return bem_vfileGet_0();
case -1674644863: return bem_serializeToString_0();
case 2089277173: return bem_classNameGet_0();
case 836604081: return bem_tagGet_0();
case -2035802034: return bem_hashGet_0();
case -1432966592: return bem_deserializeClassNameGet_0();
case -2079261808: return bem_toString_0();
case -1144635038: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -102763151: return bem_defined_1(bevd_0);
case 1820941401: return bem_def_1(bevd_0);
case 729465196: return bem_equals_1(bevd_0);
case -2018158572: return bem_sameType_1(bevd_0);
case -1713192448: return bem_isClosedSet_1(bevd_0);
case -3701728: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -1285524271: return bem_sameClass_1(bevd_0);
case 1292274364: return bem_undefined_1(bevd_0);
case 894987079: return bem_undef_1(bevd_0);
case 567619203: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1181026029: return bem_copyTo_1(bevd_0);
case -467831865: return bem_otherClass_1(bevd_0);
case -1690226246: return bem_notEquals_1(bevd_0);
case -955519709: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1743252117: return bem_sameObject_1(bevd_0);
case 1975786452: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1053963189: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1353658551: return bem_vfileSet_1(bevd_0);
case -864903677: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1632202498: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1527927145: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1067491989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1241720452: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2041527697: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1713973958: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1814064163: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOWriter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOWriter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_6_IOWriter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_inst = (BEC_2_2_6_IOWriter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_inst;
}
}
