package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_one = (new BEC_2_4_3_MathInt(1));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(-992168582);
bevt_1_ta_ph = bevl_i.bemd_0(-1963698239);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1840253599);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1197*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1198*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(742368689);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1202*/ {
bevt_4_ta_ph = bevl_i.bemd_0(-1963698239);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1202*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(742368689);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1204*/
 else /* Line: 1202*/ {
break;
} /* Line: 1202*/
} /* Line: 1202*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1214*/ {
bevt_3_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 1214*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_4_ta_ph = bevl_step.bem_equals_1(bevp_space);
if (bevt_4_ta_ph.bevi_bool)/* Line: 1216*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1216*/ {
bevt_5_ta_ph = bevl_step.bem_equals_1(bevp_tab);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1216*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1216*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1216*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1216*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1216*/ {
bevt_6_ta_ph = bevl_step.bem_equals_1(bevp_cr);
if (bevt_6_ta_ph.bevi_bool)/* Line: 1216*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1216*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1216*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1216*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1216*/ {
bevt_7_ta_ph = bevl_step.bem_equals_1(bevp_unixNewline);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1216*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1216*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1216*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1216*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1217*/ {
bevl_end.bevi_int++;
} /* Line: 1218*/
 else /* Line: 1219*/ {
bevl_beg.bevi_int++;
} /* Line: 1220*/
} /* Line: 1217*/
 else /* Line: 1222*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_8_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1224*/
} /* Line: 1216*/
 else /* Line: 1214*/ {
break;
} /* Line: 1214*/
} /* Line: 1214*/
if (bevl_foundChar.bevi_bool)/* Line: 1227*/ {
bevt_10_ta_ph = beva_str.bem_lengthGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_9_ta_ph);
} /* Line: 1228*/
 else /* Line: 1229*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1230*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1236*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1236*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1236*/ {
return null;
} /* Line: 1236*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_lengthGet_0();
bevt_5_ta_ph = beva_b.bem_lengthGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1242*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1242*/ {
bevl_ai.bemd_1(1736190875, bevl_av);
bevl_bi.bemd_1(1736190875, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1245*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1246*/
bevl_i.bevi_int++;
} /* Line: 1242*/
 else /* Line: 1242*/ {
break;
} /* Line: 1242*/
} /* Line: 1242*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1253*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1253*/ {
bevt_3_ta_ph = beva_value.bem_lengthGet_0();
if (bevt_3_ta_ph.bevi_int < bevp_one.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1253*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1253*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1253*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1253*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1254*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1260*/ {
bevt_3_ta_ph = beva_value.bem_lengthGet_0();
if (bevt_3_ta_ph.bevi_int > bevp_zero.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1260*/
 else /* Line: 1260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1260*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1261*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNumSpace_1(BEC_2_4_6_TextString beva_toCheck) throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_length = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_length = beva_toCheck.bem_lengthGet_0();
bevt_4_ta_ph = beva_toCheck.bem_lengthGet_0();
bevl_ret = (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_ta_ph);
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1270*/ {
if (bevl_j.bevi_int < bevl_length.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 1270*/ {
beva_toCheck.bem_getInt_2(bevl_j, bevl_ic);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1272*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ic.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 1272*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1272*/
 else /* Line: 1272*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 1272*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1272*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_ic.bevi_int < bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 1272*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1272*/
 else /* Line: 1272*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1272*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1272*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1272*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 1272*/ {
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ic.bevi_int < bevt_17_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 1272*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1272*/
 else /* Line: 1272*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1272*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1272*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1272*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(32));
if (bevl_ic.bevi_int == bevt_19_ta_ph.bevi_int) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 1272*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1272*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1272*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1272*/ {
bevt_21_ta_ph = bevl_ret.bem_lengthGet_0();
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_22_ta_ph);
bevl_ret.bem_lengthSet_1(bevt_20_ta_ph);
bevl_ret.bem_setInt_2(bevl_j, bevl_ic);
} /* Line: 1274*/
bevl_j.bevi_int++;
} /* Line: 1270*/
 else /* Line: 1270*/ {
break;
} /* Line: 1270*/
} /* Line: 1270*/
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() throws Throwable {
return bevp_one;
} /*method end*/
public BEC_2_4_7_TextStrings bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1176, 1177, 1178, 1179, 1180, 1180, 1181, 1181, 1182, 1183, 1185, 1185, 1186, 1187, 1192, 1192, 1196, 1197, 1197, 1198, 1198, 1200, 1201, 1201, 1202, 1203, 1204, 1204, 1206, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 0, 1216, 0, 0, 0, 1216, 0, 0, 0, 1216, 0, 0, 1218, 1220, 1223, 1223, 1224, 1228, 1228, 1228, 1230, 1232, 1236, 1236, 0, 1236, 1236, 0, 0, 1236, 1237, 1237, 1237, 1237, 1238, 1239, 1240, 1241, 1242, 1242, 1242, 1243, 1244, 1245, 1246, 1246, 1246, 1242, 1249, 1249, 1249, 1253, 1253, 0, 1253, 1253, 1253, 0, 0, 1254, 1254, 1256, 1256, 1260, 1260, 1260, 1260, 1260, 0, 0, 0, 1261, 1261, 1263, 1263, 1267, 1268, 1269, 1269, 1270, 1270, 1270, 1271, 1272, 1272, 1272, 1272, 1272, 1272, 0, 0, 0, 0, 1272, 1272, 1272, 1272, 1272, 1272, 0, 0, 0, 0, 0, 0, 1272, 1272, 1272, 1272, 1272, 1272, 0, 0, 0, 0, 0, 0, 1272, 1272, 1272, 0, 0, 1273, 1273, 1273, 1273, 1274, 1270, 1277, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 53, 54, 65, 66, 67, 69, 70, 72, 73, 74, 77, 79, 80, 81, 87, 107, 108, 109, 110, 113, 115, 116, 118, 121, 123, 126, 130, 133, 135, 138, 142, 145, 147, 150, 155, 158, 162, 163, 164, 172, 173, 174, 177, 179, 200, 205, 206, 209, 214, 215, 218, 222, 224, 225, 226, 227, 228, 229, 230, 231, 232, 235, 240, 241, 242, 243, 245, 246, 247, 249, 255, 256, 257, 266, 271, 272, 275, 276, 281, 282, 285, 289, 290, 292, 293, 302, 307, 308, 309, 314, 315, 318, 322, 325, 326, 328, 329, 359, 360, 361, 362, 363, 366, 371, 372, 373, 374, 379, 380, 381, 386, 387, 390, 394, 397, 400, 401, 406, 407, 408, 413, 414, 417, 421, 424, 427, 431, 434, 435, 440, 441, 442, 447, 448, 451, 455, 458, 461, 465, 468, 469, 474, 475, 478, 482, 483, 484, 485, 486, 488, 494, 497, 500, 504, 507, 511, 514, 518, 521, 525, 528, 532, 535, 539, 542, 546, 549, 553, 556, 560, 563, 567, 570, 574, 577};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1176 35
new 0 1176 35
assign 1 1177 36
new 0 1177 36
assign 1 1178 37
new 0 1178 37
assign 1 1179 38
new 0 1179 38
assign 1 1180 39
new 0 1180 39
assign 1 1180 40
codeNew 1 1180 40
assign 1 1181 41
new 0 1181 41
assign 1 1181 42
codeNew 1 1181 42
assign 1 1182 43
new 0 1182 43
assign 1 1183 44
new 0 1183 44
assign 1 1185 45
new 0 1185 45
assign 1 1185 46
codeNew 1 1185 46
assign 1 1186 47
new 0 1186 47
assign 1 1187 48
new 0 1187 48
assign 1 1192 53
joinBuffer 2 1192 53
return 1 1192 54
assign 1 1196 65
iteratorGet 0 1196 65
assign 1 1197 66
hasNextGet 0 1197 66
assign 1 1197 67
not 0 1197 67
assign 1 1198 69
new 0 1198 69
return 1 1198 70
assign 1 1200 72
new 0 1200 72
assign 1 1201 73
nextGet 0 1201 73
addValue 1 1201 74
assign 1 1202 77
hasNextGet 0 1202 77
addValue 1 1203 79
assign 1 1204 80
nextGet 0 1204 80
addValue 1 1204 81
return 1 1206 87
assign 1 1210 107
new 0 1210 107
assign 1 1211 108
new 0 1211 108
assign 1 1212 109
new 0 1212 109
assign 1 1213 110
mbiterGet 0 1213 110
assign 1 1214 113
hasNextGet 0 1214 113
assign 1 1215 115
nextGet 0 1215 115
assign 1 1216 116
equals 1 1216 116
assign 1 0 118
assign 1 1216 121
equals 1 1216 121
assign 1 0 123
assign 1 0 126
assign 1 0 130
assign 1 1216 133
equals 1 1216 133
assign 1 0 135
assign 1 0 138
assign 1 0 142
assign 1 1216 145
equals 1 1216 145
assign 1 0 147
assign 1 0 150
incrementValue 0 1218 155
incrementValue 0 1220 158
assign 1 1223 162
new 0 1223 162
setValue 1 1223 163
assign 1 1224 164
new 0 1224 164
assign 1 1228 172
lengthGet 0 1228 172
assign 1 1228 173
subtract 1 1228 173
assign 1 1228 174
substring 2 1228 174
assign 1 1230 177
new 0 1230 177
return 1 1232 179
assign 1 1236 200
undef 1 1236 205
assign 1 0 206
assign 1 1236 209
undef 1 1236 214
assign 1 0 215
assign 1 0 218
return 1 1236 222
assign 1 1237 224
new 0 1237 224
assign 1 1237 225
lengthGet 0 1237 225
assign 1 1237 226
lengthGet 0 1237 226
assign 1 1237 227
min 2 1237 227
assign 1 1238 228
biterGet 0 1238 228
assign 1 1239 229
biterGet 0 1239 229
assign 1 1240 230
new 0 1240 230
assign 1 1241 231
new 0 1241 231
assign 1 1242 232
new 0 1242 232
assign 1 1242 235
lesser 1 1242 240
next 1 1243 241
next 1 1244 242
assign 1 1245 243
notEquals 1 1245 243
assign 1 1246 245
new 0 1246 245
assign 1 1246 246
substring 2 1246 246
return 1 1246 247
incrementValue 0 1242 249
assign 1 1249 255
new 0 1249 255
assign 1 1249 256
substring 2 1249 256
return 1 1249 257
assign 1 1253 266
undef 1 1253 271
assign 1 0 272
assign 1 1253 275
lengthGet 0 1253 275
assign 1 1253 276
lesser 1 1253 281
assign 1 0 282
assign 1 0 285
assign 1 1254 289
new 0 1254 289
return 1 1254 290
assign 1 1256 292
new 0 1256 292
return 1 1256 293
assign 1 1260 302
def 1 1260 307
assign 1 1260 308
lengthGet 0 1260 308
assign 1 1260 309
greater 1 1260 314
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 1261 325
new 0 1261 325
return 1 1261 326
assign 1 1263 328
new 0 1263 328
return 1 1263 329
assign 1 1267 359
new 0 1267 359
assign 1 1268 360
lengthGet 0 1268 360
assign 1 1269 361
lengthGet 0 1269 361
assign 1 1269 362
new 1 1269 362
assign 1 1270 363
new 0 1270 363
assign 1 1270 366
lesser 1 1270 371
getInt 2 1271 372
assign 1 1272 373
new 0 1272 373
assign 1 1272 374
greater 1 1272 379
assign 1 1272 380
new 0 1272 380
assign 1 1272 381
lesser 1 1272 386
assign 1 0 387
assign 1 0 390
assign 1 0 394
assign 1 0 397
assign 1 1272 400
new 0 1272 400
assign 1 1272 401
greater 1 1272 406
assign 1 1272 407
new 0 1272 407
assign 1 1272 408
lesser 1 1272 413
assign 1 0 414
assign 1 0 417
assign 1 0 421
assign 1 0 424
assign 1 0 427
assign 1 0 431
assign 1 1272 434
new 0 1272 434
assign 1 1272 435
greater 1 1272 440
assign 1 1272 441
new 0 1272 441
assign 1 1272 442
lesser 1 1272 447
assign 1 0 448
assign 1 0 451
assign 1 0 455
assign 1 0 458
assign 1 0 461
assign 1 0 465
assign 1 1272 468
new 0 1272 468
assign 1 1272 469
equals 1 1272 474
assign 1 0 475
assign 1 0 478
assign 1 1273 482
lengthGet 0 1273 482
assign 1 1273 483
new 0 1273 483
assign 1 1273 484
add 1 1273 484
lengthSet 1 1273 485
setInt 2 1274 486
incrementValue 0 1270 488
return 1 1277 494
return 1 0 497
assign 1 0 500
return 1 0 504
assign 1 0 507
return 1 0 511
assign 1 0 514
return 1 0 518
assign 1 0 521
return 1 0 525
assign 1 0 528
return 1 0 532
assign 1 0 535
return 1 0 539
assign 1 0 542
return 1 0 546
assign 1 0 549
return 1 0 553
assign 1 0 556
return 1 0 560
assign 1 0 563
return 1 0 567
assign 1 0 570
return 1 0 574
assign 1 0 577
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 16987715: return bem_new_0();
case -93130122: return bem_lfGet_0();
case -1466603265: return bem_colonGet_0();
case 1288797182: return bem_default_0();
case -320608485: return bem_toString_0();
case 1570674726: return bem_create_0();
case -678474722: return bem_print_0();
case -1780640215: return bem_zeroGet_0();
case 993101344: return bem_crGet_0();
case 614859423: return bem_unixNewlineGet_0();
case 2004322207: return bem_oneGet_0();
case 1042715784: return bem_quoteGet_0();
case -1817583380: return bem_spaceGet_0();
case -1952193259: return bem_copy_0();
case 1364504355: return bem_emptyGet_0();
case -992168582: return bem_iteratorGet_0();
case 1147722730: return bem_dosNewlineGet_0();
case 1598284741: return bem_tabGet_0();
case -71966292: return bem_newlineGet_0();
case -1593363650: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 5440256: return bem_print_1(bevd_0);
case 2143570660: return bem_notEquals_1(bevd_0);
case 1766299454: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -1679272790: return bem_crSet_1(bevd_0);
case 421133072: return bem_toAlphaNumSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1479299814: return bem_newlineSet_1(bevd_0);
case 967153379: return bem_emptySet_1(bevd_0);
case -1334630507: return bem_undef_1(bevd_0);
case -258108692: return bem_dosNewlineSet_1(bevd_0);
case 1200364408: return bem_copyTo_1(bevd_0);
case 967175966: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 198252181: return bem_tabSet_1(bevd_0);
case 506250572: return bem_lfSet_1(bevd_0);
case 829352666: return bem_colonSet_1(bevd_0);
case -1763258631: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -2045095560: return bem_def_1(bevd_0);
case -454238240: return bem_zeroSet_1(bevd_0);
case -1824551316: return bem_unixNewlineSet_1(bevd_0);
case -1954055815: return bem_spaceSet_1(bevd_0);
case 317504029: return bem_oneSet_1(bevd_0);
case -974275: return bem_equals_1(bevd_0);
case 103141132: return bem_quoteSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1869814166: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1491209441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1976895315: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1796225008: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 671415301: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -283223927: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -937076209: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
