package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(1676715436);
bevt_1_ta_ph = bevl_i.bemd_0(1031776864);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1563547147);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1299*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1300*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(-430730425);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1304*/ {
bevt_4_ta_ph = bevl_i.bemd_0(1031776864);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1304*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(-430730425);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1306*/
 else /* Line: 1304*/ {
break;
} /* Line: 1304*/
} /* Line: 1304*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1316*/ {
bevt_3_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 1316*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_4_ta_ph = bevl_step.bem_equals_1(bevp_space);
if (bevt_4_ta_ph.bevi_bool)/* Line: 1318*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1318*/ {
bevt_5_ta_ph = bevl_step.bem_equals_1(bevp_tab);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1318*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1318*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1318*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1318*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1318*/ {
bevt_6_ta_ph = bevl_step.bem_equals_1(bevp_cr);
if (bevt_6_ta_ph.bevi_bool)/* Line: 1318*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1318*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1318*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1318*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1318*/ {
bevt_7_ta_ph = bevl_step.bem_equals_1(bevp_unixNewline);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1318*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1318*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1318*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1318*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1319*/ {
bevl_end.bevi_int++;
} /* Line: 1320*/
 else /* Line: 1321*/ {
bevl_beg.bevi_int++;
} /* Line: 1322*/
} /* Line: 1319*/
 else /* Line: 1324*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_8_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1326*/
} /* Line: 1318*/
 else /* Line: 1316*/ {
break;
} /* Line: 1316*/
} /* Line: 1316*/
if (bevl_foundChar.bevi_bool)/* Line: 1329*/ {
bevt_10_ta_ph = beva_str.bem_sizeGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_9_ta_ph);
} /* Line: 1330*/
 else /* Line: 1331*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1332*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1338*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1338*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1338*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1338*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1338*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1338*/ {
return null;
} /* Line: 1338*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1344*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1344*/ {
bevl_ai.bemd_1(1646739635, bevl_av);
bevl_bi.bemd_1(1646739635, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1347*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1348*/
bevl_i.bevi_int++;
} /* Line: 1344*/
 else /* Line: 1344*/ {
break;
} /* Line: 1344*/
} /* Line: 1344*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(1676715436);
while (true)
/* Line: 1355*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(1031776864);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1355*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-430730425);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1356*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1357*/
} /* Line: 1356*/
 else /* Line: 1355*/ {
break;
} /* Line: 1355*/
} /* Line: 1355*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1364*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1364*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1364*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1365*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1371*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1371*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1371*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1371*/
 else /* Line: 1371*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1371*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1372*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1279, 1280, 1281, 1282, 1282, 1283, 1283, 1284, 1285, 1287, 1287, 1288, 1289, 1294, 1294, 1298, 1299, 1299, 1300, 1300, 1302, 1303, 1303, 1304, 1305, 1306, 1306, 1308, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 0, 1318, 0, 0, 0, 1318, 0, 0, 0, 1318, 0, 0, 1320, 1322, 1325, 1325, 1326, 1330, 1330, 1330, 1332, 1334, 1338, 1338, 0, 1338, 1338, 0, 0, 1338, 1339, 1339, 1339, 1339, 1340, 1341, 1342, 1343, 1344, 1344, 1344, 1345, 1346, 1347, 1348, 1348, 1348, 1344, 1351, 1351, 1351, 1355, 0, 1355, 1355, 1356, 1357, 1357, 1360, 1360, 1364, 1364, 0, 1364, 1364, 1364, 1364, 0, 0, 1365, 1365, 1367, 1367, 1371, 1371, 1371, 1371, 1371, 1371, 0, 0, 0, 1372, 1372, 1374, 1374, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 51, 52, 63, 64, 65, 67, 68, 70, 71, 72, 75, 77, 78, 79, 85, 105, 106, 107, 108, 111, 113, 114, 116, 119, 121, 124, 128, 131, 133, 136, 140, 143, 145, 148, 153, 156, 160, 161, 162, 170, 171, 172, 175, 177, 198, 203, 204, 207, 212, 213, 216, 220, 222, 223, 224, 225, 226, 227, 228, 229, 230, 233, 238, 239, 240, 241, 243, 244, 245, 247, 253, 254, 255, 264, 264, 267, 269, 270, 272, 273, 280, 281, 291, 296, 297, 300, 301, 302, 307, 308, 311, 315, 316, 318, 319, 329, 334, 335, 336, 337, 342, 343, 346, 350, 353, 354, 356, 357, 360, 363, 367, 370, 374, 377, 381, 384, 388, 391, 395, 398, 402, 405, 409, 412, 416, 419, 423, 426, 430, 433};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1279 34
new 0 1279 34
assign 1 1280 35
new 0 1280 35
assign 1 1281 36
new 0 1281 36
assign 1 1282 37
new 0 1282 37
assign 1 1282 38
codeNew 1 1282 38
assign 1 1283 39
new 0 1283 39
assign 1 1283 40
codeNew 1 1283 40
assign 1 1284 41
new 0 1284 41
assign 1 1285 42
new 0 1285 42
assign 1 1287 43
new 0 1287 43
assign 1 1287 44
codeNew 1 1287 44
assign 1 1288 45
new 0 1288 45
assign 1 1289 46
new 0 1289 46
assign 1 1294 51
joinBuffer 2 1294 51
return 1 1294 52
assign 1 1298 63
iteratorGet 0 1298 63
assign 1 1299 64
hasNextGet 0 1299 64
assign 1 1299 65
not 0 1299 65
assign 1 1300 67
new 0 1300 67
return 1 1300 68
assign 1 1302 70
new 0 1302 70
assign 1 1303 71
nextGet 0 1303 71
addValue 1 1303 72
assign 1 1304 75
hasNextGet 0 1304 75
addValue 1 1305 77
assign 1 1306 78
nextGet 0 1306 78
addValue 1 1306 79
return 1 1308 85
assign 1 1312 105
new 0 1312 105
assign 1 1313 106
new 0 1313 106
assign 1 1314 107
new 0 1314 107
assign 1 1315 108
mbiterGet 0 1315 108
assign 1 1316 111
hasNextGet 0 1316 111
assign 1 1317 113
nextGet 0 1317 113
assign 1 1318 114
equals 1 1318 114
assign 1 0 116
assign 1 1318 119
equals 1 1318 119
assign 1 0 121
assign 1 0 124
assign 1 0 128
assign 1 1318 131
equals 1 1318 131
assign 1 0 133
assign 1 0 136
assign 1 0 140
assign 1 1318 143
equals 1 1318 143
assign 1 0 145
assign 1 0 148
incrementValue 0 1320 153
incrementValue 0 1322 156
assign 1 1325 160
new 0 1325 160
setValue 1 1325 161
assign 1 1326 162
new 0 1326 162
assign 1 1330 170
sizeGet 0 1330 170
assign 1 1330 171
subtract 1 1330 171
assign 1 1330 172
substring 2 1330 172
assign 1 1332 175
new 0 1332 175
return 1 1334 177
assign 1 1338 198
undef 1 1338 203
assign 1 0 204
assign 1 1338 207
undef 1 1338 212
assign 1 0 213
assign 1 0 216
return 1 1338 220
assign 1 1339 222
new 0 1339 222
assign 1 1339 223
sizeGet 0 1339 223
assign 1 1339 224
sizeGet 0 1339 224
assign 1 1339 225
min 2 1339 225
assign 1 1340 226
biterGet 0 1340 226
assign 1 1341 227
biterGet 0 1341 227
assign 1 1342 228
new 0 1342 228
assign 1 1343 229
new 0 1343 229
assign 1 1344 230
new 0 1344 230
assign 1 1344 233
lesser 1 1344 238
next 1 1345 239
next 1 1346 240
assign 1 1347 241
notEquals 1 1347 241
assign 1 1348 243
new 0 1348 243
assign 1 1348 244
substring 2 1348 244
return 1 1348 245
incrementValue 0 1344 247
assign 1 1351 253
new 0 1351 253
assign 1 1351 254
substring 2 1351 254
return 1 1351 255
assign 1 1355 264
iteratorGet 0 0 264
assign 1 1355 267
hasNextGet 0 1355 267
assign 1 1355 269
nextGet 0 1355 269
assign 1 1356 270
isEmpty 1 1356 270
assign 1 1357 272
new 0 1357 272
return 1 1357 273
assign 1 1360 280
new 0 1360 280
return 1 1360 281
assign 1 1364 291
undef 1 1364 296
assign 1 0 297
assign 1 1364 300
sizeGet 0 1364 300
assign 1 1364 301
new 0 1364 301
assign 1 1364 302
lesser 1 1364 307
assign 1 0 308
assign 1 0 311
assign 1 1365 315
new 0 1365 315
return 1 1365 316
assign 1 1367 318
new 0 1367 318
return 1 1367 319
assign 1 1371 329
def 1 1371 334
assign 1 1371 335
sizeGet 0 1371 335
assign 1 1371 336
new 0 1371 336
assign 1 1371 337
greater 1 1371 342
assign 1 0 343
assign 1 0 346
assign 1 0 350
assign 1 1372 353
new 0 1372 353
return 1 1372 354
assign 1 1374 356
new 0 1374 356
return 1 1374 357
return 1 0 360
assign 1 0 363
return 1 0 367
assign 1 0 370
return 1 0 374
assign 1 0 377
return 1 0 381
assign 1 0 384
return 1 0 388
assign 1 0 391
return 1 0 395
assign 1 0 398
return 1 0 402
assign 1 0 405
return 1 0 409
assign 1 0 412
return 1 0 416
assign 1 0 419
return 1 0 423
assign 1 0 426
return 1 0 430
assign 1 0 433
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1585983204: return bem_dosNewlineGet_0();
case -1877460972: return bem_crGet_0();
case 1861855516: return bem_copy_0();
case 1676715436: return bem_iteratorGet_0();
case -2042483961: return bem_toString_0();
case -1757033570: return bem_print_0();
case -1660153331: return bem_colonGet_0();
case -1297029134: return bem_default_0();
case 961492374: return bem_emptyGet_0();
case 1004335399: return bem_lfGet_0();
case -1425898375: return bem_new_0();
case 984626228: return bem_zeroGet_0();
case 436863164: return bem_hashGet_0();
case 1146187227: return bem_newlineGet_0();
case -1364325848: return bem_spaceGet_0();
case 1794782637: return bem_quoteGet_0();
case -1717154338: return bem_unixNewlineGet_0();
case -199074387: return bem_tabGet_0();
case -1844269288: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1727795301: return bem_newlineSet_1(bevd_0);
case 1051624606: return bem_undef_1(bevd_0);
case -794415108: return bem_unixNewlineSet_1(bevd_0);
case 1536815018: return bem_crSet_1(bevd_0);
case 1306600423: return bem_equals_1(bevd_0);
case 1458705638: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 16414741: return bem_lfSet_1(bevd_0);
case -371582843: return bem_copyTo_1(bevd_0);
case -272587445: return bem_notEquals_1(bevd_0);
case -1048885357: return bem_colonSet_1(bevd_0);
case -88015559: return bem_spaceSet_1(bevd_0);
case -1109902961: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -1695471464: return bem_emptySet_1(bevd_0);
case 1075465964: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1519979168: return bem_quoteSet_1(bevd_0);
case 1004638371: return bem_anyEmpty_1(bevd_0);
case 859819983: return bem_dosNewlineSet_1(bevd_0);
case 958183090: return bem_tabSet_1(bevd_0);
case 324846295: return bem_def_1(bevd_0);
case -441706697: return bem_zeroSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1900373187: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 705539453: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1263166407: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1704989212: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1725892051: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1176905374: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1497376474: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
