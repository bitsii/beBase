package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_one = (new BEC_2_4_3_MathInt(1));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(1293705497);
bevt_1_ta_ph = bevl_i.bemd_0(-550521573);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-520153746);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1196*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1197*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(1371110439);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1201*/ {
bevt_4_ta_ph = bevl_i.bemd_0(-550521573);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1201*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(1371110439);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1203*/
 else /* Line: 1201*/ {
break;
} /* Line: 1201*/
} /* Line: 1201*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1213*/ {
bevt_3_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 1213*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_4_ta_ph = bevl_step.bem_equals_1(bevp_space);
if (bevt_4_ta_ph.bevi_bool)/* Line: 1215*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1215*/ {
bevt_5_ta_ph = bevl_step.bem_equals_1(bevp_tab);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1215*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1215*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1215*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1215*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1215*/ {
bevt_6_ta_ph = bevl_step.bem_equals_1(bevp_cr);
if (bevt_6_ta_ph.bevi_bool)/* Line: 1215*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1215*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1215*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1215*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1215*/ {
bevt_7_ta_ph = bevl_step.bem_equals_1(bevp_unixNewline);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1215*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1215*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1215*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1215*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1216*/ {
bevl_end.bevi_int++;
} /* Line: 1217*/
 else /* Line: 1218*/ {
bevl_beg.bevi_int++;
} /* Line: 1219*/
} /* Line: 1216*/
 else /* Line: 1221*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_8_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1223*/
} /* Line: 1215*/
 else /* Line: 1213*/ {
break;
} /* Line: 1213*/
} /* Line: 1213*/
if (bevl_foundChar.bevi_bool)/* Line: 1226*/ {
bevt_10_ta_ph = beva_str.bem_sizeGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_9_ta_ph);
} /* Line: 1227*/
 else /* Line: 1228*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1229*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1235*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1235*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1235*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1235*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1235*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1235*/ {
return null;
} /* Line: 1235*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1241*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1241*/ {
bevl_ai.bemd_1(70608276, bevl_av);
bevl_bi.bemd_1(70608276, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1244*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1245*/
bevl_i.bevi_int++;
} /* Line: 1241*/
 else /* Line: 1241*/ {
break;
} /* Line: 1241*/
} /* Line: 1241*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1252*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1252*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
if (bevt_3_ta_ph.bevi_int < bevp_one.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1252*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1252*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1252*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1252*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1253*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1259*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
if (bevt_3_ta_ph.bevi_int > bevp_zero.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1259*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1259*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1259*/
 else /* Line: 1259*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1259*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1260*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNumSpace_1(BEC_2_4_6_TextString beva_toCheck) throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_size = beva_toCheck.bem_sizeGet_0();
bevt_4_ta_ph = beva_toCheck.bem_sizeGet_0();
bevl_ret = (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_ta_ph);
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1269*/ {
if (bevl_j.bevi_int < bevl_size.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 1269*/ {
beva_toCheck.bem_getInt_2(bevl_j, bevl_ic);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1271*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ic.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 1271*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1271*/
 else /* Line: 1271*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 1271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1271*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(91));
if (bevl_ic.bevi_int < bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 1271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1271*/
 else /* Line: 1271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1271*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1271*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 1271*/ {
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ic.bevi_int < bevt_17_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 1271*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1271*/
 else /* Line: 1271*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1271*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1271*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1271*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(32));
if (bevl_ic.bevi_int == bevt_19_ta_ph.bevi_int) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 1271*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1271*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1271*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1271*/ {
bevt_21_ta_ph = bevl_ret.bem_sizeGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_increment_0();
bevl_ret.bem_sizeSet_1(bevt_20_ta_ph);
bevl_ret.bem_setInt_2(bevl_j, bevl_ic);
} /* Line: 1273*/
bevl_j.bevi_int++;
} /* Line: 1269*/
 else /* Line: 1269*/ {
break;
} /* Line: 1269*/
} /* Line: 1269*/
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() throws Throwable {
return bevp_one;
} /*method end*/
public BEC_2_4_7_TextStrings bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1175, 1176, 1177, 1178, 1179, 1179, 1180, 1180, 1181, 1182, 1184, 1184, 1185, 1186, 1191, 1191, 1195, 1196, 1196, 1197, 1197, 1199, 1200, 1200, 1201, 1202, 1203, 1203, 1205, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 0, 1215, 0, 0, 0, 1215, 0, 0, 0, 1215, 0, 0, 1217, 1219, 1222, 1222, 1223, 1227, 1227, 1227, 1229, 1231, 1235, 1235, 0, 1235, 1235, 0, 0, 1235, 1236, 1236, 1236, 1236, 1237, 1238, 1239, 1240, 1241, 1241, 1241, 1242, 1243, 1244, 1245, 1245, 1245, 1241, 1248, 1248, 1248, 1252, 1252, 0, 1252, 1252, 1252, 0, 0, 1253, 1253, 1255, 1255, 1259, 1259, 1259, 1259, 1259, 0, 0, 0, 1260, 1260, 1262, 1262, 1266, 1267, 1268, 1268, 1269, 1269, 1269, 1270, 1271, 1271, 1271, 1271, 1271, 1271, 0, 0, 0, 0, 1271, 1271, 1271, 1271, 1271, 1271, 0, 0, 0, 0, 0, 0, 1271, 1271, 1271, 1271, 1271, 1271, 0, 0, 0, 0, 0, 0, 1271, 1271, 1271, 0, 0, 1272, 1272, 1272, 1273, 1269, 1276, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 53, 54, 65, 66, 67, 69, 70, 72, 73, 74, 77, 79, 80, 81, 87, 107, 108, 109, 110, 113, 115, 116, 118, 121, 123, 126, 130, 133, 135, 138, 142, 145, 147, 150, 155, 158, 162, 163, 164, 172, 173, 174, 177, 179, 200, 205, 206, 209, 214, 215, 218, 222, 224, 225, 226, 227, 228, 229, 230, 231, 232, 235, 240, 241, 242, 243, 245, 246, 247, 249, 255, 256, 257, 266, 271, 272, 275, 276, 281, 282, 285, 289, 290, 292, 293, 302, 307, 308, 309, 314, 315, 318, 322, 325, 326, 328, 329, 358, 359, 360, 361, 362, 365, 370, 371, 372, 373, 378, 379, 380, 385, 386, 389, 393, 396, 399, 400, 405, 406, 407, 412, 413, 416, 420, 423, 426, 430, 433, 434, 439, 440, 441, 446, 447, 450, 454, 457, 460, 464, 467, 468, 473, 474, 477, 481, 482, 483, 484, 486, 492, 495, 498, 502, 505, 509, 512, 516, 519, 523, 526, 530, 533, 537, 540, 544, 547, 551, 554, 558, 561, 565, 568, 572, 575};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1175 35
new 0 1175 35
assign 1 1176 36
new 0 1176 36
assign 1 1177 37
new 0 1177 37
assign 1 1178 38
new 0 1178 38
assign 1 1179 39
new 0 1179 39
assign 1 1179 40
codeNew 1 1179 40
assign 1 1180 41
new 0 1180 41
assign 1 1180 42
codeNew 1 1180 42
assign 1 1181 43
new 0 1181 43
assign 1 1182 44
new 0 1182 44
assign 1 1184 45
new 0 1184 45
assign 1 1184 46
codeNew 1 1184 46
assign 1 1185 47
new 0 1185 47
assign 1 1186 48
new 0 1186 48
assign 1 1191 53
joinBuffer 2 1191 53
return 1 1191 54
assign 1 1195 65
iteratorGet 0 1195 65
assign 1 1196 66
hasNextGet 0 1196 66
assign 1 1196 67
not 0 1196 67
assign 1 1197 69
new 0 1197 69
return 1 1197 70
assign 1 1199 72
new 0 1199 72
assign 1 1200 73
nextGet 0 1200 73
addValue 1 1200 74
assign 1 1201 77
hasNextGet 0 1201 77
addValue 1 1202 79
assign 1 1203 80
nextGet 0 1203 80
addValue 1 1203 81
return 1 1205 87
assign 1 1209 107
new 0 1209 107
assign 1 1210 108
new 0 1210 108
assign 1 1211 109
new 0 1211 109
assign 1 1212 110
mbiterGet 0 1212 110
assign 1 1213 113
hasNextGet 0 1213 113
assign 1 1214 115
nextGet 0 1214 115
assign 1 1215 116
equals 1 1215 116
assign 1 0 118
assign 1 1215 121
equals 1 1215 121
assign 1 0 123
assign 1 0 126
assign 1 0 130
assign 1 1215 133
equals 1 1215 133
assign 1 0 135
assign 1 0 138
assign 1 0 142
assign 1 1215 145
equals 1 1215 145
assign 1 0 147
assign 1 0 150
incrementValue 0 1217 155
incrementValue 0 1219 158
assign 1 1222 162
new 0 1222 162
setValue 1 1222 163
assign 1 1223 164
new 0 1223 164
assign 1 1227 172
sizeGet 0 1227 172
assign 1 1227 173
subtract 1 1227 173
assign 1 1227 174
substring 2 1227 174
assign 1 1229 177
new 0 1229 177
return 1 1231 179
assign 1 1235 200
undef 1 1235 205
assign 1 0 206
assign 1 1235 209
undef 1 1235 214
assign 1 0 215
assign 1 0 218
return 1 1235 222
assign 1 1236 224
new 0 1236 224
assign 1 1236 225
sizeGet 0 1236 225
assign 1 1236 226
sizeGet 0 1236 226
assign 1 1236 227
min 2 1236 227
assign 1 1237 228
biterGet 0 1237 228
assign 1 1238 229
biterGet 0 1238 229
assign 1 1239 230
new 0 1239 230
assign 1 1240 231
new 0 1240 231
assign 1 1241 232
new 0 1241 232
assign 1 1241 235
lesser 1 1241 240
next 1 1242 241
next 1 1243 242
assign 1 1244 243
notEquals 1 1244 243
assign 1 1245 245
new 0 1245 245
assign 1 1245 246
substring 2 1245 246
return 1 1245 247
incrementValue 0 1241 249
assign 1 1248 255
new 0 1248 255
assign 1 1248 256
substring 2 1248 256
return 1 1248 257
assign 1 1252 266
undef 1 1252 271
assign 1 0 272
assign 1 1252 275
sizeGet 0 1252 275
assign 1 1252 276
lesser 1 1252 281
assign 1 0 282
assign 1 0 285
assign 1 1253 289
new 0 1253 289
return 1 1253 290
assign 1 1255 292
new 0 1255 292
return 1 1255 293
assign 1 1259 302
def 1 1259 307
assign 1 1259 308
sizeGet 0 1259 308
assign 1 1259 309
greater 1 1259 314
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 1260 325
new 0 1260 325
return 1 1260 326
assign 1 1262 328
new 0 1262 328
return 1 1262 329
assign 1 1266 358
new 0 1266 358
assign 1 1267 359
sizeGet 0 1267 359
assign 1 1268 360
sizeGet 0 1268 360
assign 1 1268 361
new 1 1268 361
assign 1 1269 362
new 0 1269 362
assign 1 1269 365
lesser 1 1269 370
getInt 2 1270 371
assign 1 1271 372
new 0 1271 372
assign 1 1271 373
greater 1 1271 378
assign 1 1271 379
new 0 1271 379
assign 1 1271 380
lesser 1 1271 385
assign 1 0 386
assign 1 0 389
assign 1 0 393
assign 1 0 396
assign 1 1271 399
new 0 1271 399
assign 1 1271 400
greater 1 1271 405
assign 1 1271 406
new 0 1271 406
assign 1 1271 407
lesser 1 1271 412
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 0 423
assign 1 0 426
assign 1 0 430
assign 1 1271 433
new 0 1271 433
assign 1 1271 434
greater 1 1271 439
assign 1 1271 440
new 0 1271 440
assign 1 1271 441
lesser 1 1271 446
assign 1 0 447
assign 1 0 450
assign 1 0 454
assign 1 0 457
assign 1 0 460
assign 1 0 464
assign 1 1271 467
new 0 1271 467
assign 1 1271 468
equals 1 1271 473
assign 1 0 474
assign 1 0 477
assign 1 1272 481
sizeGet 0 1272 481
assign 1 1272 482
increment 0 1272 482
sizeSet 1 1272 483
setInt 2 1273 484
incrementValue 0 1269 486
return 1 1276 492
return 1 0 495
assign 1 0 498
return 1 0 502
assign 1 0 505
return 1 0 509
assign 1 0 512
return 1 0 516
assign 1 0 519
return 1 0 523
assign 1 0 526
return 1 0 530
assign 1 0 533
return 1 0 537
assign 1 0 540
return 1 0 544
assign 1 0 547
return 1 0 551
assign 1 0 554
return 1 0 558
assign 1 0 561
return 1 0 565
assign 1 0 568
return 1 0 572
assign 1 0 575
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1540610251: return bem_newlineGet_0();
case -1730162424: return bem_spaceGet_0();
case -892600160: return bem_colonGet_0();
case 2040121503: return bem_unixNewlineGet_0();
case 1500763754: return bem_zeroGet_0();
case 827808077: return bem_default_0();
case -455592099: return bem_dosNewlineGet_0();
case -2046929697: return bem_toString_0();
case -424614227: return bem_print_0();
case 179874280: return bem_lfGet_0();
case -676802561: return bem_create_0();
case 109796013: return bem_tabGet_0();
case -1648793551: return bem_hashGet_0();
case 1293705497: return bem_iteratorGet_0();
case -52976429: return bem_new_0();
case 356050183: return bem_quoteGet_0();
case 2118955590: return bem_crGet_0();
case -1337014400: return bem_copy_0();
case -1883872501: return bem_emptyGet_0();
case 1404539846: return bem_oneGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1970708029: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -1675688952: return bem_emptySet_1(bevd_0);
case 1359207293: return bem_newlineSet_1(bevd_0);
case 471220918: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 2143855521: return bem_unixNewlineSet_1(bevd_0);
case 1997017825: return bem_crSet_1(bevd_0);
case -2048838144: return bem_tabSet_1(bevd_0);
case -222095687: return bem_toAlphaNumSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1774225827: return bem_oneSet_1(bevd_0);
case -1337452029: return bem_notEquals_1(bevd_0);
case 1346074140: return bem_equals_1(bevd_0);
case 298080975: return bem_lfSet_1(bevd_0);
case 322005879: return bem_copyTo_1(bevd_0);
case 2098146499: return bem_colonSet_1(bevd_0);
case 1651082390: return bem_undef_1(bevd_0);
case -709284216: return bem_dosNewlineSet_1(bevd_0);
case -511861774: return bem_quoteSet_1(bevd_0);
case -1967390692: return bem_zeroSet_1(bevd_0);
case 1648967994: return bem_spaceSet_1(bevd_0);
case 696250712: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 526222373: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1326218229: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1488275060: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 142360600: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1649942408: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -44675165: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 964580200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -628094110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
