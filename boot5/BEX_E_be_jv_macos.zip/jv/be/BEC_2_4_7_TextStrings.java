package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_5 = {};
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_7_TextStrings_bels_6 = {};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_TextStrings_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_TextStrings_bels_6, 0));
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpany_phold);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpany_phold);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_4));
bevp_lineSplitter = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_splits.bemd_0(331067077);
bevt_1_tmpany_phold = bevl_i.bemd_0(-331472942);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1054128750);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1167 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpany_phold;
} /* Line: 1168 */
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpany_phold = bevl_i.bemd_0(-654009727);
bevl_buf.bem_addValue_1(bevt_3_tmpany_phold);
while (true)
 /* Line: 1172 */ {
bevt_4_tmpany_phold = bevl_i.bemd_0(-331472942);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 1172 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpany_phold = bevl_i.bemd_0(-654009727);
bevl_buf.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 1174 */
 else  /* Line: 1172 */ {
break;
} /* Line: 1172 */
} /* Line: 1172 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1184 */ {
bevt_0_tmpany_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1184 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpany_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1186 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1187 */ {
bevl_end.bevi_int++;
} /* Line: 1188 */
 else  /* Line: 1189 */ {
bevl_beg.bevi_int++;
} /* Line: 1190 */
} /* Line: 1187 */
 else  /* Line: 1192 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1194 */
} /* Line: 1186 */
 else  /* Line: 1184 */ {
break;
} /* Line: 1184 */
} /* Line: 1184 */
if (bevl_foundChar.bevi_bool) /* Line: 1197 */ {
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_tmpany_phold);
} /* Line: 1198 */
 else  /* Line: 1199 */ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_5));
} /* Line: 1200 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1206 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1206 */ {
if (beva_b == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1206 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1206 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1206 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1206 */ {
return null;
} /* Line: 1206 */
bevt_3_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_tmpany_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpany_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_min_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1212 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1212 */ {
bevl_ai.bemd_1(-1469774479, bevl_av);
bevl_bi.bemd_1(-1469774479, bevl_bv);
bevt_7_tmpany_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1215 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_0;
bevt_8_tmpany_phold = beva_a.bem_substring_2(bevt_9_tmpany_phold, bevl_i);
return bevt_8_tmpany_phold;
} /* Line: 1216 */
bevl_i.bevi_int++;
} /* Line: 1212 */
 else  /* Line: 1212 */ {
break;
} /* Line: 1212 */
} /* Line: 1212 */
bevt_11_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_1;
bevt_10_tmpany_phold = beva_a.bem_substring_2(bevt_11_tmpany_phold, bevl_i);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevt_0_tmpany_loop = beva_strs.bemd_0(331067077);
while (true)
 /* Line: 1223 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-331472942);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 1223 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-654009727);
bevt_2_tmpany_phold = bem_isEmpty_1(bevl_i);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1224 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 1225 */
} /* Line: 1224 */
 else  /* Line: 1223 */ {
break;
} /* Line: 1223 */
} /* Line: 1223 */
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1232 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1232 */ {
bevt_3_tmpany_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_2;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1232 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1232 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1232 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1232 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 1233 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1239 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_3;
bevt_2_tmpany_phold = beva_value.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1239 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1239 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1239 */
 else  /* Line: 1239 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1239 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 1240 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1141, 1142, 1143, 1143, 1144, 1144, 1145, 1146, 1148, 1148, 1149, 1150, 1151, 1152, 1155, 1156, 1157, 1158, 1162, 1162, 1166, 1167, 1167, 1168, 1168, 1170, 1171, 1171, 1172, 1173, 1174, 1174, 1176, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1188, 1190, 1193, 1193, 1194, 1198, 1198, 1198, 1200, 1202, 1206, 1206, 0, 1206, 1206, 0, 0, 1206, 1207, 1207, 1207, 1207, 1208, 1209, 1210, 1211, 1212, 1212, 1212, 1213, 1214, 1215, 1216, 1216, 1216, 1212, 1219, 1219, 1219, 1223, 0, 1223, 1223, 1224, 1225, 1225, 1228, 1228, 1232, 1232, 0, 1232, 1232, 1232, 1232, 0, 0, 1233, 1233, 1235, 1235, 1239, 1239, 1239, 1239, 0, 0, 0, 1240, 1240, 1242, 1242, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 60, 61, 72, 73, 74, 76, 77, 79, 80, 81, 84, 86, 87, 88, 94, 108, 109, 110, 111, 114, 116, 117, 120, 123, 127, 128, 129, 137, 138, 139, 142, 144, 165, 170, 171, 174, 179, 180, 183, 187, 189, 190, 191, 192, 193, 194, 195, 196, 197, 200, 205, 206, 207, 208, 210, 211, 212, 214, 220, 221, 222, 231, 231, 234, 236, 237, 239, 240, 247, 248, 258, 263, 264, 267, 268, 269, 274, 275, 278, 282, 283, 285, 286, 295, 300, 301, 302, 304, 307, 311, 314, 315, 317, 318, 321, 324, 328, 331, 335, 338, 342, 345, 349, 352, 356, 359, 363, 366, 370, 373, 377, 380, 384, 387, 391, 394, 398, 401};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1141 38
new 0 1141 38
assign 1 1142 39
new 0 1142 39
assign 1 1143 40
new 0 1143 40
assign 1 1143 41
codeNew 1 1143 41
assign 1 1144 42
new 0 1144 42
assign 1 1144 43
codeNew 1 1144 43
assign 1 1145 44
new 0 1145 44
assign 1 1146 45
new 0 1146 45
assign 1 1148 46
new 0 1148 46
assign 1 1148 47
codeNew 1 1148 47
assign 1 1149 48
new 0 1149 48
assign 1 1150 49
new 0 1150 49
assign 1 1151 50
new 1 1151 50
assign 1 1152 51
new 0 1152 51
put 1 1155 52
put 1 1156 53
put 1 1157 54
put 1 1158 55
assign 1 1162 60
joinBuffer 2 1162 60
return 1 1162 61
assign 1 1166 72
iteratorGet 0 1166 72
assign 1 1167 73
hasNextGet 0 1167 73
assign 1 1167 74
not 0 1167 74
assign 1 1168 76
new 0 1168 76
return 1 1168 77
assign 1 1170 79
new 0 1170 79
assign 1 1171 80
nextGet 0 1171 80
addValue 1 1171 81
assign 1 1172 84
hasNextGet 0 1172 84
addValue 1 1173 86
assign 1 1174 87
nextGet 0 1174 87
addValue 1 1174 88
return 1 1176 94
assign 1 1180 108
new 0 1180 108
assign 1 1181 109
new 0 1181 109
assign 1 1182 110
new 0 1182 110
assign 1 1183 111
mbiterGet 0 1183 111
assign 1 1184 114
hasNextGet 0 1184 114
assign 1 1185 116
nextGet 0 1185 116
assign 1 1186 117
has 1 1186 117
incrementValue 0 1188 120
incrementValue 0 1190 123
assign 1 1193 127
new 0 1193 127
setValue 1 1193 128
assign 1 1194 129
new 0 1194 129
assign 1 1198 137
sizeGet 0 1198 137
assign 1 1198 138
subtract 1 1198 138
assign 1 1198 139
substring 2 1198 139
assign 1 1200 142
new 0 1200 142
return 1 1202 144
assign 1 1206 165
undef 1 1206 170
assign 1 0 171
assign 1 1206 174
undef 1 1206 179
assign 1 0 180
assign 1 0 183
return 1 1206 187
assign 1 1207 189
new 0 1207 189
assign 1 1207 190
sizeGet 0 1207 190
assign 1 1207 191
sizeGet 0 1207 191
assign 1 1207 192
min 2 1207 192
assign 1 1208 193
biterGet 0 1208 193
assign 1 1209 194
biterGet 0 1209 194
assign 1 1210 195
new 0 1210 195
assign 1 1211 196
new 0 1211 196
assign 1 1212 197
new 0 1212 197
assign 1 1212 200
lesser 1 1212 205
next 1 1213 206
next 1 1214 207
assign 1 1215 208
notEquals 1 1215 208
assign 1 1216 210
new 0 1216 210
assign 1 1216 211
substring 2 1216 211
return 1 1216 212
incrementValue 0 1212 214
assign 1 1219 220
new 0 1219 220
assign 1 1219 221
substring 2 1219 221
return 1 1219 222
assign 1 1223 231
iteratorGet 0 0 231
assign 1 1223 234
hasNextGet 0 1223 234
assign 1 1223 236
nextGet 0 1223 236
assign 1 1224 237
isEmpty 1 1224 237
assign 1 1225 239
new 0 1225 239
return 1 1225 240
assign 1 1228 247
new 0 1228 247
return 1 1228 248
assign 1 1232 258
undef 1 1232 263
assign 1 0 264
assign 1 1232 267
sizeGet 0 1232 267
assign 1 1232 268
new 0 1232 268
assign 1 1232 269
lesser 1 1232 274
assign 1 0 275
assign 1 0 278
assign 1 1233 282
new 0 1233 282
return 1 1233 283
assign 1 1235 285
new 0 1235 285
return 1 1235 286
assign 1 1239 295
def 1 1239 300
assign 1 1239 301
new 0 1239 301
assign 1 1239 302
notEquals 1 1239 302
assign 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 1240 314
new 0 1240 314
return 1 1240 315
assign 1 1242 317
new 0 1242 317
return 1 1242 318
return 1 0 321
assign 1 0 324
return 1 0 328
assign 1 0 331
return 1 0 335
assign 1 0 338
return 1 0 342
assign 1 0 345
return 1 0 349
assign 1 0 352
return 1 0 356
assign 1 0 359
return 1 0 363
assign 1 0 366
return 1 0 370
assign 1 0 373
return 1 0 377
assign 1 0 380
return 1 0 384
assign 1 0 387
return 1 0 391
assign 1 0 394
return 1 0 398
assign 1 0 401
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1674644863: return bem_serializeToString_0();
case 199782852: return bem_wsGet_0();
case 353744263: return bem_once_0();
case 1107063436: return bem_create_0();
case -1431676168: return bem_tabGet_0();
case -455732011: return bem_lineSplitterGet_0();
case -868754815: return bem_serializeContents_0();
case -1144635038: return bem_fieldIteratorGet_0();
case -459363310: return bem_lfGet_0();
case -32534406: return bem_unixNewlineGet_0();
case -1704001450: return bem_serializationIteratorGet_0();
case -1615155660: return bem_sourceFileNameGet_0();
case 1586265763: return bem_copy_0();
case -1207227016: return bem_toAny_0();
case 836604081: return bem_tagGet_0();
case 465988621: return bem_emptyGet_0();
case 755005070: return bem_echo_0();
case -1432966592: return bem_deserializeClassNameGet_0();
case 1550782506: return bem_print_0();
case -587123786: return bem_dosNewlineGet_0();
case 331067077: return bem_iteratorGet_0();
case -241682743: return bem_colonGet_0();
case -1143792058: return bem_default_0();
case -2079261808: return bem_toString_0();
case 1984963359: return bem_crGet_0();
case 1618197244: return bem_new_0();
case -520266758: return bem_spaceGet_0();
case -2035802034: return bem_hashGet_0();
case 1399141081: return bem_newlineGet_0();
case 875578639: return bem_quoteGet_0();
case 2089277173: return bem_classNameGet_0();
case 1724993772: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -116617170: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -734163518: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1500628477: return bem_emptySet_1(bevd_0);
case 1292274364: return bem_undefined_1(bevd_0);
case 1844790520: return bem_dosNewlineSet_1(bevd_0);
case 787925997: return bem_unixNewlineSet_1(bevd_0);
case 567619203: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2018158572: return bem_sameType_1(bevd_0);
case 1053963189: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -401289301: return bem_lineSplitterSet_1(bevd_0);
case -864903677: return bem_otherType_1(bevd_0);
case -1690572361: return bem_wsSet_1(bevd_0);
case -467831865: return bem_otherClass_1(bevd_0);
case -739905319: return bem_colonSet_1(bevd_0);
case -955519709: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1752472493: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -1743252117: return bem_sameObject_1(bevd_0);
case 729465196: return bem_equals_1(bevd_0);
case 1743860852: return bem_crSet_1(bevd_0);
case 1975786452: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1285524271: return bem_sameClass_1(bevd_0);
case 1820941401: return bem_def_1(bevd_0);
case -102763151: return bem_defined_1(bevd_0);
case 358260992: return bem_anyEmpty_1(bevd_0);
case -1382237935: return bem_lfSet_1(bevd_0);
case -1082065255: return bem_newlineSet_1(bevd_0);
case 89654816: return bem_quoteSet_1(bevd_0);
case -1659949140: return bem_tabSet_1(bevd_0);
case 894987079: return bem_undef_1(bevd_0);
case 1181026029: return bem_copyTo_1(bevd_0);
case -1690226246: return bem_notEquals_1(bevd_0);
case 1655973766: return bem_spaceSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1632202498: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1527927145: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1067491989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1262316226: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -545620176: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -910810703: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1241720452: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2041527697: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1713973958: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1814064163: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
}
