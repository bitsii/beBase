package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(2036051475);
bevt_1_ta_ph = bevl_i.bemd_0(1315977308);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1468933333);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1254*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1255*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(-681478278);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1259*/ {
bevt_4_ta_ph = bevl_i.bemd_0(1315977308);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1259*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(-681478278);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1261*/
 else /* Line: 1259*/ {
break;
} /* Line: 1259*/
} /* Line: 1259*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1271*/ {
bevt_0_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 1271*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_ta_ph = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_ta_ph.bevi_bool)/* Line: 1273*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1274*/ {
bevl_end.bevi_int++;
} /* Line: 1275*/
 else /* Line: 1276*/ {
bevl_beg.bevi_int++;
} /* Line: 1277*/
} /* Line: 1274*/
 else /* Line: 1279*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1281*/
} /* Line: 1273*/
 else /* Line: 1271*/ {
break;
} /* Line: 1271*/
} /* Line: 1271*/
if (bevl_foundChar.bevi_bool)/* Line: 1284*/ {
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_ta_ph);
} /* Line: 1285*/
 else /* Line: 1286*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1287*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1293*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1293*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1293*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1293*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1293*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1293*/ {
return null;
} /* Line: 1293*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1299*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1299*/ {
bevl_ai.bemd_1(-951859496, bevl_av);
bevl_bi.bemd_1(-951859496, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1302*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1303*/
bevl_i.bevi_int++;
} /* Line: 1299*/
 else /* Line: 1299*/ {
break;
} /* Line: 1299*/
} /* Line: 1299*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(2036051475);
while (true)
/* Line: 1310*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(1315977308);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1310*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-681478278);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1311*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1312*/
} /* Line: 1311*/
 else /* Line: 1310*/ {
break;
} /* Line: 1310*/
} /* Line: 1310*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1319*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1319*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1319*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1319*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1319*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1319*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1320*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1326*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
bevt_2_ta_ph = beva_value.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1326*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1326*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1326*/
 else /* Line: 1326*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1326*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1327*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public final BEC_2_4_3_MathInt bem_zeroGetDirect_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_zeroSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public final BEC_2_4_6_TextString bem_spaceGetDirect_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public final BEC_2_4_6_TextString bem_emptyGetDirect_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public final BEC_2_4_6_TextString bem_quoteGetDirect_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public final BEC_2_4_6_TextString bem_tabGetDirect_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public final BEC_2_4_6_TextString bem_crGetDirect_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public final BEC_2_4_6_TextString bem_lfGetDirect_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public final BEC_2_4_6_TextString bem_colonGetDirect_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_wsGetDirect_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1228, 1229, 1230, 1231, 1231, 1232, 1232, 1233, 1234, 1236, 1236, 1237, 1238, 1239, 1242, 1243, 1244, 1245, 1249, 1249, 1253, 1254, 1254, 1255, 1255, 1257, 1258, 1258, 1259, 1260, 1261, 1261, 1263, 1267, 1268, 1269, 1270, 1271, 1272, 1273, 1275, 1277, 1280, 1280, 1281, 1285, 1285, 1285, 1287, 1289, 1293, 1293, 0, 1293, 1293, 0, 0, 1293, 1294, 1294, 1294, 1294, 1295, 1296, 1297, 1298, 1299, 1299, 1299, 1300, 1301, 1302, 1303, 1303, 1303, 1299, 1306, 1306, 1306, 1310, 0, 1310, 1310, 1311, 1312, 1312, 1315, 1315, 1319, 1319, 0, 1319, 1319, 1319, 1319, 0, 0, 1320, 1320, 1322, 1322, 1326, 1326, 1326, 1326, 0, 0, 0, 1327, 1327, 1329, 1329, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 57, 58, 69, 70, 71, 73, 74, 76, 77, 78, 81, 83, 84, 85, 91, 105, 106, 107, 108, 111, 113, 114, 117, 120, 124, 125, 126, 134, 135, 136, 139, 141, 162, 167, 168, 171, 176, 177, 180, 184, 186, 187, 188, 189, 190, 191, 192, 193, 194, 197, 202, 203, 204, 205, 207, 208, 209, 211, 217, 218, 219, 228, 228, 231, 233, 234, 236, 237, 244, 245, 255, 260, 261, 264, 265, 266, 271, 272, 275, 279, 280, 282, 283, 292, 297, 298, 299, 301, 304, 308, 311, 312, 314, 315, 318, 321, 324, 328, 332, 335, 338, 342, 346, 349, 352, 356, 360, 363, 366, 370, 374, 377, 380, 384, 388, 391, 394, 398, 402, 405, 408, 412, 416, 419, 422, 426, 430, 433, 436, 440, 444, 447, 450, 454, 458, 461, 464, 468, 472, 475, 478, 482};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1228 35
new 0 1228 35
assign 1 1229 36
new 0 1229 36
assign 1 1230 37
new 0 1230 37
assign 1 1231 38
new 0 1231 38
assign 1 1231 39
codeNew 1 1231 39
assign 1 1232 40
new 0 1232 40
assign 1 1232 41
codeNew 1 1232 41
assign 1 1233 42
new 0 1233 42
assign 1 1234 43
new 0 1234 43
assign 1 1236 44
new 0 1236 44
assign 1 1236 45
codeNew 1 1236 45
assign 1 1237 46
new 0 1237 46
assign 1 1238 47
new 0 1238 47
assign 1 1239 48
new 0 1239 48
put 1 1242 49
put 1 1243 50
put 1 1244 51
put 1 1245 52
assign 1 1249 57
joinBuffer 2 1249 57
return 1 1249 58
assign 1 1253 69
iteratorGet 0 1253 69
assign 1 1254 70
hasNextGet 0 1254 70
assign 1 1254 71
not 0 1254 71
assign 1 1255 73
new 0 1255 73
return 1 1255 74
assign 1 1257 76
new 0 1257 76
assign 1 1258 77
nextGet 0 1258 77
addValue 1 1258 78
assign 1 1259 81
hasNextGet 0 1259 81
addValue 1 1260 83
assign 1 1261 84
nextGet 0 1261 84
addValue 1 1261 85
return 1 1263 91
assign 1 1267 105
new 0 1267 105
assign 1 1268 106
new 0 1268 106
assign 1 1269 107
new 0 1269 107
assign 1 1270 108
mbiterGet 0 1270 108
assign 1 1271 111
hasNextGet 0 1271 111
assign 1 1272 113
nextGet 0 1272 113
assign 1 1273 114
has 1 1273 114
incrementValue 0 1275 117
incrementValue 0 1277 120
assign 1 1280 124
new 0 1280 124
setValue 1 1280 125
assign 1 1281 126
new 0 1281 126
assign 1 1285 134
sizeGet 0 1285 134
assign 1 1285 135
subtract 1 1285 135
assign 1 1285 136
substring 2 1285 136
assign 1 1287 139
new 0 1287 139
return 1 1289 141
assign 1 1293 162
undef 1 1293 167
assign 1 0 168
assign 1 1293 171
undef 1 1293 176
assign 1 0 177
assign 1 0 180
return 1 1293 184
assign 1 1294 186
new 0 1294 186
assign 1 1294 187
sizeGet 0 1294 187
assign 1 1294 188
sizeGet 0 1294 188
assign 1 1294 189
min 2 1294 189
assign 1 1295 190
biterGet 0 1295 190
assign 1 1296 191
biterGet 0 1296 191
assign 1 1297 192
new 0 1297 192
assign 1 1298 193
new 0 1298 193
assign 1 1299 194
new 0 1299 194
assign 1 1299 197
lesser 1 1299 202
next 1 1300 203
next 1 1301 204
assign 1 1302 205
notEquals 1 1302 205
assign 1 1303 207
new 0 1303 207
assign 1 1303 208
substring 2 1303 208
return 1 1303 209
incrementValue 0 1299 211
assign 1 1306 217
new 0 1306 217
assign 1 1306 218
substring 2 1306 218
return 1 1306 219
assign 1 1310 228
iteratorGet 0 0 228
assign 1 1310 231
hasNextGet 0 1310 231
assign 1 1310 233
nextGet 0 1310 233
assign 1 1311 234
isEmpty 1 1311 234
assign 1 1312 236
new 0 1312 236
return 1 1312 237
assign 1 1315 244
new 0 1315 244
return 1 1315 245
assign 1 1319 255
undef 1 1319 260
assign 1 0 261
assign 1 1319 264
sizeGet 0 1319 264
assign 1 1319 265
new 0 1319 265
assign 1 1319 266
lesser 1 1319 271
assign 1 0 272
assign 1 0 275
assign 1 1320 279
new 0 1320 279
return 1 1320 280
assign 1 1322 282
new 0 1322 282
return 1 1322 283
assign 1 1326 292
def 1 1326 297
assign 1 1326 298
new 0 1326 298
assign 1 1326 299
notEquals 1 1326 299
assign 1 0 301
assign 1 0 304
assign 1 0 308
assign 1 1327 311
new 0 1327 311
return 1 1327 312
assign 1 1329 314
new 0 1329 314
return 1 1329 315
return 1 0 318
return 1 0 321
assign 1 0 324
assign 1 0 328
return 1 0 332
return 1 0 335
assign 1 0 338
assign 1 0 342
return 1 0 346
return 1 0 349
assign 1 0 352
assign 1 0 356
return 1 0 360
return 1 0 363
assign 1 0 366
assign 1 0 370
return 1 0 374
return 1 0 377
assign 1 0 380
assign 1 0 384
return 1 0 388
return 1 0 391
assign 1 0 394
assign 1 0 398
return 1 0 402
return 1 0 405
assign 1 0 408
assign 1 0 412
return 1 0 416
return 1 0 419
assign 1 0 422
assign 1 0 426
return 1 0 430
return 1 0 433
assign 1 0 436
assign 1 0 440
return 1 0 444
return 1 0 447
assign 1 0 450
assign 1 0 454
return 1 0 458
return 1 0 461
assign 1 0 464
assign 1 0 468
return 1 0 472
return 1 0 475
assign 1 0 478
assign 1 0 482
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -59885155: return bem_dosNewlineGetDirect_0();
case 2146383679: return bem_newlineGet_0();
case 1609612359: return bem_echo_0();
case 556090396: return bem_sourceFileNameGet_0();
case -1347523976: return bem_colonGetDirect_0();
case 212630626: return bem_tabGetDirect_0();
case 969222217: return bem_newlineGetDirect_0();
case -1564975844: return bem_serializeContents_0();
case -2111844006: return bem_quoteGetDirect_0();
case 2133436679: return bem_emptyGetDirect_0();
case 584892558: return bem_unixNewlineGet_0();
case -150613155: return bem_wsGet_0();
case -811046848: return bem_copy_0();
case 740286225: return bem_spaceGetDirect_0();
case -489373623: return bem_quoteGet_0();
case 1132429880: return bem_tagGet_0();
case -1997767299: return bem_colonGet_0();
case 1649202206: return bem_lfGet_0();
case -1950650464: return bem_emptyGet_0();
case 55056354: return bem_zeroGet_0();
case -253234032: return bem_crGetDirect_0();
case 1120194534: return bem_unixNewlineGetDirect_0();
case 432179744: return bem_fieldNamesGet_0();
case -1812965558: return bem_fieldIteratorGet_0();
case 138302413: return bem_new_0();
case -1747597055: return bem_create_0();
case -1799525886: return bem_lfGetDirect_0();
case 712783465: return bem_hashGet_0();
case 91029658: return bem_dosNewlineGet_0();
case 1267631579: return bem_serializationIteratorGet_0();
case 67700549: return bem_classNameGet_0();
case -1498562624: return bem_default_0();
case -1783813746: return bem_wsGetDirect_0();
case 178019168: return bem_toString_0();
case -2106036149: return bem_deserializeClassNameGet_0();
case -1854967969: return bem_spaceGet_0();
case 1189093835: return bem_tabGet_0();
case 2036051475: return bem_iteratorGet_0();
case -1627734356: return bem_serializeToString_0();
case 478950400: return bem_print_0();
case -1216586339: return bem_crGet_0();
case -206366587: return bem_zeroGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 299147329: return bem_zeroSetDirect_1(bevd_0);
case 1951774795: return bem_copyTo_1(bevd_0);
case -187946541: return bem_crSet_1(bevd_0);
case -71207453: return bem_newlineSetDirect_1(bevd_0);
case -445227031: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 399670111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1084952852: return bem_undef_1(bevd_0);
case -225795861: return bem_sameType_1(bevd_0);
case -960189358: return bem_spaceSet_1(bevd_0);
case 1228002526: return bem_tabSet_1(bevd_0);
case 606870566: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2059692827: return bem_sameObject_1(bevd_0);
case 2107311680: return bem_notEquals_1(bevd_0);
case -639040987: return bem_lfSetDirect_1(bevd_0);
case 1495309367: return bem_wsSetDirect_1(bevd_0);
case 649657428: return bem_colonSet_1(bevd_0);
case -706717564: return bem_colonSetDirect_1(bevd_0);
case 2001165360: return bem_lfSet_1(bevd_0);
case -1779944426: return bem_wsSet_1(bevd_0);
case -577791552: return bem_spaceSetDirect_1(bevd_0);
case -280360904: return bem_quoteSet_1(bevd_0);
case -472375151: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 257683973: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1628514536: return bem_dosNewlineSetDirect_1(bevd_0);
case 241193565: return bem_emptySetDirect_1(bevd_0);
case 2102402789: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -1155872979: return bem_dosNewlineSet_1(bevd_0);
case 393515873: return bem_anyEmpty_1(bevd_0);
case -13433445: return bem_unixNewlineSetDirect_1(bevd_0);
case 1233289430: return bem_newlineSet_1(bevd_0);
case 1964074985: return bem_otherType_1(bevd_0);
case 413789666: return bem_quoteSetDirect_1(bevd_0);
case -832563928: return bem_zeroSet_1(bevd_0);
case -60802666: return bem_otherClass_1(bevd_0);
case 123395573: return bem_unixNewlineSet_1(bevd_0);
case 1361278573: return bem_emptySet_1(bevd_0);
case -301008142: return bem_equals_1(bevd_0);
case 1184247111: return bem_sameClass_1(bevd_0);
case 1915580539: return bem_tabSetDirect_1(bevd_0);
case 465594002: return bem_def_1(bevd_0);
case 1230950349: return bem_crSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1679235980: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -824531634: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1107212100: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 284860950: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 500210595: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1035176912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 471675441: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1306506121: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
