package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_16_SystemExceptionBuilder extends BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
public static BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;

public static BET_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;

public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public BEC_2_6_16_SystemExceptionBuilder bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() throws Throwable {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) throws Throwable {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_klass == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 169*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 169*/ {
if (beva_eline == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 169*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 169*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 169*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 169*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(-1));
return bevt_3_ta_ph;
} /* Line: 171*/
bevl_line = (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toJvString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_ex == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 205*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_6_16_SystemExceptionBuilder_bels_0));
bevt_1_ta_ph.bem_print_0();
} /* Line: 206*/
 else /* Line: 207*/ {
try /* Line: 208*/ {
beva_ex.bemd_0(37637962);
} /* Line: 209*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_6_16_SystemExceptionBuilder_bels_1));
bevt_2_ta_ph.bem_print_0();
} /* Line: 211*/
} /* Line: 210*/
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 218*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_6_16_SystemExceptionBuilder_bels_0));
bevt_1_ta_ph.bem_print_0();
} /* Line: 219*/
 else /* Line: 220*/ {
try /* Line: 221*/ {
} /* Line: 221*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_6_16_SystemExceptionBuilder_bels_1));
bevt_2_ta_ph.bem_print_0();
} /* Line: 224*/
} /* Line: 223*/
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_passBack == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 230*/ {
bevt_2_ta_ph = beva_passBack.bemd_1(-1935405349, bevp_except);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 230*/
 else /* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 230*/ {
beva_passBack.bemd_1(-869310328, beva_sinClass);
beva_passBack.bemd_1(-1392151163, beva_sinMtd);
beva_passBack.bemd_1(1292912493, beva_sfname);
beva_passBack.bemd_1(-1850742452, beva_ilinep);
} /* Line: 234*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() throws Throwable {
return bevp_except;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_exceptGetDirect_0() throws Throwable {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_except = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_except = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_lastStrGetDirect_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastStr = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_lastStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastStr = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {160, 161, 169, 169, 0, 169, 169, 0, 0, 171, 171, 174, 200, 205, 205, 206, 206, 209, 211, 211, 217, 218, 218, 219, 219, 224, 224, 230, 230, 230, 0, 0, 0, 231, 232, 233, 234, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 30, 35, 36, 39, 44, 45, 48, 52, 53, 55, 60, 67, 72, 73, 74, 78, 82, 83, 93, 94, 99, 100, 101, 108, 109, 118, 123, 124, 126, 129, 133, 136, 137, 138, 139, 144, 147, 150, 154, 158, 161, 164, 168, 172, 175, 178, 182};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 160 20
new 0 160 20
assign 1 161 21
new 0 161 21
assign 1 169 30
undef 1 169 35
assign 1 0 36
assign 1 169 39
undef 1 169 44
assign 1 0 45
assign 1 0 48
assign 1 171 52
new 0 171 52
return 1 171 53
assign 1 174 55
new 0 174 55
return 1 200 60
assign 1 205 67
undef 1 205 72
assign 1 206 73
new 0 206 73
print 0 206 74
print 0 209 78
assign 1 211 82
new 0 211 82
print 0 211 83
assign 1 217 93
assign 1 218 94
undef 1 218 99
assign 1 219 100
new 0 219 100
print 0 219 101
assign 1 224 108
new 0 224 108
print 0 224 109
assign 1 230 118
def 1 230 123
assign 1 230 124
sameType 1 230 124
assign 1 0 126
assign 1 0 129
assign 1 0 133
klassNameSet 1 231 136
methodNameSet 1 232 137
fileNameSet 1 233 138
lineNumberSet 1 234 139
return 1 0 144
return 1 0 147
assign 1 0 150
assign 1 0 154
return 1 0 158
return 1 0 161
assign 1 0 164
assign 1 0 168
return 1 0 172
return 1 0 175
assign 1 0 178
assign 1 0 182
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1263154564: return bem_new_0();
case 1615402015: return bem_create_0();
case -311950162: return bem_exceptGet_0();
case 1179961651: return bem_serializeToString_0();
case 37637962: return bem_print_0();
case 299056070: return bem_lastStrGet_0();
case 1333799692: return bem_tagGet_0();
case 154967714: return bem_default_0();
case 340030523: return bem_classNameGet_0();
case -1826539616: return bem_lastStrGetDirect_0();
case 1546143657: return bem_echo_0();
case -1001743190: return bem_fieldNamesGet_0();
case 1445801145: return bem_serializationIteratorGet_0();
case -800146552: return bem_serializeContents_0();
case -717720996: return bem_exceptGetDirect_0();
case -2095499202: return bem_fieldIteratorGet_0();
case 147497190: return bem_iteratorGet_0();
case 1530427: return bem_intGetDirect_0();
case -794718926: return bem_copy_0();
case -676070096: return bem_sourceFileNameGet_0();
case -794062933: return bem_hashGet_0();
case 1531893825: return bem_intGet_0();
case 1577124637: return bem_deserializeClassNameGet_0();
case 219112807: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1405755430: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2093685595: return bem_printException_1(bevd_0);
case -265035352: return bem_exceptSet_1(bevd_0);
case -1913594804: return bem_lastStrSet_1(bevd_0);
case -1022428889: return bem_exceptSetDirect_1(bevd_0);
case 1151953229: return bem_intSetDirect_1(bevd_0);
case -1935405349: return bem_sameType_1(bevd_0);
case -19945451: return bem_notEquals_1(bevd_0);
case 158199809: return bem_intSet_1(bevd_0);
case 1623353087: return bem_lastStrSetDirect_1(bevd_0);
case 1981346500: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 550061094: return bem_undef_1(bevd_0);
case -2022815028: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1868129616: return bem_copyTo_1(bevd_0);
case -1534545800: return bem_otherType_1(bevd_0);
case 2044993814: return bem_sameClass_1(bevd_0);
case 739117568: return bem_otherClass_1(bevd_0);
case 250302014: return bem_equals_1(bevd_0);
case 1661150226: return bem_def_1(bevd_0);
case 1419064041: return bem_sameObject_1(bevd_0);
case -762018613: return bem_sendToConsole_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -938540681: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1301400069: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1738406137: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1708873965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 853768892: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2112740717: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) throws Throwable {
switch (callId) {
case 1422420557: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return super.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;
}
}
