package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_16_SystemExceptionBuilder extends BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_0, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_1, 25));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_2 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_2, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_3 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_3, 25));
public static BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;

public static BET_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;

public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_thing;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public BEC_2_6_16_SystemExceptionBuilder bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() throws Throwable {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) throws Throwable {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
if (beva_eline == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 396 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 396 */ {
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
return bevt_3_tmpany_phold;
} /* Line: 398 */
bevl_line = (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toJvString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 432 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 433 */
 else  /* Line: 434 */ {
try  /* Line: 435 */ {
beva_ex.bemd_0(652618710);
} /* Line: 436 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 438 */
} /* Line: 437 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 445 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 446 */
 else  /* Line: 447 */ {
try  /* Line: 448 */ {
} /* Line: 448 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 451 */
} /* Line: 450 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_passBack == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_2_tmpany_phold = beva_passBack.bemd_1(-1340973491, bevp_except);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 457 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 457 */ {
beva_passBack.bemd_1(151182661, beva_sinClass);
beva_passBack.bemd_1(2147106503, beva_sinMtd);
beva_passBack.bemd_1(-125059667, beva_sfname);
beva_passBack.bemd_1(729330370, beva_ilinep);
} /* Line: 461 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() throws Throwable {
return bevp_except;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_exceptGetDirect_0() throws Throwable {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGet_0() throws Throwable {
return bevp_thing;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_thingGetDirect_0() throws Throwable {
return bevp_thing;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_lastStrGetDirect_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_16_SystemExceptionBuilder bem_lastStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {386, 387, 388, 396, 396, 0, 396, 396, 0, 0, 398, 398, 401, 427, 432, 432, 433, 433, 436, 438, 438, 444, 445, 445, 446, 446, 451, 451, 457, 457, 457, 0, 0, 0, 458, 459, 460, 461, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {27, 28, 29, 38, 43, 44, 47, 52, 53, 56, 60, 61, 63, 68, 75, 80, 81, 82, 86, 90, 91, 101, 102, 107, 108, 109, 116, 117, 126, 131, 132, 134, 137, 141, 144, 145, 146, 147, 152, 155, 158, 162, 166, 169, 172, 176, 180, 183, 186, 190, 194, 197, 200, 204};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 386 27
new 0 386 27
assign 1 387 28
new 0 387 28
assign 1 388 29
new 0 388 29
assign 1 396 38
undef 1 396 43
assign 1 0 44
assign 1 396 47
undef 1 396 52
assign 1 0 53
assign 1 0 56
assign 1 398 60
new 0 398 60
return 1 398 61
assign 1 401 63
new 0 401 63
return 1 427 68
assign 1 432 75
undef 1 432 80
assign 1 433 81
new 0 433 81
print 0 433 82
print 0 436 86
assign 1 438 90
new 0 438 90
print 0 438 91
assign 1 444 101
assign 1 445 102
undef 1 445 107
assign 1 446 108
new 0 446 108
print 0 446 109
assign 1 451 116
new 0 451 116
print 0 451 117
assign 1 457 126
def 1 457 131
assign 1 457 132
sameType 1 457 132
assign 1 0 134
assign 1 0 137
assign 1 0 141
klassNameSet 1 458 144
methodNameSet 1 459 145
fileNameSet 1 460 146
lineNumberSet 1 461 147
return 1 0 152
return 1 0 155
assign 1 0 158
assign 1 0 162
return 1 0 166
return 1 0 169
assign 1 0 172
assign 1 0 176
return 1 0 180
return 1 0 183
assign 1 0 186
assign 1 0 190
return 1 0 194
return 1 0 197
assign 1 0 200
assign 1 0 204
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -451287241: return bem_iteratorGet_0();
case -2087517757: return bem_intGetDirect_0();
case 1260713952: return bem_fieldNamesGet_0();
case 408400458: return bem_exceptGetDirect_0();
case -512173810: return bem_tagGet_0();
case 166156356: return bem_hashGet_0();
case 1012944178: return bem_create_0();
case 1970654758: return bem_lastStrGet_0();
case -1360047774: return bem_serializeToString_0();
case -1927997963: return bem_thingGetDirect_0();
case -794542805: return bem_fieldIteratorGet_0();
case 1712919396: return bem_serializationIteratorGet_0();
case 1010970574: return bem_deserializeClassNameGet_0();
case 368405588: return bem_echo_0();
case 652618710: return bem_print_0();
case 938978826: return bem_serializeContents_0();
case 546450796: return bem_intGet_0();
case -131396274: return bem_classNameGet_0();
case 373871049: return bem_copy_0();
case 657440259: return bem_many_0();
case 37115722: return bem_toAny_0();
case 374527032: return bem_thingGet_0();
case 149300560: return bem_sourceFileNameGet_0();
case 1305332477: return bem_exceptGet_0();
case 29028378: return bem_lastStrGetDirect_0();
case -1497736169: return bem_new_0();
case 884758076: return bem_toString_0();
case 144782273: return bem_once_0();
case 542819736: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1184632884: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2033993347: return bem_sameObject_1(bevd_0);
case 46811792: return bem_otherType_1(bevd_0);
case -1958398234: return bem_sendToConsole_1(bevd_0);
case -2100048027: return bem_exceptSet_1(bevd_0);
case -1411989216: return bem_lastStrSet_1(bevd_0);
case -1418198617: return bem_def_1(bevd_0);
case 1346191662: return bem_thingSet_1(bevd_0);
case -1340973491: return bem_sameType_1(bevd_0);
case -1434589659: return bem_undef_1(bevd_0);
case 1450913634: return bem_defined_1(bevd_0);
case -1691038775: return bem_notEquals_1(bevd_0);
case 773892154: return bem_sameClass_1(bevd_0);
case 1993092731: return bem_thingSetDirect_1(bevd_0);
case -675060011: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -926157429: return bem_equals_1(bevd_0);
case 1499820327: return bem_intSetDirect_1(bevd_0);
case 974930963: return bem_undefined_1(bevd_0);
case -1952204646: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1849842647: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1022068717: return bem_printException_1(bevd_0);
case 1106643126: return bem_lastStrSetDirect_1(bevd_0);
case 2044588239: return bem_otherClass_1(bevd_0);
case -1215328786: return bem_intSet_1(bevd_0);
case -442448216: return bem_copyTo_1(bevd_0);
case -716673008: return bem_exceptSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -330880231: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -261819627: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1368517810: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1351268593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1842958248: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 840782676: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 498622947: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1807714621: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) throws Throwable {
switch (callId) {
case -183882914: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return super.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;
}
}
