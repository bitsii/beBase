package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList extends BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_2_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 137 */ {
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /* Line: 138 */
while (true)
 /* Line: 142 */ {
if (bevl_f == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 144 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 145 */
if (bevl_fnode == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_fnode = bevl_f;
} /* Line: 149 */
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 152 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(618913819, null);
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_node.bemd_1(64615945, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 164 */
 else  /* Line: 165 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 167 */
beva_node.bemd_1(769465484, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(618913819, null);
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 174 */ {
beva_node.bemd_1(618913819, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 177 */
 else  /* Line: 178 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 180 */
beva_node.bemd_1(769465484, this);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(-1102450468);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(1989672930, beva_toIns);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_0;
if (beva_pos.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_2_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 195 */
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 198 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 198 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 200 */
 else  /* Line: 201 */ {
break;
} /* Line: 202 */
bevl_i.bevi_int++;
} /* Line: 204 */
 else  /* Line: 198 */ {
break;
} /* Line: 198 */
} /* Line: 198 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 206 */ {
return null;
} /* Line: 207 */
bevt_6_tmpany_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 215 */ {
bevt_1_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 215 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 217 */
 else  /* Line: 218 */ {
break;
} /* Line: 219 */
bevl_i.bevi_int++;
} /* Line: 221 */
 else  /* Line: 215 */ {
break;
} /* Line: 215 */
} /* Line: 215 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 224 */
bevt_5_tmpany_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 230 */ {
return null;
} /* Line: 230 */
bevt_1_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_3_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 235 */ {
bevt_5_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_heldGet_0();
return bevt_4_tmpany_phold;
} /* Line: 236 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_4_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_7_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_nextGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_10_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_nextGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_heldGet_0();
return bevt_8_tmpany_phold;
} /* Line: 243 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 249 */ {
return null;
} /* Line: 249 */
bevt_1_tmpany_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_pos.bemd_1(53407038, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 254 */ {
return bevp_firstNode;
} /* Line: 255 */
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 258 */ {
bevt_2_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 258 */ {
bevt_3_tmpany_phold = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 260 */
 else  /* Line: 261 */ {
break;
} /* Line: 262 */
bevl_i.bevi_int++;
} /* Line: 264 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
bevt_4_tmpany_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 266 */ {
return null;
} /* Line: 267 */
bevt_5_tmpany_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_held == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 278 */ {
bevt_2_tmpany_phold = beva_held.bemd_1(-194482552, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 278 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 278 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 278 */
 else  /* Line: 278 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 278 */ {
bem_addAll_1(beva_held);
} /* Line: 279 */
 else  /* Line: 280 */ {
bem_addValueWhole_1(beva_held);
} /* Line: 281 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 286 */ {
while (true)
 /* Line: 287 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-861082790);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(-1770055311);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 288 */
 else  /* Line: 287 */ {
break;
} /* Line: 287 */
} /* Line: 287 */
} /* Line: 287 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 294 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-1706743432);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 295 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 306 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 306 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 308 */
 else  /* Line: 306 */ {
break;
} /* Line: 306 */
} /* Line: 306 */
return bevl_cnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_lengthGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 319 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toNodeList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 328 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 328 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevt_2_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 330 */
bevl_cnt.bevi_int++;
} /* Line: 332 */
 else  /* Line: 328 */ {
break;
} /* Line: 328 */
} /* Line: 328 */
return bevl_toret;
} /*method end*/
public BEC_2_9_4_ContainerList bem_toList_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 341 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 341 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 342 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-1264854428);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 343 */
bevl_cnt.bevi_int++;
} /* Line: 345 */
 else  /* Line: 341 */ {
break;
} /* Line: 341 */
} /* Line: 341 */
return bevl_toret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_maxGet_0();
bevt_0_tmpany_phold = bem_subList_2(beva_start, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 368 */ {
return bevl_res;
} /* Line: 369 */
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 372 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(541581678);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 373 */ {
return bevl_res;
} /* Line: 374 */
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 377 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 378 */
bevl_i.bevi_int++;
} /* Line: 372 */
 else  /* Line: 372 */ {
break;
} /* Line: 372 */
} /* Line: 372 */
return bevl_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 421 */ {
if (bevl_current == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpany_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpany_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 426 */
 else  /* Line: 421 */ {
break;
} /* Line: 421 */
} /* Line: 421 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGetDirect_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_firstNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGetDirect_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_lastNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {129, 129, 134, 135, 136, 137, 137, 138, 142, 142, 143, 144, 144, 145, 148, 148, 149, 151, 152, 154, 155, 156, 160, 161, 161, 162, 163, 164, 166, 167, 169, 173, 174, 174, 175, 176, 177, 179, 180, 182, 186, 190, 194, 194, 194, 195, 195, 197, 198, 198, 199, 199, 200, 204, 206, 206, 207, 209, 209, 213, 213, 214, 215, 215, 216, 216, 217, 221, 223, 223, 224, 224, 226, 226, 230, 230, 230, 231, 231, 235, 235, 235, 235, 235, 0, 0, 0, 236, 236, 236, 238, 242, 242, 242, 242, 242, 0, 0, 0, 242, 242, 242, 242, 0, 0, 0, 243, 243, 243, 243, 245, 249, 249, 249, 250, 250, 254, 254, 255, 257, 258, 258, 259, 260, 264, 266, 267, 269, 269, 273, 274, 278, 278, 278, 0, 0, 0, 279, 281, 286, 286, 287, 288, 288, 294, 294, 295, 295, 300, 301, 305, 306, 306, 307, 308, 310, 314, 314, 318, 318, 319, 319, 321, 321, 325, 326, 327, 328, 328, 329, 329, 330, 330, 332, 334, 338, 339, 340, 341, 341, 342, 342, 343, 343, 343, 345, 347, 351, 351, 355, 355, 359, 359, 363, 363, 363, 363, 367, 368, 368, 369, 371, 372, 372, 372, 373, 373, 374, 376, 377, 377, 378, 372, 381, 419, 420, 421, 421, 422, 423, 423, 424, 425, 426, 428, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 33, 34, 35, 36, 41, 42, 46, 51, 52, 53, 58, 59, 61, 66, 67, 69, 70, 76, 77, 78, 82, 83, 88, 89, 90, 91, 94, 95, 97, 102, 103, 108, 109, 110, 111, 114, 115, 117, 121, 125, 138, 139, 144, 145, 146, 148, 149, 152, 154, 159, 160, 165, 171, 176, 177, 179, 180, 191, 192, 193, 194, 197, 199, 204, 205, 210, 216, 221, 222, 223, 225, 226, 231, 236, 237, 239, 240, 249, 254, 255, 256, 261, 262, 265, 269, 272, 273, 274, 276, 290, 295, 296, 297, 302, 303, 306, 310, 313, 314, 315, 320, 321, 324, 328, 331, 332, 333, 334, 336, 341, 346, 347, 349, 350, 361, 362, 364, 366, 367, 370, 372, 374, 379, 385, 387, 389, 390, 394, 395, 402, 407, 408, 410, 413, 417, 420, 423, 431, 436, 439, 441, 442, 454, 459, 460, 461, 467, 468, 475, 476, 479, 481, 482, 488, 492, 493, 499, 504, 505, 506, 508, 509, 519, 520, 521, 522, 525, 527, 532, 533, 534, 536, 542, 553, 554, 555, 556, 559, 561, 566, 567, 568, 569, 571, 577, 581, 582, 586, 587, 591, 592, 598, 599, 600, 601, 613, 614, 619, 620, 622, 623, 626, 631, 632, 633, 635, 637, 638, 643, 644, 646, 652, 660, 661, 664, 669, 670, 671, 672, 673, 674, 675, 681, 685, 688, 691, 695, 699, 702, 705, 709};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 129 20
new 2 129 20
return 1 129 21
assign 1 134 33
create 0 134 33
assign 1 135 34
linkedListIteratorGet 0 135 34
assign 1 136 35
nextNodeGet 0 136 35
assign 1 137 36
undef 1 137 41
return 1 138 42
assign 1 142 46
def 1 142 51
assign 1 143 52
copy 0 143 52
assign 1 144 53
def 1 144 58
nextSet 1 145 59
assign 1 148 61
undef 1 148 66
assign 1 149 67
assign 1 151 69
assign 1 152 70
nextNodeGet 0 152 70
firstNodeSet 1 154 76
lastNodeSet 1 155 77
return 1 156 78
nextSet 1 160 82
assign 1 161 83
def 1 161 88
priorSet 1 162 89
nextSet 1 163 90
assign 1 164 91
assign 1 166 94
assign 1 167 95
mylistSet 1 169 97
nextSet 1 173 102
assign 1 174 103
def 1 174 108
nextSet 1 175 109
priorSet 1 176 110
assign 1 177 111
assign 1 179 114
assign 1 180 115
mylistSet 1 182 117
delete 0 186 121
insertBefore 1 190 125
assign 1 194 138
new 0 194 138
assign 1 194 139
equals 1 194 144
assign 1 195 145
heldGet 0 195 145
return 1 195 146
assign 1 197 148
new 0 197 148
assign 1 198 149
linkedListIteratorGet 0 198 149
assign 1 198 152
hasNextGet 0 198 152
assign 1 199 154
lesser 1 199 159
nextGet 0 200 160
incrementValue 0 204 165
assign 1 206 171
notEquals 1 206 176
return 1 207 177
assign 1 209 179
nextGet 0 209 179
return 1 209 180
assign 1 213 191
new 0 213 191
assign 1 213 192
add 1 213 192
assign 1 214 193
new 0 214 193
assign 1 215 194
linkedListIteratorGet 0 215 194
assign 1 215 197
hasNextGet 0 215 197
assign 1 216 199
lesser 1 216 204
nextGet 0 217 205
incrementValue 0 221 210
assign 1 223 216
notEquals 1 223 221
assign 1 224 222
new 0 224 222
return 1 224 223
assign 1 226 225
currentSet 1 226 225
return 1 226 226
assign 1 230 231
undef 1 230 236
return 1 230 237
assign 1 231 239
heldGet 0 231 239
return 1 231 240
assign 1 235 249
def 1 235 254
assign 1 235 255
nextGet 0 235 255
assign 1 235 256
def 1 235 261
assign 1 0 262
assign 1 0 265
assign 1 0 269
assign 1 236 272
nextGet 0 236 272
assign 1 236 273
heldGet 0 236 273
return 1 236 274
return 1 238 276
assign 1 242 290
def 1 242 295
assign 1 242 296
nextGet 0 242 296
assign 1 242 297
def 1 242 302
assign 1 0 303
assign 1 0 306
assign 1 0 310
assign 1 242 313
nextGet 0 242 313
assign 1 242 314
nextGet 0 242 314
assign 1 242 315
def 1 242 320
assign 1 0 321
assign 1 0 324
assign 1 0 328
assign 1 243 331
nextGet 0 243 331
assign 1 243 332
nextGet 0 243 332
assign 1 243 333
heldGet 0 243 333
return 1 243 334
return 1 245 336
assign 1 249 341
undef 1 249 346
return 1 249 347
assign 1 250 349
heldGet 0 250 349
return 1 250 350
assign 1 254 361
new 0 254 361
assign 1 254 362
equals 1 254 362
return 1 255 364
assign 1 257 366
new 0 257 366
assign 1 258 367
linkedListIteratorGet 0 258 367
assign 1 258 370
hasNextGet 0 258 370
assign 1 259 372
lesser 1 259 372
nextGet 0 260 374
incrementValue 0 264 379
assign 1 266 385
notEquals 1 266 385
return 1 267 387
assign 1 269 389
nextNodeGet 0 269 389
return 1 269 390
assign 1 273 394
newNode 1 273 394
appendNode 1 274 395
assign 1 278 402
def 1 278 407
assign 1 278 408
sameType 1 278 408
assign 1 0 410
assign 1 0 413
assign 1 0 417
addAll 1 279 420
addValueWhole 1 281 423
assign 1 286 431
def 1 286 436
assign 1 287 439
hasNextGet 0 287 439
assign 1 288 441
nextGet 0 288 441
addValueWhole 1 288 442
assign 1 294 454
def 1 294 459
assign 1 295 460
iteratorGet 0 295 460
iterateAdd 1 295 461
assign 1 300 467
newNode 1 300 467
prependNode 1 301 468
assign 1 305 475
new 0 305 475
assign 1 306 476
linkedListIteratorGet 0 306 476
assign 1 306 479
hasNextGet 0 306 479
nextGet 0 307 481
incrementValue 0 308 482
return 1 310 488
assign 1 314 492
lengthGet 0 314 492
return 1 314 493
assign 1 318 499
undef 1 318 504
assign 1 319 505
new 0 319 505
return 1 319 506
assign 1 321 508
new 0 321 508
return 1 321 509
assign 1 325 519
lengthGet 0 325 519
assign 1 326 520
new 1 326 520
assign 1 327 521
new 0 327 521
assign 1 328 522
linkedListIteratorGet 0 328 522
assign 1 328 525
hasNextGet 0 328 525
assign 1 329 527
lesser 1 329 532
assign 1 330 533
nextNodeGet 0 330 533
put 2 330 534
incrementValue 0 332 536
return 1 334 542
assign 1 338 553
lengthGet 0 338 553
assign 1 339 554
new 1 339 554
assign 1 340 555
new 0 340 555
assign 1 341 556
linkedListIteratorGet 0 341 556
assign 1 341 559
hasNextGet 0 341 559
assign 1 342 561
lesser 1 342 566
assign 1 343 567
nextNodeGet 0 343 567
assign 1 343 568
heldGet 0 343 568
put 2 343 569
incrementValue 0 345 571
return 1 347 577
assign 1 351 581
new 1 351 581
return 1 351 582
assign 1 355 586
new 1 355 586
return 1 355 587
assign 1 359 591
iteratorGet 0 359 591
return 1 359 592
assign 1 363 598
new 0 363 598
assign 1 363 599
maxGet 0 363 599
assign 1 363 600
subList 2 363 600
return 1 363 601
assign 1 367 613
create 0 367 613
assign 1 368 614
lesserEquals 1 368 619
return 1 369 620
assign 1 371 622
linkedListIteratorGet 0 371 622
assign 1 372 623
new 0 372 623
assign 1 372 626
lesser 1 372 631
assign 1 373 632
hasNextGet 0 373 632
assign 1 373 633
not 0 373 633
return 1 374 635
assign 1 376 637
nextGet 0 376 637
assign 1 377 638
greaterEquals 1 377 643
addValue 1 378 644
incrementValue 0 372 646
return 1 381 652
assign 1 419 660
assign 1 420 661
assign 1 421 664
def 1 421 669
assign 1 422 670
nextGet 0 422 670
assign 1 423 671
priorGet 0 423 671
nextSet 1 423 672
priorSet 1 424 673
assign 1 425 674
assign 1 426 675
assign 1 428 681
return 1 0 685
return 1 0 688
assign 1 0 691
assign 1 0 695
return 1 0 699
return 1 0 702
assign 1 0 705
assign 1 0 709
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1894090923: return bem_toString_0();
case -808123537: return bem_hashGet_0();
case -1706743432: return bem_iteratorGet_0();
case -1602615308: return bem_fieldIteratorGet_0();
case -583037527: return bem_firstNodeGet_0();
case 1606613844: return bem_echo_0();
case 1377047095: return bem_serializeToString_0();
case -391347582: return bem_firstNodeGetDirect_0();
case -1442653865: return bem_serializationIteratorGet_0();
case 299120428: return bem_lastGet_0();
case 1847001915: return bem_lastNodeGetDirect_0();
case 2009810245: return bem_lengthGet_0();
case -295553573: return bem_new_0();
case -1460543860: return bem_fieldNamesGet_0();
case -493975186: return bem_create_0();
case -41381797: return bem_copy_0();
case -802767414: return bem_deserializeClassNameGet_0();
case -398600922: return bem_lastNodeGet_0();
case 542329342: return bem_thirdGet_0();
case 853279026: return bem_sizeGet_0();
case -1159699712: return bem_linkedListIteratorGet_0();
case -1396413274: return bem_classNameGet_0();
case 899896295: return bem_print_0();
case 146787314: return bem_toNodeList_0();
case -2071452709: return bem_serializeContents_0();
case 85669346: return bem_once_0();
case -2077175513: return bem_isEmptyGet_0();
case 874569701: return bem_toAny_0();
case -1794506213: return bem_many_0();
case -1333837278: return bem_tagGet_0();
case 1523861211: return bem_sourceFileNameGet_0();
case -302359707: return bem_firstGet_0();
case 1235517002: return bem_toList_0();
case 209175818: return bem_secondGet_0();
case -2058395955: return bem_reverse_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1915172172: return bem_addValue_1(bevd_0);
case -600692997: return bem_prepend_1(bevd_0);
case 1328285078: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -920243169: return bem_sameObject_1(bevd_0);
case -1323160972: return bem_deleteNode_1(bevd_0);
case -2123613587: return bem_notEquals_1(bevd_0);
case -125779744: return bem_addValueWhole_1(bevd_0);
case -812324986: return bem_getNode_1(bevd_0);
case 1213137777: return bem_undef_1(bevd_0);
case 53407038: return bem_equals_1(bevd_0);
case 251588443: return bem_otherType_1(bevd_0);
case -467808258: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 537349208: return bem_lastNodeSet_1(bevd_0);
case 454270762: return bem_appendNode_1(bevd_0);
case 966131902: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 847095864: return bem_iterateAdd_1(bevd_0);
case -1739662857: return bem_lastNodeSetDirect_1(bevd_0);
case 1346697926: return bem_addAll_1(bevd_0);
case 1829433968: return bem_otherClass_1(bevd_0);
case 1775410418: return bem_prependNode_1(bevd_0);
case -319164445: return bem_undefined_1(bevd_0);
case 208018151: return bem_firstNodeSet_1(bevd_0);
case 391192402: return bem_copyTo_1(bevd_0);
case -194482552: return bem_sameType_1(bevd_0);
case 652115224: return bem_def_1(bevd_0);
case 1380048260: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 2012638821: return bem_newNode_1(bevd_0);
case -1989300932: return bem_sameClass_1(bevd_0);
case 1229660223: return bem_firstNodeSetDirect_1(bevd_0);
case 284248916: return bem_defined_1(bevd_0);
case -794252146: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2107328658: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1874085610: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1865862746: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1766660250: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1736065910: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1057911785: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1842324693: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1158884482: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126000923: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1059941037: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -1221539498: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
