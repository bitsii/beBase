package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_4_IOLogs extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOLogs() { }
private static byte[] becc_BEC_2_2_4_IOLogs_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67,0x73};
private static byte[] becc_BEC_2_2_4_IOLogs_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
public static BEC_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_inst;

public static BET_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_type;

public BEC_2_4_3_MathInt bevp_debug;
public BEC_2_4_3_MathInt bevp_info;
public BEC_2_4_3_MathInt bevp_warn;
public BEC_2_4_3_MathInt bevp_error;
public BEC_2_4_3_MathInt bevp_fatal;
public BEC_2_9_3_ContainerSet bevp_overrides;
public BEC_2_9_3_ContainerMap bevp_loggers;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_4_3_MathInt bevp_defaultOutputLevel;
public BEC_2_4_3_MathInt bevp_defaultLevel;
public BEC_2_6_6_SystemObject bevp_sink;
public BEC_2_2_4_IOLogs bem_default_0() throws Throwable {
bevp_debug = (new BEC_2_4_3_MathInt(400));
bevp_info = (new BEC_2_4_3_MathInt(300));
bevp_warn = (new BEC_2_4_3_MathInt(200));
bevp_error = (new BEC_2_4_3_MathInt(100));
bevp_fatal = (new BEC_2_4_3_MathInt(0));
bevp_overrides = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_loggers = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_defaultOutputLevel = bevp_error;
bevp_defaultLevel = bevp_info;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_setDefaultLevels_2(BEC_2_4_3_MathInt beva__defaultOutputLevel, BEC_2_4_3_MathInt beva__defaultLevel) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
try /* Line: 37*/ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = beva__defaultOutputLevel;
bevp_defaultLevel = beva__defaultLevel;
bevt_0_ta_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
/* Line: 41*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 41*/ {
bevl_kv = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = bevl_kv.bemd_0(342681197);
bevt_2_ta_ph = bevp_overrides.bem_has_1(bevt_3_ta_ph);
if (!(bevt_2_ta_ph.bevi_bool))/* Line: 42*/ {
bevt_4_ta_ph = bevl_kv.bemd_0(-621108489);
bevt_4_ta_ph.bemd_2(957351529, bevp_defaultOutputLevel, bevp_defaultLevel);
} /* Line: 43*/
} /* Line: 42*/
 else /* Line: 41*/ {
break;
} /* Line: 41*/
} /* Line: 41*/
bevp_lock.bem_unlock_0();
} /* Line: 46*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 48*/
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_putKeyLevels_3(BEC_2_4_6_TextString beva_key, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
try /* Line: 53*/ {
bevp_lock.bem_lock_0();
bevp_overrides.bem_put_1(beva_key);
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 58*/ {
bevl_log = (new BEC_2_2_3_IOLog()).bem_new_3(bevp_sink, beva_level, beva_outputLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 60*/
 else /* Line: 61*/ {
bevl_log.bem_levelSet_1(beva_level);
bevl_log.bem_outputLevelSet_1(beva_outputLevel);
} /* Line: 63*/
bevp_lock.bem_unlock_0();
} /* Line: 65*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 67*/
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_putLevels_3(BEC_2_6_6_SystemObject beva_inst, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_inst.bemd_0(-1104258259);
bem_putKeyLevels_3((BEC_2_4_6_TextString) bevt_0_ta_ph , beva_level, beva_outputLevel);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_getKey_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
try /* Line: 76*/ {
bevp_lock.bem_lock_0();
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 79*/ {
bevl_log = (new BEC_2_2_3_IOLog()).bem_new_3(bevp_sink, bevp_defaultOutputLevel, bevp_defaultLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 81*/
bevp_lock.bem_unlock_0();
} /* Line: 83*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 85*/
return bevl_log;
} /*method end*/
public BEC_2_2_3_IOLog bem_get_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_2_3_IOLog bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = beva_inst.bemd_0(-1104258259);
bevt_0_ta_ph = bem_getKey_1((BEC_2_4_6_TextString) bevt_1_ta_ph );
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_2_4_IOLogs bem_turnOn_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
try /* Line: 95*/ {
bevp_lock.bem_lock_0();
bevl_log = bem_get_1(beva_inst);
bevt_0_ta_ph = bevl_log.bem_levelGet_0();
bevt_1_ta_ph = bevl_log.bem_levelGet_0();
bem_putLevels_3(beva_inst, bevt_0_ta_ph, bevt_1_ta_ph);
bevp_lock.bem_unlock_0();
} /* Line: 99*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 101*/
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_turnOnAll_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
try /* Line: 106*/ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = bevp_defaultLevel;
bevt_0_ta_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
/* Line: 109*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 109*/ {
bevl_kv = bevt_0_ta_loop.bem_nextGet_0();
bevt_2_ta_ph = bevl_kv.bemd_0(-621108489);
bevt_2_ta_ph.bemd_1(852050482, bevp_defaultOutputLevel);
bevt_3_ta_ph = bevl_kv.bemd_0(-621108489);
bevt_3_ta_ph.bemd_1(1426623495, bevp_defaultLevel);
} /* Line: 111*/
 else /* Line: 109*/ {
break;
} /* Line: 109*/
} /* Line: 109*/
bevp_lock.bem_unlock_0();
} /* Line: 113*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 115*/
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_setAllSinks_1(BEC_2_6_6_SystemObject beva__sink) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
try /* Line: 120*/ {
bevp_lock.bem_lock_0();
bevp_sink = beva__sink;
bevt_0_ta_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
/* Line: 123*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 123*/ {
bevl_kv = bevt_0_ta_loop.bem_nextGet_0();
bevt_2_ta_ph = bevl_kv.bemd_0(-621108489);
bevt_2_ta_ph.bemd_1(-1821610247, beva__sink);
} /* Line: 124*/
 else /* Line: 123*/ {
break;
} /* Line: 123*/
} /* Line: 123*/
bevp_lock.bem_unlock_0();
} /* Line: 126*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 128*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public final BEC_2_4_3_MathInt bem_debugGetDirect_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_2_4_IOLogs bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_debugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_infoGet_0() throws Throwable {
return bevp_info;
} /*method end*/
public final BEC_2_4_3_MathInt bem_infoGetDirect_0() throws Throwable {
return bevp_info;
} /*method end*/
public BEC_2_2_4_IOLogs bem_infoSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_infoSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_warnGet_0() throws Throwable {
return bevp_warn;
} /*method end*/
public final BEC_2_4_3_MathInt bem_warnGetDirect_0() throws Throwable {
return bevp_warn;
} /*method end*/
public BEC_2_2_4_IOLogs bem_warnSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_warnSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_errorGet_0() throws Throwable {
return bevp_error;
} /*method end*/
public final BEC_2_4_3_MathInt bem_errorGetDirect_0() throws Throwable {
return bevp_error;
} /*method end*/
public BEC_2_2_4_IOLogs bem_errorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_errorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_fatalGet_0() throws Throwable {
return bevp_fatal;
} /*method end*/
public final BEC_2_4_3_MathInt bem_fatalGetDirect_0() throws Throwable {
return bevp_fatal;
} /*method end*/
public BEC_2_2_4_IOLogs bem_fatalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_fatalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_overridesGet_0() throws Throwable {
return bevp_overrides;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_overridesGetDirect_0() throws Throwable {
return bevp_overrides;
} /*method end*/
public BEC_2_2_4_IOLogs bem_overridesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_overridesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_loggersGet_0() throws Throwable {
return bevp_loggers;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_loggersGetDirect_0() throws Throwable {
return bevp_loggers;
} /*method end*/
public BEC_2_2_4_IOLogs bem_loggersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_loggersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_2_2_4_IOLogs bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultOutputLevelGet_0() throws Throwable {
return bevp_defaultOutputLevel;
} /*method end*/
public final BEC_2_4_3_MathInt bem_defaultOutputLevelGetDirect_0() throws Throwable {
return bevp_defaultOutputLevel;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultOutputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_defaultOutputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultLevelGet_0() throws Throwable {
return bevp_defaultLevel;
} /*method end*/
public final BEC_2_4_3_MathInt bem_defaultLevelGetDirect_0() throws Throwable {
return bevp_defaultLevel;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultLevelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_defaultLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGet_0() throws Throwable {
return bevp_sink;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_sinkGetDirect_0() throws Throwable {
return bevp_sink;
} /*method end*/
public BEC_2_2_4_IOLogs bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_sinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 38, 39, 40, 41, 0, 41, 41, 42, 42, 43, 43, 46, 48, 54, 55, 57, 58, 58, 59, 60, 62, 63, 65, 67, 72, 72, 77, 78, 79, 79, 80, 81, 83, 85, 87, 91, 91, 91, 96, 97, 98, 98, 98, 99, 101, 107, 108, 109, 0, 109, 109, 110, 110, 111, 111, 113, 115, 121, 122, 123, 0, 123, 123, 124, 124, 126, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 44, 45, 46, 47, 47, 50, 52, 53, 54, 56, 57, 64, 68, 77, 78, 79, 80, 85, 86, 87, 90, 91, 93, 97, 103, 104, 112, 113, 114, 119, 120, 121, 123, 127, 129, 134, 135, 136, 144, 145, 146, 147, 148, 149, 153, 165, 166, 167, 167, 170, 172, 173, 174, 175, 176, 182, 186, 197, 198, 199, 199, 202, 204, 205, 206, 212, 216, 221, 224, 227, 231, 235, 238, 241, 245, 249, 252, 255, 259, 263, 266, 269, 273, 277, 280, 283, 287, 291, 294, 297, 301, 305, 308, 311, 315, 319, 322, 325, 329, 333, 336, 339, 343, 347, 350, 353, 357, 361, 364, 367, 371};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 23
new 0 18 23
assign 1 19 24
new 0 19 24
assign 1 20 25
new 0 20 25
assign 1 21 26
new 0 21 26
assign 1 22 27
new 0 22 27
assign 1 23 28
new 0 23 28
assign 1 24 29
new 0 24 29
assign 1 25 30
new 0 25 30
assign 1 27 31
assign 1 28 32
lock 0 38 44
assign 1 39 45
assign 1 40 46
assign 1 41 47
mapIteratorGet 0 0 47
assign 1 41 50
hasNextGet 0 41 50
assign 1 41 52
nextGet 0 41 52
assign 1 42 53
keyGet 0 42 53
assign 1 42 54
has 1 42 54
assign 1 43 56
valueGet 0 43 56
setLevels 2 43 57
unlock 0 46 64
unlock 0 48 68
lock 0 54 77
put 1 55 78
assign 1 57 79
get 1 57 79
assign 1 58 80
undef 1 58 85
assign 1 59 86
new 3 59 86
put 2 60 87
levelSet 1 62 90
outputLevelSet 1 63 91
unlock 0 65 93
unlock 0 67 97
assign 1 72 103
classNameGet 0 72 103
putKeyLevels 3 72 104
lock 0 77 112
assign 1 78 113
get 1 78 113
assign 1 79 114
undef 1 79 119
assign 1 80 120
new 3 80 120
put 2 81 121
unlock 0 83 123
unlock 0 85 127
return 1 87 129
assign 1 91 134
classNameGet 0 91 134
assign 1 91 135
getKey 1 91 135
return 1 91 136
lock 0 96 144
assign 1 97 145
get 1 97 145
assign 1 98 146
levelGet 0 98 146
assign 1 98 147
levelGet 0 98 147
putLevels 3 98 148
unlock 0 99 149
unlock 0 101 153
lock 0 107 165
assign 1 108 166
assign 1 109 167
mapIteratorGet 0 0 167
assign 1 109 170
hasNextGet 0 109 170
assign 1 109 172
nextGet 0 109 172
assign 1 110 173
valueGet 0 110 173
outputLevelSet 1 110 174
assign 1 111 175
valueGet 0 111 175
levelSet 1 111 176
unlock 0 113 182
unlock 0 115 186
lock 0 121 197
assign 1 122 198
assign 1 123 199
mapIteratorGet 0 0 199
assign 1 123 202
hasNextGet 0 123 202
assign 1 123 204
nextGet 0 123 204
assign 1 124 205
valueGet 0 124 205
sinkSet 1 124 206
unlock 0 126 212
unlock 0 128 216
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
return 1 0 235
return 1 0 238
assign 1 0 241
assign 1 0 245
return 1 0 249
return 1 0 252
assign 1 0 255
assign 1 0 259
return 1 0 263
return 1 0 266
assign 1 0 269
assign 1 0 273
return 1 0 277
return 1 0 280
assign 1 0 283
assign 1 0 287
return 1 0 291
return 1 0 294
assign 1 0 297
assign 1 0 301
return 1 0 305
return 1 0 308
assign 1 0 311
assign 1 0 315
return 1 0 319
return 1 0 322
assign 1 0 325
assign 1 0 329
return 1 0 333
return 1 0 336
assign 1 0 339
assign 1 0 343
return 1 0 347
return 1 0 350
assign 1 0 353
assign 1 0 357
return 1 0 361
return 1 0 364
assign 1 0 367
assign 1 0 371
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -509817397: return bem_lockGet_0();
case -860686885: return bem_loggersGetDirect_0();
case 313703765: return bem_defaultLevelGetDirect_0();
case 911217281: return bem_create_0();
case -1877158914: return bem_toString_0();
case 312867770: return bem_copy_0();
case -214862240: return bem_default_0();
case 329327970: return bem_debugGetDirect_0();
case 1325905816: return bem_debugGet_0();
case -2130950202: return bem_infoGet_0();
case -1740139760: return bem_hashGet_0();
case -411258415: return bem_sinkGetDirect_0();
case -881029601: return bem_sourceFileNameGet_0();
case 1951226479: return bem_warnGet_0();
case 993554392: return bem_infoGetDirect_0();
case 327203525: return bem_defaultOutputLevelGet_0();
case 1581666123: return bem_fieldNamesGet_0();
case -548661343: return bem_print_0();
case 1415664588: return bem_defaultLevelGet_0();
case -1982049887: return bem_sinkGet_0();
case -54781391: return bem_turnOnAll_0();
case 636518318: return bem_errorGetDirect_0();
case 53861742: return bem_tagGet_0();
case -344507410: return bem_loggersGet_0();
case -558758224: return bem_errorGet_0();
case 1641698430: return bem_fatalGet_0();
case 805022552: return bem_iteratorGet_0();
case -1236045758: return bem_overridesGet_0();
case 451452907: return bem_defaultOutputLevelGetDirect_0();
case 1906024104: return bem_new_0();
case -1104258259: return bem_classNameGet_0();
case -231771407: return bem_lockGetDirect_0();
case -1092713656: return bem_fatalGetDirect_0();
case 1724260319: return bem_warnGetDirect_0();
case -1548164250: return bem_overridesGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 558249851: return bem_notEquals_1(bevd_0);
case 1029162264: return bem_loggersSet_1(bevd_0);
case 1497249976: return bem_debugSet_1(bevd_0);
case 1904446316: return bem_defaultOutputLevelSet_1(bevd_0);
case 228216757: return bem_fatalSetDirect_1(bevd_0);
case 1385482133: return bem_lockSet_1(bevd_0);
case -203892341: return bem_get_1(bevd_0);
case 112284551: return bem_setAllSinks_1(bevd_0);
case 1114301310: return bem_def_1(bevd_0);
case -1385235007: return bem_overridesSet_1(bevd_0);
case 1885394490: return bem_infoSet_1(bevd_0);
case 489253828: return bem_otherClass_1(bevd_0);
case -1887247579: return bem_sameObject_1(bevd_0);
case 1293339574: return bem_undef_1(bevd_0);
case 18677202: return bem_equals_1(bevd_0);
case 1006797366: return bem_defaultOutputLevelSetDirect_1(bevd_0);
case -1821610247: return bem_sinkSet_1(bevd_0);
case 690466043: return bem_overridesSetDirect_1(bevd_0);
case -753630513: return bem_getKey_1((BEC_2_4_6_TextString) bevd_0);
case 1255589592: return bem_copyTo_1(bevd_0);
case -1560907688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1028711593: return bem_errorSetDirect_1(bevd_0);
case -1872438813: return bem_turnOn_1(bevd_0);
case -1486825103: return bem_infoSetDirect_1(bevd_0);
case -1787376025: return bem_fatalSet_1(bevd_0);
case 135845454: return bem_debugSetDirect_1(bevd_0);
case -185079718: return bem_loggersSetDirect_1(bevd_0);
case 763899872: return bem_defaultLevelSet_1(bevd_0);
case 1759752481: return bem_warnSet_1(bevd_0);
case -1158093324: return bem_errorSet_1(bevd_0);
case -482991028: return bem_sinkSetDirect_1(bevd_0);
case 1073215221: return bem_lockSetDirect_1(bevd_0);
case 154276409: return bem_defaultLevelSetDirect_1(bevd_0);
case -1298677367: return bem_sameClass_1(bevd_0);
case 1376758358: return bem_otherType_1(bevd_0);
case 537700897: return bem_warnSetDirect_1(bevd_0);
case 1433290729: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 732425668: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465163535: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1053039422: return bem_setDefaultLevels_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -772732651: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 332629402: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 290208042: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 2018268066: return bem_putKeyLevels_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1692056744: return bem_putLevels_3(bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOLogs_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_4_IOLogs_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOLogs();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst = (BEC_2_2_4_IOLogs) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_type;
}
}
