package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_BEC_2_8_6_TemplateRunner_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_BEC_2_8_6_TemplateRunner_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_inst;

public static BET_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public BEC_2_8_6_TemplateRunner bem_new_0() throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_swap == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 181*/ {
bevp_swap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 181*/
return bevp_swap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_handOff == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 186*/ {
bevp_handOff = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 186*/
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) throws Throwable {
bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bem_new_0();
bem_load_1(beva_template);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bevp_replace = (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_restart_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_baton == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 206*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 208*/
bevp_stepIter = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
if (bevp_stepIter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 214*/ {
bevt_1_ta_ph = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_ta_ph.bem_iteratorGet_0();
} /* Line: 215*/
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_8_6_TemplateRunner bevt_1_ta_ph = null;
if (bevp_baton == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_1_ta_ph = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_ta_ph;
} /* Line: 222*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_8_6_TemplateRunner bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_currentRunnerGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_stepIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-970920508);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = bem_stepIterGet_0();
bevl_iter.bemd_1(-397489975, beva_node);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
if (bevp_baton == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_4_ta_ph = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 240*/
 else /* Line: 241*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 244*/
} /* Line: 239*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 248*/ {
bevt_6_ta_ph = bevl_iter.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 248*/ {
bevl_s = bevl_iter.bemd_0(-785429246);
if (bevp_handOff == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 250*/ {
bevt_8_ta_ph = bevl_s.bemd_1(1498119962, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 250*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 250*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 250*/
 else /* Line: 250*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 250*/ {
bevt_10_ta_ph = bevl_s.bemd_0(18854523);
bevt_9_ta_ph = bevp_handOff.bem_has_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 250*/
 else /* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 250*/ {
bevt_11_ta_ph = bevl_s.bemd_0(18854523);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_ta_ph = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_13_ta_ph;
} /* Line: 255*/
 else /* Line: 256*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 259*/
} /* Line: 254*/
 else /* Line: 250*/ {
bevt_14_ta_ph = bevl_s.bemd_1(1498119962, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 261*/ {
bevt_16_ta_ph = bevl_s.bemd_0(18854523);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(997331927, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 261*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 261*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 261*/
 else /* Line: 261*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 261*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /* Line: 262*/
 else /* Line: 263*/ {
bevt_18_ta_ph = bevl_s.bemd_1(1379896555, this);
bevp_output.bemd_1(995507293, bevt_18_ta_ph);
} /* Line: 264*/
} /* Line: 250*/
} /* Line: 250*/
 else /* Line: 248*/ {
break;
} /* Line: 248*/
} /* Line: 248*/
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_19_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
if (bevp_baton == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 271*/ {
bevt_4_ta_ph = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_ta_ph.bevi_bool)/* Line: 272*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 273*/
 else /* Line: 274*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 277*/
} /* Line: 272*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 281*/ {
bevt_6_ta_ph = bevl_iter.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 281*/ {
bevl_s = bevl_iter.bemd_0(-785429246);
if (bevp_handOff == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_8_ta_ph = bevl_s.bemd_1(1498119962, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 283*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 283*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 283*/
 else /* Line: 283*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 283*/ {
bevt_10_ta_ph = bevl_s.bemd_0(18854523);
bevt_9_ta_ph = bevp_handOff.bem_has_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 283*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 283*/
 else /* Line: 283*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 283*/ {
bevt_11_ta_ph = bevl_s.bemd_0(18854523);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_ta_ph = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_ta_ph.bevi_bool)/* Line: 287*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_13_ta_ph;
} /* Line: 288*/
 else /* Line: 289*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 292*/
} /* Line: 287*/
 else /* Line: 283*/ {
bevt_14_ta_ph = bevl_s.bemd_1(1498119962, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 294*/ {
bevt_16_ta_ph = bevl_s.bemd_0(18854523);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(997331927, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 294*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 294*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 294*/
 else /* Line: 294*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 294*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /* Line: 295*/
} /* Line: 283*/
} /* Line: 283*/
 else /* Line: 281*/ {
break;
} /* Line: 281*/
} /* Line: 281*/
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_18_ta_ph;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_run_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (bevp_baton == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 302*/ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 305*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 308*/ {
bevt_3_ta_ph = bevl_iter.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 308*/ {
bevl_s = bevl_iter.bemd_0(-785429246);
if (bevp_handOff == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 310*/ {
bevt_5_ta_ph = bevl_s.bemd_1(1498119962, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 310*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 310*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 310*/
 else /* Line: 310*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 310*/ {
bevt_7_ta_ph = bevl_s.bemd_0(18854523);
bevt_6_ta_ph = bevp_handOff.bem_has_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 310*/
 else /* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 310*/ {
bevt_8_ta_ph = bevl_s.bemd_0(18854523);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 316*/
 else /* Line: 317*/ {
bevt_9_ta_ph = bevl_s.bemd_1(1379896555, this);
bevp_output.bemd_1(995507293, bevt_9_ta_ph);
} /* Line: 318*/
} /* Line: 310*/
 else /* Line: 308*/ {
break;
} /* Line: 308*/
} /* Line: 308*/
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public final BEC_2_8_7_TemplateReplace bem_replaceGetDirect_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_replaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_outputGetDirect_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_output = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_outputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_output = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_stepIterGetDirect_0() throws Throwable {
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stepIter = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_stepIterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stepIter = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_swapGetDirect_0() throws Throwable {
return bevp_swap;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_swapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_handOffGetDirect_0() throws Throwable {
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_handOffSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGet_0() throws Throwable {
return bevp_baton;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_batonGetDirect_0() throws Throwable {
return bevp_baton;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_batonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public final BEC_2_7_7_ReplaceRunStep bem_runStepGetDirect_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_runStepSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {176, 181, 181, 181, 182, 186, 186, 186, 187, 191, 192, 196, 197, 201, 202, 206, 206, 207, 208, 210, 214, 214, 215, 215, 217, 221, 221, 222, 222, 224, 228, 228, 228, 228, 233, 234, 238, 238, 239, 240, 240, 243, 244, 247, 248, 249, 250, 250, 250, 0, 0, 0, 250, 250, 0, 0, 0, 251, 251, 252, 253, 254, 255, 255, 258, 259, 261, 261, 261, 0, 0, 0, 262, 262, 264, 264, 267, 267, 271, 271, 272, 273, 273, 276, 277, 280, 281, 282, 283, 283, 283, 0, 0, 0, 283, 283, 0, 0, 0, 284, 284, 285, 286, 287, 288, 288, 291, 292, 294, 294, 294, 0, 0, 0, 295, 295, 298, 298, 302, 302, 303, 304, 305, 307, 308, 309, 310, 310, 310, 0, 0, 0, 310, 310, 0, 0, 0, 311, 311, 312, 313, 314, 315, 316, 318, 318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 24, 29, 30, 32, 36, 41, 42, 44, 47, 48, 52, 53, 57, 58, 63, 68, 69, 70, 72, 78, 83, 84, 85, 87, 92, 97, 98, 99, 101, 107, 108, 109, 110, 114, 115, 141, 146, 147, 149, 150, 153, 154, 157, 160, 162, 163, 168, 169, 171, 174, 178, 181, 182, 184, 187, 191, 194, 195, 196, 197, 198, 200, 201, 204, 205, 209, 211, 212, 214, 217, 221, 224, 225, 228, 229, 237, 238, 262, 267, 268, 270, 271, 274, 275, 278, 281, 283, 284, 289, 290, 292, 295, 299, 302, 303, 305, 308, 312, 315, 316, 317, 318, 319, 321, 322, 325, 326, 330, 332, 333, 335, 338, 342, 345, 346, 354, 355, 370, 375, 376, 377, 378, 380, 383, 385, 386, 391, 392, 394, 397, 401, 404, 405, 407, 410, 414, 417, 418, 419, 420, 421, 422, 423, 426, 427, 437, 440, 443, 447, 451, 454, 457, 461, 465, 468, 472, 476, 479, 483, 487, 490, 494, 498, 501, 504, 508, 512, 515, 518, 522};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 176 19
new 0 176 19
assign 1 181 24
undef 1 181 29
assign 1 181 30
new 0 181 30
return 1 182 32
assign 1 186 36
undef 1 186 41
assign 1 186 42
new 0 186 42
return 1 187 44
new 1 191 47
assign 1 192 48
new 0 196 52
load 1 197 53
assign 1 201 57
new 0 201 57
load 2 202 58
assign 1 206 63
def 1 206 68
restart 0 207 69
assign 1 208 70
assign 1 210 72
assign 1 214 78
undef 1 214 83
assign 1 215 84
stepsGet 0 215 84
assign 1 215 85
iteratorGet 0 215 85
return 1 217 87
assign 1 221 92
def 1 221 97
assign 1 222 98
currentRunnerGet 0 222 98
return 1 222 99
return 1 224 101
assign 1 228 107
currentRunnerGet 0 228 107
assign 1 228 108
stepIterGet 0 228 108
assign 1 228 109
currentNodeGet 0 228 109
return 1 228 110
assign 1 233 114
stepIterGet 0 233 114
currentNodeSet 1 234 115
assign 1 238 141
def 1 238 146
assign 1 239 147
runToLabel 1 239 147
assign 1 240 149
new 0 240 149
return 1 240 150
restart 0 243 153
assign 1 244 154
assign 1 247 157
stepIterGet 0 247 157
assign 1 248 160
hasNextGet 0 248 160
assign 1 249 162
nextGet 0 249 162
assign 1 250 163
def 1 250 168
assign 1 250 169
sameType 1 250 169
assign 1 0 171
assign 1 0 174
assign 1 0 178
assign 1 250 181
strGet 0 250 181
assign 1 250 182
has 1 250 182
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 251 194
strGet 0 251 194
assign 1 251 195
get 1 251 195
outputSet 1 252 196
swapSet 1 253 197
assign 1 254 198
runToLabel 1 254 198
assign 1 255 200
new 0 255 200
return 1 255 201
restart 0 258 204
assign 1 259 205
assign 1 261 209
sameType 1 261 209
assign 1 261 211
strGet 0 261 211
assign 1 261 212
equals 1 261 212
assign 1 0 214
assign 1 0 217
assign 1 0 221
assign 1 262 224
new 0 262 224
return 1 262 225
assign 1 264 228
handle 1 264 228
write 1 264 229
assign 1 267 237
new 0 267 237
return 1 267 238
assign 1 271 262
def 1 271 267
assign 1 272 268
skipToLabel 1 272 268
assign 1 273 270
new 0 273 270
return 1 273 271
restart 0 276 274
assign 1 277 275
assign 1 280 278
stepIterGet 0 280 278
assign 1 281 281
hasNextGet 0 281 281
assign 1 282 283
nextGet 0 282 283
assign 1 283 284
def 1 283 289
assign 1 283 290
sameType 1 283 290
assign 1 0 292
assign 1 0 295
assign 1 0 299
assign 1 283 302
strGet 0 283 302
assign 1 283 303
has 1 283 303
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 284 315
strGet 0 284 315
assign 1 284 316
get 1 284 316
outputSet 1 285 317
swapSet 1 286 318
assign 1 287 319
skipToLabel 1 287 319
assign 1 288 321
new 0 288 321
return 1 288 322
restart 0 291 325
assign 1 292 326
assign 1 294 330
sameType 1 294 330
assign 1 294 332
strGet 0 294 332
assign 1 294 333
equals 1 294 333
assign 1 0 335
assign 1 0 338
assign 1 0 342
assign 1 295 345
new 0 295 345
return 1 295 346
assign 1 298 354
new 0 298 354
return 1 298 355
assign 1 302 370
def 1 302 375
run 0 303 376
restart 0 304 377
assign 1 305 378
assign 1 307 380
stepIterGet 0 307 380
assign 1 308 383
hasNextGet 0 308 383
assign 1 309 385
nextGet 0 309 385
assign 1 310 386
def 1 310 391
assign 1 310 392
sameType 1 310 392
assign 1 0 394
assign 1 0 397
assign 1 0 401
assign 1 310 404
strGet 0 310 404
assign 1 310 405
has 1 310 405
assign 1 0 407
assign 1 0 410
assign 1 0 414
assign 1 311 417
strGet 0 311 417
assign 1 311 418
get 1 311 418
outputSet 1 312 419
swapSet 1 313 420
run 0 314 421
restart 0 315 422
assign 1 316 423
assign 1 318 426
handle 1 318 426
write 1 318 427
return 1 0 437
return 1 0 440
assign 1 0 443
assign 1 0 447
return 1 0 451
return 1 0 454
assign 1 0 457
assign 1 0 461
return 1 0 465
assign 1 0 468
assign 1 0 472
return 1 0 476
assign 1 0 479
assign 1 0 483
return 1 0 487
assign 1 0 490
assign 1 0 494
return 1 0 498
return 1 0 501
assign 1 0 504
assign 1 0 508
return 1 0 512
return 1 0 515
assign 1 0 518
assign 1 0 522
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -899256741: return bem_toString_0();
case -1915666683: return bem_serializationIteratorGet_0();
case 1315725661: return bem_hashGet_0();
case 1971272809: return bem_stepIterGetDirect_0();
case 734038395: return bem_handOffGet_0();
case -407687427: return bem_fieldNamesGet_0();
case -604810828: return bem_replaceGet_0();
case -1514184278: return bem_serializeContents_0();
case 1270756764: return bem_print_0();
case -1900527229: return bem_outputGet_0();
case 1293575145: return bem_serializeToString_0();
case 350194081: return bem_currentRunnerGet_0();
case -1945570638: return bem_once_0();
case -1959899288: return bem_fieldIteratorGet_0();
case 672005749: return bem_handOffGetDirect_0();
case 991622112: return bem_batonGetDirect_0();
case -479412451: return bem_iteratorGet_0();
case 226027115: return bem_stepIterGet_0();
case 830944435: return bem_run_0();
case -552634269: return bem_outputGetDirect_0();
case 119080647: return bem_replaceGetDirect_0();
case 818210964: return bem_toAny_0();
case -749268313: return bem_copy_0();
case -327712425: return bem_many_0();
case 1210407094: return bem_tagGet_0();
case -1085396793: return bem_runStepGet_0();
case -501360864: return bem_swapGet_0();
case 846353007: return bem_echo_0();
case -278470293: return bem_batonGet_0();
case -970920508: return bem_currentNodeGet_0();
case 887254713: return bem_sourceFileNameGet_0();
case -179439117: return bem_swapGetDirect_0();
case 826167413: return bem_classNameGet_0();
case 113247096: return bem_restart_0();
case -344688418: return bem_new_0();
case -519581463: return bem_deserializeClassNameGet_0();
case 175852074: return bem_runStepGetDirect_0();
case 770986263: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1715370141: return bem_sameClass_1(bevd_0);
case 509956737: return bem_def_1(bevd_0);
case -597164057: return bem_defined_1(bevd_0);
case 1494563025: return bem_batonSet_1(bevd_0);
case 767117759: return bem_replaceSet_1(bevd_0);
case -397489975: return bem_currentNodeSet_1(bevd_0);
case 1790583029: return bem_outputSet_1(bevd_0);
case 836257682: return bem_handOffSet_1(bevd_0);
case -1548523977: return bem_otherClass_1(bevd_0);
case -1468949165: return bem_undefined_1(bevd_0);
case 509252275: return bem_sameObject_1(bevd_0);
case 2119802592: return bem_outputSetDirect_1(bevd_0);
case 2011695784: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 2144395088: return bem_undef_1(bevd_0);
case 90328539: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case 248598654: return bem_copyTo_1(bevd_0);
case -2022797159: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case -907147745: return bem_swapSetDirect_1(bevd_0);
case -1466208573: return bem_stepIterSet_1(bevd_0);
case -1343727458: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1548942085: return bem_swapSet_1(bevd_0);
case 1477732575: return bem_otherType_1(bevd_0);
case 1946977825: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 784918995: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -44834796: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
case -1672381432: return bem_batonSetDirect_1(bevd_0);
case -233300707: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1505524759: return bem_runStepSet_1(bevd_0);
case 1772678539: return bem_notEquals_1(bevd_0);
case 1498119962: return bem_sameType_1(bevd_0);
case 997331927: return bem_equals_1(bevd_0);
case -1709803447: return bem_stepIterSetDirect_1(bevd_0);
case 1611962343: return bem_handOffSetDirect_1(bevd_0);
case -1816323396: return bem_replaceSetDirect_1(bevd_0);
case 2141366037: return bem_runStepSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -455603186: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -403771483: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 262774206: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1189130153: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -390764901: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1675736992: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1904308898: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -319997805: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_TemplateRunner_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_6_TemplateRunner_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_TemplateRunner();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst = (BEC_2_8_6_TemplateRunner) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_type;
}
}
