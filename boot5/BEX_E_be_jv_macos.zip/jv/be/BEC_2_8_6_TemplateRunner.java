package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_BEC_2_8_6_TemplateRunner_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_BEC_2_8_6_TemplateRunner_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_inst;

public static BET_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public BEC_2_6_5_SystemTypes bevp_stp;
public BEC_2_8_6_TemplateRunner bem_new_0() throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
bevp_stp = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_swap == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 182*/ {
bevp_swap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 182*/
return bevp_swap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_handOff == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 187*/ {
bevp_handOff = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 187*/
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) throws Throwable {
bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bem_new_0();
bem_load_1(beva_template);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bevp_replace = (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_restart_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_baton == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 207*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 209*/
bevp_stepIter = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
if (bevp_stepIter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 215*/ {
bevt_1_ta_ph = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_ta_ph.bem_iteratorGet_0();
} /* Line: 216*/
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_8_6_TemplateRunner bevt_1_ta_ph = null;
if (bevp_baton == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 222*/ {
bevt_1_ta_ph = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_ta_ph;
} /* Line: 223*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_8_6_TemplateRunner bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_currentRunnerGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_stepIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1481196743);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = bem_stepIterGet_0();
bevl_iter.bemd_1(1509382360, beva_node);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
if (bevp_baton == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_4_ta_ph = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_ta_ph.bevi_bool)/* Line: 240*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 241*/
 else /* Line: 242*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 245*/
} /* Line: 240*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 249*/ {
bevt_6_ta_ph = bevl_iter.bemd_0(219092993);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 249*/ {
bevl_s = bevl_iter.bemd_0(-1911588285);
if (bevp_handOff == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 251*/ {
bevt_8_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_8_ta_ph.bevi_bool)/* Line: 251*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 251*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 251*/
 else /* Line: 251*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 251*/ {
bevt_10_ta_ph = bevl_s.bemd_0(-506826780);
bevt_9_ta_ph = bevp_handOff.bem_has_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 251*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 251*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 251*/
 else /* Line: 251*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 251*/ {
bevt_11_ta_ph = bevl_s.bemd_0(-506826780);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_ta_ph = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_ta_ph.bevi_bool)/* Line: 255*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_13_ta_ph;
} /* Line: 256*/
 else /* Line: 257*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 260*/
} /* Line: 255*/
 else /* Line: 251*/ {
bevt_14_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_14_ta_ph.bevi_bool)/* Line: 262*/ {
bevt_16_ta_ph = bevl_s.bemd_0(-506826780);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-611752368, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 262*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 262*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 262*/
 else /* Line: 262*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 262*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /* Line: 263*/
 else /* Line: 264*/ {
bevt_18_ta_ph = bevl_s.bemd_1(-931840208, this);
bevp_output.bemd_1(-1954572111, bevt_18_ta_ph);
} /* Line: 265*/
} /* Line: 251*/
} /* Line: 251*/
 else /* Line: 249*/ {
break;
} /* Line: 249*/
} /* Line: 249*/
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_19_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
if (bevp_baton == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 272*/ {
bevt_4_ta_ph = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_ta_ph.bevi_bool)/* Line: 273*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 274*/
 else /* Line: 275*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 278*/
} /* Line: 273*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 282*/ {
bevt_6_ta_ph = bevl_iter.bemd_0(219092993);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 282*/ {
bevl_s = bevl_iter.bemd_0(-1911588285);
if (bevp_handOff == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 284*/ {
bevt_8_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_8_ta_ph.bevi_bool)/* Line: 284*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 284*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 284*/
 else /* Line: 284*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 284*/ {
bevt_10_ta_ph = bevl_s.bemd_0(-506826780);
bevt_9_ta_ph = bevp_handOff.bem_has_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 284*/
 else /* Line: 284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 284*/ {
bevt_11_ta_ph = bevl_s.bemd_0(-506826780);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_ta_ph = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_ta_ph.bevi_bool)/* Line: 288*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_13_ta_ph;
} /* Line: 289*/
 else /* Line: 290*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 293*/
} /* Line: 288*/
 else /* Line: 284*/ {
bevt_14_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_14_ta_ph.bevi_bool)/* Line: 295*/ {
bevt_16_ta_ph = bevl_s.bemd_0(-506826780);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-611752368, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 295*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 295*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 295*/
 else /* Line: 295*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 295*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /* Line: 296*/
} /* Line: 284*/
} /* Line: 284*/
 else /* Line: 282*/ {
break;
} /* Line: 282*/
} /* Line: 282*/
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_18_ta_ph;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_run_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (bevp_baton == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 303*/ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 306*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 309*/ {
bevt_3_ta_ph = bevl_iter.bemd_0(219092993);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 309*/ {
bevl_s = bevl_iter.bemd_0(-1911588285);
if (bevp_handOff == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 311*/ {
bevt_5_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_5_ta_ph.bevi_bool)/* Line: 311*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 311*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 311*/
 else /* Line: 311*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 311*/ {
bevt_7_ta_ph = bevl_s.bemd_0(-506826780);
bevt_6_ta_ph = bevp_handOff.bem_has_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 311*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 311*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 311*/
 else /* Line: 311*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 311*/ {
bevt_8_ta_ph = bevl_s.bemd_0(-506826780);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 317*/
 else /* Line: 318*/ {
bevt_9_ta_ph = bevl_s.bemd_1(-931840208, this);
bevp_output.bemd_1(-1954572111, bevt_9_ta_ph);
} /* Line: 319*/
} /* Line: 311*/
 else /* Line: 309*/ {
break;
} /* Line: 309*/
} /* Line: 309*/
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_output = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stepIter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGet_0() throws Throwable {
return bevp_baton;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stpGet_0() throws Throwable {
return bevp_stp;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stp = (BEC_2_6_5_SystemTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {176, 177, 182, 182, 182, 183, 187, 187, 187, 188, 192, 193, 197, 198, 202, 203, 207, 207, 208, 209, 211, 215, 215, 216, 216, 218, 222, 222, 223, 223, 225, 229, 229, 229, 229, 234, 235, 239, 239, 240, 241, 241, 244, 245, 248, 249, 250, 251, 251, 251, 0, 0, 0, 251, 251, 0, 0, 0, 252, 252, 253, 254, 255, 256, 256, 259, 260, 262, 262, 262, 0, 0, 0, 263, 263, 265, 265, 268, 268, 272, 272, 273, 274, 274, 277, 278, 281, 282, 283, 284, 284, 284, 0, 0, 0, 284, 284, 0, 0, 0, 285, 285, 286, 287, 288, 289, 289, 292, 293, 295, 295, 295, 0, 0, 0, 296, 296, 299, 299, 303, 303, 304, 305, 306, 308, 309, 310, 311, 311, 311, 0, 0, 0, 311, 311, 0, 0, 0, 312, 312, 313, 314, 315, 316, 317, 319, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 26, 31, 32, 34, 38, 43, 44, 46, 49, 50, 54, 55, 59, 60, 65, 70, 71, 72, 74, 80, 85, 86, 87, 89, 94, 99, 100, 101, 103, 109, 110, 111, 112, 116, 117, 143, 148, 149, 151, 152, 155, 156, 159, 162, 164, 165, 170, 171, 173, 176, 180, 183, 184, 186, 189, 193, 196, 197, 198, 199, 200, 202, 203, 206, 207, 211, 213, 214, 216, 219, 223, 226, 227, 230, 231, 239, 240, 264, 269, 270, 272, 273, 276, 277, 280, 283, 285, 286, 291, 292, 294, 297, 301, 304, 305, 307, 310, 314, 317, 318, 319, 320, 321, 323, 324, 327, 328, 332, 334, 335, 337, 340, 344, 347, 348, 356, 357, 372, 377, 378, 379, 380, 382, 385, 387, 388, 393, 394, 396, 399, 403, 406, 407, 409, 412, 416, 419, 420, 421, 422, 423, 424, 425, 428, 429, 439, 442, 446, 449, 453, 457, 461, 465, 468, 472, 475, 479, 482};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 176 20
new 0 176 20
assign 1 177 21
new 0 177 21
assign 1 182 26
undef 1 182 31
assign 1 182 32
new 0 182 32
return 1 183 34
assign 1 187 38
undef 1 187 43
assign 1 187 44
new 0 187 44
return 1 188 46
new 1 192 49
assign 1 193 50
new 0 197 54
load 1 198 55
assign 1 202 59
new 0 202 59
load 2 203 60
assign 1 207 65
def 1 207 70
restart 0 208 71
assign 1 209 72
assign 1 211 74
assign 1 215 80
undef 1 215 85
assign 1 216 86
stepsGet 0 216 86
assign 1 216 87
iteratorGet 0 216 87
return 1 218 89
assign 1 222 94
def 1 222 99
assign 1 223 100
currentRunnerGet 0 223 100
return 1 223 101
return 1 225 103
assign 1 229 109
currentRunnerGet 0 229 109
assign 1 229 110
stepIterGet 0 229 110
assign 1 229 111
currentNodeGet 0 229 111
return 1 229 112
assign 1 234 116
stepIterGet 0 234 116
currentNodeSet 1 235 117
assign 1 239 143
def 1 239 148
assign 1 240 149
runToLabel 1 240 149
assign 1 241 151
new 0 241 151
return 1 241 152
restart 0 244 155
assign 1 245 156
assign 1 248 159
stepIterGet 0 248 159
assign 1 249 162
hasNextGet 0 249 162
assign 1 250 164
nextGet 0 250 164
assign 1 251 165
def 1 251 170
assign 1 251 171
sameType 2 251 171
assign 1 0 173
assign 1 0 176
assign 1 0 180
assign 1 251 183
strGet 0 251 183
assign 1 251 184
has 1 251 184
assign 1 0 186
assign 1 0 189
assign 1 0 193
assign 1 252 196
strGet 0 252 196
assign 1 252 197
get 1 252 197
outputSet 1 253 198
swapSet 1 254 199
assign 1 255 200
runToLabel 1 255 200
assign 1 256 202
new 0 256 202
return 1 256 203
restart 0 259 206
assign 1 260 207
assign 1 262 211
sameType 2 262 211
assign 1 262 213
strGet 0 262 213
assign 1 262 214
equals 1 262 214
assign 1 0 216
assign 1 0 219
assign 1 0 223
assign 1 263 226
new 0 263 226
return 1 263 227
assign 1 265 230
handle 1 265 230
write 1 265 231
assign 1 268 239
new 0 268 239
return 1 268 240
assign 1 272 264
def 1 272 269
assign 1 273 270
skipToLabel 1 273 270
assign 1 274 272
new 0 274 272
return 1 274 273
restart 0 277 276
assign 1 278 277
assign 1 281 280
stepIterGet 0 281 280
assign 1 282 283
hasNextGet 0 282 283
assign 1 283 285
nextGet 0 283 285
assign 1 284 286
def 1 284 291
assign 1 284 292
sameType 2 284 292
assign 1 0 294
assign 1 0 297
assign 1 0 301
assign 1 284 304
strGet 0 284 304
assign 1 284 305
has 1 284 305
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 285 317
strGet 0 285 317
assign 1 285 318
get 1 285 318
outputSet 1 286 319
swapSet 1 287 320
assign 1 288 321
skipToLabel 1 288 321
assign 1 289 323
new 0 289 323
return 1 289 324
restart 0 292 327
assign 1 293 328
assign 1 295 332
sameType 2 295 332
assign 1 295 334
strGet 0 295 334
assign 1 295 335
equals 1 295 335
assign 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 296 347
new 0 296 347
return 1 296 348
assign 1 299 356
new 0 299 356
return 1 299 357
assign 1 303 372
def 1 303 377
run 0 304 378
restart 0 305 379
assign 1 306 380
assign 1 308 382
stepIterGet 0 308 382
assign 1 309 385
hasNextGet 0 309 385
assign 1 310 387
nextGet 0 310 387
assign 1 311 388
def 1 311 393
assign 1 311 394
sameType 2 311 394
assign 1 0 396
assign 1 0 399
assign 1 0 403
assign 1 311 406
strGet 0 311 406
assign 1 311 407
has 1 311 407
assign 1 0 409
assign 1 0 412
assign 1 0 416
assign 1 312 419
strGet 0 312 419
assign 1 312 420
get 1 312 420
outputSet 1 313 421
swapSet 1 314 422
run 0 315 423
restart 0 316 424
assign 1 317 425
assign 1 319 428
handle 1 319 428
write 1 319 429
return 1 0 439
assign 1 0 442
return 1 0 446
assign 1 0 449
assign 1 0 453
assign 1 0 457
assign 1 0 461
return 1 0 465
assign 1 0 468
return 1 0 472
assign 1 0 475
return 1 0 479
assign 1 0 482
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 707791423: return bem_replaceGet_0();
case -146244539: return bem_new_0();
case -1683996620: return bem_swapGet_0();
case -765297886: return bem_currentRunnerGet_0();
case 486070658: return bem_restart_0();
case -442020683: return bem_handOffGet_0();
case -1293470343: return bem_hashGet_0();
case 12637792: return bem_toString_0();
case -1120158825: return bem_print_0();
case 1696325472: return bem_copy_0();
case 1481196743: return bem_currentNodeGet_0();
case 955322063: return bem_stpGet_0();
case -774209410: return bem_outputGet_0();
case -1485760361: return bem_iteratorGet_0();
case 1523607601: return bem_run_0();
case 966769950: return bem_runStepGet_0();
case -1105484206: return bem_batonGet_0();
case 13401454: return bem_create_0();
case -1607105209: return bem_stepIterGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1075891113: return bem_stepIterSet_1(bevd_0);
case -926391521: return bem_swapSet_1(bevd_0);
case -1018588943: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 1259270525: return bem_stpSet_1(bevd_0);
case -1424023357: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1975102115: return bem_runStepSet_1(bevd_0);
case -44259182: return bem_def_1(bevd_0);
case -580491199: return bem_undef_1(bevd_0);
case 1509382360: return bem_currentNodeSet_1(bevd_0);
case 522592536: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
case -855732496: return bem_copyTo_1(bevd_0);
case 997731365: return bem_replaceSet_1(bevd_0);
case -70001973: return bem_handOffSet_1(bevd_0);
case -1689645447: return bem_notEquals_1(bevd_0);
case 2127680456: return bem_outputSet_1(bevd_0);
case 192176403: return bem_batonSet_1(bevd_0);
case -611752368: return bem_equals_1(bevd_0);
case 240453960: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1130899650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -382539192: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1299735066: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -859667978: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 504776993: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_TemplateRunner_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_6_TemplateRunner_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_TemplateRunner();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst = (BEC_2_8_6_TemplateRunner) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_type;
}
}
