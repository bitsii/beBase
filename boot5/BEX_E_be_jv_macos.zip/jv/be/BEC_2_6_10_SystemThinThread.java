package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_10_SystemThinThread extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemThinThread() { }

   volatile public Thread bevi_thread;
   static class BECS_Runnable implements Runnable {
    volatile BEC_2_6_10_SystemThinThread bevi_sysThread = null;
    BECS_Runnable(BEC_2_6_10_SystemThinThread bevi_sysThread) {
      this.bevi_sysThread = bevi_sysThread;
    }
    public void run() {
      try {
        bevi_sysThread.bem_main_0();
      } catch (Throwable t) {
        throw new RuntimeException(t.getMessage(), t);
      }
    }
   }
   private static byte[] becc_BEC_2_6_10_SystemThinThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x69,0x6E,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_10_SystemThinThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemThinThread bece_BEC_2_6_10_SystemThinThread_bevs_inst;

public static BET_2_6_10_SystemThinThread bece_BEC_2_6_10_SystemThinThread_bevs_type;

public BEC_2_6_6_SystemObject bevp_toRun;
public BEC_2_6_10_SystemThinThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) throws Throwable {
bevp_toRun = beva__toRun;
return this;
} /*method end*/
public BEC_2_6_10_SystemThinThread bem_start_0() throws Throwable {

     BECS_Runnable bevi_runnable = new BECS_Runnable(this);
     bevi_thread = new Thread(bevi_runnable);
     bevi_thread.start();
     return this;
} /*method end*/
public BEC_2_6_10_SystemThinThread bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
try /* Line: 448*/ {
bevp_toRun.bemd_0(-498462045);
} /* Line: 449*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 450*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wait_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

     bevi_thread.join();
     bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toRunGet_0() throws Throwable {
return bevp_toRun;
} /*method end*/
public BEC_2_6_10_SystemThinThread bem_toRunSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toRun = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {419, 449, 476, 476, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 43, 54, 55, 58, 61};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 419 30
main 0 449 43
assign 1 476 54
new 0 476 54
return 1 476 55
return 1 0 58
assign 1 0 61
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1593363650: return bem_hashGet_0();
case -678474722: return bem_print_0();
case 1570674726: return bem_create_0();
case 16987715: return bem_new_0();
case -992168582: return bem_iteratorGet_0();
case -1952193259: return bem_copy_0();
case -139563795: return bem_toRunGet_0();
case -195875575: return bem_wait_0();
case 2084132803: return bem_start_0();
case -320608485: return bem_toString_0();
case -498462045: return bem_main_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1711336271: return bem_new_1(bevd_0);
case 5440256: return bem_print_1(bevd_0);
case -974275: return bem_equals_1(bevd_0);
case 1200364408: return bem_copyTo_1(bevd_0);
case 2143570660: return bem_notEquals_1(bevd_0);
case -2045095560: return bem_def_1(bevd_0);
case -1334630507: return bem_undef_1(bevd_0);
case 665544293: return bem_toRunSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1869814166: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -937076209: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 671415301: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1491209441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemThinThread_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_10_SystemThinThread_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemThinThread();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_inst = (BEC_2_6_10_SystemThinThread) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_type;
}
}
