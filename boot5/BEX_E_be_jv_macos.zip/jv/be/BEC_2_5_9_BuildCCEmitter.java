package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_24, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x3E,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_35, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 31));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_55, 20));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x3E,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x66,0x72,0x6F,0x6D,0x5F,0x74,0x68,0x69,0x73,0x28,0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_56, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_60, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_65, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_68, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_69, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_80, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_81, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_82, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_83, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_84, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_85, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_86, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_87, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_88, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_89, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_90, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_91, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_92, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_93, 18));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x3E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_94, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_95, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_97, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_98, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_100, 19));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_101, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_109, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_110, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_111, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_112, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_113, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x3C,0x69,0x6F,0x73,0x74,0x72,0x65,0x61,0x6D,0x3E,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x3C,0x6D,0x65,0x6D,0x6F,0x72,0x79,0x3E,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x5B,0x5D,0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_136, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_137, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_141, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_142, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x7D};
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 38 */
 else  /* Line: 39 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 40 */
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
if (bevp_parentConf == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_tmpany_phold = bevl_begin.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 49 */
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_19_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevp_heow.bem_write_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(76, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(62, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevp_heow.bem_write_1(bevt_24_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevp_deow.bem_write_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
return bevt_30_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevt_19_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_20_tmpany_phold);
bevt_24_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(-1529403712);
bevt_22_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_23_tmpany_phold );
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_17_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevt_27_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1857411251);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1426855075);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_6_tmpany_phold = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevt_0_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevt_16_tmpany_phold = bevp_methods.bem_addValue_1(bevt_17_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_22_tmpany_phold = bevp_classHeadBody.bem_addValue_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_24_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_19_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevp_classHeadBody.bem_addValue_1(bevt_28_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_tmpany_phold.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
} /* Line: 129 */
 else  /* Line: 128 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1272147718);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(729465196, bevt_6_tmpany_phold);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 130 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevl_tcall = bevt_7_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
} /* Line: 131 */
 else  /* Line: 128 */ {
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1272147718);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(729465196, bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 132 */ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
} /* Line: 133 */
 else  /* Line: 134 */ {
bevt_15_tmpany_phold = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_15_tmpany_phold );
} /* Line: 135 */
} /* Line: 128 */
} /* Line: 128 */
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1272147718);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(729465196, bevt_3_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevl_tcall = bevt_4_tmpany_phold.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 143 */
bevt_5_tmpany_phold = super.bem_formCallTarg_1(beva_node);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_12_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 149 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_3_tmpany_phold = beva_b.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_2_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 150 */
 else  /* Line: 151 */ {
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_9_tmpany_phold = beva_b.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_12_tmpany_phold = bem_getClassConfig_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_relEmitName_1(bevt_14_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_8_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 152 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevl_ccall = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
} /* Line: 158 */
 else  /* Line: 159 */ {
bevl_ccall = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
} /* Line: 160 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_18_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_22_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-27020439);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-27020439);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 186 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 187 */
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_20_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(beva_lisz);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_belsName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
return bevt_12_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 202 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1272147718);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_19_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_36_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_47_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
if (bevp_deow == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_7_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_3_tmpany_phold.bem_add_1(bevp_headExt);
bevt_12_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_13_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_9_tmpany_phold.bem_add_1(bevp_headExt);
bevt_15_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_15_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_16_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_20_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_fileGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_existsGet_0();
if (bevt_18_tmpany_phold.bevi_bool) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevt_22_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold.bem_makeDirs_0();
} /* Line: 258 */
bevt_24_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_23_tmpany_phold.bemd_0(1632435390);
bevt_26_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_25_tmpany_phold.bemd_0(1632435390);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevp_heow.bem_write_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_heow.bem_write_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevp_heow.bem_write_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevp_heow.bem_write_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevp_deow.bem_write_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_heow.bem_write_1(bevt_32_tmpany_phold);
bevt_34_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_has_1(bevt_35_tmpany_phold);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevt_37_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_get_1(bevt_38_tmpany_phold);
bevt_0_tmpany_loop = bevt_36_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 277 */ {
bevt_39_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-331472942);
if (bevt_39_tmpany_phold != null && bevt_39_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_39_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-654009727);
bevt_40_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_40_tmpany_phold.bem_fileGet_0();
bevt_42_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(1632435390);
bevl_inc = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bemd_0(-1738466141);
bevt_43_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_43_tmpany_phold.bemd_0(765609192);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 283 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
} /* Line: 277 */
bevt_45_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_48_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
bevt_1_tmpany_loop = bevt_47_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 288 */ {
bevt_50_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-331472942);
if (bevt_50_tmpany_phold != null && bevt_50_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 288 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(-654009727);
bevt_51_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_51_tmpany_phold.bem_fileGet_0();
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(1632435390);
bevl_inc = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bemd_0(-1738466141);
bevt_54_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_54_tmpany_phold.bemd_0(765609192);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 294 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
} /* Line: 288 */
} /* Line: 286 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_14_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevt_7_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 310 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(1632435390);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevp_shlibe.bem_write_1(bevt_10_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_12_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_15_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_get_1(bevt_16_tmpany_phold);
bevt_0_tmpany_loop = bevt_14_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_17_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-331472942);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 317 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-654009727);
bevt_18_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_18_tmpany_phold.bem_fileGet_0();
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1632435390);
bevl_inc = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bemd_0(-1738466141);
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_21_tmpany_phold.bemd_0(765609192);
bevt_22_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_22_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 322 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 316 */
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
beva_libe.bem_write_1(bevt_0_tmpany_phold);
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevp_deow.bem_write_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevp_heow.bem_write_1(bevt_2_tmpany_phold);
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_1_tmpany_phold = beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(-1108389163);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 361 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-331472942);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 361 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(-654009727);
if (bevl_first.bevi_bool) /* Line: 362 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 363 */
 else  /* Line: 364 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 365 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 367 */
 else  /* Line: 361 */ {
break;
} /* Line: 361 */
} /* Line: 361 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_7_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_4_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_0_tmpany_phold.bem_relEmitName_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-1529403712);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_2_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_12_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_11_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_19_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_20_tmpany_phold, bevl_asnr);
} /* Line: 399 */
bevt_24_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_151));
bevt_27_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_153));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_154));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_addValue_1(bevt_42_tmpany_phold);
bevt_29_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
bevt_45_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_46_tmpany_phold);
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_157));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_addValue_1(bevt_47_tmpany_phold);
bevt_43_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_158));
bevt_48_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_49_tmpany_phold);
bevt_48_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 19, 20, 22, 23, 27, 29, 30, 31, 32, 33, 37, 37, 38, 38, 38, 40, 40, 42, 42, 42, 42, 42, 42, 44, 44, 45, 45, 47, 47, 49, 49, 49, 49, 49, 49, 49, 52, 52, 54, 54, 56, 58, 60, 62, 64, 64, 65, 65, 66, 66, 67, 67, 68, 68, 70, 70, 70, 70, 70, 70, 72, 72, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 79, 79, 79, 83, 85, 85, 86, 90, 90, 90, 91, 92, 92, 92, 92, 92, 92, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 99, 99, 103, 103, 107, 107, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 112, 114, 116, 116, 116, 116, 116, 116, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 120, 122, 122, 128, 128, 128, 128, 129, 130, 130, 130, 130, 131, 131, 131, 131, 131, 132, 132, 132, 132, 133, 135, 135, 137, 141, 141, 141, 141, 142, 142, 143, 145, 145, 149, 149, 149, 150, 150, 150, 150, 150, 150, 150, 152, 152, 152, 152, 152, 152, 152, 152, 152, 157, 157, 158, 160, 162, 162, 162, 162, 162, 162, 162, 162, 167, 167, 171, 171, 171, 171, 171, 171, 171, 171, 171, 171, 171, 171, 171, 171, 171, 172, 172, 172, 172, 172, 172, 172, 172, 172, 174, 174, 174, 178, 178, 178, 178, 178, 178, 178, 178, 178, 178, 178, 178, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 193, 193, 193, 193, 193, 198, 199, 200, 200, 201, 201, 202, 202, 204, 204, 204, 205, 211, 211, 211, 211, 215, 215, 219, 219, 219, 219, 219, 220, 220, 220, 220, 220, 220, 221, 221, 221, 222, 222, 222, 222, 222, 222, 222, 222, 224, 224, 228, 228, 232, 232, 232, 232, 236, 236, 251, 251, 252, 253, 253, 253, 253, 253, 253, 253, 254, 254, 254, 254, 254, 254, 254, 255, 255, 256, 256, 257, 257, 257, 257, 257, 258, 258, 258, 260, 260, 260, 261, 261, 261, 263, 263, 264, 264, 265, 265, 266, 266, 268, 268, 269, 269, 275, 275, 275, 277, 277, 277, 277, 0, 277, 277, 279, 279, 280, 280, 280, 281, 281, 283, 286, 286, 286, 288, 288, 288, 288, 0, 288, 288, 290, 290, 291, 291, 291, 292, 292, 294, 301, 302, 307, 307, 308, 309, 309, 309, 309, 309, 310, 310, 310, 312, 312, 312, 314, 314, 315, 316, 316, 316, 317, 317, 317, 317, 0, 317, 317, 318, 318, 319, 319, 319, 320, 320, 321, 321, 322, 328, 333, 333, 334, 335, 337, 337, 339, 339, 340, 341, 346, 346, 350, 350, 350, 350, 350, 355, 355, 356, 358, 358, 358, 358, 360, 361, 0, 361, 361, 363, 365, 365, 367, 367, 367, 367, 367, 367, 371, 371, 371, 376, 378, 378, 378, 378, 378, 380, 380, 380, 380, 380, 380, 380, 380, 380, 382, 386, 386, 387, 387, 387, 387, 388, 392, 392, 392, 393, 393, 393, 394, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 396, 397, 398, 398, 399, 399, 402, 402, 402, 402, 402, 402, 402, 404, 404, 404, 407, 407, 407, 407, 407, 407, 407, 407, 407, 407, 407, 407, 407, 407, 407, 409, 409, 409, 409, 409, 409, 411, 411, 411, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 265, 270, 271, 272, 273, 276, 277, 279, 280, 281, 282, 283, 284, 285, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 397, 398, 399, 400, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 444, 445, 449, 450, 454, 455, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 542, 543, 544, 549, 550, 553, 554, 555, 556, 558, 559, 560, 561, 562, 565, 566, 567, 568, 570, 573, 574, 578, 588, 589, 590, 591, 593, 594, 595, 597, 598, 617, 618, 623, 624, 625, 626, 627, 628, 629, 630, 633, 634, 635, 636, 637, 638, 639, 640, 641, 656, 657, 659, 662, 664, 665, 666, 667, 668, 669, 670, 671, 675, 676, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 841, 842, 843, 844, 845, 855, 856, 857, 858, 860, 861, 862, 863, 865, 866, 867, 868, 875, 876, 877, 878, 882, 883, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 933, 934, 940, 941, 942, 943, 947, 948, 1013, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1046, 1047, 1048, 1049, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1073, 1074, 1075, 1076, 1076, 1079, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1096, 1097, 1098, 1100, 1101, 1102, 1103, 1103, 1106, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 1116, 1127, 1128, 1158, 1163, 1164, 1165, 1166, 1167, 1168, 1173, 1174, 1175, 1176, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1188, 1189, 1190, 1191, 1191, 1194, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1214, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1228, 1229, 1234, 1235, 1242, 1243, 1244, 1245, 1246, 1268, 1269, 1270, 1271, 1272, 1273, 1274, 1275, 1276, 1276, 1279, 1281, 1283, 1286, 1287, 1289, 1290, 1291, 1292, 1293, 1294, 1300, 1301, 1302, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1344, 1345, 1346, 1347, 1348, 1349, 1350, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1433, 1434, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1473, 1476, 1480, 1483, 1487, 1490, 1494, 1497, 1501, 1504, 1508, 1511, 1515, 1518, 1522, 1525, 1529, 1532};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 218
new 0 18 218
assign 1 19 219
new 0 19 219
assign 1 20 220
new 0 20 220
assign 1 22 221
new 0 22 221
assign 1 23 222
new 0 23 222
new 1 27 223
assign 1 29 224
new 0 29 224
assign 1 30 225
new 0 30 225
assign 1 31 226
new 0 31 226
assign 1 32 227
new 0 32 227
assign 1 33 228
new 0 33 228
assign 1 37 265
def 1 37 270
assign 1 38 271
libNameGet 0 38 271
assign 1 38 272
relEmitName 1 38 272
assign 1 38 273
extend 1 38 273
assign 1 40 276
new 0 40 276
assign 1 40 277
extend 1 40 277
assign 1 42 279
new 0 42 279
assign 1 42 280
emitNameGet 0 42 280
assign 1 42 281
addValue 1 42 281
assign 1 42 282
addValue 1 42 282
assign 1 42 283
new 0 42 283
assign 1 42 284
addValue 1 42 284
assign 1 44 285
def 1 44 290
assign 1 45 291
new 0 45 291
addValue 1 45 292
assign 1 47 293
new 0 47 293
addValue 1 47 294
assign 1 49 295
new 0 49 295
assign 1 49 296
addValue 1 49 296
assign 1 49 297
libNameGet 0 49 297
assign 1 49 298
relEmitName 1 49 298
assign 1 49 299
addValue 1 49 299
assign 1 49 300
new 0 49 300
addValue 1 49 301
assign 1 52 303
new 0 52 303
addValue 1 52 304
assign 1 54 305
new 0 54 305
addValue 1 54 306
write 1 56 307
write 1 58 308
write 1 60 309
clear 0 62 310
assign 1 64 311
new 0 64 311
write 1 64 312
assign 1 65 313
new 0 65 313
write 1 65 314
assign 1 66 315
new 0 66 315
write 1 66 316
assign 1 67 317
new 0 67 317
write 1 67 318
assign 1 68 319
new 0 68 319
write 1 68 320
assign 1 70 321
new 0 70 321
assign 1 70 322
emitNameGet 0 70 322
assign 1 70 323
add 1 70 323
assign 1 70 324
new 0 70 324
assign 1 70 325
add 1 70 325
write 1 70 326
assign 1 72 327
new 0 72 327
return 1 72 328
assign 1 76 360
overrideMtdDecGet 0 76 360
assign 1 76 361
addValue 1 76 361
assign 1 76 362
new 0 76 362
assign 1 76 363
addValue 1 76 363
assign 1 76 364
getClassConfig 1 76 364
assign 1 76 365
libNameGet 0 76 365
assign 1 76 366
relEmitName 1 76 366
assign 1 76 367
addValue 1 76 367
assign 1 76 368
new 0 76 368
assign 1 76 369
addValue 1 76 369
assign 1 76 370
emitNameGet 0 76 370
assign 1 76 371
addValue 1 76 371
assign 1 76 372
new 0 76 372
assign 1 76 373
addValue 1 76 373
assign 1 76 374
addValue 1 76 374
assign 1 76 375
new 0 76 375
assign 1 76 376
addValue 1 76 376
addValue 1 76 377
assign 1 77 378
new 0 77 378
assign 1 77 379
addValue 1 77 379
assign 1 77 380
heldGet 0 77 380
assign 1 77 381
namepathGet 0 77 381
assign 1 77 382
getClassConfig 1 77 382
assign 1 77 383
libNameGet 0 77 383
assign 1 77 384
relEmitName 1 77 384
assign 1 77 385
addValue 1 77 385
assign 1 77 386
new 0 77 386
assign 1 77 387
addValue 1 77 387
addValue 1 77 388
assign 1 79 389
new 0 79 389
assign 1 79 390
addValue 1 79 390
addValue 1 79 391
assign 1 83 397
new 0 83 397
assign 1 85 398
new 0 85 398
write 1 85 399
return 1 86 400
assign 1 90 420
new 0 90 420
assign 1 90 421
toString 0 90 421
assign 1 90 422
add 1 90 422
incrementValue 0 91 423
assign 1 92 424
new 0 92 424
assign 1 92 425
addValue 1 92 425
assign 1 92 426
addValue 1 92 426
assign 1 92 427
new 0 92 427
assign 1 92 428
addValue 1 92 428
addValue 1 92 429
assign 1 94 430
containedGet 0 94 430
assign 1 94 431
firstGet 0 94 431
assign 1 94 432
containedGet 0 94 432
assign 1 94 433
firstGet 0 94 433
assign 1 94 434
new 0 94 434
assign 1 94 435
add 1 94 435
assign 1 94 436
new 0 94 436
assign 1 94 437
add 1 94 437
assign 1 94 438
finalAssign 4 94 438
addValue 1 94 439
assign 1 99 444
new 0 99 444
return 1 99 445
assign 1 103 449
new 0 103 449
return 1 103 450
assign 1 107 454
new 0 107 454
return 1 107 455
assign 1 112 487
addValue 1 112 487
assign 1 112 488
new 0 112 488
assign 1 112 489
addValue 1 112 489
assign 1 112 490
libNameGet 0 112 490
assign 1 112 491
relEmitName 1 112 491
assign 1 112 492
addValue 1 112 492
assign 1 112 493
new 0 112 493
assign 1 112 494
addValue 1 112 494
assign 1 112 495
emitNameGet 0 112 495
assign 1 112 496
addValue 1 112 496
assign 1 112 497
new 0 112 497
assign 1 112 498
addValue 1 112 498
assign 1 112 499
addValue 1 112 499
assign 1 112 500
new 0 112 500
addValue 1 112 501
addValue 1 114 502
assign 1 116 503
new 0 116 503
assign 1 116 504
addValue 1 116 504
assign 1 116 505
addValue 1 116 505
assign 1 116 506
new 0 116 506
assign 1 116 507
addValue 1 116 507
addValue 1 116 508
assign 1 118 509
new 0 118 509
assign 1 118 510
addValue 1 118 510
assign 1 118 511
libNameGet 0 118 511
assign 1 118 512
relEmitName 1 118 512
assign 1 118 513
addValue 1 118 513
assign 1 118 514
new 0 118 514
assign 1 118 515
addValue 1 118 515
assign 1 118 516
addValue 1 118 516
assign 1 118 517
new 0 118 517
addValue 1 118 518
addValue 1 120 519
assign 1 122 520
new 0 122 520
addValue 1 122 521
assign 1 128 542
typenameGet 0 128 542
assign 1 128 543
NULLGet 0 128 543
assign 1 128 544
equals 1 128 549
assign 1 129 550
new 0 129 550
assign 1 130 553
heldGet 0 130 553
assign 1 130 554
nameGet 0 130 554
assign 1 130 555
new 0 130 555
assign 1 130 556
equals 1 130 556
assign 1 131 558
new 0 131 558
assign 1 131 559
emitNameGet 0 131 559
assign 1 131 560
add 1 131 560
assign 1 131 561
new 0 131 561
assign 1 131 562
add 1 131 562
assign 1 132 565
heldGet 0 132 565
assign 1 132 566
nameGet 0 132 566
assign 1 132 567
new 0 132 567
assign 1 132 568
equals 1 132 568
assign 1 133 570
new 0 133 570
assign 1 135 573
heldGet 0 135 573
assign 1 135 574
nameForVar 1 135 574
return 1 137 578
assign 1 141 588
heldGet 0 141 588
assign 1 141 589
nameGet 0 141 589
assign 1 141 590
new 0 141 590
assign 1 141 591
equals 1 141 591
assign 1 142 593
new 0 142 593
assign 1 142 594
add 1 142 594
return 1 143 595
assign 1 145 597
formCallTarg 1 145 597
return 1 145 598
assign 1 149 617
isTypedGet 0 149 617
assign 1 149 618
not 0 149 623
assign 1 150 624
new 0 150 624
assign 1 150 625
addValue 1 150 625
assign 1 150 626
libNameGet 0 150 626
assign 1 150 627
relEmitName 1 150 627
assign 1 150 628
addValue 1 150 628
assign 1 150 629
new 0 150 629
addValue 1 150 630
assign 1 152 633
new 0 152 633
assign 1 152 634
addValue 1 152 634
assign 1 152 635
namepathGet 0 152 635
assign 1 152 636
getClassConfig 1 152 636
assign 1 152 637
libNameGet 0 152 637
assign 1 152 638
relEmitName 1 152 638
assign 1 152 639
addValue 1 152 639
assign 1 152 640
new 0 152 640
addValue 1 152 641
assign 1 157 656
new 0 157 656
assign 1 157 657
equals 1 157 657
assign 1 158 659
new 0 158 659
assign 1 160 662
new 0 160 662
assign 1 162 664
new 0 162 664
assign 1 162 665
add 1 162 665
assign 1 162 666
libNameGet 0 162 666
assign 1 162 667
relEmitName 1 162 667
assign 1 162 668
add 1 162 668
assign 1 162 669
new 0 162 669
assign 1 162 670
add 1 162 670
return 1 162 671
assign 1 167 675
new 0 167 675
return 1 167 676
assign 1 171 703
overrideMtdDecGet 0 171 703
assign 1 171 704
addValue 1 171 704
assign 1 171 705
new 0 171 705
assign 1 171 706
addValue 1 171 706
assign 1 171 707
emitNameGet 0 171 707
assign 1 171 708
addValue 1 171 708
assign 1 171 709
new 0 171 709
assign 1 171 710
addValue 1 171 710
assign 1 171 711
addValue 1 171 711
assign 1 171 712
new 0 171 712
assign 1 171 713
addValue 1 171 713
assign 1 171 714
addValue 1 171 714
assign 1 171 715
new 0 171 715
assign 1 171 716
addValue 1 171 716
addValue 1 171 717
assign 1 172 718
new 0 172 718
assign 1 172 719
addValue 1 172 719
assign 1 172 720
addValue 1 172 720
assign 1 172 721
new 0 172 721
assign 1 172 722
addValue 1 172 722
assign 1 172 723
addValue 1 172 723
assign 1 172 724
new 0 172 724
assign 1 172 725
addValue 1 172 725
addValue 1 172 726
assign 1 174 727
new 0 174 727
assign 1 174 728
addValue 1 174 728
addValue 1 174 729
assign 1 178 744
new 0 178 744
assign 1 178 745
libNameGet 0 178 745
assign 1 178 746
relEmitName 1 178 746
assign 1 178 747
add 1 178 747
assign 1 178 748
new 0 178 748
assign 1 178 749
add 1 178 749
assign 1 178 750
heldGet 0 178 750
assign 1 178 751
literalValueGet 0 178 751
assign 1 178 752
add 1 178 752
assign 1 178 753
new 0 178 753
assign 1 178 754
add 1 178 754
return 1 178 755
assign 1 182 769
new 0 182 769
assign 1 182 770
libNameGet 0 182 770
assign 1 182 771
relEmitName 1 182 771
assign 1 182 772
add 1 182 772
assign 1 182 773
new 0 182 773
assign 1 182 774
add 1 182 774
assign 1 182 775
heldGet 0 182 775
assign 1 182 776
literalValueGet 0 182 776
assign 1 182 777
add 1 182 777
assign 1 182 778
new 0 182 778
assign 1 182 779
add 1 182 779
return 1 182 780
assign 1 187 808
new 0 187 808
assign 1 187 809
libNameGet 0 187 809
assign 1 187 810
relEmitName 1 187 810
assign 1 187 811
add 1 187 811
assign 1 187 812
new 0 187 812
assign 1 187 813
add 1 187 813
assign 1 187 814
add 1 187 814
assign 1 187 815
new 0 187 815
assign 1 187 816
add 1 187 816
assign 1 187 817
add 1 187 817
assign 1 187 818
new 0 187 818
assign 1 187 819
add 1 187 819
return 1 187 820
assign 1 189 822
new 0 189 822
assign 1 189 823
libNameGet 0 189 823
assign 1 189 824
relEmitName 1 189 824
assign 1 189 825
add 1 189 825
assign 1 189 826
new 0 189 826
assign 1 189 827
add 1 189 827
assign 1 189 828
add 1 189 828
assign 1 189 829
new 0 189 829
assign 1 189 830
add 1 189 830
assign 1 189 831
add 1 189 831
assign 1 189 832
new 0 189 832
assign 1 189 833
add 1 189 833
return 1 189 834
assign 1 193 841
new 0 193 841
assign 1 193 842
add 1 193 842
assign 1 193 843
new 0 193 843
assign 1 193 844
add 1 193 844
return 1 193 845
getInt 2 198 855
assign 1 199 856
toHexString 1 199 856
assign 1 200 857
new 0 200 857
assign 1 200 858
begins 1 200 858
assign 1 201 860
new 0 201 860
assign 1 201 861
substring 1 201 861
assign 1 202 862
new 0 202 862
addValue 1 202 863
assign 1 204 865
new 0 204 865
assign 1 204 866
once 0 204 866
addValue 1 204 867
addValue 1 205 868
assign 1 211 875
new 0 211 875
assign 1 211 876
add 1 211 876
assign 1 211 877
add 1 211 877
return 1 211 878
assign 1 215 882
new 0 215 882
return 1 215 883
assign 1 219 906
new 0 219 906
assign 1 219 907
add 1 219 907
assign 1 219 908
new 0 219 908
assign 1 219 909
add 1 219 909
assign 1 219 910
add 1 219 910
assign 1 220 911
new 0 220 911
assign 1 220 912
addValue 1 220 912
assign 1 220 913
addValue 1 220 913
assign 1 220 914
new 0 220 914
assign 1 220 915
addValue 1 220 915
addValue 1 220 916
assign 1 221 917
new 0 221 917
assign 1 221 918
addValue 1 221 918
addValue 1 221 919
assign 1 222 920
new 0 222 920
assign 1 222 921
addValue 1 222 921
assign 1 222 922
outputPlatformGet 0 222 922
assign 1 222 923
nameGet 0 222 923
assign 1 222 924
addValue 1 222 924
assign 1 222 925
new 0 222 925
assign 1 222 926
addValue 1 222 926
addValue 1 222 927
assign 1 224 928
new 0 224 928
return 1 224 929
assign 1 228 933
new 0 228 933
return 1 228 934
assign 1 232 940
new 0 232 940
assign 1 232 941
once 0 232 941
assign 1 232 942
add 1 232 942
return 1 232 943
assign 1 236 947
getLibOutput 0 236 947
return 1 236 948
assign 1 251 1013
undef 1 251 1018
assign 1 252 1019
libNameGet 0 252 1019
assign 1 253 1020
new 0 253 1020
assign 1 253 1021
sizeGet 0 253 1021
assign 1 253 1022
add 1 253 1022
assign 1 253 1023
new 0 253 1023
assign 1 253 1024
add 1 253 1024
assign 1 253 1025
add 1 253 1025
assign 1 253 1026
add 1 253 1026
assign 1 254 1027
new 0 254 1027
assign 1 254 1028
sizeGet 0 254 1028
assign 1 254 1029
add 1 254 1029
assign 1 254 1030
new 0 254 1030
assign 1 254 1031
add 1 254 1031
assign 1 254 1032
add 1 254 1032
assign 1 254 1033
add 1 254 1033
assign 1 255 1034
parentGet 0 255 1034
assign 1 255 1035
addStep 1 255 1035
assign 1 256 1036
parentGet 0 256 1036
assign 1 256 1037
addStep 1 256 1037
assign 1 257 1038
parentGet 0 257 1038
assign 1 257 1039
fileGet 0 257 1039
assign 1 257 1040
existsGet 0 257 1040
assign 1 257 1041
not 0 257 1046
assign 1 258 1047
parentGet 0 258 1047
assign 1 258 1048
fileGet 0 258 1048
makeDirs 0 258 1049
assign 1 260 1051
fileGet 0 260 1051
assign 1 260 1052
writerGet 0 260 1052
assign 1 260 1053
open 0 260 1053
assign 1 261 1054
fileGet 0 261 1054
assign 1 261 1055
writerGet 0 261 1055
assign 1 261 1056
open 0 261 1056
assign 1 263 1057
new 0 263 1057
write 1 263 1058
assign 1 264 1059
new 0 264 1059
write 1 264 1060
assign 1 265 1061
new 0 265 1061
write 1 265 1062
assign 1 266 1063
new 0 266 1063
write 1 266 1064
assign 1 268 1065
new 0 268 1065
write 1 268 1066
assign 1 269 1067
new 0 269 1067
write 1 269 1068
assign 1 275 1069
paramsGet 0 275 1069
assign 1 275 1070
new 0 275 1070
assign 1 275 1071
has 1 275 1071
assign 1 277 1073
paramsGet 0 277 1073
assign 1 277 1074
new 0 277 1074
assign 1 277 1075
get 1 277 1075
assign 1 277 1076
iteratorGet 0 0 1076
assign 1 277 1079
hasNextGet 0 277 1079
assign 1 277 1081
nextGet 0 277 1081
assign 1 279 1082
apNew 1 279 1082
assign 1 279 1083
fileGet 0 279 1083
assign 1 280 1084
readerGet 0 280 1084
assign 1 280 1085
open 0 280 1085
assign 1 280 1086
readString 0 280 1086
assign 1 281 1087
readerGet 0 281 1087
close 0 281 1088
write 1 283 1089
assign 1 286 1096
paramsGet 0 286 1096
assign 1 286 1097
new 0 286 1097
assign 1 286 1098
has 1 286 1098
assign 1 288 1100
paramsGet 0 288 1100
assign 1 288 1101
new 0 288 1101
assign 1 288 1102
get 1 288 1102
assign 1 288 1103
iteratorGet 0 0 1103
assign 1 288 1106
hasNextGet 0 288 1106
assign 1 288 1108
nextGet 0 288 1108
assign 1 290 1109
apNew 1 290 1109
assign 1 290 1110
fileGet 0 290 1110
assign 1 291 1111
readerGet 0 291 1111
assign 1 291 1112
open 0 291 1112
assign 1 291 1113
readString 0 291 1113
assign 1 292 1114
readerGet 0 292 1114
close 0 292 1115
write 1 294 1116
begin 1 301 1127
prepHeaderOutput 0 302 1128
assign 1 307 1158
undef 1 307 1163
assign 1 308 1164
new 0 308 1164
assign 1 309 1165
parentGet 0 309 1165
assign 1 309 1166
fileGet 0 309 1166
assign 1 309 1167
existsGet 0 309 1167
assign 1 309 1168
not 0 309 1173
assign 1 310 1174
parentGet 0 310 1174
assign 1 310 1175
fileGet 0 310 1175
makeDirs 0 310 1176
assign 1 312 1178
fileGet 0 312 1178
assign 1 312 1179
writerGet 0 312 1179
assign 1 312 1180
open 0 312 1180
assign 1 314 1181
new 0 314 1181
write 1 314 1182
increment 0 315 1183
assign 1 316 1184
paramsGet 0 316 1184
assign 1 316 1185
new 0 316 1185
assign 1 316 1186
has 1 316 1186
assign 1 317 1188
paramsGet 0 317 1188
assign 1 317 1189
new 0 317 1189
assign 1 317 1190
get 1 317 1190
assign 1 317 1191
iteratorGet 0 0 1191
assign 1 317 1194
hasNextGet 0 317 1194
assign 1 317 1196
nextGet 0 317 1196
assign 1 318 1197
apNew 1 318 1197
assign 1 318 1198
fileGet 0 318 1198
assign 1 319 1199
readerGet 0 319 1199
assign 1 319 1200
open 0 319 1200
assign 1 319 1201
readString 0 319 1201
assign 1 320 1202
readerGet 0 320 1202
close 0 320 1203
assign 1 321 1204
countLines 1 321 1204
addValue 1 321 1205
write 1 322 1206
return 1 328 1214
assign 1 333 1220
new 0 333 1220
write 1 333 1221
close 0 334 1222
assign 1 335 1223
assign 1 337 1224
new 0 337 1224
write 1 337 1225
assign 1 339 1226
new 0 339 1226
write 1 339 1227
close 0 340 1228
close 0 341 1229
assign 1 346 1234
new 0 346 1234
return 1 346 1235
assign 1 350 1242
new 0 350 1242
assign 1 350 1243
addValue 1 350 1243
assign 1 350 1244
addValue 1 350 1244
assign 1 350 1245
new 0 350 1245
addValue 1 350 1246
assign 1 355 1268
heldGet 0 355 1268
assign 1 355 1269
synGet 0 355 1269
assign 1 356 1270
ptyListGet 0 356 1270
assign 1 358 1271
emitNameGet 0 358 1271
assign 1 358 1272
addValue 1 358 1272
assign 1 358 1273
new 0 358 1273
addValue 1 358 1274
assign 1 360 1275
new 0 360 1275
assign 1 361 1276
iteratorGet 0 0 1276
assign 1 361 1279
hasNextGet 0 361 1279
assign 1 361 1281
nextGet 0 361 1281
assign 1 363 1283
new 0 363 1283
assign 1 365 1286
new 0 365 1286
addValue 1 365 1287
assign 1 367 1289
addValue 1 367 1289
assign 1 367 1290
new 0 367 1290
assign 1 367 1291
addValue 1 367 1291
assign 1 367 1292
nameGet 0 367 1292
assign 1 367 1293
addValue 1 367 1293
addValue 1 367 1294
assign 1 371 1300
new 0 371 1300
assign 1 371 1301
addValue 1 371 1301
addValue 1 371 1302
assign 1 376 1320
new 0 376 1320
assign 1 378 1321
new 0 378 1321
assign 1 378 1322
emitNameGet 0 378 1322
assign 1 378 1323
add 1 378 1323
assign 1 378 1324
new 0 378 1324
assign 1 378 1325
add 1 378 1325
assign 1 380 1326
new 0 380 1326
assign 1 380 1327
addValue 1 380 1327
assign 1 380 1328
emitNameGet 0 380 1328
assign 1 380 1329
addValue 1 380 1329
assign 1 380 1330
new 0 380 1330
assign 1 380 1331
addValue 1 380 1331
assign 1 380 1332
addValue 1 380 1332
assign 1 380 1333
new 0 380 1333
addValue 1 380 1334
return 1 382 1335
assign 1 386 1344
libNameGet 0 386 1344
assign 1 386 1345
relEmitName 1 386 1345
assign 1 387 1346
new 0 387 1346
assign 1 387 1347
add 1 387 1347
assign 1 387 1348
new 0 387 1348
assign 1 387 1349
add 1 387 1349
return 1 388 1350
assign 1 392 1407
getClassConfig 1 392 1407
assign 1 392 1408
libNameGet 0 392 1408
assign 1 392 1409
relEmitName 1 392 1409
assign 1 393 1410
heldGet 0 393 1410
assign 1 393 1411
namepathGet 0 393 1411
assign 1 393 1412
getClassConfig 1 393 1412
assign 1 394 1413
getInitialInst 1 394 1413
assign 1 396 1414
overrideMtdDecGet 0 396 1414
assign 1 396 1415
addValue 1 396 1415
assign 1 396 1416
new 0 396 1416
assign 1 396 1417
addValue 1 396 1417
assign 1 396 1418
emitNameGet 0 396 1418
assign 1 396 1419
addValue 1 396 1419
assign 1 396 1420
new 0 396 1420
assign 1 396 1421
addValue 1 396 1421
assign 1 396 1422
addValue 1 396 1422
assign 1 396 1423
new 0 396 1423
assign 1 396 1424
addValue 1 396 1424
assign 1 396 1425
addValue 1 396 1425
assign 1 396 1426
new 0 396 1426
assign 1 396 1427
addValue 1 396 1427
addValue 1 396 1428
assign 1 397 1429
new 0 397 1429
assign 1 398 1430
emitNameGet 0 398 1430
assign 1 398 1431
notEquals 1 398 1431
assign 1 399 1433
new 0 399 1433
assign 1 399 1434
formCast 3 399 1434
assign 1 402 1436
addValue 1 402 1436
assign 1 402 1437
new 0 402 1437
assign 1 402 1438
addValue 1 402 1438
assign 1 402 1439
addValue 1 402 1439
assign 1 402 1440
new 0 402 1440
assign 1 402 1441
addValue 1 402 1441
addValue 1 402 1442
assign 1 404 1443
new 0 404 1443
assign 1 404 1444
addValue 1 404 1444
addValue 1 404 1445
assign 1 407 1446
overrideMtdDecGet 0 407 1446
assign 1 407 1447
addValue 1 407 1447
assign 1 407 1448
new 0 407 1448
assign 1 407 1449
addValue 1 407 1449
assign 1 407 1450
addValue 1 407 1450
assign 1 407 1451
new 0 407 1451
assign 1 407 1452
addValue 1 407 1452
assign 1 407 1453
emitNameGet 0 407 1453
assign 1 407 1454
addValue 1 407 1454
assign 1 407 1455
new 0 407 1455
assign 1 407 1456
addValue 1 407 1456
assign 1 407 1457
addValue 1 407 1457
assign 1 407 1458
new 0 407 1458
assign 1 407 1459
addValue 1 407 1459
addValue 1 407 1460
assign 1 409 1461
new 0 409 1461
assign 1 409 1462
addValue 1 409 1462
assign 1 409 1463
addValue 1 409 1463
assign 1 409 1464
new 0 409 1464
assign 1 409 1465
addValue 1 409 1465
addValue 1 409 1466
assign 1 411 1467
new 0 411 1467
assign 1 411 1468
addValue 1 411 1468
addValue 1 411 1469
return 1 0 1473
assign 1 0 1476
return 1 0 1480
assign 1 0 1483
return 1 0 1487
assign 1 0 1490
return 1 0 1494
assign 1 0 1497
return 1 0 1501
assign 1 0 1504
return 1 0 1508
assign 1 0 1511
return 1 0 1515
assign 1 0 1518
return 1 0 1522
assign 1 0 1525
return 1 0 1529
assign 1 0 1532
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2096182068: return bem_instOfGet_0();
case -88104050: return bem_baseMtdDecGet_0();
case 349970145: return bem_deonGet_0();
case 461011218: return bem_cnodeGet_0();
case -1304607114: return bem_fileExtGet_0();
case -2143104349: return bem_boolNpGet_0();
case -1704001450: return bem_serializationIteratorGet_0();
case -502106771: return bem_classConfGet_0();
case 1107063436: return bem_create_0();
case 1093974100: return bem_lastMethodsSizeGet_0();
case 1586265763: return bem_copy_0();
case 359002034: return bem_deowGet_0();
case 1550782506: return bem_print_0();
case 1037382864: return bem_spropDecGet_0();
case -1674644863: return bem_serializeToString_0();
case 1351327405: return bem_transGet_0();
case -1580292217: return bem_stringNpGet_0();
case -1732815767: return bem_saveSyns_0();
case 71034992: return bem_buildGet_0();
case 593441621: return bem_maxSpillArgsLenGet_0();
case -1687448300: return bem_idToNameGet_0();
case 1094209580: return bem_endNs_0();
case 848601447: return bem_buildClassInfo_0();
case 732962876: return bem_intNpGet_0();
case -461165952: return bem_randGet_0();
case -1718747445: return bem_mnodeGet_0();
case 1797100127: return bem_ccMethodsGet_0();
case -193069103: return bem_lineCountGet_0();
case -867655846: return bem_qGet_0();
case -1783890369: return bem_methodCallsGet_0();
case 1724993772: return bem_many_0();
case -1754438966: return bem_libEmitPathGet_0();
case -667056235: return bem_getClassOutput_0();
case 1328927380: return bem_lastMethodsLinesGet_0();
case -269714784: return bem_nullValueGet_0();
case 1450914070: return bem_fullLibEmitNameGet_0();
case -981128241: return bem_coanyiantReturnsGet_0();
case 775562796: return bem_buildPropList_0();
case -708604045: return bem_mainOutsideNsGet_0();
case 353744263: return bem_once_0();
case -1126086156: return bem_classHeadBodyGet_0();
case -1625526216: return bem_heonGet_0();
case -1184163045: return bem_mainEndGet_0();
case 489393732: return bem_deopGet_0();
case 191411912: return bem_propertyDecsGet_0();
case 282132881: return bem_emitLib_0();
case -659144166: return bem_mainStartGet_0();
case -1461114629: return bem_onceDecsGet_0();
case 2089277173: return bem_classNameGet_0();
case -1615155660: return bem_sourceFileNameGet_0();
case 619699014: return bem_objectCcGet_0();
case -2098768246: return bem_buildInitial_0();
case -1106599077: return bem_headExtGet_0();
case -1762073960: return bem_nameToIdGet_0();
case -1197288989: return bem_propDecGet_0();
case -1245325464: return bem_callNamesGet_0();
case -661284875: return bem_runtimeInitGet_0();
case 1166861683: return bem_objectNpGet_0();
case 755005070: return bem_echo_0();
case 648317532: return bem_scvpGet_0();
case -1770937237: return bem_classCallsGet_0();
case -763388145: return bem_boolTypeGet_0();
case -1596425386: return bem_classEmitsGet_0();
case 836604081: return bem_tagGet_0();
case -1877620143: return bem_smnlcsGet_0();
case 1328912068: return bem_boolCcGet_0();
case -619400735: return bem_initialDecGet_0();
case -691992739: return bem_falseValueGet_0();
case -1393945423: return bem_invpGet_0();
case 569250064: return bem_nlGet_0();
case -868754815: return bem_serializeContents_0();
case 453069921: return bem_methodCatchGet_0();
case -161494459: return bem_lastMethodBodySizeGet_0();
case -302150888: return bem_inFilePathedGet_0();
case 1855656725: return bem_heowGet_0();
case -663402285: return bem_instanceEqualGet_0();
case 1090672269: return bem_afterCast_0();
case 911591641: return bem_methodBodyGet_0();
case 1956510568: return bem_msynGet_0();
case -2079261808: return bem_toString_0();
case 356510618: return bem_returnTypeGet_0();
case -312883636: return bem_classesInDepthOrderGet_0();
case 1673137910: return bem_synEmitPathGet_0();
case 2075313116: return bem_prepHeaderOutput_0();
case 1983847785: return bem_baseSmtdDecGet_0();
case -2060020988: return bem_preClassGet_0();
case -2136823553: return bem_dynMethodsGet_0();
case -1204411124: return bem_smnlecsGet_0();
case 767288021: return bem_maxDynArgsGet_0();
case 1192141557: return bem_libEmitNameGet_0();
case -1182753845: return bem_ntypesGet_0();
case -1207227016: return bem_toAny_0();
case 936910277: return bem_ccCacheGet_0();
case -64960881: return bem_emitLangGet_0();
case -435256550: return bem_trueValueGet_0();
case 959373353: return bem_superCallsGet_0();
case -358182818: return bem_beginNs_0();
case 331067077: return bem_iteratorGet_0();
case -1122589214: return bem_nativeCSlotsGet_0();
case -1144635038: return bem_fieldIteratorGet_0();
case -14740290: return bem_onceCountGet_0();
case 1859788184: return bem_lastCallGet_0();
case -1914642068: return bem_getLibOutput_0();
case -142902587: return bem_useDynMethodsGet_0();
case 366015806: return bem_methodsGet_0();
case -2035802034: return bem_hashGet_0();
case -674879542: return bem_heopGet_0();
case -1033815473: return bem_doEmit_0();
case -1432966592: return bem_deserializeClassNameGet_0();
case 989795321: return bem_parentConfGet_0();
case 1742760381: return bem_instanceNotEqualGet_0();
case 1857825564: return bem_mainInClassGet_0();
case -1702389050: return bem_floatNpGet_0();
case -2112201387: return bem_buildCreate_0();
case -1837949925: return bem_shlibeGet_0();
case 1618197244: return bem_new_0();
case 2018655279: return bem_csynGet_0();
case -2144993929: return bem_superNameGet_0();
case 46046540: return bem_constGet_0();
case -1605699222: return bem_exceptDecGet_0();
case 2077052286: return bem_lastMethodBodyLinesGet_0();
case -1009279470: return bem_classEndGet_0();
case 305597191: return bem_overrideMtdDecGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -170182319: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 128814655: return bem_lastMethodsLinesSet_1(bevd_0);
case 2137028741: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 403760440: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 972511036: return bem_classConfSet_1(bevd_0);
case -433893: return bem_mnodeSet_1(bevd_0);
case 1008507753: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 2146931069: return bem_heowSet_1(bevd_0);
case -477859385: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2036090677: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 483060887: return bem_lastMethodsSizeSet_1(bevd_0);
case -731486139: return bem_synEmitPathSet_1(bevd_0);
case -1744736586: return bem_constSet_1(bevd_0);
case -112659913: return bem_cnodeSet_1(bevd_0);
case -748799548: return bem_headExtSet_1(bevd_0);
case -780603964: return bem_idToNameSet_1(bevd_0);
case -955519709: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -871499967: return bem_smnlcsSet_1(bevd_0);
case -864903677: return bem_otherType_1(bevd_0);
case -1617873552: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1040435204: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 902442951: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -2021481596: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -2018158572: return bem_sameType_1(bevd_0);
case 1270853577: return bem_buildSet_1(bevd_0);
case -1083382781: return bem_nativeCSlotsSet_1(bevd_0);
case -872423717: return bem_lineCountSet_1(bevd_0);
case 167556231: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 2049129562: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 982618822: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -999307084: return bem_classHeadBodySet_1(bevd_0);
case -1690226246: return bem_notEquals_1(bevd_0);
case 1975786452: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -392135578: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1696730819: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 444543765: return bem_qSet_1(bevd_0);
case 1928553350: return bem_classCallsSet_1(bevd_0);
case -1398318576: return bem_nameToIdSet_1(bevd_0);
case 950206493: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1181026029: return bem_copyTo_1(bevd_0);
case -1060482438: return bem_classEmitsSet_1(bevd_0);
case -1208389413: return bem_maxDynArgsSet_1(bevd_0);
case -1688663612: return bem_objectNpSet_1(bevd_0);
case 1395297337: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 174955110: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -194638325: return bem_falseValueSet_1(bevd_0);
case 232637882: return bem_dynMethodsSet_1(bevd_0);
case 954206088: return bem_superCallsSet_1(bevd_0);
case 1181072814: return bem_deowSet_1(bevd_0);
case 1799070255: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 587078382: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -251500064: return bem_inFilePathedSet_1(bevd_0);
case 2082220238: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -556437133: return bem_stringNpSet_1(bevd_0);
case 471238685: return bem_methodsSet_1(bevd_0);
case 894987079: return bem_undef_1(bevd_0);
case -1252080395: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1269866494: return bem_ccMethodsSet_1(bevd_0);
case 2100213172: return bem_methodCallsSet_1(bevd_0);
case 1820941401: return bem_def_1(bevd_0);
case -237606196: return bem_fullLibEmitNameSet_1(bevd_0);
case 1103021233: return bem_scvpSet_1(bevd_0);
case 1652222354: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 535848997: return bem_transSet_1(bevd_0);
case 567619203: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1751145258: return bem_boolCcSet_1(bevd_0);
case 517890338: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1445069973: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 729465196: return bem_equals_1(bevd_0);
case -1743252117: return bem_sameObject_1(bevd_0);
case 2104366689: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1157323512: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1618803979: return bem_libEmitPathSet_1(bevd_0);
case -1739639922: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -467831865: return bem_otherClass_1(bevd_0);
case -392213771: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1170293800: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 192934317: return bem_ntypesSet_1(bevd_0);
case 318385507: return bem_callNamesSet_1(bevd_0);
case -1120319243: return bem_deopSet_1(bevd_0);
case 140644373: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1445340691: return bem_smnlecsSet_1(bevd_0);
case 674866186: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1326213702: return bem_instOfSet_1(bevd_0);
case 480155326: return bem_emitLangSet_1(bevd_0);
case -2049354035: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -623401932: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1201981680: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 984883467: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -2044350068: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1243010364: return bem_nlSet_1(bevd_0);
case -542448676: return bem_libEmitNameSet_1(bevd_0);
case -579243103: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -41135354: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1292274364: return bem_undefined_1(bevd_0);
case 1620724588: return bem_heonSet_1(bevd_0);
case -1670650980: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -899950996: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -102763151: return bem_defined_1(bevd_0);
case 681098758: return bem_floatNpSet_1(bevd_0);
case 2029862240: return bem_classesInDepthOrderSet_1(bevd_0);
case -1689996795: return bem_shlibeSet_1(bevd_0);
case -490440270: return bem_lastCallSet_1(bevd_0);
case -328095172: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1038423853: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1369274986: return bem_begin_1(bevd_0);
case 586828538: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1937596397: return bem_instanceNotEqualSet_1(bevd_0);
case -1285524271: return bem_sameClass_1(bevd_0);
case -1469813543: return bem_onceCountSet_1(bevd_0);
case -1202294464: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -232661786: return bem_end_1(bevd_0);
case 524042363: return bem_ccCacheSet_1(bevd_0);
case 1178680259: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1910111852: return bem_intNpSet_1(bevd_0);
case 1188997763: return bem_fileExtSet_1(bevd_0);
case -1543621734: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1696167234: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -694199888: return bem_heopSet_1(bevd_0);
case -535009874: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -685451487: return bem_parentConfSet_1(bevd_0);
case -728691395: return bem_randSet_1(bevd_0);
case 1053963189: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1288435421: return bem_invpSet_1(bevd_0);
case -2090647481: return bem_methodCatchSet_1(bevd_0);
case 1601121046: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -263091767: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1724062474: return bem_propertyDecsSet_1(bevd_0);
case 1957645265: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 265640445: return bem_exceptDecSet_1(bevd_0);
case -307544589: return bem_msynSet_1(bevd_0);
case 469106010: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1999249335: return bem_boolNpSet_1(bevd_0);
case 1382998181: return bem_csynSet_1(bevd_0);
case -102231785: return bem_instanceEqualSet_1(bevd_0);
case 868534267: return bem_nullValueSet_1(bevd_0);
case 1373109998: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 239121586: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1949582727: return bem_deonSet_1(bevd_0);
case 1315371316: return bem_onceDecsSet_1(bevd_0);
case -1264532152: return bem_returnTypeSet_1(bevd_0);
case 533075724: return bem_preClassSet_1(bevd_0);
case 797069630: return bem_methodBodySet_1(bevd_0);
case 1857254645: return bem_objectCcSet_1(bevd_0);
case -1187275128: return bem_trueValueSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 823519660: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -284032048: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -126619906: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1713973958: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2041527697: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1814064163: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 55988273: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1766023995: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 41847434: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1022011264: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1640237169: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1562178329: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1241720452: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1527927145: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 489129127: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1067491989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1330371622: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 809429251: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1632202498: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1600827154: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 555607815: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 799090607: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 743018259: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1983107208: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1411265895: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 960459451: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
}
