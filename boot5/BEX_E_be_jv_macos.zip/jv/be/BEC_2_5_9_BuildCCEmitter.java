package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x74,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x61,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x62,0x65,0x76,0x74,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x62,0x65,0x76,0x6B,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x63,0x63,0x4E,0x6F,0x52,0x74,0x74,0x69};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x2A,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x63,0x63,0x53,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x66,0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x42,0x45,0x44,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x42,0x45,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 41*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 42*/
 else /* Line: 43*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 44*/
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_extends);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
if (bevp_parentConf == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_ta_ph = bevl_begin.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_libNameGet_0();
bevt_15_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_16_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
} /* Line: 53*/
 else /* Line: 54*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_20_ta_ph);
} /* Line: 59*/
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_22_ta_ph);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_24_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_25_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_23_ta_ph = bevt_24_ta_ph.bem_has_1(bevt_25_ta_ph);
if (!(bevt_23_ta_ph.bevi_bool))/* Line: 74*/ {
bevt_26_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_27_ta_ph);
} /* Line: 76*/
bevt_28_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_28_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_34_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_34_ta_ph);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_36_ta_ph = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_36_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_37_ta_ph);
bevp_heow.bem_write_1(bevt_29_ta_ph);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 85*/ {
bevt_46_ta_ph = (new BEC_2_4_6_TextString(40, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_47_ta_ph);
} /* Line: 87*/
bevt_50_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevt_51_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_add_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevt_52_ta_ph);
bevp_heow.bem_write_1(bevt_48_ta_ph);
bevt_55_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_56_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_add_1(bevt_56_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bem_add_1(bevt_57_ta_ph);
bevp_deow.bem_write_1(bevt_53_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_58_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_7_ta_ph = bem_overrideMtdDecGet_0();
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_22_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(1083174784);
bevt_20_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_ta_ph );
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_relEmitName_1(bevt_23_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_26_ta_ph);
bevt_25_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevp_heow.bem_write_1(bevt_0_ta_ph);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_5_ta_ph = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_ta_ph = bevp_build.bem_libNameGet_0();
bevt_6_ta_ph = beva_returnType.bem_relEmitName_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_0_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_14_ta_ph = bevp_methods.bem_addValue_1(bevt_15_ta_ph);
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(beva_exceptDec);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_20_ta_ph = bevp_classHeadBody.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_22_ta_ph = beva_returnType.bem_relEmitName_1(bevt_23_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_mtdName);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_17_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevp_classHeadBody.bem_addValue_1(bevt_26_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_typenameGet_0();
bevt_2_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_ta_ph.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 142*/ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 143*/
 else /* Line: 142*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-1612371159);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(1063069793, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 144*/ {
bevl_tcall = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
} /* Line: 145*/
 else /* Line: 142*/ {
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1612371159);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(1063069793, bevt_10_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 146*/ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
} /* Line: 147*/
 else /* Line: 148*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_ta_ph );
} /* Line: 149*/
} /* Line: 142*/
} /* Line: 142*/
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_4_6_TextString bevl_prefix = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isTmpVarGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 157*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
} /* Line: 158*/
 else /* Line: 157*/ {
bevt_1_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 159*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
} /* Line: 160*/
 else /* Line: 157*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 161*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
} /* Line: 162*/
 else /* Line: 163*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
} /* Line: 164*/
} /* Line: 157*/
} /* Line: 157*/
bevt_4_ta_ph = beva_v.bem_nameGet_0();
bevt_3_ta_ph = bevl_prefix.bem_add_1(bevt_4_ta_ph);
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_decNameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_4_6_TextString bevl_prefix = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isTmpVarGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 173*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
} /* Line: 174*/
 else /* Line: 173*/ {
bevt_1_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 175*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
} /* Line: 176*/
 else /* Line: 173*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 177*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
} /* Line: 178*/
 else /* Line: 179*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
} /* Line: 180*/
} /* Line: 173*/
} /* Line: 173*/
bevt_4_ta_ph = beva_v.bem_nameGet_0();
bevt_3_ta_ph = bevl_prefix.bem_add_1(bevt_4_ta_ph);
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1612371159);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1063069793, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 187*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevl_tcall = bevt_4_ta_ph.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 189*/
bevt_5_ta_ph = super.bem_formCallTarg_1(beva_node);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1926098085);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(2029771715, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 199*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-1979897676);
bevp_classHeaders.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 200*/
 else /* Line: 201*/ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 202*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_8_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevl_clh = bevt_4_ta_ph.bem_add_1(bevt_10_ta_ph);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_ta_ph = bevl_initialDec.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevl_bein);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_11_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_24_ta_ph = bevl_initialDec.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_32_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_21_ta_ph.bem_addValue_1(bevt_29_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-878420186);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1130908394);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_8_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_v.bem_isTypedGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_4_ta_ph = bevp_build.bem_libNameGet_0();
bevt_3_ta_ph = bevp_objectCc.bem_relEmitName_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_b.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_2_ta_ph.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 234*/
 else /* Line: 235*/ {
bevt_9_ta_ph = beva_v.bem_namepathGet_0();
bevt_8_ta_ph = bem_getClassConfig_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = beva_b.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_6_ta_ph.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 236*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_0_ta_ph = beva_type.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 241*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
} /* Line: 242*/
 else /* Line: 243*/ {
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 244*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
} /* Line: 245*/
 else /* Line: 246*/ {
bevl_ccall = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
} /* Line: 247*/
} /* Line: 244*/
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_7_ta_ph = bevl_ccall.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_cc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevt_8_ta_ph = bem_overrideMtdDecGet_0();
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_bemBase);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevt_18_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_19_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_len);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(beva_belsBase);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_22_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_23_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 266*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-1073772186);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 267*/
 else /* Line: 268*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-1073772186);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 269*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-1073772186);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 276*/
 else /* Line: 277*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-1073772186);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 278*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_litArgs = bevt_0_ta_ph.bem_add_1(beva_sdec);
bevt_5_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_ta_ph = bevp_build.bem_libNameGet_0();
bevt_13_ta_ph = beva_newcc.bem_relEmitName_1(bevt_14_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = beva_newcc.bem_relEmitName_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_litArgs);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_newCall = bevt_7_ta_ph.bem_add_1(bevt_19_ta_ph);
} /* Line: 286*/
 else /* Line: 287*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_27_ta_ph = bevp_build.bem_libNameGet_0();
bevt_26_ta_ph = beva_newcc.bem_relEmitName_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_30_ta_ph = bevp_build.bem_libNameGet_0();
bevt_29_ta_ph = beva_newcc.bem_relEmitName_1(bevt_30_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_31_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevl_litArgs);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_newCall = bevt_20_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 288*/
return bevl_newCall;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_1_ta_ph = beva_typeName.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevp_setOutputTime = null;
bevt_1_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 337*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 337*/ {
bevt_5_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 337*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 337*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 337*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 337*/ {
return this;
} /* Line: 338*/
 else /* Line: 339*/ {
bevt_7_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevl_outts = bevt_6_ta_ph.bem_lastUpdatedGet_0();
bevt_9_ta_ph = bevp_inClass.bem_fromFileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(461992495);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bemd_0(-475723998);
bevt_10_ta_ph = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_ta_ph.bevi_bool)/* Line: 342*/ {
return this;
} /* Line: 345*/
bevp_setOutputTime = bevl_outts;
} /* Line: 348*/
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_1_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 353*/ {
bevt_1_ta_ph = bem_getLibOutput_0();
return bevt_1_ta_ph;
} /* Line: 354*/
bevt_2_ta_ph = super.bem_getClassOutput_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 360*/ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_1_ta_ph = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 363*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_2_4_IOFile bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 368*/ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_1_ta_ph = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 374*/ {
bevt_4_ta_ph = beva_cle.bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_fileGet_0();
bevt_3_ta_ph.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 376*/
} /* Line: 374*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) throws Throwable {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_7_ta_ph = bevl_bet.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(beva_mvn);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(beva_mvn);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevt_12_ta_ph = bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_14_ta_ph = bevl_bet.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 386*/
return bevl_bet;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_4_ContainerList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_9_4_ContainerList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
bevp_deow.bem_write_1(bevt_2_ta_ph);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = bevl_beh.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_ta_ph = bevl_beh.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevl_beh.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_beh.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevl_beh.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevl_beh.bem_addValue_1(bevt_19_ta_ph);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_23_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_22_ta_ph = bevl_bet.bem_addValue_1(bevt_23_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_25_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevt_20_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevl_bet.bem_addValue_1(bevt_27_ta_ph);
bevt_29_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (!(bevt_28_ta_ph.bevi_bool))/* Line: 406*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_31_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 408*/ {
bevt_32_ta_ph = bevt_0_ta_loop.bemd_0(1936587141);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 408*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(634443565);
if (bevl_firstmnsyn.bevi_bool)/* Line: 409*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 410*/
 else /* Line: 411*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_bet.bem_addValue_1(bevt_33_ta_ph);
} /* Line: 412*/
bevt_35_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_36_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_36_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 414*/
 else /* Line: 408*/ {
break;
} /* Line: 408*/
} /* Line: 408*/
} /* Line: 408*/
bevt_37_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevl_bet.bem_addValue_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_40_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_38_ta_ph = bevt_39_ta_ph.bem_has_1(bevt_40_ta_ph);
if (!(bevt_38_ta_ph.bevi_bool))/* Line: 419*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
} /* Line: 420*/
bevt_42_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 424*/ {
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_46_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_46_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 426*/ {
bevt_47_ta_ph = bevt_1_ta_loop.bemd_0(1936587141);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 426*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(634443565);
bevt_48_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_48_ta_ph.bevi_bool))/* Line: 427*/ {
if (bevl_firstptsyn.bevi_bool)/* Line: 428*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 429*/
 else /* Line: 430*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_bet.bem_addValue_1(bevt_49_ta_ph);
} /* Line: 431*/
bevt_51_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_52_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_52_ta_ph);
bevt_50_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 433*/
} /* Line: 427*/
 else /* Line: 426*/ {
break;
} /* Line: 426*/
} /* Line: 426*/
} /* Line: 426*/
bevt_53_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevl_bet.bem_addValue_1(bevt_54_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_56_ta_ph = bevl_bet.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_55_ta_ph = bevt_56_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_55_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_61_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_62_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_60_ta_ph = bevt_61_ta_ph.bem_equals_1(bevt_62_ta_ph);
if (bevt_60_ta_ph.bevi_bool)/* Line: 442*/ {
bevt_65_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_64_ta_ph = bevl_bet.bem_addValue_1(bevt_65_ta_ph);
bevt_66_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bem_addValue_1(bevt_66_ta_ph);
bevt_67_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_63_ta_ph.bem_addValue_1(bevt_67_ta_ph);
} /* Line: 443*/
 else /* Line: 444*/ {
bevt_70_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_69_ta_ph = bevl_bet.bem_addValue_1(bevt_70_ta_ph);
bevt_71_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_72_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_68_ta_ph.bem_addValue_1(bevt_72_ta_ph);
} /* Line: 445*/
bevt_73_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevl_bet.bem_addValue_1(bevt_73_ta_ph);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_75_ta_ph = bevl_bet.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_74_ta_ph.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevl_bet.bem_addValue_1(bevt_79_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_80_ta_ph = bem_genMark_1(bevt_81_ta_ph);
bevl_bet.bem_addValue_1(bevt_80_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevl_bet.bem_addValue_1(bevt_82_ta_ph);
bevt_83_ta_ph = bem_getClassOutput_0();
bevt_83_ta_ph.bem_write_1(bevl_bet);
bevt_84_ta_ph = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_84_ta_ph.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_2_4_IOFile bevt_20_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_2_4_IOFile bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_2_4_IOFile bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_31_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_45_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_56_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
if (bevp_deow == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 468*/ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_8_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_libName);
bevp_deon = bevt_4_ta_ph.bem_add_1(bevp_headExt);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_14_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevl_libName);
bevp_heon = bevt_10_ta_ph.bem_add_1(bevp_headExt);
bevt_16_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_ta_ph.bem_addStep_1(bevp_deon);
bevt_17_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_ta_ph.bem_addStep_1(bevp_heon);
bevt_21_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_existsGet_0();
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 474*/ {
bevt_23_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_fileGet_0();
bevt_22_ta_ph.bem_makeDirs_0();
} /* Line: 475*/
bevt_25_ta_ph = bevp_deop.bem_fileGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_ta_ph.bemd_0(-1178677845);
bevt_27_ta_ph = bevp_heop.bem_fileGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_ta_ph.bemd_0(-1178677845);
bevt_29_ta_ph = bevp_build.bem_paramsGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (bevt_28_ta_ph.bevi_bool)/* Line: 480*/ {
bevt_32_ta_ph = bevp_build.bem_paramsGet_0();
bevt_33_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_31_ta_ph = bevt_32_ta_ph.bem_get_1(bevt_33_ta_ph);
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 482*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(1936587141);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 482*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(634443565);
bevt_35_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_ta_ph.bem_fileGet_0();
bevt_37_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(-1178677845);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_ta_ph.bemd_0(2040090444);
bevt_38_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_38_ta_ph.bemd_0(206718762);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 488*/
 else /* Line: 482*/ {
break;
} /* Line: 482*/
} /* Line: 482*/
} /* Line: 482*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_deow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_43_ta_ph = bevp_build.bem_paramsGet_0();
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_42_ta_ph = bevt_43_ta_ph.bem_has_1(bevt_44_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 502*/ {
bevt_46_ta_ph = bevp_build.bem_paramsGet_0();
bevt_47_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_45_ta_ph = bevt_46_ta_ph.bem_get_1(bevt_47_ta_ph);
bevt_1_ta_loop = bevt_45_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 504*/ {
bevt_48_ta_ph = bevt_1_ta_loop.bemd_0(1936587141);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 504*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(634443565);
bevt_49_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_49_ta_ph.bem_fileGet_0();
bevt_51_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bemd_0(-1178677845);
bevl_inc = (BEC_2_4_6_TextString) bevt_50_ta_ph.bemd_0(2040090444);
bevt_52_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_52_ta_ph.bemd_0(206718762);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 510*/
 else /* Line: 504*/ {
break;
} /* Line: 504*/
} /* Line: 504*/
} /* Line: 504*/
bevt_54_ta_ph = bevp_build.bem_paramsGet_0();
bevt_55_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_53_ta_ph = bevt_54_ta_ph.bem_has_1(bevt_55_ta_ph);
if (bevt_53_ta_ph.bevi_bool)/* Line: 513*/ {
bevt_57_ta_ph = bevp_build.bem_paramsGet_0();
bevt_58_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_56_ta_ph = bevt_57_ta_ph.bem_get_1(bevt_58_ta_ph);
bevt_2_ta_loop = bevt_56_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 515*/ {
bevt_59_ta_ph = bevt_2_ta_loop.bemd_0(1936587141);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 515*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(634443565);
bevt_60_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_60_ta_ph.bem_fileGet_0();
bevt_62_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(-1178677845);
bevl_inc = (BEC_2_4_6_TextString) bevt_61_ta_ph.bemd_0(2040090444);
bevt_63_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_63_ta_ph.bemd_0(206718762);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 521*/
 else /* Line: 515*/ {
break;
} /* Line: 515*/
} /* Line: 515*/
} /* Line: 515*/
} /* Line: 513*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_15_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_27_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
if (bevp_shlibe == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 534*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_existsGet_0();
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 536*/ {
bevt_8_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 537*/
bevt_10_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_ta_ph.bemd_0(-1178677845);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevp_shlibe.bem_write_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_paramsGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_12_ta_ph = bevt_13_ta_ph.bem_has_1(bevt_14_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 543*/ {
bevt_16_ta_ph = bevp_build.bem_paramsGet_0();
bevt_17_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_15_ta_ph = bevt_16_ta_ph.bem_get_1(bevt_17_ta_ph);
bevt_0_ta_loop = bevt_15_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 545*/ {
bevt_18_ta_ph = bevt_0_ta_loop.bemd_0(1936587141);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 545*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(634443565);
bevt_19_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_ta_ph.bem_fileGet_0();
bevt_21_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(-1178677845);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_ta_ph.bemd_0(2040090444);
bevt_22_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_22_ta_ph.bemd_0(206718762);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 551*/
 else /* Line: 545*/ {
break;
} /* Line: 545*/
} /* Line: 545*/
} /* Line: 545*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_shlibe.bem_write_1(bevt_23_ta_ph);
bevp_lineCount.bem_increment_0();
bevt_25_ta_ph = bevp_build.bem_paramsGet_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 557*/ {
bevt_28_ta_ph = bevp_build.bem_paramsGet_0();
bevt_29_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_27_ta_ph = bevt_28_ta_ph.bem_get_1(bevt_29_ta_ph);
bevt_1_ta_loop = bevt_27_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 558*/ {
bevt_30_ta_ph = bevt_1_ta_loop.bemd_0(1936587141);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 558*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(634443565);
bevt_31_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_ta_ph.bem_fileGet_0();
bevt_33_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(-1178677845);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_ta_ph.bemd_0(2040090444);
bevt_34_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_34_ta_ph.bemd_0(206718762);
bevt_35_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 563*/
 else /* Line: 558*/ {
break;
} /* Line: 558*/
} /* Line: 558*/
} /* Line: 558*/
} /* Line: 557*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevp_heow.bem_write_1(bevt_1_ta_ph);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 581*/ {
bevl_mh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_5_ta_ph = bevl_mh.bem_addValue_1(bevt_6_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 584*/
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 605*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_4_ta_ph = beva_sdec.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 606*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(-1711068518);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 618*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(1936587141);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 618*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(634443565);
bevt_6_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_6_ta_ph.bevi_bool))/* Line: 619*/ {
if (bevl_first.bevi_bool)/* Line: 620*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 621*/
 else /* Line: 622*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
} /* Line: 623*/
bevt_10_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 625*/
} /* Line: 619*/
 else /* Line: 618*/ {
break;
} /* Line: 618*/
} /* Line: 618*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_13_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_14_ta_ph);
bevt_13_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = bevl_initialDec.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_bein);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_4_ta_ph.bem_addValue_1(bevt_13_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
bevt_1_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_ta_ph.bem_relEmitName_1(bevt_2_ta_ph);
bevt_4_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(1083174784);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_ta_ph = bem_overrideMtdDecGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevl_oname);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_20_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_notEquals_1(bevl_oname);
if (bevt_19_ta_ph.bevi_bool)/* Line: 667*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_ta_ph, bevl_asnr);
} /* Line: 668*/
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_24_ta_ph = bevt_25_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevl_asnr);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_28_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_29_ta_ph);
bevt_28_ta_ph.bem_addValue_1(bevp_nl);
bevt_37_ta_ph = bem_overrideMtdDecGet_0();
bevt_36_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevl_oname);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevt_40_ta_ph);
bevt_31_ta_ph = bevt_32_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_30_ta_ph = bevt_31_ta_ph.bem_addValue_1(bevt_41_ta_ph);
bevt_30_ta_ph.bem_addValue_1(bevp_nl);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_44_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevl_stinst);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_47_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_48_ta_ph);
bevt_47_ta_ph.bem_addValue_1(bevp_nl);
bevt_55_ta_ph = bem_overrideMtdDecGet_0();
bevt_54_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_55_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_62_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(844044976);
if (bevt_61_ta_ph == null) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 687*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 687*/ {
bevt_65_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_64_ta_ph = bevt_65_ta_ph.bemd_0(844044976);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_1(1063069793, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 687*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 687*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 687*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 687*/ {
bevt_67_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_66_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_67_ta_ph);
bevt_66_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 688*/
 else /* Line: 689*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_68_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_69_ta_ph);
bevt_68_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 690*/
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_70_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_71_ta_ph);
bevt_70_ta_ph.bem_addValue_1(bevp_nl);
bevt_78_ta_ph = bem_overrideMtdDecGet_0();
bevt_77_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_76_ta_ph = bevt_77_ta_ph.bem_addValue_1(bevt_79_ta_ph);
bevt_80_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bem_addValue_1(bevt_80_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevt_81_ta_ph);
bevt_73_ta_ph = bevt_74_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_72_ta_ph = bevt_73_ta_ph.bem_addValue_1(bevt_82_ta_ph);
bevt_72_ta_ph.bem_addValue_1(bevp_nl);
bevt_84_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_83_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_85_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_89_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_90_ta_ph);
bevt_91_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_88_ta_ph = bevt_89_ta_ph.bem_addValue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_87_ta_ph = bevt_88_ta_ph.bem_addValue_1(bevt_92_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_95_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_96_ta_ph);
bevt_94_ta_ph = bevt_95_ta_ph.bem_addValue_1(bevl_tinst);
bevt_97_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_93_ta_ph = bevt_94_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_98_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_99_ta_ph);
bevt_98_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_libEmitName);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_libEmitName);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevp_heow.bem_write_1(bevt_4_ta_ph);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 21, 22, 23, 27, 29, 30, 31, 32, 33, 37, 41, 41, 42, 42, 42, 44, 44, 46, 46, 46, 46, 46, 46, 48, 48, 49, 49, 51, 51, 53, 53, 53, 53, 53, 53, 53, 55, 55, 57, 57, 59, 59, 62, 62, 64, 64, 66, 68, 70, 72, 74, 74, 74, 75, 75, 76, 76, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 85, 86, 86, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 91, 91, 91, 91, 93, 93, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 100, 100, 100, 104, 106, 107, 108, 108, 109, 113, 113, 117, 117, 121, 121, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 128, 130, 130, 130, 130, 130, 130, 132, 132, 132, 132, 132, 132, 132, 132, 132, 132, 134, 136, 136, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 146, 146, 146, 146, 147, 149, 149, 151, 157, 158, 159, 160, 161, 162, 164, 166, 166, 166, 173, 174, 175, 176, 177, 178, 180, 182, 182, 182, 187, 187, 187, 187, 188, 188, 189, 191, 191, 195, 195, 195, 195, 195, 195, 195, 195, 199, 199, 199, 199, 200, 200, 200, 202, 208, 208, 208, 208, 208, 210, 210, 210, 210, 210, 210, 210, 210, 212, 214, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 218, 218, 218, 218, 218, 218, 218, 218, 218, 218, 218, 218, 218, 218, 220, 225, 225, 225, 226, 227, 227, 227, 227, 227, 227, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 233, 233, 233, 234, 234, 234, 234, 234, 236, 236, 236, 236, 236, 236, 236, 241, 241, 242, 244, 244, 244, 245, 247, 250, 250, 250, 250, 250, 250, 250, 250, 255, 255, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 260, 260, 260, 260, 260, 260, 260, 260, 260, 262, 262, 262, 266, 266, 266, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 271, 275, 275, 275, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 280, 284, 284, 284, 284, 284, 285, 285, 285, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 288, 288, 288, 288, 288, 288, 288, 288, 288, 288, 288, 288, 288, 288, 290, 295, 296, 297, 297, 298, 304, 304, 304, 304, 308, 308, 312, 312, 317, 317, 321, 321, 325, 325, 329, 329, 329, 336, 337, 0, 337, 337, 337, 337, 337, 0, 0, 338, 340, 340, 340, 341, 341, 341, 342, 345, 348, 353, 354, 354, 356, 356, 360, 361, 362, 362, 363, 368, 370, 371, 371, 372, 373, 374, 374, 375, 375, 375, 376, 382, 383, 383, 383, 384, 384, 384, 384, 384, 384, 384, 384, 384, 385, 385, 385, 385, 386, 386, 386, 388, 392, 392, 392, 392, 392, 392, 393, 394, 394, 394, 394, 394, 394, 395, 395, 396, 396, 396, 396, 397, 397, 398, 398, 399, 399, 400, 400, 401, 403, 404, 404, 404, 404, 404, 404, 404, 404, 405, 405, 406, 406, 406, 407, 408, 408, 0, 408, 408, 410, 412, 412, 414, 414, 414, 414, 417, 417, 419, 419, 419, 420, 420, 423, 423, 424, 424, 424, 425, 426, 426, 0, 426, 426, 427, 429, 431, 431, 433, 433, 433, 433, 437, 437, 439, 439, 441, 441, 441, 441, 441, 441, 442, 442, 442, 443, 443, 443, 443, 443, 443, 445, 445, 445, 445, 445, 445, 447, 447, 449, 449, 449, 449, 449, 449, 450, 450, 451, 451, 451, 452, 452, 455, 455, 456, 456, 468, 468, 469, 470, 470, 470, 470, 470, 470, 470, 471, 471, 471, 471, 471, 471, 471, 472, 472, 473, 473, 474, 474, 474, 474, 474, 475, 475, 475, 477, 477, 477, 478, 478, 478, 480, 480, 480, 482, 482, 482, 482, 0, 482, 482, 484, 484, 485, 485, 485, 486, 486, 488, 492, 492, 495, 495, 496, 496, 502, 502, 502, 504, 504, 504, 504, 0, 504, 504, 506, 506, 507, 507, 507, 508, 508, 510, 513, 513, 513, 515, 515, 515, 515, 0, 515, 515, 517, 517, 518, 518, 518, 519, 519, 521, 528, 529, 534, 534, 535, 536, 536, 536, 536, 536, 537, 537, 537, 539, 539, 539, 541, 541, 543, 543, 543, 545, 545, 545, 545, 0, 545, 545, 547, 547, 548, 548, 548, 549, 549, 551, 555, 555, 556, 557, 557, 557, 558, 558, 558, 558, 0, 558, 558, 559, 559, 560, 560, 560, 561, 561, 562, 562, 563, 569, 574, 575, 577, 577, 579, 579, 581, 581, 581, 582, 583, 583, 583, 584, 587, 588, 593, 593, 597, 597, 601, 601, 605, 605, 605, 606, 606, 606, 606, 606, 612, 612, 613, 615, 615, 615, 615, 617, 618, 0, 618, 618, 619, 621, 623, 623, 625, 625, 625, 625, 625, 625, 630, 630, 630, 635, 637, 637, 637, 637, 637, 639, 639, 639, 639, 639, 639, 639, 639, 639, 639, 639, 641, 645, 645, 646, 646, 646, 646, 647, 651, 651, 652, 652, 652, 652, 653, 653, 653, 653, 657, 657, 657, 661, 661, 661, 662, 662, 662, 663, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 666, 667, 667, 668, 668, 671, 671, 671, 671, 671, 671, 671, 673, 673, 673, 676, 676, 676, 676, 676, 676, 676, 676, 676, 676, 676, 676, 676, 681, 681, 681, 681, 681, 681, 684, 684, 684, 686, 686, 686, 686, 686, 686, 686, 686, 686, 686, 686, 686, 687, 687, 687, 687, 0, 687, 687, 687, 0, 0, 688, 688, 688, 690, 690, 690, 692, 693, 696, 696, 696, 698, 698, 698, 698, 698, 698, 698, 698, 698, 698, 698, 698, 699, 699, 699, 701, 701, 701, 703, 705, 705, 705, 705, 705, 705, 705, 707, 707, 707, 707, 707, 707, 709, 709, 709, 715, 715, 715, 715, 715, 716, 716, 716, 716, 716, 718, 723, 723, 724, 724, 724, 724, 725, 725, 725, 725, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 189, 254, 259, 260, 261, 262, 265, 266, 268, 269, 270, 271, 272, 273, 274, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 293, 294, 295, 296, 297, 298, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 312, 313, 314, 315, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 343, 344, 345, 346, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 426, 427, 428, 429, 430, 431, 435, 436, 440, 441, 445, 446, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 525, 526, 527, 532, 533, 536, 537, 538, 539, 541, 544, 545, 546, 547, 549, 552, 553, 557, 566, 568, 571, 573, 576, 578, 581, 585, 586, 587, 596, 598, 601, 603, 606, 608, 611, 615, 616, 617, 627, 628, 629, 630, 632, 633, 634, 636, 637, 647, 648, 649, 650, 651, 652, 653, 654, 664, 665, 666, 667, 669, 670, 671, 674, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 811, 812, 817, 818, 819, 820, 821, 822, 825, 826, 827, 828, 829, 830, 831, 849, 850, 852, 855, 856, 857, 859, 862, 865, 866, 867, 868, 869, 870, 871, 872, 876, 877, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 968, 969, 970, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982, 983, 984, 985, 986, 987, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1003, 1004, 1005, 1007, 1044, 1045, 1046, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1083, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 1142, 1143, 1146, 1147, 1148, 1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1161, 1166, 1167, 1168, 1169, 1170, 1177, 1178, 1179, 1180, 1184, 1185, 1189, 1190, 1194, 1195, 1199, 1200, 1204, 1205, 1210, 1211, 1212, 1228, 1229, 1231, 1234, 1235, 1236, 1237, 1242, 1243, 1246, 1250, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1261, 1263, 1271, 1273, 1274, 1276, 1277, 1283, 1285, 1286, 1287, 1288, 1299, 1301, 1302, 1303, 1304, 1305, 1306, 1311, 1312, 1313, 1314, 1315, 1338, 1339, 1340, 1341, 1343, 1344, 1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1360, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475, 1476, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1495, 1497, 1498, 1499, 1499, 1502, 1504, 1506, 1509, 1510, 1512, 1513, 1514, 1515, 1522, 1523, 1524, 1525, 1526, 1528, 1529, 1531, 1532, 1533, 1534, 1535, 1537, 1538, 1539, 1539, 1542, 1544, 1545, 1548, 1551, 1552, 1554, 1555, 1556, 1557, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1579, 1580, 1581, 1582, 1583, 1584, 1587, 1588, 1589, 1590, 1591, 1592, 1594, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1608, 1609, 1610, 1611, 1612, 1684, 1689, 1690, 1691, 1692, 1693, 1694, 1695, 1696, 1697, 1698, 1699, 1700, 1701, 1702, 1703, 1704, 1705, 1706, 1707, 1708, 1709, 1710, 1711, 1712, 1717, 1718, 1719, 1720, 1722, 1723, 1724, 1725, 1726, 1727, 1728, 1729, 1730, 1732, 1733, 1734, 1735, 1735, 1738, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1763, 1765, 1766, 1767, 1768, 1768, 1771, 1773, 1774, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1788, 1789, 1790, 1792, 1793, 1794, 1795, 1795, 1798, 1800, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1819, 1820, 1863, 1868, 1869, 1870, 1871, 1872, 1873, 1878, 1879, 1880, 1881, 1883, 1884, 1885, 1886, 1887, 1888, 1889, 1890, 1892, 1893, 1894, 1895, 1895, 1898, 1900, 1901, 1902, 1903, 1904, 1905, 1906, 1907, 1908, 1915, 1916, 1917, 1918, 1919, 1920, 1922, 1923, 1924, 1925, 1925, 1928, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1948, 1959, 1960, 1961, 1962, 1963, 1964, 1965, 1966, 1967, 1969, 1970, 1971, 1972, 1973, 1975, 1976, 1981, 1982, 1986, 1987, 1992, 1993, 2004, 2005, 2006, 2008, 2009, 2010, 2011, 2012, 2036, 2037, 2038, 2039, 2040, 2041, 2042, 2043, 2044, 2044, 2047, 2049, 2050, 2053, 2056, 2057, 2059, 2060, 2061, 2062, 2063, 2064, 2071, 2072, 2073, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2101, 2102, 2103, 2104, 2105, 2106, 2107, 2108, 2109, 2110, 2119, 2120, 2121, 2122, 2123, 2124, 2125, 2137, 2138, 2139, 2140, 2141, 2142, 2143, 2144, 2145, 2146, 2151, 2152, 2153, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268, 2269, 2270, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2283, 2284, 2285, 2287, 2288, 2290, 2291, 2292, 2293, 2294, 2295, 2296, 2297, 2298, 2299, 2300, 2301, 2302, 2303, 2304, 2305, 2306, 2307, 2308, 2309, 2310, 2311, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2341, 2342, 2345, 2346, 2347, 2349, 2352, 2356, 2357, 2358, 2361, 2362, 2363, 2365, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2384, 2385, 2386, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2394, 2395, 2396, 2397, 2398, 2399, 2400, 2401, 2402, 2403, 2404, 2416, 2417, 2418, 2419, 2420, 2421, 2422, 2423, 2424, 2425, 2426, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2448, 2451, 2454, 2458, 2461, 2465, 2468, 2472, 2475, 2479, 2482, 2486, 2489, 2493, 2496, 2500, 2503, 2507, 2510, 2514, 2517, 2521, 2524};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 174
new 0 17 174
assign 1 18 175
new 0 18 175
assign 1 19 176
new 0 19 176
assign 1 21 177
new 0 21 177
assign 1 22 178
new 0 22 178
assign 1 23 179
new 0 23 179
new 1 27 180
assign 1 29 181
new 0 29 181
assign 1 30 182
new 0 30 182
assign 1 31 183
new 0 31 183
assign 1 32 184
new 0 32 184
assign 1 33 185
new 0 33 185
addValue 1 37 189
assign 1 41 254
def 1 41 259
assign 1 42 260
libNameGet 0 42 260
assign 1 42 261
relEmitName 1 42 261
assign 1 42 262
extend 1 42 262
assign 1 44 265
new 0 44 265
assign 1 44 266
extend 1 44 266
assign 1 46 268
new 0 46 268
assign 1 46 269
emitNameGet 0 46 269
assign 1 46 270
addValue 1 46 270
assign 1 46 271
addValue 1 46 271
assign 1 46 272
new 0 46 272
assign 1 46 273
addValue 1 46 273
assign 1 48 274
def 1 48 279
assign 1 49 280
new 0 49 280
addValue 1 49 281
assign 1 51 282
new 0 51 282
addValue 1 51 283
assign 1 53 284
new 0 53 284
assign 1 53 285
addValue 1 53 285
assign 1 53 286
libNameGet 0 53 286
assign 1 53 287
relEmitName 1 53 287
assign 1 53 288
addValue 1 53 288
assign 1 53 289
new 0 53 289
addValue 1 53 290
assign 1 55 293
new 0 55 293
addValue 1 55 294
assign 1 57 295
new 0 57 295
addValue 1 57 296
assign 1 59 297
new 0 59 297
addValue 1 59 298
assign 1 62 300
new 0 62 300
addValue 1 62 301
assign 1 64 302
new 0 64 302
addValue 1 64 303
write 1 66 304
write 1 68 305
write 1 70 306
clear 0 72 307
assign 1 74 308
emitChecksGet 0 74 308
assign 1 74 309
new 0 74 309
assign 1 74 310
has 1 74 310
assign 1 75 312
new 0 75 312
write 1 75 313
assign 1 76 314
new 0 76 314
write 1 76 315
assign 1 78 317
new 0 78 317
write 1 78 318
assign 1 79 319
new 0 79 319
assign 1 79 320
emitNameGet 0 79 320
assign 1 79 321
add 1 79 321
assign 1 79 322
new 0 79 322
assign 1 79 323
add 1 79 323
assign 1 79 324
getHeaderInitialInst 1 79 324
assign 1 79 325
add 1 79 325
assign 1 79 326
new 0 79 326
assign 1 79 327
add 1 79 327
write 1 79 328
assign 1 80 329
new 0 80 329
write 1 80 330
assign 1 81 331
new 0 81 331
write 1 81 332
assign 1 82 333
new 0 82 333
write 1 82 334
assign 1 83 335
new 0 83 335
write 1 83 336
assign 1 84 337
new 0 84 337
write 1 84 338
assign 1 85 339
emitChecksGet 0 85 339
assign 1 85 340
new 0 85 340
assign 1 85 341
has 1 85 341
assign 1 86 343
new 0 86 343
write 1 86 344
assign 1 87 345
new 0 87 345
write 1 87 346
assign 1 89 348
new 0 89 348
assign 1 89 349
emitNameGet 0 89 349
assign 1 89 350
add 1 89 350
assign 1 89 351
new 0 89 351
assign 1 89 352
add 1 89 352
write 1 89 353
assign 1 91 354
new 0 91 354
assign 1 91 355
emitNameGet 0 91 355
assign 1 91 356
add 1 91 356
assign 1 91 357
new 0 91 357
assign 1 91 358
add 1 91 358
write 1 91 359
assign 1 93 360
new 0 93 360
return 1 93 361
assign 1 97 391
overrideMtdDecGet 0 97 391
assign 1 97 392
addValue 1 97 392
assign 1 97 393
getClassConfig 1 97 393
assign 1 97 394
libNameGet 0 97 394
assign 1 97 395
relEmitName 1 97 395
assign 1 97 396
addValue 1 97 396
assign 1 97 397
new 0 97 397
assign 1 97 398
addValue 1 97 398
assign 1 97 399
emitNameGet 0 97 399
assign 1 97 400
addValue 1 97 400
assign 1 97 401
new 0 97 401
assign 1 97 402
addValue 1 97 402
assign 1 97 403
addValue 1 97 403
assign 1 97 404
new 0 97 404
assign 1 97 405
addValue 1 97 405
addValue 1 97 406
assign 1 98 407
new 0 98 407
assign 1 98 408
addValue 1 98 408
assign 1 98 409
heldGet 0 98 409
assign 1 98 410
namepathGet 0 98 410
assign 1 98 411
getClassConfig 1 98 411
assign 1 98 412
libNameGet 0 98 412
assign 1 98 413
relEmitName 1 98 413
assign 1 98 414
addValue 1 98 414
assign 1 98 415
new 0 98 415
assign 1 98 416
addValue 1 98 416
addValue 1 98 417
assign 1 100 418
new 0 100 418
assign 1 100 419
addValue 1 100 419
addValue 1 100 420
assign 1 104 426
new 0 104 426
write 1 106 427
clear 0 107 428
assign 1 108 429
new 0 108 429
write 1 108 430
return 1 109 431
assign 1 113 435
new 0 113 435
return 1 113 436
assign 1 117 440
new 0 117 440
return 1 117 441
assign 1 121 445
new 0 121 445
return 1 121 446
assign 1 126 476
addValue 1 126 476
assign 1 126 477
libNameGet 0 126 477
assign 1 126 478
relEmitName 1 126 478
assign 1 126 479
addValue 1 126 479
assign 1 126 480
new 0 126 480
assign 1 126 481
addValue 1 126 481
assign 1 126 482
emitNameGet 0 126 482
assign 1 126 483
addValue 1 126 483
assign 1 126 484
new 0 126 484
assign 1 126 485
addValue 1 126 485
assign 1 126 486
addValue 1 126 486
assign 1 126 487
new 0 126 487
addValue 1 126 488
addValue 1 128 489
assign 1 130 490
new 0 130 490
assign 1 130 491
addValue 1 130 491
assign 1 130 492
addValue 1 130 492
assign 1 130 493
new 0 130 493
assign 1 130 494
addValue 1 130 494
addValue 1 130 495
assign 1 132 496
new 0 132 496
assign 1 132 497
addValue 1 132 497
assign 1 132 498
libNameGet 0 132 498
assign 1 132 499
relEmitName 1 132 499
assign 1 132 500
addValue 1 132 500
assign 1 132 501
new 0 132 501
assign 1 132 502
addValue 1 132 502
assign 1 132 503
addValue 1 132 503
assign 1 132 504
new 0 132 504
addValue 1 132 505
addValue 1 134 506
assign 1 136 507
new 0 136 507
addValue 1 136 508
assign 1 142 525
typenameGet 0 142 525
assign 1 142 526
NULLGet 0 142 526
assign 1 142 527
equals 1 142 532
assign 1 143 533
new 0 143 533
assign 1 144 536
heldGet 0 144 536
assign 1 144 537
nameGet 0 144 537
assign 1 144 538
new 0 144 538
assign 1 144 539
equals 1 144 539
assign 1 145 541
new 0 145 541
assign 1 146 544
heldGet 0 146 544
assign 1 146 545
nameGet 0 146 545
assign 1 146 546
new 0 146 546
assign 1 146 547
equals 1 146 547
assign 1 147 549
new 0 147 549
assign 1 149 552
heldGet 0 149 552
assign 1 149 553
nameForVar 1 149 553
return 1 151 557
assign 1 157 566
isTmpVarGet 0 157 566
assign 1 158 568
new 0 158 568
assign 1 159 571
isPropertyGet 0 159 571
assign 1 160 573
new 0 160 573
assign 1 161 576
isArgGet 0 161 576
assign 1 162 578
new 0 162 578
assign 1 164 581
new 0 164 581
assign 1 166 585
nameGet 0 166 585
assign 1 166 586
add 1 166 586
return 1 166 587
assign 1 173 596
isTmpVarGet 0 173 596
assign 1 174 598
new 0 174 598
assign 1 175 601
isPropertyGet 0 175 601
assign 1 176 603
new 0 176 603
assign 1 177 606
isArgGet 0 177 606
assign 1 178 608
new 0 178 608
assign 1 180 611
new 0 180 611
assign 1 182 615
nameGet 0 182 615
assign 1 182 616
add 1 182 616
return 1 182 617
assign 1 187 627
heldGet 0 187 627
assign 1 187 628
nameGet 0 187 628
assign 1 187 629
new 0 187 629
assign 1 187 630
equals 1 187 630
assign 1 188 632
new 0 188 632
assign 1 188 633
add 1 188 633
return 1 189 634
assign 1 191 636
formCallTarg 1 191 636
return 1 191 637
assign 1 195 647
new 0 195 647
assign 1 195 648
addValue 1 195 648
assign 1 195 649
secondGet 0 195 649
assign 1 195 650
formTarg 1 195 650
assign 1 195 651
addValue 1 195 651
assign 1 195 652
new 0 195 652
assign 1 195 653
addValue 1 195 653
addValue 1 195 654
assign 1 199 664
heldGet 0 199 664
assign 1 199 665
langsGet 0 199 665
assign 1 199 666
new 0 199 666
assign 1 199 667
has 1 199 667
assign 1 200 669
heldGet 0 200 669
assign 1 200 670
textGet 0 200 670
addValue 1 200 671
handleClassEmit 1 202 674
assign 1 208 716
new 0 208 716
assign 1 208 717
emitNameGet 0 208 717
assign 1 208 718
add 1 208 718
assign 1 208 719
new 0 208 719
assign 1 208 720
add 1 208 720
assign 1 210 721
new 0 210 721
assign 1 210 722
typeEmitNameGet 0 210 722
assign 1 210 723
add 1 210 723
assign 1 210 724
new 0 210 724
assign 1 210 725
add 1 210 725
assign 1 210 726
add 1 210 726
assign 1 210 727
new 0 210 727
assign 1 210 728
add 1 210 728
addClassHeader 1 212 729
assign 1 214 730
new 0 214 730
assign 1 216 731
typeEmitNameGet 0 216 731
assign 1 216 732
addValue 1 216 732
assign 1 216 733
new 0 216 733
assign 1 216 734
addValue 1 216 734
assign 1 216 735
emitNameGet 0 216 735
assign 1 216 736
addValue 1 216 736
assign 1 216 737
new 0 216 737
assign 1 216 738
addValue 1 216 738
assign 1 216 739
addValue 1 216 739
assign 1 216 740
new 0 216 740
addValue 1 216 741
assign 1 218 742
new 0 218 742
assign 1 218 743
addValue 1 218 743
assign 1 218 744
typeEmitNameGet 0 218 744
assign 1 218 745
addValue 1 218 745
assign 1 218 746
new 0 218 746
assign 1 218 747
addValue 1 218 747
assign 1 218 748
emitNameGet 0 218 748
assign 1 218 749
addValue 1 218 749
assign 1 218 750
new 0 218 750
assign 1 218 751
emitNameGet 0 218 751
assign 1 218 752
add 1 218 752
assign 1 218 753
new 0 218 753
assign 1 218 754
add 1 218 754
addValue 1 218 755
return 1 220 756
assign 1 225 776
new 0 225 776
assign 1 225 777
toString 0 225 777
assign 1 225 778
add 1 225 778
incrementValue 0 226 779
assign 1 227 780
new 0 227 780
assign 1 227 781
addValue 1 227 781
assign 1 227 782
addValue 1 227 782
assign 1 227 783
new 0 227 783
assign 1 227 784
addValue 1 227 784
addValue 1 227 785
assign 1 229 786
containedGet 0 229 786
assign 1 229 787
firstGet 0 229 787
assign 1 229 788
containedGet 0 229 788
assign 1 229 789
firstGet 0 229 789
assign 1 229 790
new 0 229 790
assign 1 229 791
add 1 229 791
assign 1 229 792
new 0 229 792
assign 1 229 793
add 1 229 793
assign 1 229 794
finalAssign 4 229 794
addValue 1 229 795
assign 1 233 811
isTypedGet 0 233 811
assign 1 233 812
not 0 233 817
assign 1 234 818
libNameGet 0 234 818
assign 1 234 819
relEmitName 1 234 819
assign 1 234 820
addValue 1 234 820
assign 1 234 821
new 0 234 821
addValue 1 234 822
assign 1 236 825
namepathGet 0 236 825
assign 1 236 826
getClassConfig 1 236 826
assign 1 236 827
libNameGet 0 236 827
assign 1 236 828
relEmitName 1 236 828
assign 1 236 829
addValue 1 236 829
assign 1 236 830
new 0 236 830
addValue 1 236 831
assign 1 241 849
new 0 241 849
assign 1 241 850
equals 1 241 850
assign 1 242 852
new 0 242 852
assign 1 244 855
emitChecksGet 0 244 855
assign 1 244 856
new 0 244 856
assign 1 244 857
has 1 244 857
assign 1 245 859
new 0 245 859
assign 1 247 862
new 0 247 862
assign 1 250 865
new 0 250 865
assign 1 250 866
add 1 250 866
assign 1 250 867
libNameGet 0 250 867
assign 1 250 868
relEmitName 1 250 868
assign 1 250 869
add 1 250 869
assign 1 250 870
new 0 250 870
assign 1 250 871
add 1 250 871
return 1 250 872
assign 1 255 876
new 0 255 876
return 1 255 877
assign 1 259 904
overrideMtdDecGet 0 259 904
assign 1 259 905
addValue 1 259 905
assign 1 259 906
new 0 259 906
assign 1 259 907
addValue 1 259 907
assign 1 259 908
emitNameGet 0 259 908
assign 1 259 909
addValue 1 259 909
assign 1 259 910
new 0 259 910
assign 1 259 911
addValue 1 259 911
assign 1 259 912
addValue 1 259 912
assign 1 259 913
new 0 259 913
assign 1 259 914
addValue 1 259 914
assign 1 259 915
addValue 1 259 915
assign 1 259 916
new 0 259 916
assign 1 259 917
addValue 1 259 917
addValue 1 259 918
assign 1 260 919
new 0 260 919
assign 1 260 920
addValue 1 260 920
assign 1 260 921
addValue 1 260 921
assign 1 260 922
new 0 260 922
assign 1 260 923
addValue 1 260 923
assign 1 260 924
addValue 1 260 924
assign 1 260 925
new 0 260 925
assign 1 260 926
addValue 1 260 926
addValue 1 260 927
assign 1 262 928
new 0 262 928
assign 1 262 929
addValue 1 262 929
addValue 1 262 930
assign 1 266 968
emitChecksGet 0 266 968
assign 1 266 969
new 0 266 969
assign 1 266 970
has 1 266 970
assign 1 267 972
new 0 267 972
assign 1 267 973
libNameGet 0 267 973
assign 1 267 974
relEmitName 1 267 974
assign 1 267 975
add 1 267 975
assign 1 267 976
new 0 267 976
assign 1 267 977
add 1 267 977
assign 1 267 978
libNameGet 0 267 978
assign 1 267 979
relEmitName 1 267 979
assign 1 267 980
add 1 267 980
assign 1 267 981
new 0 267 981
assign 1 267 982
add 1 267 982
assign 1 267 983
heldGet 0 267 983
assign 1 267 984
literalValueGet 0 267 984
assign 1 267 985
add 1 267 985
assign 1 267 986
new 0 267 986
assign 1 267 987
add 1 267 987
assign 1 269 990
new 0 269 990
assign 1 269 991
libNameGet 0 269 991
assign 1 269 992
relEmitName 1 269 992
assign 1 269 993
add 1 269 993
assign 1 269 994
new 0 269 994
assign 1 269 995
add 1 269 995
assign 1 269 996
libNameGet 0 269 996
assign 1 269 997
relEmitName 1 269 997
assign 1 269 998
add 1 269 998
assign 1 269 999
new 0 269 999
assign 1 269 1000
add 1 269 1000
assign 1 269 1001
heldGet 0 269 1001
assign 1 269 1002
literalValueGet 0 269 1002
assign 1 269 1003
add 1 269 1003
assign 1 269 1004
new 0 269 1004
assign 1 269 1005
add 1 269 1005
return 1 271 1007
assign 1 275 1044
emitChecksGet 0 275 1044
assign 1 275 1045
new 0 275 1045
assign 1 275 1046
has 1 275 1046
assign 1 276 1048
new 0 276 1048
assign 1 276 1049
libNameGet 0 276 1049
assign 1 276 1050
relEmitName 1 276 1050
assign 1 276 1051
add 1 276 1051
assign 1 276 1052
new 0 276 1052
assign 1 276 1053
add 1 276 1053
assign 1 276 1054
libNameGet 0 276 1054
assign 1 276 1055
relEmitName 1 276 1055
assign 1 276 1056
add 1 276 1056
assign 1 276 1057
new 0 276 1057
assign 1 276 1058
add 1 276 1058
assign 1 276 1059
heldGet 0 276 1059
assign 1 276 1060
literalValueGet 0 276 1060
assign 1 276 1061
add 1 276 1061
assign 1 276 1062
new 0 276 1062
assign 1 276 1063
add 1 276 1063
assign 1 278 1066
new 0 278 1066
assign 1 278 1067
libNameGet 0 278 1067
assign 1 278 1068
relEmitName 1 278 1068
assign 1 278 1069
add 1 278 1069
assign 1 278 1070
new 0 278 1070
assign 1 278 1071
add 1 278 1071
assign 1 278 1072
libNameGet 0 278 1072
assign 1 278 1073
relEmitName 1 278 1073
assign 1 278 1074
add 1 278 1074
assign 1 278 1075
new 0 278 1075
assign 1 278 1076
add 1 278 1076
assign 1 278 1077
heldGet 0 278 1077
assign 1 278 1078
literalValueGet 0 278 1078
assign 1 278 1079
add 1 278 1079
assign 1 278 1080
new 0 278 1080
assign 1 278 1081
add 1 278 1081
return 1 280 1083
assign 1 284 1121
new 0 284 1121
assign 1 284 1122
add 1 284 1122
assign 1 284 1123
new 0 284 1123
assign 1 284 1124
add 1 284 1124
assign 1 284 1125
add 1 284 1125
assign 1 285 1126
emitChecksGet 0 285 1126
assign 1 285 1127
new 0 285 1127
assign 1 285 1128
has 1 285 1128
assign 1 286 1130
new 0 286 1130
assign 1 286 1131
libNameGet 0 286 1131
assign 1 286 1132
relEmitName 1 286 1132
assign 1 286 1133
add 1 286 1133
assign 1 286 1134
new 0 286 1134
assign 1 286 1135
add 1 286 1135
assign 1 286 1136
libNameGet 0 286 1136
assign 1 286 1137
relEmitName 1 286 1137
assign 1 286 1138
add 1 286 1138
assign 1 286 1139
new 0 286 1139
assign 1 286 1140
add 1 286 1140
assign 1 286 1141
add 1 286 1141
assign 1 286 1142
new 0 286 1142
assign 1 286 1143
add 1 286 1143
assign 1 288 1146
new 0 288 1146
assign 1 288 1147
libNameGet 0 288 1147
assign 1 288 1148
relEmitName 1 288 1148
assign 1 288 1149
add 1 288 1149
assign 1 288 1150
new 0 288 1150
assign 1 288 1151
add 1 288 1151
assign 1 288 1152
libNameGet 0 288 1152
assign 1 288 1153
relEmitName 1 288 1153
assign 1 288 1154
add 1 288 1154
assign 1 288 1155
new 0 288 1155
assign 1 288 1156
add 1 288 1156
assign 1 288 1157
add 1 288 1157
assign 1 288 1158
new 0 288 1158
assign 1 288 1159
add 1 288 1159
return 1 290 1161
getCode 2 295 1166
assign 1 296 1167
toHexString 1 296 1167
assign 1 297 1168
new 0 297 1168
addValue 1 297 1169
addValue 1 298 1170
assign 1 304 1177
new 0 304 1177
assign 1 304 1178
add 1 304 1178
assign 1 304 1179
add 1 304 1179
return 1 304 1180
assign 1 308 1184
new 0 308 1184
return 1 308 1185
assign 1 312 1189
new 0 312 1189
return 1 312 1190
assign 1 317 1194
new 0 317 1194
return 1 317 1195
assign 1 321 1199
new 0 321 1199
return 1 321 1200
assign 1 325 1204
new 0 325 1204
return 1 325 1205
assign 1 329 1210
new 0 329 1210
assign 1 329 1211
add 1 329 1211
return 1 329 1212
assign 1 336 1228
assign 1 337 1229
singleCCGet 0 337 1229
assign 1 0 1231
assign 1 337 1234
classPathGet 0 337 1234
assign 1 337 1235
fileGet 0 337 1235
assign 1 337 1236
existsGet 0 337 1236
assign 1 337 1237
not 0 337 1242
assign 1 0 1243
assign 1 0 1246
return 1 338 1250
assign 1 340 1253
classPathGet 0 340 1253
assign 1 340 1254
fileGet 0 340 1254
assign 1 340 1255
lastUpdatedGet 0 340 1255
assign 1 341 1256
fromFileGet 0 341 1256
assign 1 341 1257
fileGet 0 341 1257
assign 1 341 1258
lastUpdatedGet 0 341 1258
assign 1 342 1259
greater 1 342 1259
return 1 345 1261
assign 1 348 1263
assign 1 353 1271
singleCCGet 0 353 1271
assign 1 354 1273
getLibOutput 0 354 1273
return 1 354 1274
assign 1 356 1276
getClassOutput 0 356 1276
return 1 356 1277
assign 1 360 1283
singleCCGet 0 360 1283
assign 1 361 1285
new 0 361 1285
assign 1 362 1286
countLines 1 362 1286
addValue 1 362 1287
write 1 363 1288
assign 1 368 1299
singleCCGet 0 368 1299
assign 1 370 1301
new 0 370 1301
assign 1 371 1302
countLines 1 371 1302
addValue 1 371 1303
write 1 372 1304
close 0 373 1305
assign 1 374 1306
def 1 374 1311
assign 1 375 1312
pathGet 0 375 1312
assign 1 375 1313
fileGet 0 375 1313
lastUpdatedSet 1 375 1314
assign 1 376 1315
assign 1 382 1338
new 0 382 1338
assign 1 383 1339
emitChecksGet 0 383 1339
assign 1 383 1340
new 0 383 1340
assign 1 383 1341
has 1 383 1341
assign 1 384 1343
new 0 384 1343
assign 1 384 1344
addValue 1 384 1344
assign 1 384 1345
addValue 1 384 1345
assign 1 384 1346
new 0 384 1346
assign 1 384 1347
addValue 1 384 1347
assign 1 384 1348
addValue 1 384 1348
assign 1 384 1349
new 0 384 1349
assign 1 384 1350
addValue 1 384 1350
addValue 1 384 1351
assign 1 385 1352
addValue 1 385 1352
assign 1 385 1353
new 0 385 1353
assign 1 385 1354
addValue 1 385 1354
addValue 1 385 1355
assign 1 386 1356
new 0 386 1356
assign 1 386 1357
addValue 1 386 1357
addValue 1 386 1358
return 1 388 1360
assign 1 392 1454
new 0 392 1454
assign 1 392 1455
typeEmitNameGet 0 392 1455
assign 1 392 1456
add 1 392 1456
assign 1 392 1457
new 0 392 1457
assign 1 392 1458
add 1 392 1458
write 1 392 1459
assign 1 393 1460
new 0 393 1460
assign 1 394 1461
new 0 394 1461
assign 1 394 1462
addValue 1 394 1462
assign 1 394 1463
typeEmitNameGet 0 394 1463
assign 1 394 1464
addValue 1 394 1464
assign 1 394 1465
new 0 394 1465
addValue 1 394 1466
assign 1 395 1467
new 0 395 1467
addValue 1 395 1468
assign 1 396 1469
typeEmitNameGet 0 396 1469
assign 1 396 1470
addValue 1 396 1470
assign 1 396 1471
new 0 396 1471
addValue 1 396 1472
assign 1 397 1473
new 0 397 1473
addValue 1 397 1474
assign 1 398 1475
new 0 398 1475
addValue 1 398 1476
assign 1 399 1477
new 0 399 1477
addValue 1 399 1478
assign 1 400 1479
new 0 400 1479
addValue 1 400 1480
write 1 401 1481
assign 1 403 1482
new 0 403 1482
assign 1 404 1483
typeEmitNameGet 0 404 1483
assign 1 404 1484
addValue 1 404 1484
assign 1 404 1485
new 0 404 1485
assign 1 404 1486
addValue 1 404 1486
assign 1 404 1487
typeEmitNameGet 0 404 1487
assign 1 404 1488
addValue 1 404 1488
assign 1 404 1489
new 0 404 1489
addValue 1 404 1490
assign 1 405 1491
new 0 405 1491
addValue 1 405 1492
assign 1 406 1493
emitChecksGet 0 406 1493
assign 1 406 1494
new 0 406 1494
assign 1 406 1495
has 1 406 1495
assign 1 407 1497
new 0 407 1497
assign 1 408 1498
mtdListGet 0 408 1498
assign 1 408 1499
iteratorGet 0 0 1499
assign 1 408 1502
hasNextGet 0 408 1502
assign 1 408 1504
nextGet 0 408 1504
assign 1 410 1506
new 0 410 1506
assign 1 412 1509
new 0 412 1509
addValue 1 412 1510
assign 1 414 1512
addValue 1 414 1512
assign 1 414 1513
nameGet 0 414 1513
assign 1 414 1514
addValue 1 414 1514
addValue 1 414 1515
assign 1 417 1522
new 0 417 1522
addValue 1 417 1523
assign 1 419 1524
emitChecksGet 0 419 1524
assign 1 419 1525
new 0 419 1525
assign 1 419 1526
has 1 419 1526
assign 1 420 1528
new 0 420 1528
addValue 1 420 1529
assign 1 423 1531
new 0 423 1531
addValue 1 423 1532
assign 1 424 1533
emitChecksGet 0 424 1533
assign 1 424 1534
new 0 424 1534
assign 1 424 1535
has 1 424 1535
assign 1 425 1537
new 0 425 1537
assign 1 426 1538
ptyListGet 0 426 1538
assign 1 426 1539
iteratorGet 0 0 1539
assign 1 426 1542
hasNextGet 0 426 1542
assign 1 426 1544
nextGet 0 426 1544
assign 1 427 1545
isSlotGet 0 427 1545
assign 1 429 1548
new 0 429 1548
assign 1 431 1551
new 0 431 1551
addValue 1 431 1552
assign 1 433 1554
addValue 1 433 1554
assign 1 433 1555
nameGet 0 433 1555
assign 1 433 1556
addValue 1 433 1556
addValue 1 433 1557
assign 1 437 1565
new 0 437 1565
addValue 1 437 1566
assign 1 439 1567
new 0 439 1567
addValue 1 439 1568
assign 1 441 1569
new 0 441 1569
assign 1 441 1570
addValue 1 441 1570
assign 1 441 1571
typeEmitNameGet 0 441 1571
assign 1 441 1572
addValue 1 441 1572
assign 1 441 1573
new 0 441 1573
addValue 1 441 1574
assign 1 442 1575
emitNameGet 0 442 1575
assign 1 442 1576
new 0 442 1576
assign 1 442 1577
equals 1 442 1577
assign 1 443 1579
new 0 443 1579
assign 1 443 1580
addValue 1 443 1580
assign 1 443 1581
emitNameGet 0 443 1581
assign 1 443 1582
addValue 1 443 1582
assign 1 443 1583
new 0 443 1583
addValue 1 443 1584
assign 1 445 1587
new 0 445 1587
assign 1 445 1588
addValue 1 445 1588
assign 1 445 1589
emitNameGet 0 445 1589
assign 1 445 1590
addValue 1 445 1590
assign 1 445 1591
new 0 445 1591
addValue 1 445 1592
assign 1 447 1594
new 0 447 1594
addValue 1 447 1595
assign 1 449 1596
new 0 449 1596
assign 1 449 1597
addValue 1 449 1597
assign 1 449 1598
typeEmitNameGet 0 449 1598
assign 1 449 1599
addValue 1 449 1599
assign 1 449 1600
new 0 449 1600
addValue 1 449 1601
assign 1 450 1602
new 0 450 1602
addValue 1 450 1603
assign 1 451 1604
new 0 451 1604
assign 1 451 1605
genMark 1 451 1605
addValue 1 451 1606
assign 1 452 1607
new 0 452 1607
addValue 1 452 1608
assign 1 455 1609
getClassOutput 0 455 1609
write 1 455 1610
assign 1 456 1611
countLines 1 456 1611
addValue 1 456 1612
assign 1 468 1684
undef 1 468 1689
assign 1 469 1690
libNameGet 0 469 1690
assign 1 470 1691
new 0 470 1691
assign 1 470 1692
sizeGet 0 470 1692
assign 1 470 1693
add 1 470 1693
assign 1 470 1694
new 0 470 1694
assign 1 470 1695
add 1 470 1695
assign 1 470 1696
add 1 470 1696
assign 1 470 1697
add 1 470 1697
assign 1 471 1698
new 0 471 1698
assign 1 471 1699
sizeGet 0 471 1699
assign 1 471 1700
add 1 471 1700
assign 1 471 1701
new 0 471 1701
assign 1 471 1702
add 1 471 1702
assign 1 471 1703
add 1 471 1703
assign 1 471 1704
add 1 471 1704
assign 1 472 1705
parentGet 0 472 1705
assign 1 472 1706
addStep 1 472 1706
assign 1 473 1707
parentGet 0 473 1707
assign 1 473 1708
addStep 1 473 1708
assign 1 474 1709
parentGet 0 474 1709
assign 1 474 1710
fileGet 0 474 1710
assign 1 474 1711
existsGet 0 474 1711
assign 1 474 1712
not 0 474 1717
assign 1 475 1718
parentGet 0 475 1718
assign 1 475 1719
fileGet 0 475 1719
makeDirs 0 475 1720
assign 1 477 1722
fileGet 0 477 1722
assign 1 477 1723
writerGet 0 477 1723
assign 1 477 1724
open 0 477 1724
assign 1 478 1725
fileGet 0 478 1725
assign 1 478 1726
writerGet 0 478 1726
assign 1 478 1727
open 0 478 1727
assign 1 480 1728
paramsGet 0 480 1728
assign 1 480 1729
new 0 480 1729
assign 1 480 1730
has 1 480 1730
assign 1 482 1732
paramsGet 0 482 1732
assign 1 482 1733
new 0 482 1733
assign 1 482 1734
get 1 482 1734
assign 1 482 1735
iteratorGet 0 0 1735
assign 1 482 1738
hasNextGet 0 482 1738
assign 1 482 1740
nextGet 0 482 1740
assign 1 484 1741
apNew 1 484 1741
assign 1 484 1742
fileGet 0 484 1742
assign 1 485 1743
readerGet 0 485 1743
assign 1 485 1744
open 0 485 1744
assign 1 485 1745
readString 0 485 1745
assign 1 486 1746
readerGet 0 486 1746
close 0 486 1747
write 1 488 1748
assign 1 492 1755
new 0 492 1755
write 1 492 1756
assign 1 495 1757
new 0 495 1757
write 1 495 1758
assign 1 496 1759
new 0 496 1759
write 1 496 1760
assign 1 502 1761
paramsGet 0 502 1761
assign 1 502 1762
new 0 502 1762
assign 1 502 1763
has 1 502 1763
assign 1 504 1765
paramsGet 0 504 1765
assign 1 504 1766
new 0 504 1766
assign 1 504 1767
get 1 504 1767
assign 1 504 1768
iteratorGet 0 0 1768
assign 1 504 1771
hasNextGet 0 504 1771
assign 1 504 1773
nextGet 0 504 1773
assign 1 506 1774
apNew 1 506 1774
assign 1 506 1775
fileGet 0 506 1775
assign 1 507 1776
readerGet 0 507 1776
assign 1 507 1777
open 0 507 1777
assign 1 507 1778
readString 0 507 1778
assign 1 508 1779
readerGet 0 508 1779
close 0 508 1780
write 1 510 1781
assign 1 513 1788
paramsGet 0 513 1788
assign 1 513 1789
new 0 513 1789
assign 1 513 1790
has 1 513 1790
assign 1 515 1792
paramsGet 0 515 1792
assign 1 515 1793
new 0 515 1793
assign 1 515 1794
get 1 515 1794
assign 1 515 1795
iteratorGet 0 0 1795
assign 1 515 1798
hasNextGet 0 515 1798
assign 1 515 1800
nextGet 0 515 1800
assign 1 517 1801
apNew 1 517 1801
assign 1 517 1802
fileGet 0 517 1802
assign 1 518 1803
readerGet 0 518 1803
assign 1 518 1804
open 0 518 1804
assign 1 518 1805
readString 0 518 1805
assign 1 519 1806
readerGet 0 519 1806
close 0 519 1807
write 1 521 1808
begin 1 528 1819
prepHeaderOutput 0 529 1820
assign 1 534 1863
undef 1 534 1868
assign 1 535 1869
new 0 535 1869
assign 1 536 1870
parentGet 0 536 1870
assign 1 536 1871
fileGet 0 536 1871
assign 1 536 1872
existsGet 0 536 1872
assign 1 536 1873
not 0 536 1878
assign 1 537 1879
parentGet 0 537 1879
assign 1 537 1880
fileGet 0 537 1880
makeDirs 0 537 1881
assign 1 539 1883
fileGet 0 539 1883
assign 1 539 1884
writerGet 0 539 1884
assign 1 539 1885
open 0 539 1885
assign 1 541 1886
new 0 541 1886
write 1 541 1887
assign 1 543 1888
paramsGet 0 543 1888
assign 1 543 1889
new 0 543 1889
assign 1 543 1890
has 1 543 1890
assign 1 545 1892
paramsGet 0 545 1892
assign 1 545 1893
new 0 545 1893
assign 1 545 1894
get 1 545 1894
assign 1 545 1895
iteratorGet 0 0 1895
assign 1 545 1898
hasNextGet 0 545 1898
assign 1 545 1900
nextGet 0 545 1900
assign 1 547 1901
apNew 1 547 1901
assign 1 547 1902
fileGet 0 547 1902
assign 1 548 1903
readerGet 0 548 1903
assign 1 548 1904
open 0 548 1904
assign 1 548 1905
readString 0 548 1905
assign 1 549 1906
readerGet 0 549 1906
close 0 549 1907
write 1 551 1908
assign 1 555 1915
new 0 555 1915
write 1 555 1916
increment 0 556 1917
assign 1 557 1918
paramsGet 0 557 1918
assign 1 557 1919
new 0 557 1919
assign 1 557 1920
has 1 557 1920
assign 1 558 1922
paramsGet 0 558 1922
assign 1 558 1923
new 0 558 1923
assign 1 558 1924
get 1 558 1924
assign 1 558 1925
iteratorGet 0 0 1925
assign 1 558 1928
hasNextGet 0 558 1928
assign 1 558 1930
nextGet 0 558 1930
assign 1 559 1931
apNew 1 559 1931
assign 1 559 1932
fileGet 0 559 1932
assign 1 560 1933
readerGet 0 560 1933
assign 1 560 1934
open 0 560 1934
assign 1 560 1935
readString 0 560 1935
assign 1 561 1936
readerGet 0 561 1936
close 0 561 1937
assign 1 562 1938
countLines 1 562 1938
addValue 1 562 1939
write 1 563 1940
return 1 569 1948
close 0 574 1959
assign 1 575 1960
assign 1 577 1961
new 0 577 1961
write 1 577 1962
assign 1 579 1963
new 0 579 1963
write 1 579 1964
assign 1 581 1965
emitChecksGet 0 581 1965
assign 1 581 1966
new 0 581 1966
assign 1 581 1967
has 1 581 1967
assign 1 582 1969
new 0 582 1969
assign 1 583 1970
new 0 583 1970
assign 1 583 1971
addValue 1 583 1971
addValue 1 583 1972
write 1 584 1973
close 0 587 1975
close 0 588 1976
assign 1 593 1981
new 0 593 1981
return 1 593 1982
assign 1 597 1986
new 0 597 1986
addValue 1 597 1987
assign 1 601 1992
new 0 601 1992
addValue 1 601 1993
assign 1 605 2004
emitChecksGet 0 605 2004
assign 1 605 2005
new 0 605 2005
assign 1 605 2006
has 1 605 2006
assign 1 606 2008
new 0 606 2008
assign 1 606 2009
addValue 1 606 2009
assign 1 606 2010
addValue 1 606 2010
assign 1 606 2011
new 0 606 2011
addValue 1 606 2012
assign 1 612 2036
heldGet 0 612 2036
assign 1 612 2037
synGet 0 612 2037
assign 1 613 2038
ptyListGet 0 613 2038
assign 1 615 2039
emitNameGet 0 615 2039
assign 1 615 2040
addValue 1 615 2040
assign 1 615 2041
new 0 615 2041
addValue 1 615 2042
assign 1 617 2043
new 0 617 2043
assign 1 618 2044
iteratorGet 0 0 2044
assign 1 618 2047
hasNextGet 0 618 2047
assign 1 618 2049
nextGet 0 618 2049
assign 1 619 2050
isSlotGet 0 619 2050
assign 1 621 2053
new 0 621 2053
assign 1 623 2056
new 0 623 2056
addValue 1 623 2057
assign 1 625 2059
addValue 1 625 2059
assign 1 625 2060
new 0 625 2060
assign 1 625 2061
addValue 1 625 2061
assign 1 625 2062
nameGet 0 625 2062
assign 1 625 2063
addValue 1 625 2063
addValue 1 625 2064
assign 1 630 2071
new 0 630 2071
assign 1 630 2072
addValue 1 630 2072
addValue 1 630 2073
assign 1 635 2093
new 0 635 2093
assign 1 637 2094
new 0 637 2094
assign 1 637 2095
emitNameGet 0 637 2095
assign 1 637 2096
add 1 637 2096
assign 1 637 2097
new 0 637 2097
assign 1 637 2098
add 1 637 2098
assign 1 639 2099
emitNameGet 0 639 2099
assign 1 639 2100
addValue 1 639 2100
assign 1 639 2101
new 0 639 2101
assign 1 639 2102
addValue 1 639 2102
assign 1 639 2103
emitNameGet 0 639 2103
assign 1 639 2104
addValue 1 639 2104
assign 1 639 2105
new 0 639 2105
assign 1 639 2106
addValue 1 639 2106
assign 1 639 2107
addValue 1 639 2107
assign 1 639 2108
new 0 639 2108
addValue 1 639 2109
return 1 641 2110
assign 1 645 2119
libNameGet 0 645 2119
assign 1 645 2120
relEmitName 1 645 2120
assign 1 646 2121
new 0 646 2121
assign 1 646 2122
add 1 646 2122
assign 1 646 2123
new 0 646 2123
assign 1 646 2124
add 1 646 2124
return 1 647 2125
assign 1 651 2137
libNameGet 0 651 2137
assign 1 651 2138
relEmitName 1 651 2138
assign 1 652 2139
new 0 652 2139
assign 1 652 2140
add 1 652 2140
assign 1 652 2141
new 0 652 2141
assign 1 652 2142
add 1 652 2142
assign 1 653 2143
new 0 653 2143
assign 1 653 2144
add 1 653 2144
assign 1 653 2145
add 1 653 2145
return 1 653 2146
assign 1 657 2151
new 0 657 2151
assign 1 657 2152
add 1 657 2152
return 1 657 2153
assign 1 661 2261
getClassConfig 1 661 2261
assign 1 661 2262
libNameGet 0 661 2262
assign 1 661 2263
relEmitName 1 661 2263
assign 1 662 2264
heldGet 0 662 2264
assign 1 662 2265
namepathGet 0 662 2265
assign 1 662 2266
getClassConfig 1 662 2266
assign 1 663 2267
getInitialInst 1 663 2267
assign 1 665 2268
overrideMtdDecGet 0 665 2268
assign 1 665 2269
addValue 1 665 2269
assign 1 665 2270
new 0 665 2270
assign 1 665 2271
addValue 1 665 2271
assign 1 665 2272
emitNameGet 0 665 2272
assign 1 665 2273
addValue 1 665 2273
assign 1 665 2274
new 0 665 2274
assign 1 665 2275
addValue 1 665 2275
assign 1 665 2276
addValue 1 665 2276
assign 1 665 2277
new 0 665 2277
assign 1 665 2278
addValue 1 665 2278
assign 1 665 2279
addValue 1 665 2279
assign 1 665 2280
new 0 665 2280
assign 1 665 2281
addValue 1 665 2281
addValue 1 665 2282
assign 1 666 2283
new 0 666 2283
assign 1 667 2284
emitNameGet 0 667 2284
assign 1 667 2285
notEquals 1 667 2285
assign 1 668 2287
new 0 668 2287
assign 1 668 2288
formCast 3 668 2288
assign 1 671 2290
addValue 1 671 2290
assign 1 671 2291
new 0 671 2291
assign 1 671 2292
addValue 1 671 2292
assign 1 671 2293
addValue 1 671 2293
assign 1 671 2294
new 0 671 2294
assign 1 671 2295
addValue 1 671 2295
addValue 1 671 2296
assign 1 673 2297
new 0 673 2297
assign 1 673 2298
addValue 1 673 2298
addValue 1 673 2299
assign 1 676 2300
overrideMtdDecGet 0 676 2300
assign 1 676 2301
addValue 1 676 2301
assign 1 676 2302
addValue 1 676 2302
assign 1 676 2303
new 0 676 2303
assign 1 676 2304
addValue 1 676 2304
assign 1 676 2305
emitNameGet 0 676 2305
assign 1 676 2306
addValue 1 676 2306
assign 1 676 2307
new 0 676 2307
assign 1 676 2308
addValue 1 676 2308
assign 1 676 2309
addValue 1 676 2309
assign 1 676 2310
new 0 676 2310
assign 1 676 2311
addValue 1 676 2311
addValue 1 676 2312
assign 1 681 2313
new 0 681 2313
assign 1 681 2314
addValue 1 681 2314
assign 1 681 2315
addValue 1 681 2315
assign 1 681 2316
new 0 681 2316
assign 1 681 2317
addValue 1 681 2317
addValue 1 681 2318
assign 1 684 2319
new 0 684 2319
assign 1 684 2320
addValue 1 684 2320
addValue 1 684 2321
assign 1 686 2322
overrideMtdDecGet 0 686 2322
assign 1 686 2323
addValue 1 686 2323
assign 1 686 2324
new 0 686 2324
assign 1 686 2325
addValue 1 686 2325
assign 1 686 2326
emitNameGet 0 686 2326
assign 1 686 2327
addValue 1 686 2327
assign 1 686 2328
new 0 686 2328
assign 1 686 2329
addValue 1 686 2329
assign 1 686 2330
addValue 1 686 2330
assign 1 686 2331
new 0 686 2331
assign 1 686 2332
addValue 1 686 2332
addValue 1 686 2333
assign 1 687 2334
heldGet 0 687 2334
assign 1 687 2335
extendsGet 0 687 2335
assign 1 687 2336
undef 1 687 2341
assign 1 0 2342
assign 1 687 2345
heldGet 0 687 2345
assign 1 687 2346
extendsGet 0 687 2346
assign 1 687 2347
equals 1 687 2347
assign 1 0 2349
assign 1 0 2352
assign 1 688 2356
new 0 688 2356
assign 1 688 2357
addValue 1 688 2357
addValue 1 688 2358
assign 1 690 2361
new 0 690 2361
assign 1 690 2362
addValue 1 690 2362
addValue 1 690 2363
addValue 1 692 2365
clear 0 693 2366
assign 1 696 2367
new 0 696 2367
assign 1 696 2368
addValue 1 696 2368
addValue 1 696 2369
assign 1 698 2370
overrideMtdDecGet 0 698 2370
assign 1 698 2371
addValue 1 698 2371
assign 1 698 2372
new 0 698 2372
assign 1 698 2373
addValue 1 698 2373
assign 1 698 2374
emitNameGet 0 698 2374
assign 1 698 2375
addValue 1 698 2375
assign 1 698 2376
new 0 698 2376
assign 1 698 2377
addValue 1 698 2377
assign 1 698 2378
addValue 1 698 2378
assign 1 698 2379
new 0 698 2379
assign 1 698 2380
addValue 1 698 2380
addValue 1 698 2381
assign 1 699 2382
new 0 699 2382
assign 1 699 2383
addValue 1 699 2383
addValue 1 699 2384
assign 1 701 2385
new 0 701 2385
assign 1 701 2386
addValue 1 701 2386
addValue 1 701 2387
assign 1 703 2388
getTypeInst 1 703 2388
assign 1 705 2389
new 0 705 2389
assign 1 705 2390
addValue 1 705 2390
assign 1 705 2391
emitNameGet 0 705 2391
assign 1 705 2392
addValue 1 705 2392
assign 1 705 2393
new 0 705 2393
assign 1 705 2394
addValue 1 705 2394
addValue 1 705 2395
assign 1 707 2396
new 0 707 2396
assign 1 707 2397
addValue 1 707 2397
assign 1 707 2398
addValue 1 707 2398
assign 1 707 2399
new 0 707 2399
assign 1 707 2400
addValue 1 707 2400
addValue 1 707 2401
assign 1 709 2402
new 0 709 2402
assign 1 709 2403
addValue 1 709 2403
addValue 1 709 2404
assign 1 715 2416
new 0 715 2416
assign 1 715 2417
add 1 715 2417
assign 1 715 2418
new 0 715 2418
assign 1 715 2419
add 1 715 2419
write 1 715 2420
assign 1 716 2421
new 0 716 2421
assign 1 716 2422
add 1 716 2422
assign 1 716 2423
new 0 716 2423
assign 1 716 2424
add 1 716 2424
write 1 716 2425
emitLib 0 718 2426
assign 1 723 2439
libNameGet 0 723 2439
assign 1 723 2440
relEmitName 1 723 2440
assign 1 724 2441
new 0 724 2441
assign 1 724 2442
add 1 724 2442
assign 1 724 2443
new 0 724 2443
assign 1 724 2444
add 1 724 2444
assign 1 725 2445
new 0 725 2445
assign 1 725 2446
add 1 725 2446
assign 1 725 2447
add 1 725 2447
return 1 725 2448
return 1 0 2451
assign 1 0 2454
return 1 0 2458
assign 1 0 2461
return 1 0 2465
assign 1 0 2468
return 1 0 2472
assign 1 0 2475
return 1 0 2479
assign 1 0 2482
return 1 0 2486
assign 1 0 2489
return 1 0 2493
assign 1 0 2496
return 1 0 2500
assign 1 0 2503
return 1 0 2507
assign 1 0 2510
return 1 0 2514
assign 1 0 2517
return 1 0 2521
assign 1 0 2524
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -302982768: return bem_nlGet_0();
case 92773956: return bem_superNameGet_0();
case -1704987411: return bem_hashGet_0();
case -1720881372: return bem_maxDynArgsGet_0();
case -660151547: return bem_methodBodyGet_0();
case 1293615860: return bem_smnlecsGet_0();
case 1451868756: return bem_mainOutsideNsGet_0();
case -2098439667: return bem_runtimeInitGet_0();
case 524044254: return bem_callNamesGet_0();
case -1479480078: return bem_nameToIdPathGet_0();
case -1278316438: return bem_spropDecGet_0();
case -720547562: return bem_scvpGet_0();
case -1162089212: return bem_boolCcGet_0();
case -1195131702: return bem_lineCountGet_0();
case 831594389: return bem_mnodeGet_0();
case -1761353942: return bem_constGet_0();
case 1866804777: return bem_methodsGet_0();
case 1745521128: return bem_floatNpGet_0();
case 121407827: return bem_ntypesGet_0();
case 1560974427: return bem_deowGet_0();
case -1710439973: return bem_iteratorGet_0();
case -1991911556: return bem_stringNpGet_0();
case -1478080290: return bem_lastCallGet_0();
case -701224863: return bem_dynMethodsGet_0();
case -777522768: return bem_methodCallsGet_0();
case -1644627054: return bem_maxSpillArgsLenGet_0();
case 1117478340: return bem_buildGet_0();
case -1395089610: return bem_libEmitPathGet_0();
case -1337586448: return bem_buildInitial_0();
case -1914138546: return bem_getClassOutput_0();
case 216540396: return bem_invpGet_0();
case -319745223: return bem_exceptDecGet_0();
case 1269592162: return bem_instanceNotEqualGet_0();
case 298864882: return bem_instOfGet_0();
case 245099747: return bem_loadIds_0();
case -1873048571: return bem_boolTypeGet_0();
case -1788243316: return bem_falseValueGet_0();
case 963511110: return bem_nameToIdGet_0();
case -1728180498: return bem_transGet_0();
case -1724019842: return bem_inFilePathedGet_0();
case -780442249: return bem_saveSyns_0();
case -1000494527: return bem_buildClassInfo_0();
case 420645631: return bem_baseMtdDecGet_0();
case -234951554: return bem_headExtGet_0();
case -527198678: return bem_lastMethodsSizeGet_0();
case 1200797913: return bem_onceDecsGet_0();
case -216825810: return bem_inClassGet_0();
case 887316059: return bem_prepHeaderOutput_0();
case 319975707: return bem_propDecGet_0();
case -1799675450: return bem_setOutputTimeGet_0();
case 220675497: return bem_propertyDecsGet_0();
case -1366046690: return bem_superCallsGet_0();
case -1891228509: return bem_beginNs_0();
case 1862195184: return bem_synEmitPathGet_0();
case 714334344: return bem_afterCast_0();
case 2115571700: return bem_classEmitsGet_0();
case 1140092790: return bem_methodCatchGet_0();
case -450561525: return bem_lastMethodBodySizeGet_0();
case -1462902468: return bem_randGet_0();
case 2032003305: return bem_returnTypeGet_0();
case 24504508: return bem_preClassOutput_0();
case 1544451686: return bem_instanceEqualGet_0();
case -424641606: return bem_newDecGet_0();
case 2004002170: return bem_covariantReturnsGet_0();
case -1361397004: return bem_classEndGet_0();
case -411905360: return bem_endNs_0();
case 1155285063: return bem_fileExtGet_0();
case -1307813513: return bem_qGet_0();
case 1830684648: return bem_lastMethodsLinesGet_0();
case -1146721903: return bem_doEmit_0();
case 636877634: return bem_preClassGet_0();
case -689113549: return bem_heonGet_0();
case 2026069842: return bem_heopGet_0();
case -874403637: return bem_new_0();
case 1745430237: return bem_heowGet_0();
case -1555826243: return bem_objectNpGet_0();
case -755862175: return bem_lastMethodBodyLinesGet_0();
case 1000676385: return bem_classCallsGet_0();
case -502054206: return bem_shlibeGet_0();
case 1790245935: return bem_toString_0();
case 1998081160: return bem_deonGet_0();
case -205277899: return bem_mainEndGet_0();
case 522336547: return bem_emitLib_0();
case 1044160434: return bem_mainInClassGet_0();
case -682430558: return bem_fullLibEmitNameGet_0();
case 1645935183: return bem_gcMarksGet_0();
case -1585427589: return bem_cnodeGet_0();
case -1752793885: return bem_getLibOutput_0();
case -1068874537: return bem_baseSmtdDecGet_0();
case -447981689: return bem_emitLangGet_0();
case 1222565418: return bem_deopGet_0();
case -988015540: return bem_smnlcsGet_0();
case -1059342092: return bem_ccCacheGet_0();
case 1099871277: return bem_idToNamePathGet_0();
case 1421794063: return bem_copy_0();
case 1950233710: return bem_classHeadersGet_0();
case 274429422: return bem_writeBET_0();
case -421897039: return bem_print_0();
case -837665832: return bem_idToNameGet_0();
case 952727112: return bem_objectCcGet_0();
case 1331362760: return bem_parentConfGet_0();
case 333682466: return bem_overrideMtdDecGet_0();
case -783508214: return bem_nativeCSlotsGet_0();
case 837697751: return bem_trueValueGet_0();
case 50068568: return bem_nullValueGet_0();
case 1167287990: return bem_classesInDepthOrderGet_0();
case 1913908680: return bem_typeDecGet_0();
case -413181506: return bem_buildCreate_0();
case 1265763366: return bem_classConfGet_0();
case -1553623881: return bem_mainStartGet_0();
case -315696734: return bem_belslitsGet_0();
case 1784006951: return bem_boolNpGet_0();
case -1820578382: return bem_initialDecGet_0();
case 31547702: return bem_useDynMethodsGet_0();
case 1472625823: return bem_buildPropList_0();
case 1973253922: return bem_classHeadBodyGet_0();
case 133490875: return bem_saveIds_0();
case 637337824: return bem_ccMethodsGet_0();
case 1268523348: return bem_msynGet_0();
case 699657320: return bem_create_0();
case -1991023590: return bem_intNpGet_0();
case -1076078862: return bem_libEmitNameGet_0();
case 1719266164: return bem_csynGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1316765790: return bem_cnodeSet_1(bevd_0);
case -2042183379: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -70704656: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 60147779: return bem_instOfSet_1(bevd_0);
case -1068888371: return bem_deowSet_1(bevd_0);
case 1389161244: return bem_notEquals_1(bevd_0);
case -2032071589: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1074224074: return bem_end_1(bevd_0);
case 520455679: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1236689084: return bem_setOutputTimeSet_1(bevd_0);
case -1333905788: return bem_classConfSet_1(bevd_0);
case 1662269100: return bem_synEmitPathSet_1(bevd_0);
case 304175281: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 231363066: return bem_classHeadBodySet_1(bevd_0);
case 1872964804: return bem_stringNpSet_1(bevd_0);
case 1117764836: return bem_idToNamePathSet_1(bevd_0);
case 481735216: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1786635: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 164232828: return bem_emitLangSet_1(bevd_0);
case -329661031: return bem_deonSet_1(bevd_0);
case -1790568879: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -976526484: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1733221391: return bem_heopSet_1(bevd_0);
case -1364302582: return bem_nameToIdPathSet_1(bevd_0);
case -691765019: return bem_libEmitNameSet_1(bevd_0);
case 310405801: return bem_classEmitsSet_1(bevd_0);
case 1006136564: return bem_ccMethodsSet_1(bevd_0);
case 1719345673: return bem_fileExtSet_1(bevd_0);
case 1356061796: return bem_trueValueSet_1(bevd_0);
case -112934060: return bem_copyTo_1(bevd_0);
case -773813186: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -880618346: return bem_csynSet_1(bevd_0);
case 1061005121: return bem_ntypesSet_1(bevd_0);
case 1793248562: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1122270149: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1542693116: return bem_superCallsSet_1(bevd_0);
case 239220207: return bem_headExtSet_1(bevd_0);
case -1440216044: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1933546821: return bem_undef_1(bevd_0);
case -1264848386: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 86533341: return bem_objectNpSet_1(bevd_0);
case 639317673: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1221940830: return bem_lineCountSet_1(bevd_0);
case 1067585063: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1724375880: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1255673: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -54765596: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1532838381: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 446542271: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -226355275: return bem_idToNameSet_1(bevd_0);
case 505934715: return bem_heowSet_1(bevd_0);
case -1858312128: return bem_ccCacheSet_1(bevd_0);
case 1653472330: return bem_qSet_1(bevd_0);
case -2070881982: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 411032543: return bem_mnodeSet_1(bevd_0);
case -236893407: return bem_onceDecsSet_1(bevd_0);
case -224688064: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1891924354: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 859387312: return bem_lastMethodsSizeSet_1(bevd_0);
case 1755260023: return bem_boolCcSet_1(bevd_0);
case 1231585864: return bem_smnlcsSet_1(bevd_0);
case 633991611: return bem_msynSet_1(bevd_0);
case -95858744: return bem_heonSet_1(bevd_0);
case 2075065958: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1074442451: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -602485573: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1938268474: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -387518266: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 486145254: return bem_buildSet_1(bevd_0);
case 1722296712: return bem_callNamesSet_1(bevd_0);
case -1860106531: return bem_inFilePathedSet_1(bevd_0);
case 35985339: return bem_intNpSet_1(bevd_0);
case -27308864: return bem_parentConfSet_1(bevd_0);
case 2129063294: return bem_lastCallSet_1(bevd_0);
case -123626097: return bem_libEmitPathSet_1(bevd_0);
case 35538763: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -1705697515: return bem_nativeCSlotsSet_1(bevd_0);
case 1624274637: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1031434664: return bem_belslitsSet_1(bevd_0);
case 1158012230: return bem_methodCallsSet_1(bevd_0);
case 1848178579: return bem_randSet_1(bevd_0);
case 1969893744: return bem_nullValueSet_1(bevd_0);
case -1152358524: return bem_objectCcSet_1(bevd_0);
case 1891017278: return bem_falseValueSet_1(bevd_0);
case -951961192: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -203203157: return bem_def_1(bevd_0);
case -914265453: return bem_gcMarksSet_1(bevd_0);
case 1648199694: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1061804801: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1708833213: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 292631893: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1367103451: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -71094166: return bem_fullLibEmitNameSet_1(bevd_0);
case 1706186593: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1480060668: return bem_floatNpSet_1(bevd_0);
case 235124630: return bem_instanceEqualSet_1(bevd_0);
case 1618516147: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -655782708: return bem_instanceNotEqualSet_1(bevd_0);
case -467708250: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 439538293: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 549413203: return bem_smnlecsSet_1(bevd_0);
case -1492822422: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1472194439: return bem_decNameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -788339973: return bem_methodCatchSet_1(bevd_0);
case -298262294: return bem_methodBodySet_1(bevd_0);
case 603466887: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1340652639: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1111555675: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1412567009: return bem_deopSet_1(bevd_0);
case -1575351677: return bem_classHeadersSet_1(bevd_0);
case 126990833: return bem_lastMethodsLinesSet_1(bevd_0);
case -1715911610: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case 1675868501: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2061164028: return bem_scvpSet_1(bevd_0);
case -1013541477: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1736835785: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1515109987: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 682931168: return bem_returnTypeSet_1(bevd_0);
case -371391208: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1084617555: return bem_inClassSet_1(bevd_0);
case -1948934017: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1233509200: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 132021027: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 2020876559: return bem_shlibeSet_1(bevd_0);
case 2120628659: return bem_constSet_1(bevd_0);
case 2098319284: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1393548508: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -231594504: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -757053488: return bem_boolNpSet_1(bevd_0);
case 1063069793: return bem_equals_1(bevd_0);
case 1841734083: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1391871933: return bem_maxDynArgsSet_1(bevd_0);
case -459803109: return bem_methodsSet_1(bevd_0);
case -346300607: return bem_lastMethodBodySizeSet_1(bevd_0);
case 444832001: return bem_propertyDecsSet_1(bevd_0);
case -872090227: return bem_classCallsSet_1(bevd_0);
case -1587272165: return bem_nameToIdSet_1(bevd_0);
case -257841902: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -720330989: return bem_classesInDepthOrderSet_1(bevd_0);
case -1330434608: return bem_preClassSet_1(bevd_0);
case -1448517480: return bem_begin_1(bevd_0);
case 1360646413: return bem_transSet_1(bevd_0);
case 550065522: return bem_nlSet_1(bevd_0);
case 1168773543: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 142714481: return bem_dynMethodsSet_1(bevd_0);
case -681912916: return bem_exceptDecSet_1(bevd_0);
case -1777109591: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1702631655: return bem_invpSet_1(bevd_0);
case 233103781: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -992018755: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1839649845: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1882233302: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -962422058: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1414675049: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2103088564: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2029354730: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 164622216: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -588882663: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1768559776: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310903487: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 971670791: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 352034400: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -191573592: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1016955070: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -953126097: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1693005286: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 870219202: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -821101662: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1617495106: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 769768789: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -966440848: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1495377415: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 11348815: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -766816522: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
