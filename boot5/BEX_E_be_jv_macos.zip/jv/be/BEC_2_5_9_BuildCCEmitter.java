package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_24, 18));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x3E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_26, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_32, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_33, 14));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_34, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_35, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x3E,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_61, 20));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x3E,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x66,0x72,0x6F,0x6D,0x5F,0x74,0x68,0x69,0x73,0x28,0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_62, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_66, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_70, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_71, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_78, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_81, 28));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_82, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_87, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_90, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_91, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_101, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_102, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_103, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_104, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_105, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_106, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_107, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_108, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_109, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_110, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_111, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_112, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_113, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_114, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_115, 18));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x3E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_116, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_117, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_118, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_120, 19));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_121, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_129, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_132, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_133, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_152, 22));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x3E,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x28,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x3E,0x28,0x29,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_158, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_159 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_159, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_160 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_160, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_161 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_161, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_162 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_163 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_164 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_165 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_166 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_167 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_168 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_169 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_170 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_171 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_172 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_173 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_174 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_175 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_176 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_177 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_178 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_179 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_180 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_181 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_182 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_183 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_184 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_185 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_186 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_186, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_187 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_187, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_188 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_189 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_190 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_191 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_192 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_192, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_193 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_52 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_193, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_194 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_53 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_194, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_195 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_195, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_196 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_55 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_196, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_197 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_56 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_197, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_198 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_199 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_200 = {0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_201 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_202 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_203 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_204 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_205 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_206 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_207 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_208 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_209 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_210 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_211 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_212 = {0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_213 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_214 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_215 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_216 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_217 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_218 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_219 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_220 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_221 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_222 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_223 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_224 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_224, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_225 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_225, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_226 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_59 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_226, 2));
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 43 */
 else  /* Line: 44 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 45 */
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
if (bevp_parentConf == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_tmpany_phold = bevl_begin.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 54 */
 else  /* Line: 55 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevl_begin.bem_addValue_1(bevt_20_tmpany_phold);
} /* Line: 60 */
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevl_begin.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevl_begin.bem_addValue_1(bevt_22_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevp_heow.bem_write_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevp_heow.bem_write_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_31_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevp_heow.bem_write_1(bevt_26_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(76, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(62, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_42_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_43_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_add_1(bevt_44_tmpany_phold);
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_47_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_48_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevp_deow.bem_write_1(bevt_45_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
return bevt_50_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_19_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_20_tmpany_phold);
bevt_24_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(34068194);
bevt_22_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_23_tmpany_phold );
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_17_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_27_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_6_tmpany_phold = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_0_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_16_tmpany_phold = bevp_methods.bem_addValue_1(bevt_17_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_22_tmpany_phold = bevp_classHeadBody.bem_addValue_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_24_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_19_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevp_classHeadBody.bem_addValue_1(bevt_28_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_tmpany_phold.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
} /* Line: 138 */
 else  /* Line: 137 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1871413753);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1049358928, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 139 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevl_tcall = bevt_7_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
} /* Line: 140 */
 else  /* Line: 137 */ {
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1871413753);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(1049358928, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 142 */
 else  /* Line: 143 */ {
bevt_15_tmpany_phold = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_15_tmpany_phold );
} /* Line: 144 */
} /* Line: 137 */
} /* Line: 137 */
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1871413753);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1049358928, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 150 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevl_tcall = bevt_4_tmpany_phold.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 152 */
bevt_5_tmpany_phold = super.bem_formCallTarg_1(beva_node);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_2_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-950359223);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(309499786, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 162 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-284728802);
bevp_classHeaders.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 163 */
 else  /* Line: 164 */ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 165 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevt_8_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevl_clh = bevt_4_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_11_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-565741670);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(2114928542);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_12_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_3_tmpany_phold = beva_b.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_2_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 195 */
 else  /* Line: 196 */ {
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_9_tmpany_phold = beva_b.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_12_tmpany_phold = bem_getClassConfig_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_relEmitName_1(bevt_14_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_8_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 197 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevl_ccall = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
} /* Line: 203 */
 else  /* Line: 204 */ {
bevl_ccall = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
} /* Line: 205 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_18_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevt_22_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-383830300);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-383830300);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 231 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 232 */
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_20_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(beva_lisz);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_belsName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
return bevt_12_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1871413753);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_41;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
bevp_setOutputTime = null;
bevt_1_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 290 */ {
return this;
} /* Line: 291 */
 else  /* Line: 292 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevl_outts = bevt_6_tmpany_phold.bem_lastUpdatedGet_0();
bevt_9_tmpany_phold = bevp_inClass.bem_fromFileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1674889629);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bemd_0(1277123521);
bevt_10_tmpany_phold = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 295 */ {
return this;
} /* Line: 298 */
bevp_setOutputTime = bevl_outts;
} /* Line: 301 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_1_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_1_tmpany_phold = bem_getLibOutput_0();
return bevt_1_tmpany_phold;
} /* Line: 307 */
bevt_2_tmpany_phold = super.bem_getClassOutput_0();
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 313 */ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 316 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 321 */ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_4_tmpany_phold = beva_cle.bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 329 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_42;
bevt_5_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_43;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevp_deow.bem_write_1(bevt_2_tmpany_phold);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_8_tmpany_phold = bevl_beh.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevl_beh.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_tmpany_phold = bevl_beh.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(66, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevl_beh.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevl_beh.bem_addValue_1(bevt_17_tmpany_phold);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_21_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_tmpany_phold = bevl_bet.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_18_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_26_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_26_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 348 */ {
bevt_27_tmpany_phold = bevt_0_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_27_tmpany_phold).bevi_bool) /* Line: 348 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(772185969);
if (bevl_firstmnsyn.bevi_bool) /* Line: 349 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 350 */
 else  /* Line: 351 */ {
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
} /* Line: 352 */
bevt_30_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_31_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_addValue_1(bevt_31_tmpany_phold);
bevt_29_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 354 */
 else  /* Line: 348 */ {
break;
} /* Line: 348 */
} /* Line: 348 */
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevl_bet.bem_addValue_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevl_bet.bem_addValue_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_35_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_35_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 361 */ {
bevt_36_tmpany_phold = bevt_1_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 361 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(772185969);
if (bevl_firstptsyn.bevi_bool) /* Line: 362 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 363 */
 else  /* Line: 364 */ {
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevl_bet.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 365 */
bevt_39_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_40_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_38_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 367 */
 else  /* Line: 361 */ {
break;
} /* Line: 361 */
} /* Line: 361 */
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevl_bet.bem_addValue_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_44_tmpany_phold = bevl_bet.bem_addValue_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_addValue_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_151));
bevt_43_tmpany_phold.bem_addValue_1(bevt_47_tmpany_phold);
bevt_49_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_50_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_44;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_equals_1(bevt_50_tmpany_phold);
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 374 */ {
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_153));
bevt_52_tmpany_phold = bevl_bet.bem_addValue_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_154));
bevt_51_tmpany_phold.bem_addValue_1(bevt_55_tmpany_phold);
} /* Line: 375 */
 else  /* Line: 376 */ {
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
bevt_57_tmpany_phold = bevl_bet.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
bevt_56_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
} /* Line: 377 */
bevt_61_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_157));
bevl_bet.bem_addValue_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = bem_getClassOutput_0();
bevt_62_tmpany_phold.bem_write_1(bevl_bet);
bevt_63_tmpany_phold = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_63_tmpany_phold.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_20_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_31_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
if (bevp_deow == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_45;
bevt_8_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_46;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_4_tmpany_phold.bem_add_1(bevp_headExt);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_47;
bevt_14_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_48;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_10_tmpany_phold.bem_add_1(bevp_headExt);
bevt_16_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_17_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_21_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_existsGet_0();
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 399 */ {
bevt_23_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_fileGet_0();
bevt_22_tmpany_phold.bem_makeDirs_0();
} /* Line: 400 */
bevt_25_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_tmpany_phold.bemd_0(288971190);
bevt_27_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_tmpany_phold.bemd_0(288971190);
bevt_29_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_162));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_has_1(bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_32_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_163));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_get_1(bevt_33_tmpany_phold);
bevt_0_tmpany_loop = bevt_31_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 407 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 407 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(772185969);
bevt_35_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_tmpany_phold.bem_fileGet_0();
bevt_37_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(288971190);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bemd_0(-484125849);
bevt_38_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_38_tmpany_phold.bemd_0(9597572);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 413 */
 else  /* Line: 407 */ {
break;
} /* Line: 407 */
} /* Line: 407 */
} /* Line: 407 */
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_164));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_165));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_166));
bevp_deow.bem_write_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_167));
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_168));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_has_1(bevt_45_tmpany_phold);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 427 */ {
bevt_47_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_169));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_get_1(bevt_48_tmpany_phold);
bevt_1_tmpany_loop = bevt_46_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 429 */ {
bevt_49_tmpany_phold = bevt_1_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_49_tmpany_phold).bevi_bool) /* Line: 429 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(772185969);
bevt_50_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_50_tmpany_phold.bem_fileGet_0();
bevt_52_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(288971190);
bevl_inc = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bemd_0(-484125849);
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_53_tmpany_phold.bemd_0(9597572);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 435 */
 else  /* Line: 429 */ {
break;
} /* Line: 429 */
} /* Line: 429 */
} /* Line: 429 */
bevt_55_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_170));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_has_1(bevt_56_tmpany_phold);
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 438 */ {
bevt_58_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_171));
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_get_1(bevt_59_tmpany_phold);
bevt_2_tmpany_loop = bevt_57_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 440 */ {
bevt_60_tmpany_phold = bevt_2_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 440 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(772185969);
bevt_61_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_61_tmpany_phold.bem_fileGet_0();
bevt_63_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(288971190);
bevl_inc = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bemd_0(-484125849);
bevt_64_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_64_tmpany_phold.bemd_0(9597572);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 446 */
 else  /* Line: 440 */ {
break;
} /* Line: 440 */
} /* Line: 440 */
} /* Line: 440 */
} /* Line: 438 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_27_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 459 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_existsGet_0();
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 461 */ {
bevt_8_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 462 */
bevt_10_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_tmpany_phold.bemd_0(288971190);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_172));
bevp_shlibe.bem_write_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_173));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_has_1(bevt_14_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 468 */ {
bevt_16_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_174));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_get_1(bevt_17_tmpany_phold);
bevt_0_tmpany_loop = bevt_15_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 470 */ {
bevt_18_tmpany_phold = bevt_0_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 470 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(772185969);
bevt_19_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(288971190);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bemd_0(-484125849);
bevt_22_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_22_tmpany_phold.bemd_0(9597572);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 476 */
 else  /* Line: 470 */ {
break;
} /* Line: 470 */
} /* Line: 470 */
} /* Line: 470 */
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_175));
bevp_shlibe.bem_write_1(bevt_23_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_25_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_176));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_has_1(bevt_26_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_28_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_177));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_get_1(bevt_29_tmpany_phold);
bevt_1_tmpany_loop = bevt_27_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 483 */ {
bevt_30_tmpany_phold = bevt_1_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 483 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(772185969);
bevt_31_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_tmpany_phold.bem_fileGet_0();
bevt_33_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(288971190);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bemd_0(-484125849);
bevt_34_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_34_tmpany_phold.bemd_0(9597572);
bevt_35_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 488 */
 else  /* Line: 483 */ {
break;
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 482 */
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_178));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_179));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_180));
bevt_1_tmpany_phold = beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_181));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(388569193);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_182));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 525 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(946079220);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 525 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(772185969);
if (bevl_first.bevi_bool) /* Line: 526 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 527 */
 else  /* Line: 528 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_183));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 529 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_184));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 531 */
 else  /* Line: 525 */ {
break;
} /* Line: 525 */
} /* Line: 525 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_185));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_49;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_50;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_188));
bevt_9_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_189));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_190));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_191));
bevt_4_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_51;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_52;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_53;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_54;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_55;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_56;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_0_tmpany_phold.bem_relEmitName_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(34068194);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_2_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_12_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_11_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_198));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_199));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_200));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_201));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_202));
bevt_19_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 572 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_203));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_20_tmpany_phold, bevl_asnr);
} /* Line: 573 */
bevt_24_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_204));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_205));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_206));
bevt_27_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_207));
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_208));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_209));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_210));
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_addValue_1(bevt_42_tmpany_phold);
bevt_29_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_44_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 583 */ {
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(27, bece_BEC_2_5_9_BuildCCEmitter_bels_211));
bevt_49_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_50_tmpany_phold);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_212));
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_addValue_1(bevt_51_tmpany_phold);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_213));
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_addValue_1(bevt_52_tmpany_phold);
bevt_45_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 584 */
 else  /* Line: 585 */ {
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_214));
bevt_55_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_56_tmpany_phold);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_57_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_215));
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_addValue_1(bevt_57_tmpany_phold);
bevt_53_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 586 */
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_216));
bevt_58_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_59_tmpany_phold);
bevt_58_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_217));
bevt_62_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_63_tmpany_phold);
bevt_64_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_addValue_1(bevt_64_tmpany_phold);
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_218));
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bem_addValue_1(bevt_65_tmpany_phold);
bevt_60_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_219));
bevt_68_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_69_tmpany_phold);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_70_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_220));
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_addValue_1(bevt_70_tmpany_phold);
bevt_66_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_72_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_221));
bevt_71_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_72_tmpany_phold);
bevt_71_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_222));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_223));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_57;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_58;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_59;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_headExtGetDirect_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public final BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public final BEC_2_4_6_TextString bem_classHeadersGetDirect_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public final BEC_2_4_6_TextString bem_deonGetDirect_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public final BEC_2_4_6_TextString bem_heonGetDirect_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 19, 20, 22, 23, 24, 28, 30, 31, 32, 33, 34, 38, 42, 42, 43, 43, 43, 45, 45, 47, 47, 47, 47, 47, 47, 49, 49, 50, 50, 52, 52, 54, 54, 54, 54, 54, 54, 54, 56, 56, 58, 58, 60, 60, 63, 63, 65, 65, 67, 69, 71, 73, 75, 75, 76, 76, 77, 77, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 84, 84, 84, 84, 86, 86, 86, 86, 86, 86, 88, 88, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 95, 95, 95, 99, 101, 102, 103, 103, 104, 108, 108, 112, 112, 116, 116, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 121, 123, 125, 125, 125, 125, 125, 125, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 129, 131, 131, 137, 137, 137, 137, 138, 139, 139, 139, 139, 140, 140, 140, 140, 140, 141, 141, 141, 141, 142, 144, 144, 146, 150, 150, 150, 150, 151, 151, 152, 154, 154, 158, 158, 158, 158, 158, 158, 158, 158, 162, 162, 162, 162, 163, 163, 163, 165, 171, 171, 171, 171, 171, 173, 173, 173, 173, 173, 173, 173, 173, 175, 177, 179, 179, 179, 179, 179, 179, 179, 179, 179, 179, 179, 181, 186, 186, 186, 187, 188, 188, 188, 188, 188, 188, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 194, 194, 194, 195, 195, 195, 195, 195, 195, 195, 197, 197, 197, 197, 197, 197, 197, 197, 197, 202, 202, 203, 205, 207, 207, 207, 207, 207, 207, 207, 207, 212, 212, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 217, 217, 217, 217, 217, 217, 217, 217, 217, 219, 219, 219, 223, 223, 223, 223, 223, 223, 223, 223, 223, 223, 223, 223, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 238, 238, 238, 238, 238, 243, 244, 245, 245, 245, 246, 252, 252, 252, 252, 256, 256, 260, 260, 265, 265, 269, 269, 269, 269, 269, 270, 270, 270, 270, 270, 270, 271, 271, 271, 272, 272, 272, 272, 272, 272, 272, 272, 274, 274, 278, 278, 282, 282, 282, 282, 289, 290, 0, 290, 290, 290, 290, 290, 0, 0, 291, 293, 293, 293, 294, 294, 294, 295, 298, 301, 306, 307, 307, 309, 309, 313, 314, 315, 315, 316, 321, 323, 324, 324, 325, 326, 327, 327, 328, 328, 328, 329, 335, 335, 335, 335, 335, 335, 336, 337, 337, 337, 337, 337, 337, 338, 338, 339, 339, 339, 339, 340, 340, 341, 341, 342, 344, 345, 345, 345, 345, 345, 345, 345, 345, 346, 346, 347, 348, 348, 0, 348, 348, 350, 352, 352, 354, 354, 354, 354, 356, 356, 357, 357, 359, 359, 360, 361, 361, 0, 361, 361, 363, 365, 365, 367, 367, 367, 367, 369, 369, 371, 371, 373, 373, 373, 373, 373, 373, 374, 374, 374, 375, 375, 375, 375, 375, 375, 377, 377, 377, 377, 377, 377, 379, 379, 380, 380, 381, 381, 393, 393, 394, 395, 395, 395, 395, 395, 395, 395, 396, 396, 396, 396, 396, 396, 396, 397, 397, 398, 398, 399, 399, 399, 399, 399, 400, 400, 400, 402, 402, 402, 403, 403, 403, 405, 405, 405, 407, 407, 407, 407, 0, 407, 407, 409, 409, 410, 410, 410, 411, 411, 413, 417, 417, 418, 418, 420, 420, 421, 421, 427, 427, 427, 429, 429, 429, 429, 0, 429, 429, 431, 431, 432, 432, 432, 433, 433, 435, 438, 438, 438, 440, 440, 440, 440, 0, 440, 440, 442, 442, 443, 443, 443, 444, 444, 446, 453, 454, 459, 459, 460, 461, 461, 461, 461, 461, 462, 462, 462, 464, 464, 464, 466, 466, 468, 468, 468, 470, 470, 470, 470, 0, 470, 470, 472, 472, 473, 473, 473, 474, 474, 476, 480, 480, 481, 482, 482, 482, 483, 483, 483, 483, 0, 483, 483, 484, 484, 485, 485, 485, 486, 486, 487, 487, 488, 494, 498, 499, 501, 501, 503, 503, 504, 505, 510, 510, 514, 514, 514, 514, 514, 519, 519, 520, 522, 522, 522, 522, 524, 525, 0, 525, 525, 527, 529, 529, 531, 531, 531, 531, 531, 531, 535, 535, 535, 540, 542, 542, 542, 542, 542, 544, 544, 544, 544, 544, 544, 544, 544, 544, 544, 544, 544, 544, 546, 550, 550, 551, 551, 551, 551, 552, 556, 556, 557, 557, 557, 557, 558, 558, 558, 558, 562, 562, 562, 566, 566, 566, 567, 567, 567, 568, 570, 570, 570, 570, 570, 570, 570, 570, 570, 570, 570, 570, 570, 570, 570, 571, 572, 572, 573, 573, 576, 576, 576, 576, 576, 576, 576, 578, 578, 578, 581, 581, 581, 581, 581, 581, 581, 581, 581, 581, 581, 581, 581, 581, 581, 583, 583, 584, 584, 584, 584, 584, 584, 584, 584, 584, 586, 586, 586, 586, 586, 586, 589, 589, 589, 591, 593, 593, 593, 593, 593, 593, 593, 595, 595, 595, 595, 595, 595, 597, 597, 597, 603, 603, 604, 604, 606, 611, 611, 612, 612, 612, 612, 613, 613, 613, 613, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 325, 382, 387, 388, 389, 390, 393, 394, 396, 397, 398, 399, 400, 401, 402, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 421, 422, 423, 424, 425, 426, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 544, 545, 546, 547, 548, 549, 553, 554, 558, 559, 563, 564, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 651, 652, 653, 658, 659, 662, 663, 664, 665, 667, 668, 669, 670, 671, 674, 675, 676, 677, 679, 682, 683, 687, 697, 698, 699, 700, 702, 703, 704, 706, 707, 717, 718, 719, 720, 721, 722, 723, 724, 734, 735, 736, 737, 739, 740, 741, 744, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 858, 859, 864, 865, 866, 867, 868, 869, 870, 871, 874, 875, 876, 877, 878, 879, 880, 881, 882, 897, 898, 900, 903, 905, 906, 907, 908, 909, 910, 911, 912, 916, 917, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1082, 1083, 1084, 1085, 1086, 1092, 1093, 1094, 1095, 1096, 1097, 1104, 1105, 1106, 1107, 1111, 1112, 1116, 1117, 1121, 1122, 1145, 1146, 1147, 1148, 1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1161, 1162, 1163, 1164, 1165, 1166, 1167, 1168, 1172, 1173, 1179, 1180, 1181, 1182, 1198, 1199, 1201, 1204, 1205, 1206, 1207, 1212, 1213, 1216, 1220, 1223, 1224, 1225, 1226, 1227, 1228, 1229, 1231, 1233, 1241, 1243, 1244, 1246, 1247, 1253, 1255, 1256, 1257, 1258, 1269, 1271, 1272, 1273, 1274, 1275, 1276, 1281, 1282, 1283, 1284, 1285, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1387, 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1398, 1401, 1403, 1405, 1408, 1409, 1411, 1412, 1413, 1414, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1428, 1431, 1433, 1435, 1438, 1439, 1441, 1442, 1443, 1444, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462, 1464, 1465, 1466, 1467, 1468, 1469, 1472, 1473, 1474, 1475, 1476, 1477, 1479, 1480, 1481, 1482, 1483, 1484, 1557, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1590, 1591, 1592, 1593, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1605, 1606, 1607, 1608, 1608, 1611, 1613, 1614, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1640, 1641, 1642, 1643, 1643, 1646, 1648, 1649, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1663, 1664, 1665, 1667, 1668, 1669, 1670, 1670, 1673, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1694, 1695, 1738, 1743, 1744, 1745, 1746, 1747, 1748, 1753, 1754, 1755, 1756, 1758, 1759, 1760, 1761, 1762, 1763, 1764, 1765, 1767, 1768, 1769, 1770, 1770, 1773, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1783, 1790, 1791, 1792, 1793, 1794, 1795, 1797, 1798, 1799, 1800, 1800, 1803, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1813, 1814, 1815, 1823, 1828, 1829, 1830, 1831, 1832, 1833, 1834, 1835, 1840, 1841, 1848, 1849, 1850, 1851, 1852, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1881, 1882, 1882, 1885, 1887, 1889, 1892, 1893, 1895, 1896, 1897, 1898, 1899, 1900, 1906, 1907, 1908, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943, 1944, 1945, 1946, 1947, 1948, 1949, 1958, 1959, 1960, 1961, 1962, 1963, 1964, 1976, 1977, 1978, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1990, 1991, 1992, 2073, 2074, 2075, 2076, 2077, 2078, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2099, 2100, 2102, 2103, 2104, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2112, 2113, 2114, 2115, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2124, 2125, 2126, 2127, 2128, 2130, 2131, 2132, 2133, 2134, 2135, 2136, 2137, 2138, 2141, 2142, 2143, 2144, 2145, 2146, 2148, 2149, 2150, 2151, 2152, 2153, 2154, 2155, 2156, 2157, 2158, 2159, 2160, 2161, 2162, 2163, 2164, 2165, 2166, 2167, 2173, 2174, 2175, 2176, 2177, 2190, 2191, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2202, 2205, 2208, 2212, 2216, 2219, 2222, 2226, 2230, 2233, 2236, 2240, 2244, 2247, 2250, 2254, 2258, 2261, 2264, 2268, 2272, 2275, 2278, 2282, 2286, 2289, 2292, 2296, 2300, 2303, 2306, 2310, 2314, 2317, 2320, 2324, 2328, 2331, 2334, 2338, 2342, 2345, 2348, 2352};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 310
new 0 18 310
assign 1 19 311
new 0 19 311
assign 1 20 312
new 0 20 312
assign 1 22 313
new 0 22 313
assign 1 23 314
new 0 23 314
assign 1 24 315
new 0 24 315
new 1 28 316
assign 1 30 317
new 0 30 317
assign 1 31 318
new 0 31 318
assign 1 32 319
new 0 32 319
assign 1 33 320
new 0 33 320
assign 1 34 321
new 0 34 321
addValue 1 38 325
assign 1 42 382
def 1 42 387
assign 1 43 388
libNameGet 0 43 388
assign 1 43 389
relEmitName 1 43 389
assign 1 43 390
extend 1 43 390
assign 1 45 393
new 0 45 393
assign 1 45 394
extend 1 45 394
assign 1 47 396
new 0 47 396
assign 1 47 397
emitNameGet 0 47 397
assign 1 47 398
addValue 1 47 398
assign 1 47 399
addValue 1 47 399
assign 1 47 400
new 0 47 400
assign 1 47 401
addValue 1 47 401
assign 1 49 402
def 1 49 407
assign 1 50 408
new 0 50 408
addValue 1 50 409
assign 1 52 410
new 0 52 410
addValue 1 52 411
assign 1 54 412
new 0 54 412
assign 1 54 413
addValue 1 54 413
assign 1 54 414
libNameGet 0 54 414
assign 1 54 415
relEmitName 1 54 415
assign 1 54 416
addValue 1 54 416
assign 1 54 417
new 0 54 417
addValue 1 54 418
assign 1 56 421
new 0 56 421
addValue 1 56 422
assign 1 58 423
new 0 58 423
addValue 1 58 424
assign 1 60 425
new 0 60 425
addValue 1 60 426
assign 1 63 428
new 0 63 428
addValue 1 63 429
assign 1 65 430
new 0 65 430
addValue 1 65 431
write 1 67 432
write 1 69 433
write 1 71 434
clear 0 73 435
assign 1 75 436
new 0 75 436
write 1 75 437
assign 1 76 438
new 0 76 438
write 1 76 439
assign 1 77 440
new 0 77 440
write 1 77 441
assign 1 78 442
new 0 78 442
assign 1 78 443
emitNameGet 0 78 443
assign 1 78 444
add 1 78 444
assign 1 78 445
new 0 78 445
assign 1 78 446
add 1 78 446
assign 1 78 447
getHeaderInitialInst 1 78 447
assign 1 78 448
add 1 78 448
assign 1 78 449
new 0 78 449
assign 1 78 450
add 1 78 450
write 1 78 451
assign 1 79 452
new 0 79 452
write 1 79 453
assign 1 80 454
new 0 80 454
write 1 80 455
assign 1 81 456
new 0 81 456
write 1 81 457
assign 1 82 458
new 0 82 458
write 1 82 459
assign 1 83 460
new 0 83 460
write 1 83 461
assign 1 84 462
new 0 84 462
assign 1 84 463
emitNameGet 0 84 463
assign 1 84 464
add 1 84 464
assign 1 84 465
new 0 84 465
assign 1 84 466
add 1 84 466
write 1 84 467
assign 1 86 468
new 0 86 468
assign 1 86 469
emitNameGet 0 86 469
assign 1 86 470
add 1 86 470
assign 1 86 471
new 0 86 471
assign 1 86 472
add 1 86 472
write 1 86 473
assign 1 88 474
new 0 88 474
return 1 88 475
assign 1 92 507
overrideMtdDecGet 0 92 507
assign 1 92 508
addValue 1 92 508
assign 1 92 509
new 0 92 509
assign 1 92 510
addValue 1 92 510
assign 1 92 511
getClassConfig 1 92 511
assign 1 92 512
libNameGet 0 92 512
assign 1 92 513
relEmitName 1 92 513
assign 1 92 514
addValue 1 92 514
assign 1 92 515
new 0 92 515
assign 1 92 516
addValue 1 92 516
assign 1 92 517
emitNameGet 0 92 517
assign 1 92 518
addValue 1 92 518
assign 1 92 519
new 0 92 519
assign 1 92 520
addValue 1 92 520
assign 1 92 521
addValue 1 92 521
assign 1 92 522
new 0 92 522
assign 1 92 523
addValue 1 92 523
addValue 1 92 524
assign 1 93 525
new 0 93 525
assign 1 93 526
addValue 1 93 526
assign 1 93 527
heldGet 0 93 527
assign 1 93 528
namepathGet 0 93 528
assign 1 93 529
getClassConfig 1 93 529
assign 1 93 530
libNameGet 0 93 530
assign 1 93 531
relEmitName 1 93 531
assign 1 93 532
addValue 1 93 532
assign 1 93 533
new 0 93 533
assign 1 93 534
addValue 1 93 534
addValue 1 93 535
assign 1 95 536
new 0 95 536
assign 1 95 537
addValue 1 95 537
addValue 1 95 538
assign 1 99 544
new 0 99 544
write 1 101 545
clear 0 102 546
assign 1 103 547
new 0 103 547
write 1 103 548
return 1 104 549
assign 1 108 553
new 0 108 553
return 1 108 554
assign 1 112 558
new 0 112 558
return 1 112 559
assign 1 116 563
new 0 116 563
return 1 116 564
assign 1 121 596
addValue 1 121 596
assign 1 121 597
new 0 121 597
assign 1 121 598
addValue 1 121 598
assign 1 121 599
libNameGet 0 121 599
assign 1 121 600
relEmitName 1 121 600
assign 1 121 601
addValue 1 121 601
assign 1 121 602
new 0 121 602
assign 1 121 603
addValue 1 121 603
assign 1 121 604
emitNameGet 0 121 604
assign 1 121 605
addValue 1 121 605
assign 1 121 606
new 0 121 606
assign 1 121 607
addValue 1 121 607
assign 1 121 608
addValue 1 121 608
assign 1 121 609
new 0 121 609
addValue 1 121 610
addValue 1 123 611
assign 1 125 612
new 0 125 612
assign 1 125 613
addValue 1 125 613
assign 1 125 614
addValue 1 125 614
assign 1 125 615
new 0 125 615
assign 1 125 616
addValue 1 125 616
addValue 1 125 617
assign 1 127 618
new 0 127 618
assign 1 127 619
addValue 1 127 619
assign 1 127 620
libNameGet 0 127 620
assign 1 127 621
relEmitName 1 127 621
assign 1 127 622
addValue 1 127 622
assign 1 127 623
new 0 127 623
assign 1 127 624
addValue 1 127 624
assign 1 127 625
addValue 1 127 625
assign 1 127 626
new 0 127 626
addValue 1 127 627
addValue 1 129 628
assign 1 131 629
new 0 131 629
addValue 1 131 630
assign 1 137 651
typenameGet 0 137 651
assign 1 137 652
NULLGet 0 137 652
assign 1 137 653
equals 1 137 658
assign 1 138 659
new 0 138 659
assign 1 139 662
heldGet 0 139 662
assign 1 139 663
nameGet 0 139 663
assign 1 139 664
new 0 139 664
assign 1 139 665
equals 1 139 665
assign 1 140 667
new 0 140 667
assign 1 140 668
emitNameGet 0 140 668
assign 1 140 669
add 1 140 669
assign 1 140 670
new 0 140 670
assign 1 140 671
add 1 140 671
assign 1 141 674
heldGet 0 141 674
assign 1 141 675
nameGet 0 141 675
assign 1 141 676
new 0 141 676
assign 1 141 677
equals 1 141 677
assign 1 142 679
new 0 142 679
assign 1 144 682
heldGet 0 144 682
assign 1 144 683
nameForVar 1 144 683
return 1 146 687
assign 1 150 697
heldGet 0 150 697
assign 1 150 698
nameGet 0 150 698
assign 1 150 699
new 0 150 699
assign 1 150 700
equals 1 150 700
assign 1 151 702
new 0 151 702
assign 1 151 703
add 1 151 703
return 1 152 704
assign 1 154 706
formCallTarg 1 154 706
return 1 154 707
assign 1 158 717
new 0 158 717
assign 1 158 718
addValue 1 158 718
assign 1 158 719
secondGet 0 158 719
assign 1 158 720
formTarg 1 158 720
assign 1 158 721
addValue 1 158 721
assign 1 158 722
new 0 158 722
assign 1 158 723
addValue 1 158 723
addValue 1 158 724
assign 1 162 734
heldGet 0 162 734
assign 1 162 735
langsGet 0 162 735
assign 1 162 736
new 0 162 736
assign 1 162 737
has 1 162 737
assign 1 163 739
heldGet 0 163 739
assign 1 163 740
textGet 0 163 740
addValue 1 163 741
handleClassEmit 1 165 744
assign 1 171 773
new 0 171 773
assign 1 171 774
emitNameGet 0 171 774
assign 1 171 775
add 1 171 775
assign 1 171 776
new 0 171 776
assign 1 171 777
add 1 171 777
assign 1 173 778
new 0 173 778
assign 1 173 779
typeEmitNameGet 0 173 779
assign 1 173 780
add 1 173 780
assign 1 173 781
new 0 173 781
assign 1 173 782
add 1 173 782
assign 1 173 783
add 1 173 783
assign 1 173 784
new 0 173 784
assign 1 173 785
add 1 173 785
addClassHeader 1 175 786
assign 1 177 787
new 0 177 787
assign 1 179 788
typeEmitNameGet 0 179 788
assign 1 179 789
addValue 1 179 789
assign 1 179 790
new 0 179 790
assign 1 179 791
addValue 1 179 791
assign 1 179 792
emitNameGet 0 179 792
assign 1 179 793
addValue 1 179 793
assign 1 179 794
new 0 179 794
assign 1 179 795
addValue 1 179 795
assign 1 179 796
addValue 1 179 796
assign 1 179 797
new 0 179 797
addValue 1 179 798
return 1 181 799
assign 1 186 819
new 0 186 819
assign 1 186 820
toString 0 186 820
assign 1 186 821
add 1 186 821
incrementValue 0 187 822
assign 1 188 823
new 0 188 823
assign 1 188 824
addValue 1 188 824
assign 1 188 825
addValue 1 188 825
assign 1 188 826
new 0 188 826
assign 1 188 827
addValue 1 188 827
addValue 1 188 828
assign 1 190 829
containedGet 0 190 829
assign 1 190 830
firstGet 0 190 830
assign 1 190 831
containedGet 0 190 831
assign 1 190 832
firstGet 0 190 832
assign 1 190 833
new 0 190 833
assign 1 190 834
add 1 190 834
assign 1 190 835
new 0 190 835
assign 1 190 836
add 1 190 836
assign 1 190 837
finalAssign 4 190 837
addValue 1 190 838
assign 1 194 858
isTypedGet 0 194 858
assign 1 194 859
not 0 194 864
assign 1 195 865
new 0 195 865
assign 1 195 866
addValue 1 195 866
assign 1 195 867
libNameGet 0 195 867
assign 1 195 868
relEmitName 1 195 868
assign 1 195 869
addValue 1 195 869
assign 1 195 870
new 0 195 870
addValue 1 195 871
assign 1 197 874
new 0 197 874
assign 1 197 875
addValue 1 197 875
assign 1 197 876
namepathGet 0 197 876
assign 1 197 877
getClassConfig 1 197 877
assign 1 197 878
libNameGet 0 197 878
assign 1 197 879
relEmitName 1 197 879
assign 1 197 880
addValue 1 197 880
assign 1 197 881
new 0 197 881
addValue 1 197 882
assign 1 202 897
new 0 202 897
assign 1 202 898
equals 1 202 898
assign 1 203 900
new 0 203 900
assign 1 205 903
new 0 205 903
assign 1 207 905
new 0 207 905
assign 1 207 906
add 1 207 906
assign 1 207 907
libNameGet 0 207 907
assign 1 207 908
relEmitName 1 207 908
assign 1 207 909
add 1 207 909
assign 1 207 910
new 0 207 910
assign 1 207 911
add 1 207 911
return 1 207 912
assign 1 212 916
new 0 212 916
return 1 212 917
assign 1 216 944
overrideMtdDecGet 0 216 944
assign 1 216 945
addValue 1 216 945
assign 1 216 946
new 0 216 946
assign 1 216 947
addValue 1 216 947
assign 1 216 948
emitNameGet 0 216 948
assign 1 216 949
addValue 1 216 949
assign 1 216 950
new 0 216 950
assign 1 216 951
addValue 1 216 951
assign 1 216 952
addValue 1 216 952
assign 1 216 953
new 0 216 953
assign 1 216 954
addValue 1 216 954
assign 1 216 955
addValue 1 216 955
assign 1 216 956
new 0 216 956
assign 1 216 957
addValue 1 216 957
addValue 1 216 958
assign 1 217 959
new 0 217 959
assign 1 217 960
addValue 1 217 960
assign 1 217 961
addValue 1 217 961
assign 1 217 962
new 0 217 962
assign 1 217 963
addValue 1 217 963
assign 1 217 964
addValue 1 217 964
assign 1 217 965
new 0 217 965
assign 1 217 966
addValue 1 217 966
addValue 1 217 967
assign 1 219 968
new 0 219 968
assign 1 219 969
addValue 1 219 969
addValue 1 219 970
assign 1 223 985
new 0 223 985
assign 1 223 986
libNameGet 0 223 986
assign 1 223 987
relEmitName 1 223 987
assign 1 223 988
add 1 223 988
assign 1 223 989
new 0 223 989
assign 1 223 990
add 1 223 990
assign 1 223 991
heldGet 0 223 991
assign 1 223 992
literalValueGet 0 223 992
assign 1 223 993
add 1 223 993
assign 1 223 994
new 0 223 994
assign 1 223 995
add 1 223 995
return 1 223 996
assign 1 227 1010
new 0 227 1010
assign 1 227 1011
libNameGet 0 227 1011
assign 1 227 1012
relEmitName 1 227 1012
assign 1 227 1013
add 1 227 1013
assign 1 227 1014
new 0 227 1014
assign 1 227 1015
add 1 227 1015
assign 1 227 1016
heldGet 0 227 1016
assign 1 227 1017
literalValueGet 0 227 1017
assign 1 227 1018
add 1 227 1018
assign 1 227 1019
new 0 227 1019
assign 1 227 1020
add 1 227 1020
return 1 227 1021
assign 1 232 1049
new 0 232 1049
assign 1 232 1050
libNameGet 0 232 1050
assign 1 232 1051
relEmitName 1 232 1051
assign 1 232 1052
add 1 232 1052
assign 1 232 1053
new 0 232 1053
assign 1 232 1054
add 1 232 1054
assign 1 232 1055
add 1 232 1055
assign 1 232 1056
new 0 232 1056
assign 1 232 1057
add 1 232 1057
assign 1 232 1058
add 1 232 1058
assign 1 232 1059
new 0 232 1059
assign 1 232 1060
add 1 232 1060
return 1 232 1061
assign 1 234 1063
new 0 234 1063
assign 1 234 1064
libNameGet 0 234 1064
assign 1 234 1065
relEmitName 1 234 1065
assign 1 234 1066
add 1 234 1066
assign 1 234 1067
new 0 234 1067
assign 1 234 1068
add 1 234 1068
assign 1 234 1069
add 1 234 1069
assign 1 234 1070
new 0 234 1070
assign 1 234 1071
add 1 234 1071
assign 1 234 1072
add 1 234 1072
assign 1 234 1073
new 0 234 1073
assign 1 234 1074
add 1 234 1074
return 1 234 1075
assign 1 238 1082
new 0 238 1082
assign 1 238 1083
add 1 238 1083
assign 1 238 1084
new 0 238 1084
assign 1 238 1085
add 1 238 1085
return 1 238 1086
getCode 2 243 1092
assign 1 244 1093
toHexString 1 244 1093
assign 1 245 1094
new 0 245 1094
assign 1 245 1095
once 0 245 1095
addValue 1 245 1096
addValue 1 246 1097
assign 1 252 1104
new 0 252 1104
assign 1 252 1105
add 1 252 1105
assign 1 252 1106
add 1 252 1106
return 1 252 1107
assign 1 256 1111
new 0 256 1111
return 1 256 1112
assign 1 260 1116
new 0 260 1116
return 1 260 1117
assign 1 265 1121
new 0 265 1121
return 1 265 1122
assign 1 269 1145
new 0 269 1145
assign 1 269 1146
add 1 269 1146
assign 1 269 1147
new 0 269 1147
assign 1 269 1148
add 1 269 1148
assign 1 269 1149
add 1 269 1149
assign 1 270 1150
new 0 270 1150
assign 1 270 1151
addValue 1 270 1151
assign 1 270 1152
addValue 1 270 1152
assign 1 270 1153
new 0 270 1153
assign 1 270 1154
addValue 1 270 1154
addValue 1 270 1155
assign 1 271 1156
new 0 271 1156
assign 1 271 1157
addValue 1 271 1157
addValue 1 271 1158
assign 1 272 1159
new 0 272 1159
assign 1 272 1160
addValue 1 272 1160
assign 1 272 1161
outputPlatformGet 0 272 1161
assign 1 272 1162
nameGet 0 272 1162
assign 1 272 1163
addValue 1 272 1163
assign 1 272 1164
new 0 272 1164
assign 1 272 1165
addValue 1 272 1165
addValue 1 272 1166
assign 1 274 1167
new 0 274 1167
return 1 274 1168
assign 1 278 1172
new 0 278 1172
return 1 278 1173
assign 1 282 1179
new 0 282 1179
assign 1 282 1180
once 0 282 1180
assign 1 282 1181
add 1 282 1181
return 1 282 1182
assign 1 289 1198
assign 1 290 1199
singleCCGet 0 290 1199
assign 1 0 1201
assign 1 290 1204
classPathGet 0 290 1204
assign 1 290 1205
fileGet 0 290 1205
assign 1 290 1206
existsGet 0 290 1206
assign 1 290 1207
not 0 290 1212
assign 1 0 1213
assign 1 0 1216
return 1 291 1220
assign 1 293 1223
classPathGet 0 293 1223
assign 1 293 1224
fileGet 0 293 1224
assign 1 293 1225
lastUpdatedGet 0 293 1225
assign 1 294 1226
fromFileGet 0 294 1226
assign 1 294 1227
fileGet 0 294 1227
assign 1 294 1228
lastUpdatedGet 0 294 1228
assign 1 295 1229
greater 1 295 1229
return 1 298 1231
assign 1 301 1233
assign 1 306 1241
singleCCGet 0 306 1241
assign 1 307 1243
getLibOutput 0 307 1243
return 1 307 1244
assign 1 309 1246
getClassOutput 0 309 1246
return 1 309 1247
assign 1 313 1253
singleCCGet 0 313 1253
assign 1 314 1255
new 0 314 1255
assign 1 315 1256
countLines 1 315 1256
addValue 1 315 1257
write 1 316 1258
assign 1 321 1269
singleCCGet 0 321 1269
assign 1 323 1271
new 0 323 1271
assign 1 324 1272
countLines 1 324 1272
addValue 1 324 1273
write 1 325 1274
close 0 326 1275
assign 1 327 1276
def 1 327 1281
assign 1 328 1282
pathGet 0 328 1282
assign 1 328 1283
fileGet 0 328 1283
lastUpdatedSet 1 328 1284
assign 1 329 1285
assign 1 335 1361
new 0 335 1361
assign 1 335 1362
typeEmitNameGet 0 335 1362
assign 1 335 1363
add 1 335 1363
assign 1 335 1364
new 0 335 1364
assign 1 335 1365
add 1 335 1365
write 1 335 1366
assign 1 336 1367
new 0 336 1367
assign 1 337 1368
new 0 337 1368
assign 1 337 1369
addValue 1 337 1369
assign 1 337 1370
typeEmitNameGet 0 337 1370
assign 1 337 1371
addValue 1 337 1371
assign 1 337 1372
new 0 337 1372
addValue 1 337 1373
assign 1 338 1374
new 0 338 1374
addValue 1 338 1375
assign 1 339 1376
typeEmitNameGet 0 339 1376
assign 1 339 1377
addValue 1 339 1377
assign 1 339 1378
new 0 339 1378
addValue 1 339 1379
assign 1 340 1380
new 0 340 1380
addValue 1 340 1381
assign 1 341 1382
new 0 341 1382
addValue 1 341 1383
write 1 342 1384
assign 1 344 1385
new 0 344 1385
assign 1 345 1386
typeEmitNameGet 0 345 1386
assign 1 345 1387
addValue 1 345 1387
assign 1 345 1388
new 0 345 1388
assign 1 345 1389
addValue 1 345 1389
assign 1 345 1390
typeEmitNameGet 0 345 1390
assign 1 345 1391
addValue 1 345 1391
assign 1 345 1392
new 0 345 1392
addValue 1 345 1393
assign 1 346 1394
new 0 346 1394
addValue 1 346 1395
assign 1 347 1396
new 0 347 1396
assign 1 348 1397
mtdListGet 0 348 1397
assign 1 348 1398
iteratorGet 0 0 1398
assign 1 348 1401
hasNextGet 0 348 1401
assign 1 348 1403
nextGet 0 348 1403
assign 1 350 1405
new 0 350 1405
assign 1 352 1408
new 0 352 1408
addValue 1 352 1409
assign 1 354 1411
addValue 1 354 1411
assign 1 354 1412
nameGet 0 354 1412
assign 1 354 1413
addValue 1 354 1413
addValue 1 354 1414
assign 1 356 1420
new 0 356 1420
addValue 1 356 1421
assign 1 357 1422
new 0 357 1422
addValue 1 357 1423
assign 1 359 1424
new 0 359 1424
addValue 1 359 1425
assign 1 360 1426
new 0 360 1426
assign 1 361 1427
ptyListGet 0 361 1427
assign 1 361 1428
iteratorGet 0 0 1428
assign 1 361 1431
hasNextGet 0 361 1431
assign 1 361 1433
nextGet 0 361 1433
assign 1 363 1435
new 0 363 1435
assign 1 365 1438
new 0 365 1438
addValue 1 365 1439
assign 1 367 1441
addValue 1 367 1441
assign 1 367 1442
nameGet 0 367 1442
assign 1 367 1443
addValue 1 367 1443
addValue 1 367 1444
assign 1 369 1450
new 0 369 1450
addValue 1 369 1451
assign 1 371 1452
new 0 371 1452
addValue 1 371 1453
assign 1 373 1454
new 0 373 1454
assign 1 373 1455
addValue 1 373 1455
assign 1 373 1456
typeEmitNameGet 0 373 1456
assign 1 373 1457
addValue 1 373 1457
assign 1 373 1458
new 0 373 1458
addValue 1 373 1459
assign 1 374 1460
emitNameGet 0 374 1460
assign 1 374 1461
new 0 374 1461
assign 1 374 1462
equals 1 374 1462
assign 1 375 1464
new 0 375 1464
assign 1 375 1465
addValue 1 375 1465
assign 1 375 1466
emitNameGet 0 375 1466
assign 1 375 1467
addValue 1 375 1467
assign 1 375 1468
new 0 375 1468
addValue 1 375 1469
assign 1 377 1472
new 0 377 1472
assign 1 377 1473
addValue 1 377 1473
assign 1 377 1474
emitNameGet 0 377 1474
assign 1 377 1475
addValue 1 377 1475
assign 1 377 1476
new 0 377 1476
addValue 1 377 1477
assign 1 379 1479
new 0 379 1479
addValue 1 379 1480
assign 1 380 1481
getClassOutput 0 380 1481
write 1 380 1482
assign 1 381 1483
countLines 1 381 1483
addValue 1 381 1484
assign 1 393 1557
undef 1 393 1562
assign 1 394 1563
libNameGet 0 394 1563
assign 1 395 1564
new 0 395 1564
assign 1 395 1565
sizeGet 0 395 1565
assign 1 395 1566
add 1 395 1566
assign 1 395 1567
new 0 395 1567
assign 1 395 1568
add 1 395 1568
assign 1 395 1569
add 1 395 1569
assign 1 395 1570
add 1 395 1570
assign 1 396 1571
new 0 396 1571
assign 1 396 1572
sizeGet 0 396 1572
assign 1 396 1573
add 1 396 1573
assign 1 396 1574
new 0 396 1574
assign 1 396 1575
add 1 396 1575
assign 1 396 1576
add 1 396 1576
assign 1 396 1577
add 1 396 1577
assign 1 397 1578
parentGet 0 397 1578
assign 1 397 1579
addStep 1 397 1579
assign 1 398 1580
parentGet 0 398 1580
assign 1 398 1581
addStep 1 398 1581
assign 1 399 1582
parentGet 0 399 1582
assign 1 399 1583
fileGet 0 399 1583
assign 1 399 1584
existsGet 0 399 1584
assign 1 399 1585
not 0 399 1590
assign 1 400 1591
parentGet 0 400 1591
assign 1 400 1592
fileGet 0 400 1592
makeDirs 0 400 1593
assign 1 402 1595
fileGet 0 402 1595
assign 1 402 1596
writerGet 0 402 1596
assign 1 402 1597
open 0 402 1597
assign 1 403 1598
fileGet 0 403 1598
assign 1 403 1599
writerGet 0 403 1599
assign 1 403 1600
open 0 403 1600
assign 1 405 1601
paramsGet 0 405 1601
assign 1 405 1602
new 0 405 1602
assign 1 405 1603
has 1 405 1603
assign 1 407 1605
paramsGet 0 407 1605
assign 1 407 1606
new 0 407 1606
assign 1 407 1607
get 1 407 1607
assign 1 407 1608
iteratorGet 0 0 1608
assign 1 407 1611
hasNextGet 0 407 1611
assign 1 407 1613
nextGet 0 407 1613
assign 1 409 1614
apNew 1 409 1614
assign 1 409 1615
fileGet 0 409 1615
assign 1 410 1616
readerGet 0 410 1616
assign 1 410 1617
open 0 410 1617
assign 1 410 1618
readString 0 410 1618
assign 1 411 1619
readerGet 0 411 1619
close 0 411 1620
write 1 413 1621
assign 1 417 1628
new 0 417 1628
write 1 417 1629
assign 1 418 1630
new 0 418 1630
write 1 418 1631
assign 1 420 1632
new 0 420 1632
write 1 420 1633
assign 1 421 1634
new 0 421 1634
write 1 421 1635
assign 1 427 1636
paramsGet 0 427 1636
assign 1 427 1637
new 0 427 1637
assign 1 427 1638
has 1 427 1638
assign 1 429 1640
paramsGet 0 429 1640
assign 1 429 1641
new 0 429 1641
assign 1 429 1642
get 1 429 1642
assign 1 429 1643
iteratorGet 0 0 1643
assign 1 429 1646
hasNextGet 0 429 1646
assign 1 429 1648
nextGet 0 429 1648
assign 1 431 1649
apNew 1 431 1649
assign 1 431 1650
fileGet 0 431 1650
assign 1 432 1651
readerGet 0 432 1651
assign 1 432 1652
open 0 432 1652
assign 1 432 1653
readString 0 432 1653
assign 1 433 1654
readerGet 0 433 1654
close 0 433 1655
write 1 435 1656
assign 1 438 1663
paramsGet 0 438 1663
assign 1 438 1664
new 0 438 1664
assign 1 438 1665
has 1 438 1665
assign 1 440 1667
paramsGet 0 440 1667
assign 1 440 1668
new 0 440 1668
assign 1 440 1669
get 1 440 1669
assign 1 440 1670
iteratorGet 0 0 1670
assign 1 440 1673
hasNextGet 0 440 1673
assign 1 440 1675
nextGet 0 440 1675
assign 1 442 1676
apNew 1 442 1676
assign 1 442 1677
fileGet 0 442 1677
assign 1 443 1678
readerGet 0 443 1678
assign 1 443 1679
open 0 443 1679
assign 1 443 1680
readString 0 443 1680
assign 1 444 1681
readerGet 0 444 1681
close 0 444 1682
write 1 446 1683
begin 1 453 1694
prepHeaderOutput 0 454 1695
assign 1 459 1738
undef 1 459 1743
assign 1 460 1744
new 0 460 1744
assign 1 461 1745
parentGet 0 461 1745
assign 1 461 1746
fileGet 0 461 1746
assign 1 461 1747
existsGet 0 461 1747
assign 1 461 1748
not 0 461 1753
assign 1 462 1754
parentGet 0 462 1754
assign 1 462 1755
fileGet 0 462 1755
makeDirs 0 462 1756
assign 1 464 1758
fileGet 0 464 1758
assign 1 464 1759
writerGet 0 464 1759
assign 1 464 1760
open 0 464 1760
assign 1 466 1761
new 0 466 1761
write 1 466 1762
assign 1 468 1763
paramsGet 0 468 1763
assign 1 468 1764
new 0 468 1764
assign 1 468 1765
has 1 468 1765
assign 1 470 1767
paramsGet 0 470 1767
assign 1 470 1768
new 0 470 1768
assign 1 470 1769
get 1 470 1769
assign 1 470 1770
iteratorGet 0 0 1770
assign 1 470 1773
hasNextGet 0 470 1773
assign 1 470 1775
nextGet 0 470 1775
assign 1 472 1776
apNew 1 472 1776
assign 1 472 1777
fileGet 0 472 1777
assign 1 473 1778
readerGet 0 473 1778
assign 1 473 1779
open 0 473 1779
assign 1 473 1780
readString 0 473 1780
assign 1 474 1781
readerGet 0 474 1781
close 0 474 1782
write 1 476 1783
assign 1 480 1790
new 0 480 1790
write 1 480 1791
increment 0 481 1792
assign 1 482 1793
paramsGet 0 482 1793
assign 1 482 1794
new 0 482 1794
assign 1 482 1795
has 1 482 1795
assign 1 483 1797
paramsGet 0 483 1797
assign 1 483 1798
new 0 483 1798
assign 1 483 1799
get 1 483 1799
assign 1 483 1800
iteratorGet 0 0 1800
assign 1 483 1803
hasNextGet 0 483 1803
assign 1 483 1805
nextGet 0 483 1805
assign 1 484 1806
apNew 1 484 1806
assign 1 484 1807
fileGet 0 484 1807
assign 1 485 1808
readerGet 0 485 1808
assign 1 485 1809
open 0 485 1809
assign 1 485 1810
readString 0 485 1810
assign 1 486 1811
readerGet 0 486 1811
close 0 486 1812
assign 1 487 1813
countLines 1 487 1813
addValue 1 487 1814
write 1 488 1815
return 1 494 1823
close 0 498 1828
assign 1 499 1829
assign 1 501 1830
new 0 501 1830
write 1 501 1831
assign 1 503 1832
new 0 503 1832
write 1 503 1833
close 0 504 1834
close 0 505 1835
assign 1 510 1840
new 0 510 1840
return 1 510 1841
assign 1 514 1848
new 0 514 1848
assign 1 514 1849
addValue 1 514 1849
assign 1 514 1850
addValue 1 514 1850
assign 1 514 1851
new 0 514 1851
addValue 1 514 1852
assign 1 519 1874
heldGet 0 519 1874
assign 1 519 1875
synGet 0 519 1875
assign 1 520 1876
ptyListGet 0 520 1876
assign 1 522 1877
emitNameGet 0 522 1877
assign 1 522 1878
addValue 1 522 1878
assign 1 522 1879
new 0 522 1879
addValue 1 522 1880
assign 1 524 1881
new 0 524 1881
assign 1 525 1882
iteratorGet 0 0 1882
assign 1 525 1885
hasNextGet 0 525 1885
assign 1 525 1887
nextGet 0 525 1887
assign 1 527 1889
new 0 527 1889
assign 1 529 1892
new 0 529 1892
addValue 1 529 1893
assign 1 531 1895
addValue 1 531 1895
assign 1 531 1896
new 0 531 1896
assign 1 531 1897
addValue 1 531 1897
assign 1 531 1898
nameGet 0 531 1898
assign 1 531 1899
addValue 1 531 1899
addValue 1 531 1900
assign 1 535 1906
new 0 535 1906
assign 1 535 1907
addValue 1 535 1907
addValue 1 535 1908
assign 1 540 1930
new 0 540 1930
assign 1 542 1931
new 0 542 1931
assign 1 542 1932
emitNameGet 0 542 1932
assign 1 542 1933
add 1 542 1933
assign 1 542 1934
new 0 542 1934
assign 1 542 1935
add 1 542 1935
assign 1 544 1936
new 0 544 1936
assign 1 544 1937
addValue 1 544 1937
assign 1 544 1938
emitNameGet 0 544 1938
assign 1 544 1939
addValue 1 544 1939
assign 1 544 1940
new 0 544 1940
assign 1 544 1941
addValue 1 544 1941
assign 1 544 1942
emitNameGet 0 544 1942
assign 1 544 1943
addValue 1 544 1943
assign 1 544 1944
new 0 544 1944
assign 1 544 1945
addValue 1 544 1945
assign 1 544 1946
addValue 1 544 1946
assign 1 544 1947
new 0 544 1947
addValue 1 544 1948
return 1 546 1949
assign 1 550 1958
libNameGet 0 550 1958
assign 1 550 1959
relEmitName 1 550 1959
assign 1 551 1960
new 0 551 1960
assign 1 551 1961
add 1 551 1961
assign 1 551 1962
new 0 551 1962
assign 1 551 1963
add 1 551 1963
return 1 552 1964
assign 1 556 1976
libNameGet 0 556 1976
assign 1 556 1977
relEmitName 1 556 1977
assign 1 557 1978
new 0 557 1978
assign 1 557 1979
add 1 557 1979
assign 1 557 1980
new 0 557 1980
assign 1 557 1981
add 1 557 1981
assign 1 558 1982
new 0 558 1982
assign 1 558 1983
add 1 558 1983
assign 1 558 1984
add 1 558 1984
return 1 558 1985
assign 1 562 1990
new 0 562 1990
assign 1 562 1991
add 1 562 1991
return 1 562 1992
assign 1 566 2073
getClassConfig 1 566 2073
assign 1 566 2074
libNameGet 0 566 2074
assign 1 566 2075
relEmitName 1 566 2075
assign 1 567 2076
heldGet 0 567 2076
assign 1 567 2077
namepathGet 0 567 2077
assign 1 567 2078
getClassConfig 1 567 2078
assign 1 568 2079
getInitialInst 1 568 2079
assign 1 570 2080
overrideMtdDecGet 0 570 2080
assign 1 570 2081
addValue 1 570 2081
assign 1 570 2082
new 0 570 2082
assign 1 570 2083
addValue 1 570 2083
assign 1 570 2084
emitNameGet 0 570 2084
assign 1 570 2085
addValue 1 570 2085
assign 1 570 2086
new 0 570 2086
assign 1 570 2087
addValue 1 570 2087
assign 1 570 2088
addValue 1 570 2088
assign 1 570 2089
new 0 570 2089
assign 1 570 2090
addValue 1 570 2090
assign 1 570 2091
addValue 1 570 2091
assign 1 570 2092
new 0 570 2092
assign 1 570 2093
addValue 1 570 2093
addValue 1 570 2094
assign 1 571 2095
new 0 571 2095
assign 1 572 2096
emitNameGet 0 572 2096
assign 1 572 2097
notEquals 1 572 2097
assign 1 573 2099
new 0 573 2099
assign 1 573 2100
formCast 3 573 2100
assign 1 576 2102
addValue 1 576 2102
assign 1 576 2103
new 0 576 2103
assign 1 576 2104
addValue 1 576 2104
assign 1 576 2105
addValue 1 576 2105
assign 1 576 2106
new 0 576 2106
assign 1 576 2107
addValue 1 576 2107
addValue 1 576 2108
assign 1 578 2109
new 0 578 2109
assign 1 578 2110
addValue 1 578 2110
addValue 1 578 2111
assign 1 581 2112
overrideMtdDecGet 0 581 2112
assign 1 581 2113
addValue 1 581 2113
assign 1 581 2114
new 0 581 2114
assign 1 581 2115
addValue 1 581 2115
assign 1 581 2116
addValue 1 581 2116
assign 1 581 2117
new 0 581 2117
assign 1 581 2118
addValue 1 581 2118
assign 1 581 2119
emitNameGet 0 581 2119
assign 1 581 2120
addValue 1 581 2120
assign 1 581 2121
new 0 581 2121
assign 1 581 2122
addValue 1 581 2122
assign 1 581 2123
addValue 1 581 2123
assign 1 581 2124
new 0 581 2124
assign 1 581 2125
addValue 1 581 2125
addValue 1 581 2126
assign 1 583 2127
emitNameGet 0 583 2127
assign 1 583 2128
notEquals 1 583 2128
assign 1 584 2130
new 0 584 2130
assign 1 584 2131
addValue 1 584 2131
assign 1 584 2132
addValue 1 584 2132
assign 1 584 2133
new 0 584 2133
assign 1 584 2134
addValue 1 584 2134
assign 1 584 2135
addValue 1 584 2135
assign 1 584 2136
new 0 584 2136
assign 1 584 2137
addValue 1 584 2137
addValue 1 584 2138
assign 1 586 2141
new 0 586 2141
assign 1 586 2142
addValue 1 586 2142
assign 1 586 2143
addValue 1 586 2143
assign 1 586 2144
new 0 586 2144
assign 1 586 2145
addValue 1 586 2145
addValue 1 586 2146
assign 1 589 2148
new 0 589 2148
assign 1 589 2149
addValue 1 589 2149
addValue 1 589 2150
assign 1 591 2151
getTypeInst 1 591 2151
assign 1 593 2152
new 0 593 2152
assign 1 593 2153
addValue 1 593 2153
assign 1 593 2154
emitNameGet 0 593 2154
assign 1 593 2155
addValue 1 593 2155
assign 1 593 2156
new 0 593 2156
assign 1 593 2157
addValue 1 593 2157
addValue 1 593 2158
assign 1 595 2159
new 0 595 2159
assign 1 595 2160
addValue 1 595 2160
assign 1 595 2161
addValue 1 595 2161
assign 1 595 2162
new 0 595 2162
assign 1 595 2163
addValue 1 595 2163
addValue 1 595 2164
assign 1 597 2165
new 0 597 2165
assign 1 597 2166
addValue 1 597 2166
addValue 1 597 2167
assign 1 603 2173
new 0 603 2173
write 1 603 2174
assign 1 604 2175
new 0 604 2175
write 1 604 2176
emitLib 0 606 2177
assign 1 611 2190
libNameGet 0 611 2190
assign 1 611 2191
relEmitName 1 611 2191
assign 1 612 2192
new 0 612 2192
assign 1 612 2193
add 1 612 2193
assign 1 612 2194
new 0 612 2194
assign 1 612 2195
add 1 612 2195
assign 1 613 2196
new 0 613 2196
assign 1 613 2197
add 1 613 2197
assign 1 613 2198
add 1 613 2198
return 1 613 2199
return 1 0 2202
return 1 0 2205
assign 1 0 2208
assign 1 0 2212
return 1 0 2216
return 1 0 2219
assign 1 0 2222
assign 1 0 2226
return 1 0 2230
return 1 0 2233
assign 1 0 2236
assign 1 0 2240
return 1 0 2244
return 1 0 2247
assign 1 0 2250
assign 1 0 2254
return 1 0 2258
return 1 0 2261
assign 1 0 2264
assign 1 0 2268
return 1 0 2272
return 1 0 2275
assign 1 0 2278
assign 1 0 2282
return 1 0 2286
return 1 0 2289
assign 1 0 2292
assign 1 0 2296
return 1 0 2300
return 1 0 2303
assign 1 0 2306
assign 1 0 2310
return 1 0 2314
return 1 0 2317
assign 1 0 2320
assign 1 0 2324
return 1 0 2328
return 1 0 2331
assign 1 0 2334
assign 1 0 2338
return 1 0 2342
return 1 0 2345
assign 1 0 2348
assign 1 0 2352
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 80036415: return bem_classCallsGet_0();
case -1278441962: return bem_classHeadersGetDirect_0();
case 1233890983: return bem_onceCountGetDirect_0();
case -1253029456: return bem_heowGetDirect_0();
case -1660492811: return bem_returnTypeGetDirect_0();
case -199826941: return bem_msynGetDirect_0();
case 752640732: return bem_nameToIdPathGet_0();
case 1512034580: return bem_lastMethodsSizeGetDirect_0();
case -2049404332: return bem_fieldIteratorGet_0();
case -1965805577: return bem_methodCallsGetDirect_0();
case 2128731348: return bem_headExtGetDirect_0();
case -844377762: return bem_methodCatchGet_0();
case -1153621323: return bem_sourceFileNameGet_0();
case 155727536: return bem_ccMethodsGetDirect_0();
case -1360935346: return bem_csynGetDirect_0();
case -1963450201: return bem_intNpGet_0();
case 1994147939: return bem_emitLib_0();
case 1195479112: return bem_runtimeInitGet_0();
case -21306841: return bem_ccCacheGetDirect_0();
case 672371133: return bem_floatNpGet_0();
case -955176467: return bem_scvpGetDirect_0();
case -1774384173: return bem_randGetDirect_0();
case 1246525343: return bem_copy_0();
case 546251375: return bem_onceCountGet_0();
case -568546853: return bem_buildPropList_0();
case -1223680233: return bem_heonGetDirect_0();
case 1701128611: return bem_classEndGet_0();
case 355548466: return bem_classConfGet_0();
case -1794573020: return bem_lastMethodBodySizeGet_0();
case 2014462765: return bem_inClassGetDirect_0();
case -1981833424: return bem_inFilePathedGetDirect_0();
case 912170343: return bem_falseValueGet_0();
case 1963631625: return bem_mainEndGet_0();
case -266686088: return bem_lastMethodBodySizeGetDirect_0();
case -1803893565: return bem_instanceNotEqualGet_0();
case -1968612821: return bem_buildCreate_0();
case 495991554: return bem_methodCatchGetDirect_0();
case 453387577: return bem_shlibeGet_0();
case -1501728727: return bem_floatNpGetDirect_0();
case 1914514147: return bem_afterCast_0();
case -1963287770: return bem_idToNamePathGetDirect_0();
case -1618181095: return bem_objectCcGet_0();
case -71637796: return bem_intNpGetDirect_0();
case 203930334: return bem_classHeadBodyGetDirect_0();
case -1569137248: return bem_baseSmtdDecGet_0();
case 878091655: return bem_instanceEqualGet_0();
case 1311114940: return bem_maxSpillArgsLenGet_0();
case 634917601: return bem_boolNpGet_0();
case -833893835: return bem_libEmitNameGet_0();
case 1448453145: return bem_lineCountGet_0();
case 353423613: return bem_trueValueGetDirect_0();
case -1154573828: return bem_heopGet_0();
case -849417772: return bem_setOutputTimeGetDirect_0();
case 834974873: return bem_once_0();
case -950723937: return bem_deowGet_0();
case 1644468992: return bem_objectNpGet_0();
case -1160930852: return bem_cnodeGetDirect_0();
case -1759370483: return bem_beginNs_0();
case -671361255: return bem_onceDecsGetDirect_0();
case -677880994: return bem_preClassGet_0();
case -842081223: return bem_emitLangGet_0();
case 1264368313: return bem_classEmitsGetDirect_0();
case -2069212926: return bem_callNamesGetDirect_0();
case -19560021: return bem_fileExtGetDirect_0();
case 2051591602: return bem_cnodeGet_0();
case 1985347066: return bem_libEmitNameGetDirect_0();
case 248294284: return bem_smnlcsGetDirect_0();
case 1522977325: return bem_mainInClassGet_0();
case -1481120: return bem_hashGet_0();
case 172640264: return bem_stringNpGetDirect_0();
case 969122546: return bem_maxDynArgsGetDirect_0();
case -121898153: return bem_instanceEqualGetDirect_0();
case 1090384071: return bem_writeBET_0();
case 1319001609: return bem_classesInDepthOrderGet_0();
case -1781488090: return bem_buildInitial_0();
case -1882407318: return bem_ntypesGet_0();
case -283205576: return bem_overrideMtdDecGet_0();
case -1151122392: return bem_serializeToString_0();
case -138374155: return bem_nativeCSlotsGetDirect_0();
case -1787706936: return bem_typeDecGet_0();
case 1600953285: return bem_saveSyns_0();
case -149985636: return bem_parentConfGet_0();
case 1971073283: return bem_loadIds_0();
case -479949239: return bem_lineCountGetDirect_0();
case 1216427283: return bem_heowGet_0();
case 1600637036: return bem_heonGet_0();
case -260016569: return bem_new_0();
case -179169425: return bem_exceptDecGetDirect_0();
case 247244319: return bem_lastCallGet_0();
case -1763581287: return bem_classHeadersGet_0();
case 1543553352: return bem_propertyDecsGet_0();
case -826038776: return bem_shlibeGetDirect_0();
case 629513215: return bem_create_0();
case 1325005685: return bem_qGet_0();
case 1374986220: return bem_ccCacheGet_0();
case 1925505968: return bem_inFilePathedGet_0();
case -1219240461: return bem_msynGet_0();
case 1440739422: return bem_idToNameGet_0();
case 1826423279: return bem_fullLibEmitNameGet_0();
case 1846185190: return bem_fileExtGet_0();
case 1607651413: return bem_randGet_0();
case -516300936: return bem_many_0();
case -2041322689: return bem_onceDecsGet_0();
case -121425639: return bem_classEmitsGet_0();
case -1311613209: return bem_dynMethodsGet_0();
case 837374047: return bem_fullLibEmitNameGetDirect_0();
case 1841075196: return bem_deserializeClassNameGet_0();
case 1076055334: return bem_nameToIdGetDirect_0();
case -31734150: return bem_dynMethodsGetDirect_0();
case 1376159633: return bem_coanyiantReturnsGet_0();
case 1774744776: return bem_ccMethodsGet_0();
case 1409489274: return bem_smnlecsGetDirect_0();
case 268950612: return bem_classesInDepthOrderGetDirect_0();
case -1288777512: return bem_transGetDirect_0();
case -452734639: return bem_nameToIdPathGetDirect_0();
case 520238370: return bem_print_0();
case -1566168767: return bem_methodBodyGet_0();
case 865440274: return bem_lastMethodsSizeGet_0();
case 1260060741: return bem_constGet_0();
case -1906011811: return bem_classNameGet_0();
case 226982491: return bem_deonGetDirect_0();
case -1700654062: return bem_methodBodyGetDirect_0();
case 51201540: return bem_lastMethodsLinesGetDirect_0();
case 834367967: return bem_propertyDecsGetDirect_0();
case -212837501: return bem_headExtGet_0();
case -586347877: return bem_spropDecGet_0();
case -420636718: return bem_callNamesGet_0();
case 181924838: return bem_saveIds_0();
case 861905678: return bem_falseValueGetDirect_0();
case -146507031: return bem_exceptDecGet_0();
case -509474669: return bem_lastMethodBodyLinesGet_0();
case -273667940: return bem_baseMtdDecGet_0();
case 2146615586: return bem_emitLangGetDirect_0();
case 1695553285: return bem_toString_0();
case 1724218028: return bem_nameToIdGet_0();
case 1521839166: return bem_deonGet_0();
case 572556217: return bem_nlGetDirect_0();
case -1158413980: return bem_buildGetDirect_0();
case -845933593: return bem_synEmitPathGetDirect_0();
case 805049377: return bem_inClassGet_0();
case 2137709829: return bem_boolCcGetDirect_0();
case -1773246632: return bem_invpGetDirect_0();
case 40312046: return bem_idToNamePathGet_0();
case 1383546009: return bem_propDecGet_0();
case -1221489348: return bem_trueValueGet_0();
case 1363596807: return bem_toAny_0();
case 27905295: return bem_nullValueGet_0();
case -2126786396: return bem_prepHeaderOutput_0();
case -1126144051: return bem_classHeadBodyGet_0();
case 1934827441: return bem_tagGet_0();
case -555656699: return bem_objectNpGetDirect_0();
case -857317967: return bem_methodsGetDirect_0();
case -578397480: return bem_ntypesGetDirect_0();
case -973374147: return bem_doEmit_0();
case -2021586315: return bem_transGet_0();
case -2126470188: return bem_objectCcGetDirect_0();
case 18744621: return bem_boolNpGetDirect_0();
case 1612179044: return bem_endNs_0();
case 850276246: return bem_heopGetDirect_0();
case -1784818407: return bem_serializeContents_0();
case -323317224: return bem_superCallsGet_0();
case 891707168: return bem_superCallsGetDirect_0();
case -1849076065: return bem_initialDecGet_0();
case -1806453680: return bem_preClassOutput_0();
case 258153758: return bem_constGetDirect_0();
case -499469881: return bem_superNameGet_0();
case 18956663: return bem_deowGetDirect_0();
case 1250439957: return bem_buildClassInfo_0();
case 1920068436: return bem_mainStartGet_0();
case 539964113: return bem_mainOutsideNsGet_0();
case 620713025: return bem_nullValueGetDirect_0();
case -665319302: return bem_scvpGet_0();
case -329032549: return bem_instOfGet_0();
case 2053632457: return bem_synEmitPathGet_0();
case 2016645363: return bem_boolCcGet_0();
case -727421147: return bem_lastCallGetDirect_0();
case -1333636563: return bem_csynGet_0();
case -455711370: return bem_methodCallsGet_0();
case 1553771989: return bem_maxSpillArgsLenGetDirect_0();
case -441332951: return bem_smnlecsGet_0();
case 1496083257: return bem_nativeCSlotsGet_0();
case 1506082444: return bem_methodsGet_0();
case -1638169226: return bem_deopGetDirect_0();
case 2053313156: return bem_returnTypeGet_0();
case 1875004790: return bem_preClassGetDirect_0();
case -1583394924: return bem_mnodeGetDirect_0();
case -883765858: return bem_libEmitPathGet_0();
case 633430235: return bem_setOutputTimeGet_0();
case 294416408: return bem_boolTypeGet_0();
case 2066607592: return bem_smnlcsGet_0();
case 80505915: return bem_fieldNamesGet_0();
case -1598531944: return bem_parentConfGetDirect_0();
case -1319639079: return bem_deopGet_0();
case -1893136051: return bem_instanceNotEqualGetDirect_0();
case 510740763: return bem_echo_0();
case 1415223971: return bem_stringNpGet_0();
case -1118187657: return bem_useDynMethodsGet_0();
case -1336572611: return bem_qGetDirect_0();
case 1842661129: return bem_maxDynArgsGet_0();
case -304688982: return bem_nlGet_0();
case -641930861: return bem_lastMethodBodyLinesGetDirect_0();
case -319884304: return bem_serializationIteratorGet_0();
case -951361758: return bem_buildGet_0();
case -1647044627: return bem_mnodeGet_0();
case 911970070: return bem_lastMethodsLinesGet_0();
case 12210090: return bem_classCallsGetDirect_0();
case 1197659104: return bem_getClassOutput_0();
case -261216024: return bem_instOfGetDirect_0();
case -1150052491: return bem_idToNameGetDirect_0();
case 630175193: return bem_classConfGetDirect_0();
case 1297893564: return bem_libEmitPathGetDirect_0();
case 1641099347: return bem_getLibOutput_0();
case 654534455: return bem_invpGet_0();
case 1754760186: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -361889096: return bem_nullValueSet_1(bevd_0);
case 1493862628: return bem_maxDynArgsSetDirect_1(bevd_0);
case 245779175: return bem_heopSetDirect_1(bevd_0);
case 1773759648: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -899071506: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 925743769: return bem_ccCacheSetDirect_1(bevd_0);
case 2041503820: return bem_floatNpSet_1(bevd_0);
case -1575644728: return bem_intNpSet_1(bevd_0);
case -1942108524: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 989721692: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -503675708: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -162060766: return bem_falseValueSet_1(bevd_0);
case -450964904: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -252196833: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1274490834: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1812248660: return bem_methodsSet_1(bevd_0);
case 2022041279: return bem_msynSetDirect_1(bevd_0);
case 1221767125: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 345339634: return bem_deopSet_1(bevd_0);
case 187291232: return bem_boolCcSetDirect_1(bevd_0);
case 1398337470: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 942701087: return bem_heonSet_1(bevd_0);
case 305880936: return bem_constSet_1(bevd_0);
case 343163904: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1329768815: return bem_superCallsSet_1(bevd_0);
case 791490513: return bem_classesInDepthOrderSet_1(bevd_0);
case 1994024270: return bem_preClassSet_1(bevd_0);
case -462739699: return bem_qSet_1(bevd_0);
case 192438278: return bem_headExtSet_1(bevd_0);
case 51207908: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 978878462: return bem_lastMethodBodySizeSet_1(bevd_0);
case -126662905: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -597911462: return bem_lineCountSetDirect_1(bevd_0);
case -2139347686: return bem_nlSetDirect_1(bevd_0);
case 853722608: return bem_mnodeSet_1(bevd_0);
case -367081752: return bem_nameToIdPathSet_1(bevd_0);
case -1622491216: return bem_methodBodySetDirect_1(bevd_0);
case -52824489: return bem_idToNameSetDirect_1(bevd_0);
case 1113478042: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1003953706: return bem_heonSetDirect_1(bevd_0);
case -85461654: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1664943824: return bem_stringNpSetDirect_1(bevd_0);
case 1413348548: return bem_fileExtSetDirect_1(bevd_0);
case 1445064280: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1934407928: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1727017466: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1405980579: return bem_instOfSet_1(bevd_0);
case 1885014194: return bem_deonSet_1(bevd_0);
case -1559803506: return bem_csynSetDirect_1(bevd_0);
case -198910958: return bem_boolNpSet_1(bevd_0);
case 995929518: return bem_instanceEqualSetDirect_1(bevd_0);
case -662154603: return bem_inFilePathedSetDirect_1(bevd_0);
case 1075962476: return bem_methodCatchSet_1(bevd_0);
case -333584865: return bem_smnlecsSet_1(bevd_0);
case -1057356581: return bem_superCallsSetDirect_1(bevd_0);
case 1830379820: return bem_invpSet_1(bevd_0);
case 1233024916: return bem_cnodeSet_1(bevd_0);
case -472125460: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1573802551: return bem_sameObject_1(bevd_0);
case 796059176: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -935789449: return bem_deowSet_1(bevd_0);
case -1479201792: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -2134107370: return bem_nameToIdSet_1(bevd_0);
case -228195679: return bem_copyTo_1(bevd_0);
case 239863586: return bem_boolNpSetDirect_1(bevd_0);
case 1542840183: return bem_msynSet_1(bevd_0);
case -406133561: return bem_heowSetDirect_1(bevd_0);
case 1533031284: return bem_smnlcsSetDirect_1(bevd_0);
case 835146207: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1031344048: return bem_trueValueSetDirect_1(bevd_0);
case 1830919913: return bem_lastMethodsLinesSet_1(bevd_0);
case -199363867: return bem_fullLibEmitNameSet_1(bevd_0);
case 1955316107: return bem_fileExtSet_1(bevd_0);
case -1078701089: return bem_headExtSetDirect_1(bevd_0);
case 704439319: return bem_propertyDecsSet_1(bevd_0);
case -557111565: return bem_onceDecsSetDirect_1(bevd_0);
case 270596679: return bem_objectNpSetDirect_1(bevd_0);
case -1902563353: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -362724264: return bem_setOutputTimeSet_1(bevd_0);
case 380056381: return bem_mnodeSetDirect_1(bevd_0);
case -1416633773: return bem_propertyDecsSetDirect_1(bevd_0);
case -320915117: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1661973231: return bem_ntypesSet_1(bevd_0);
case 1303666333: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1341964461: return bem_maxDynArgsSet_1(bevd_0);
case 1847518384: return bem_idToNamePathSetDirect_1(bevd_0);
case 150710665: return bem_randSet_1(bevd_0);
case -108287278: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -761725127: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1459652262: return bem_objectNpSet_1(bevd_0);
case 496004891: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 216738391: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1392586967: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -383182953: return bem_scvpSet_1(bevd_0);
case 1892971336: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -740907965: return bem_floatNpSetDirect_1(bevd_0);
case 1074912428: return bem_deonSetDirect_1(bevd_0);
case -2072347930: return bem_classHeadBodySet_1(bevd_0);
case -1081294418: return bem_lineCountSet_1(bevd_0);
case 428946154: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1512301827: return bem_ccCacheSet_1(bevd_0);
case 1005658398: return bem_buildSetDirect_1(bevd_0);
case 1811082774: return bem_onceDecsSet_1(bevd_0);
case 1580000870: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 2069619325: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1632233231: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -1701865597: return bem_heopSet_1(bevd_0);
case -15694464: return bem_methodCatchSetDirect_1(bevd_0);
case 1049358928: return bem_equals_1(bevd_0);
case 1543826887: return bem_buildSet_1(bevd_0);
case -849106920: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 143336558: return bem_inClassSet_1(bevd_0);
case -1051909796: return bem_csynSet_1(bevd_0);
case -1545304414: return bem_instanceEqualSet_1(bevd_0);
case -1805451038: return bem_deopSetDirect_1(bevd_0);
case 29716091: return bem_begin_1(bevd_0);
case 560464774: return bem_heowSet_1(bevd_0);
case -580910278: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 653032052: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -884644191: return bem_nullValueSetDirect_1(bevd_0);
case 253811563: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -1253122165: return bem_idToNamePathSet_1(bevd_0);
case 375921982: return bem_constSetDirect_1(bevd_0);
case 1697979752: return bem_cnodeSetDirect_1(bevd_0);
case -119328487: return bem_ccMethodsSetDirect_1(bevd_0);
case 436013790: return bem_trueValueSet_1(bevd_0);
case 1122576928: return bem_objectCcSet_1(bevd_0);
case -310987252: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 188440393: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1440607164: return bem_parentConfSet_1(bevd_0);
case -1725133819: return bem_objectCcSetDirect_1(bevd_0);
case 506528829: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -439996951: return bem_dynMethodsSetDirect_1(bevd_0);
case -951929577: return bem_defined_1(bevd_0);
case -1616666751: return bem_classHeadBodySetDirect_1(bevd_0);
case -761153528: return bem_dynMethodsSet_1(bevd_0);
case 1172452558: return bem_emitLangSetDirect_1(bevd_0);
case 685317069: return bem_libEmitNameSet_1(bevd_0);
case 1523343000: return bem_sameClass_1(bevd_0);
case 408504379: return bem_methodCallsSet_1(bevd_0);
case -111572750: return bem_falseValueSetDirect_1(bevd_0);
case 273138700: return bem_onceCountSet_1(bevd_0);
case -1144341678: return bem_notEquals_1(bevd_0);
case -395850459: return bem_undefined_1(bevd_0);
case -1606159574: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -2005202313: return bem_ccMethodsSet_1(bevd_0);
case 11223702: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1132667350: return bem_end_1(bevd_0);
case 652227392: return bem_transSet_1(bevd_0);
case 462621647: return bem_def_1(bevd_0);
case 1632372796: return bem_lastCallSet_1(bevd_0);
case -450442959: return bem_ntypesSetDirect_1(bevd_0);
case -200739020: return bem_synEmitPathSet_1(bevd_0);
case 1456536465: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -770277295: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 775340194: return bem_smnlecsSetDirect_1(bevd_0);
case -109180546: return bem_nameToIdSetDirect_1(bevd_0);
case -1752795756: return bem_parentConfSetDirect_1(bevd_0);
case -1386138002: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -429063360: return bem_idToNameSet_1(bevd_0);
case 929098549: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1707475669: return bem_callNamesSet_1(bevd_0);
case -541225887: return bem_nlSet_1(bevd_0);
case -1625671102: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -85945164: return bem_classCallsSetDirect_1(bevd_0);
case 115468921: return bem_exceptDecSet_1(bevd_0);
case 274225403: return bem_classHeadersSet_1(bevd_0);
case -1430533719: return bem_onceCountSetDirect_1(bevd_0);
case -1152586245: return bem_maxSpillArgsLenSet_1(bevd_0);
case 831015921: return bem_classConfSetDirect_1(bevd_0);
case -1445635087: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -192963993: return bem_methodCallsSetDirect_1(bevd_0);
case 605068050: return bem_libEmitPathSet_1(bevd_0);
case -951926936: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 221275419: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 660459075: return bem_intNpSetDirect_1(bevd_0);
case 279269002: return bem_lastMethodsSizeSet_1(bevd_0);
case -1940429677: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1632353878: return bem_undef_1(bevd_0);
case 1980751657: return bem_shlibeSet_1(bevd_0);
case -184684396: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -703273772: return bem_methodBodySet_1(bevd_0);
case -1737646260: return bem_shlibeSetDirect_1(bevd_0);
case 482689426: return bem_otherClass_1(bevd_0);
case 521828142: return bem_setOutputTimeSetDirect_1(bevd_0);
case -2132039974: return bem_nativeCSlotsSet_1(bevd_0);
case -1088754113: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1909373597: return bem_transSetDirect_1(bevd_0);
case -2003321362: return bem_libEmitNameSetDirect_1(bevd_0);
case -491486505: return bem_emitLangSet_1(bevd_0);
case -1512005598: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 275328152: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 7609893: return bem_classCallsSet_1(bevd_0);
case 138455881: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1675184841: return bem_lastCallSetDirect_1(bevd_0);
case 757142161: return bem_returnTypeSetDirect_1(bevd_0);
case 45497442: return bem_randSetDirect_1(bevd_0);
case -1149023819: return bem_classEmitsSetDirect_1(bevd_0);
case 320742165: return bem_stringNpSet_1(bevd_0);
case 1947215970: return bem_deowSetDirect_1(bevd_0);
case -1294149975: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 118692631: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -23054072: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1441432622: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 58982469: return bem_methodsSetDirect_1(bevd_0);
case -1430178609: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -892750554: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -747947725: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 223461373: return bem_instOfSetDirect_1(bevd_0);
case -648943571: return bem_instanceNotEqualSet_1(bevd_0);
case 1803658040: return bem_smnlcsSet_1(bevd_0);
case -769696169: return bem_classEmitsSet_1(bevd_0);
case -2000647991: return bem_invpSetDirect_1(bevd_0);
case 1540517734: return bem_synEmitPathSetDirect_1(bevd_0);
case -2112752268: return bem_inFilePathedSet_1(bevd_0);
case 310115535: return bem_boolCcSet_1(bevd_0);
case -924139841: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1943740753: return bem_inClassSetDirect_1(bevd_0);
case -1605087258: return bem_preClassSetDirect_1(bevd_0);
case -1355561103: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1997751310: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1233250267: return bem_libEmitPathSetDirect_1(bevd_0);
case 2122170094: return bem_otherType_1(bevd_0);
case -484639434: return bem_qSetDirect_1(bevd_0);
case -859518730: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -753793171: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1759935113: return bem_exceptDecSetDirect_1(bevd_0);
case -1281842328: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1012979594: return bem_callNamesSetDirect_1(bevd_0);
case -1533130519: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -998599251: return bem_scvpSetDirect_1(bevd_0);
case 1443081793: return bem_classHeadersSetDirect_1(bevd_0);
case 2033324165: return bem_returnTypeSet_1(bevd_0);
case -1560805052: return bem_classConfSet_1(bevd_0);
case -1177836823: return bem_sameType_1(bevd_0);
case 476621767: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1134278648: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1768894021: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1967117180: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1872811781: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1207013071: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 595016345: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -2045271612: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 518732674: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1018924161: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -42068313: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 308804077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -222561805: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 802263707: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 2072018670: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1518228438: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -357078730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1010026607: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 185369359: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2084764755: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -277637599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1244524360: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -366494025: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 2121739188: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -704710659: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -988800189: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 2139213926: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 482770847: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
