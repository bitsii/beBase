package be;
public class BET_3_2_4_12_IOFileNamedWriters extends BETS_Object {
public BET_3_2_4_12_IOFileNamedWriters() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "default_0", "outputSet_1", "errorSet_1", "exceptionConsoleSet_1", "outputGet_0", "errorGet_0", "exceptionConsoleGet_0" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "output", "error", "exceptionConsole" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_2_4_12_IOFileNamedWriters();
}
}
