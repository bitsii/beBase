package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog extends BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x6C,0x6F,0x67,0x67,0x65,0x64,0x20};
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x20};
public static BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public BEC_2_6_6_SystemObject bevp_sink;
public BEC_2_2_3_IOLog bem_new_3(BEC_2_6_6_SystemObject beva__sink, BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
bevp_sink = beva__sink;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 151*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 152*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 158*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 159*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_2_3_IOLog bem_out_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 165*/ {
beva_msg = (new BEC_2_4_6_TextString(4, bece_BEC_2_2_3_IOLog_bels_0));
} /* Line: 166*/
if (bevp_sink == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 169*/ {
bevp_sink.bemd_1(1146471158, beva_msg);
} /* Line: 170*/
 else /* Line: 171*/ {
beva_msg.bem_print_0();
} /* Line: 172*/
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_1(BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_2_3_IOLog_bels_1));
bem_elog_2(bevt_0_ta_ph, beva_e);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_2(BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_10_SystemExceptions bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_2_3_IOLog_bels_2));
bevt_1_ta_ph = beva_msg.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_ta_ph = bevt_4_ta_ph.bem_tS_1(beva_e);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_log_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 194*/ {
bem_out_1(beva_msg);
} /* Line: 195*/
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_3(BEC_2_4_3_MathInt beva_level, BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_10_SystemExceptions bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_2_3_IOLog_bels_2));
bevt_1_ta_ph = beva_msg.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_ta_ph = bevt_4_ta_ph.bem_tS_1(beva_e);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_log_2(beva_level, bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 204*/ {
bem_out_1(beva_msg);
} /* Line: 205*/
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_debug_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(400));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_info_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(300));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_warn_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(200));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_error_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(100));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_fatal_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(0));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
bem_out_1(beva_msg);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGet_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGet_0() throws Throwable {
return bevp_level;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGet_0() throws Throwable {
return bevp_sink;
} /*method end*/
public BEC_2_2_3_IOLog bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {144, 145, 146, 151, 151, 152, 152, 154, 154, 158, 158, 159, 159, 161, 161, 165, 165, 166, 169, 169, 170, 172, 186, 186, 190, 190, 190, 190, 190, 190, 194, 194, 195, 200, 200, 200, 200, 200, 200, 204, 204, 205, 210, 211, 215, 216, 220, 221, 225, 226, 230, 231, 235, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 27, 32, 33, 34, 36, 37, 43, 48, 49, 50, 52, 53, 58, 63, 64, 66, 71, 72, 75, 81, 82, 91, 92, 93, 94, 95, 96, 101, 106, 107, 117, 118, 119, 120, 121, 122, 127, 132, 133, 139, 140, 145, 146, 151, 152, 157, 158, 163, 164, 168, 172, 175, 179, 182, 186, 189};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 144 18
assign 1 145 19
assign 1 146 20
assign 1 151 27
lesserEquals 1 151 32
assign 1 152 33
new 0 152 33
return 1 152 34
assign 1 154 36
new 0 154 36
return 1 154 37
assign 1 158 43
lesserEquals 1 158 48
assign 1 159 49
new 0 159 49
return 1 159 50
assign 1 161 52
new 0 161 52
return 1 161 53
assign 1 165 58
undef 1 165 63
assign 1 166 64
new 0 166 64
assign 1 169 66
def 1 169 71
out 1 170 72
print 0 172 75
assign 1 186 81
new 0 186 81
elog 2 186 82
assign 1 190 91
new 0 190 91
assign 1 190 92
add 1 190 92
assign 1 190 93
new 0 190 93
assign 1 190 94
tS 1 190 94
assign 1 190 95
add 1 190 95
log 1 190 96
assign 1 194 101
lesserEquals 1 194 106
out 1 195 107
assign 1 200 117
new 0 200 117
assign 1 200 118
add 1 200 118
assign 1 200 119
new 0 200 119
assign 1 200 120
tS 1 200 120
assign 1 200 121
add 1 200 121
log 2 200 122
assign 1 204 127
lesserEquals 1 204 132
out 1 205 133
assign 1 210 139
new 0 210 139
log 2 211 140
assign 1 215 145
new 0 215 145
log 2 216 146
assign 1 220 151
new 0 220 151
log 2 221 152
assign 1 225 157
new 0 225 157
log 2 226 158
assign 1 230 163
new 0 230 163
log 2 231 164
out 1 235 168
return 1 0 172
assign 1 0 175
return 1 0 179
assign 1 0 182
return 1 0 186
assign 1 0 189
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1954876952: return bem_iteratorGet_0();
case 1069615902: return bem_copy_0();
case 1428575040: return bem_toString_0();
case -1629771427: return bem_create_0();
case 1524122585: return bem_will_0();
case -43191778: return bem_hashGet_0();
case -935641853: return bem_print_0();
case -839783539: return bem_levelGet_0();
case 1356338585: return bem_new_0();
case -1350191606: return bem_outputLevelGet_0();
case 278884176: return bem_sinkGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1073716984: return bem_equals_1(bevd_0);
case 659667749: return bem_outputLevelSet_1(bevd_0);
case -179556288: return bem_undef_1(bevd_0);
case 544595500: return bem_warn_1((BEC_2_4_6_TextString) bevd_0);
case -1366175642: return bem_def_1(bevd_0);
case -53376444: return bem_elog_1(bevd_0);
case 1478644823: return bem_levelSet_1(bevd_0);
case -1712468896: return bem_debug_1((BEC_2_4_6_TextString) bevd_0);
case 111505242: return bem_sinkSet_1(bevd_0);
case 1388413072: return bem_copyTo_1(bevd_0);
case 1146471158: return bem_out_1((BEC_2_4_6_TextString) bevd_0);
case -946351099: return bem_print_1(bevd_0);
case -62292977: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case 1515791838: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case 1056734265: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case 1923019325: return bem_error_1((BEC_2_4_6_TextString) bevd_0);
case -1199938797: return bem_fatal_1((BEC_2_4_6_TextString) bevd_0);
case 484780340: return bem_notEquals_1(bevd_0);
case 1206512915: return bem_info_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -570336382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -105829285: return bem_elog_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1111008594: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1050001109: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -548042918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 159189467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1928363307: return bem_new_3(bevd_0, bevd_1, bevd_2);
case -1047989282: return bem_elog_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_3_IOLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
