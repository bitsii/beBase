package be;
/* IO:File: source/build/Pass10.be */
public final class BEC_3_5_5_6_BuildVisitPass10 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass10() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x30};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x30,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_1 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_2 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_3 = {0x61,0x6E,0x63,0x68,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
public static BEC_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;

public static BET_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;

public BEC_2_6_6_SystemObject bem_condCall_2(BEC_2_6_6_SystemObject beva_condany, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_acc = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_5_4_BuildCall bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_ta_ph = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_cnode.bemd_1(-1834851058, bevt_0_ta_ph);
bevt_1_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_cnode.bemd_1(266416068, bevt_1_ta_ph);
bevl_acc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_acc.bemd_1(266416068, bevt_2_ta_ph);
bevl_acc.bemd_1(-1834851058, beva_condany);
bevl_cnode.bemd_1(823237209, bevl_acc);
bevt_3_ta_ph = bevl_cnode.bemd_0(-1120999119);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_0));
bevt_3_ta_ph.bemd_1(-353514630, bevt_4_ta_ph);
bevl_nnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nnode.bemd_1(266416068, beva_value);
bevl_cnode.bemd_1(823237209, bevl_nnode);
return bevl_cnode;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_anchor = null;
BEC_2_6_6_SystemObject bevl_condany = null;
BEC_2_6_6_SystemObject bevl_cvnp = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_rinode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_BuildNode bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_5_4_BuildNode bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_5_4_BuildNode bevt_77_ta_ph = null;
bevt_4_ta_ph = beva_node.bem_typenameGet_0();
bevt_5_ta_ph = bevp_ntypes.bem_PARENSGet_0();
if (bevt_4_ta_ph.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 37*/ {
bevt_8_ta_ph = beva_node.bem_containedGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_lengthGet_0();
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_7_ta_ph.bevi_int == bevt_9_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 37*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 37*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 37*/
 else /* Line: 37*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 37*/ {
bevt_13_ta_ph = beva_node.bem_containedGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_firstGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(1182514009);
bevt_14_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(-1291367990, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 37*/
 else /* Line: 37*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 37*/ {
bevt_16_ta_ph = beva_node.bem_containedGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bem_firstGet_0();
beva_node.bem_takeContents_1((BEC_2_5_4_BuildNode) bevt_15_ta_ph );
return beva_node;
} /* Line: 39*/
bevt_18_ta_ph = beva_node.bem_typenameGet_0();
bevt_19_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_18_ta_ph.bevi_int == bevt_19_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_20_ta_ph = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_20_ta_ph);
beva_node.bem_syncVariable_1(this);
} /* Line: 44*/
bevt_22_ta_ph = beva_node.bem_typenameGet_0();
bevt_23_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_22_ta_ph.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_26_ta_ph = beva_node.bem_heldGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(-682481326);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(-1291367990, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 47*/ {
bevt_30_ta_ph = beva_node.bem_heldGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(-682481326);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_2));
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(-1291367990, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 47*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 47*/
 else /* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 47*/ {
bevl_anchor = beva_node.bem_anchorGet_0();
bevl_condany = bevl_anchor.bemd_0(-1915814582);
if (bevl_condany == null) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 52*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_3));
bevl_condany = bevl_anchor.bemd_2(280063987, bevt_33_ta_ph, bevp_build);
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
bevl_condany.bemd_1(2082904551, bevt_34_ta_ph);
bevl_cvnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_4));
bevl_cvnp.bemd_1(849816558, bevt_35_ta_ph);
bevl_condany.bemd_1(1005769644, bevl_cvnp);
bevl_anchor.bemd_1(1554656300, bevl_condany);
} /* Line: 58*/
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_36_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(266416068, bevt_36_ta_ph);
bevl_inode.bemd_1(693562905, beva_node);
bevl_rinode = bevl_inode;
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(693562905, beva_node);
bevt_37_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(266416068, bevt_37_ta_ph);
bevl_inode.bemd_1(823237209, bevl_pnode);
bevt_39_ta_ph = beva_node.bem_containedGet_0();
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevl_pnode.bemd_1(823237209, bevt_38_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(693562905, beva_node);
bevt_40_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(266416068, bevt_40_ta_ph);
bevl_inode.bemd_1(823237209, bevl_bnode);
bevt_43_ta_ph = beva_node.bem_heldGet_0();
bevt_42_ta_ph = bevt_43_ta_ph.bemd_0(-682481326);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(-1291367990, bevt_44_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 79*/ {
bevt_46_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_45_ta_ph = bem_condCall_2(bevl_condany, bevt_46_ta_ph);
bevl_bnode.bemd_1(823237209, bevt_45_ta_ph);
} /* Line: 80*/
 else /* Line: 82*/ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(693562905, beva_node);
bevt_47_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(266416068, bevt_47_ta_ph);
bevl_inode.bemd_1(1554656300, bevl_condany);
bevl_bnode.bemd_1(823237209, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(693562905, beva_node);
bevt_48_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(266416068, bevt_48_ta_ph);
bevl_inode.bemd_1(823237209, bevl_pnode);
bevt_49_ta_ph = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(823237209, bevt_49_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(693562905, beva_node);
bevt_50_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(266416068, bevt_50_ta_ph);
bevl_inode.bemd_1(823237209, bevl_bnode);
bevt_52_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_51_ta_ph = bem_condCall_2(bevl_condany, bevt_52_ta_ph);
bevl_bnode.bemd_1(823237209, bevt_51_ta_ph);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(693562905, beva_node);
bevt_53_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(266416068, bevt_53_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(693562905, beva_node);
bevt_54_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(266416068, bevt_54_ta_ph);
bevt_56_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_55_ta_ph = bem_condCall_2(bevl_condany, bevt_56_ta_ph);
bevl_bnode.bemd_1(823237209, bevt_55_ta_ph);
bevl_enode.bemd_1(823237209, bevl_bnode);
bevl_inode.bemd_1(823237209, bevl_enode);
} /* Line: 109*/
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(693562905, beva_node);
bevt_57_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(266416068, bevt_57_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(693562905, beva_node);
bevt_58_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(266416068, bevt_58_ta_ph);
bevl_rinode.bemd_1(823237209, bevl_enode);
bevl_enode.bemd_1(823237209, bevl_bnode);
bevt_61_ta_ph = beva_node.bem_heldGet_0();
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(-682481326);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_59_ta_ph = bevt_60_ta_ph.bemd_1(-1291367990, bevt_62_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 121*/ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(693562905, beva_node);
bevt_63_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(266416068, bevt_63_ta_ph);
bevl_inode.bemd_1(1554656300, bevl_condany);
bevl_bnode.bemd_1(823237209, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(693562905, beva_node);
bevt_64_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(266416068, bevt_64_ta_ph);
bevl_inode.bemd_1(823237209, bevl_pnode);
bevt_65_ta_ph = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(823237209, bevt_65_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(693562905, beva_node);
bevt_66_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(266416068, bevt_66_ta_ph);
bevl_inode.bemd_1(823237209, bevl_bnode);
bevt_68_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_67_ta_ph = bem_condCall_2(bevl_condany, bevt_68_ta_ph);
bevl_bnode.bemd_1(823237209, bevt_67_ta_ph);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(693562905, beva_node);
bevt_69_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(266416068, bevt_69_ta_ph);
bevl_inode.bemd_1(823237209, bevl_enode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(693562905, beva_node);
bevt_70_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(266416068, bevt_70_ta_ph);
bevt_72_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_71_ta_ph = bem_condCall_2(bevl_condany, bevt_72_ta_ph);
bevl_bnode.bemd_1(823237209, bevt_71_ta_ph);
bevl_enode.bemd_1(823237209, bevl_bnode);
} /* Line: 147*/
 else /* Line: 148*/ {
bevt_74_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_73_ta_ph = bem_condCall_2(bevl_condany, bevt_74_ta_ph);
bevl_bnode.bemd_1(823237209, bevt_73_ta_ph);
} /* Line: 149*/
bevl_anchor.bemd_1(-308330323, bevl_rinode);
beva_node.bem_containedSet_1(null);
bevt_75_ta_ph = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_75_ta_ph);
beva_node.bem_heldSet_1(bevl_condany);
beva_node.bem_syncAddVariable_0();
bevt_76_ta_ph = bevl_rinode.bemd_0(1331008492);
return (BEC_2_5_4_BuildNode) bevt_76_ta_ph;
} /* Line: 158*/
bevt_77_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_77_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {22, 23, 23, 24, 24, 25, 26, 26, 27, 28, 29, 29, 29, 30, 31, 32, 33, 37, 37, 37, 37, 37, 37, 37, 37, 37, 0, 0, 0, 37, 37, 37, 37, 37, 0, 0, 0, 38, 38, 38, 39, 42, 42, 42, 42, 43, 43, 44, 47, 47, 47, 47, 47, 47, 47, 47, 0, 47, 47, 47, 47, 0, 0, 0, 0, 0, 49, 50, 52, 52, 53, 53, 54, 54, 55, 56, 56, 57, 58, 61, 62, 62, 63, 65, 67, 68, 69, 69, 70, 72, 72, 72, 74, 75, 76, 76, 77, 79, 79, 79, 79, 80, 80, 80, 84, 85, 86, 86, 87, 88, 90, 91, 92, 92, 93, 94, 94, 95, 96, 97, 97, 98, 99, 99, 99, 101, 102, 103, 103, 104, 105, 106, 106, 107, 107, 107, 108, 109, 112, 113, 114, 114, 115, 116, 117, 117, 118, 119, 121, 121, 121, 121, 122, 123, 124, 124, 125, 126, 128, 129, 130, 130, 131, 132, 132, 133, 134, 135, 135, 136, 137, 137, 137, 139, 140, 141, 141, 142, 143, 144, 145, 145, 146, 146, 146, 147, 149, 149, 149, 153, 154, 155, 155, 156, 157, 158, 158, 161, 161};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 130, 131, 132, 137, 138, 139, 140, 141, 146, 147, 150, 154, 157, 158, 159, 160, 161, 163, 166, 170, 173, 174, 175, 176, 178, 179, 180, 185, 186, 187, 188, 190, 191, 192, 197, 198, 199, 200, 201, 203, 206, 207, 208, 209, 211, 214, 218, 221, 225, 228, 229, 230, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 269, 270, 271, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 360, 361, 362, 364, 365, 366, 367, 368, 369, 370, 371, 373, 374};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 22 25
new 1 22 25
assign 1 23 26
new 0 23 26
heldSet 1 23 27
assign 1 24 28
CALLGet 0 24 28
typenameSet 1 24 29
assign 1 25 30
new 1 25 30
assign 1 26 31
VARGet 0 26 31
typenameSet 1 26 32
heldSet 1 27 33
addValue 1 28 34
assign 1 29 35
heldGet 0 29 35
assign 1 29 36
new 0 29 36
nameSet 1 29 37
assign 1 30 38
new 1 30 38
typenameSet 1 31 39
addValue 1 32 40
return 1 33 41
assign 1 37 130
typenameGet 0 37 130
assign 1 37 131
PARENSGet 0 37 131
assign 1 37 132
equals 1 37 137
assign 1 37 138
containedGet 0 37 138
assign 1 37 139
lengthGet 0 37 139
assign 1 37 140
new 0 37 140
assign 1 37 141
equals 1 37 146
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 37 157
containedGet 0 37 157
assign 1 37 158
firstGet 0 37 158
assign 1 37 159
typenameGet 0 37 159
assign 1 37 160
PARENSGet 0 37 160
assign 1 37 161
equals 1 37 161
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 38 173
containedGet 0 38 173
assign 1 38 174
firstGet 0 38 174
takeContents 1 38 175
return 1 39 176
assign 1 42 178
typenameGet 0 42 178
assign 1 42 179
IDGet 0 42 179
assign 1 42 180
equals 1 42 185
assign 1 43 186
VARGet 0 43 186
typenameSet 1 43 187
syncVariable 1 44 188
assign 1 47 190
typenameGet 0 47 190
assign 1 47 191
CALLGet 0 47 191
assign 1 47 192
equals 1 47 197
assign 1 47 198
heldGet 0 47 198
assign 1 47 199
nameGet 0 47 199
assign 1 47 200
new 0 47 200
assign 1 47 201
equals 1 47 201
assign 1 0 203
assign 1 47 206
heldGet 0 47 206
assign 1 47 207
nameGet 0 47 207
assign 1 47 208
new 0 47 208
assign 1 47 209
equals 1 47 209
assign 1 0 211
assign 1 0 214
assign 1 0 218
assign 1 0 221
assign 1 0 225
assign 1 49 228
anchorGet 0 49 228
assign 1 50 229
condanyGet 0 50 229
assign 1 52 230
undef 1 52 235
assign 1 53 236
new 0 53 236
assign 1 53 237
tmpVar 2 53 237
assign 1 54 238
new 0 54 238
isTypedSet 1 54 239
assign 1 55 240
new 0 55 240
assign 1 56 241
new 0 56 241
fromString 1 56 242
namepathSet 1 57 243
condanySet 1 58 244
assign 1 61 246
new 1 61 246
assign 1 62 247
IFGet 0 62 247
typenameSet 1 62 248
copyLoc 1 63 249
assign 1 65 250
assign 1 67 251
new 1 67 251
copyLoc 1 68 252
assign 1 69 253
PARENSGet 0 69 253
typenameSet 1 69 254
addValue 1 70 255
assign 1 72 256
containedGet 0 72 256
assign 1 72 257
firstGet 0 72 257
addValue 1 72 258
assign 1 74 259
new 1 74 259
copyLoc 1 75 260
assign 1 76 261
BRACESGet 0 76 261
typenameSet 1 76 262
addValue 1 77 263
assign 1 79 264
heldGet 0 79 264
assign 1 79 265
nameGet 0 79 265
assign 1 79 266
new 0 79 266
assign 1 79 267
equals 1 79 267
assign 1 80 269
TRUEGet 0 80 269
assign 1 80 270
condCall 2 80 270
addValue 1 80 271
assign 1 84 274
new 1 84 274
copyLoc 1 85 275
assign 1 86 276
IFGet 0 86 276
typenameSet 1 86 277
condanySet 1 87 278
addValue 1 88 279
assign 1 90 280
new 1 90 280
copyLoc 1 91 281
assign 1 92 282
PARENSGet 0 92 282
typenameSet 1 92 283
addValue 1 93 284
assign 1 94 285
secondGet 0 94 285
addValue 1 94 286
assign 1 95 287
new 1 95 287
copyLoc 1 96 288
assign 1 97 289
BRACESGet 0 97 289
typenameSet 1 97 290
addValue 1 98 291
assign 1 99 292
TRUEGet 0 99 292
assign 1 99 293
condCall 2 99 293
addValue 1 99 294
assign 1 101 295
new 1 101 295
copyLoc 1 102 296
assign 1 103 297
ELSEGet 0 103 297
typenameSet 1 103 298
assign 1 104 299
new 1 104 299
copyLoc 1 105 300
assign 1 106 301
BRACESGet 0 106 301
typenameSet 1 106 302
assign 1 107 303
FALSEGet 0 107 303
assign 1 107 304
condCall 2 107 304
addValue 1 107 305
addValue 1 108 306
addValue 1 109 307
assign 1 112 309
new 1 112 309
copyLoc 1 113 310
assign 1 114 311
ELSEGet 0 114 311
typenameSet 1 114 312
assign 1 115 313
new 1 115 313
copyLoc 1 116 314
assign 1 117 315
BRACESGet 0 117 315
typenameSet 1 117 316
addValue 1 118 317
addValue 1 119 318
assign 1 121 319
heldGet 0 121 319
assign 1 121 320
nameGet 0 121 320
assign 1 121 321
new 0 121 321
assign 1 121 322
equals 1 121 322
assign 1 122 324
new 1 122 324
copyLoc 1 123 325
assign 1 124 326
IFGet 0 124 326
typenameSet 1 124 327
condanySet 1 125 328
addValue 1 126 329
assign 1 128 330
new 1 128 330
copyLoc 1 129 331
assign 1 130 332
PARENSGet 0 130 332
typenameSet 1 130 333
addValue 1 131 334
assign 1 132 335
secondGet 0 132 335
addValue 1 132 336
assign 1 133 337
new 1 133 337
copyLoc 1 134 338
assign 1 135 339
BRACESGet 0 135 339
typenameSet 1 135 340
addValue 1 136 341
assign 1 137 342
TRUEGet 0 137 342
assign 1 137 343
condCall 2 137 343
addValue 1 137 344
assign 1 139 345
new 1 139 345
copyLoc 1 140 346
assign 1 141 347
ELSEGet 0 141 347
typenameSet 1 141 348
addValue 1 142 349
assign 1 143 350
new 1 143 350
copyLoc 1 144 351
assign 1 145 352
BRACESGet 0 145 352
typenameSet 1 145 353
assign 1 146 354
FALSEGet 0 146 354
assign 1 146 355
condCall 2 146 355
addValue 1 146 356
addValue 1 147 357
assign 1 149 360
FALSEGet 0 149 360
assign 1 149 361
condCall 2 149 361
addValue 1 149 362
beforeInsert 1 153 364
containedSet 1 154 365
assign 1 155 366
VARGet 0 155 366
typenameSet 1 155 367
heldSet 1 156 368
syncAddVariable 0 157 369
assign 1 158 370
nextDescendGet 0 158 370
return 1 158 371
assign 1 161 373
nextDescendGet 0 161 373
return 1 161 374
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1116049816: return bem_toString_0();
case 612951226: return bem_transGet_0();
case 2021446686: return bem_create_0();
case -1834362432: return bem_constGet_0();
case 201436634: return bem_print_0();
case 1113331113: return bem_ntypesGet_0();
case -1602239310: return bem_new_0();
case -907463432: return bem_copy_0();
case 1407534539: return bem_iteratorGet_0();
case -1827671744: return bem_hashGet_0();
case -1513708818: return bem_buildGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -471447072: return bem_notEquals_1(bevd_0);
case -1508695202: return bem_constSet_1(bevd_0);
case 505990086: return bem_undef_1(bevd_0);
case -1812901017: return bem_def_1(bevd_0);
case -1463414220: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1992355075: return bem_ntypesSet_1(bevd_0);
case 516373942: return bem_buildSet_1(bevd_0);
case -170830352: return bem_end_1(bevd_0);
case -1291367990: return bem_equals_1(bevd_0);
case 1989503752: return bem_copyTo_1(bevd_0);
case 1729413977: return bem_print_1(bevd_0);
case -2051950937: return bem_transSet_1(bevd_0);
case 702563854: return bem_begin_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -994154646: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1018458287: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1214519122: return bem_condCall_2(bevd_0, bevd_1);
case 241691596: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -993790175: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass10_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass10_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass10();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst = (BEC_3_5_5_6_BuildVisitPass10) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;
}
}
