package be;
/* IO:File: source/build/EmitData.be */
public final class BEC_2_5_13_BuildPropertyIndex extends BEC_2_6_6_SystemObject {
public BEC_2_5_13_BuildPropertyIndex() { }
private static byte[] becc_BEC_2_5_13_BuildPropertyIndex_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_BEC_2_5_13_BuildPropertyIndex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static BEC_2_5_13_BuildPropertyIndex bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildPtySyn bevp_psyn;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_13_BuildPropertyIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildPtySyn beva__psyn) throws Throwable {
bevp_syn = beva__syn;
bevp_psyn = beva__psyn;
bevp_origin = bevp_psyn.bem_originGet_0();
bevp_name = bevp_psyn.bem_nameGet_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_origin.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_4_tmpany_phold = bem_sameClass_1(beva_x);
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 87 */
bevt_7_tmpany_phold = beva_x.bemd_0(1910150126);
bevt_6_tmpany_phold = bevp_origin.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_9_tmpany_phold = beva_x.bemd_0(1272147718);
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
 else  /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 88 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 89 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_psynGet_0() throws Throwable {
return bevp_psyn;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_psynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_psyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {75, 76, 77, 78, 83, 83, 83, 83, 87, 87, 0, 87, 87, 87, 0, 0, 87, 87, 88, 88, 88, 88, 0, 0, 0, 89, 89, 91, 91, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 15, 16, 23, 24, 25, 26, 41, 46, 47, 50, 51, 56, 57, 60, 64, 65, 67, 68, 70, 71, 73, 76, 80, 83, 84, 86, 87, 90, 93, 97, 100, 104, 107, 111, 114};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 75 13
assign 1 76 14
assign 1 77 15
originGet 0 77 15
assign 1 78 16
nameGet 0 78 16
assign 1 83 23
toString 0 83 23
assign 1 83 24
add 1 83 24
assign 1 83 25
hashGet 0 83 25
return 1 83 26
assign 1 87 41
undef 1 87 46
assign 1 0 47
assign 1 87 50
sameClass 1 87 50
assign 1 87 51
not 0 87 56
assign 1 0 57
assign 1 0 60
assign 1 87 64
new 0 87 64
return 1 87 65
assign 1 88 67
originGet 0 88 67
assign 1 88 68
equals 1 88 68
assign 1 88 70
nameGet 0 88 70
assign 1 88 71
equals 1 88 71
assign 1 0 73
assign 1 0 76
assign 1 0 80
assign 1 89 83
new 0 89 83
return 1 89 84
assign 1 91 86
new 0 91 86
return 1 91 87
return 1 0 90
assign 1 0 93
return 1 0 97
assign 1 0 100
return 1 0 104
assign 1 0 107
return 1 0 111
assign 1 0 114
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1704001450: return bem_serializationIteratorGet_0();
case -868754815: return bem_serializeContents_0();
case -1615155660: return bem_sourceFileNameGet_0();
case 1910150126: return bem_originGet_0();
case 1724993772: return bem_many_0();
case -1108389163: return bem_synGet_0();
case -1207227016: return bem_toAny_0();
case 1107063436: return bem_create_0();
case 331067077: return bem_iteratorGet_0();
case 1586265763: return bem_copy_0();
case 1550782506: return bem_print_0();
case 1618197244: return bem_new_0();
case 755005070: return bem_echo_0();
case 353744263: return bem_once_0();
case 1272147718: return bem_nameGet_0();
case -1674644863: return bem_serializeToString_0();
case 2089277173: return bem_classNameGet_0();
case 836604081: return bem_tagGet_0();
case -2035802034: return bem_hashGet_0();
case -1432966592: return bem_deserializeClassNameGet_0();
case -2079261808: return bem_toString_0();
case -338744131: return bem_psynGet_0();
case -1144635038: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1292274364: return bem_undefined_1(bevd_0);
case 1156110170: return bem_synSet_1(bevd_0);
case 567619203: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2018158572: return bem_sameType_1(bevd_0);
case 1053963189: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -864903677: return bem_otherType_1(bevd_0);
case -1182880634: return bem_nameSet_1(bevd_0);
case -1538430266: return bem_originSet_1(bevd_0);
case -467831865: return bem_otherClass_1(bevd_0);
case -955519709: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1743252117: return bem_sameObject_1(bevd_0);
case 729465196: return bem_equals_1(bevd_0);
case -842835715: return bem_psynSet_1(bevd_0);
case 1975786452: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1285524271: return bem_sameClass_1(bevd_0);
case 1820941401: return bem_def_1(bevd_0);
case -102763151: return bem_defined_1(bevd_0);
case 894987079: return bem_undef_1(bevd_0);
case 1181026029: return bem_copyTo_1(bevd_0);
case -1690226246: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1713973958: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1241720452: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1527927145: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1067491989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2041527697: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2020198439: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildPtySyn) bevd_1);
case 1632202498: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1814064163: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_5_13_BuildPropertyIndex_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_13_BuildPropertyIndex_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_13_BuildPropertyIndex();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_13_BuildPropertyIndex.bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst = (BEC_2_5_13_BuildPropertyIndex) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_13_BuildPropertyIndex.bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst;
}
}
