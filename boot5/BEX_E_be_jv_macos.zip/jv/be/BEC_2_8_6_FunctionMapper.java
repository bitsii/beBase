package be;
/* IO:File: source/base/Functions.be */
public final class BEC_2_8_6_FunctionMapper extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_FunctionMapper() { }
private static byte[] becc_BEC_2_8_6_FunctionMapper_clname = {0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x3A,0x4D,0x61,0x70,0x70,0x65,0x72};
private static byte[] becc_BEC_2_8_6_FunctionMapper_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_8_6_FunctionMapper bece_BEC_2_8_6_FunctionMapper_bevs_inst;
public BEC_2_8_6_FunctionMapper bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapCopy_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemMethod beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = beva_input.bemd_0(-1980796873);
bevt_0_tmpany_phold = bem_map_2(bevt_1_tmpany_phold, beva_action);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_map_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemObject beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_input.bemd_0(997723391);
bem_mapIterator_2(bevt_0_tmpany_phold, (BEC_2_6_6_SystemMethod) beva_action );
return beva_input;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_mapIterator_2(BEC_2_6_6_SystemObject beva_iter, BEC_2_6_6_SystemMethod beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[2];
while (true)
 /* Line: 24 */ {
bevt_0_tmpany_phold = beva_iter.bemd_0(863439583);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 24 */ {
bevt_2_tmpany_phold = beva_iter.bemd_0(-1141859925);
bevd_x[0] = bevt_2_tmpany_phold;
bevt_1_tmpany_phold = beva_action.bem_forwardCall_2(new BEC_2_4_6_TextString("apply".getBytes("UTF-8")), (new BEC_2_9_4_ContainerList(bevd_x, 1)).bem_copy_0());
beva_iter.bemd_1(-313919489, bevt_1_tmpany_phold);
} /* Line: 25 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15, 15, 15, 19, 19, 20, 24, 25, 25, 25};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 23, 24, 25, 34, 36, 37, 39};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 15 17
copy 0 15 17
assign 1 15 18
map 2 15 18
return 1 15 19
assign 1 19 23
iteratorGet 0 19 23
mapIterator 2 19 24
return 1 20 25
assign 1 24 34
hasNextGet 0 24 34
assign 1 25 36
nextGet 0 25 36
assign 1 25 37
apply 1 25 37
currentSet 1 25 39
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -302965453: return bem_tagGet_0();
case 301206433: return bem_echo_0();
case 1452879382: return bem_sourceFileNameGet_0();
case 1732876397: return bem_serializationIteratorGet_0();
case -803388239: return bem_deserializeClassNameGet_0();
case 737771364: return bem_toString_0();
case -1980796873: return bem_copy_0();
case -364483975: return bem_default_0();
case 366164054: return bem_serializeContents_0();
case 997723391: return bem_iteratorGet_0();
case 1023783415: return bem_create_0();
case 2033657832: return bem_hashGet_0();
case 737353003: return bem_new_0();
case -420235024: return bem_classNameGet_0();
case 482356666: return bem_toAny_0();
case 1222310146: return bem_many_0();
case -1866917929: return bem_serializeToString_0();
case 1314576819: return bem_print_0();
case 1775715094: return bem_once_0();
case -70500062: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1732568943: return bem_sameObject_1(bevd_0);
case 1732014863: return bem_equals_1(bevd_0);
case -369272378: return bem_undefined_1(bevd_0);
case 1452810576: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 808158717: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1112750632: return bem_otherType_1(bevd_0);
case 228693515: return bem_notEquals_1(bevd_0);
case 254712574: return bem_def_1(bevd_0);
case 1210677960: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1107846755: return bem_otherClass_1(bevd_0);
case 1735205112: return bem_sameType_1(bevd_0);
case -10325606: return bem_undef_1(bevd_0);
case 235706821: return bem_defined_1(bevd_0);
case -1078688343: return bem_copyTo_1(bevd_0);
case 1940225088: return bem_sameClass_1(bevd_0);
case 1235111255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1437812444: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -164742720: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -677486738: return bem_mapCopy_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case -1990568085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1590778198: return bem_map_2(bevd_0, bevd_1);
case 1815656517: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2097626536: return bem_mapIterator_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case 1747848637: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -303274357: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -70659423: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_FunctionMapper_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_8_6_FunctionMapper_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_FunctionMapper();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst = (BEC_2_8_6_FunctionMapper) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst;
}
}
