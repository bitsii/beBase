package be;
/* IO:File: source/base/Object.be */
public class BEC_2_6_8_SystemVariadic extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemVariadic() { }
private static byte[] becc_BEC_2_6_8_SystemVariadic_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x56,0x61,0x72,0x69,0x61,0x64,0x69,0x63};
private static byte[] becc_BEC_2_6_8_SystemVariadic_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
public static BEC_2_6_8_SystemVariadic bece_BEC_2_6_8_SystemVariadic_bevs_inst;
public final BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_9_4_ContainerList bevl_varargs = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = bem_can_2(beva_name, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 726 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_varargs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_varargs.bem_put_2(bevt_3_tmpany_phold, beva_args);
bevl_result = bem_invoke_2(beva_name, bevl_varargs);
} /* Line: 729 */
return bevl_result;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {726, 726, 727, 727, 728, 728, 729, 731};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 18, 19, 20, 21, 22, 24};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 726 15
new 0 726 15
assign 1 726 16
can 2 726 16
assign 1 727 18
new 0 727 18
assign 1 727 19
new 1 727 19
assign 1 728 20
new 0 728 20
put 2 728 21
assign 1 729 22
invoke 2 729 22
return 1 731 24
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -302965453: return bem_tagGet_0();
case 301206433: return bem_echo_0();
case 1452879382: return bem_sourceFileNameGet_0();
case 1732876397: return bem_serializationIteratorGet_0();
case -803388239: return bem_deserializeClassNameGet_0();
case 737771364: return bem_toString_0();
case -1980796873: return bem_copy_0();
case 366164054: return bem_serializeContents_0();
case 997723391: return bem_iteratorGet_0();
case 1023783415: return bem_create_0();
case 2033657832: return bem_hashGet_0();
case 737353003: return bem_new_0();
case -420235024: return bem_classNameGet_0();
case 482356666: return bem_toAny_0();
case 1222310146: return bem_many_0();
case -1866917929: return bem_serializeToString_0();
case 1314576819: return bem_print_0();
case 1775715094: return bem_once_0();
case -70500062: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1732568943: return bem_sameObject_1(bevd_0);
case 1732014863: return bem_equals_1(bevd_0);
case -369272378: return bem_undefined_1(bevd_0);
case 1452810576: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 808158717: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1112750632: return bem_otherType_1(bevd_0);
case 228693515: return bem_notEquals_1(bevd_0);
case 254712574: return bem_def_1(bevd_0);
case 1210677960: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1107846755: return bem_otherClass_1(bevd_0);
case 1735205112: return bem_sameType_1(bevd_0);
case -10325606: return bem_undef_1(bevd_0);
case 235706821: return bem_defined_1(bevd_0);
case -1078688343: return bem_copyTo_1(bevd_0);
case 1940225088: return bem_sameClass_1(bevd_0);
case 1235111255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1747848637: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1990568085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1437812444: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -303274357: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815656517: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -70659423: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -164742720: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemVariadic_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemVariadic_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemVariadic();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_inst = (BEC_2_6_8_SystemVariadic) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_inst;
}
}
