package be;
public class BET_2_5_11_BuildMethodIndex extends BETS_Object {
public BET_2_5_11_BuildMethodIndex() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_2", "synGet_0", "synSet_1", "msynGet_0", "msynSet_1", "declarationGet_0", "declarationSet_1", "nameGet_0", "nameSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "syn", "msyn", "declaration", "name" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_11_BuildMethodIndex();
}
}
