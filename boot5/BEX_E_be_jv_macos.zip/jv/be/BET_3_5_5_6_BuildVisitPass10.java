package be;
public class BET_3_5_5_6_BuildVisitPass10 extends BETS_Object {
public BET_3_5_5_6_BuildVisitPass10() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "begin_1", "accept_1", "end_1", "transGet_0", "transSet_1", "buildGet_0", "buildSet_1", "constGet_0", "constSet_1", "ntypesGet_0", "ntypesSet_1", "condCall_2" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "trans", "build", "const", "ntypes" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_5_5_6_BuildVisitPass10();
}
}
