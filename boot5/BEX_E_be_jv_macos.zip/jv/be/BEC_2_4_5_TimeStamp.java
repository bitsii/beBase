package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeStamp extends BEC_2_4_8_TimeInterval {
public BEC_2_4_5_TimeStamp() { }

   java.util.TimeZone bevi_zone = java.util.TimeZone.getTimeZone("Etc/UTC");
   private static byte[] becc_BEC_2_4_5_TimeStamp_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x74,0x61,0x6D,0x70};
private static byte[] becc_BEC_2_4_5_TimeStamp_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
public static BEC_2_4_5_TimeStamp bece_BEC_2_4_5_TimeStamp_bevs_inst;

public static BET_2_4_5_TimeStamp bece_BEC_2_4_5_TimeStamp_bevs_type;

public BEC_2_5_4_LogicBool bevp_localZone;
public BEC_2_4_5_TimeStamp bem_new_0() throws Throwable {
bem_now_0();
return this;
} /*method end*/
public BEC_2_4_5_TimeStamp bem_copy_0() throws Throwable {
BEC_2_4_5_TimeStamp bevl_cp = null;
bevl_cp = (BEC_2_4_5_TimeStamp) (new BEC_2_4_5_TimeStamp()).bem_new_2(bevp_secs, bevp_millis);
bevl_cp.bem_localZoneSet_1(bevp_localZone);
return this;
} /*method end*/
public BEC_2_4_5_TimeStamp bem_localZoneSet_1(BEC_2_5_4_LogicBool beva__localZone) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_localZone == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 379*/ {
bevp_localZone = be.BECS_Runtime.boolFalse;
} /* Line: 380*/
bevp_localZone = beva__localZone;
if (bevp_localZone.bevi_bool)/* Line: 385*/ {

         bevi_zone = java.util.TimeZone.getDefault();
       } /* Line: 386*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_localZoneGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevp_localZone == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 395*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 395*/
return bevp_localZone;
} /*method end*/
public BEC_2_4_6_TextString bem_yearGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("yyyy");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_monthGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("MM");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_dayGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("dd");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_hourGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("HH");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_minuteGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("mm");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_secondGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("ss");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_millisecondGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_millis.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {370, 374, 375, 379, 379, 380, 383, 395, 395, 395, 395, 396, 416, 436, 456, 476, 496, 516, 520, 520};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 20, 21, 26, 31, 32, 34, 44, 49, 50, 51, 53, 69, 85, 101, 117, 133, 149, 153, 154};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
now 0 370 15
assign 1 374 20
new 2 374 20
localZoneSet 1 375 21
assign 1 379 26
undef 1 379 31
assign 1 380 32
new 0 380 32
assign 1 383 34
assign 1 395 44
undef 1 395 49
assign 1 395 50
new 0 395 50
return 1 395 51
return 1 396 53
return 1 416 69
return 1 436 85
return 1 456 101
return 1 476 117
return 1 496 133
return 1 516 149
assign 1 520 153
toString 0 520 153
return 1 520 154
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2105446481: return bem_print_0();
case -1632807266: return bem_localZoneGet_0();
case 97869199: return bem_hashGet_0();
case 420796529: return bem_toString_0();
case -1885752786: return bem_yearGet_0();
case -2096331826: return bem_copy_0();
case -999123940: return bem_create_0();
case -202463896: return bem_now_0();
case -2133146908: return bem_iteratorGet_0();
case -2134993308: return bem_new_0();
case -613791002: return bem_secondInMinuteGet_0();
case -218493971: return bem_secondsGet_0();
case -1181967883: return bem_millisGet_0();
case -1760620723: return bem_minutesGet_0();
case -1573778606: return bem_dayGet_0();
case -846865080: return bem_toStringMinutes_0();
case -1659030326: return bem_secsGet_0();
case -1113562231: return bem_hourGet_0();
case -857664832: return bem_millisecondInSecondGet_0();
case 791995407: return bem_monthGet_0();
case 1192753520: return bem_millisecondsGet_0();
case 876078961: return bem_millisecondGet_0();
case -509140091: return bem_carryMillis_0();
case -603877240: return bem_toShortString_0();
case 1191981523: return bem_secondGet_0();
case -1354253029: return bem_minuteGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1724089654: return bem_equals_1(bevd_0);
case -1053307136: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case 267037064: return bem_secsSet_1(bevd_0);
case -486844982: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case 702306014: return bem_millisSet_1(bevd_0);
case -1985682318: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case -1644625942: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 1971880743: return bem_localZoneSet_1((BEC_2_5_4_LogicBool) bevd_0);
case -1532570429: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1845239358: return bem_copyTo_1(bevd_0);
case 680985996: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 255956228: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1714528971: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 977201824: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case -561946826: return bem_def_1(bevd_0);
case -1283550108: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1234526699: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case -1742980900: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 875398070: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case 1016050541: return bem_notEquals_1(bevd_0);
case 892243421: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 2002768304: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1346233774: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -199176115: return bem_undef_1(bevd_0);
case -563281287: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 861111505: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 150001987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1560972769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -444420730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 479138021: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeStamp_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeStamp_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_TimeStamp();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_inst = (BEC_2_4_5_TimeStamp) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_type;
}
}
