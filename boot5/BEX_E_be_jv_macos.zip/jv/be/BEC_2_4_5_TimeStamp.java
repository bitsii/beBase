package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeStamp extends BEC_2_4_8_TimeInterval {
public BEC_2_4_5_TimeStamp() { }

   java.util.TimeZone bevi_zone = java.util.TimeZone.getTimeZone("Etc/UTC");
   private static byte[] becc_BEC_2_4_5_TimeStamp_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x74,0x61,0x6D,0x70};
private static byte[] becc_BEC_2_4_5_TimeStamp_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
public static BEC_2_4_5_TimeStamp bece_BEC_2_4_5_TimeStamp_bevs_inst;

public static BET_2_4_5_TimeStamp bece_BEC_2_4_5_TimeStamp_bevs_type;

public BEC_2_5_4_LogicBool bevp_localZone;
public BEC_2_4_5_TimeStamp bem_new_0() throws Throwable {
bem_now_0();
return this;
} /*method end*/
public BEC_2_4_5_TimeStamp bem_copy_0() throws Throwable {
BEC_2_4_5_TimeStamp bevl_cp = null;
bevl_cp = (BEC_2_4_5_TimeStamp) (new BEC_2_4_5_TimeStamp()).bem_new_2(bevp_secs, bevp_millis);
bevl_cp.bem_localZoneSet_1(bevp_localZone);
return this;
} /*method end*/
public BEC_2_4_5_TimeStamp bem_localZoneSet_1(BEC_2_5_4_LogicBool beva__localZone) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_localZone == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevp_localZone = be.BECS_Runtime.boolFalse;
} /* Line: 374 */
bevp_localZone = beva__localZone;
if (bevp_localZone.bevi_bool) /* Line: 379 */ {

         bevi_zone = java.util.TimeZone.getDefault();
       } /* Line: 380 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_localZoneGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_localZone == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 389 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 389 */
return bevp_localZone;
} /*method end*/
public BEC_2_4_6_TextString bem_yearGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("yyyy");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_monthGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("MM");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_dayGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("dd");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_hourGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("HH");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_minuteGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("mm");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_secondGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("ss");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_millisecondGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_millis.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_localZoneGetDirect_0() throws Throwable {
return bevp_localZone;
} /*method end*/
public final BEC_2_4_5_TimeStamp bem_localZoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_localZone = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {364, 368, 369, 373, 373, 374, 377, 389, 389, 389, 389, 390, 410, 430, 450, 470, 490, 510, 514, 514, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 20, 21, 26, 31, 32, 34, 44, 49, 50, 51, 53, 69, 85, 101, 117, 133, 149, 153, 154, 157, 160};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
now 0 364 15
assign 1 368 20
new 2 368 20
localZoneSet 1 369 21
assign 1 373 26
undef 1 373 31
assign 1 374 32
new 0 374 32
assign 1 377 34
assign 1 389 44
undef 1 389 49
assign 1 389 50
new 0 389 50
return 1 389 51
return 1 390 53
return 1 410 69
return 1 430 85
return 1 450 101
return 1 470 117
return 1 490 133
return 1 510 149
assign 1 514 153
toString 0 514 153
return 1 514 154
return 1 0 157
assign 1 0 160
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 810516096: return bem_tagGet_0();
case -743032273: return bem_dayGet_0();
case 1516528362: return bem_copy_0();
case 647733846: return bem_hashGet_0();
case 764111846: return bem_classNameGet_0();
case -861566588: return bem_monthGet_0();
case -2096909353: return bem_minuteGet_0();
case -2012773835: return bem_millisecondInSecondGet_0();
case -55106104: return bem_millisecondsGet_0();
case -294349744: return bem_yearGet_0();
case 1640160430: return bem_serializationIteratorGet_0();
case -2027075098: return bem_sourceFileNameGet_0();
case 258900446: return bem_millisecondGet_0();
case -1857169421: return bem_print_0();
case -1019129421: return bem_iteratorGet_0();
case 2120555843: return bem_toShortString_0();
case 2072062711: return bem_secondsGet_0();
case -1433376527: return bem_now_0();
case -1459660688: return bem_once_0();
case 1956626943: return bem_hourGet_0();
case 1977268733: return bem_toAny_0();
case 415444144: return bem_many_0();
case -1154435755: return bem_carryMillis_0();
case -1440519528: return bem_new_0();
case 1464556610: return bem_serializeContents_0();
case -352222734: return bem_echo_0();
case 1737993344: return bem_toStringMinutes_0();
case -916808790: return bem_serializeToString_0();
case -1366269253: return bem_secondInMinuteGet_0();
case 977410886: return bem_secsGetDirect_0();
case -1941199374: return bem_secondGet_0();
case -1903952639: return bem_millisGetDirect_0();
case -1217520136: return bem_millisGet_0();
case 1337720095: return bem_localZoneGet_0();
case -2042019182: return bem_toString_0();
case -738477154: return bem_secsGet_0();
case -722012369: return bem_localZoneGetDirect_0();
case 596114544: return bem_minutesGet_0();
case -1322750582: return bem_fieldNamesGet_0();
case 1966604989: return bem_deserializeClassNameGet_0();
case 1544637441: return bem_fieldIteratorGet_0();
case 1256493526: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1451816788: return bem_otherType_1(bevd_0);
case -1066262854: return bem_copyTo_1(bevd_0);
case -2113151813: return bem_otherClass_1(bevd_0);
case 1686689499: return bem_sameType_1(bevd_0);
case -615053439: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1120239273: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 129664577: return bem_undefined_1(bevd_0);
case 153656470: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1049451245: return bem_millisSet_1(bevd_0);
case 858949566: return bem_sameObject_1(bevd_0);
case 115240264: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1149328783: return bem_equals_1(bevd_0);
case 1597179281: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1770634976: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1613791509: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 114225301: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case -1103921791: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1726382580: return bem_undef_1(bevd_0);
case 1070069720: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1169656357: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case -724951647: return bem_localZoneSet_1((BEC_2_5_4_LogicBool) bevd_0);
case -62499290: return bem_notEquals_1(bevd_0);
case 1075419472: return bem_secsSetDirect_1(bevd_0);
case 2044188090: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 173437066: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1509341300: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case 537660897: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1884560238: return bem_sameClass_1(bevd_0);
case -407337974: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case -1693595005: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1303995883: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1529930548: return bem_def_1(bevd_0);
case -602403420: return bem_localZoneSetDirect_1(bevd_0);
case 456604916: return bem_defined_1(bevd_0);
case -110111057: return bem_millisSetDirect_1(bevd_0);
case -386609926: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1063104431: return bem_secsSet_1(bevd_0);
case -486263239: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 271640761: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -169926786: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -840184945: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2113325337: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1732137967: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1058450326: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1752849240: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1337367239: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 572204899: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeStamp_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeStamp_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_TimeStamp();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_inst = (BEC_2_4_5_TimeStamp) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_type;
}
}
