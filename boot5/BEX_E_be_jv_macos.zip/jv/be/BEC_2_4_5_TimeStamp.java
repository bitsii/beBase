package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeStamp extends BEC_2_4_8_TimeInterval {
public BEC_2_4_5_TimeStamp() { }

   java.util.TimeZone bevi_zone = java.util.TimeZone.getTimeZone("Etc/UTC");
   private static byte[] becc_BEC_2_4_5_TimeStamp_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x74,0x61,0x6D,0x70};
private static byte[] becc_BEC_2_4_5_TimeStamp_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
public static BEC_2_4_5_TimeStamp bece_BEC_2_4_5_TimeStamp_bevs_inst;

public static BET_2_4_5_TimeStamp bece_BEC_2_4_5_TimeStamp_bevs_type;

public BEC_2_5_4_LogicBool bevp_localZone;
public BEC_2_4_5_TimeStamp bem_new_0() throws Throwable {
bem_now_0();
return this;
} /*method end*/
public BEC_2_4_5_TimeStamp bem_copy_0() throws Throwable {
BEC_2_4_5_TimeStamp bevl_cp = null;
bevl_cp = (BEC_2_4_5_TimeStamp) (new BEC_2_4_5_TimeStamp()).bem_new_2(bevp_secs, bevp_millis);
bevl_cp.bem_localZoneSet_1(bevp_localZone);
return this;
} /*method end*/
public BEC_2_4_5_TimeStamp bem_localZoneSet_1(BEC_2_5_4_LogicBool beva__localZone) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_localZone == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 373*/ {
bevp_localZone = be.BECS_Runtime.boolFalse;
} /* Line: 374*/
bevp_localZone = beva__localZone;
if (bevp_localZone.bevi_bool)/* Line: 379*/ {

         bevi_zone = java.util.TimeZone.getDefault();
       } /* Line: 380*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_localZoneGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevp_localZone == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 389*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 389*/
return bevp_localZone;
} /*method end*/
public BEC_2_4_6_TextString bem_yearGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("yyyy");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_monthGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("MM");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_dayGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("dd");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_hourGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("HH");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_minuteGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("mm");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_secondGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_rval = null;

       
       long ms = (long) bevp_secs.bevi_int;
       ms = ms * 1000;
       ms = ms + ((long) bevp_millis.bevi_int);
       
       java.util.Date date = new java.util.Date(ms);
       java.text.DateFormat format = new java.text.SimpleDateFormat("ss");
       format.setTimeZone(bevi_zone);
       String formatted = format.format(date);
       bevl_rval = new BEC_2_4_6_TextString(formatted);
       
     return bevl_rval;
} /*method end*/
public BEC_2_4_6_TextString bem_millisecondGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_millis.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_localZoneGetDirect_0() throws Throwable {
return bevp_localZone;
} /*method end*/
public final BEC_2_4_5_TimeStamp bem_localZoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_localZone = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {364, 368, 369, 373, 373, 374, 377, 389, 389, 389, 389, 390, 410, 430, 450, 470, 490, 510, 514, 514, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 20, 21, 26, 31, 32, 34, 44, 49, 50, 51, 53, 69, 85, 101, 117, 133, 149, 153, 154, 157, 160};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
now 0 364 15
assign 1 368 20
new 2 368 20
localZoneSet 1 369 21
assign 1 373 26
undef 1 373 31
assign 1 374 32
new 0 374 32
assign 1 377 34
assign 1 389 44
undef 1 389 49
assign 1 389 50
new 0 389 50
return 1 389 51
return 1 390 53
return 1 410 69
return 1 430 85
return 1 450 101
return 1 470 117
return 1 490 133
return 1 510 149
assign 1 514 153
toString 0 514 153
return 1 514 154
return 1 0 157
assign 1 0 160
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1971186178: return bem_yearGet_0();
case 1864861581: return bem_echo_0();
case -1092425859: return bem_hourGet_0();
case -347009298: return bem_millisecondsGet_0();
case 566573794: return bem_tagGet_0();
case -562992690: return bem_secsGetDirect_0();
case 873828646: return bem_deserializeClassNameGet_0();
case -45329095: return bem_secsGet_0();
case -898166382: return bem_millisecondGet_0();
case 1551436403: return bem_millisecondInSecondGet_0();
case -185274422: return bem_minuteGet_0();
case 1464527658: return bem_toString_0();
case 1393634620: return bem_serializeToString_0();
case 2071875109: return bem_sourceFileNameGet_0();
case 239077256: return bem_print_0();
case -1388663011: return bem_now_0();
case 2113534779: return bem_hashGet_0();
case 785161348: return bem_fieldNamesGet_0();
case 2063548645: return bem_dayGet_0();
case -2131640624: return bem_new_0();
case 496263989: return bem_localZoneGet_0();
case 1188062710: return bem_minutesGet_0();
case -281350604: return bem_serializeContents_0();
case 1645989341: return bem_iteratorGet_0();
case -157777737: return bem_fieldIteratorGet_0();
case -626713871: return bem_millisGet_0();
case -176142795: return bem_secondsGet_0();
case -1562541342: return bem_toStringMinutes_0();
case -800624269: return bem_monthGet_0();
case 969994032: return bem_serializationIteratorGet_0();
case 644642636: return bem_toShortString_0();
case 974175749: return bem_secondInMinuteGet_0();
case -750650506: return bem_millisGetDirect_0();
case 1925201335: return bem_carryMillis_0();
case 350812655: return bem_copy_0();
case 2005341358: return bem_localZoneGetDirect_0();
case 1005443364: return bem_create_0();
case 1587133120: return bem_classNameGet_0();
case 302703424: return bem_secondGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1622831317: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -454398751: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1614667218: return bem_millisSetDirect_1(bevd_0);
case 1682620824: return bem_localZoneSet_1((BEC_2_5_4_LogicBool) bevd_0);
case -396283576: return bem_undef_1(bevd_0);
case 1689291310: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 105771457: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case 1952657800: return bem_millisSet_1(bevd_0);
case -565373617: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -93091738: return bem_secsSetDirect_1(bevd_0);
case 1197429492: return bem_localZoneSetDirect_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 215459176: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case -2002082344: return bem_secsSet_1(bevd_0);
case 1807927222: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1672950580: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case -826557009: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 1953656042: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case -1380565896: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case -287473676: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
case -59238618: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -339219602: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case -1235172734: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1406331467: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case -674081015: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1433419964: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeStamp_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeStamp_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_TimeStamp();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_inst = (BEC_2_4_5_TimeStamp) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_type;
}
}
