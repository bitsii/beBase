package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemPlatform extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemPlatform() { }
private static byte[] becc_BEC_2_6_8_SystemPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_8_SystemPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_0 = {0x6D,0x61,0x63,0x6F,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_1 = {0x6C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_2 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_3 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_4 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_5 = {0x2F,0x64,0x65,0x76,0x2F,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_6 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_6, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_7 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_8 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_9 = {0x6E,0x75,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_10 = {0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 9));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_11 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x2C,0x20,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x69,0x6E,0x20,0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_11, 60));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_12, 5));
public static BEC_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_inst;

public static BET_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_4_LogicBool bevp_isNix;
public BEC_2_5_4_LogicBool bevp_isWin;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_otherSeparator;
public BEC_2_4_6_TextString bevp_nullFile;
public BEC_2_6_8_SystemPlatform bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_new_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_0;
bevt_2_tmpany_phold = bevp_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 631 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_1;
bevt_4_tmpany_phold = bevp_name.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 631 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 631 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 631 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 631 */ {
bevt_7_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_2;
bevt_6_tmpany_phold = bevp_name.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 631 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 631 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 631 */ {
bevp_isNix = be.BECS_Runtime.boolTrue;
bevp_isWin = be.BECS_Runtime.boolFalse;
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_otherSeparator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_nullFile = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_8_SystemPlatform_bels_5));
} /* Line: 636 */
 else  /* Line: 631 */ {
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_3;
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 637 */ {
bevp_isNix = be.BECS_Runtime.boolFalse;
bevp_isWin = be.BECS_Runtime.boolTrue;
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_7));
bevp_otherSeparator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_8));
bevp_nullFile = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_9));
} /* Line: 642 */
 else  /* Line: 643 */ {
bevt_13_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_name);
bevt_14_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_5;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 644 */
} /* Line: 631 */
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_16_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_6;
bevt_15_tmpany_phold = bevp_name.bem_equals_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 647 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(-1860189172);
} /* Line: 649 */
 else  /* Line: 650 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(-1860189172);
} /* Line: 651 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNixGet_0() throws Throwable {
return bevp_isNix;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isNixSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isWinGet_0() throws Throwable {
return bevp_isWin;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isWinSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_otherSeparatorGet_0() throws Throwable {
return bevp_otherSeparator;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_otherSeparatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullFileGet_0() throws Throwable {
return bevp_nullFile;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nullFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {625, 626, 631, 631, 0, 631, 631, 0, 0, 0, 631, 631, 0, 0, 632, 633, 634, 635, 636, 637, 637, 638, 639, 640, 641, 642, 644, 644, 644, 644, 644, 644, 646, 647, 647, 649, 651, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 67, 68, 70, 73, 74, 76, 79, 83, 86, 87, 89, 92, 96, 97, 98, 99, 100, 103, 104, 106, 107, 108, 109, 110, 113, 114, 115, 116, 117, 118, 121, 122, 123, 125, 128, 133, 136, 140, 143, 147, 150, 154, 157, 161, 164, 168, 171, 175, 178};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 625 44
buildProfile 0 626 45
assign 1 631 67
new 0 631 67
assign 1 631 68
equals 1 631 68
assign 1 0 70
assign 1 631 73
new 0 631 73
assign 1 631 74
equals 1 631 74
assign 1 0 76
assign 1 0 79
assign 1 0 83
assign 1 631 86
new 0 631 86
assign 1 631 87
equals 1 631 87
assign 1 0 89
assign 1 0 92
assign 1 632 96
new 0 632 96
assign 1 633 97
new 0 633 97
assign 1 634 98
new 0 634 98
assign 1 635 99
new 0 635 99
assign 1 636 100
new 0 636 100
assign 1 637 103
new 0 637 103
assign 1 637 104
equals 1 637 104
assign 1 638 106
new 0 638 106
assign 1 639 107
new 0 639 107
assign 1 640 108
new 0 640 108
assign 1 641 109
new 0 641 109
assign 1 642 110
new 0 642 110
assign 1 644 113
new 0 644 113
assign 1 644 114
add 1 644 114
assign 1 644 115
new 0 644 115
assign 1 644 116
add 1 644 116
assign 1 644 117
new 1 644 117
throw 1 644 118
assign 1 646 121
new 0 646 121
assign 1 647 122
new 0 647 122
assign 1 647 123
equals 1 647 123
assign 1 649 125
unixNewlineGet 0 649 125
assign 1 651 128
unixNewlineGet 0 651 128
return 1 0 133
assign 1 0 136
return 1 0 140
assign 1 0 143
return 1 0 147
assign 1 0 150
return 1 0 154
assign 1 0 157
return 1 0 161
assign 1 0 164
return 1 0 168
assign 1 0 171
return 1 0 175
assign 1 0 178
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2144751797: return bem_isWinGet_0();
case 1793221455: return bem_copy_0();
case -980884323: return bem_new_0();
case -398879823: return bem_separatorGet_0();
case -1226625126: return bem_once_0();
case 1142946706: return bem_buildProfile_0();
case 2049066942: return bem_fieldIteratorGet_0();
case 1310553601: return bem_toString_0();
case -1565549870: return bem_print_0();
case 489788599: return bem_serializeContents_0();
case 1924413487: return bem_hashGet_0();
case 1150664853: return bem_create_0();
case 2052709534: return bem_many_0();
case 332981262: return bem_deserializeClassNameGet_0();
case 1604962015: return bem_sourceFileNameGet_0();
case 1519856241: return bem_otherSeparatorGet_0();
case -290041240: return bem_serializeToString_0();
case -1897026239: return bem_echo_0();
case 194016774: return bem_iteratorGet_0();
case 1535974186: return bem_nameGet_0();
case -732524867: return bem_tagGet_0();
case -1535847383: return bem_toAny_0();
case 1129335789: return bem_isNixGet_0();
case -53834466: return bem_nullFileGet_0();
case -525681067: return bem_classNameGet_0();
case -1920531733: return bem_serializationIteratorGet_0();
case -1906059858: return bem_newlineGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -93139500: return bem_isNixSet_1(bevd_0);
case -567954698: return bem_isWinSet_1(bevd_0);
case 1693216688: return bem_sameClass_1(bevd_0);
case -1040169247: return bem_newlineSet_1(bevd_0);
case -145738070: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 863435643: return bem_equals_1(bevd_0);
case 1868528499: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1545437990: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 420384947: return bem_def_1(bevd_0);
case 1998776126: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1021436824: return bem_sameType_1(bevd_0);
case -467299687: return bem_defined_1(bevd_0);
case -1834098557: return bem_notEquals_1(bevd_0);
case 562081982: return bem_undefined_1(bevd_0);
case 842068699: return bem_otherSeparatorSet_1(bevd_0);
case -1966507736: return bem_undef_1(bevd_0);
case 1529714024: return bem_nullFileSet_1(bevd_0);
case 959360624: return bem_otherType_1(bevd_0);
case 679257612: return bem_separatorSet_1(bevd_0);
case -1343499453: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 257405303: return bem_copyTo_1(bevd_0);
case 386836188: return bem_otherClass_1(bevd_0);
case -2104330508: return bem_sameObject_1(bevd_0);
case -1635666086: return bem_nameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1240676558: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -371043039: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1325559256: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1035622269: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -145115514: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686918154: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1895634211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst = (BEC_2_6_8_SystemPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_type;
}
}
