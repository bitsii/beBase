package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_13_SystemIncorrectType extends BEC_2_6_9_SystemException {
public BEC_2_6_13_SystemIncorrectType() { }
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x54,0x79,0x70,0x65};
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;

public static BET_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_type;

public BEC_2_6_13_SystemIncorrectType bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {146};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 146 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1464527658: return bem_toString_0();
case 1711465395: return bem_methodNameGet_0();
case -2018405427: return bem_vvGetDirect_0();
case 26249322: return bem_framesGetDirect_0();
case -465044387: return bem_framesTextGetDirect_0();
case -1164886894: return bem_methodNameGetDirect_0();
case 1864861581: return bem_echo_0();
case 1645989341: return bem_iteratorGet_0();
case -2131640624: return bem_new_0();
case -157777737: return bem_fieldIteratorGet_0();
case 1847711236: return bem_vvGet_0();
case 1863709164: return bem_lineNumberGet_0();
case 329316948: return bem_klassNameGet_0();
case 563362131: return bem_framesGet_0();
case 1170690618: return bem_translatedGetDirect_0();
case 969994032: return bem_serializationIteratorGet_0();
case 1005443364: return bem_create_0();
case -1269354124: return bem_descriptionGet_0();
case 2113534779: return bem_hashGet_0();
case 1082738156: return bem_getFrameText_0();
case -1115751611: return bem_lineNumberGetDirect_0();
case 2071875109: return bem_sourceFileNameGet_0();
case 239077256: return bem_print_0();
case 785161348: return bem_fieldNamesGet_0();
case 1393634620: return bem_serializeToString_0();
case -585652079: return bem_framesTextGet_0();
case 1587133120: return bem_classNameGet_0();
case -1021124998: return bem_klassNameGetDirect_0();
case 1989474255: return bem_translatedGet_0();
case 1476896558: return bem_emitLangGet_0();
case -639336458: return bem_emitLangGetDirect_0();
case -1193488438: return bem_descriptionGetDirect_0();
case -929052621: return bem_fileNameGet_0();
case -281350604: return bem_serializeContents_0();
case 1983421758: return bem_langGetDirect_0();
case -33478759: return bem_langGet_0();
case 873828646: return bem_deserializeClassNameGet_0();
case 350812655: return bem_copy_0();
case 566573794: return bem_tagGet_0();
case -2120559150: return bem_fileNameGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -903913232: return bem_descriptionSet_1(bevd_0);
case -1634081985: return bem_vvSetDirect_1(bevd_0);
case 1300163563: return bem_emitLangSetDirect_1(bevd_0);
case -396283576: return bem_undef_1(bevd_0);
case -800854443: return bem_methodNameSetDirect_1(bevd_0);
case 643524688: return bem_emitLangSet_1(bevd_0);
case 648740707: return bem_lineNumberSetDirect_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 666215113: return bem_lineNumberSet_1(bevd_0);
case -1209655002: return bem_framesSet_1(bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case -185181824: return bem_langSet_1(bevd_0);
case -1353668075: return bem_new_1(bevd_0);
case -130608934: return bem_klassNameSet_1(bevd_0);
case -1259261363: return bem_fileNameSetDirect_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case -601715410: return bem_framesSetDirect_1(bevd_0);
case 1023800581: return bem_klassNameSetDirect_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 46260488: return bem_langSetDirect_1(bevd_0);
case 1146649309: return bem_methodNameSet_1(bevd_0);
case -923725574: return bem_framesTextSetDirect_1(bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case 456419439: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1027712283: return bem_framesTextSet_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 2069034369: return bem_descriptionSetDirect_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case 592226772: return bem_fileNameSet_1(bevd_0);
case -1248555496: return bem_translatedSetDirect_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
case -1257602985: return bem_translatedSet_1(bevd_0);
case 1552075531: return bem_vvSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1774679440: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_13_SystemIncorrectType_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_13_SystemIncorrectType_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_13_SystemIncorrectType();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst = (BEC_2_6_13_SystemIncorrectType) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_type;
}
}
