package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_13_SystemIncorrectType extends BEC_2_6_9_SystemException {
public BEC_2_6_13_SystemIncorrectType() { }
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x54,0x79,0x70,0x65};
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;

public static BET_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_type;

public BEC_2_6_13_SystemIncorrectType bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {373};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 373 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1928088089: return bem_descriptionGet_0();
case -999742713: return bem_getFrameText_0();
case 1913575531: return bem_framesTextGetDirect_0();
case 1517070805: return bem_framesGetDirect_0();
case -542895744: return bem_descriptionGetDirect_0();
case 1751408331: return bem_create_0();
case 605198235: return bem_framesTextGet_0();
case 1914998316: return bem_langGet_0();
case 1265443227: return bem_methodNameGet_0();
case -284827837: return bem_serializationIteratorGet_0();
case -1176703679: return bem_fieldNamesGet_0();
case -1131671229: return bem_lineNumberGet_0();
case 1925518230: return bem_sourceFileNameGet_0();
case 793345871: return bem_serializeContents_0();
case 949832554: return bem_copy_0();
case -488017103: return bem_translateEmittedExceptionInner_0();
case 2011805555: return bem_translatedGetDirect_0();
case 1775735288: return bem_many_0();
case 896037617: return bem_tagGet_0();
case -513793520: return bem_echo_0();
case -2086164923: return bem_vvGetDirect_0();
case -641653704: return bem_klassNameGetDirect_0();
case 1943997529: return bem_emitLangGetDirect_0();
case -2027613701: return bem_translatedGet_0();
case 623979920: return bem_fieldIteratorGet_0();
case 996800845: return bem_hashGet_0();
case -127134874: return bem_new_0();
case 238124596: return bem_klassNameGet_0();
case -399960042: return bem_serializeToString_0();
case 1661320608: return bem_fileNameGetDirect_0();
case -1516054414: return bem_fileNameGet_0();
case -808651918: return bem_methodNameGetDirect_0();
case 1106799870: return bem_once_0();
case 841480631: return bem_emitLangGet_0();
case 2056349311: return bem_toString_0();
case 1309169735: return bem_toAny_0();
case 1854711577: return bem_deserializeClassNameGet_0();
case -43734388: return bem_translateEmittedException_0();
case 636545300: return bem_lineNumberGetDirect_0();
case -920044500: return bem_langGetDirect_0();
case 2144753883: return bem_framesGet_0();
case 1970795670: return bem_print_0();
case -93701723: return bem_iteratorGet_0();
case -493798980: return bem_vvGet_0();
case -342364250: return bem_classNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -187229559: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1002016496: return bem_fileNameSetDirect_1(bevd_0);
case 1040475448: return bem_descriptionSet_1(bevd_0);
case -1442769844: return bem_defined_1(bevd_0);
case 196505848: return bem_copyTo_1(bevd_0);
case 1965711925: return bem_vvSet_1(bevd_0);
case -511506123: return bem_framesTextSetDirect_1(bevd_0);
case 1564465433: return bem_otherClass_1(bevd_0);
case 496972815: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1876058153: return bem_langSet_1(bevd_0);
case -779382852: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1003074772: return bem_lineNumberSetDirect_1(bevd_0);
case -131663220: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1587859478: return bem_methodNameSet_1(bevd_0);
case -865793810: return bem_framesSetDirect_1(bevd_0);
case 926712295: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 907697888: return bem_notEquals_1(bevd_0);
case 1733853833: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1241878849: return bem_undef_1(bevd_0);
case -1302734873: return bem_new_1(bevd_0);
case -657813432: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1613999742: return bem_sameObject_1(bevd_0);
case 1629186458: return bem_emitLangSetDirect_1(bevd_0);
case -687597052: return bem_vvSetDirect_1(bevd_0);
case 1464581110: return bem_methodNameSetDirect_1(bevd_0);
case -780071654: return bem_klassNameSetDirect_1(bevd_0);
case -898321379: return bem_sameClass_1(bevd_0);
case -696648516: return bem_langSetDirect_1(bevd_0);
case -1284801705: return bem_translatedSet_1(bevd_0);
case -1851864229: return bem_equals_1(bevd_0);
case -1476488229: return bem_translatedSetDirect_1(bevd_0);
case 1865502099: return bem_sameType_1(bevd_0);
case 421162766: return bem_klassNameSet_1(bevd_0);
case -1342631278: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1950370730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -632919670: return bem_framesSet_1(bevd_0);
case -2015846886: return bem_fileNameSet_1(bevd_0);
case 1650850952: return bem_lineNumberSet_1(bevd_0);
case 1277827347: return bem_otherType_1(bevd_0);
case -733244257: return bem_descriptionSetDirect_1(bevd_0);
case -69593350: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 442389467: return bem_emitLangSet_1(bevd_0);
case 880135880: return bem_framesTextSet_1(bevd_0);
case -1608198204: return bem_def_1(bevd_0);
case 1577584266: return bem_undefined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1936049104: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1545739438: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 550444665: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1077148737: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1695587472: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1683215334: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 641350819: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1879660947: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_13_SystemIncorrectType_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_13_SystemIncorrectType_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_13_SystemIncorrectType();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst = (BEC_2_6_13_SystemIncorrectType) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_type;
}
}
