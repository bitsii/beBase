package be;
/* IO:File: source/extended/Properties.be */
public class BEC_2_9_11_ContainerPropertyMap extends BEC_2_6_6_SystemObject {
public BEC_2_9_11_ContainerPropertyMap() { }
private static byte[] becc_BEC_2_9_11_ContainerPropertyMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerPropertyMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerPropertyMap bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst;

public static BET_2_9_11_ContainerPropertyMap bece_BEC_2_9_11_ContainerPropertyMap_bevs_type;

public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_9_11_ContainerPropertyMap bem_new_0() throws Throwable {
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_9_11_ContainerPropertyMap bem_set_2(BEC_2_4_6_TextString beva_key, BEC_2_4_6_TextString beva_value) throws Throwable {
bevp_map.bem_put_2(beva_key, beva_value);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_get_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_map.bem_get_1(beva_key);
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getCached_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_map.bem_get_1(beva_key);
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_11_ContainerPropertyMap bem_unset_1(BEC_2_4_6_TextString beva_key) throws Throwable {
bevp_map.bem_delete_1(beva_key);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return null;
} /*method end*/
public BEC_2_9_11_ContainerPropertyMap bem_mapSet_1(BEC_2_9_3_ContainerMap beva__map) throws Throwable {
return this;
} /*method end*/
public BEC_2_9_11_ContainerPropertyMap bem_load_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_map.bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 23, 27, 27, 31, 31, 35, 38, 39, 44, 44};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 17, 22, 23, 27, 28, 31, 35, 38, 45, 46};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 13
new 0 17 13
put 2 23 17
assign 1 27 22
get 1 27 22
return 1 27 23
assign 1 31 27
get 1 31 27
return 1 31 28
delete 1 35 31
return 1 38 35
return 1 39 38
assign 1 44 45
iteratorGet 0 44 45
return 1 44 46
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1500345660: return bem_new_0();
case -1128089878: return bem_load_0();
case 1914698093: return bem_copy_0();
case -2044808959: return bem_create_0();
case -1799992292: return bem_mapGet_0();
case 701056781: return bem_print_0();
case 403207358: return bem_hashGet_0();
case 332374972: return bem_toString_0();
case -411352811: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2091475700: return bem_def_1(bevd_0);
case -2122498883: return bem_getCached_1((BEC_2_4_6_TextString) bevd_0);
case 242448501: return bem_undef_1(bevd_0);
case -183213474: return bem_copyTo_1(bevd_0);
case 2093081199: return bem_equals_1(bevd_0);
case -361142495: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 1056390040: return bem_notEquals_1(bevd_0);
case -1530741328: return bem_unset_1((BEC_2_4_6_TextString) bevd_0);
case -1828599612: return bem_mapSet_1((BEC_2_9_3_ContainerMap) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1734287964: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1748111499: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1719173143: return bem_set_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1968238059: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1944821118: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerPropertyMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_2_9_11_ContainerPropertyMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerPropertyMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst = (BEC_2_9_11_ContainerPropertyMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_type;
}
}
