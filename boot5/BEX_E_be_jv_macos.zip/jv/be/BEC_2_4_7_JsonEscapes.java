package be;
/* IO:File: source/extended/Json.be */
public final class BEC_2_4_7_JsonEscapes extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_JsonEscapes() { }
private static byte[] becc_BEC_2_4_7_JsonEscapes_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x45,0x73,0x63,0x61,0x70,0x65,0x73};
private static byte[] becc_BEC_2_4_7_JsonEscapes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_0 = {0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_1 = {0x5C,0x5C};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_JsonEscapes_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_JsonEscapes_bels_0, 1));
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_2 = {0x08};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_3 = {0x5C,0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_4 = {0x0C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_5 = {0x5C,0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_6 = {0x0A};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_7 = {0x5C,0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_8 = {0x0D};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_9 = {0x5C,0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_10 = {0x09};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_11 = {0x5C,0x74};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_12 = {0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_13 = {0x5C,0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_14 = {0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_15 = {0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_16 = {0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_17 = {0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_18 = {0x74};
public static BEC_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_inst;

public static BET_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_type;

public BEC_2_9_3_ContainerMap bevp_toEscapes;
public BEC_2_9_3_ContainerMap bevp_fromEscapes;
public BEC_2_4_7_JsonEscapes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
bevp_toEscapes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_fromEscapes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_1));
bevp_toEscapes.bem_put_2(bevt_0_tmpany_phold, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_quoteGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_4_7_JsonEscapes_bevo_0;
bevt_11_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_quoteGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevp_toEscapes.bem_put_2(bevt_4_tmpany_phold, bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_2));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_3));
bevp_toEscapes.bem_put_2(bevt_12_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_5));
bevp_toEscapes.bem_put_2(bevt_16_tmpany_phold, bevt_19_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_7));
bevp_toEscapes.bem_put_2(bevt_20_tmpany_phold, bevt_23_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_9));
bevp_toEscapes.bem_put_2(bevt_24_tmpany_phold, bevt_27_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_11));
bevp_toEscapes.bem_put_2(bevt_28_tmpany_phold, bevt_31_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_13));
bevp_toEscapes.bem_put_2(bevt_32_tmpany_phold, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevp_fromEscapes.bem_put_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_quoteGet_0();
bevt_41_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_quoteGet_0();
bevp_fromEscapes.bem_put_2(bevt_38_tmpany_phold, bevt_40_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_14));
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_2));
bevp_fromEscapes.bem_put_2(bevt_42_tmpany_phold, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_15));
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevp_fromEscapes.bem_put_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_16));
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevp_fromEscapes.bem_put_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_17));
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevp_fromEscapes.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_18));
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevp_fromEscapes.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevp_fromEscapes.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_toEscapesGet_0() throws Throwable {
return bevp_toEscapes;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_toEscapesGetDirect_0() throws Throwable {
return bevp_toEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_toEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_JsonEscapes bem_toEscapesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fromEscapesGet_0() throws Throwable {
return bevp_fromEscapes;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_fromEscapesGetDirect_0() throws Throwable {
return bevp_fromEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_fromEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_JsonEscapes bem_fromEscapesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {262, 263, 265, 265, 265, 265, 265, 266, 266, 266, 266, 266, 266, 266, 266, 266, 267, 267, 267, 267, 267, 268, 268, 268, 268, 268, 269, 269, 269, 269, 269, 270, 270, 270, 270, 270, 271, 271, 271, 271, 271, 272, 272, 272, 272, 272, 274, 274, 274, 275, 275, 275, 275, 275, 276, 276, 276, 277, 277, 277, 278, 278, 278, 279, 279, 279, 280, 280, 280, 281, 281, 281, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 166, 169, 172, 176, 180, 183, 186, 190};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 262 91
new 0 262 91
assign 1 263 92
new 0 263 92
assign 1 265 93
new 0 265 93
assign 1 265 94
new 0 265 94
assign 1 265 95
addValue 1 265 95
assign 1 265 96
new 0 265 96
put 2 265 97
assign 1 266 98
new 0 266 98
assign 1 266 99
new 0 266 99
assign 1 266 100
quoteGet 0 266 100
assign 1 266 101
addValue 1 266 101
assign 1 266 102
new 0 266 102
assign 1 266 103
new 0 266 103
assign 1 266 104
quoteGet 0 266 104
assign 1 266 105
add 1 266 105
put 2 266 106
assign 1 267 107
new 0 267 107
assign 1 267 108
new 0 267 108
assign 1 267 109
addValue 1 267 109
assign 1 267 110
new 0 267 110
put 2 267 111
assign 1 268 112
new 0 268 112
assign 1 268 113
new 0 268 113
assign 1 268 114
addValue 1 268 114
assign 1 268 115
new 0 268 115
put 2 268 116
assign 1 269 117
new 0 269 117
assign 1 269 118
new 0 269 118
assign 1 269 119
addValue 1 269 119
assign 1 269 120
new 0 269 120
put 2 269 121
assign 1 270 122
new 0 270 122
assign 1 270 123
new 0 270 123
assign 1 270 124
addValue 1 270 124
assign 1 270 125
new 0 270 125
put 2 270 126
assign 1 271 127
new 0 271 127
assign 1 271 128
new 0 271 128
assign 1 271 129
addValue 1 271 129
assign 1 271 130
new 0 271 130
put 2 271 131
assign 1 272 132
new 0 272 132
assign 1 272 133
new 0 272 133
assign 1 272 134
addValue 1 272 134
assign 1 272 135
new 0 272 135
put 2 272 136
assign 1 274 137
new 0 274 137
assign 1 274 138
new 0 274 138
put 2 274 139
assign 1 275 140
new 0 275 140
assign 1 275 141
quoteGet 0 275 141
assign 1 275 142
new 0 275 142
assign 1 275 143
quoteGet 0 275 143
put 2 275 144
assign 1 276 145
new 0 276 145
assign 1 276 146
new 0 276 146
put 2 276 147
assign 1 277 148
new 0 277 148
assign 1 277 149
new 0 277 149
put 2 277 150
assign 1 278 151
new 0 278 151
assign 1 278 152
new 0 278 152
put 2 278 153
assign 1 279 154
new 0 279 154
assign 1 279 155
new 0 279 155
put 2 279 156
assign 1 280 157
new 0 280 157
assign 1 280 158
new 0 280 158
put 2 280 159
assign 1 281 160
new 0 281 160
assign 1 281 161
new 0 281 161
put 2 281 162
return 1 0 166
return 1 0 169
assign 1 0 172
assign 1 0 176
return 1 0 180
return 1 0 183
assign 1 0 186
assign 1 0 190
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2079582721: return bem_toString_0();
case -579194210: return bem_iteratorGet_0();
case 1886067938: return bem_fromEscapesGet_0();
case 572016682: return bem_serializationIteratorGet_0();
case -1682958828: return bem_tagGet_0();
case 1568711247: return bem_fieldIteratorGet_0();
case -1489022328: return bem_once_0();
case 577869439: return bem_serializeToString_0();
case 427126687: return bem_fromEscapesGetDirect_0();
case -621270081: return bem_new_0();
case 640879523: return bem_toEscapesGetDirect_0();
case 1476265575: return bem_toAny_0();
case 102995179: return bem_default_0();
case -165278261: return bem_hashGet_0();
case -278660789: return bem_toEscapesGet_0();
case 11313755: return bem_echo_0();
case -1430069919: return bem_serializeContents_0();
case -1045898755: return bem_classNameGet_0();
case -980602152: return bem_sourceFileNameGet_0();
case -1406264904: return bem_copy_0();
case 448246445: return bem_fieldNamesGet_0();
case -1791746868: return bem_print_0();
case -1168657718: return bem_create_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case 334571614: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2130736394: return bem_fromEscapesSetDirect_1(bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case -1725463935: return bem_toEscapesSetDirect_1(bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -24831799: return bem_toEscapesSet_1(bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
case 1549269169: return bem_fromEscapesSet_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_JsonEscapes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_7_JsonEscapes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_JsonEscapes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst = (BEC_2_4_7_JsonEscapes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_type;
}
}
