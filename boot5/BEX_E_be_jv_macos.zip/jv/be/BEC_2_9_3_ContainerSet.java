package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_4_ContainerList bevp_buckets;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 195*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 196*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 202*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /* Line: 203*/
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_modu.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
/* Line: 221*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 221*/ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 223*/ {
bevt_4_ta_ph = bevl_ni.bem_keyGet_0();
bevt_3_ta_ph = bem_innerPut_4(bevt_4_ta_ph, null, bevl_ni, beva_ninner);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(802916803);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 224*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 225*/
} /* Line: 224*/
} /* Line: 223*/
 else /* Line: 221*/ {
break;
} /* Line: 221*/
} /* Line: 221*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nbuckets = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = beva_slt.bem_sizeGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(bevp_multi);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_nbuckets = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
while (true)
/* Line: 236*/ {
bevt_4_ta_ph = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(802916803);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 236*/ {
bevl_nbuckets = bevl_nbuckets.bem_increment_0();
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nbuckets);
} /* Line: 238*/
 else /* Line: 236*/ {
break;
} /* Line: 236*/
} /* Line: 236*/
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_4_ta_ph = beva_other.bem_sizeGet_0();
bevt_5_ta_ph = bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 244*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 244*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 245*/
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 247*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_7_ta_ph.bevi_bool)/* Line: 247*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_9_ta_ph = beva_other.bem_has_1(bevl_i);
if (bevt_9_ta_ph.bevi_bool) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 248*/
} /* Line: 248*/
 else /* Line: 247*/ {
break;
} /* Line: 247*/
} /* Line: 247*/
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 255*/ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 257*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 258*/
} /* Line: 257*/
 else /* Line: 260*/ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(1429985689);
} /* Line: 261*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 265*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 267*/ {
if (beva_inode == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 268*/ {
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_ta_ph);
} /* Line: 269*/
 else /* Line: 270*/ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 271*/
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 274*/
 else /* Line: 267*/ {
bevt_10_ta_ph = bevl_n.bem_hvalGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_9_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /* Line: 276*/
 else /* Line: 267*/ {
bevt_13_ta_ph = bevl_n.bem_keyGet_0();
bevt_12_ta_ph = bevp_rel.bem_isEqual_2(bevt_13_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 277*/ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /* Line: 281*/
 else /* Line: 282*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 284*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 285*/
} /* Line: 284*/
} /* Line: 267*/
} /* Line: 267*/
} /* Line: 267*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevp_buckets);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(802916803);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 292*/ {
bevl_slt = bevp_buckets;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 295*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(802916803);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 295*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 296*/
 else /* Line: 295*/ {
break;
} /* Line: 295*/
} /* Line: 295*/
bevp_buckets = bevl_slt;
} /* Line: 298*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 300*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 301*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 309*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 310*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 314*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 316*/ {
return null;
} /* Line: 317*/
 else /* Line: 316*/ {
bevt_5_ta_ph = bevl_n.bem_hvalGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_4_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 318*/ {
return null;
} /* Line: 319*/
 else /* Line: 316*/ {
bevt_7_ta_ph = bevl_n.bem_keyGet_0();
bevt_6_ta_ph = bevp_rel.bem_isEqual_2(bevt_7_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 320*/ {
bevt_8_ta_ph = bevl_n.bem_getFrom_0();
return bevt_8_ta_ph;
} /* Line: 321*/
 else /* Line: 322*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 324*/ {
return null;
} /* Line: 325*/
} /* Line: 324*/
} /* Line: 316*/
} /* Line: 316*/
} /* Line: 316*/
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 335*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 336*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 340*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 343*/
 else /* Line: 342*/ {
bevt_6_ta_ph = bevl_n.bem_hvalGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_5_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 345*/
 else /* Line: 342*/ {
bevt_9_ta_ph = bevl_n.bem_keyGet_0();
bevt_8_ta_ph = bevp_rel.bem_isEqual_2(bevt_9_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 346*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 347*/
 else /* Line: 348*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /* Line: 351*/
} /* Line: 350*/
} /* Line: 342*/
} /* Line: 342*/
} /* Line: 342*/
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
bevl_slt = bevp_buckets;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 362*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 363*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 367*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 369*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 370*/
 else /* Line: 369*/ {
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_6_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 372*/
 else /* Line: 369*/ {
bevt_10_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevp_rel.bem_isEqual_2(bevt_10_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 373*/ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
/* Line: 377*/ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 377*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 379*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 379*/ {
bevt_15_ta_ph = bevl_n.bem_hvalGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_14_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 379*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 379*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 379*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 379*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_16_ta_ph;
} /* Line: 380*/
 else /* Line: 381*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_17_ta_ph = bevl_sl.bem_subtract_1(bevt_18_ta_ph);
bevl_slt.bem_put_2(bevt_17_ta_ph, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 383*/
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 385*/
 else /* Line: 377*/ {
break;
} /* Line: 377*/
} /* Line: 377*/
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_19_ta_ph;
} /* Line: 387*/
 else /* Line: 388*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 390*/ {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_21_ta_ph;
} /* Line: 391*/
} /* Line: 390*/
} /* Line: 369*/
} /* Line: 369*/
} /* Line: 369*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_buckets.bem_copy_0();
bevl_other.bemd_1(-1476381098, bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 402*/ {
bevt_2_ta_ph = bevp_buckets.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 402*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 404*/ {
bevt_4_ta_ph = bevl_other.bemd_0(947762649);
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_8_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevl_n.bem_getFrom_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
bevt_4_ta_ph.bemd_2(-832171868, bevl_i, bevt_5_ta_ph);
} /* Line: 405*/
 else /* Line: 406*/ {
bevt_10_ta_ph = bevl_other.bemd_0(947762649);
bevt_10_ta_ph.bemd_2(-832171868, bevl_i, null);
} /* Line: 407*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 402*/
 else /* Line: 402*/ {
break;
} /* Line: 402*/
} /* Line: 402*/
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_buckets.bem_clear_0();
bevp_buckets.bem_sizeSet_1(bevp_modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_keyIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_nodeIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 447*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 447*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = beva_other.bem_has_1(bevl_x);
if (bevt_3_ta_ph.bevi_bool)/* Line: 448*/ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 449*/
} /* Line: 448*/
 else /* Line: 447*/ {
break;
} /* Line: 447*/
} /* Line: 447*/
} /* Line: 447*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 458*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 458*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 459*/
 else /* Line: 458*/ {
break;
} /* Line: 458*/
} /* Line: 458*/
if (beva_other == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 461*/ {
bevt_1_ta_loop = beva_other.bem_setIteratorGet_0();
while (true)
/* Line: 462*/ {
bevt_4_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 462*/ {
bevl_x = bevt_1_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 463*/
 else /* Line: 462*/ {
break;
} /* Line: 462*/
} /* Line: 462*/
} /* Line: 462*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 476*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_other, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 477*/ {
bevt_0_ta_loop = beva_other.bemd_0(-2030650485);
while (true)
/* Line: 478*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(-1981041811);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 478*/ {
bevl_x = bevt_0_ta_loop.bemd_0(2010653187);
bem_put_1(bevl_x);
} /* Line: 479*/
 else /* Line: 478*/ {
break;
} /* Line: 478*/
} /* Line: 478*/
} /* Line: 478*/
 else /* Line: 477*/ {
bevt_6_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_5_ta_ph = bevt_6_ta_ph.bem_sameType_2(beva_other, bevp_baseNode);
if (bevt_5_ta_ph.bevi_bool)/* Line: 481*/ {
bevt_7_ta_ph = beva_other.bemd_0(1258394262);
bem_put_1(bevt_7_ta_ph);
} /* Line: 482*/
 else /* Line: 483*/ {
bem_put_1(beva_other);
} /* Line: 484*/
} /* Line: 477*/
} /* Line: 477*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_bucketsGet_0() throws Throwable {
return bevp_buckets;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_bucketsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buckets = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {175, 175, 181, 182, 183, 184, 185, 188, 189, 195, 195, 195, 196, 196, 198, 198, 202, 202, 202, 203, 203, 205, 205, 209, 209, 213, 213, 217, 217, 221, 221, 222, 223, 223, 224, 224, 224, 225, 225, 229, 229, 234, 234, 234, 234, 235, 236, 236, 237, 238, 240, 244, 244, 0, 244, 244, 244, 244, 0, 0, 245, 245, 247, 0, 247, 247, 248, 248, 248, 248, 248, 250, 250, 254, 255, 255, 256, 257, 257, 257, 258, 261, 263, 264, 266, 267, 267, 268, 268, 269, 269, 269, 271, 273, 274, 274, 275, 275, 275, 275, 276, 276, 277, 277, 278, 280, 281, 281, 283, 284, 284, 285, 285, 292, 292, 293, 294, 295, 295, 296, 298, 301, 306, 307, 308, 309, 309, 309, 310, 312, 313, 315, 316, 316, 317, 318, 318, 318, 318, 319, 320, 320, 321, 321, 323, 324, 324, 325, 332, 333, 334, 335, 335, 335, 336, 338, 339, 341, 342, 342, 343, 343, 344, 344, 344, 344, 345, 345, 346, 346, 347, 347, 349, 350, 350, 351, 351, 358, 359, 361, 362, 362, 362, 363, 365, 366, 368, 369, 369, 370, 370, 371, 371, 371, 371, 372, 372, 373, 373, 374, 375, 376, 377, 377, 378, 379, 379, 0, 379, 379, 379, 379, 0, 0, 380, 380, 382, 382, 382, 383, 385, 387, 387, 389, 390, 390, 391, 391, 399, 400, 401, 401, 402, 402, 402, 402, 403, 404, 404, 405, 405, 405, 405, 405, 405, 405, 407, 407, 402, 410, 415, 416, 417, 421, 421, 425, 425, 429, 429, 433, 433, 437, 437, 441, 441, 445, 446, 446, 447, 0, 447, 447, 448, 449, 453, 457, 458, 0, 458, 458, 459, 461, 461, 462, 0, 462, 462, 463, 466, 470, 471, 472, 476, 476, 477, 477, 478, 0, 478, 478, 479, 481, 481, 482, 482, 484, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 27, 28, 29, 30, 31, 39, 40, 45, 46, 47, 49, 50, 57, 58, 63, 64, 65, 67, 68, 72, 73, 77, 78, 83, 84, 96, 99, 101, 102, 107, 108, 109, 110, 112, 113, 121, 122, 132, 133, 134, 135, 136, 139, 140, 142, 143, 149, 165, 170, 171, 174, 175, 176, 181, 182, 185, 189, 190, 192, 192, 195, 197, 198, 199, 204, 205, 206, 213, 214, 239, 240, 245, 246, 247, 248, 253, 254, 258, 260, 261, 264, 265, 270, 271, 276, 277, 278, 279, 282, 284, 285, 286, 289, 290, 291, 296, 297, 298, 301, 302, 304, 305, 306, 307, 310, 311, 316, 317, 318, 331, 332, 334, 335, 338, 339, 341, 347, 350, 371, 372, 373, 374, 375, 380, 381, 383, 384, 387, 388, 393, 394, 397, 398, 399, 404, 405, 408, 409, 411, 412, 415, 416, 421, 422, 449, 450, 451, 452, 453, 458, 459, 461, 462, 465, 466, 471, 472, 473, 476, 477, 478, 483, 484, 485, 488, 489, 491, 492, 495, 496, 501, 502, 503, 539, 540, 541, 542, 543, 548, 549, 551, 552, 555, 556, 561, 562, 563, 566, 567, 568, 573, 574, 575, 578, 579, 581, 582, 583, 586, 591, 592, 593, 598, 599, 602, 603, 604, 609, 610, 613, 617, 618, 621, 622, 623, 624, 626, 632, 633, 636, 637, 642, 643, 644, 666, 667, 668, 669, 670, 673, 674, 679, 680, 681, 686, 687, 688, 689, 690, 691, 692, 693, 696, 697, 699, 705, 708, 709, 710, 715, 716, 720, 721, 725, 726, 730, 731, 735, 736, 740, 741, 750, 751, 756, 757, 757, 760, 762, 763, 765, 773, 783, 784, 784, 787, 789, 790, 796, 801, 802, 802, 805, 807, 808, 815, 819, 820, 821, 833, 838, 839, 840, 842, 842, 845, 847, 848, 856, 857, 859, 860, 863, 870, 873, 877, 880};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 175 20
new 0 175 20
new 1 175 21
assign 1 181 25
assign 1 182 26
new 0 182 26
assign 1 183 27
new 0 183 27
assign 1 184 28
new 0 184 28
assign 1 185 29
new 0 185 29
assign 1 188 30
new 1 188 30
assign 1 189 31
new 0 189 31
assign 1 195 39
new 0 195 39
assign 1 195 40
equals 1 195 45
assign 1 196 46
new 0 196 46
return 1 196 47
assign 1 198 49
new 0 198 49
return 1 198 50
assign 1 202 57
new 0 202 57
assign 1 202 58
equals 1 202 63
assign 1 203 64
new 0 203 64
return 1 203 65
assign 1 205 67
new 0 205 67
return 1 205 68
assign 1 209 72
toString 0 209 72
return 1 209 73
assign 1 213 77
new 1 213 77
new 1 213 78
assign 1 217 83
new 1 217 83
return 1 217 84
assign 1 221 96
arrayIteratorGet 0 221 96
assign 1 221 99
hasNextGet 0 221 99
assign 1 222 101
nextGet 0 222 101
assign 1 223 102
def 1 223 107
assign 1 224 108
keyGet 0 224 108
assign 1 224 109
innerPut 4 224 109
assign 1 224 110
not 0 224 110
assign 1 225 112
new 0 225 112
return 1 225 113
assign 1 229 121
new 0 229 121
return 1 229 122
assign 1 234 132
sizeGet 0 234 132
assign 1 234 133
multiply 1 234 133
assign 1 234 134
new 0 234 134
assign 1 234 135
add 1 234 135
assign 1 235 136
new 1 235 136
assign 1 236 139
insertAll 2 236 139
assign 1 236 140
not 0 236 140
assign 1 237 142
increment 0 237 142
assign 1 238 143
new 1 238 143
return 1 240 149
assign 1 244 165
undef 1 244 170
assign 1 0 171
assign 1 244 174
sizeGet 0 244 174
assign 1 244 175
sizeGet 0 244 175
assign 1 244 176
notEquals 1 244 181
assign 1 0 182
assign 1 0 185
assign 1 245 189
new 0 245 189
return 1 245 190
assign 1 247 192
setIteratorGet 0 0 192
assign 1 247 195
hasNextGet 0 247 195
assign 1 247 197
nextGet 0 247 197
assign 1 248 198
has 1 248 198
assign 1 248 199
not 0 248 204
assign 1 248 205
new 0 248 205
return 1 248 206
assign 1 250 213
new 0 250 213
return 1 250 214
assign 1 254 239
sizeGet 0 254 239
assign 1 255 240
undef 1 255 245
assign 1 256 246
getHash 1 256 246
assign 1 257 247
new 0 257 247
assign 1 257 248
lesser 1 257 253
assign 1 258 254
abs 0 258 254
assign 1 261 258
hvalGet 0 261 258
assign 1 263 260
modulus 1 263 260
assign 1 264 261
assign 1 266 264
get 1 266 264
assign 1 267 265
undef 1 267 270
assign 1 268 271
undef 1 268 276
assign 1 269 277
create 0 269 277
assign 1 269 278
new 3 269 278
put 2 269 279
put 2 271 282
assign 1 273 284
new 0 273 284
assign 1 274 285
new 0 274 285
return 1 274 286
assign 1 275 289
hvalGet 0 275 289
assign 1 275 290
modulus 1 275 290
assign 1 275 291
notEquals 1 275 296
assign 1 276 297
new 0 276 297
return 1 276 298
assign 1 277 301
keyGet 0 277 301
assign 1 277 302
isEqual 2 277 302
putTo 2 278 304
assign 1 280 305
new 0 280 305
assign 1 281 306
new 0 281 306
return 1 281 307
assign 1 283 310
increment 0 283 310
assign 1 284 311
greaterEquals 1 284 316
assign 1 285 317
new 0 285 317
return 1 285 318
assign 1 292 331
innerPut 4 292 331
assign 1 292 332
not 0 292 332
assign 1 293 334
assign 1 294 335
rehash 1 294 335
assign 1 295 338
innerPut 4 295 338
assign 1 295 339
not 0 295 339
assign 1 296 341
rehash 1 296 341
assign 1 298 347
assign 1 301 350
increment 0 301 350
assign 1 306 371
assign 1 307 372
sizeGet 0 307 372
assign 1 308 373
getHash 1 308 373
assign 1 309 374
new 0 309 374
assign 1 309 375
lesser 1 309 380
assign 1 310 381
abs 0 310 381
assign 1 312 383
modulus 1 312 383
assign 1 313 384
assign 1 315 387
get 1 315 387
assign 1 316 388
undef 1 316 393
return 1 317 394
assign 1 318 397
hvalGet 0 318 397
assign 1 318 398
modulus 1 318 398
assign 1 318 399
notEquals 1 318 404
return 1 319 405
assign 1 320 408
keyGet 0 320 408
assign 1 320 409
isEqual 2 320 409
assign 1 321 411
getFrom 0 321 411
return 1 321 412
assign 1 323 415
increment 0 323 415
assign 1 324 416
greaterEquals 1 324 421
return 1 325 422
assign 1 332 449
assign 1 333 450
sizeGet 0 333 450
assign 1 334 451
getHash 1 334 451
assign 1 335 452
new 0 335 452
assign 1 335 453
lesser 1 335 458
assign 1 336 459
abs 0 336 459
assign 1 338 461
modulus 1 338 461
assign 1 339 462
assign 1 341 465
get 1 341 465
assign 1 342 466
undef 1 342 471
assign 1 343 472
new 0 343 472
return 1 343 473
assign 1 344 476
hvalGet 0 344 476
assign 1 344 477
modulus 1 344 477
assign 1 344 478
notEquals 1 344 483
assign 1 345 484
new 0 345 484
return 1 345 485
assign 1 346 488
keyGet 0 346 488
assign 1 346 489
isEqual 2 346 489
assign 1 347 491
new 0 347 491
return 1 347 492
assign 1 349 495
increment 0 349 495
assign 1 350 496
greaterEquals 1 350 501
assign 1 351 502
new 0 351 502
return 1 351 503
assign 1 358 539
assign 1 359 540
sizeGet 0 359 540
assign 1 361 541
getHash 1 361 541
assign 1 362 542
new 0 362 542
assign 1 362 543
lesser 1 362 548
assign 1 363 549
abs 0 363 549
assign 1 365 551
modulus 1 365 551
assign 1 366 552
assign 1 368 555
get 1 368 555
assign 1 369 556
undef 1 369 561
assign 1 370 562
new 0 370 562
return 1 370 563
assign 1 371 566
hvalGet 0 371 566
assign 1 371 567
modulus 1 371 567
assign 1 371 568
notEquals 1 371 573
assign 1 372 574
new 0 372 574
return 1 372 575
assign 1 373 578
keyGet 0 373 578
assign 1 373 579
isEqual 2 373 579
put 2 374 581
assign 1 375 582
decrement 0 375 582
assign 1 376 583
increment 0 376 583
assign 1 377 586
lesser 1 377 591
assign 1 378 592
get 1 378 592
assign 1 379 593
undef 1 379 598
assign 1 0 599
assign 1 379 602
hvalGet 0 379 602
assign 1 379 603
modulus 1 379 603
assign 1 379 604
notEquals 1 379 609
assign 1 0 610
assign 1 0 613
assign 1 380 617
new 0 380 617
return 1 380 618
assign 1 382 621
new 0 382 621
assign 1 382 622
subtract 1 382 622
put 2 382 623
put 2 383 624
assign 1 385 626
increment 0 385 626
assign 1 387 632
new 0 387 632
return 1 387 633
assign 1 389 636
increment 0 389 636
assign 1 390 637
greaterEquals 1 390 642
assign 1 391 643
new 0 391 643
return 1 391 644
assign 1 399 666
create 0 399 666
copyTo 1 400 667
assign 1 401 668
copy 0 401 668
bucketsSet 1 401 669
assign 1 402 670
new 0 402 670
assign 1 402 673
lengthGet 0 402 673
assign 1 402 674
lesser 1 402 679
assign 1 403 680
get 1 403 680
assign 1 404 681
def 1 404 686
assign 1 405 687
bucketsGet 0 405 687
assign 1 405 688
create 0 405 688
assign 1 405 689
hvalGet 0 405 689
assign 1 405 690
keyGet 0 405 690
assign 1 405 691
getFrom 0 405 691
assign 1 405 692
new 3 405 692
put 2 405 693
assign 1 407 696
bucketsGet 0 407 696
put 2 407 697
assign 1 402 699
increment 0 402 699
return 1 410 705
clear 0 415 708
sizeSet 1 416 709
assign 1 417 710
new 0 417 710
assign 1 421 715
new 1 421 715
return 1 421 716
assign 1 425 720
new 1 425 720
return 1 425 721
assign 1 429 725
new 1 429 725
return 1 429 726
assign 1 433 730
keyIteratorGet 0 433 730
return 1 433 731
assign 1 437 735
new 1 437 735
return 1 437 736
assign 1 441 740
nodeIteratorGet 0 441 740
return 1 441 741
assign 1 445 750
new 0 445 750
assign 1 446 751
def 1 446 756
assign 1 447 757
setIteratorGet 0 0 757
assign 1 447 760
hasNextGet 0 447 760
assign 1 447 762
nextGet 0 447 762
assign 1 448 763
has 1 448 763
put 1 449 765
return 1 453 773
assign 1 457 783
new 0 457 783
assign 1 458 784
setIteratorGet 0 0 784
assign 1 458 787
hasNextGet 0 458 787
assign 1 458 789
nextGet 0 458 789
put 1 459 790
assign 1 461 796
def 1 461 801
assign 1 462 802
setIteratorGet 0 0 802
assign 1 462 805
hasNextGet 0 462 805
assign 1 462 807
nextGet 0 462 807
put 1 463 808
return 1 466 815
assign 1 470 819
copy 0 470 819
addValue 1 471 820
return 1 472 821
assign 1 476 833
def 1 476 838
assign 1 477 839
new 0 477 839
assign 1 477 840
sameType 2 477 840
assign 1 478 842
iteratorGet 0 0 842
assign 1 478 845
hasNextGet 0 478 845
assign 1 478 847
nextGet 0 478 847
put 1 479 848
assign 1 481 856
new 0 481 856
assign 1 481 857
sameType 2 481 857
assign 1 482 859
keyGet 0 482 859
put 1 482 860
put 1 484 863
return 1 0 870
assign 1 0 873
return 1 0 877
assign 1 0 880
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -357122009: return bem_sizeGet_0();
case -280965545: return bem_create_0();
case -1744345454: return bem_serializationIteratorGet_0();
case 320209385: return bem_serializeToString_0();
case -356228351: return bem_nodeIteratorGet_0();
case -192913186: return bem_notEmptyGet_0();
case -46953866: return bem_keysGet_0();
case -822554769: return bem_setIteratorGet_0();
case -2030650485: return bem_iteratorGet_0();
case 1208900678: return bem_nodesGet_0();
case -1894078219: return bem_keyIteratorGet_0();
case 1728425397: return bem_new_0();
case 2129615446: return bem_hashGet_0();
case -399727008: return bem_isEmptyGet_0();
case 1461439411: return bem_print_0();
case -840722244: return bem_clear_0();
case 1955630180: return bem_copy_0();
case 947762649: return bem_bucketsGet_0();
case -1992408208: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1128896308: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -494047982: return bem_delete_1(bevd_0);
case -846736338: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1490815914: return bem_put_1(bevd_0);
case 1541276215: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -304345246: return bem_has_1(bevd_0);
case -703550458: return bem_def_1(bevd_0);
case -452045086: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 238419537: return bem_equals_1(bevd_0);
case -45650867: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 335648263: return bem_sizeSet_1(bevd_0);
case -1476381098: return bem_bucketsSet_1(bevd_0);
case 878611554: return bem_copyTo_1(bevd_0);
case 348757805: return bem_undef_1(bevd_0);
case -458287772: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1242491213: return bem_addValue_1(bevd_0);
case -631144085: return bem_get_1(bevd_0);
case -1410913493: return bem_notEquals_1(bevd_0);
case -78542674: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1749764545: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1480112933: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 880586801: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2055106389: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1664418666: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -382827838: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
