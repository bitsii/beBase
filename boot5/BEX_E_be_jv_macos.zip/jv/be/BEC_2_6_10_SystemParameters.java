package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_8 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_1, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_10 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_12 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_3, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_4, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_17 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x23};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_5, 1));
public static BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public BEC_2_6_10_SystemParameters bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
bem_new_0();
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevl_ii = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 124 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(1879248692);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold );
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(-1653734043, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(-591128848, bevt_9_tmpany_phold);
beva__args.bemd_2(-724454193, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 124 */
 else  /* Line: 124 */ {
break;
} /* Line: 124 */
} /* Line: 124 */
} /* Line: 124 */
if (bevp_args == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevp_args = (BEC_2_9_4_ContainerList) beva__args;
bevp_params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (new BEC_2_9_4_ContainerList()).bem_new_0();
} /* Line: 131 */
 else  /* Line: 132 */ {
bevp_args = bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
} /* Line: 133 */
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(1011206981);
while (true)
 /* Line: 137 */ {
bevt_11_tmpany_phold = bevt_0_tmpany_loop.bemd_0(2119728128);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 137 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(2081884322);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_13_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_14_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_0;
if (bevt_13_tmpany_phold.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_1;
bevt_16_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_2;
bevl_fa = bevl_i.bem_substring_2(bevt_15_tmpany_phold, bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_3;
if (bevt_18_tmpany_phold.bevi_int > bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_20_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_4;
bevt_21_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_5;
bevl_fb = bevl_i.bem_substring_2(bevt_20_tmpany_phold, bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_24_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_6;
if (bevt_23_tmpany_phold.bevi_int > bevt_24_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 145 */ {
bevt_25_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_7;
bevt_26_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_8;
bevl_fc = bevl_i.bem_substring_2(bevt_25_tmpany_phold, bevt_26_tmpany_phold);
} /* Line: 146 */
} /* Line: 145 */
} /* Line: 143 */
if (bevl_pname == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 150 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 151 */ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 152 */
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
} /* Line: 155 */
 else  /* Line: 150 */ {
if (bevl_fb == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_9;
bevt_30_tmpany_phold = bevl_fb.bem_equals_1(bevt_31_tmpany_phold);
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 156 */
 else  /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 156 */ {
bevt_32_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_10;
bevt_33_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
} /* Line: 157 */
 else  /* Line: 150 */ {
if (bevl_fa == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevt_36_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_11;
bevt_35_tmpany_phold = bevl_fa.bem_equals_1(bevt_36_tmpany_phold);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 158 */
 else  /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 158 */ {
bevt_37_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_12;
bevt_38_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_37_tmpany_phold, bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_13;
bevl_pos = bevl_par.bem_find_1(bevt_39_tmpany_phold);
if (bevl_pos == null) {
bevt_40_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevt_41_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_14;
bevl_key = bevl_par.bem_substring_2(bevt_41_tmpany_phold, bevl_pos);
bevt_43_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_15;
bevt_42_tmpany_phold = bevl_pos.bem_add_1(bevt_43_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_42_tmpany_phold);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 164 */
} /* Line: 161 */
 else  /* Line: 150 */ {
if (bevl_fc == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_46_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_16;
bevt_45_tmpany_phold = bevl_fc.bem_equals_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
 else  /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 166 */ {
bevt_47_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_17;
bevt_48_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevl_pnameComment = be.BECS_Runtime.boolTrue;
} /* Line: 168 */
 else  /* Line: 150 */ {
if (bevl_fa == null) {
bevt_49_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_51_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_18;
bevt_50_tmpany_phold = bevl_fa.bem_equals_1(bevt_51_tmpany_phold);
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 169 */
 else  /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 170 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
 else  /* Line: 137 */ {
break;
} /* Line: 137 */
} /* Line: 137 */
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 177 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 178 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 178 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(-591128848, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 178 */
 else  /* Line: 178 */ {
break;
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 183 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(-591128848, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 183 */
 else  /* Line: 183 */ {
break;
} /* Line: 183 */
} /* Line: 183 */
} /* Line: 183 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevl__params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 189 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(2119728128);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 189 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(2081884322);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 193 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 193 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(-591128848, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 194 */
 else  /* Line: 193 */ {
break;
} /* Line: 193 */
} /* Line: 193 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(-591128848, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 197 */
 else  /* Line: 189 */ {
break;
} /* Line: 189 */
} /* Line: 189 */
bevp_params = bevl__params;
} /* Line: 199 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 205 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 207 */
return beva_isit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevl_pl = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 229 */
return bevl_pl;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 240 */ {
return beva_default;
} /* Line: 241 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevl_vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 251 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) throws Throwable {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-2015375271);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(-428540784);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(-325367324);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(1269771729);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGet_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGet_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGet_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 111, 118, 119, 123, 123, 124, 124, 124, 125, 125, 125, 124, 128, 128, 129, 130, 131, 133, 135, 136, 137, 0, 137, 137, 138, 139, 140, 141, 141, 141, 141, 142, 142, 142, 143, 143, 143, 143, 144, 144, 144, 145, 145, 145, 145, 146, 146, 146, 150, 150, 151, 151, 152, 154, 155, 156, 156, 156, 156, 0, 0, 0, 157, 157, 157, 158, 158, 158, 158, 0, 0, 0, 159, 159, 159, 160, 160, 161, 161, 162, 162, 163, 163, 163, 164, 166, 166, 166, 166, 0, 0, 0, 167, 167, 167, 168, 169, 169, 169, 169, 0, 0, 0, 169, 169, 170, 176, 177, 177, 178, 178, 178, 178, 179, 179, 179, 178, 182, 182, 183, 183, 183, 183, 184, 184, 184, 183, 187, 187, 188, 189, 189, 190, 191, 192, 193, 0, 193, 193, 194, 194, 196, 197, 199, 204, 205, 205, 207, 210, 214, 214, 214, 218, 218, 222, 222, 226, 227, 227, 228, 229, 231, 235, 235, 239, 240, 240, 241, 243, 243, 248, 249, 249, 250, 251, 253, 257, 257, 257, 258, 258, 259, 259, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {43, 44, 48, 49, 117, 122, 123, 126, 127, 129, 130, 131, 132, 139, 144, 145, 146, 147, 150, 152, 153, 154, 154, 157, 159, 160, 161, 162, 163, 164, 165, 170, 171, 172, 173, 174, 175, 176, 181, 182, 183, 184, 185, 186, 187, 192, 193, 194, 195, 199, 204, 205, 210, 211, 213, 214, 217, 222, 223, 224, 226, 229, 233, 236, 237, 238, 241, 246, 247, 248, 250, 253, 257, 260, 261, 262, 263, 264, 265, 270, 271, 272, 273, 274, 275, 276, 280, 285, 286, 287, 289, 292, 296, 299, 300, 301, 302, 305, 310, 311, 312, 314, 317, 321, 323, 328, 329, 365, 366, 371, 372, 375, 376, 381, 382, 383, 384, 385, 392, 397, 398, 401, 402, 407, 408, 409, 410, 411, 418, 423, 424, 425, 428, 430, 431, 432, 433, 433, 436, 438, 439, 440, 446, 447, 453, 460, 461, 466, 467, 469, 474, 475, 476, 480, 481, 485, 486, 491, 492, 497, 498, 499, 501, 505, 506, 512, 513, 518, 519, 521, 522, 527, 528, 533, 534, 535, 537, 547, 548, 549, 550, 551, 552, 553, 554, 558, 561, 565, 568, 572, 575, 579, 582, 586};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 43
new 0 111 43
assign 1 111 44
new 1 111 44
new 0 118 48
addArgs 1 119 49
assign 1 123 117
def 1 123 122
assign 1 124 123
new 0 124 123
assign 1 124 126
lengthGet 0 124 126
assign 1 124 127
lesser 1 124 127
assign 1 125 129
get 1 125 129
assign 1 125 130
process 1 125 130
put 2 125 131
assign 1 124 132
increment 0 124 132
assign 1 128 139
undef 1 128 144
assign 1 129 145
assign 1 130 146
new 0 130 146
assign 1 131 147
new 0 131 147
assign 1 133 150
add 1 133 150
assign 1 135 152
assign 1 136 153
new 0 136 153
assign 1 137 154
iteratorGet 0 0 154
assign 1 137 157
hasNextGet 0 137 157
assign 1 137 159
nextGet 0 137 159
assign 1 138 160
assign 1 139 161
assign 1 140 162
assign 1 141 163
sizeGet 0 141 163
assign 1 141 164
new 0 141 164
assign 1 141 165
greater 1 141 170
assign 1 142 171
new 0 142 171
assign 1 142 172
new 0 142 172
assign 1 142 173
substring 2 142 173
assign 1 143 174
sizeGet 0 143 174
assign 1 143 175
new 0 143 175
assign 1 143 176
greater 1 143 181
assign 1 144 182
new 0 144 182
assign 1 144 183
new 0 144 183
assign 1 144 184
substring 2 144 184
assign 1 145 185
sizeGet 0 145 185
assign 1 145 186
new 0 145 186
assign 1 145 187
greater 1 145 192
assign 1 146 193
new 0 146 193
assign 1 146 194
new 0 146 194
assign 1 146 195
substring 2 146 195
assign 1 150 199
def 1 150 204
assign 1 151 205
not 0 151 210
addParameter 2 152 211
assign 1 154 213
assign 1 155 214
new 0 155 214
assign 1 156 217
def 1 156 222
assign 1 156 223
new 0 156 223
assign 1 156 224
equals 1 156 224
assign 1 0 226
assign 1 0 229
assign 1 0 233
assign 1 157 236
new 0 157 236
assign 1 157 237
sizeGet 0 157 237
assign 1 157 238
substring 2 157 238
assign 1 158 241
def 1 158 246
assign 1 158 247
new 0 158 247
assign 1 158 248
equals 1 158 248
assign 1 0 250
assign 1 0 253
assign 1 0 257
assign 1 159 260
new 0 159 260
assign 1 159 261
sizeGet 0 159 261
assign 1 159 262
substring 2 159 262
assign 1 160 263
new 0 160 263
assign 1 160 264
find 1 160 264
assign 1 161 265
def 1 161 270
assign 1 162 271
new 0 162 271
assign 1 162 272
substring 2 162 272
assign 1 163 273
new 0 163 273
assign 1 163 274
add 1 163 274
assign 1 163 275
substring 1 163 275
addParameter 2 164 276
assign 1 166 280
def 1 166 285
assign 1 166 286
new 0 166 286
assign 1 166 287
equals 1 166 287
assign 1 0 289
assign 1 0 292
assign 1 0 296
assign 1 167 299
new 0 167 299
assign 1 167 300
sizeGet 0 167 300
assign 1 167 301
substring 2 167 301
assign 1 168 302
new 0 168 302
assign 1 169 305
def 1 169 310
assign 1 169 311
new 0 169 311
assign 1 169 312
equals 1 169 312
assign 1 0 314
assign 1 0 317
assign 1 0 321
assign 1 169 323
not 0 169 328
addValue 1 170 329
assign 1 176 365
assign 1 177 366
def 1 177 371
assign 1 178 372
new 0 178 372
assign 1 178 375
lengthGet 0 178 375
assign 1 178 376
lesser 1 178 381
assign 1 179 382
get 1 179 382
assign 1 179 383
process 1 179 383
put 2 179 384
assign 1 178 385
increment 0 178 385
assign 1 182 392
def 1 182 397
assign 1 183 398
new 0 183 398
assign 1 183 401
lengthGet 0 183 401
assign 1 183 402
lesser 1 183 407
assign 1 184 408
get 1 184 408
assign 1 184 409
process 1 184 409
put 2 184 410
assign 1 183 411
increment 0 183 411
assign 1 187 418
def 1 187 423
assign 1 188 424
new 0 188 424
assign 1 189 425
keyIteratorGet 0 189 425
assign 1 189 428
hasNextGet 0 189 428
assign 1 190 430
nextGet 0 190 430
assign 1 191 431
get 1 191 431
assign 1 192 432
new 0 192 432
assign 1 193 433
linkedListIteratorGet 0 0 433
assign 1 193 436
hasNextGet 0 193 436
assign 1 193 438
nextGet 0 193 438
assign 1 194 439
process 1 194 439
addValue 1 194 440
assign 1 196 446
process 1 196 446
put 2 197 447
assign 1 199 453
assign 1 204 460
getFirst 1 204 460
assign 1 205 461
def 1 205 466
assign 1 207 467
new 1 207 467
return 1 210 469
assign 1 214 474
new 0 214 474
assign 1 214 475
isTrue 2 214 475
return 1 214 476
assign 1 218 480
has 1 218 480
return 1 218 481
assign 1 222 485
get 1 222 485
return 1 222 486
assign 1 226 491
get 1 226 491
assign 1 227 492
undef 1 227 497
assign 1 228 498
new 0 228 498
addValue 1 229 499
return 1 231 501
assign 1 235 505
getFirst 2 235 505
return 1 235 506
assign 1 239 512
get 1 239 512
assign 1 240 513
undef 1 240 518
return 1 241 519
assign 1 243 521
firstGet 0 243 521
return 1 243 522
assign 1 248 527
get 1 248 527
assign 1 249 528
undef 1 249 533
assign 1 250 534
new 0 250 534
put 2 251 535
addValue 1 253 537
assign 1 257 547
readerGet 0 257 547
assign 1 257 548
open 0 257 548
assign 1 257 549
readString 0 257 549
assign 1 258 550
readerGet 0 258 550
close 0 258 551
assign 1 259 552
tokenize 1 259 552
assign 1 259 553
toList 0 259 553
addArgs 1 260 554
return 1 0 558
assign 1 0 561
return 1 0 565
assign 1 0 568
return 1 0 572
assign 1 0 575
return 1 0 579
assign 1 0 582
return 1 0 586
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -463196257: return bem_serializeContents_0();
case 115695864: return bem_once_0();
case 1941582964: return bem_sourceFileNameGet_0();
case -586791724: return bem_orderedGet_0();
case -210661827: return bem_copy_0();
case -924621717: return bem_argsGet_0();
case 1632866629: return bem_paramsGet_0();
case -1052813950: return bem_toAny_0();
case -1844033239: return bem_many_0();
case -1728373933: return bem_new_0();
case 1332992288: return bem_fieldIteratorGet_0();
case -586562582: return bem_tagGet_0();
case 1328810726: return bem_preProcessorGet_0();
case 505645727: return bem_create_0();
case 3495950: return bem_hashGet_0();
case -1040761527: return bem_echo_0();
case 560354327: return bem_serializeToString_0();
case -1664120672: return bem_fileTokGet_0();
case 31457629: return bem_print_0();
case -1265669844: return bem_deserializeClassNameGet_0();
case 1951974872: return bem_classNameGet_0();
case 1011206981: return bem_iteratorGet_0();
case -1182088407: return bem_serializationIteratorGet_0();
case -1027395170: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1843942068: return bem_def_1(bevd_0);
case -1923884134: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1395839705: return bem_copyTo_1(bevd_0);
case 1545764367: return bem_sameType_1(bevd_0);
case 2073856910: return bem_orderedSet_1(bevd_0);
case -50695613: return bem_argsSet_1(bevd_0);
case -66761530: return bem_paramsSet_1(bevd_0);
case 1342994706: return bem_defined_1(bevd_0);
case 1743355513: return bem_preProcessorSet_1(bevd_0);
case 1696267060: return bem_sameObject_1(bevd_0);
case -947905368: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -393616236: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -410022434: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case -775795960: return bem_addArgs_1(bevd_0);
case -1667698157: return bem_equals_1(bevd_0);
case -1175815914: return bem_fileTokSet_1(bevd_0);
case -1653734043: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1536743123: return bem_sameClass_1(bevd_0);
case 1480277969: return bem_undefined_1(bevd_0);
case 2016961897: return bem_otherType_1(bevd_0);
case -907629645: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case 551223712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1914824302: return bem_notEquals_1(bevd_0);
case -1682621253: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case -767207715: return bem_otherClass_1(bevd_0);
case 241397973: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1369310094: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case -2013963177: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1016690827: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1304489926: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -933309971: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 363117363: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1289901535: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1157468779: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 129084661: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1168064516: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 468732887: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1967402540: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -209626346: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
