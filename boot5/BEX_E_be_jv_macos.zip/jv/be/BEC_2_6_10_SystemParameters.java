package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x70,0x61,0x72,0x61,0x6D,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x6F,0x72,0x64,0x65,0x72,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_1, 4));
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_2, 6));
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_3, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_6 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_9 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_4, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_13 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_5, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_6 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_6, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_18 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_7 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_7, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_20 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_8 = {0x23};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_8, 1));
public static BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_initialArgs;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public BEC_2_6_10_SystemParameters bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevp_initialArgs = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_args = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toJson_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_9_4_ContainerMaps bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_10_JsonMarshaller bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[7];
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerMaps) BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_10_SystemParameters_bels_1));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_6_10_SystemParameters_bels_2));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_10_SystemParameters_bels_3));
bevd_x[0] = bevt_1_tmpany_phold;
bevd_x[1] = bevp_args;
bevd_x[2] = bevt_2_tmpany_phold;
bevd_x[3] = bevp_params;
bevd_x[4] = bevt_3_tmpany_phold;
bevd_x[5] = bevp_ordered;
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_phold.bem_forwardCall_2(new BEC_2_4_6_TextString("from".getBytes("UTF-8")), (new BEC_2_9_4_ContainerList(bevd_x, 6)).bem_copy_0());
bevt_5_tmpany_phold = (new BEC_2_4_10_JsonMarshaller()).bem_new_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_marshall_1(bevl_jsm);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fromJson_1(BEC_2_4_6_TextString beva_jsms) throws Throwable {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_4_12_JsonUnmarshaller bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_12_JsonUnmarshaller()).bem_new_0();
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_phold.bem_unmarshall_1(beva_jsms);
bevt_1_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_0;
bevp_args = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_1;
bevp_params = (BEC_2_9_3_ContainerMap) bevl_jsm.bem_get_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_2;
bevp_ordered = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fromJsonFile_1(BEC_2_2_4_IOFile beva_jsf) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = beva_jsf.bem_readerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-2105265423);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-2053708108);
bem_fromJson_1((BEC_2_4_6_TextString) bevt_0_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_toJsonFile_1(BEC_2_2_4_IOFile beva_jsf) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = beva_jsf.bem_writerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-2105265423);
bevt_2_tmpany_phold = bem_toJson_0();
bevt_0_tmpany_phold.bemd_1(1907260621, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addValue_1(BEC_2_6_10_SystemParameters beva_p) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_9_10_ContainerLinkedList bevl_cp = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_9_4_ContainerList bevt_1_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_p.bem_argsGet_0();
bevp_args.bem_addValue_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = beva_p.bem_orderedGet_0();
bevp_ordered.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = beva_p.bem_paramsGet_0();
bevt_0_tmpany_loop = bevt_3_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 140 */ {
bevt_4_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1639542906);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_kv = bevt_0_tmpany_loop.bemd_0(-1466225858);
bevt_5_tmpany_phold = bevl_kv.bemd_0(-1995600260);
bevl_cp = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevt_5_tmpany_phold);
if (bevl_cp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_7_tmpany_phold = bevl_kv.bemd_0(945901393);
bevl_cp.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 143 */
 else  /* Line: 144 */ {
bevt_8_tmpany_phold = bevl_kv.bemd_0(-1995600260);
bevt_9_tmpany_phold = bevl_kv.bemd_0(945901393);
bevp_params.bem_put_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
} /* Line: 145 */
} /* Line: 142 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
bem_new_0();
bevp_initialArgs = beva__args;
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevl_ii = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 158 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(-921183157);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold );
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(-1230021919, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(153147626, bevt_9_tmpany_phold);
beva__args.bemd_2(560517072, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 158 */
 else  /* Line: 158 */ {
break;
} /* Line: 158 */
} /* Line: 158 */
} /* Line: 158 */
bevp_args = bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(-579194210);
while (true)
 /* Line: 165 */ {
bevt_10_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1639542906);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 165 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1466225858);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_12_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_13_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_3;
if (bevt_12_tmpany_phold.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_4;
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_5;
bevl_fa = bevl_i.bem_substring_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_18_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_6;
if (bevt_17_tmpany_phold.bevi_int > bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_7;
bevt_20_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_8;
bevl_fb = bevl_i.bem_substring_2(bevt_19_tmpany_phold, bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_23_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_9;
if (bevt_22_tmpany_phold.bevi_int > bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_10;
bevt_25_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_11;
bevl_fc = bevl_i.bem_substring_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
} /* Line: 174 */
} /* Line: 173 */
} /* Line: 171 */
if (bevl_pname == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 178 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 179 */ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 180 */
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
} /* Line: 183 */
 else  /* Line: 178 */ {
if (bevl_fb == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 184 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_12;
bevt_29_tmpany_phold = bevl_fb.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 184 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 184 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 184 */
 else  /* Line: 184 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 184 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_13;
bevt_32_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_31_tmpany_phold, bevt_32_tmpany_phold);
} /* Line: 185 */
 else  /* Line: 178 */ {
if (bevl_fa == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_35_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_14;
bevt_34_tmpany_phold = bevl_fa.bem_equals_1(bevt_35_tmpany_phold);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 186 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 186 */
 else  /* Line: 186 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 186 */ {
bevt_36_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_15;
bevt_37_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_16;
bevl_pos = bevl_par.bem_find_1(bevt_38_tmpany_phold);
if (bevl_pos == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_40_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_17;
bevl_key = bevl_par.bem_substring_2(bevt_40_tmpany_phold, bevl_pos);
bevt_42_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_18;
bevt_41_tmpany_phold = bevl_pos.bem_add_1(bevt_42_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_41_tmpany_phold);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 192 */
} /* Line: 189 */
 else  /* Line: 178 */ {
if (bevl_fc == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_45_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_19;
bevt_44_tmpany_phold = bevl_fc.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 194 */
 else  /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 194 */ {
bevt_46_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_20;
bevt_47_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevl_pnameComment = be.BECS_Runtime.boolTrue;
} /* Line: 196 */
 else  /* Line: 178 */ {
if (bevl_fa == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_50_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_21;
bevt_49_tmpany_phold = bevl_fa.bem_equals_1(bevt_50_tmpany_phold);
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 197 */
 else  /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 198 */
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
 else  /* Line: 165 */ {
break;
} /* Line: 165 */
} /* Line: 165 */
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 206 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(153147626, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 206 */
 else  /* Line: 206 */ {
break;
} /* Line: 206 */
} /* Line: 206 */
} /* Line: 206 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 210 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 211 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(153147626, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 211 */
 else  /* Line: 211 */ {
break;
} /* Line: 211 */
} /* Line: 211 */
} /* Line: 211 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevl__params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 217 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(1639542906);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 217 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(-1466225858);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 221 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 221 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(153147626, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 222 */
 else  /* Line: 221 */ {
break;
} /* Line: 221 */
} /* Line: 221 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(153147626, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 225 */
 else  /* Line: 217 */ {
break;
} /* Line: 217 */
} /* Line: 217 */
bevp_params = bevl__params;
} /* Line: 227 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 233 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 235 */
return beva_isit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevl_pl = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 257 */
return bevl_pl;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 268 */ {
return beva_default;
} /* Line: 269 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
bem_addParam_2(beva_name, beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParam_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 281 */ {
bevl_vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 283 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) throws Throwable {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-2105265423);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(-230148247);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(-1342163691);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(329004727);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_initialArgsGet_0() throws Throwable {
return bevp_initialArgs;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_initialArgsGetDirect_0() throws Throwable {
return bevp_initialArgs;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_initialArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_initialArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGet_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_orderedGetDirect_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_orderedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGet_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_fileTokGetDirect_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_fileTokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGet_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_preProcessorGetDirect_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_preProcessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_preProcessor = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {107, 108, 109, 110, 111, 111, 118, 118, 118, 118, 118, 119, 119, 119, 123, 123, 124, 124, 125, 125, 126, 126, 130, 130, 130, 130, 134, 134, 134, 134, 138, 138, 139, 139, 140, 140, 0, 140, 140, 141, 141, 142, 142, 143, 143, 145, 145, 145, 151, 152, 153, 157, 157, 158, 158, 158, 159, 159, 159, 158, 162, 163, 164, 165, 0, 165, 165, 166, 167, 168, 169, 169, 169, 169, 170, 170, 170, 171, 171, 171, 171, 172, 172, 172, 173, 173, 173, 173, 174, 174, 174, 178, 178, 179, 179, 180, 182, 183, 184, 184, 184, 184, 0, 0, 0, 185, 185, 185, 186, 186, 186, 186, 0, 0, 0, 187, 187, 187, 188, 188, 189, 189, 190, 190, 191, 191, 191, 192, 194, 194, 194, 194, 0, 0, 0, 195, 195, 195, 196, 197, 197, 197, 197, 0, 0, 0, 197, 197, 198, 204, 205, 205, 206, 206, 206, 206, 207, 207, 207, 206, 210, 210, 211, 211, 211, 211, 212, 212, 212, 211, 215, 215, 216, 217, 217, 218, 219, 220, 221, 0, 221, 221, 222, 222, 224, 225, 227, 232, 233, 233, 235, 238, 242, 242, 242, 246, 246, 250, 250, 254, 255, 255, 256, 257, 259, 263, 263, 267, 268, 268, 269, 271, 271, 275, 280, 281, 281, 282, 283, 285, 290, 290, 290, 291, 291, 292, 292, 293, 297, 297, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {50, 51, 52, 53, 54, 55, 67, 68, 69, 70, 71, 78, 79, 80, 88, 89, 90, 91, 92, 93, 94, 95, 102, 103, 104, 105, 112, 113, 114, 115, 131, 132, 133, 134, 135, 136, 136, 139, 141, 142, 143, 144, 149, 150, 151, 154, 155, 156, 166, 167, 168, 235, 240, 241, 244, 245, 247, 248, 249, 250, 257, 258, 259, 260, 260, 263, 265, 266, 267, 268, 269, 270, 271, 276, 277, 278, 279, 280, 281, 282, 287, 288, 289, 290, 291, 292, 293, 298, 299, 300, 301, 305, 310, 311, 316, 317, 319, 320, 323, 328, 329, 330, 332, 335, 339, 342, 343, 344, 347, 352, 353, 354, 356, 359, 363, 366, 367, 368, 369, 370, 371, 376, 377, 378, 379, 380, 381, 382, 386, 391, 392, 393, 395, 398, 402, 405, 406, 407, 408, 411, 416, 417, 418, 420, 423, 427, 429, 434, 435, 471, 472, 477, 478, 481, 482, 487, 488, 489, 490, 491, 498, 503, 504, 507, 508, 513, 514, 515, 516, 517, 524, 529, 530, 531, 534, 536, 537, 538, 539, 539, 542, 544, 545, 546, 552, 553, 559, 566, 567, 572, 573, 575, 580, 581, 582, 586, 587, 591, 592, 597, 598, 603, 604, 605, 607, 611, 612, 618, 619, 624, 625, 627, 628, 631, 637, 638, 643, 644, 645, 647, 657, 658, 659, 660, 661, 662, 663, 664, 669, 670, 673, 676, 679, 683, 687, 690, 693, 697, 701, 704, 707, 711, 715, 718, 721, 725, 729, 732, 735, 739, 743, 746, 749};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 107 50
new 0 107 50
assign 1 108 51
new 0 108 51
assign 1 109 52
new 0 109 52
assign 1 110 53
new 0 110 53
assign 1 111 54
new 0 111 54
assign 1 111 55
new 1 111 55
assign 1 118 67
new 0 118 67
assign 1 118 68
new 0 118 68
assign 1 118 69
new 0 118 69
assign 1 118 70
new 0 118 70
assign 1 118 71
from 6 118 71
assign 1 119 78
new 0 119 78
assign 1 119 79
marshall 1 119 79
return 1 119 80
assign 1 123 88
new 0 123 88
assign 1 123 89
unmarshall 1 123 89
assign 1 124 90
new 0 124 90
assign 1 124 91
get 1 124 91
assign 1 125 92
new 0 125 92
assign 1 125 93
get 1 125 93
assign 1 126 94
new 0 126 94
assign 1 126 95
get 1 126 95
assign 1 130 102
readerGet 0 130 102
assign 1 130 103
open 0 130 103
assign 1 130 104
readStringClose 0 130 104
fromJson 1 130 105
assign 1 134 112
writerGet 0 134 112
assign 1 134 113
open 0 134 113
assign 1 134 114
toJson 0 134 114
writeStringClose 1 134 115
assign 1 138 131
argsGet 0 138 131
addValue 1 138 132
assign 1 139 133
orderedGet 0 139 133
addValue 1 139 134
assign 1 140 135
paramsGet 0 140 135
assign 1 140 136
iteratorGet 0 0 136
assign 1 140 139
hasNextGet 0 140 139
assign 1 140 141
nextGet 0 140 141
assign 1 141 142
keyGet 0 141 142
assign 1 141 143
get 1 141 143
assign 1 142 144
def 1 142 149
assign 1 143 150
valueGet 0 143 150
addValue 1 143 151
assign 1 145 154
keyGet 0 145 154
assign 1 145 155
valueGet 0 145 155
put 2 145 156
new 0 151 166
assign 1 152 167
addArgs 1 153 168
assign 1 157 235
def 1 157 240
assign 1 158 241
new 0 158 241
assign 1 158 244
lengthGet 0 158 244
assign 1 158 245
lesser 1 158 245
assign 1 159 247
get 1 159 247
assign 1 159 248
process 1 159 248
put 2 159 249
assign 1 158 250
increment 0 158 250
assign 1 162 257
add 1 162 257
assign 1 163 258
assign 1 164 259
new 0 164 259
assign 1 165 260
iteratorGet 0 0 260
assign 1 165 263
hasNextGet 0 165 263
assign 1 165 265
nextGet 0 165 265
assign 1 166 266
assign 1 167 267
assign 1 168 268
assign 1 169 269
sizeGet 0 169 269
assign 1 169 270
new 0 169 270
assign 1 169 271
greater 1 169 276
assign 1 170 277
new 0 170 277
assign 1 170 278
new 0 170 278
assign 1 170 279
substring 2 170 279
assign 1 171 280
sizeGet 0 171 280
assign 1 171 281
new 0 171 281
assign 1 171 282
greater 1 171 287
assign 1 172 288
new 0 172 288
assign 1 172 289
new 0 172 289
assign 1 172 290
substring 2 172 290
assign 1 173 291
sizeGet 0 173 291
assign 1 173 292
new 0 173 292
assign 1 173 293
greater 1 173 298
assign 1 174 299
new 0 174 299
assign 1 174 300
new 0 174 300
assign 1 174 301
substring 2 174 301
assign 1 178 305
def 1 178 310
assign 1 179 311
not 0 179 316
addParameter 2 180 317
assign 1 182 319
assign 1 183 320
new 0 183 320
assign 1 184 323
def 1 184 328
assign 1 184 329
new 0 184 329
assign 1 184 330
equals 1 184 330
assign 1 0 332
assign 1 0 335
assign 1 0 339
assign 1 185 342
new 0 185 342
assign 1 185 343
sizeGet 0 185 343
assign 1 185 344
substring 2 185 344
assign 1 186 347
def 1 186 352
assign 1 186 353
new 0 186 353
assign 1 186 354
equals 1 186 354
assign 1 0 356
assign 1 0 359
assign 1 0 363
assign 1 187 366
new 0 187 366
assign 1 187 367
sizeGet 0 187 367
assign 1 187 368
substring 2 187 368
assign 1 188 369
new 0 188 369
assign 1 188 370
find 1 188 370
assign 1 189 371
def 1 189 376
assign 1 190 377
new 0 190 377
assign 1 190 378
substring 2 190 378
assign 1 191 379
new 0 191 379
assign 1 191 380
add 1 191 380
assign 1 191 381
substring 1 191 381
addParameter 2 192 382
assign 1 194 386
def 1 194 391
assign 1 194 392
new 0 194 392
assign 1 194 393
equals 1 194 393
assign 1 0 395
assign 1 0 398
assign 1 0 402
assign 1 195 405
new 0 195 405
assign 1 195 406
sizeGet 0 195 406
assign 1 195 407
substring 2 195 407
assign 1 196 408
new 0 196 408
assign 1 197 411
def 1 197 416
assign 1 197 417
new 0 197 417
assign 1 197 418
equals 1 197 418
assign 1 0 420
assign 1 0 423
assign 1 0 427
assign 1 197 429
not 0 197 434
addValue 1 198 435
assign 1 204 471
assign 1 205 472
def 1 205 477
assign 1 206 478
new 0 206 478
assign 1 206 481
lengthGet 0 206 481
assign 1 206 482
lesser 1 206 487
assign 1 207 488
get 1 207 488
assign 1 207 489
process 1 207 489
put 2 207 490
assign 1 206 491
increment 0 206 491
assign 1 210 498
def 1 210 503
assign 1 211 504
new 0 211 504
assign 1 211 507
lengthGet 0 211 507
assign 1 211 508
lesser 1 211 513
assign 1 212 514
get 1 212 514
assign 1 212 515
process 1 212 515
put 2 212 516
assign 1 211 517
increment 0 211 517
assign 1 215 524
def 1 215 529
assign 1 216 530
new 0 216 530
assign 1 217 531
keyIteratorGet 0 217 531
assign 1 217 534
hasNextGet 0 217 534
assign 1 218 536
nextGet 0 218 536
assign 1 219 537
get 1 219 537
assign 1 220 538
new 0 220 538
assign 1 221 539
linkedListIteratorGet 0 0 539
assign 1 221 542
hasNextGet 0 221 542
assign 1 221 544
nextGet 0 221 544
assign 1 222 545
process 1 222 545
addValue 1 222 546
assign 1 224 552
process 1 224 552
put 2 225 553
assign 1 227 559
assign 1 232 566
getFirst 1 232 566
assign 1 233 567
def 1 233 572
assign 1 235 573
new 1 235 573
return 1 238 575
assign 1 242 580
new 0 242 580
assign 1 242 581
isTrue 2 242 581
return 1 242 582
assign 1 246 586
has 1 246 586
return 1 246 587
assign 1 250 591
get 1 250 591
return 1 250 592
assign 1 254 597
get 1 254 597
assign 1 255 598
undef 1 255 603
assign 1 256 604
new 0 256 604
addValue 1 257 605
return 1 259 607
assign 1 263 611
getFirst 2 263 611
return 1 263 612
assign 1 267 618
get 1 267 618
assign 1 268 619
undef 1 268 624
return 1 269 625
assign 1 271 627
firstGet 0 271 627
return 1 271 628
addParam 2 275 631
assign 1 280 637
get 1 280 637
assign 1 281 638
undef 1 281 643
assign 1 282 644
new 0 282 644
put 2 283 645
addValue 1 285 647
assign 1 290 657
readerGet 0 290 657
assign 1 290 658
open 0 290 658
assign 1 290 659
readString 0 290 659
assign 1 291 660
readerGet 0 291 660
close 0 291 661
assign 1 292 662
tokenize 1 292 662
assign 1 292 663
toList 0 292 663
addArgs 1 293 664
assign 1 297 669
iteratorGet 0 297 669
return 1 297 670
return 1 0 673
return 1 0 676
assign 1 0 679
assign 1 0 683
return 1 0 687
return 1 0 690
assign 1 0 693
assign 1 0 697
return 1 0 701
return 1 0 704
assign 1 0 707
assign 1 0 711
return 1 0 715
return 1 0 718
assign 1 0 721
assign 1 0 725
return 1 0 729
return 1 0 732
assign 1 0 735
assign 1 0 739
return 1 0 743
return 1 0 746
assign 1 0 749
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2079582721: return bem_toString_0();
case 572016682: return bem_serializationIteratorGet_0();
case -165278261: return bem_hashGet_0();
case -1814437399: return bem_fileTokGet_0();
case 310020158: return bem_preProcessorGetDirect_0();
case -980602152: return bem_sourceFileNameGet_0();
case 577869439: return bem_serializeToString_0();
case -579194210: return bem_iteratorGet_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case 1378704246: return bem_argsGetDirect_0();
case -1168657718: return bem_create_0();
case 876000240: return bem_orderedGet_0();
case 1488804201: return bem_paramsGetDirect_0();
case 1476265575: return bem_toAny_0();
case 448246445: return bem_fieldNamesGet_0();
case -882132448: return bem_toJson_0();
case 11313755: return bem_echo_0();
case -1791746868: return bem_print_0();
case -1045898755: return bem_classNameGet_0();
case 1568711247: return bem_fieldIteratorGet_0();
case -1489022328: return bem_once_0();
case 956204141: return bem_orderedGetDirect_0();
case 161726405: return bem_fileTokGetDirect_0();
case -1406264904: return bem_copy_0();
case 334571614: return bem_many_0();
case -1430069919: return bem_serializeContents_0();
case -669530838: return bem_preProcessorGet_0();
case 556258175: return bem_initialArgsGet_0();
case 1148021267: return bem_initialArgsGetDirect_0();
case -1179458078: return bem_argsGet_0();
case 1772271100: return bem_paramsGet_0();
case -1682958828: return bem_tagGet_0();
case -621270081: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case 528546477: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case 279445619: return bem_initialArgsSet_1(bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case -85686461: return bem_orderedSetDirect_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case -165955174: return bem_argsSetDirect_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case 923234269: return bem_fileTokSet_1(bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case -1230021919: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 653855332: return bem_paramsSetDirect_1(bevd_0);
case -1868474583: return bem_preProcessorSetDirect_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case -974312875: return bem_fromJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case -123534170: return bem_initialArgsSetDirect_1(bevd_0);
case -1193379989: return bem_fromJson_1((BEC_2_4_6_TextString) bevd_0);
case -2122595181: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case 544331812: return bem_addValue_1((BEC_2_6_10_SystemParameters) bevd_0);
case 1839678727: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case 886424470: return bem_fileTokSetDirect_1(bevd_0);
case 1995581719: return bem_toJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1087300703: return bem_orderedSet_1(bevd_0);
case -934816238: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 1453960352: return bem_paramsSet_1(bevd_0);
case -1513827208: return bem_addArgs_1(bevd_0);
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -674850162: return bem_argsSet_1(bevd_0);
case -1574401917: return bem_preProcessorSet_1(bevd_0);
case 1171039333: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1143649219: return bem_addParam_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -91893436: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1839568795: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1600711279: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1024949629: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
