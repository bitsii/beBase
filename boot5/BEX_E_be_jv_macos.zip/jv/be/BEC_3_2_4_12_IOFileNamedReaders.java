package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_3_2_4_12_IOFileNamedReaders extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedReaders() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x52,0x65,0x61,0x64,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;

public static BET_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_type;

public BEC_3_2_4_6_IOFileReader bevp_input;
public BEC_3_2_4_12_IOFileNamedReaders bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_default_0() throws Throwable {
BEC_4_2_4_6_5_IOFileReaderStdin bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst.bem_new_0();
bem_inputSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_inputSet_1(BEC_3_2_4_6_IOFileReader beva__input) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_input = beva__input;
bevt_0_tmpany_phold = bevp_input.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 627 */ {
bevp_input.bem_open_0();
} /* Line: 628 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_inputGet_0() throws Throwable {
return bevp_input;
} /*method end*/
public final BEC_3_2_4_6_IOFileReader bem_inputGetDirect_0() throws Throwable {
return bevp_input;
} /*method end*/
public final BEC_3_2_4_12_IOFileNamedReaders bem_inputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_input = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {622, 622, 626, 627, 628, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 23, 24, 26, 31, 34, 37};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 622 17
new 0 622 17
inputSet 1 622 18
assign 1 626 23
assign 1 627 24
isClosedGet 0 627 24
open 0 628 26
return 1 0 31
return 1 0 34
assign 1 0 37
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1191299721: return bem_deserializeClassNameGet_0();
case -260111055: return bem_print_0();
case -1486852325: return bem_copy_0();
case -1166462165: return bem_iteratorGet_0();
case -243903584: return bem_fieldNamesGet_0();
case 838552382: return bem_inputGet_0();
case -557938157: return bem_toString_0();
case 740465458: return bem_new_0();
case -383147285: return bem_serializationIteratorGet_0();
case 1540627001: return bem_classNameGet_0();
case 351178267: return bem_echo_0();
case 1227289471: return bem_hashGet_0();
case 1840305191: return bem_serializeToString_0();
case -2039624597: return bem_sourceFileNameGet_0();
case 1529322692: return bem_default_0();
case -1348350074: return bem_create_0();
case -295279542: return bem_once_0();
case -844497155: return bem_tagGet_0();
case 210621055: return bem_inputGetDirect_0();
case -736476180: return bem_serializeContents_0();
case -1203535797: return bem_toAny_0();
case 1567955799: return bem_fieldIteratorGet_0();
case -5604421: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -218864081: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1670790162: return bem_sameClass_1(bevd_0);
case -604269913: return bem_inputSet_1((BEC_3_2_4_6_IOFileReader) bevd_0);
case 681538010: return bem_notEquals_1(bevd_0);
case -67300059: return bem_equals_1(bevd_0);
case 1544353280: return bem_otherClass_1(bevd_0);
case 1724749097: return bem_undefined_1(bevd_0);
case -1748281966: return bem_sameObject_1(bevd_0);
case 1755435888: return bem_inputSetDirect_1(bevd_0);
case 1647627603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2100440987: return bem_def_1(bevd_0);
case 958315163: return bem_sameType_1(bevd_0);
case -593937181: return bem_copyTo_1(bevd_0);
case 1187046692: return bem_defined_1(bevd_0);
case -1258811879: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2039711690: return bem_undef_1(bevd_0);
case -387830191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1839755987: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1783125070: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1046047039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1868703996: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -528171684: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1304899076: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1671846119: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 520681709: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedReaders_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedReaders_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_12_IOFileNamedReaders();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst = (BEC_3_2_4_12_IOFileNamedReaders) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_type;
}
}
