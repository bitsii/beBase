package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_6_TextString extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) {
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) {
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) {
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(String bevi_string) throws Exception {
        byte[] bevi_bytes = bevi_string.getBytes("UTF-8");
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public String bems_toJvString() throws Exception {
        String jvString = new String(bevi_bytes, 0, bevp_size.bevi_int, "UTF-8");
        return jvString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_18 = (new BEC_2_4_3_MathInt(43));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_19 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_20 = (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_21 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_22 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_23 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_24 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_25 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_27 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_28 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_29 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_30 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_31 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_32 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_33 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_34 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_35 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_36 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_38 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_40 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_41 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_42 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_43 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_44 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_45 = (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_46 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_47 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_48 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_49 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevp_capacity = (new BEC_2_4_3_MathInt(0));
} /* Line: 187 */
 else  /* Line: 186 */ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 188 */ {
return this;
} /* Line: 189 */
} /* Line: 186 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        this.bevi_bytes = java.util.Arrays.copyOf(this.bevi_bytes, beva_ncap.bevi_int);
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 221 */
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_1;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bem_new_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_2;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_3;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bem_setHex_2(bevt_4_tmpany_phold, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_1_tmpany_phold = bem_getCode_2(beva_pos, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt(16));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_toString_3(bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) throws Throwable {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(737771364);
if (bevp_leni == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevp_leni = (new BEC_2_4_3_MathInt());
bevp_sizi = (new BEC_2_4_3_MathInt());
} /* Line: 245 */
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 250 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_4;
bevt_4_tmpany_phold = bevp_sizi.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_5;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_6;
bevl_nsize = bevt_3_tmpany_phold.bem_divide_1(bevt_7_tmpany_phold);
bem_capacitySet_1(bevl_nsize);
} /* Line: 252 */
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_9_tmpany_phold = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_8_tmpany_phold, bevt_9_tmpany_phold, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) throws Throwable {
beva_w.bemd_1(-1486757307, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_7;
if (bevp_size.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_8;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_9;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bem_setIntUnchecked_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_10;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_6_tmpany_phold.bevi_int;
} /* Line: 288 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_11;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_12;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bem_setCodeUnchecked_2(bevt_3_tmpany_phold, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() throws Throwable {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_1_tmpany_phold = bem_ends_1(bevl_nl);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_13;
bevt_5_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpany_phold = bevp_size.bem_subtract_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold = bem_substring_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 301 */
bevl_nl = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_6_tmpany_phold = bem_ends_1(bevl_nl);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_14;
bevt_10_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpany_phold = bevp_size.bem_subtract_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return bevt_7_tmpany_phold;
} /* Line: 305 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_copy_0() throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_15;
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_c = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_4_6_TextString) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_16;
if (bevl_found.bevi_int != bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 318 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 318 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 319 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 325 */
bevt_3_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bevp_size.bem_subtract_1(bevt_3_tmpany_phold);
bevl_found = bem_find_2(beva_str, bevt_2_tmpany_phold);
if (bevl_found == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 328 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_3_tmpany_phold = bem_find_1(beva_str);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 334 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 334 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 335 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 342 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 342 */ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_17;
if (bevl_j.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_18;
if (bevl_ic.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_19;
if (bevl_ic.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 344 */ {
} /* Line: 344 */
 else  /* Line: 344 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_20;
if (bevl_ic.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_21;
if (bevl_ic.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 346 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 346 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 347 */
} /* Line: 344 */
bevl_j.bevi_int++;
} /* Line: 342 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 355 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 355 */ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_22;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_23;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 357 */
 else  /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 357 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_tmpany_phold.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 359 */
bevl_j.bevi_int++;
} /* Line: 355 */
 else  /* Line: 355 */ {
break;
} /* Line: 355 */
} /* Line: 355 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lowerValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 370 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 370 */ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_24;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_25;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpany_phold);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 374 */
bevl_j.bevi_int++;
} /* Line: 370 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_upperValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bem_split_1(beva_from);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_to, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevt_1_tmpany_phold = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_2_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bem_sizeGet_0();
bevt_3_tmpany_phold = bem_substring_2(bevl_last, bevt_4_tmpany_phold);
bevl_res.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 398 */
 else  /* Line: 399 */ {
bevt_5_tmpany_phold = beva_from.bem_copy_0();
return bevt_5_tmpany_phold;
} /* Line: 400 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 410 */ {
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevt_2_tmpany_phold = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_3_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 415 */
 else  /* Line: 417 */ {
bevt_5_tmpany_phold = bem_sizeGet_0();
bevt_4_tmpany_phold = bem_substring_2(bevl_last, bevt_5_tmpany_phold);
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 418 */
} /* Line: 412 */
 else  /* Line: 410 */ {
break;
} /* Line: 410 */
} /* Line: 410 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_j = bem_mbiterGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 429 */ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 429 */
 else  /* Line: 429 */ {
break;
} /* Line: 429 */
} /* Line: 429 */
bevt_2_tmpany_phold = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_tmpany_phold.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_tmpany_phold.bevi_int;
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 439 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 439 */ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpany_phold);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 439 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_hashValue_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getCode_2(beva_pos, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_26;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 463 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 463 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 463 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 463 */
 else  /* Line: 463 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 463 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 483 */
 else  /* Line: 491 */ {
return null;
} /* Line: 492 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_27;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 505 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 505 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 505 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 505 */
 else  /* Line: 505 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 505 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int < 0) {
            beva_into.bevi_int += 256;
         }
         } /* Line: 529 */
 else  /* Line: 534 */ {
return null;
} /* Line: 535 */
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_28;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 541 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 541 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 541 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 541 */
 else  /* Line: 541 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 541 */ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 542 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_29;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 547 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 547 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 547 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 547 */
 else  /* Line: 547 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 547 */ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 548 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() throws Throwable {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevl_input = this;
bevt_3_tmpany_phold = bevl_input.bem_sizeGet_0();
bevl_insz = bevt_3_tmpany_phold.bem_copy_0();
bevl_output = (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (new BEC_2_4_3_MathInt());
bevl_p = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 558 */ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 558 */ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_30;
if (bevl_c.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 560 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_31;
if (bevl_c.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 560 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 560 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 560 */
 else  /* Line: 560 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 560 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 560 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_32;
if (bevl_c.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 560 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_33;
if (bevl_c.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 560 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 560 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 560 */
 else  /* Line: 560 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 560 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 560 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 560 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 560 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 560 */ {
bevt_14_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_34;
if (bevl_c.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 560 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_35;
if (bevl_c.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 560 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 560 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 560 */
 else  /* Line: 560 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 560 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 560 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 560 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 560 */ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 562 */
bevl_i.bevi_int++;
} /* Line: 558 */
 else  /* Line: 558 */ {
break;
} /* Line: 558 */
} /* Line: 558 */
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_36;
if (bevp_size.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 570 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 571 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b > 127) {
        twvls_b -= 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_rfind_1(beva_str);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_reverseBytes_0();
bevt_3_tmpany_phold = beva_str.bem_copy_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpany_phold.bem_find_1(bevt_2_tmpany_phold);
if (bevl_rpos == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 664 */ {
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpany_phold;
} /* Line: 666 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_37;
bevt_0_tmpany_phold = bem_find_2(beva_str, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
if (beva_str == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 678 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
if (beva_start == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 678 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 678 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 678 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_38;
if (beva_start.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 678 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 678 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 678 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 678 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 678 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 678 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_12_tmpany_phold = beva_str.bem_sizeGet_0();
if (bevt_12_tmpany_phold.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 678 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 678 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 678 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_14_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_39;
if (bevp_size.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 678 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 678 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 678 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_16_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_40;
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 678 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 678 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 678 */ {
return null;
} /* Line: 679 */
bevl_end = bevp_size;
bevl_current = beva_start.bem_copy_0();
bevl_myval = (new BEC_2_4_3_MathInt());
bevl_strfirst = (new BEC_2_4_3_MathInt());
bevt_18_tmpany_phold = (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpany_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_41;
if (bevl_strsize.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 690 */ {
bevl_strval = (new BEC_2_4_3_MathInt());
bevl_current2 = (new BEC_2_4_3_MathInt());
bevl_end2 = (new BEC_2_4_3_MathInt());
} /* Line: 693 */
bevl_currentstr2 = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 696 */ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 696 */ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 698 */ {
bevt_24_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_42;
if (bevl_strsize.bevi_int == bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 699 */ {
return bevl_current;
} /* Line: 700 */
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_tmpany_phold.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 706 */ {
return null;
} /* Line: 707 */
bevt_28_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_43;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_tmpany_phold.bevi_int;
while (true)
 /* Line: 710 */ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 710 */ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 713 */ {
break;
} /* Line: 714 */
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 717 */
 else  /* Line: 710 */ {
break;
} /* Line: 710 */
} /* Line: 710 */
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 719 */ {
return bevl_current;
} /* Line: 720 */
} /* Line: 719 */
bevl_current.bevi_int++;
} /* Line: 723 */
 else  /* Line: 696 */ {
break;
} /* Line: 696 */
} /* Line: 696 */
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 733 */ {
if (bevl_i == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 733 */ {
bevt_1_tmpany_phold = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpany_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 736 */
 else  /* Line: 733 */ {
break;
} /* Line: 733 */
} /* Line: 733 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 738 */ {
bevt_3_tmpany_phold = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 739 */
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lineSplitterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_stri == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 761 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 761 */ {
bevt_2_tmpany_phold = beva_stri.bemd_1(-1112750632, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 761 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 761 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 761 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 761 */ {
return null;
} /* Line: 762 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(1740522405);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 766 */ {
bevl_maxsize = bevl_osize;
} /* Line: 767 */
 else  /* Line: 768 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 769 */
bevl_myret = (new BEC_2_4_3_MathInt());
bevl_mv = (new BEC_2_4_3_MathInt());
bevl_ov = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 774 */ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 774 */ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(839801657, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 777 */ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 778 */ {
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpany_phold;
} /* Line: 779 */
 else  /* Line: 780 */ {
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpany_phold;
} /* Line: 781 */
} /* Line: 778 */
bevl_i.bevi_int++;
} /* Line: 774 */
 else  /* Line: 774 */ {
break;
} /* Line: 774 */
} /* Line: 774 */
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_44;
if (bevl_myret.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 785 */ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 786 */ {
bevl_myret = (new BEC_2_4_3_MathInt(1));
} /* Line: 787 */
 else  /* Line: 786 */ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 788 */ {
bevl_myret = (new BEC_2_4_3_MathInt(-1));
} /* Line: 789 */
} /* Line: 786 */
} /* Line: 786 */
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 796 */ {
return null;
} /* Line: 796 */
bevt_2_tmpany_phold = bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_45;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 797 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 798 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 804 */ {
return null;
} /* Line: 804 */
bevt_2_tmpany_phold = bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_46;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 805 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 806 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

    BEC_2_4_6_TextString bevls_stri = (BEC_2_4_6_TextString) beva_stri;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_str);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(737771364);
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpany_phold, bevp_size, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevp_size);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_create_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) throws Throwable {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_47;
if (beva_starti.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 890 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 890 */ {
bevt_4_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 890 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 890 */ {
bevt_6_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 890 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 890 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 890 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 890 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 890 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 890 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 890 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_7_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 891 */
 else  /* Line: 892 */ {
if (bevp_leni == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 895 */ {
bevp_leni = (new BEC_2_4_3_MathInt());
bevp_sizi = (new BEC_2_4_3_MathInt());
} /* Line: 897 */
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 906 */ {
bem_capacitySet_1(bevp_sizi);
} /* Line: 907 */

         //source, sourceStart, dest, destStart, length
         System.arraycopy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 962 */ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 966 */
return this;
} /* Line: 968 */
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sizeGet_0();
bevt_0_tmpany_phold = bem_substring_2(beva_starti, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevi_bytes.length - 1);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_print_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevp_size.bevi_int);
System.out.write('\n');
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_echo_0() throws Throwable {
bem_output_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_snw == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1094 */ {
bem_new_0();
} /* Line: 1095 */
 else  /* Line: 1096 */ {
bevt_2_tmpany_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_48;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bem_new_1(bevt_1_tmpany_phold);
bem_addValue_1(beva_snw);
} /* Line: 1098 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_strip_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevl_vb = (new BEC_2_4_3_MathInt());
bevl_ve = (new BEC_2_4_3_MathInt());
bevl_b = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_49;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpany_phold);
while (true)
 /* Line: 1115 */ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1115 */ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1121 */
 else  /* Line: 1115 */ {
break;
} /* Line: 1115 */
} /* Line: 1115 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() throws Throwable {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() throws Throwable {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {168, 169, 182, 182, 182, 186, 186, 187, 188, 188, 189, 220, 220, 221, 223, 227, 227, 227, 228, 228, 228, 229, 229, 229, 233, 233, 233, 233, 233, 233, 233, 237, 238, 242, 243, 243, 244, 245, 247, 247, 248, 250, 250, 251, 251, 251, 251, 251, 251, 252, 254, 254, 254, 258, 262, 266, 270, 280, 281, 282, 286, 286, 286, 287, 287, 287, 287, 287, 288, 288, 288, 293, 293, 294, 294, 294, 295, 295, 295, 299, 299, 300, 301, 301, 301, 301, 301, 303, 304, 305, 305, 305, 305, 305, 307, 311, 311, 311, 312, 313, 317, 318, 318, 0, 318, 318, 318, 0, 0, 319, 319, 321, 321, 325, 325, 325, 325, 326, 326, 326, 327, 327, 328, 328, 330, 330, 334, 334, 0, 334, 334, 334, 0, 0, 335, 335, 337, 337, 341, 342, 342, 342, 343, 344, 344, 344, 344, 344, 344, 0, 344, 344, 344, 0, 0, 0, 0, 0, 346, 346, 346, 0, 346, 346, 346, 0, 0, 347, 347, 342, 350, 350, 354, 355, 355, 355, 356, 357, 357, 357, 357, 357, 357, 0, 0, 0, 358, 358, 359, 355, 365, 365, 365, 369, 370, 370, 370, 371, 372, 372, 372, 372, 372, 372, 0, 0, 0, 373, 373, 374, 370, 380, 380, 380, 384, 384, 384, 384, 390, 391, 392, 393, 394, 394, 395, 395, 396, 397, 397, 398, 398, 398, 400, 400, 402, 407, 408, 409, 410, 410, 411, 412, 412, 413, 413, 414, 415, 415, 418, 418, 418, 422, 427, 427, 428, 429, 429, 429, 430, 429, 432, 432, 433, 437, 438, 438, 439, 439, 439, 440, 441, 441, 442, 439, 445, 449, 449, 449, 453, 453, 453, 463, 463, 463, 463, 463, 0, 0, 0, 492, 494, 505, 505, 505, 505, 505, 0, 0, 0, 535, 537, 541, 541, 541, 541, 541, 0, 0, 0, 542, 547, 547, 547, 547, 547, 0, 0, 0, 548, 553, 554, 554, 555, 556, 557, 558, 558, 558, 559, 560, 560, 560, 560, 560, 560, 0, 0, 0, 0, 560, 560, 560, 560, 560, 560, 0, 0, 0, 0, 0, 0, 560, 560, 560, 560, 560, 560, 0, 0, 0, 0, 0, 561, 562, 558, 565, 566, 570, 570, 570, 571, 571, 573, 573, 656, 656, 662, 662, 662, 662, 662, 664, 664, 665, 665, 666, 666, 668, 672, 672, 672, 678, 678, 0, 678, 678, 0, 0, 0, 678, 678, 678, 0, 0, 0, 678, 678, 0, 0, 0, 678, 678, 678, 0, 0, 0, 678, 678, 678, 0, 0, 0, 678, 678, 678, 678, 0, 0, 679, 682, 683, 684, 685, 686, 686, 688, 690, 690, 690, 691, 692, 693, 695, 696, 696, 697, 698, 698, 699, 699, 699, 700, 702, 703, 704, 705, 705, 706, 706, 707, 709, 709, 709, 710, 710, 711, 712, 713, 713, 716, 717, 719, 719, 720, 723, 725, 729, 730, 731, 732, 733, 733, 734, 734, 735, 736, 738, 738, 739, 739, 741, 745, 745, 745, 749, 749, 749, 749, 753, 761, 761, 0, 761, 0, 0, 762, 764, 765, 766, 766, 767, 769, 771, 772, 773, 774, 774, 774, 775, 776, 777, 777, 778, 778, 779, 779, 781, 781, 774, 785, 785, 785, 786, 786, 787, 788, 788, 789, 792, 796, 796, 796, 797, 797, 797, 797, 798, 798, 800, 800, 804, 804, 804, 805, 805, 805, 805, 806, 806, 808, 808, 850, 850, 854, 854, 854, 858, 859, 859, 859, 860, 860, 860, 861, 861, 861, 862, 865, 865, 890, 890, 890, 0, 890, 890, 890, 0, 890, 890, 890, 0, 0, 0, 0, 891, 891, 891, 895, 895, 896, 897, 899, 900, 901, 903, 904, 906, 906, 907, 962, 962, 966, 968, 973, 973, 973, 977, 977, 977, 977, 977, 1062, 1066, 1066, 1070, 1070, 1074, 1074, 1078, 1078, 1082, 1082, 1086, 1086, 1090, 1094, 1094, 1095, 1097, 1097, 1097, 1097, 1098, 1103, 1103, 1107, 1107, 1107, 1111, 1112, 1113, 1114, 1114, 1115, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {103, 104, 110, 111, 112, 119, 124, 125, 128, 133, 134, 143, 148, 149, 151, 161, 162, 163, 164, 165, 166, 167, 168, 169, 179, 180, 181, 182, 183, 184, 185, 189, 190, 206, 207, 212, 213, 214, 216, 217, 218, 219, 224, 225, 226, 227, 228, 229, 230, 231, 233, 234, 235, 239, 242, 245, 249, 260, 261, 262, 273, 274, 279, 280, 281, 282, 283, 284, 285, 286, 287, 297, 298, 299, 300, 301, 302, 303, 304, 320, 321, 322, 324, 325, 326, 327, 328, 330, 331, 333, 334, 335, 336, 337, 339, 345, 346, 347, 348, 349, 359, 360, 365, 366, 369, 370, 375, 376, 379, 383, 384, 386, 387, 398, 403, 404, 405, 407, 408, 409, 410, 415, 416, 417, 419, 420, 429, 434, 435, 438, 439, 444, 445, 448, 452, 453, 455, 456, 476, 477, 480, 485, 486, 487, 488, 493, 494, 495, 500, 501, 504, 505, 510, 511, 514, 518, 521, 525, 530, 531, 536, 537, 540, 541, 546, 547, 550, 554, 555, 558, 564, 565, 577, 578, 581, 586, 587, 588, 589, 594, 595, 596, 601, 602, 605, 609, 612, 613, 614, 616, 627, 628, 629, 641, 642, 645, 650, 651, 652, 653, 658, 659, 660, 665, 666, 669, 673, 676, 677, 678, 680, 691, 692, 693, 699, 700, 701, 702, 714, 715, 716, 717, 718, 723, 724, 725, 726, 727, 728, 729, 730, 731, 734, 735, 737, 749, 750, 751, 754, 759, 760, 761, 766, 767, 768, 769, 770, 771, 774, 775, 776, 783, 793, 794, 795, 796, 799, 804, 805, 806, 812, 813, 814, 822, 823, 824, 825, 828, 833, 834, 835, 836, 837, 838, 844, 849, 850, 851, 856, 857, 858, 865, 866, 871, 872, 877, 878, 881, 885, 892, 894, 901, 902, 907, 908, 913, 914, 917, 921, 931, 933, 940, 941, 946, 947, 952, 953, 956, 960, 963, 972, 973, 978, 979, 984, 985, 988, 992, 995, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1032, 1037, 1038, 1039, 1040, 1045, 1046, 1047, 1052, 1053, 1056, 1060, 1063, 1066, 1067, 1072, 1073, 1074, 1079, 1080, 1083, 1087, 1090, 1093, 1097, 1100, 1101, 1106, 1107, 1108, 1113, 1114, 1117, 1121, 1124, 1127, 1131, 1132, 1134, 1140, 1141, 1148, 1149, 1154, 1155, 1156, 1158, 1159, 1177, 1178, 1189, 1190, 1191, 1192, 1193, 1194, 1199, 1200, 1201, 1202, 1203, 1205, 1210, 1211, 1212, 1256, 1261, 1262, 1265, 1270, 1271, 1274, 1278, 1281, 1282, 1287, 1288, 1291, 1295, 1298, 1303, 1304, 1307, 1311, 1314, 1315, 1320, 1321, 1324, 1328, 1331, 1332, 1337, 1338, 1341, 1345, 1348, 1349, 1350, 1355, 1356, 1359, 1363, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1378, 1379, 1380, 1381, 1383, 1386, 1391, 1392, 1393, 1398, 1399, 1400, 1405, 1406, 1408, 1409, 1410, 1411, 1412, 1413, 1418, 1419, 1421, 1422, 1423, 1426, 1431, 1432, 1433, 1434, 1439, 1442, 1443, 1449, 1454, 1455, 1458, 1464, 1475, 1476, 1477, 1478, 1481, 1486, 1487, 1488, 1489, 1490, 1496, 1501, 1502, 1503, 1505, 1510, 1511, 1512, 1518, 1519, 1520, 1521, 1524, 1547, 1552, 1553, 1556, 1558, 1561, 1565, 1567, 1568, 1569, 1574, 1575, 1578, 1580, 1581, 1582, 1583, 1586, 1591, 1592, 1593, 1594, 1599, 1600, 1605, 1606, 1607, 1610, 1611, 1614, 1620, 1621, 1626, 1627, 1632, 1633, 1636, 1641, 1642, 1646, 1655, 1660, 1661, 1663, 1664, 1665, 1670, 1671, 1672, 1674, 1675, 1684, 1689, 1690, 1692, 1693, 1694, 1699, 1700, 1701, 1703, 1704, 1718, 1719, 1724, 1725, 1730, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1755, 1756, 1773, 1774, 1779, 1780, 1783, 1784, 1789, 1790, 1793, 1794, 1799, 1800, 1803, 1807, 1810, 1814, 1815, 1816, 1819, 1824, 1825, 1826, 1828, 1829, 1830, 1831, 1832, 1833, 1838, 1839, 1844, 1849, 1850, 1852, 1858, 1859, 1860, 1867, 1868, 1869, 1870, 1871, 1885, 1890, 1891, 1895, 1896, 1900, 1901, 1905, 1906, 1910, 1911, 1915, 1916, 1919, 1926, 1931, 1932, 1935, 1936, 1937, 1938, 1939, 1945, 1946, 1951, 1952, 1953, 1962, 1963, 1964, 1965, 1966, 1969, 1974, 1975, 1976, 1977, 1978, 1979, 1980, 1989, 1992, 1996, 1999, 2002, 2006, 2009};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 168 103
new 0 168 103
capacitySet 1 169 104
assign 1 182 110
new 0 182 110
assign 1 182 111
once 0 182 111
new 1 182 112
assign 1 186 119
undef 1 186 124
assign 1 187 125
new 0 187 125
assign 1 188 128
equals 1 188 133
return 1 189 134
assign 1 220 143
greater 1 220 148
setValue 1 221 149
setValue 1 223 151
assign 1 227 161
new 0 227 161
assign 1 227 162
once 0 227 162
new 1 227 163
assign 1 228 164
new 0 228 164
assign 1 228 165
once 0 228 165
setValue 1 228 166
assign 1 229 167
new 0 229 167
assign 1 229 168
once 0 229 168
setHex 2 229 169
assign 1 233 179
new 0 233 179
assign 1 233 180
getCode 2 233 180
assign 1 233 181
new 0 233 181
assign 1 233 182
new 0 233 182
assign 1 233 183
new 0 233 183
assign 1 233 184
toString 3 233 184
return 1 233 185
assign 1 237 189
hexNew 1 237 189
setCode 2 238 190
assign 1 242 206
toString 0 242 206
assign 1 243 207
undef 1 243 212
assign 1 244 213
new 0 244 213
assign 1 245 214
new 0 245 214
assign 1 247 216
sizeGet 0 247 216
setValue 1 247 217
addValue 1 248 218
assign 1 250 219
lesser 1 250 224
assign 1 251 225
new 0 251 225
assign 1 251 226
add 1 251 226
assign 1 251 227
new 0 251 227
assign 1 251 228
multiply 1 251 228
assign 1 251 229
new 0 251 229
assign 1 251 230
divide 1 251 230
capacitySet 1 252 231
assign 1 254 233
new 0 254 233
assign 1 254 234
sizeGet 0 254 234
copyValue 4 254 235
return 1 258 239
return 1 262 242
addValue 1 266 245
write 1 270 249
assign 1 280 260
copy 0 280 260
clear 0 281 261
return 1 282 262
assign 1 286 273
new 0 286 273
assign 1 286 274
greater 1 286 279
assign 1 287 280
new 0 287 280
assign 1 287 281
once 0 287 281
assign 1 287 282
new 0 287 282
assign 1 287 283
once 0 287 283
setIntUnchecked 2 287 284
assign 1 288 285
new 0 288 285
assign 1 288 286
once 0 288 286
setValue 1 288 287
assign 1 293 297
new 0 293 297
new 1 293 298
assign 1 294 299
new 0 294 299
assign 1 294 300
once 0 294 300
setValue 1 294 301
assign 1 295 302
new 0 295 302
assign 1 295 303
once 0 295 303
setCodeUnchecked 2 295 304
assign 1 299 320
new 0 299 320
assign 1 299 321
newlineGet 0 299 321
assign 1 300 322
ends 1 300 322
assign 1 301 324
new 0 301 324
assign 1 301 325
sizeGet 0 301 325
assign 1 301 326
subtract 1 301 326
assign 1 301 327
substring 2 301 327
return 1 301 328
assign 1 303 330
new 0 303 330
assign 1 304 331
ends 1 304 331
assign 1 305 333
new 0 305 333
assign 1 305 334
sizeGet 0 305 334
assign 1 305 335
subtract 1 305 335
assign 1 305 336
substring 2 305 336
return 1 305 337
return 1 307 339
assign 1 311 345
new 0 311 345
assign 1 311 346
add 1 311 346
assign 1 311 347
new 1 311 347
addValue 1 312 348
return 1 313 349
assign 1 317 359
find 1 317 359
assign 1 318 360
undef 1 318 365
assign 1 0 366
assign 1 318 369
new 0 318 369
assign 1 318 370
notEquals 1 318 375
assign 1 0 376
assign 1 0 379
assign 1 319 383
new 0 319 383
return 1 319 384
assign 1 321 386
new 0 321 386
return 1 321 387
assign 1 325 398
undef 1 325 403
assign 1 325 404
new 0 325 404
return 1 325 405
assign 1 326 407
sizeGet 0 326 407
assign 1 326 408
subtract 1 326 408
assign 1 326 409
find 2 326 409
assign 1 327 410
undef 1 327 415
assign 1 328 416
new 0 328 416
return 1 328 417
assign 1 330 419
new 0 330 419
return 1 330 420
assign 1 334 429
undef 1 334 434
assign 1 0 435
assign 1 334 438
find 1 334 438
assign 1 334 439
undef 1 334 444
assign 1 0 445
assign 1 0 448
assign 1 335 452
new 0 335 452
return 1 335 453
assign 1 337 455
new 0 337 455
return 1 337 456
assign 1 341 476
new 0 341 476
assign 1 342 477
new 0 342 477
assign 1 342 480
lesser 1 342 485
getInt 2 343 486
assign 1 344 487
new 0 344 487
assign 1 344 488
equals 1 344 493
assign 1 344 494
new 0 344 494
assign 1 344 495
equals 1 344 500
assign 1 0 501
assign 1 344 504
new 0 344 504
assign 1 344 505
equals 1 344 510
assign 1 0 511
assign 1 0 514
assign 1 0 518
assign 1 0 521
assign 1 0 525
assign 1 346 530
new 0 346 530
assign 1 346 531
greater 1 346 536
assign 1 0 537
assign 1 346 540
new 0 346 540
assign 1 346 541
lesser 1 346 546
assign 1 0 547
assign 1 0 550
assign 1 347 554
new 0 347 554
return 1 347 555
incrementValue 0 342 558
assign 1 350 564
new 0 350 564
return 1 350 565
assign 1 354 577
new 0 354 577
assign 1 355 578
new 0 355 578
assign 1 355 581
lesser 1 355 586
getInt 2 356 587
assign 1 357 588
new 0 357 588
assign 1 357 589
greater 1 357 594
assign 1 357 595
new 0 357 595
assign 1 357 596
lesser 1 357 601
assign 1 0 602
assign 1 0 605
assign 1 0 609
assign 1 358 612
new 0 358 612
addValue 1 358 613
setIntUnchecked 2 359 614
incrementValue 0 355 616
assign 1 365 627
copy 0 365 627
assign 1 365 628
lowerValue 0 365 628
return 1 365 629
assign 1 369 641
new 0 369 641
assign 1 370 642
new 0 370 642
assign 1 370 645
lesser 1 370 650
getInt 2 371 651
assign 1 372 652
new 0 372 652
assign 1 372 653
greater 1 372 658
assign 1 372 659
new 0 372 659
assign 1 372 660
lesser 1 372 665
assign 1 0 666
assign 1 0 669
assign 1 0 673
assign 1 373 676
new 0 373 676
subtractValue 1 373 677
setIntUnchecked 2 374 678
incrementValue 0 370 680
assign 1 380 691
copy 0 380 691
assign 1 380 692
upperValue 0 380 692
return 1 380 693
assign 1 384 699
new 0 384 699
assign 1 384 700
split 1 384 700
assign 1 384 701
join 2 384 701
return 1 384 702
assign 1 390 714
new 0 390 714
assign 1 391 715
new 0 391 715
assign 1 392 716
new 0 392 716
assign 1 393 717
find 2 393 717
assign 1 394 718
def 1 394 723
assign 1 395 724
substring 2 395 724
addValue 1 395 725
addValue 1 396 726
assign 1 397 727
sizeGet 0 397 727
assign 1 397 728
add 1 397 728
assign 1 398 729
sizeGet 0 398 729
assign 1 398 730
substring 2 398 730
addValue 1 398 731
assign 1 400 734
copy 0 400 734
return 1 400 735
return 1 402 737
assign 1 407 749
new 0 407 749
assign 1 408 750
new 0 408 750
assign 1 409 751
new 0 409 751
assign 1 410 754
def 1 410 759
assign 1 411 760
find 2 411 760
assign 1 412 761
def 1 412 766
assign 1 413 767
substring 2 413 767
addValue 1 413 768
addValue 1 414 769
assign 1 415 770
sizeGet 0 415 770
assign 1 415 771
add 1 415 771
assign 1 418 774
sizeGet 0 418 774
assign 1 418 775
substring 2 418 775
addValue 1 418 776
return 1 422 783
assign 1 427 793
new 0 427 793
assign 1 427 794
new 1 427 794
assign 1 428 795
mbiterGet 0 428 795
assign 1 429 796
new 0 429 796
assign 1 429 799
lesser 1 429 804
next 1 430 805
incrementValue 0 429 806
assign 1 432 812
next 1 432 812
assign 1 432 813
toString 0 432 813
return 1 433 814
assign 1 437 822
new 0 437 822
assign 1 438 823
new 0 438 823
setValue 1 438 824
assign 1 439 825
new 0 439 825
assign 1 439 828
lesser 1 439 833
getInt 2 440 834
assign 1 441 835
new 0 441 835
multiplyValue 1 441 836
addValue 1 442 837
incrementValue 0 439 838
return 1 445 844
assign 1 449 849
new 0 449 849
assign 1 449 850
hashValue 1 449 850
return 1 449 851
assign 1 453 856
new 0 453 856
assign 1 453 857
getCode 2 453 857
return 1 453 858
assign 1 463 865
new 0 463 865
assign 1 463 866
greaterEquals 1 463 871
assign 1 463 872
greater 1 463 877
assign 1 0 878
assign 1 0 881
assign 1 0 885
return 1 492 892
return 1 494 894
assign 1 505 901
new 0 505 901
assign 1 505 902
greaterEquals 1 505 907
assign 1 505 908
greater 1 505 913
assign 1 0 914
assign 1 0 917
assign 1 0 921
return 1 535 931
return 1 537 933
assign 1 541 940
new 0 541 940
assign 1 541 941
greaterEquals 1 541 946
assign 1 541 947
greater 1 541 952
assign 1 0 953
assign 1 0 956
assign 1 0 960
setIntUnchecked 2 542 963
assign 1 547 972
new 0 547 972
assign 1 547 973
greaterEquals 1 547 978
assign 1 547 979
greater 1 547 984
assign 1 0 985
assign 1 0 988
assign 1 0 992
setCodeUnchecked 2 548 995
assign 1 553 1023
assign 1 554 1024
sizeGet 0 554 1024
assign 1 554 1025
copy 0 554 1025
assign 1 555 1026
new 1 555 1026
assign 1 556 1027
new 0 556 1027
assign 1 557 1028
new 0 557 1028
assign 1 558 1029
new 0 558 1029
assign 1 558 1032
lesser 1 558 1037
getInt 2 559 1038
assign 1 560 1039
new 0 560 1039
assign 1 560 1040
greater 1 560 1045
assign 1 560 1046
new 0 560 1046
assign 1 560 1047
lesser 1 560 1052
assign 1 0 1053
assign 1 0 1056
assign 1 0 1060
assign 1 0 1063
assign 1 560 1066
new 0 560 1066
assign 1 560 1067
greater 1 560 1072
assign 1 560 1073
new 0 560 1073
assign 1 560 1074
lesser 1 560 1079
assign 1 0 1080
assign 1 0 1083
assign 1 0 1087
assign 1 0 1090
assign 1 0 1093
assign 1 0 1097
assign 1 560 1100
new 0 560 1100
assign 1 560 1101
greater 1 560 1106
assign 1 560 1107
new 0 560 1107
assign 1 560 1108
lesser 1 560 1113
assign 1 0 1114
assign 1 0 1117
assign 1 0 1121
assign 1 0 1124
assign 1 0 1127
setIntUnchecked 2 561 1131
incrementValue 0 562 1132
incrementValue 0 558 1134
sizeSet 1 565 1140
return 1 566 1141
assign 1 570 1148
new 0 570 1148
assign 1 570 1149
lesserEquals 1 570 1154
assign 1 571 1155
new 0 571 1155
return 1 571 1156
assign 1 573 1158
new 0 573 1158
return 1 573 1159
assign 1 656 1177
rfind 1 656 1177
return 1 656 1178
assign 1 662 1189
copy 0 662 1189
assign 1 662 1190
reverseBytes 0 662 1190
assign 1 662 1191
copy 0 662 1191
assign 1 662 1192
reverseBytes 0 662 1192
assign 1 662 1193
find 1 662 1193
assign 1 664 1194
def 1 664 1199
assign 1 665 1200
sizeGet 0 665 1200
addValue 1 665 1201
assign 1 666 1202
subtract 1 666 1202
return 1 666 1203
return 1 668 1205
assign 1 672 1210
new 0 672 1210
assign 1 672 1211
find 2 672 1211
return 1 672 1212
assign 1 678 1256
undef 1 678 1261
assign 1 0 1262
assign 1 678 1265
undef 1 678 1270
assign 1 0 1271
assign 1 0 1274
assign 1 0 1278
assign 1 678 1281
new 0 678 1281
assign 1 678 1282
lesser 1 678 1287
assign 1 0 1288
assign 1 0 1291
assign 1 0 1295
assign 1 678 1298
greaterEquals 1 678 1303
assign 1 0 1304
assign 1 0 1307
assign 1 0 1311
assign 1 678 1314
sizeGet 0 678 1314
assign 1 678 1315
greater 1 678 1320
assign 1 0 1321
assign 1 0 1324
assign 1 0 1328
assign 1 678 1331
new 0 678 1331
assign 1 678 1332
equals 1 678 1337
assign 1 0 1338
assign 1 0 1341
assign 1 0 1345
assign 1 678 1348
sizeGet 0 678 1348
assign 1 678 1349
new 0 678 1349
assign 1 678 1350
equals 1 678 1355
assign 1 0 1356
assign 1 0 1359
return 1 679 1363
assign 1 682 1365
assign 1 683 1366
copy 0 683 1366
assign 1 684 1367
new 0 684 1367
assign 1 685 1368
new 0 685 1368
assign 1 686 1369
new 0 686 1369
getInt 2 686 1370
assign 1 688 1371
sizeGet 0 688 1371
assign 1 690 1372
new 0 690 1372
assign 1 690 1373
greater 1 690 1378
assign 1 691 1379
new 0 691 1379
assign 1 692 1380
new 0 692 1380
assign 1 693 1381
new 0 693 1381
assign 1 695 1383
new 0 695 1383
assign 1 696 1386
lesser 1 696 1391
getInt 2 697 1392
assign 1 698 1393
equals 1 698 1398
assign 1 699 1399
new 0 699 1399
assign 1 699 1400
equals 1 699 1405
return 1 700 1406
setValue 1 702 1408
incrementValue 0 703 1409
setValue 1 704 1410
assign 1 705 1411
sizeGet 0 705 1411
addValue 1 705 1412
assign 1 706 1413
greater 1 706 1418
return 1 707 1419
assign 1 709 1421
new 0 709 1421
assign 1 709 1422
once 0 709 1422
setValue 1 709 1423
assign 1 710 1426
lesser 1 710 1431
getInt 2 711 1432
getInt 2 712 1433
assign 1 713 1434
notEquals 1 713 1439
incrementValue 0 716 1442
incrementValue 0 717 1443
assign 1 719 1449
equals 1 719 1454
return 1 720 1455
incrementValue 0 723 1458
return 1 725 1464
assign 1 729 1475
new 0 729 1475
assign 1 730 1476
new 0 730 1476
assign 1 731 1477
find 2 731 1477
assign 1 732 1478
sizeGet 0 732 1478
assign 1 733 1481
def 1 733 1486
assign 1 734 1487
substring 2 734 1487
addValue 1 734 1488
assign 1 735 1489
add 1 735 1489
assign 1 736 1490
find 2 736 1490
assign 1 738 1496
lesser 1 738 1501
assign 1 739 1502
substring 2 739 1502
addValue 1 739 1503
return 1 741 1505
assign 1 745 1510
new 0 745 1510
assign 1 745 1511
join 2 745 1511
return 1 745 1512
assign 1 749 1518
new 0 749 1518
assign 1 749 1519
lineSplitterGet 0 749 1519
assign 1 749 1520
tokenize 1 749 1520
return 1 749 1521
return 1 753 1524
assign 1 761 1547
undef 1 761 1552
assign 1 0 1553
assign 1 761 1556
otherType 1 761 1556
assign 1 0 1558
assign 1 0 1561
return 1 762 1565
assign 1 764 1567
assign 1 765 1568
sizeGet 0 765 1568
assign 1 766 1569
greater 1 766 1574
assign 1 767 1575
assign 1 769 1578
assign 1 771 1580
new 0 771 1580
assign 1 772 1581
new 0 772 1581
assign 1 773 1582
new 0 773 1582
assign 1 774 1583
new 0 774 1583
assign 1 774 1586
lesser 1 774 1591
getCode 2 775 1592
getCode 2 776 1593
assign 1 777 1594
notEquals 1 777 1599
assign 1 778 1600
greater 1 778 1605
assign 1 779 1606
new 0 779 1606
return 1 779 1607
assign 1 781 1610
new 0 781 1610
return 1 781 1611
incrementValue 0 774 1614
assign 1 785 1620
new 0 785 1620
assign 1 785 1621
equals 1 785 1626
assign 1 786 1627
greater 1 786 1632
assign 1 787 1633
new 0 787 1633
assign 1 788 1636
greater 1 788 1641
assign 1 789 1642
new 0 789 1642
return 1 792 1646
assign 1 796 1655
undef 1 796 1660
return 1 796 1661
assign 1 797 1663
compare 1 797 1663
assign 1 797 1664
new 0 797 1664
assign 1 797 1665
equals 1 797 1670
assign 1 798 1671
new 0 798 1671
return 1 798 1672
assign 1 800 1674
new 0 800 1674
return 1 800 1675
assign 1 804 1684
undef 1 804 1689
return 1 804 1690
assign 1 805 1692
compare 1 805 1692
assign 1 805 1693
new 0 805 1693
assign 1 805 1694
equals 1 805 1699
assign 1 806 1700
new 0 806 1700
return 1 806 1701
assign 1 808 1703
new 0 808 1703
return 1 808 1704
assign 1 850 1718
new 0 850 1718
return 1 850 1719
assign 1 854 1724
equals 1 854 1724
assign 1 854 1725
not 0 854 1730
return 1 854 1730
assign 1 858 1741
toString 0 858 1741
assign 1 859 1742
sizeGet 0 859 1742
assign 1 859 1743
add 1 859 1743
assign 1 859 1744
new 1 859 1744
assign 1 860 1745
new 0 860 1745
assign 1 860 1746
new 0 860 1746
copyValue 4 860 1747
assign 1 861 1748
new 0 861 1748
assign 1 861 1749
sizeGet 0 861 1749
copyValue 4 861 1750
return 1 862 1751
assign 1 865 1755
new 0 865 1755
return 1 865 1756
assign 1 890 1773
new 0 890 1773
assign 1 890 1774
lesser 1 890 1779
assign 1 0 1780
assign 1 890 1783
sizeGet 0 890 1783
assign 1 890 1784
greater 1 890 1789
assign 1 0 1790
assign 1 890 1793
sizeGet 0 890 1793
assign 1 890 1794
greater 1 890 1799
assign 1 0 1800
assign 1 0 1803
assign 1 0 1807
assign 1 0 1810
assign 1 891 1814
new 0 891 1814
assign 1 891 1815
new 1 891 1815
throw 1 891 1816
assign 1 895 1819
undef 1 895 1824
assign 1 896 1825
new 0 896 1825
assign 1 897 1826
new 0 897 1826
setValue 1 899 1828
subtractValue 1 900 1829
assign 1 901 1830
setValue 1 903 1831
addValue 1 904 1832
assign 1 906 1833
greater 1 906 1838
capacitySet 1 907 1839
assign 1 962 1844
greater 1 962 1849
setValue 1 966 1850
return 1 968 1852
assign 1 973 1858
sizeGet 0 973 1858
assign 1 973 1859
substring 2 973 1859
return 1 973 1860
assign 1 977 1867
subtract 1 977 1867
assign 1 977 1868
new 1 977 1868
assign 1 977 1869
new 0 977 1869
assign 1 977 1870
copyValue 4 977 1870
return 1 977 1871
output 0 1062 1885
assign 1 1066 1890
new 1 1066 1890
return 1 1066 1891
assign 1 1070 1895
new 1 1070 1895
return 1 1070 1896
assign 1 1074 1900
new 1 1074 1900
return 1 1074 1901
assign 1 1078 1905
new 1 1078 1905
return 1 1078 1906
assign 1 1082 1910
new 1 1082 1910
return 1 1082 1911
assign 1 1086 1915
new 1 1086 1915
return 1 1086 1916
return 1 1090 1919
assign 1 1094 1926
undef 1 1094 1931
new 0 1095 1932
assign 1 1097 1935
sizeGet 0 1097 1935
assign 1 1097 1936
new 0 1097 1936
assign 1 1097 1937
add 1 1097 1937
new 1 1097 1938
addValue 1 1098 1939
assign 1 1103 1945
new 0 1103 1945
return 1 1103 1946
assign 1 1107 1951
new 0 1107 1951
assign 1 1107 1952
strip 1 1107 1952
return 1 1107 1953
assign 1 1111 1962
new 0 1111 1962
assign 1 1112 1963
new 0 1112 1963
assign 1 1113 1964
new 0 1113 1964
assign 1 1114 1965
new 0 1114 1965
assign 1 1114 1966
subtract 1 1114 1966
assign 1 1115 1969
greater 1 1115 1974
getInt 2 1116 1975
getInt 2 1117 1976
setInt 2 1118 1977
setInt 2 1119 1978
incrementValue 0 1120 1979
decrementValue 0 1121 1980
return 1 0 1989
assign 1 0 1992
return 1 0 1996
return 1 0 1999
assign 1 0 2002
return 1 0 2006
assign 1 0 2009
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1313107106: return bem_output_0();
case 458508116: return bem_clear_0();
case -187123131: return bem_upper_0();
case -541144972: return bem_chomp_0();
case -206768372: return bem_siziGet_0();
case 336430743: return bem_reverseBytes_0();
case 874913429: return bem_mbiterGet_0();
case -70500062: return bem_fieldIteratorGet_0();
case 1222310146: return bem_many_0();
case -1866917929: return bem_serializeToString_0();
case -1821737719: return bem_strip_0();
case -471143374: return bem_lower_0();
case -420235024: return bem_classNameGet_0();
case -1193812684: return bem_lowerValue_0();
case -1980796873: return bem_copy_0();
case -1668805461: return bem_byteIteratorGet_0();
case -803388239: return bem_deserializeClassNameGet_0();
case -327335716: return bem_isInteger_0();
case 1314576819: return bem_print_0();
case 1732876397: return bem_serializationIteratorGet_0();
case 1033188255: return bem_biterGet_0();
case 396248915: return bem_readString_0();
case 526333334: return bem_open_0();
case 1668067058: return bem_toAlphaNum_0();
case 822258290: return bem_leniGet_0();
case -1574214064: return bem_upperValue_0();
case -302965453: return bem_tagGet_0();
case 1968685700: return bem_isEmptyGet_0();
case 681827158: return bem_readBuffer_0();
case 2033657832: return bem_hashGet_0();
case 1337331290: return bem_vstringSet_0();
case -1187428942: return bem_close_0();
case 737353003: return bem_new_0();
case -1914640248: return bem_capacityGet_0();
case 1023783415: return bem_create_0();
case 1452879382: return bem_sourceFileNameGet_0();
case 301206433: return bem_echo_0();
case -2009041372: return bem_extractString_0();
case 1775715094: return bem_once_0();
case 482356666: return bem_toAny_0();
case -1669822509: return bem_vstringGet_0();
case 997723391: return bem_iteratorGet_0();
case -2107372823: return bem_multiByteIteratorGet_0();
case 366164054: return bem_serializeContents_0();
case 1740522405: return bem_sizeGet_0();
case 132164462: return bem_stringIteratorGet_0();
case 1995713396: return bem_splitLines_0();
case 737771364: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 241629330: return bem_compare_1(bevd_0);
case 55109045: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 1210677960: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1235111255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1452810576: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 582551547: return bem_siziSet_1(bevd_0);
case -1458727376: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -396768715: return bem_addValue_1(bevd_0);
case -105591508: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case 235706821: return bem_defined_1(bevd_0);
case 718462951: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case -1029474173: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case 2092199138: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 860069412: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -369272378: return bem_undefined_1(bevd_0);
case 1004533413: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case 228693515: return bem_notEquals_1(bevd_0);
case 1852168897: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case 808158717: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1009777941: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 439216438: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 1735205112: return bem_sameType_1(bevd_0);
case 1940225088: return bem_sameClass_1(bevd_0);
case -1112750632: return bem_otherType_1(bevd_0);
case -1732568943: return bem_sameObject_1(bevd_0);
case -153913453: return bem_leniSet_1(bevd_0);
case 1820711442: return bem_sizeSet_1(bevd_0);
case 1732014863: return bem_equals_1(bevd_0);
case 491365959: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case -1486757307: return bem_write_1(bevd_0);
case 254712574: return bem_def_1(bevd_0);
case -265444296: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -10325606: return bem_undef_1(bevd_0);
case 1107846755: return bem_otherClass_1(bevd_0);
case -156026523: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case -729643081: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 1697055981: return bem_codeNew_1(bevd_0);
case -2040539499: return bem_add_1(bevd_0);
case -299256488: return bem_writeTo_1(bevd_0);
case -243996941: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -572622948: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case -1078688343: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1990980581: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 839801657: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1755391354: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1747848637: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 726146393: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1701258880: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211826468: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1451173678: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1815656517: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1990568085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -164742720: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1411611180: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1215461954: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -70659423: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1437812444: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -430062568: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -303274357: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1778025498: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 825256584: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1793249074: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 290219288: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_TextString();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
}
