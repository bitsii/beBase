package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_4_SystemMain extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_SystemMain() { }
private static byte[] becc_BEC_2_6_4_SystemMain_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x61,0x69,0x6E};
private static byte[] becc_BEC_2_6_4_SystemMain_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_4_SystemMain bece_BEC_2_6_4_SystemMain_bevs_inst;

public static BET_2_6_4_SystemMain bece_BEC_2_6_4_SystemMain_bevs_type;

public BEC_2_6_4_SystemMain bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_SystemMain bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_SystemMain bem_main_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 49169285: return bem_create_0();
case -7476103: return bem_hashGet_0();
case 1631198925: return bem_print_0();
case -2129238938: return bem_fieldNamesGet_0();
case 2115475884: return bem_new_0();
case -854129615: return bem_classNameGet_0();
case 1703942120: return bem_main_0();
case 744789579: return bem_tagGet_0();
case 956564530: return bem_toString_0();
case -6785712: return bem_copy_0();
case -928436113: return bem_default_0();
case 235554219: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1005385637: return bem_copyTo_1(bevd_0);
case -76922352: return bem_equals_1(bevd_0);
case -2052423771: return bem_notEquals_1(bevd_0);
case -1554337727: return bem_sameObject_1(bevd_0);
case -1184273709: return bem_undef_1(bevd_0);
case -2142487980: return bem_sameType_1(bevd_0);
case 1338190085: return bem_def_1(bevd_0);
case -1256020058: return bem_otherType_1(bevd_0);
case 1149746123: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -829590487: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -744751889: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1116067959: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -383996467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1363599577: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_SystemMain_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_4_SystemMain_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_SystemMain();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_SystemMain.bece_BEC_2_6_4_SystemMain_bevs_inst = (BEC_2_6_4_SystemMain) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_SystemMain.bece_BEC_2_6_4_SystemMain_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_4_SystemMain.bece_BEC_2_6_4_SystemMain_bevs_type;
}
}
