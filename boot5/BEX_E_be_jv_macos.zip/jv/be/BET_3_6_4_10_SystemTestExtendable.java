package be;
public class BET_3_6_4_10_SystemTestExtendable extends BETS_Object {
public BET_3_6_4_10_SystemTestExtendable() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "acall_0", "bcall_0", "propaGet_0", "propaSet_1", "propbGet_0", "propbSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "propa", "propb" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_6_4_10_SystemTestExtendable();
}
}
