package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_4_ContainerLinkedListNode extends BEC_2_6_6_SystemObject {
public BEC_3_9_10_4_ContainerLinkedListNode() { }
private static byte[] becc_BEC_3_9_10_4_ContainerLinkedListNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_4_ContainerLinkedListNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_4_ContainerLinkedListNode bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst;

public static BET_3_9_10_4_ContainerLinkedListNode bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_prior;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_next;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_9_10_ContainerLinkedList bevp_mylist;
public BEC_3_9_10_4_ContainerLinkedListNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) throws Throwable {
bevp_held = beva__held;
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_insertBefore_1(BEC_2_6_6_SystemObject beva_toIns) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_toIns.bemd_1(-1318490722, null);
beva_toIns.bemd_1(1551212143, this);
beva_toIns.bemd_1(1904842649, bevp_mylist);
bevl_p = bevp_prior;
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) beva_toIns;
if (bevl_p == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevp_mylist.bem_firstNodeSet_1(beva_toIns);
} /* Line: 60 */
 else  /* Line: 61 */ {
bevl_p.bem_nextSet_1(beva_toIns);
beva_toIns.bemd_1(-1318490722, bevl_p);
} /* Line: 63 */
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_delete_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevl_p = bevp_prior;
bevl_n = bevp_next;
bevp_next = null;
bevp_prior = null;
if (bevl_p == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevp_mylist.bem_firstNodeSet_1(bevl_n);
if (bevl_n == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 75 */ {
bevl_n.bem_priorSet_1(null);
} /* Line: 76 */
 else  /* Line: 77 */ {
bevp_mylist.bem_lastNodeSet_1(bevl_n);
} /* Line: 79 */
} /* Line: 75 */
 else  /* Line: 72 */ {
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevl_p.bem_nextSet_1(bevl_n);
bevp_mylist.bem_lastNodeSet_1(bevl_p);
} /* Line: 84 */
 else  /* Line: 85 */ {
bevl_p.bem_nextSet_1(bevl_n);
bevl_n.bem_priorSet_1(bevl_p);
} /* Line: 88 */
} /* Line: 72 */
bevp_mylist = null;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_priorGet_0() throws Throwable {
return bevp_prior;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_priorGetDirect_0() throws Throwable {
return bevp_prior;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_priorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_priorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_nextGet_0() throws Throwable {
return bevp_next;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_nextGetDirect_0() throws Throwable {
return bevp_next;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_nextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_next = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_nextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_next = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_heldGetDirect_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_mylistGet_0() throws Throwable {
return bevp_mylist;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_mylistGetDirect_0() throws Throwable {
return bevp_mylist;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_mylistSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mylist = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_mylistSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mylist = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {45, 46, 53, 54, 55, 56, 57, 58, 58, 60, 62, 63, 68, 69, 70, 71, 72, 72, 74, 75, 75, 76, 79, 81, 81, 83, 84, 87, 88, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 23, 24, 25, 26, 27, 28, 33, 34, 37, 38, 48, 49, 50, 51, 52, 57, 58, 59, 64, 65, 68, 72, 77, 78, 79, 82, 83, 86, 90, 93, 96, 100, 104, 107, 110, 114, 118, 121, 124, 128, 132, 135, 138, 142};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 45 16
assign 1 46 17
priorSet 1 53 23
nextSet 1 54 24
mylistSet 1 55 25
assign 1 56 26
assign 1 57 27
assign 1 58 28
undef 1 58 33
firstNodeSet 1 60 34
nextSet 1 62 37
priorSet 1 63 38
assign 1 68 48
assign 1 69 49
assign 1 70 50
assign 1 71 51
assign 1 72 52
undef 1 72 57
firstNodeSet 1 74 58
assign 1 75 59
def 1 75 64
priorSet 1 76 65
lastNodeSet 1 79 68
assign 1 81 72
undef 1 81 77
nextSet 1 83 78
lastNodeSet 1 84 79
nextSet 1 87 82
priorSet 1 88 83
assign 1 90 86
return 1 0 90
return 1 0 93
assign 1 0 96
assign 1 0 100
return 1 0 104
return 1 0 107
assign 1 0 110
assign 1 0 114
return 1 0 118
return 1 0 121
assign 1 0 124
assign 1 0 128
return 1 0 132
return 1 0 135
assign 1 0 138
assign 1 0 142
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2061412556: return bem_classNameGet_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case -868741030: return bem_nextGet_0();
case 605755759: return bem_fieldNamesGet_0();
case -39706070: return bem_serializeContents_0();
case 2069196027: return bem_print_0();
case 1359777543: return bem_toAny_0();
case -1951841333: return bem_delete_0();
case 637537548: return bem_priorGet_0();
case 874968344: return bem_once_0();
case 344752250: return bem_hashGet_0();
case 1623110333: return bem_mylistGet_0();
case 27033645: return bem_sourceFileNameGet_0();
case 502031978: return bem_iteratorGet_0();
case 1480415803: return bem_serializationIteratorGet_0();
case 1924137904: return bem_priorGetDirect_0();
case 665352419: return bem_heldGetDirect_0();
case 325964466: return bem_echo_0();
case 1799708649: return bem_nextGetDirect_0();
case 1965613314: return bem_tagGet_0();
case 1578098134: return bem_toString_0();
case 26417469: return bem_create_0();
case 962099177: return bem_fieldIteratorGet_0();
case -1878305271: return bem_many_0();
case 334767424: return bem_copy_0();
case -570879253: return bem_heldGet_0();
case 339403928: return bem_mylistGetDirect_0();
case 2132890711: return bem_new_0();
case -799200084: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 404304684: return bem_insertBefore_1(bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1963951324: return bem_mylistSetDirect_1(bevd_0);
case 622277503: return bem_priorSetDirect_1(bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case -1318490722: return bem_priorSet_1(bevd_0);
case 1922290984: return bem_heldSet_1(bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case -358030321: return bem_heldSetDirect_1(bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case 1551212143: return bem_nextSet_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case 1904842649: return bem_mylistSet_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
case -263341724: return bem_nextSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 140119030: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_4_ContainerLinkedListNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_4_ContainerLinkedListNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_4_ContainerLinkedListNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst = (BEC_3_9_10_4_ContainerLinkedListNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_type;
}
}
