package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileWriter extends BEC_2_2_6_IOWriter {
public BEC_3_2_4_6_IOFileWriter() { }
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_0 = {0x77,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_1 = {0x61,0x62};
public static BEC_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;

public static BET_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_3_2_4_6_IOFileWriter bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevp_isClosed = be.BECS_Runtime.boolTrue;
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_openTruncate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_openAppend_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_open_1(BEC_2_4_6_TextString beva_mode) throws Throwable {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevl_append = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevl_fhpatha = bevp_path.bem_toString_0();
if (beva_mode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 435*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bevt_2_ta_ph = beva_mode.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 435*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 435*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 435*/
 else /* Line: 435*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 435*/ {
bevl_append = be.BECS_Runtime.boolTrue;
} /* Line: 436*/
 else /* Line: 437*/ {
bevl_append = be.BECS_Runtime.boolFalse;
} /* Line: 438*/

      if (this.bevi_os == null) {
        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_length.bevi_int, "UTF-8"));
        this.bevi_os = new java.io.FileOutputStream(bevls_f, bevl_append.bevi_bool);
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {394, 395, 395, 399, 399, 403, 403, 407, 407, 418, 435, 435, 435, 435, 0, 0, 0, 436, 438, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 23, 24, 29, 30, 35, 36, 47, 48, 53, 54, 55, 57, 60, 64, 67, 70, 81, 84};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 394 16
new 0 394 16
assign 1 395 17
new 1 395 17
pathSet 1 395 18
assign 1 399 23
new 0 399 23
open 1 399 24
assign 1 403 29
new 0 403 29
open 1 403 30
assign 1 407 35
new 0 407 35
open 1 407 36
assign 1 418 47
toString 0 418 47
assign 1 435 48
def 1 435 53
assign 1 435 54
new 0 435 54
assign 1 435 55
equals 1 435 55
assign 1 0 57
assign 1 0 60
assign 1 0 64
assign 1 436 67
new 0 436 67
assign 1 438 70
new 0 438 70
return 1 0 81
assign 1 0 84
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1428575040: return bem_toString_0();
case 1954876952: return bem_iteratorGet_0();
case -1192792371: return bem_close_0();
case 1356338585: return bem_new_0();
case -43191778: return bem_hashGet_0();
case 1215053353: return bem_open_0();
case -1561177696: return bem_isClosedGet_0();
case -1981735960: return bem_openTruncate_0();
case -935641853: return bem_print_0();
case 420976792: return bem_vfileGet_0();
case -1629771427: return bem_create_0();
case 1069615902: return bem_copy_0();
case 1134252678: return bem_extOpen_0();
case 1422366976: return bem_openAppend_0();
case 120983446: return bem_pathGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -880319736: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -1214510135: return bem_vfileSet_1(bevd_0);
case 1073716984: return bem_equals_1(bevd_0);
case 1449623924: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case -1200916237: return bem_isClosedSet_1(bevd_0);
case 484780340: return bem_notEquals_1(bevd_0);
case 870724511: return bem_new_1(bevd_0);
case -179556288: return bem_undef_1(bevd_0);
case 67055068: return bem_pathSet_1(bevd_0);
case 1388413072: return bem_copyTo_1(bevd_0);
case -1128067899: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -946351099: return bem_print_1(bevd_0);
case -1366175642: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -570336382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1111008594: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -548042918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 159189467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileWriter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileWriter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_6_IOFileWriter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst = (BEC_3_2_4_6_IOFileWriter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_type;
}
}
