package be;
/* IO:File: source/base/Float.be */
public final class BEC_2_4_5_MathFloat extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
public static BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) throws Throwable {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_5_MathFloat bevt_21_ta_ph = null;
BEC_2_4_5_MathFloat bevt_22_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_ta_ph = beva_si.bemd_1(1434897734, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 82*/ {
bevl_neg = be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(2029433438, bevt_2_ta_ph);
} /* Line: 84*/
 else /* Line: 85*/ {
bevl_neg = be.BECS_Runtime.boolFalse;
} /* Line: 86*/
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(-479605274, bevt_3_ta_ph);
if (bevl_dec == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 89*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_dec.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 90*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_7_ta_ph = beva_si.bemd_2(-475596601, bevt_8_ta_ph, bevl_dec);
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_ta_ph);
} /* Line: 91*/
 else /* Line: 92*/ {
bevl_lhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 93*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_10_ta_ph = bevl_dec.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = beva_si.bemd_0(-909310911);
bevt_9_ta_ph = bevt_10_ta_ph.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_ta_ph );
if (bevt_9_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_14_ta_ph = bevl_dec.bem_add_1(bevt_15_ta_ph);
bevt_13_ta_ph = beva_si.bemd_1(2029433438, bevt_14_ta_ph);
bevl_rhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_ta_ph);
} /* Line: 96*/
 else /* Line: 97*/ {
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 98*/
} /* Line: 95*/
 else /* Line: 100*/ {
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 102*/
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_18_ta_ph = bevl_rhs.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_sizeGet_0();
bevl_divby = bevt_16_ta_ph.bem_power_1(bevt_17_ta_ph);
if (bevl_neg.bevi_bool)/* Line: 105*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_ta_ph);
} /* Line: 107*/
bevt_21_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_rhs);
bevt_22_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_divby);
bevl_rhsf = bevt_21_ta_ph.bem_divide_1(bevt_22_ta_ph);
bevl_lhsf = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_lhs);
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_intNew_1(BEC_2_4_3_MathInt beva_int) throws Throwable {

      bevi_float = (float) beva_int.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_create_0() throws Throwable {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_4_5_MathFloat) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toInt_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
BEC_2_4_5_MathFloat bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_lhi = bem_toInt_0();
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_lhi);
bevl_rh = bem_subtract_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_ta_ph);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_ta_ph = bevl_lhi.bem_toString_0();
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = bevl_rhi.bem_toString_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
/* Line: 181*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 193*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
/* Line: 201*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 213*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
/* Line: 221*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 233*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
/* Line: 241*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 253*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
/* Line: 261*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 273*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
/* Line: 281*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 293*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float == ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float != ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {82, 82, 83, 84, 84, 86, 88, 88, 89, 89, 90, 90, 90, 91, 91, 91, 93, 95, 95, 95, 95, 96, 96, 96, 96, 98, 101, 102, 104, 104, 104, 104, 106, 106, 107, 107, 109, 109, 109, 110, 111, 112, 134, 134, 137, 137, 141, 145, 145, 156, 164, 169, 169, 173, 174, 174, 175, 175, 176, 177, 177, 177, 177, 177, 177, 182, 193, 202, 213, 222, 233, 242, 253, 262, 273, 282, 293, 301, 301, 343, 343, 385, 385, 413, 413, 441, 441, 469, 469, 497, 497};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {59, 60, 62, 63, 64, 67, 69, 70, 71, 76, 77, 78, 83, 84, 85, 86, 89, 91, 92, 93, 94, 96, 97, 98, 99, 102, 106, 107, 109, 110, 111, 112, 114, 115, 116, 117, 119, 120, 121, 122, 123, 124, 133, 134, 138, 139, 142, 147, 148, 152, 153, 157, 158, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 187, 190, 196, 199, 205, 208, 214, 217, 223, 226, 232, 235, 240, 241, 249, 250, 258, 259, 267, 268, 276, 277, 285, 286, 294, 295};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 82 59
new 0 82 59
assign 1 82 60
begins 1 82 60
assign 1 83 62
new 0 83 62
assign 1 84 63
new 0 84 63
assign 1 84 64
substring 1 84 64
assign 1 86 67
new 0 86 67
assign 1 88 69
new 0 88 69
assign 1 88 70
find 1 88 70
assign 1 89 71
def 1 89 76
assign 1 90 77
new 0 90 77
assign 1 90 78
greater 1 90 83
assign 1 91 84
new 0 91 84
assign 1 91 85
substring 2 91 85
assign 1 91 86
new 1 91 86
assign 1 93 89
new 0 93 89
assign 1 95 91
new 0 95 91
assign 1 95 92
add 1 95 92
assign 1 95 93
sizeGet 0 95 93
assign 1 95 94
lesser 1 95 94
assign 1 96 96
new 0 96 96
assign 1 96 97
add 1 96 97
assign 1 96 98
substring 1 96 98
assign 1 96 99
new 1 96 99
assign 1 98 102
new 0 98 102
assign 1 101 106
new 1 101 106
assign 1 102 107
new 0 102 107
assign 1 104 109
new 0 104 109
assign 1 104 110
toString 0 104 110
assign 1 104 111
sizeGet 0 104 111
assign 1 104 112
power 1 104 112
assign 1 106 114
new 0 106 114
multiplyValue 1 106 115
assign 1 107 116
new 0 107 116
multiplyValue 1 107 117
assign 1 109 119
intNew 1 109 119
assign 1 109 120
intNew 1 109 120
assign 1 109 121
divide 1 109 121
assign 1 110 122
intNew 1 110 122
assign 1 111 123
add 1 111 123
return 1 112 124
assign 1 134 133
new 0 134 133
return 1 134 134
assign 1 137 138
toString 0 137 138
return 1 137 139
new 1 141 142
assign 1 145 147
new 0 145 147
return 1 145 148
assign 1 156 152
new 0 156 152
return 1 164 153
assign 1 169 157
toInt 0 169 157
return 1 169 158
assign 1 173 171
toInt 0 173 171
assign 1 174 172
intNew 1 174 172
assign 1 174 173
subtract 1 174 173
assign 1 175 174
new 0 175 174
assign 1 175 175
multiply 1 175 175
assign 1 176 176
toInt 0 176 176
assign 1 177 177
toString 0 177 177
assign 1 177 178
new 0 177 178
assign 1 177 179
add 1 177 179
assign 1 177 180
toString 0 177 180
assign 1 177 181
add 1 177 181
return 1 177 182
assign 1 182 187
new 0 182 187
return 1 193 190
assign 1 202 196
new 0 202 196
return 1 213 199
assign 1 222 205
new 0 222 205
return 1 233 208
assign 1 242 214
new 0 242 214
return 1 253 217
assign 1 262 223
new 0 262 223
return 1 273 226
assign 1 282 232
new 0 282 232
return 1 293 235
assign 1 301 240
new 0 301 240
return 1 301 241
assign 1 343 249
new 0 343 249
return 1 343 250
assign 1 385 258
new 0 385 258
return 1 385 259
assign 1 413 267
new 0 413 267
return 1 413 268
assign 1 441 276
new 0 441 276
return 1 441 277
assign 1 469 285
new 0 469 285
return 1 469 286
assign 1 497 294
new 0 497 294
return 1 497 295
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1676715436: return bem_iteratorGet_0();
case -1844269288: return bem_create_0();
case 48424000: return bem_vfloatGet_0();
case 1788527916: return bem_decrement_0();
case -1717921599: return bem_serializeToString_0();
case -2042483961: return bem_toString_0();
case -1425898375: return bem_new_0();
case 1876953354: return bem_serializeContentsGet_0();
case 436863164: return bem_hashGet_0();
case 1313758565: return bem_increment_0();
case -713554455: return bem_vfloatSet_0();
case 1861855516: return bem_copy_0();
case -1757033570: return bem_print_0();
case -1788166164: return bem_toInt_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1031379539: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case -272587445: return bem_notEquals_1(bevd_0);
case 324846295: return bem_def_1(bevd_0);
case 931840460: return bem_intNew_1((BEC_2_4_3_MathInt) bevd_0);
case -1107038442: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case -1423618965: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -371582843: return bem_copyTo_1(bevd_0);
case 1089170059: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case -2086891498: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case 2015800048: return bem_new_1(bevd_0);
case 1586592391: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case -720139703: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case 1051624606: return bem_undef_1(bevd_0);
case 1784922692: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1306600423: return bem_equals_1(bevd_0);
case -1500390972: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1243687912: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1704989212: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1725892051: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1176905374: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1263166407: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_MathFloat();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
