package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_9_ContainerLinkedListAwareNode extends BEC_3_9_10_4_ContainerLinkedListNode {
public BEC_3_9_10_9_ContainerLinkedListAwareNode() { }
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x41,0x77,0x61,0x72,0x65,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;

public static BET_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;

public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) throws Throwable {
bevp_held = beva__held;
bevp_held.bemd_1(-755342140, this);
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldSet_1(BEC_2_6_6_SystemObject beva__held) throws Throwable {
bevp_held = beva__held;
bevp_held.bemd_1(-755342140, this);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {98, 99, 100, 104, 105};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 13, 14, 18, 19};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 98 12
heldBySet 1 99 13
assign 1 100 14
assign 1 104 18
heldBySet 1 105 19
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1068935130: return bem_mylistGetDirect_0();
case 517270213: return bem_priorGetDirect_0();
case -1972053611: return bem_priorGet_0();
case 1751408331: return bem_create_0();
case 1926065034: return bem_delete_0();
case -284827837: return bem_serializationIteratorGet_0();
case -1176703679: return bem_fieldNamesGet_0();
case 1925518230: return bem_sourceFileNameGet_0();
case 793345871: return bem_serializeContents_0();
case 949832554: return bem_copy_0();
case 1775735288: return bem_many_0();
case 896037617: return bem_tagGet_0();
case -513793520: return bem_echo_0();
case 2087063400: return bem_nextGet_0();
case 595778190: return bem_heldGetDirect_0();
case 623979920: return bem_fieldIteratorGet_0();
case 996800845: return bem_hashGet_0();
case -127134874: return bem_new_0();
case -399960042: return bem_serializeToString_0();
case 1106799870: return bem_once_0();
case 2056349311: return bem_toString_0();
case 1309169735: return bem_toAny_0();
case 1854711577: return bem_deserializeClassNameGet_0();
case 532163785: return bem_mylistGet_0();
case -271281854: return bem_heldGet_0();
case -1332404135: return bem_nextGetDirect_0();
case 1970795670: return bem_print_0();
case -93701723: return bem_iteratorGet_0();
case -342364250: return bem_classNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1442769844: return bem_defined_1(bevd_0);
case 196505848: return bem_copyTo_1(bevd_0);
case 1564465433: return bem_otherClass_1(bevd_0);
case 496972815: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -131663220: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2135786177: return bem_priorSetDirect_1(bevd_0);
case 907697888: return bem_notEquals_1(bevd_0);
case 396825729: return bem_nextSet_1(bevd_0);
case -1241878849: return bem_undef_1(bevd_0);
case -1613999742: return bem_sameObject_1(bevd_0);
case -898321379: return bem_sameClass_1(bevd_0);
case -451129814: return bem_insertBefore_1(bevd_0);
case -1851864229: return bem_equals_1(bevd_0);
case 1865502099: return bem_sameType_1(bevd_0);
case -1003384436: return bem_heldSetDirect_1(bevd_0);
case 2125352689: return bem_mylistSetDirect_1(bevd_0);
case -1536576377: return bem_mylistSet_1(bevd_0);
case 1950370730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1277827347: return bem_otherType_1(bevd_0);
case 1631175119: return bem_priorSet_1(bevd_0);
case -69593350: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1318574367: return bem_heldSet_1(bevd_0);
case -1608198204: return bem_def_1(bevd_0);
case 496684342: return bem_nextSetDirect_1(bevd_0);
case 1577584266: return bem_undefined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1936049104: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 641350819: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1683215334: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1695587472: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1545739438: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -284782102: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 550444665: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1077148737: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_9_ContainerLinkedListAwareNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst = (BEC_3_9_10_9_ContainerLinkedListAwareNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;
}
}
