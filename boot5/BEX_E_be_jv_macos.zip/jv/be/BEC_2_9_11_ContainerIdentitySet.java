package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet extends BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public BEC_2_9_11_ContainerIdentitySet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentitySet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {199, 199, 203, 204, 205, 206, 207, 208};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 199 13
new 0 199 13
new 1 199 14
assign 1 203 18
new 1 203 18
assign 1 204 19
assign 1 205 20
new 0 205 20
assign 1 206 21
new 0 206 21
assign 1 207 22
new 0 207 22
assign 1 208 23
new 0 208 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1416939995: return bem_fieldNamesGet_0();
case -1770063088: return bem_moduGetDirect_0();
case 769814255: return bem_sourceFileNameGet_0();
case -1829424765: return bem_new_0();
case -821330970: return bem_fieldIteratorGet_0();
case 627368752: return bem_clear_0();
case -1117841689: return bem_relGetDirect_0();
case -285809792: return bem_iteratorGet_0();
case 418678181: return bem_create_0();
case -2071205409: return bem_sizeGetDirect_0();
case 327774600: return bem_innerPutAddedGetDirect_0();
case -1588300494: return bem_many_0();
case -1175877060: return bem_serializationIteratorGet_0();
case -1629315459: return bem_once_0();
case -2119225685: return bem_innerPutAddedGet_0();
case -1946033573: return bem_isEmptyGet_0();
case 1322082037: return bem_keyIteratorGet_0();
case 335028608: return bem_moduGet_0();
case -807409811: return bem_deserializeClassNameGet_0();
case 1386516464: return bem_tagGet_0();
case 1044693889: return bem_multiGet_0();
case 1426181439: return bem_print_0();
case 2858608: return bem_setIteratorGet_0();
case 1493048824: return bem_echo_0();
case -1434470463: return bem_multiGetDirect_0();
case -271514631: return bem_nodesGet_0();
case -1850807496: return bem_keysGet_0();
case -36004389: return bem_nodeIteratorGet_0();
case -759614770: return bem_serializeToString_0();
case -1274019410: return bem_copy_0();
case 181352533: return bem_toString_0();
case -1041327364: return bem_relGet_0();
case -870926142: return bem_serializeContents_0();
case -524168508: return bem_baseNodeGetDirect_0();
case 613200867: return bem_sizeGet_0();
case -1137417943: return bem_slotsGetDirect_0();
case -1843989596: return bem_notEmptyGet_0();
case 1143341249: return bem_hashGet_0();
case -405562305: return bem_toAny_0();
case 18400352: return bem_baseNodeGet_0();
case -1642425221: return bem_slotsGet_0();
case 631110600: return bem_classNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -685913968: return bem_slotsSetDirect_1(bevd_0);
case 1931572257: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1510672574: return bem_slotsSet_1(bevd_0);
case 1656347955: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 119041715: return bem_multiSet_1(bevd_0);
case -859534092: return bem_equals_1(bevd_0);
case 1833226494: return bem_delete_1(bevd_0);
case -1027507443: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -258929109: return bem_sizeSetDirect_1(bevd_0);
case -198509756: return bem_get_1(bevd_0);
case -301191641: return bem_baseNodeSet_1(bevd_0);
case 1075028542: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1703662662: return bem_moduSetDirect_1(bevd_0);
case 1723573660: return bem_otherType_1(bevd_0);
case 646729715: return bem_put_1(bevd_0);
case 599422049: return bem_copyTo_1(bevd_0);
case -2007258322: return bem_relSet_1(bevd_0);
case -2046792613: return bem_defined_1(bevd_0);
case 1378844995: return bem_def_1(bevd_0);
case 1747277191: return bem_undef_1(bevd_0);
case -255815863: return bem_has_1(bevd_0);
case 1734141663: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -339502058: return bem_sameClass_1(bevd_0);
case -298306547: return bem_baseNodeSetDirect_1(bevd_0);
case 537235008: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 402602889: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1531647583: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2055717440: return bem_undefined_1(bevd_0);
case 1652037391: return bem_relSetDirect_1(bevd_0);
case 621653151: return bem_notEquals_1(bevd_0);
case 944151768: return bem_addValue_1(bevd_0);
case -431787489: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 1468755134: return bem_sameType_1(bevd_0);
case 1574213536: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1812765256: return bem_multiSetDirect_1(bevd_0);
case -1922109672: return bem_sizeSet_1(bevd_0);
case 1154001207: return bem_innerPutAddedSet_1(bevd_0);
case 428227432: return bem_sameObject_1(bevd_0);
case -1366545491: return bem_otherClass_1(bevd_0);
case 1286061101: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 2084268872: return bem_moduSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 310321751: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -496019130: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1992393015: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1454137039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1940209680: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 981296949: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885634458: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 999054655: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 623034616: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentitySet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
