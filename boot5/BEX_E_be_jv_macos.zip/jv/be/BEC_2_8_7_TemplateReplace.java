package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_7_TemplateReplace extends BEC_2_6_6_SystemObject {
public BEC_2_8_7_TemplateReplace() { }
private static byte[] becc_BEC_2_8_7_TemplateReplace_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x65,0x70,0x6C,0x61,0x63,0x65};
private static byte[] becc_BEC_2_8_7_TemplateReplace_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_0 = {0x3C,0x3F,0x74,0x74};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_1 = {0x3F,0x3E};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_2 = {0x20};
public static BEC_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_inst;

public static BET_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_steps;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_append;
public BEC_2_8_6_TemplateRunner bevp_runner;
public BEC_2_8_7_TemplateReplace bem_new_0() throws Throwable {
bevp_append = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bem_load_2(beva_template, null);
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_load_2(BEC_2_4_6_TextString beva_template, BEC_2_8_6_TemplateRunner beva__runner) throws Throwable {
BEC_2_4_6_TextString bevl_blStart = null;
BEC_2_4_6_TextString bevl_blEnd = null;
BEC_2_5_4_LogicBool bevl_onStart = null;
BEC_2_5_4_LogicBool bevl_nextIsCall = null;
BEC_2_4_6_TextString bevl_delim = null;
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_4_6_TextString bevl_payload = null;
BEC_2_9_10_ContainerLinkedList bevl_payloads = null;
BEC_2_7_8_ReplaceCallStep bevl_rcs = null;
BEC_2_4_6_TextString bevl_paypart = null;
BEC_2_7_7_ReplaceRunStep bevl_rs = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_7_10_ReplaceStringStep bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_7_10_ReplaceStringStep bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevp_runner = beva__runner;
bevp_size = beva_template.bem_sizeGet_0();
bevl_blStart = (new BEC_2_4_6_TextString(4, bece_BEC_2_8_7_TemplateReplace_bels_0));
bevl_blEnd = (new BEC_2_4_6_TextString(2, bece_BEC_2_8_7_TemplateReplace_bels_1));
bevl_onStart = be.BECS_Runtime.boolTrue;
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blStart;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
bevl_ds = bevl_delim.bem_sizeGet_0();
while (true)
/* Line: 82*/ {
if (bevl_i == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 82*/ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 83*/ {
if (bevl_nextIsCall.bevi_bool)/* Line: 84*/ {
bevt_3_ta_ph = beva_template.bem_substring_2(bevl_last, bevl_i);
bevl_payload = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_strip_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_8_7_TemplateReplace_bels_2));
bevl_payloads = bevl_payload.bem_split_1(bevt_4_ta_ph);
if (bevp_runner == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 87*/ {
bevl_rcs = (new BEC_2_7_8_ReplaceCallStep()).bem_new_1(bevl_payloads);
bevl_splits.bem_addValue_1(bevl_rcs);
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
} /* Line: 91*/
 else /* Line: 92*/ {
bevt_0_ta_loop = bevl_payloads.bem_linkedListIteratorGet_0();
while (true)
/* Line: 94*/ {
bevt_6_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 94*/ {
bevl_paypart = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_rs = (new BEC_2_7_7_ReplaceRunStep()).bem_new_2(this, bevl_paypart);
bevl_splits.bem_addValue_1(bevl_rs);
} /* Line: 96*/
 else /* Line: 94*/ {
break;
} /* Line: 94*/
} /* Line: 94*/
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
} /* Line: 98*/
} /* Line: 87*/
 else /* Line: 100*/ {
bevt_8_ta_ph = beva_template.bem_substring_2(bevl_last, bevl_i);
bevt_7_ta_ph = (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_8_ta_ph);
bevl_splits.bem_addValue_1(bevt_7_ta_ph);
} /* Line: 101*/
} /* Line: 84*/
bevl_last = bevl_i.bem_add_1(bevl_ds);
if (bevl_onStart.bevi_bool)/* Line: 105*/ {
bevl_onStart = be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blEnd;
bevl_ds = bevl_delim.bem_sizeGet_0();
bevl_nextIsCall = be.BECS_Runtime.boolTrue;
} /* Line: 109*/
 else /* Line: 110*/ {
bevl_onStart = be.BECS_Runtime.boolTrue;
bevl_delim = bevl_blStart;
bevl_ds = bevl_delim.bem_sizeGet_0();
} /* Line: 113*/
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
} /* Line: 115*/
 else /* Line: 82*/ {
break;
} /* Line: 82*/
} /* Line: 82*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 117*/ {
bevt_11_ta_ph = beva_template.bem_substring_2(bevl_last, bevp_size);
bevt_10_ta_ph = (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_11_ta_ph);
bevl_splits.bem_addValue_1(bevt_10_ta_ph);
} /* Line: 118*/
bevp_steps = bevl_splits;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_accept_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_out) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_iter = bevp_steps.bem_iteratorGet_0();
while (true)
/* Line: 125*/ {
bevt_0_ta_ph = bevl_iter.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 125*/ {
bevl_s = bevl_iter.bemd_0(-190996314);
if (bevp_append.bevi_bool)/* Line: 127*/ {
bevt_1_ta_ph = bevl_s.bemd_1(286673500, beva_inst);
beva_out.bemd_1(947427583, bevt_1_ta_ph);
} /* Line: 128*/
} /* Line: 127*/
 else /* Line: 125*/ {
break;
} /* Line: 125*/
} /* Line: 125*/
return beva_out;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
return bevp_steps;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_stepsGetDirect_0() throws Throwable {
return bevp_steps;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_stepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_7_TemplateReplace bem_stepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_7_TemplateReplace bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_appendGet_0() throws Throwable {
return bevp_append;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_appendGetDirect_0() throws Throwable {
return bevp_append;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_appendSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_7_TemplateReplace bem_appendSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runnerGet_0() throws Throwable {
return bevp_runner;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_runnerGetDirect_0() throws Throwable {
return bevp_runner;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_runnerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_8_7_TemplateReplace bem_runnerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {58, 65, 69, 70, 72, 73, 74, 75, 77, 78, 79, 80, 81, 82, 82, 83, 83, 85, 85, 86, 86, 87, 87, 89, 90, 91, 94, 0, 94, 94, 95, 96, 98, 101, 101, 101, 104, 106, 107, 108, 109, 111, 112, 113, 115, 117, 117, 118, 118, 118, 120, 124, 125, 126, 128, 128, 131, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 23, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 66, 71, 72, 77, 79, 80, 81, 82, 83, 88, 89, 90, 91, 94, 94, 97, 99, 100, 101, 107, 111, 112, 113, 116, 118, 119, 120, 121, 124, 125, 126, 128, 134, 139, 140, 141, 142, 144, 152, 155, 157, 159, 160, 167, 170, 173, 176, 180, 184, 187, 190, 194, 198, 201, 204, 208, 212, 215, 218, 222};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 58 19
new 0 58 19
load 2 65 23
assign 1 69 53
assign 1 70 54
sizeGet 0 70 54
assign 1 72 55
new 0 72 55
assign 1 73 56
new 0 73 56
assign 1 74 57
new 0 74 57
assign 1 75 58
new 0 75 58
assign 1 77 59
assign 1 78 60
new 0 78 60
assign 1 79 61
new 0 79 61
assign 1 80 62
find 2 80 62
assign 1 81 63
sizeGet 0 81 63
assign 1 82 66
def 1 82 71
assign 1 83 72
greater 1 83 77
assign 1 85 79
substring 2 85 79
assign 1 85 80
strip 0 85 80
assign 1 86 81
new 0 86 81
assign 1 86 82
split 1 86 82
assign 1 87 83
undef 1 87 88
assign 1 89 89
new 1 89 89
addValue 1 90 90
assign 1 91 91
new 0 91 91
assign 1 94 94
linkedListIteratorGet 0 0 94
assign 1 94 97
hasNextGet 0 94 97
assign 1 94 99
nextGet 0 94 99
assign 1 95 100
new 2 95 100
addValue 1 96 101
assign 1 98 107
new 0 98 107
assign 1 101 111
substring 2 101 111
assign 1 101 112
new 1 101 112
addValue 1 101 113
assign 1 104 116
add 1 104 116
assign 1 106 118
new 0 106 118
assign 1 107 119
assign 1 108 120
sizeGet 0 108 120
assign 1 109 121
new 0 109 121
assign 1 111 124
new 0 111 124
assign 1 112 125
assign 1 113 126
sizeGet 0 113 126
assign 1 115 128
find 2 115 128
assign 1 117 134
lesser 1 117 139
assign 1 118 140
substring 2 118 140
assign 1 118 141
new 1 118 141
addValue 1 118 142
assign 1 120 144
assign 1 124 152
iteratorGet 0 124 152
assign 1 125 155
hasNextGet 0 125 155
assign 1 126 157
nextGet 0 126 157
assign 1 128 159
handle 1 128 159
write 1 128 160
return 1 131 167
return 1 0 170
return 1 0 173
assign 1 0 176
assign 1 0 180
return 1 0 184
return 1 0 187
assign 1 0 190
assign 1 0 194
return 1 0 198
return 1 0 201
assign 1 0 204
assign 1 0 208
return 1 0 212
return 1 0 215
assign 1 0 218
assign 1 0 222
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1994030597: return bem_appendGetDirect_0();
case 565434536: return bem_runnerGet_0();
case -1938521961: return bem_create_0();
case 1428196909: return bem_deserializeClassNameGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case 1469761457: return bem_serializeToString_0();
case -1120775249: return bem_classNameGet_0();
case -559654393: return bem_sourceFileNameGet_0();
case 976077722: return bem_new_0();
case -583088955: return bem_stepsGet_0();
case -1359840989: return bem_toAny_0();
case -129765629: return bem_print_0();
case -1677294751: return bem_hashGet_0();
case -1660007365: return bem_iteratorGet_0();
case 126164297: return bem_serializationIteratorGet_0();
case -1640020074: return bem_toString_0();
case -1182105932: return bem_sizeGet_0();
case -374496050: return bem_tagGet_0();
case -20214683: return bem_sizeGetDirect_0();
case -1530492540: return bem_many_0();
case 921209725: return bem_echo_0();
case -1606863806: return bem_fieldIteratorGet_0();
case 576432743: return bem_runnerGetDirect_0();
case -1483834827: return bem_copy_0();
case 1881036363: return bem_appendGet_0();
case 2028199664: return bem_once_0();
case 1963846645: return bem_serializeContents_0();
case 1674870710: return bem_stepsGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1789648416: return bem_def_1(bevd_0);
case 1400060641: return bem_stepsSetDirect_1(bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case -638886250: return bem_stepsSet_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case 1621663026: return bem_appendSet_1(bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case 1414981672: return bem_defined_1(bevd_0);
case 1252772500: return bem_runnerSet_1(bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case -1715259235: return bem_sizeSet_1(bevd_0);
case 1625098724: return bem_sizeSetDirect_1(bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case 1471753611: return bem_runnerSetDirect_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1162631131: return bem_appendSetDirect_1(bevd_0);
case -203872412: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 125166773: return bem_load_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_8_6_TemplateRunner) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1619869217: return bem_accept_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_8_7_TemplateReplace_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_7_TemplateReplace_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_7_TemplateReplace();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst = (BEC_2_8_7_TemplateReplace) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_type;
}
}
