package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue extends BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_9_12_ContainerBoundedQueue bem_new_0() throws Throwable {
super.bem_new_0();
bevp_max = (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
super.bem_enqueue_1(beva_item);
if (bevp_size.bevi_int > bevp_max.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 190 */ {
bem_dequeue_0();
} /* Line: 191 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() throws Throwable {
return bevp_max;
} /*method end*/
public final BEC_2_4_3_MathInt bem_maxGetDirect_0() throws Throwable {
return bevp_max;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_12_ContainerBoundedQueue bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {183, 185, 189, 190, 190, 191, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 19, 20, 25, 26, 31, 34, 37, 41};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 183 13
assign 1 185 14
new 0 185 14
enqueue 1 189 19
assign 1 190 20
greater 1 190 25
dequeue 0 191 26
return 1 0 31
return 1 0 34
assign 1 0 37
assign 1 0 41
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 647733846: return bem_hashGet_0();
case 1622841018: return bem_endGet_0();
case -1304009809: return bem_isEmptyGet_0();
case 1977268733: return bem_toAny_0();
case -1019129421: return bem_iteratorGet_0();
case -1138165086: return bem_sizeGetDirect_0();
case 1966604989: return bem_deserializeClassNameGet_0();
case 6718322: return bem_sizeGet_0();
case -1172191432: return bem_maxGet_0();
case 762211239: return bem_endGetDirect_0();
case 415444144: return bem_many_0();
case -1322750582: return bem_fieldNamesGet_0();
case -1459660688: return bem_once_0();
case 1464556610: return bem_serializeContents_0();
case 810516096: return bem_tagGet_0();
case 1575456669: return bem_topGet_0();
case -434142726: return bem_topGetDirect_0();
case 1516528362: return bem_copy_0();
case -1440519528: return bem_new_0();
case 1544637441: return bem_fieldIteratorGet_0();
case -1263337031: return bem_dequeue_0();
case 764111846: return bem_classNameGet_0();
case -2027075098: return bem_sourceFileNameGet_0();
case 1640160430: return bem_serializationIteratorGet_0();
case 1256493526: return bem_create_0();
case -1939101875: return bem_maxGetDirect_0();
case -352222734: return bem_echo_0();
case -2042019182: return bem_toString_0();
case -1857169421: return bem_print_0();
case -916808790: return bem_serializeToString_0();
case 967328937: return bem_get_0();
case 1018774863: return bem_bottomGet_0();
case -1888510221: return bem_bottomGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2113151813: return bem_otherClass_1(bevd_0);
case -1411367049: return bem_bottomSet_1(bevd_0);
case 173437066: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -62499290: return bem_notEquals_1(bevd_0);
case 1686689499: return bem_sameType_1(bevd_0);
case 1303995883: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1529930548: return bem_def_1(bevd_0);
case -1115611450: return bem_sizeSetDirect_1(bevd_0);
case -1693595005: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 129664577: return bem_undefined_1(bevd_0);
case -1066262854: return bem_copyTo_1(bevd_0);
case 1427505482: return bem_maxSetDirect_1(bevd_0);
case 1149328783: return bem_equals_1(bevd_0);
case -882863317: return bem_put_1(bevd_0);
case 1967381275: return bem_endSet_1(bevd_0);
case -416017260: return bem_addValue_1(bevd_0);
case 119389551: return bem_bottomSetDirect_1(bevd_0);
case 456604916: return bem_defined_1(bevd_0);
case -940731965: return bem_sizeSet_1(bevd_0);
case 858949566: return bem_sameObject_1(bevd_0);
case -1103921791: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1292763202: return bem_topSetDirect_1(bevd_0);
case 52862353: return bem_endSetDirect_1(bevd_0);
case -1451816788: return bem_otherType_1(bevd_0);
case 1002330026: return bem_topSet_1(bevd_0);
case -1884560238: return bem_sameClass_1(bevd_0);
case -1726382580: return bem_undef_1(bevd_0);
case -475414837: return bem_maxSet_1(bevd_0);
case 2133273975: return bem_enqueue_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -840184945: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2113325337: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1732137967: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1058450326: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1752849240: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1337367239: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 572204899: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
