package be;
public class BET_3_5_5_5_BuildVisitPass1 extends BETS_Object {
public BET_3_5_5_5_BuildVisitPass1() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "begin_1", "accept_1", "end_1", "transGet_0", "transGetDirect_0", "transSet_1", "transSetDirect_1", "buildGet_0", "buildGetDirect_0", "buildSet_1", "buildSetDirect_1", "constGet_0", "constGetDirect_0", "constSet_1", "constSetDirect_1", "ntypesGet_0", "ntypesGetDirect_0", "ntypesSet_1", "ntypesSetDirect_1", "new_2", "printAstElementsGet_0", "printAstElementsGetDirect_0", "printAstElementsSet_1", "printAstElementsSetDirect_1", "allAstElementsGet_0", "allAstElementsGetDirect_0", "allAstElementsSet_1", "allAstElementsSetDirect_1", "fGet_0", "fGetDirect_0", "fSet_1", "fSetDirect_1", "inClassGet_0", "inClassGetDirect_0", "inClassSet_1", "inClassSetDirect_1", "inClassMethodGet_0", "inClassMethodGetDirect_0", "inClassMethodSet_1", "inClassMethodSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "trans", "build", "const", "ntypes", "printAstElements", "allAstElements", "f", "inClass", "inClassMethod" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_5_5_5_BuildVisitPass1();
}
}
