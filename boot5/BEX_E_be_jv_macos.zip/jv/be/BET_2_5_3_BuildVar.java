package be;
public class BET_2_5_3_BuildVar extends BETS_Object {
public BET_2_5_3_BuildVar() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "synNew_1", "addCall_1", "maxCposGet_0", "minCposGet_0", "nameGet_0", "nameSet_1", "namepathGet_0", "namepathSet_1", "refsGet_0", "refsSet_1", "allCallsGet_0", "allCallsSet_1", "suffixGet_0", "suffixSet_1", "isArgGet_0", "isArgSet_1", "isAddedGet_0", "isAddedSet_1", "isTmpVarGet_0", "isTmpVarSet_1", "autoTypeGet_0", "autoTypeSet_1", "isDeclaredGet_0", "isDeclaredSet_1", "isPropertyGet_0", "isPropertySet_1", "isSlotGet_0", "isSlotSet_1", "numAssignsGet_0", "numAssignsSet_1", "isTypedGet_0", "isTypedSet_1", "vposGet_0", "vposSet_1", "isSelfGet_0", "isSelfSet_1", "isThisGet_0", "isThisSet_1", "impliedGet_0", "impliedSet_1", "maxCposSet_1", "minCposSet_1", "nativeNameGet_0", "nativeNameSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "name", "namepath", "refs", "allCalls", "suffix", "isArg", "isAdded", "isTmpVar", "autoType", "isDeclared", "isProperty", "isSlot", "numAssigns", "isTyped", "vpos", "isSelf", "isThis", "implied", "maxCpos", "minCpos", "nativeName" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_3_BuildVar();
}
}
