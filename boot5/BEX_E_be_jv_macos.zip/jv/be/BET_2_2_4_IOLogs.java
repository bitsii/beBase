package be;
public class BET_2_2_4_IOLogs extends BETS_Object {
public BET_2_2_4_IOLogs() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameType_1", "otherType_1", "default_0", "setDefaultLevels_2", "putKeyLevels_3", "putLevels_3", "getKey_1", "get_1", "turnOn_1", "turnOnAll_0", "setAllSinks_1", "debugGet_0", "debugSet_1", "infoGet_0", "infoSet_1", "warnGet_0", "warnSet_1", "errorGet_0", "errorSet_1", "fatalGet_0", "fatalSet_1", "overridesGet_0", "overridesSet_1", "loggersGet_0", "loggersSet_1", "lockGet_0", "lockSet_1", "defaultOutputLevelGet_0", "defaultOutputLevelSet_1", "defaultLevelGet_0", "defaultLevelSet_1", "sinkGet_0", "sinkSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "debug", "info", "warn", "error", "fatal", "overrides", "loggers", "lock", "defaultOutputLevel", "defaultLevel", "sink" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_2_4_IOLogs();
}
}
