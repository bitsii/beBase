package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x65,0x6D,0x62,0x50,0x6C,0x61,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x3A,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x62,0x65,0x76,0x6F,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildJSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_formTarg_1(beva_node);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_invp);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_7));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_8));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_11));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(2041755654);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1874396358);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_14));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_15));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = beva_sdec.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_belsName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_1_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(903676807);
bevt_9_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_ta_ph );
bevt_12_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_12_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(317433422);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 81*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 81*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(-785429246);
if (bevl_first.bevi_bool)/* Line: 82*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 83*/
 else /* Line: 84*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 85*/
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_7_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 87*/
 else /* Line: 81*/ {
break;
} /* Line: 81*/
} /* Line: 81*/
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(903676807);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_13_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevl_stinst);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_20_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_21_ta_ph);
bevt_20_ta_ph.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_0_ta_ph = beva_sdec.bem_addValue_1(bevt_1_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_3_ta_ph = beva_v.bem_nameGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 132*/
bevt_4_ta_ph = super.bem_nameForVar_1(beva_v);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_writeBET_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_7_TextStrings bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_7_TextStrings bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_7_TextStrings bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_7_TextStrings bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_5_4_LogicBool bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_6_6_SystemObject bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_5_4_LogicBool bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_4_LogicBool bevt_116_ta_ph = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
/* Line: 148*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 148*/ {
bevl_clnode = bevl_ci.bemd_0(-785429246);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_8_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevp_q);
bevt_12_ta_ph = bevl_clnode.bemd_0(-640096766);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(903676807);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-899256741);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevp_q);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_17_ta_ph = bevl_clnode.bemd_0(-640096766);
bevt_16_ta_ph = bevt_17_ta_ph.bemd_0(903676807);
bevt_15_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_ta_ph );
bevt_18_ta_ph = bevp_build.bem_libNameGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_relEmitName_1(bevt_18_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_22_ta_ph = bevl_clnode.bemd_0(-640096766);
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(317433422);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(1147220757);
if (((BEC_2_5_4_LogicBool) bevt_20_ta_ph).bevi_bool)/* Line: 154*/ {
bevt_24_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_28_ta_ph = bevl_clnode.bemd_0(-640096766);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(903676807);
bevt_26_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_ta_ph );
bevt_29_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bem_relEmitName_1(bevt_29_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevl_nc = bevt_23_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_34_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_33_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_34_ta_ph);
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevl_nc);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_ta_ph = bevt_32_ta_ph.bem_addValue_1(bevt_35_ta_ph);
bevt_31_ta_ph.bem_addValue_1(bevp_nl);
bevt_38_ta_ph = bevl_clnode.bemd_0(-640096766);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_0(317433422);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(1147220757);
if (((BEC_2_5_4_LogicBool) bevt_36_ta_ph).bevi_bool)/* Line: 163*/ {
bevt_42_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_41_ta_ph = bevl_notNullInitDefault.bem_addValue_1(bevt_42_ta_ph);
bevt_40_ta_ph = bevt_41_ta_ph.bem_addValue_1(bevl_nc);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_39_ta_ph = bevt_40_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_39_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 164*/
} /* Line: 163*/
} /* Line: 154*/
 else /* Line: 148*/ {
break;
} /* Line: 148*/
} /* Line: 148*/
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_ta_ph = bevp_smnlcs.bem_keysGet_0();
bevt_0_ta_loop = bevt_44_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 172*/ {
bevt_45_ta_ph = bevt_0_ta_loop.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 172*/ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-785429246);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_52_ta_ph = bevl_smap.bem_addValue_1(bevt_53_ta_ph);
bevt_55_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_ta_ph = bevt_55_ta_ph.bem_quoteGet_0();
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_54_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevl_smk);
bevt_57_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_ta_ph = bevt_57_ta_ph.bem_quoteGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_48_ta_ph = bevt_49_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_ta_ph = bevt_48_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_46_ta_ph = bevt_47_ta_ph.bem_addValue_1(bevt_60_ta_ph);
bevt_46_ta_ph.bem_addValue_1(bevp_nl);
bevt_68_ta_ph = (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_67_ta_ph = bevl_smap.bem_addValue_1(bevt_68_ta_ph);
bevt_70_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_ta_ph = bevt_70_ta_ph.bem_quoteGet_0();
bevt_66_ta_ph = bevt_67_ta_ph.bem_addValue_1(bevt_69_ta_ph);
bevt_65_ta_ph = bevt_66_ta_ph.bem_addValue_1(bevl_smk);
bevt_72_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_ta_ph = bevt_72_ta_ph.bem_quoteGet_0();
bevt_64_ta_ph = bevt_65_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_73_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_63_ta_ph = bevt_64_ta_ph.bem_addValue_1(bevt_73_ta_ph);
bevt_74_ta_ph = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_ta_ph = bevt_63_ta_ph.bem_addValue_1(bevt_74_ta_ph);
bevt_75_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_61_ta_ph = bevt_62_ta_ph.bem_addValue_1(bevt_75_ta_ph);
bevt_61_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 175*/
 else /* Line: 172*/ {
break;
} /* Line: 172*/
} /* Line: 172*/
bevt_77_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_78_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_76_ta_ph = bevt_77_ta_ph.bem_has_1(bevt_78_ta_ph);
if (!(bevt_76_ta_ph.bevi_bool))/* Line: 179*/ {
bevl_libe.bem_write_1(bevl_smap);
} /* Line: 180*/
bevt_81_ta_ph = bevp_build.bem_usedLibrarysGet_0();
bevt_80_ta_ph = bevt_81_ta_ph.bem_sizeGet_0();
bevt_82_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_80_ta_ph.bevi_int == bevt_82_ta_ph.bevi_int) {
bevt_79_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_79_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_79_ta_ph.bevi_bool)/* Line: 184*/ {
bevt_84_ta_ph = (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_83_ta_ph = bevl_libInit.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_85_ta_ph = bevl_libInit.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevt_88_ta_ph = (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_87_ta_ph = bevl_libInit.bem_addValue_1(bevt_88_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 187*/
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_89_ta_ph = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_89_ta_ph);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_93_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_92_ta_ph = bevl_main.bem_addValue_1(bevt_93_ta_ph);
bevt_94_ta_ph = bevl_maincc.bem_fullEmitNameGet_0();
bevt_91_ta_ph = bevt_92_ta_ph.bem_addValue_1(bevt_94_ta_ph);
bevt_95_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_90_ta_ph = bevt_91_ta_ph.bem_addValue_1(bevt_95_ta_ph);
bevt_90_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_96_ta_ph.bevi_bool)/* Line: 200*/ {
bevt_98_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_99_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_97_ta_ph = bevt_98_ta_ph.bem_has_1(bevt_99_ta_ph);
if (!(bevt_97_ta_ph.bevi_bool))/* Line: 201*/ {
bevt_101_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_100_ta_ph = bevl_main.bem_addValue_1(bevt_101_ta_ph);
bevt_100_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 202*/
} /* Line: 201*/
bevt_105_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_104_ta_ph = bevl_main.bem_addValue_1(bevt_105_ta_ph);
bevt_107_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_106_ta_ph = bevt_107_ta_ph.bemd_0(-1426266517);
bevt_103_ta_ph = bevt_104_ta_ph.bem_addValue_1(bevt_106_ta_ph);
bevt_108_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_102_ta_ph = bevt_103_ta_ph.bem_addValue_1(bevt_108_ta_ph);
bevt_102_ta_ph.bem_addValue_1(bevp_nl);
bevt_109_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_109_ta_ph.bevi_bool)/* Line: 206*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 207*/
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_110_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_110_ta_ph.bevi_bool)/* Line: 212*/ {
bevt_112_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_111_ta_ph = bevl_main.bem_addValue_1(bevt_112_ta_ph);
bevt_111_ta_ph.bem_addValue_1(bevp_nl);
bevt_114_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_113_ta_ph = bevl_main.bem_addValue_1(bevt_114_ta_ph);
bevt_113_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 214*/
bevt_115_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_115_ta_ph.bevi_bool)/* Line: 216*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 217*/
bem_finishLibOutput_1(bevl_libe);
bevt_116_ta_ph = bevp_build.bem_saveSynsGet_0();
if (bevt_116_ta_ph.bevi_bool)/* Line: 222*/ {
bem_saveSyns_0();
} /* Line: 223*/
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 229*/ {
} /* Line: 229*/
 else /* Line: 231*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 232*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
beva_b.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 233*/
bevt_4_ta_ph = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 235*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_exceptDec);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_parent);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
bevl_extstr = bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_7_ta_ph = bevl_extstr.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevl_extstr = bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1001091226);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1001091226);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
if (beva_isOnce.bevi_bool)/* Line: 266*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(27, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_belsName);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_0_ta_ph;
} /* Line: 267*/
bevt_24_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_26_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = beva_newcc.bem_relEmitName_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(beva_belsName);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_lisz);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_31_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 273*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 274*/
 else /* Line: 275*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 276*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_6_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_8_ta_ph = bevl_begin.bem_addValue_1(bevt_9_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(2085016889);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 292*/ {
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(beva_callArgs);
if (bevt_2_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_67));
beva_callArgs = bevt_4_ta_ph.bem_add_1(beva_callArgs);
} /* Line: 294*/
 else /* Line: 295*/ {
beva_callArgs = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
} /* Line: 296*/
bevt_10_ta_ph = bevp_parentConf.bem_emitNameGet_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_68));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-1426266517);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_69));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_callArgs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_5_ta_ph;
} /* Line: 298*/
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_20_ta_ph = beva_callTarget.bem_add_1(bevt_21_ta_ph);
bevt_23_ta_ph = beva_node.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(-1426266517);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_71));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_callArgs);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_25_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_allOnceDecs == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 312*/ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 313*/
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getLibOutput_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_13_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
if (bevp_shlibe == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 329*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_7_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 332*/
bevt_9_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_ta_ph.bemd_0(1175327021);
bevt_11_ta_ph = bevp_build.bem_paramsGet_0();
bevt_12_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_10_ta_ph = bevt_11_ta_ph.bem_has_1(bevt_12_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_14_ta_ph = bevp_build.bem_paramsGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_13_ta_ph = bevt_14_ta_ph.bem_get_1(bevt_15_ta_ph);
bevt_0_ta_loop = bevt_13_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 337*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 337*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-785429246);
bevt_17_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1175327021);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_ta_ph.bemd_0(-1215164118);
bevt_20_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph.bemd_0(-2077233598);
bevt_21_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 342*/
 else /* Line: 337*/ {
break;
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 336*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_73));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_74));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_anyName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_75));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_typeName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = beva_newcc.bem_relEmitName_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_77));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_count);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_methods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_78));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_ta_ph = bevp_methods.bem_addValue_1(bevt_7_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_80));
bevt_1_ta_ph = beva_nameSpace.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_emitName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_81));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public final BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 63, 63, 63, 63, 63, 67, 67, 67, 67, 67, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 70, 70, 70, 75, 75, 76, 78, 78, 78, 78, 80, 81, 0, 81, 81, 83, 85, 85, 87, 87, 87, 87, 87, 87, 91, 91, 91, 96, 96, 96, 97, 99, 99, 99, 99, 99, 102, 102, 102, 102, 104, 104, 104, 106, 106, 106, 106, 106, 109, 109, 109, 109, 109, 109, 111, 111, 111, 113, 118, 119, 120, 126, 126, 126, 131, 132, 132, 132, 132, 134, 134, 143, 145, 146, 147, 148, 148, 150, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 154, 154, 154, 156, 156, 156, 156, 156, 156, 156, 156, 156, 162, 162, 162, 162, 162, 162, 163, 163, 163, 164, 164, 164, 164, 164, 164, 170, 172, 172, 0, 172, 172, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 179, 179, 179, 180, 184, 184, 184, 184, 184, 185, 185, 185, 186, 186, 186, 187, 187, 187, 190, 191, 194, 195, 195, 196, 198, 199, 199, 199, 199, 199, 199, 199, 200, 201, 201, 201, 202, 202, 202, 205, 205, 205, 205, 205, 205, 205, 205, 206, 207, 209, 210, 211, 212, 213, 213, 213, 214, 214, 214, 216, 217, 220, 222, 223, 229, 232, 232, 232, 233, 233, 235, 235, 240, 240, 244, 244, 244, 244, 244, 244, 248, 248, 252, 252, 252, 252, 252, 252, 252, 253, 253, 253, 253, 253, 254, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 273, 273, 274, 274, 274, 276, 276, 278, 278, 278, 278, 278, 286, 286, 286, 287, 288, 292, 292, 293, 293, 294, 294, 296, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 304, 305, 312, 312, 313, 315, 316, 316, 321, 321, 329, 329, 330, 331, 331, 331, 331, 331, 332, 332, 332, 334, 334, 334, 336, 336, 336, 337, 337, 337, 337, 0, 337, 337, 338, 338, 339, 339, 339, 340, 340, 341, 341, 342, 348, 352, 353, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 378, 378, 382, 382, 387, 387, 393, 393, 398, 398, 402, 402, 402, 402, 402, 402, 406, 406, 410, 410, 410, 410, 410, 415, 415, 415, 415, 415, 415, 415, 420, 420, 420, 420, 420, 420, 420, 422, 424, 424, 424, 429, 429, 433, 433, 437, 437, 437, 437, 442, 442, 446, 447, 447, 448, 452, 453, 453, 454, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {96, 97, 98, 99, 100, 101, 102, 103, 109, 110, 111, 117, 118, 119, 120, 126, 127, 128, 129, 139, 140, 141, 142, 143, 144, 145, 146, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 199, 200, 201, 202, 203, 204, 205, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 265, 266, 267, 268, 269, 270, 271, 272, 273, 273, 276, 278, 280, 283, 284, 286, 287, 288, 289, 290, 291, 297, 298, 299, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 362, 363, 364, 370, 371, 372, 381, 383, 384, 385, 386, 388, 389, 524, 525, 526, 527, 528, 531, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 576, 577, 578, 579, 580, 581, 589, 590, 591, 591, 594, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 634, 635, 636, 638, 640, 641, 642, 643, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 675, 676, 677, 679, 680, 681, 684, 685, 686, 687, 688, 689, 690, 691, 692, 694, 696, 697, 698, 699, 701, 702, 703, 704, 705, 706, 708, 710, 712, 713, 715, 725, 729, 730, 735, 736, 737, 739, 740, 746, 747, 755, 756, 757, 758, 759, 760, 764, 765, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 926, 931, 932, 933, 934, 937, 938, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 978, 979, 981, 982, 984, 985, 988, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1017, 1018, 1023, 1028, 1029, 1031, 1032, 1033, 1037, 1038, 1069, 1074, 1075, 1076, 1077, 1078, 1079, 1084, 1085, 1086, 1087, 1089, 1090, 1091, 1092, 1093, 1094, 1096, 1097, 1098, 1099, 1099, 1102, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1122, 1125, 1126, 1131, 1132, 1136, 1137, 1141, 1142, 1146, 1147, 1151, 1152, 1156, 1157, 1161, 1162, 1166, 1167, 1171, 1172, 1176, 1177, 1185, 1186, 1187, 1188, 1189, 1190, 1194, 1195, 1202, 1203, 1204, 1205, 1206, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1247, 1248, 1252, 1253, 1259, 1260, 1261, 1262, 1266, 1267, 1272, 1273, 1274, 1275, 1280, 1281, 1282, 1283, 1286, 1289, 1292, 1296, 1300, 1303, 1306, 1310};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 96
new 0 16 96
assign 1 17 97
new 0 17 97
assign 1 18 98
new 0 18 98
new 1 22 99
assign 1 24 100
new 0 24 100
assign 1 25 101
new 0 25 101
assign 1 27 102
new 0 27 102
assign 1 28 103
new 0 28 103
assign 1 32 109
formTarg 1 32 109
assign 1 32 110
add 1 32 110
return 1 32 111
assign 1 36 117
formCallTarg 1 36 117
assign 1 36 118
new 0 36 118
assign 1 36 119
add 1 36 119
return 1 36 120
assign 1 40 126
formCallTarg 1 40 126
assign 1 40 127
new 0 40 127
assign 1 40 128
add 1 40 128
return 1 40 129
assign 1 44 139
new 0 44 139
assign 1 44 140
addValue 1 44 140
assign 1 44 141
secondGet 0 44 141
assign 1 44 142
formTarg 1 44 142
assign 1 44 143
addValue 1 44 143
assign 1 44 144
new 0 44 144
assign 1 44 145
addValue 1 44 145
addValue 1 44 146
assign 1 48 167
new 0 48 167
assign 1 48 168
toString 0 48 168
assign 1 48 169
add 1 48 169
incrementValue 0 49 170
assign 1 50 171
new 0 50 171
assign 1 50 172
addValue 1 50 172
assign 1 50 173
addValue 1 50 173
assign 1 50 174
new 0 50 174
assign 1 50 175
addValue 1 50 175
addValue 1 50 176
assign 1 55 177
containedGet 0 55 177
assign 1 55 178
firstGet 0 55 178
assign 1 55 179
containedGet 0 55 179
assign 1 55 180
firstGet 0 55 180
assign 1 55 181
new 0 55 181
assign 1 55 182
add 1 55 182
assign 1 55 183
new 0 55 183
assign 1 55 184
add 1 55 184
assign 1 55 185
finalAssign 4 55 185
addValue 1 55 186
assign 1 63 199
emitNameGet 0 63 199
assign 1 63 200
addValue 1 63 200
assign 1 63 201
new 0 63 201
assign 1 63 202
addValue 1 63 202
assign 1 63 203
addValue 1 63 203
assign 1 63 204
new 0 63 204
addValue 1 63 205
assign 1 67 225
emitNameGet 0 67 225
assign 1 67 226
addValue 1 67 226
assign 1 67 227
new 0 67 227
assign 1 67 228
addValue 1 67 228
addValue 1 67 229
assign 1 68 230
new 0 68 230
assign 1 68 231
addValue 1 68 231
assign 1 68 232
heldGet 0 68 232
assign 1 68 233
namepathGet 0 68 233
assign 1 68 234
getClassConfig 1 68 234
assign 1 68 235
libNameGet 0 68 235
assign 1 68 236
relEmitName 1 68 236
assign 1 68 237
addValue 1 68 237
assign 1 68 238
new 0 68 238
assign 1 68 239
addValue 1 68 239
addValue 1 68 240
assign 1 70 241
new 0 70 241
assign 1 70 242
addValue 1 70 242
addValue 1 70 243
assign 1 75 265
heldGet 0 75 265
assign 1 75 266
synGet 0 75 266
assign 1 76 267
ptyListGet 0 76 267
assign 1 78 268
emitNameGet 0 78 268
assign 1 78 269
addValue 1 78 269
assign 1 78 270
new 0 78 270
addValue 1 78 271
assign 1 80 272
new 0 80 272
assign 1 81 273
iteratorGet 0 0 273
assign 1 81 276
hasNextGet 0 81 276
assign 1 81 278
nextGet 0 81 278
assign 1 83 280
new 0 83 280
assign 1 85 283
new 0 85 283
addValue 1 85 284
assign 1 87 286
addValue 1 87 286
assign 1 87 287
new 0 87 287
assign 1 87 288
addValue 1 87 288
assign 1 87 289
nameGet 0 87 289
assign 1 87 290
addValue 1 87 290
addValue 1 87 291
assign 1 91 297
new 0 91 297
assign 1 91 298
addValue 1 91 298
addValue 1 91 299
assign 1 96 327
heldGet 0 96 327
assign 1 96 328
namepathGet 0 96 328
assign 1 96 329
getClassConfig 1 96 329
assign 1 97 330
getInitialInst 1 97 330
assign 1 99 331
emitNameGet 0 99 331
assign 1 99 332
addValue 1 99 332
assign 1 99 333
new 0 99 333
assign 1 99 334
addValue 1 99 334
addValue 1 99 335
assign 1 102 336
addValue 1 102 336
assign 1 102 337
new 0 102 337
assign 1 102 338
addValue 1 102 338
addValue 1 102 339
assign 1 104 340
new 0 104 340
assign 1 104 341
addValue 1 104 341
addValue 1 104 342
assign 1 106 343
emitNameGet 0 106 343
assign 1 106 344
addValue 1 106 344
assign 1 106 345
new 0 106 345
assign 1 106 346
addValue 1 106 346
addValue 1 106 347
assign 1 109 348
new 0 109 348
assign 1 109 349
addValue 1 109 349
assign 1 109 350
addValue 1 109 350
assign 1 109 351
new 0 109 351
assign 1 109 352
addValue 1 109 352
addValue 1 109 353
assign 1 111 354
new 0 111 354
assign 1 111 355
addValue 1 111 355
addValue 1 111 356
buildPropList 0 113 357
getCode 2 118 362
assign 1 119 363
toString 0 119 363
addValue 1 120 364
assign 1 126 370
new 0 126 370
assign 1 126 371
addValue 1 126 371
addValue 1 126 372
assign 1 131 381
isPropertyGet 0 131 381
assign 1 132 383
new 0 132 383
assign 1 132 384
nameGet 0 132 384
assign 1 132 385
add 1 132 385
return 1 132 386
assign 1 134 388
nameForVar 1 134 388
return 1 134 389
assign 1 143 524
getLibOutput 0 143 524
assign 1 145 525
new 0 145 525
assign 1 146 526
new 0 146 526
assign 1 147 527
new 0 147 527
assign 1 148 528
iteratorGet 0 148 528
assign 1 148 531
hasNextGet 0 148 531
assign 1 150 533
nextGet 0 150 533
assign 1 152 534
new 0 152 534
assign 1 152 535
addValue 1 152 535
assign 1 152 536
addValue 1 152 536
assign 1 152 537
heldGet 0 152 537
assign 1 152 538
namepathGet 0 152 538
assign 1 152 539
toString 0 152 539
assign 1 152 540
addValue 1 152 540
assign 1 152 541
addValue 1 152 541
assign 1 152 542
new 0 152 542
assign 1 152 543
addValue 1 152 543
assign 1 152 544
heldGet 0 152 544
assign 1 152 545
namepathGet 0 152 545
assign 1 152 546
getClassConfig 1 152 546
assign 1 152 547
libNameGet 0 152 547
assign 1 152 548
relEmitName 1 152 548
assign 1 152 549
addValue 1 152 549
assign 1 152 550
new 0 152 550
assign 1 152 551
addValue 1 152 551
addValue 1 152 552
assign 1 154 553
heldGet 0 154 553
assign 1 154 554
synGet 0 154 554
assign 1 154 555
hasDefaultGet 0 154 555
assign 1 156 557
new 0 156 557
assign 1 156 558
heldGet 0 156 558
assign 1 156 559
namepathGet 0 156 559
assign 1 156 560
getClassConfig 1 156 560
assign 1 156 561
libNameGet 0 156 561
assign 1 156 562
relEmitName 1 156 562
assign 1 156 563
add 1 156 563
assign 1 156 564
new 0 156 564
assign 1 156 565
add 1 156 565
assign 1 162 566
new 0 162 566
assign 1 162 567
addValue 1 162 567
assign 1 162 568
addValue 1 162 568
assign 1 162 569
new 0 162 569
assign 1 162 570
addValue 1 162 570
addValue 1 162 571
assign 1 163 572
heldGet 0 163 572
assign 1 163 573
synGet 0 163 573
assign 1 163 574
hasDefaultGet 0 163 574
assign 1 164 576
new 0 164 576
assign 1 164 577
addValue 1 164 577
assign 1 164 578
addValue 1 164 578
assign 1 164 579
new 0 164 579
assign 1 164 580
addValue 1 164 580
addValue 1 164 581
assign 1 170 589
new 0 170 589
assign 1 172 590
keysGet 0 172 590
assign 1 172 591
iteratorGet 0 0 591
assign 1 172 594
hasNextGet 0 172 594
assign 1 172 596
nextGet 0 172 596
assign 1 174 597
new 0 174 597
assign 1 174 598
addValue 1 174 598
assign 1 174 599
new 0 174 599
assign 1 174 600
quoteGet 0 174 600
assign 1 174 601
addValue 1 174 601
assign 1 174 602
addValue 1 174 602
assign 1 174 603
new 0 174 603
assign 1 174 604
quoteGet 0 174 604
assign 1 174 605
addValue 1 174 605
assign 1 174 606
new 0 174 606
assign 1 174 607
addValue 1 174 607
assign 1 174 608
get 1 174 608
assign 1 174 609
addValue 1 174 609
assign 1 174 610
new 0 174 610
assign 1 174 611
addValue 1 174 611
addValue 1 174 612
assign 1 175 613
new 0 175 613
assign 1 175 614
addValue 1 175 614
assign 1 175 615
new 0 175 615
assign 1 175 616
quoteGet 0 175 616
assign 1 175 617
addValue 1 175 617
assign 1 175 618
addValue 1 175 618
assign 1 175 619
new 0 175 619
assign 1 175 620
quoteGet 0 175 620
assign 1 175 621
addValue 1 175 621
assign 1 175 622
new 0 175 622
assign 1 175 623
addValue 1 175 623
assign 1 175 624
get 1 175 624
assign 1 175 625
addValue 1 175 625
assign 1 175 626
new 0 175 626
assign 1 175 627
addValue 1 175 627
addValue 1 175 628
assign 1 179 634
emitChecksGet 0 179 634
assign 1 179 635
new 0 179 635
assign 1 179 636
has 1 179 636
write 1 180 638
assign 1 184 640
usedLibrarysGet 0 184 640
assign 1 184 641
sizeGet 0 184 641
assign 1 184 642
new 0 184 642
assign 1 184 643
equals 1 184 648
assign 1 185 649
new 0 185 649
assign 1 185 650
addValue 1 185 650
addValue 1 185 651
assign 1 186 652
new 0 186 652
assign 1 186 653
addValue 1 186 653
addValue 1 186 654
assign 1 187 655
new 0 187 655
assign 1 187 656
addValue 1 187 656
addValue 1 187 657
write 1 190 659
write 1 191 660
assign 1 194 661
new 0 194 661
assign 1 195 662
mainNameGet 0 195 662
fromString 1 195 663
assign 1 196 664
getClassConfig 1 196 664
assign 1 198 665
new 0 198 665
assign 1 199 666
new 0 199 666
assign 1 199 667
addValue 1 199 667
assign 1 199 668
fullEmitNameGet 0 199 668
assign 1 199 669
addValue 1 199 669
assign 1 199 670
new 0 199 670
assign 1 199 671
addValue 1 199 671
addValue 1 199 672
assign 1 200 673
ownProcessGet 0 200 673
assign 1 201 675
emitChecksGet 0 201 675
assign 1 201 676
new 0 201 676
assign 1 201 677
has 1 201 677
assign 1 202 679
new 0 202 679
assign 1 202 680
addValue 1 202 680
addValue 1 202 681
assign 1 205 684
new 0 205 684
assign 1 205 685
addValue 1 205 685
assign 1 205 686
outputPlatformGet 0 205 686
assign 1 205 687
nameGet 0 205 687
assign 1 205 688
addValue 1 205 688
assign 1 205 689
new 0 205 689
assign 1 205 690
addValue 1 205 690
addValue 1 205 691
assign 1 206 692
doMainGet 0 206 692
write 1 207 694
assign 1 209 696
new 0 209 696
write 1 210 697
write 1 211 698
assign 1 212 699
ownProcessGet 0 212 699
assign 1 213 701
new 0 213 701
assign 1 213 702
addValue 1 213 702
addValue 1 213 703
assign 1 214 704
new 0 214 704
assign 1 214 705
addValue 1 214 705
addValue 1 214 706
assign 1 216 708
doMainGet 0 216 708
write 1 217 710
finishLibOutput 1 220 712
assign 1 222 713
saveSynsGet 0 222 713
saveSyns 0 223 715
assign 1 229 725
isPropertyGet 0 229 725
assign 1 232 729
isArgGet 0 232 729
assign 1 232 730
not 0 232 735
assign 1 233 736
new 0 233 736
addValue 1 233 737
assign 1 235 739
nameForVar 1 235 739
addValue 1 235 740
assign 1 240 746
new 0 240 746
return 1 240 747
assign 1 244 755
new 0 244 755
assign 1 244 756
add 1 244 756
assign 1 244 757
new 0 244 757
assign 1 244 758
add 1 244 758
assign 1 244 759
add 1 244 759
return 1 244 760
assign 1 248 764
new 0 248 764
return 1 248 765
assign 1 252 779
emitNameGet 0 252 779
assign 1 252 780
new 0 252 780
assign 1 252 781
add 1 252 781
assign 1 252 782
add 1 252 782
assign 1 252 783
new 0 252 783
assign 1 252 784
add 1 252 784
assign 1 252 785
addValue 1 252 785
assign 1 253 786
emitNameGet 0 253 786
assign 1 253 787
add 1 253 787
assign 1 253 788
new 0 253 788
assign 1 253 789
add 1 253 789
assign 1 253 790
addValue 1 253 790
return 1 254 791
assign 1 258 805
new 0 258 805
assign 1 258 806
libNameGet 0 258 806
assign 1 258 807
relEmitName 1 258 807
assign 1 258 808
add 1 258 808
assign 1 258 809
new 0 258 809
assign 1 258 810
add 1 258 810
assign 1 258 811
heldGet 0 258 811
assign 1 258 812
literalValueGet 0 258 812
assign 1 258 813
add 1 258 813
assign 1 258 814
new 0 258 814
assign 1 258 815
add 1 258 815
return 1 258 816
assign 1 262 830
new 0 262 830
assign 1 262 831
libNameGet 0 262 831
assign 1 262 832
relEmitName 1 262 832
assign 1 262 833
add 1 262 833
assign 1 262 834
new 0 262 834
assign 1 262 835
add 1 262 835
assign 1 262 836
heldGet 0 262 836
assign 1 262 837
literalValueGet 0 262 837
assign 1 262 838
add 1 262 838
assign 1 262 839
new 0 262 839
assign 1 262 840
add 1 262 840
return 1 262 841
assign 1 267 877
new 0 267 877
assign 1 267 878
libNameGet 0 267 878
assign 1 267 879
relEmitName 1 267 879
assign 1 267 880
add 1 267 880
assign 1 267 881
new 0 267 881
assign 1 267 882
add 1 267 882
assign 1 267 883
emitNameGet 0 267 883
assign 1 267 884
add 1 267 884
assign 1 267 885
new 0 267 885
assign 1 267 886
add 1 267 886
assign 1 267 887
add 1 267 887
assign 1 267 888
new 0 267 888
assign 1 267 889
add 1 267 889
assign 1 267 890
add 1 267 890
assign 1 267 891
new 0 267 891
assign 1 267 892
add 1 267 892
return 1 267 893
assign 1 269 895
new 0 269 895
assign 1 269 896
libNameGet 0 269 896
assign 1 269 897
relEmitName 1 269 897
assign 1 269 898
add 1 269 898
assign 1 269 899
new 0 269 899
assign 1 269 900
add 1 269 900
assign 1 269 901
emitNameGet 0 269 901
assign 1 269 902
add 1 269 902
assign 1 269 903
new 0 269 903
assign 1 269 904
add 1 269 904
assign 1 269 905
add 1 269 905
assign 1 269 906
new 0 269 906
assign 1 269 907
add 1 269 907
assign 1 269 908
add 1 269 908
assign 1 269 909
new 0 269 909
assign 1 269 910
add 1 269 910
return 1 269 911
assign 1 273 926
def 1 273 931
assign 1 274 932
libNameGet 0 274 932
assign 1 274 933
relEmitName 1 274 933
assign 1 274 934
extend 1 274 934
assign 1 276 937
new 0 276 937
assign 1 276 938
extend 1 276 938
assign 1 278 940
new 0 278 940
assign 1 278 941
emitNameGet 0 278 941
assign 1 278 942
addValue 1 278 942
assign 1 278 943
new 0 278 943
assign 1 278 944
addValue 1 278 944
assign 1 286 945
new 0 286 945
assign 1 286 946
addValue 1 286 946
addValue 1 286 947
addValue 1 287 948
return 1 288 949
assign 1 292 978
heldGet 0 292 978
assign 1 292 979
superCallGet 0 292 979
assign 1 293 981
new 0 293 981
assign 1 293 982
notEmpty 1 293 982
assign 1 294 984
new 0 294 984
assign 1 294 985
add 1 294 985
assign 1 296 988
new 0 296 988
assign 1 298 990
emitNameGet 0 298 990
assign 1 298 991
new 0 298 991
assign 1 298 992
add 1 298 992
assign 1 298 993
heldGet 0 298 993
assign 1 298 994
nameGet 0 298 994
assign 1 298 995
add 1 298 995
assign 1 298 996
new 0 298 996
assign 1 298 997
add 1 298 997
assign 1 298 998
add 1 298 998
assign 1 298 999
new 0 298 999
assign 1 298 1000
add 1 298 1000
return 1 298 1001
assign 1 300 1003
new 0 300 1003
assign 1 300 1004
add 1 300 1004
assign 1 300 1005
heldGet 0 300 1005
assign 1 300 1006
nameGet 0 300 1006
assign 1 300 1007
add 1 300 1007
assign 1 300 1008
new 0 300 1008
assign 1 300 1009
add 1 300 1009
assign 1 300 1010
add 1 300 1010
assign 1 300 1011
new 0 300 1011
assign 1 300 1012
add 1 300 1012
return 1 300 1013
assign 1 304 1017
new 0 304 1017
return 1 305 1018
assign 1 312 1023
undef 1 312 1028
assign 1 313 1029
new 0 313 1029
addValue 1 315 1031
assign 1 316 1032
new 0 316 1032
return 1 316 1033
assign 1 321 1037
getLibOutput 0 321 1037
return 1 321 1038
assign 1 329 1069
undef 1 329 1074
assign 1 330 1075
new 0 330 1075
assign 1 331 1076
parentGet 0 331 1076
assign 1 331 1077
fileGet 0 331 1077
assign 1 331 1078
existsGet 0 331 1078
assign 1 331 1079
not 0 331 1084
assign 1 332 1085
parentGet 0 332 1085
assign 1 332 1086
fileGet 0 332 1086
makeDirs 0 332 1087
assign 1 334 1089
fileGet 0 334 1089
assign 1 334 1090
writerGet 0 334 1090
assign 1 334 1091
open 0 334 1091
assign 1 336 1092
paramsGet 0 336 1092
assign 1 336 1093
new 0 336 1093
assign 1 336 1094
has 1 336 1094
assign 1 337 1096
paramsGet 0 337 1096
assign 1 337 1097
new 0 337 1097
assign 1 337 1098
get 1 337 1098
assign 1 337 1099
iteratorGet 0 0 1099
assign 1 337 1102
hasNextGet 0 337 1102
assign 1 337 1104
nextGet 0 337 1104
assign 1 338 1105
apNew 1 338 1105
assign 1 338 1106
fileGet 0 338 1106
assign 1 339 1107
readerGet 0 339 1107
assign 1 339 1108
open 0 339 1108
assign 1 339 1109
readString 0 339 1109
assign 1 340 1110
readerGet 0 340 1110
close 0 340 1111
assign 1 341 1112
countLines 1 341 1112
addValue 1 341 1113
write 1 342 1114
return 1 348 1122
close 0 352 1125
assign 1 353 1126
assign 1 358 1131
new 0 358 1131
return 1 358 1132
assign 1 362 1136
new 0 362 1136
return 1 362 1137
assign 1 366 1141
new 0 366 1141
return 1 366 1142
assign 1 370 1146
new 0 370 1146
return 1 370 1147
assign 1 374 1151
new 0 374 1151
return 1 374 1152
assign 1 378 1156
new 0 378 1156
return 1 378 1157
assign 1 382 1161
new 0 382 1161
return 1 382 1162
assign 1 387 1166
new 0 387 1166
return 1 387 1167
assign 1 393 1171
new 0 393 1171
return 1 393 1172
assign 1 398 1176
new 0 398 1176
return 1 398 1177
assign 1 402 1185
new 0 402 1185
assign 1 402 1186
add 1 402 1186
assign 1 402 1187
new 0 402 1187
assign 1 402 1188
add 1 402 1188
assign 1 402 1189
add 1 402 1189
return 1 402 1190
assign 1 406 1194
new 0 406 1194
return 1 406 1195
assign 1 410 1202
libNameGet 0 410 1202
assign 1 410 1203
relEmitName 1 410 1203
assign 1 410 1204
new 0 410 1204
assign 1 410 1205
add 1 410 1205
return 1 410 1206
assign 1 415 1215
emitNameGet 0 415 1215
assign 1 415 1216
new 0 415 1216
assign 1 415 1217
add 1 415 1217
assign 1 415 1218
new 0 415 1218
assign 1 415 1219
add 1 415 1219
assign 1 415 1220
add 1 415 1220
return 1 415 1221
assign 1 420 1232
emitNameGet 0 420 1232
assign 1 420 1233
addValue 1 420 1233
assign 1 420 1234
new 0 420 1234
assign 1 420 1235
addValue 1 420 1235
assign 1 420 1236
addValue 1 420 1236
assign 1 420 1237
new 0 420 1237
addValue 1 420 1238
addValue 1 422 1239
assign 1 424 1240
new 0 424 1240
assign 1 424 1241
addValue 1 424 1241
addValue 1 424 1242
assign 1 429 1247
new 0 429 1247
return 1 429 1248
assign 1 433 1252
new 0 433 1252
return 1 433 1253
assign 1 437 1259
new 0 437 1259
assign 1 437 1260
add 1 437 1260
assign 1 437 1261
add 1 437 1261
return 1 437 1262
assign 1 442 1266
new 0 442 1266
return 1 442 1267
assign 1 446 1272
getClassConfig 1 446 1272
assign 1 447 1273
fullEmitNameGet 0 447 1273
emitNameSet 1 447 1274
return 1 448 1275
assign 1 452 1280
getLocalClassConfig 1 452 1280
assign 1 453 1281
fullEmitNameGet 0 453 1281
emitNameSet 1 453 1282
return 1 454 1283
return 1 0 1286
return 1 0 1289
assign 1 0 1292
assign 1 0 1296
return 1 0 1300
return 1 0 1303
assign 1 0 1306
assign 1 0 1310
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1969604454: return bem_callNamesGetDirect_0();
case -1637839643: return bem_inClassGetDirect_0();
case -912803270: return bem_classEndGet_0();
case -386052546: return bem_exceptDecGetDirect_0();
case 948518727: return bem_stringNpGet_0();
case 1971058317: return bem_nativeCSlotsGet_0();
case 1809649307: return bem_idToNamePathGet_0();
case -689047135: return bem_allOnceDecsGetDirect_0();
case 1083436236: return bem_objectNpGet_0();
case -1300094822: return bem_inFilePathedGetDirect_0();
case 1450035582: return bem_methodsGetDirect_0();
case 2132601301: return bem_invpGet_0();
case 1917496171: return bem_lastMethodBodySizeGet_0();
case -1430436192: return bem_useDynMethodsGet_0();
case -1818070066: return bem_cnodeGetDirect_0();
case 1370265048: return bem_saveSyns_0();
case -1451034946: return bem_superNameGet_0();
case -789198713: return bem_onceCountGet_0();
case -935033433: return bem_endNs_0();
case -1685440763: return bem_mainOutsideNsGet_0();
case -2028023310: return bem_trueValueGet_0();
case 121407334: return bem_cnodeGet_0();
case -749268313: return bem_copy_0();
case -1860705821: return bem_superCallsGet_0();
case 2010634137: return bem_ccMethodsGet_0();
case -1044648449: return bem_objectCcGetDirect_0();
case 1740052186: return bem_lastMethodsLinesGetDirect_0();
case -1876482568: return bem_nlGetDirect_0();
case 612962573: return bem_emitLib_0();
case 422910836: return bem_inClassGet_0();
case -2070540803: return bem_shlibeGetDirect_0();
case -2087827301: return bem_propDecGet_0();
case 956494617: return bem_idToNameGetDirect_0();
case 917921435: return bem_callNamesGet_0();
case -1282347902: return bem_beginNs_0();
case -136412141: return bem_onceCountGetDirect_0();
case 39411085: return bem_loadIds_0();
case -1980459999: return bem_maxSpillArgsLenGet_0();
case -562818490: return bem_nameToIdGetDirect_0();
case 119658054: return bem_lastMethodsSizeGetDirect_0();
case 1669711039: return bem_parentConfGet_0();
case 1775353836: return bem_intNpGet_0();
case -786565425: return bem_belslitsGet_0();
case -1052123004: return bem_mainInClassGet_0();
case 1315725661: return bem_hashGet_0();
case -1348885338: return bem_boolTypeGet_0();
case 677825267: return bem_ntypesGet_0();
case -596582204: return bem_lastCallGet_0();
case -327712425: return bem_many_0();
case -1410413832: return bem_buildGet_0();
case 1750910669: return bem_methodsGet_0();
case -951781789: return bem_allOnceDecsGet_0();
case 2011985567: return bem_floatNpGetDirect_0();
case 469568784: return bem_intNpGetDirect_0();
case -902820576: return bem_baseSmtdDecGet_0();
case -1191697641: return bem_afterCast_0();
case -646337408: return bem_mainStartGet_0();
case -1763113728: return bem_invpGetDirect_0();
case -591645166: return bem_libEmitPathGet_0();
case 984157156: return bem_mnodeGetDirect_0();
case -1035422061: return bem_falseValueGetDirect_0();
case 1798707911: return bem_buildCreate_0();
case 721806043: return bem_fileExtGetDirect_0();
case 2028992099: return bem_csynGet_0();
case 745729454: return bem_lastCallGetDirect_0();
case -1093980782: return bem_onceDecsGet_0();
case 1576193834: return bem_methodBodyGet_0();
case 2100382565: return bem_returnTypeGet_0();
case -1955257620: return bem_classesInDepthOrderGetDirect_0();
case 731216684: return bem_classConfGet_0();
case 1329768768: return bem_instanceEqualGetDirect_0();
case -348800210: return bem_covariantReturnsGet_0();
case -2048787745: return bem_trueValueGetDirect_0();
case 895934907: return bem_scvpGetDirect_0();
case -773712305: return bem_methodCatchGetDirect_0();
case -341413108: return bem_classCallsGet_0();
case 1210407094: return bem_tagGet_0();
case -1246237727: return bem_buildGetDirect_0();
case 1330167320: return bem_ntypesGetDirect_0();
case -479412451: return bem_iteratorGet_0();
case 650051570: return bem_libEmitPathGetDirect_0();
case 11195513: return bem_nameToIdGet_0();
case -1959899288: return bem_fieldIteratorGet_0();
case 1992822379: return bem_libEmitNameGetDirect_0();
case -1915666683: return bem_serializationIteratorGet_0();
case 258738191: return bem_smnlecsGet_0();
case 1717209835: return bem_typeDecGet_0();
case 1590977739: return bem_getLibOutput_0();
case 1266951796: return bem_onceDecsGetDirect_0();
case -2003369309: return bem_instanceNotEqualGetDirect_0();
case 132098331: return bem_ccMethodsGetDirect_0();
case -1076647907: return bem_objectCcGet_0();
case -899256741: return bem_toString_0();
case 2041568983: return bem_synEmitPathGetDirect_0();
case -798243009: return bem_lastMethodBodySizeGetDirect_0();
case 368891858: return bem_objectNpGetDirect_0();
case 1339285569: return bem_getClassOutput_0();
case -1546511776: return bem_inFilePathedGet_0();
case 1111491882: return bem_maxDynArgsGet_0();
case 332908802: return bem_boolNpGetDirect_0();
case -344688418: return bem_new_0();
case -1619704758: return bem_instanceNotEqualGet_0();
case -1095649894: return bem_floatNpGet_0();
case -888775498: return bem_baseMtdDecGet_0();
case -707072834: return bem_writeBET_0();
case 1083920187: return bem_lastMethodBodyLinesGet_0();
case -1031740093: return bem_smnlecsGetDirect_0();
case -1716768196: return bem_nameToIdPathGetDirect_0();
case -1749862516: return bem_classEmitsGetDirect_0();
case -1847215371: return bem_libEmitNameGet_0();
case -960306135: return bem_instOfGet_0();
case -1788728356: return bem_maxDynArgsGetDirect_0();
case -1945570638: return bem_once_0();
case 1287927608: return bem_stringNpGetDirect_0();
case 1118639566: return bem_classConfGetDirect_0();
case 460274340: return bem_emitLangGet_0();
case 1770856681: return bem_mnodeGet_0();
case -662034100: return bem_ccCacheGet_0();
case 1343149164: return bem_transGet_0();
case 561590064: return bem_belslitsGetDirect_0();
case -553928998: return bem_emitLangGetDirect_0();
case 315628849: return bem_fileExtGet_0();
case 1752879167: return bem_falseValueGet_0();
case 148775221: return bem_boolCcGet_0();
case -1759042987: return bem_overrideMtdDecGet_0();
case -2073649024: return bem_ccCacheGetDirect_0();
case -234918246: return bem_lastMethodsSizeGet_0();
case 1427063425: return bem_saveIds_0();
case 440180185: return bem_dynMethodsGet_0();
case -860055411: return bem_randGetDirect_0();
case 770986263: return bem_create_0();
case 213317222: return bem_lineCountGetDirect_0();
case 1779956294: return bem_doEmit_0();
case -973449612: return bem_nlGet_0();
case -138888560: return bem_propertyDecsGetDirect_0();
case -1081673073: return bem_propertyDecsGet_0();
case 1398725901: return bem_returnTypeGetDirect_0();
case 1663268657: return bem_transGetDirect_0();
case -416929304: return bem_runtimeInitGet_0();
case 2115142410: return bem_idToNameGet_0();
case 1493249064: return bem_classCallsGetDirect_0();
case 1935668627: return bem_nameToIdPathGet_0();
case 826167413: return bem_classNameGet_0();
case 682602080: return bem_methodBodyGetDirect_0();
case -368484819: return bem_instOfGetDirect_0();
case 303124279: return bem_boolCcGetDirect_0();
case 1270756764: return bem_print_0();
case 1368754023: return bem_initialDecGet_0();
case -1700363251: return bem_instanceEqualGet_0();
case -2058722475: return bem_gcMarksGet_0();
case -649047169: return bem_methodCallsGet_0();
case 1293575145: return bem_serializeToString_0();
case -1585347304: return bem_smnlcsGetDirect_0();
case 1297575371: return bem_superCallsGetDirect_0();
case -1841712225: return bem_fullLibEmitNameGetDirect_0();
case 134346913: return bem_gcMarksGetDirect_0();
case 1535025726: return bem_classEmitsGet_0();
case -1567267076: return bem_preClassOutput_0();
case 113054095: return bem_methodCallsGetDirect_0();
case -144040905: return bem_preClassGet_0();
case 137217213: return bem_msynGet_0();
case -1514184278: return bem_serializeContents_0();
case 1437548456: return bem_randGet_0();
case -1683929966: return bem_csynGetDirect_0();
case -1816288531: return bem_nativeCSlotsGetDirect_0();
case 1227972027: return bem_lineCountGet_0();
case 101000662: return bem_smnlcsGet_0();
case 818210964: return bem_toAny_0();
case -1390679260: return bem_idToNamePathGetDirect_0();
case -351578543: return bem_lastMethodsLinesGet_0();
case -2049421246: return bem_lastMethodBodyLinesGetDirect_0();
case -1867021247: return bem_scvpGet_0();
case 493954790: return bem_boolNpGet_0();
case -1682809495: return bem_buildPropList_0();
case -1554815440: return bem_nullValueGetDirect_0();
case 1625524123: return bem_classesInDepthOrderGet_0();
case -407687427: return bem_fieldNamesGet_0();
case -2101389791: return bem_fullLibEmitNameGet_0();
case -289001193: return bem_qGetDirect_0();
case -1299412523: return bem_synEmitPathGet_0();
case -1633185336: return bem_parentConfGetDirect_0();
case -1717298627: return bem_mainEndGet_0();
case -1064393581: return bem_nullValueGet_0();
case 578815402: return bem_buildClassInfo_0();
case 1707206314: return bem_shlibeGet_0();
case -1825453622: return bem_buildInitial_0();
case -1415427946: return bem_maxSpillArgsLenGetDirect_0();
case 1616406375: return bem_newDecGet_0();
case 2051242674: return bem_spropDecGet_0();
case 1124007611: return bem_exceptDecGet_0();
case 1931952556: return bem_constGetDirect_0();
case 1495444611: return bem_methodCatchGet_0();
case 887254713: return bem_sourceFileNameGet_0();
case 846353007: return bem_echo_0();
case 1519034973: return bem_msynGetDirect_0();
case 1389023665: return bem_preClassGetDirect_0();
case -974462353: return bem_qGet_0();
case 1354170537: return bem_constGet_0();
case -519581463: return bem_deserializeClassNameGet_0();
case 1539132569: return bem_dynMethodsGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1536585966: return bem_instOfSetDirect_1(bevd_0);
case -667039424: return bem_methodBodySet_1(bevd_0);
case 1964175011: return bem_scvpSetDirect_1(bevd_0);
case 834541411: return bem_synEmitPathSetDirect_1(bevd_0);
case 1127066091: return bem_nlSetDirect_1(bevd_0);
case 1802904852: return bem_objectNpSetDirect_1(bevd_0);
case 956088803: return bem_dynMethodsSetDirect_1(bevd_0);
case 414625357: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1688265146: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1090778852: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1377088318: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1974846291: return bem_instanceNotEqualSet_1(bevd_0);
case 1220423193: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 342551081: return bem_smnlcsSet_1(bevd_0);
case -934713398: return bem_invpSet_1(bevd_0);
case 1498542947: return bem_classEmitsSetDirect_1(bevd_0);
case 1034375114: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -158099869: return bem_belslitsSetDirect_1(bevd_0);
case -1722081057: return bem_classConfSetDirect_1(bevd_0);
case -875424038: return bem_objectCcSetDirect_1(bevd_0);
case -1243968796: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1610333594: return bem_exceptDecSet_1(bevd_0);
case -990587255: return bem_callNamesSet_1(bevd_0);
case 788752676: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 741539113: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1485324187: return bem_methodsSetDirect_1(bevd_0);
case -1784044149: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1002852037: return bem_objectCcSet_1(bevd_0);
case 166544837: return bem_emitLangSet_1(bevd_0);
case 1085832775: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -1970665504: return bem_end_1(bevd_0);
case 40922571: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -752339634: return bem_constSetDirect_1(bevd_0);
case 1839182536: return bem_shlibeSet_1(bevd_0);
case -594286356: return bem_trueValueSet_1(bevd_0);
case -1034315711: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -1788808419: return bem_dynMethodsSet_1(bevd_0);
case -216150516: return bem_nameToIdSetDirect_1(bevd_0);
case 1507799793: return bem_intNpSet_1(bevd_0);
case 348253120: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1633084256: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1057460468: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1048942771: return bem_boolCcSet_1(bevd_0);
case 1946977825: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -913868488: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 234339060: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 634930460: return bem_ccCacheSet_1(bevd_0);
case -187827898: return bem_mnodeSet_1(bevd_0);
case 1614720436: return bem_fileExtSetDirect_1(bevd_0);
case 507472797: return bem_boolNpSetDirect_1(bevd_0);
case -1562540726: return bem_stringNpSet_1(bevd_0);
case -2111127162: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1731351346: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1045944660: return bem_ntypesSetDirect_1(bevd_0);
case 409706205: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -394065538: return bem_classesInDepthOrderSet_1(bevd_0);
case 564857323: return bem_methodBodySetDirect_1(bevd_0);
case -103276923: return bem_lastMethodsLinesSet_1(bevd_0);
case -1427377022: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -924930765: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1054691051: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 763395528: return bem_trueValueSetDirect_1(bevd_0);
case -279995727: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1621465876: return bem_fileExtSet_1(bevd_0);
case 208531053: return bem_nativeCSlotsSet_1(bevd_0);
case -367472235: return bem_falseValueSetDirect_1(bevd_0);
case -688432372: return bem_onceCountSetDirect_1(bevd_0);
case 1017678313: return bem_propertyDecsSetDirect_1(bevd_0);
case 724212780: return bem_objectNpSet_1(bevd_0);
case -1909342458: return bem_stringNpSetDirect_1(bevd_0);
case -1510261794: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 923274404: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1940378678: return bem_methodCallsSet_1(bevd_0);
case 1027249635: return bem_classConfSet_1(bevd_0);
case -1937148574: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 802025336: return bem_cnodeSet_1(bevd_0);
case 1043238249: return bem_msynSetDirect_1(bevd_0);
case 248598654: return bem_copyTo_1(bevd_0);
case -128283774: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 509252275: return bem_sameObject_1(bevd_0);
case 1517312046: return bem_classCallsSet_1(bevd_0);
case 1760923582: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1343727458: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 628301677: return bem_onceDecsSetDirect_1(bevd_0);
case 596616152: return bem_randSet_1(bevd_0);
case -1907646468: return bem_qSetDirect_1(bevd_0);
case -1483751473: return bem_lineCountSet_1(bevd_0);
case 230609230: return bem_nullValueSetDirect_1(bevd_0);
case 1498119962: return bem_sameType_1(bevd_0);
case -1430104073: return bem_fullLibEmitNameSet_1(bevd_0);
case 556999369: return bem_inFilePathedSetDirect_1(bevd_0);
case 179880581: return bem_returnTypeSetDirect_1(bevd_0);
case -77548659: return bem_instanceEqualSet_1(bevd_0);
case -1548523977: return bem_otherClass_1(bevd_0);
case -515726044: return bem_csynSetDirect_1(bevd_0);
case 960936928: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1055523105: return bem_nameToIdSet_1(bevd_0);
case -1769875500: return bem_methodCatchSet_1(bevd_0);
case 1457582181: return bem_ccCacheSetDirect_1(bevd_0);
case -2139480443: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1649196212: return bem_invpSetDirect_1(bevd_0);
case 1075914707: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1374916281: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 887626992: return bem_instanceEqualSetDirect_1(bevd_0);
case -1468949165: return bem_undefined_1(bevd_0);
case -1197074474: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 394500228: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1715370141: return bem_sameClass_1(bevd_0);
case 241303836: return bem_inClassSet_1(bevd_0);
case -910291317: return bem_propertyDecsSet_1(bevd_0);
case 998304479: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 2095947770: return bem_constSet_1(bevd_0);
case 767988071: return bem_boolCcSetDirect_1(bevd_0);
case 1869153082: return bem_superCallsSetDirect_1(bevd_0);
case 1772678539: return bem_notEquals_1(bevd_0);
case -1282921091: return bem_idToNamePathSetDirect_1(bevd_0);
case -1152700367: return bem_falseValueSet_1(bevd_0);
case 888889501: return bem_maxDynArgsSetDirect_1(bevd_0);
case 12945579: return bem_maxDynArgsSet_1(bevd_0);
case 1814008335: return bem_exceptDecSetDirect_1(bevd_0);
case -2052607293: return bem_inFilePathedSet_1(bevd_0);
case 598193677: return bem_synEmitPathSet_1(bevd_0);
case 383743189: return bem_classEmitsSet_1(bevd_0);
case -1740522708: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 580498953: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -144455154: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1383464152: return bem_libEmitNameSet_1(bevd_0);
case 1036278317: return bem_gcMarksSet_1(bevd_0);
case -1039687401: return bem_superCallsSet_1(bevd_0);
case -777436964: return bem_nlSet_1(bevd_0);
case 599863498: return bem_ntypesSet_1(bevd_0);
case 1698689524: return bem_smnlcsSetDirect_1(bevd_0);
case 529180681: return bem_callNamesSetDirect_1(bevd_0);
case -2057921493: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1502400977: return bem_cnodeSetDirect_1(bevd_0);
case 1672089534: return bem_classCallsSetDirect_1(bevd_0);
case -1413490011: return bem_begin_1(bevd_0);
case 408978476: return bem_boolNpSet_1(bevd_0);
case -1180745163: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 522405687: return bem_gcMarksSetDirect_1(bevd_0);
case -1626794259: return bem_msynSet_1(bevd_0);
case -933197867: return bem_allOnceDecsSetDirect_1(bevd_0);
case -10918310: return bem_buildSetDirect_1(bevd_0);
case -1836699406: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1465163042: return bem_idToNameSet_1(bevd_0);
case 1477732575: return bem_otherType_1(bevd_0);
case -1325891187: return bem_parentConfSet_1(bevd_0);
case 991387547: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1919170023: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1484842354: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -375809001: return bem_scvpSet_1(bevd_0);
case 1717769471: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1349966853: return bem_nameToIdPathSet_1(bevd_0);
case -1640699176: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1236344224: return bem_onceDecsSet_1(bevd_0);
case 1282189525: return bem_inClassSetDirect_1(bevd_0);
case 43760314: return bem_emitLangSetDirect_1(bevd_0);
case -1482818195: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 118750095: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1113001280: return bem_parentConfSetDirect_1(bevd_0);
case 354029452: return bem_smnlecsSet_1(bevd_0);
case 1146144569: return bem_allOnceDecsSet_1(bevd_0);
case -1194196335: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1841026463: return bem_libEmitPathSetDirect_1(bevd_0);
case 1281030097: return bem_belslitsSet_1(bevd_0);
case 856923036: return bem_returnTypeSet_1(bevd_0);
case -1592253335: return bem_buildSet_1(bevd_0);
case 271197902: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1593118039: return bem_preClassSet_1(bevd_0);
case 597710655: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 2140743737: return bem_randSetDirect_1(bevd_0);
case 2011695784: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -597164057: return bem_defined_1(bevd_0);
case 1126707353: return bem_ccMethodsSet_1(bevd_0);
case 1723885611: return bem_shlibeSetDirect_1(bevd_0);
case -1822447376: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 431401523: return bem_mnodeSetDirect_1(bevd_0);
case 528127878: return bem_smnlecsSetDirect_1(bevd_0);
case 1157250016: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -233300707: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1348989902: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -321293992: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 49512060: return bem_libEmitNameSetDirect_1(bevd_0);
case -1369020344: return bem_methodsSet_1(bevd_0);
case 1630803667: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1672345420: return bem_onceCountSet_1(bevd_0);
case -1763436370: return bem_libEmitPathSet_1(bevd_0);
case -2057726918: return bem_csynSet_1(bevd_0);
case 211017650: return bem_instOfSet_1(bevd_0);
case -751487220: return bem_intNpSetDirect_1(bevd_0);
case 1023617040: return bem_idToNameSetDirect_1(bevd_0);
case 468550430: return bem_preClassSetDirect_1(bevd_0);
case 469600663: return bem_methodCatchSetDirect_1(bevd_0);
case 102142594: return bem_transSetDirect_1(bevd_0);
case 2144395088: return bem_undef_1(bevd_0);
case 922676668: return bem_lastMethodsSizeSet_1(bevd_0);
case -541032329: return bem_lineCountSetDirect_1(bevd_0);
case 1074879219: return bem_nullValueSet_1(bevd_0);
case -827709547: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 366496905: return bem_transSet_1(bevd_0);
case 2133339704: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1782751431: return bem_floatNpSet_1(bevd_0);
case 1411022892: return bem_qSet_1(bevd_0);
case 997331927: return bem_equals_1(bevd_0);
case 1484773619: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 117670797: return bem_floatNpSetDirect_1(bevd_0);
case 315625869: return bem_methodCallsSetDirect_1(bevd_0);
case 836094860: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1727629827: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 784918995: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -275416077: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 209060037: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 332555430: return bem_idToNamePathSet_1(bevd_0);
case -1903990871: return bem_lastCallSetDirect_1(bevd_0);
case -90524252: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1901754655: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 509956737: return bem_def_1(bevd_0);
case -1762085218: return bem_ccMethodsSetDirect_1(bevd_0);
case 60591368: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1551136610: return bem_lastCallSet_1(bevd_0);
case 699500156: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1565896048: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -455603186: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1851956888: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -403771483: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -934996763: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1056232156: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 262774206: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 878305058: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1342782288: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1189130153: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1342432900: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1259073355: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -390764901: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1675736992: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2108178039: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1792789064: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -319997805: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 641804903: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -420972082: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 2135621487: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -1375474502: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 100760982: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1932992669: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -468002221: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1971272332: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 206133853: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 306138076: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1318975137: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 710300293: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
