package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x6A,0x73,0x53,0x74,0x72,0x49,0x6E,0x6C,0x69,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x5D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x65,0x6D,0x62,0x50,0x6C,0x61,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x6E,0x6F,0x63,0x6F,0x70,0x79,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x3A,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x62,0x65,0x76,0x6F,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_82 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_83 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_84 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_85 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildJSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_formTarg_1(beva_node);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_invp);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_7));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_8));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_11));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1840264672);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1018135606);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_14));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_15));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_contains_1(bevt_2_ta_ph);
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 68*/ {
bevt_6_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = beva_sdec.bem_addValue_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_3_ta_ph.bem_addValue_1(bevt_8_ta_ph);
} /* Line: 69*/
 else /* Line: 70*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
beva_sdec.bem_addValue_1(bevt_9_ta_ph);
} /* Line: 71*/
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = beva_sdec.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_belsName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_1_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(548346027);
bevt_9_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_ta_ph );
bevt_12_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_12_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_14_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(337996085);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_5_ta_ph = bevt_6_ta_ph.bem_contains_1(bevt_7_ta_ph);
if (!(bevt_5_ta_ph.bevi_bool))/* Line: 94*/ {
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 96*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 96*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(-747250137);
bevt_9_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_9_ta_ph.bevi_bool))/* Line: 97*/ {
if (bevl_first.bevi_bool)/* Line: 98*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 99*/
 else /* Line: 100*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
} /* Line: 101*/
bevt_13_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 103*/
} /* Line: 97*/
 else /* Line: 96*/ {
break;
} /* Line: 96*/
} /* Line: 96*/
} /* Line: 96*/
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_16_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(548346027);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_13_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevl_stinst);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_20_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_21_ta_ph);
bevt_20_ta_ph.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_contains_1(bevt_2_ta_ph);
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 142*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_3_ta_ph = beva_sdec.bem_addValue_1(bevt_4_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevp_onceDecs.bem_addValue_1(beva_sdec);
} /* Line: 145*/
 else /* Line: 146*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
beva_sdec.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 148*/
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEndCi_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_0_ta_ph = beva_sdec.bem_addValue_1(bevt_1_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevp_onceDecs.bem_addValue_1(beva_sdec);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 160*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_3_ta_ph = beva_v.bem_nameGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 161*/
bevt_4_ta_ph = super.bem_nameForVar_1(beva_v);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_writeBET_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_7_TextStrings bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_7_TextStrings bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_7_TextStrings bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_7_TextStrings bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_5_4_LogicBool bevt_79_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_5_4_LogicBool bevt_100_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_6_6_SystemObject bevt_109_ta_ph = null;
BEC_2_6_6_SystemObject bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_5_4_LogicBool bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_5_4_LogicBool bevt_119_ta_ph = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
/* Line: 177*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 177*/ {
bevl_clnode = bevl_ci.bemd_0(-747250137);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_2_ta_ph = bevt_3_ta_ph.bem_contains_1(bevt_4_ta_ph);
if (!(bevt_2_ta_ph.bevi_bool))/* Line: 181*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevt_11_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_12_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevp_q);
bevt_15_ta_ph = bevl_clnode.bemd_0(-1567145505);
bevt_14_ta_ph = bevt_15_ta_ph.bemd_0(548346027);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(1428575040);
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevp_q);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_20_ta_ph = bevl_clnode.bemd_0(-1567145505);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(548346027);
bevt_18_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_19_ta_ph );
bevt_21_ta_ph = bevp_build.bem_libNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_relEmitName_1(bevt_21_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 182*/
bevt_25_ta_ph = bevl_clnode.bemd_0(-1567145505);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(337996085);
bevt_23_ta_ph = bevt_24_ta_ph.bemd_0(922260933);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 184*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_31_ta_ph = bevl_clnode.bemd_0(-1567145505);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(548346027);
bevt_29_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_30_ta_ph );
bevt_32_ta_ph = bevp_build.bem_libNameGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_relEmitName_1(bevt_32_ta_ph);
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevl_nc = bevt_26_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_36_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevl_nc);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_nl);
bevt_41_ta_ph = bevl_clnode.bemd_0(-1567145505);
bevt_40_ta_ph = bevt_41_ta_ph.bemd_0(337996085);
bevt_39_ta_ph = bevt_40_ta_ph.bemd_0(922260933);
if (((BEC_2_5_4_LogicBool) bevt_39_ta_ph).bevi_bool)/* Line: 193*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_44_ta_ph = bevl_notNullInitDefault.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevl_nc);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 194*/
} /* Line: 193*/
} /* Line: 184*/
 else /* Line: 177*/ {
break;
} /* Line: 177*/
} /* Line: 177*/
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_47_ta_ph = bevp_smnlcs.bem_keysGet_0();
bevt_0_ta_loop = bevt_47_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 202*/ {
bevt_48_ta_ph = bevt_0_ta_loop.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 202*/ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-747250137);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_55_ta_ph = bevl_smap.bem_addValue_1(bevt_56_ta_ph);
bevt_58_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_57_ta_ph = bevt_58_ta_ph.bem_quoteGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevl_smk);
bevt_60_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_59_ta_ph = bevt_60_ta_ph.bem_quoteGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_61_ta_ph);
bevt_62_ta_ph = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_62_ta_ph);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_63_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_71_ta_ph = (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_70_ta_ph = bevl_smap.bem_addValue_1(bevt_71_ta_ph);
bevt_73_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_72_ta_ph = bevt_73_ta_ph.bem_quoteGet_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_addValue_1(bevt_72_ta_ph);
bevt_68_ta_ph = bevt_69_ta_ph.bem_addValue_1(bevl_smk);
bevt_75_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_74_ta_ph = bevt_75_ta_ph.bem_quoteGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bem_addValue_1(bevt_74_ta_ph);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_66_ta_ph = bevt_67_ta_ph.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_65_ta_ph = bevt_66_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_64_ta_ph = bevt_65_ta_ph.bem_addValue_1(bevt_78_ta_ph);
bevt_64_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 205*/
 else /* Line: 202*/ {
break;
} /* Line: 202*/
} /* Line: 202*/
bevt_80_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_81_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_79_ta_ph = bevt_80_ta_ph.bem_contains_1(bevt_81_ta_ph);
if (!(bevt_79_ta_ph.bevi_bool))/* Line: 209*/ {
bevl_libe.bem_write_1(bevl_smap);
} /* Line: 210*/
bevt_84_ta_ph = bevp_build.bem_usedLibrarysGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bem_lengthGet_0();
bevt_85_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_83_ta_ph.bevi_int == bevt_85_ta_ph.bevi_int) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 214*/ {
bevt_87_ta_ph = (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_86_ta_ph = bevl_libInit.bem_addValue_1(bevt_87_ta_ph);
bevt_86_ta_ph.bem_addValue_1(bevp_nl);
bevt_89_ta_ph = (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_88_ta_ph = bevl_libInit.bem_addValue_1(bevt_89_ta_ph);
bevt_88_ta_ph.bem_addValue_1(bevp_nl);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_90_ta_ph = bevl_libInit.bem_addValue_1(bevt_91_ta_ph);
bevt_90_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 217*/
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_92_ta_ph = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_92_ta_ph);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_96_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_95_ta_ph = bevl_main.bem_addValue_1(bevt_96_ta_ph);
bevt_97_ta_ph = bevl_maincc.bem_fullEmitNameGet_0();
bevt_94_ta_ph = bevt_95_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_98_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_93_ta_ph = bevt_94_ta_ph.bem_addValue_1(bevt_98_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_99_ta_ph.bevi_bool)/* Line: 230*/ {
bevt_101_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_102_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_100_ta_ph = bevt_101_ta_ph.bem_contains_1(bevt_102_ta_ph);
if (!(bevt_100_ta_ph.bevi_bool))/* Line: 231*/ {
bevt_104_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_103_ta_ph = bevl_main.bem_addValue_1(bevt_104_ta_ph);
bevt_103_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 232*/
} /* Line: 231*/
bevt_108_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_107_ta_ph = bevl_main.bem_addValue_1(bevt_108_ta_ph);
bevt_110_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_109_ta_ph = bevt_110_ta_ph.bemd_0(956414101);
bevt_106_ta_ph = bevt_107_ta_ph.bem_addValue_1(bevt_109_ta_ph);
bevt_111_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
bevt_105_ta_ph = bevt_106_ta_ph.bem_addValue_1(bevt_111_ta_ph);
bevt_105_ta_ph.bem_addValue_1(bevp_nl);
bevt_112_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_112_ta_ph.bevi_bool)/* Line: 236*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 237*/
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_113_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_113_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_115_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_114_ta_ph = bevl_main.bem_addValue_1(bevt_115_ta_ph);
bevt_114_ta_ph.bem_addValue_1(bevp_nl);
bevt_117_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_116_ta_ph = bevl_main.bem_addValue_1(bevt_117_ta_ph);
bevt_116_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 244*/
bevt_118_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_118_ta_ph.bevi_bool)/* Line: 246*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 247*/
bem_finishLibOutput_1(bevl_libe);
bevt_119_ta_ph = bevp_build.bem_saveSynsGet_0();
if (bevt_119_ta_ph.bevi_bool)/* Line: 252*/ {
bem_saveSyns_0();
} /* Line: 253*/
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 259*/ {
} /* Line: 259*/
 else /* Line: 261*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 262*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
beva_b.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 263*/
bevt_4_ta_ph = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 265*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_exceptDec);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_parent);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
bevl_extstr = bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_7_ta_ph = bevl_extstr.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevl_extstr = bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1261973213);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1261973213);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_contains_1(bevt_2_ta_ph);
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 297*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJSEmitter_bels_67));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_belsName);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_17_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(beva_lisz);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_18_ta_ph);
return bevt_3_ta_ph;
} /* Line: 298*/
 else /* Line: 299*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_27_ta_ph = bevp_build.bem_libNameGet_0();
bevt_26_ta_ph = beva_newcc.bem_relEmitName_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_68));
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(beva_sdec);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(beva_lisz);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_30_ta_ph);
return bevt_19_ta_ph;
} /* Line: 300*/
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 306*/
 else /* Line: 307*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_69));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 308*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
bevt_6_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_8_ta_ph = bevl_begin.bem_addValue_1(bevt_9_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1591902873);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 324*/ {
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(beva_callArgs);
if (bevt_2_ta_ph.bevi_bool)/* Line: 325*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_71));
beva_callArgs = bevt_4_ta_ph.bem_add_1(beva_callArgs);
} /* Line: 326*/
 else /* Line: 327*/ {
beva_callArgs = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
} /* Line: 328*/
bevt_10_ta_ph = bevp_parentConf.bem_emitNameGet_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(956414101);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_73));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_callArgs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_5_ta_ph;
} /* Line: 330*/
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_74));
bevt_20_ta_ph = beva_callTarget.bem_add_1(bevt_21_ta_ph);
bevt_23_ta_ph = beva_node.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(956414101);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_75));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_callArgs);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_25_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_allOnceDecs == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 344*/ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 345*/
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getLibOutput_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_13_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
if (bevp_shlibe == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 361*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 363*/ {
bevt_7_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 364*/
bevt_9_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_ta_ph.bemd_0(1215053353);
bevt_11_ta_ph = bevp_build.bem_paramsGet_0();
bevt_12_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_10_ta_ph = bevt_11_ta_ph.bem_contains_1(bevt_12_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 368*/ {
bevt_14_ta_ph = bevp_build.bem_paramsGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_13_ta_ph = bevt_14_ta_ph.bem_get_1(bevt_15_ta_ph);
bevt_0_ta_loop = bevt_13_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 369*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 369*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-747250137);
bevt_17_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1215053353);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_ta_ph.bemd_0(209236659);
bevt_20_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph.bemd_0(-1192792371);
bevt_21_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 374*/
 else /* Line: 369*/ {
break;
} /* Line: 369*/
} /* Line: 369*/
} /* Line: 369*/
} /* Line: 368*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_77));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_78));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_anyName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_typeName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = beva_newcc.bem_relEmitName_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_80));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_81));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_count);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_methods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_82));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_83));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_ta_ph = bevp_methods.bem_addValue_1(bevt_7_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_84));
bevt_1_ta_ph = beva_nameSpace.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_emitName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_85));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {22, 23, 24, 28, 30, 31, 33, 34, 38, 38, 38, 42, 42, 42, 42, 46, 46, 46, 46, 50, 50, 50, 50, 50, 50, 50, 50, 54, 54, 54, 55, 56, 56, 56, 56, 56, 56, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 68, 68, 68, 69, 69, 69, 69, 69, 69, 69, 71, 71, 77, 77, 77, 77, 77, 77, 77, 81, 81, 81, 81, 81, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 84, 84, 84, 89, 89, 90, 92, 92, 92, 92, 94, 94, 94, 95, 96, 0, 96, 96, 97, 99, 101, 101, 103, 103, 103, 103, 103, 103, 108, 108, 108, 113, 113, 113, 114, 116, 116, 116, 116, 116, 119, 119, 119, 119, 121, 121, 121, 123, 123, 123, 123, 123, 126, 126, 126, 126, 126, 126, 128, 128, 128, 130, 135, 136, 137, 142, 142, 142, 144, 144, 144, 145, 148, 148, 154, 154, 154, 155, 160, 161, 161, 161, 161, 163, 163, 172, 174, 175, 176, 177, 177, 179, 181, 181, 181, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 184, 184, 184, 186, 186, 186, 186, 186, 186, 186, 186, 186, 192, 192, 192, 192, 192, 192, 193, 193, 193, 194, 194, 194, 194, 194, 194, 200, 202, 202, 0, 202, 202, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 209, 209, 209, 210, 214, 214, 214, 214, 214, 215, 215, 215, 216, 216, 216, 217, 217, 217, 220, 221, 224, 225, 225, 226, 228, 229, 229, 229, 229, 229, 229, 229, 230, 231, 231, 231, 232, 232, 232, 235, 235, 235, 235, 235, 235, 235, 235, 236, 237, 239, 240, 241, 242, 243, 243, 243, 244, 244, 244, 246, 247, 250, 252, 253, 259, 262, 262, 262, 263, 263, 265, 265, 270, 270, 274, 274, 274, 274, 274, 274, 278, 278, 282, 282, 282, 282, 282, 282, 282, 284, 284, 284, 284, 284, 285, 289, 289, 289, 289, 289, 289, 289, 289, 289, 289, 289, 289, 293, 293, 293, 293, 293, 293, 293, 293, 293, 293, 293, 293, 297, 297, 297, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 305, 305, 306, 306, 306, 308, 308, 310, 310, 310, 310, 310, 318, 318, 318, 319, 320, 324, 324, 325, 325, 326, 326, 328, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 336, 337, 344, 344, 345, 347, 348, 348, 353, 353, 361, 361, 362, 363, 363, 363, 363, 363, 364, 364, 364, 366, 366, 366, 368, 368, 368, 369, 369, 369, 369, 0, 369, 369, 370, 370, 371, 371, 371, 372, 372, 373, 373, 374, 380, 384, 385, 390, 390, 394, 394, 398, 398, 402, 402, 406, 406, 410, 410, 414, 414, 419, 419, 425, 425, 430, 430, 434, 434, 434, 434, 434, 434, 438, 438, 438, 438, 438, 443, 443, 443, 443, 443, 443, 443, 448, 448, 448, 448, 448, 448, 448, 450, 452, 452, 452, 457, 457, 461, 461, 465, 465, 465, 465, 470, 470, 474, 475, 475, 476, 480, 481, 481, 482, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {100, 101, 102, 103, 104, 105, 106, 107, 113, 114, 115, 121, 122, 123, 124, 130, 131, 132, 133, 143, 144, 145, 146, 147, 148, 149, 150, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 207, 208, 209, 211, 212, 213, 214, 215, 216, 217, 220, 221, 232, 233, 234, 235, 236, 237, 238, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 313, 314, 314, 317, 319, 320, 323, 326, 327, 329, 330, 331, 332, 333, 334, 342, 343, 344, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 407, 408, 409, 419, 420, 421, 423, 424, 425, 426, 429, 430, 437, 438, 439, 440, 449, 451, 452, 453, 454, 456, 457, 595, 596, 597, 598, 599, 602, 604, 605, 606, 607, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 629, 630, 631, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 652, 653, 654, 655, 656, 657, 665, 666, 667, 667, 670, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 710, 711, 712, 714, 716, 717, 718, 719, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 751, 752, 753, 755, 756, 757, 760, 761, 762, 763, 764, 765, 766, 767, 768, 770, 772, 773, 774, 775, 777, 778, 779, 780, 781, 782, 784, 786, 788, 789, 791, 801, 805, 806, 811, 812, 813, 815, 816, 822, 823, 831, 832, 833, 834, 835, 836, 840, 841, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 951, 952, 953, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 974, 975, 976, 977, 978, 979, 980, 981, 982, 983, 984, 985, 986, 1002, 1007, 1008, 1009, 1010, 1013, 1014, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1054, 1055, 1057, 1058, 1060, 1061, 1064, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1093, 1094, 1099, 1104, 1105, 1107, 1108, 1109, 1113, 1114, 1145, 1150, 1151, 1152, 1153, 1154, 1155, 1160, 1161, 1162, 1163, 1165, 1166, 1167, 1168, 1169, 1170, 1172, 1173, 1174, 1175, 1175, 1178, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1198, 1201, 1202, 1207, 1208, 1212, 1213, 1217, 1218, 1222, 1223, 1227, 1228, 1232, 1233, 1237, 1238, 1242, 1243, 1247, 1248, 1252, 1253, 1261, 1262, 1263, 1264, 1265, 1266, 1273, 1274, 1275, 1276, 1277, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1313, 1318, 1319, 1323, 1324, 1330, 1331, 1332, 1333, 1337, 1338, 1343, 1344, 1345, 1346, 1351, 1352, 1353, 1354, 1357, 1360, 1364, 1367};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 22 100
new 0 22 100
assign 1 23 101
new 0 23 101
assign 1 24 102
new 0 24 102
new 1 28 103
assign 1 30 104
new 0 30 104
assign 1 31 105
new 0 31 105
assign 1 33 106
new 0 33 106
assign 1 34 107
new 0 34 107
assign 1 38 113
formTarg 1 38 113
assign 1 38 114
add 1 38 114
return 1 38 115
assign 1 42 121
formCallTarg 1 42 121
assign 1 42 122
new 0 42 122
assign 1 42 123
add 1 42 123
return 1 42 124
assign 1 46 130
formCallTarg 1 46 130
assign 1 46 131
new 0 46 131
assign 1 46 132
add 1 46 132
return 1 46 133
assign 1 50 143
new 0 50 143
assign 1 50 144
addValue 1 50 144
assign 1 50 145
secondGet 0 50 145
assign 1 50 146
formTarg 1 50 146
assign 1 50 147
addValue 1 50 147
assign 1 50 148
new 0 50 148
assign 1 50 149
addValue 1 50 149
addValue 1 50 150
assign 1 54 171
new 0 54 171
assign 1 54 172
toString 0 54 172
assign 1 54 173
add 1 54 173
incrementValue 0 55 174
assign 1 56 175
new 0 56 175
assign 1 56 176
addValue 1 56 176
assign 1 56 177
addValue 1 56 177
assign 1 56 178
new 0 56 178
assign 1 56 179
addValue 1 56 179
addValue 1 56 180
assign 1 61 181
containedGet 0 61 181
assign 1 61 182
firstGet 0 61 182
assign 1 61 183
containedGet 0 61 183
assign 1 61 184
firstGet 0 61 184
assign 1 61 185
new 0 61 185
assign 1 61 186
add 1 61 186
assign 1 61 187
new 0 61 187
assign 1 61 188
add 1 61 188
assign 1 61 189
finalAssign 4 61 189
addValue 1 61 190
assign 1 68 207
emitChecksGet 0 68 207
assign 1 68 208
new 0 68 208
assign 1 68 209
contains 1 68 209
assign 1 69 211
emitNameGet 0 69 211
assign 1 69 212
addValue 1 69 212
assign 1 69 213
new 0 69 213
assign 1 69 214
addValue 1 69 214
assign 1 69 215
addValue 1 69 215
assign 1 69 216
new 0 69 216
addValue 1 69 217
assign 1 71 220
new 0 71 220
addValue 1 71 221
assign 1 77 232
emitNameGet 0 77 232
assign 1 77 233
addValue 1 77 233
assign 1 77 234
new 0 77 234
assign 1 77 235
addValue 1 77 235
assign 1 77 236
addValue 1 77 236
assign 1 77 237
new 0 77 237
addValue 1 77 238
assign 1 81 258
emitNameGet 0 81 258
assign 1 81 259
addValue 1 81 259
assign 1 81 260
new 0 81 260
assign 1 81 261
addValue 1 81 261
addValue 1 81 262
assign 1 82 263
new 0 82 263
assign 1 82 264
addValue 1 82 264
assign 1 82 265
heldGet 0 82 265
assign 1 82 266
namepathGet 0 82 266
assign 1 82 267
getClassConfig 1 82 267
assign 1 82 268
libNameGet 0 82 268
assign 1 82 269
relEmitName 1 82 269
assign 1 82 270
addValue 1 82 270
assign 1 82 271
new 0 82 271
assign 1 82 272
addValue 1 82 272
addValue 1 82 273
assign 1 84 274
new 0 84 274
assign 1 84 275
addValue 1 84 275
addValue 1 84 276
assign 1 89 302
heldGet 0 89 302
assign 1 89 303
synGet 0 89 303
assign 1 90 304
ptyListGet 0 90 304
assign 1 92 305
emitNameGet 0 92 305
assign 1 92 306
addValue 1 92 306
assign 1 92 307
new 0 92 307
addValue 1 92 308
assign 1 94 309
emitChecksGet 0 94 309
assign 1 94 310
new 0 94 310
assign 1 94 311
contains 1 94 311
assign 1 95 313
new 0 95 313
assign 1 96 314
iteratorGet 0 0 314
assign 1 96 317
hasNextGet 0 96 317
assign 1 96 319
nextGet 0 96 319
assign 1 97 320
isSlotGet 0 97 320
assign 1 99 323
new 0 99 323
assign 1 101 326
new 0 101 326
addValue 1 101 327
assign 1 103 329
addValue 1 103 329
assign 1 103 330
new 0 103 330
assign 1 103 331
addValue 1 103 331
assign 1 103 332
nameGet 0 103 332
assign 1 103 333
addValue 1 103 333
addValue 1 103 334
assign 1 108 342
new 0 108 342
assign 1 108 343
addValue 1 108 343
addValue 1 108 344
assign 1 113 372
heldGet 0 113 372
assign 1 113 373
namepathGet 0 113 373
assign 1 113 374
getClassConfig 1 113 374
assign 1 114 375
getInitialInst 1 114 375
assign 1 116 376
emitNameGet 0 116 376
assign 1 116 377
addValue 1 116 377
assign 1 116 378
new 0 116 378
assign 1 116 379
addValue 1 116 379
addValue 1 116 380
assign 1 119 381
addValue 1 119 381
assign 1 119 382
new 0 119 382
assign 1 119 383
addValue 1 119 383
addValue 1 119 384
assign 1 121 385
new 0 121 385
assign 1 121 386
addValue 1 121 386
addValue 1 121 387
assign 1 123 388
emitNameGet 0 123 388
assign 1 123 389
addValue 1 123 389
assign 1 123 390
new 0 123 390
assign 1 123 391
addValue 1 123 391
addValue 1 123 392
assign 1 126 393
new 0 126 393
assign 1 126 394
addValue 1 126 394
assign 1 126 395
addValue 1 126 395
assign 1 126 396
new 0 126 396
assign 1 126 397
addValue 1 126 397
addValue 1 126 398
assign 1 128 399
new 0 128 399
assign 1 128 400
addValue 1 128 400
addValue 1 128 401
buildPropList 0 130 402
getCode 2 135 407
assign 1 136 408
toString 0 136 408
addValue 1 137 409
assign 1 142 419
emitChecksGet 0 142 419
assign 1 142 420
new 0 142 420
assign 1 142 421
contains 1 142 421
assign 1 144 423
new 0 144 423
assign 1 144 424
addValue 1 144 424
addValue 1 144 425
addValue 1 145 426
assign 1 148 429
new 0 148 429
addValue 1 148 430
assign 1 154 437
new 0 154 437
assign 1 154 438
addValue 1 154 438
addValue 1 154 439
addValue 1 155 440
assign 1 160 449
isPropertyGet 0 160 449
assign 1 161 451
new 0 161 451
assign 1 161 452
nameGet 0 161 452
assign 1 161 453
add 1 161 453
return 1 161 454
assign 1 163 456
nameForVar 1 163 456
return 1 163 457
assign 1 172 595
getLibOutput 0 172 595
assign 1 174 596
new 0 174 596
assign 1 175 597
new 0 175 597
assign 1 176 598
new 0 176 598
assign 1 177 599
iteratorGet 0 177 599
assign 1 177 602
hasNextGet 0 177 602
assign 1 179 604
nextGet 0 179 604
assign 1 181 605
emitChecksGet 0 181 605
assign 1 181 606
new 0 181 606
assign 1 181 607
contains 1 181 607
assign 1 182 609
new 0 182 609
assign 1 182 610
addValue 1 182 610
assign 1 182 611
addValue 1 182 611
assign 1 182 612
heldGet 0 182 612
assign 1 182 613
namepathGet 0 182 613
assign 1 182 614
toString 0 182 614
assign 1 182 615
addValue 1 182 615
assign 1 182 616
addValue 1 182 616
assign 1 182 617
new 0 182 617
assign 1 182 618
addValue 1 182 618
assign 1 182 619
heldGet 0 182 619
assign 1 182 620
namepathGet 0 182 620
assign 1 182 621
getClassConfig 1 182 621
assign 1 182 622
libNameGet 0 182 622
assign 1 182 623
relEmitName 1 182 623
assign 1 182 624
addValue 1 182 624
assign 1 182 625
new 0 182 625
assign 1 182 626
addValue 1 182 626
addValue 1 182 627
assign 1 184 629
heldGet 0 184 629
assign 1 184 630
synGet 0 184 630
assign 1 184 631
hasDefaultGet 0 184 631
assign 1 186 633
new 0 186 633
assign 1 186 634
heldGet 0 186 634
assign 1 186 635
namepathGet 0 186 635
assign 1 186 636
getClassConfig 1 186 636
assign 1 186 637
libNameGet 0 186 637
assign 1 186 638
relEmitName 1 186 638
assign 1 186 639
add 1 186 639
assign 1 186 640
new 0 186 640
assign 1 186 641
add 1 186 641
assign 1 192 642
new 0 192 642
assign 1 192 643
addValue 1 192 643
assign 1 192 644
addValue 1 192 644
assign 1 192 645
new 0 192 645
assign 1 192 646
addValue 1 192 646
addValue 1 192 647
assign 1 193 648
heldGet 0 193 648
assign 1 193 649
synGet 0 193 649
assign 1 193 650
hasDefaultGet 0 193 650
assign 1 194 652
new 0 194 652
assign 1 194 653
addValue 1 194 653
assign 1 194 654
addValue 1 194 654
assign 1 194 655
new 0 194 655
assign 1 194 656
addValue 1 194 656
addValue 1 194 657
assign 1 200 665
new 0 200 665
assign 1 202 666
keysGet 0 202 666
assign 1 202 667
iteratorGet 0 0 667
assign 1 202 670
hasNextGet 0 202 670
assign 1 202 672
nextGet 0 202 672
assign 1 204 673
new 0 204 673
assign 1 204 674
addValue 1 204 674
assign 1 204 675
new 0 204 675
assign 1 204 676
quoteGet 0 204 676
assign 1 204 677
addValue 1 204 677
assign 1 204 678
addValue 1 204 678
assign 1 204 679
new 0 204 679
assign 1 204 680
quoteGet 0 204 680
assign 1 204 681
addValue 1 204 681
assign 1 204 682
new 0 204 682
assign 1 204 683
addValue 1 204 683
assign 1 204 684
get 1 204 684
assign 1 204 685
addValue 1 204 685
assign 1 204 686
new 0 204 686
assign 1 204 687
addValue 1 204 687
addValue 1 204 688
assign 1 205 689
new 0 205 689
assign 1 205 690
addValue 1 205 690
assign 1 205 691
new 0 205 691
assign 1 205 692
quoteGet 0 205 692
assign 1 205 693
addValue 1 205 693
assign 1 205 694
addValue 1 205 694
assign 1 205 695
new 0 205 695
assign 1 205 696
quoteGet 0 205 696
assign 1 205 697
addValue 1 205 697
assign 1 205 698
new 0 205 698
assign 1 205 699
addValue 1 205 699
assign 1 205 700
get 1 205 700
assign 1 205 701
addValue 1 205 701
assign 1 205 702
new 0 205 702
assign 1 205 703
addValue 1 205 703
addValue 1 205 704
assign 1 209 710
emitChecksGet 0 209 710
assign 1 209 711
new 0 209 711
assign 1 209 712
contains 1 209 712
write 1 210 714
assign 1 214 716
usedLibrarysGet 0 214 716
assign 1 214 717
lengthGet 0 214 717
assign 1 214 718
new 0 214 718
assign 1 214 719
equals 1 214 724
assign 1 215 725
new 0 215 725
assign 1 215 726
addValue 1 215 726
addValue 1 215 727
assign 1 216 728
new 0 216 728
assign 1 216 729
addValue 1 216 729
addValue 1 216 730
assign 1 217 731
new 0 217 731
assign 1 217 732
addValue 1 217 732
addValue 1 217 733
write 1 220 735
write 1 221 736
assign 1 224 737
new 0 224 737
assign 1 225 738
mainNameGet 0 225 738
fromString 1 225 739
assign 1 226 740
getClassConfig 1 226 740
assign 1 228 741
new 0 228 741
assign 1 229 742
new 0 229 742
assign 1 229 743
addValue 1 229 743
assign 1 229 744
fullEmitNameGet 0 229 744
assign 1 229 745
addValue 1 229 745
assign 1 229 746
new 0 229 746
assign 1 229 747
addValue 1 229 747
addValue 1 229 748
assign 1 230 749
ownProcessGet 0 230 749
assign 1 231 751
emitChecksGet 0 231 751
assign 1 231 752
new 0 231 752
assign 1 231 753
contains 1 231 753
assign 1 232 755
new 0 232 755
assign 1 232 756
addValue 1 232 756
addValue 1 232 757
assign 1 235 760
new 0 235 760
assign 1 235 761
addValue 1 235 761
assign 1 235 762
outputPlatformGet 0 235 762
assign 1 235 763
nameGet 0 235 763
assign 1 235 764
addValue 1 235 764
assign 1 235 765
new 0 235 765
assign 1 235 766
addValue 1 235 766
addValue 1 235 767
assign 1 236 768
doMainGet 0 236 768
write 1 237 770
assign 1 239 772
new 0 239 772
write 1 240 773
write 1 241 774
assign 1 242 775
ownProcessGet 0 242 775
assign 1 243 777
new 0 243 777
assign 1 243 778
addValue 1 243 778
addValue 1 243 779
assign 1 244 780
new 0 244 780
assign 1 244 781
addValue 1 244 781
addValue 1 244 782
assign 1 246 784
doMainGet 0 246 784
write 1 247 786
finishLibOutput 1 250 788
assign 1 252 789
saveSynsGet 0 252 789
saveSyns 0 253 791
assign 1 259 801
isPropertyGet 0 259 801
assign 1 262 805
isArgGet 0 262 805
assign 1 262 806
not 0 262 811
assign 1 263 812
new 0 263 812
addValue 1 263 813
assign 1 265 815
nameForVar 1 265 815
addValue 1 265 816
assign 1 270 822
new 0 270 822
return 1 270 823
assign 1 274 831
new 0 274 831
assign 1 274 832
add 1 274 832
assign 1 274 833
new 0 274 833
assign 1 274 834
add 1 274 834
assign 1 274 835
add 1 274 835
return 1 274 836
assign 1 278 840
new 0 278 840
return 1 278 841
assign 1 282 855
emitNameGet 0 282 855
assign 1 282 856
new 0 282 856
assign 1 282 857
add 1 282 857
assign 1 282 858
add 1 282 858
assign 1 282 859
new 0 282 859
assign 1 282 860
add 1 282 860
assign 1 282 861
addValue 1 282 861
assign 1 284 862
emitNameGet 0 284 862
assign 1 284 863
add 1 284 863
assign 1 284 864
new 0 284 864
assign 1 284 865
add 1 284 865
assign 1 284 866
addValue 1 284 866
return 1 285 867
assign 1 289 881
new 0 289 881
assign 1 289 882
libNameGet 0 289 882
assign 1 289 883
relEmitName 1 289 883
assign 1 289 884
add 1 289 884
assign 1 289 885
new 0 289 885
assign 1 289 886
add 1 289 886
assign 1 289 887
heldGet 0 289 887
assign 1 289 888
literalValueGet 0 289 888
assign 1 289 889
add 1 289 889
assign 1 289 890
new 0 289 890
assign 1 289 891
add 1 289 891
return 1 289 892
assign 1 293 906
new 0 293 906
assign 1 293 907
libNameGet 0 293 907
assign 1 293 908
relEmitName 1 293 908
assign 1 293 909
add 1 293 909
assign 1 293 910
new 0 293 910
assign 1 293 911
add 1 293 911
assign 1 293 912
heldGet 0 293 912
assign 1 293 913
literalValueGet 0 293 913
assign 1 293 914
add 1 293 914
assign 1 293 915
new 0 293 915
assign 1 293 916
add 1 293 916
return 1 293 917
assign 1 297 951
emitChecksGet 0 297 951
assign 1 297 952
new 0 297 952
assign 1 297 953
contains 1 297 953
assign 1 298 955
new 0 298 955
assign 1 298 956
libNameGet 0 298 956
assign 1 298 957
relEmitName 1 298 957
assign 1 298 958
add 1 298 958
assign 1 298 959
new 0 298 959
assign 1 298 960
add 1 298 960
assign 1 298 961
emitNameGet 0 298 961
assign 1 298 962
add 1 298 962
assign 1 298 963
new 0 298 963
assign 1 298 964
add 1 298 964
assign 1 298 965
add 1 298 965
assign 1 298 966
new 0 298 966
assign 1 298 967
add 1 298 967
assign 1 298 968
add 1 298 968
assign 1 298 969
new 0 298 969
assign 1 298 970
add 1 298 970
return 1 298 971
assign 1 300 974
new 0 300 974
assign 1 300 975
libNameGet 0 300 975
assign 1 300 976
relEmitName 1 300 976
assign 1 300 977
add 1 300 977
assign 1 300 978
new 0 300 978
assign 1 300 979
add 1 300 979
assign 1 300 980
add 1 300 980
assign 1 300 981
new 0 300 981
assign 1 300 982
add 1 300 982
assign 1 300 983
add 1 300 983
assign 1 300 984
new 0 300 984
assign 1 300 985
add 1 300 985
return 1 300 986
assign 1 305 1002
def 1 305 1007
assign 1 306 1008
libNameGet 0 306 1008
assign 1 306 1009
relEmitName 1 306 1009
assign 1 306 1010
extend 1 306 1010
assign 1 308 1013
new 0 308 1013
assign 1 308 1014
extend 1 308 1014
assign 1 310 1016
new 0 310 1016
assign 1 310 1017
emitNameGet 0 310 1017
assign 1 310 1018
addValue 1 310 1018
assign 1 310 1019
new 0 310 1019
assign 1 310 1020
addValue 1 310 1020
assign 1 318 1021
new 0 318 1021
assign 1 318 1022
addValue 1 318 1022
addValue 1 318 1023
addValue 1 319 1024
return 1 320 1025
assign 1 324 1054
heldGet 0 324 1054
assign 1 324 1055
superCallGet 0 324 1055
assign 1 325 1057
new 0 325 1057
assign 1 325 1058
notEmpty 1 325 1058
assign 1 326 1060
new 0 326 1060
assign 1 326 1061
add 1 326 1061
assign 1 328 1064
new 0 328 1064
assign 1 330 1066
emitNameGet 0 330 1066
assign 1 330 1067
new 0 330 1067
assign 1 330 1068
add 1 330 1068
assign 1 330 1069
heldGet 0 330 1069
assign 1 330 1070
nameGet 0 330 1070
assign 1 330 1071
add 1 330 1071
assign 1 330 1072
new 0 330 1072
assign 1 330 1073
add 1 330 1073
assign 1 330 1074
add 1 330 1074
assign 1 330 1075
new 0 330 1075
assign 1 330 1076
add 1 330 1076
return 1 330 1077
assign 1 332 1079
new 0 332 1079
assign 1 332 1080
add 1 332 1080
assign 1 332 1081
heldGet 0 332 1081
assign 1 332 1082
nameGet 0 332 1082
assign 1 332 1083
add 1 332 1083
assign 1 332 1084
new 0 332 1084
assign 1 332 1085
add 1 332 1085
assign 1 332 1086
add 1 332 1086
assign 1 332 1087
new 0 332 1087
assign 1 332 1088
add 1 332 1088
return 1 332 1089
assign 1 336 1093
new 0 336 1093
return 1 337 1094
assign 1 344 1099
undef 1 344 1104
assign 1 345 1105
new 0 345 1105
addValue 1 347 1107
assign 1 348 1108
new 0 348 1108
return 1 348 1109
assign 1 353 1113
getLibOutput 0 353 1113
return 1 353 1114
assign 1 361 1145
undef 1 361 1150
assign 1 362 1151
new 0 362 1151
assign 1 363 1152
parentGet 0 363 1152
assign 1 363 1153
fileGet 0 363 1153
assign 1 363 1154
existsGet 0 363 1154
assign 1 363 1155
not 0 363 1160
assign 1 364 1161
parentGet 0 364 1161
assign 1 364 1162
fileGet 0 364 1162
makeDirs 0 364 1163
assign 1 366 1165
fileGet 0 366 1165
assign 1 366 1166
writerGet 0 366 1166
assign 1 366 1167
open 0 366 1167
assign 1 368 1168
paramsGet 0 368 1168
assign 1 368 1169
new 0 368 1169
assign 1 368 1170
contains 1 368 1170
assign 1 369 1172
paramsGet 0 369 1172
assign 1 369 1173
new 0 369 1173
assign 1 369 1174
get 1 369 1174
assign 1 369 1175
iteratorGet 0 0 1175
assign 1 369 1178
hasNextGet 0 369 1178
assign 1 369 1180
nextGet 0 369 1180
assign 1 370 1181
apNew 1 370 1181
assign 1 370 1182
fileGet 0 370 1182
assign 1 371 1183
readerGet 0 371 1183
assign 1 371 1184
open 0 371 1184
assign 1 371 1185
readString 0 371 1185
assign 1 372 1186
readerGet 0 372 1186
close 0 372 1187
assign 1 373 1188
countLines 1 373 1188
addValue 1 373 1189
write 1 374 1190
return 1 380 1198
close 0 384 1201
assign 1 385 1202
assign 1 390 1207
new 0 390 1207
return 1 390 1208
assign 1 394 1212
new 0 394 1212
return 1 394 1213
assign 1 398 1217
new 0 398 1217
return 1 398 1218
assign 1 402 1222
new 0 402 1222
return 1 402 1223
assign 1 406 1227
new 0 406 1227
return 1 406 1228
assign 1 410 1232
new 0 410 1232
return 1 410 1233
assign 1 414 1237
new 0 414 1237
return 1 414 1238
assign 1 419 1242
new 0 419 1242
return 1 419 1243
assign 1 425 1247
new 0 425 1247
return 1 425 1248
assign 1 430 1252
new 0 430 1252
return 1 430 1253
assign 1 434 1261
new 0 434 1261
assign 1 434 1262
add 1 434 1262
assign 1 434 1263
new 0 434 1263
assign 1 434 1264
add 1 434 1264
assign 1 434 1265
add 1 434 1265
return 1 434 1266
assign 1 438 1273
libNameGet 0 438 1273
assign 1 438 1274
relEmitName 1 438 1274
assign 1 438 1275
new 0 438 1275
assign 1 438 1276
add 1 438 1276
return 1 438 1277
assign 1 443 1286
emitNameGet 0 443 1286
assign 1 443 1287
new 0 443 1287
assign 1 443 1288
add 1 443 1288
assign 1 443 1289
new 0 443 1289
assign 1 443 1290
add 1 443 1290
assign 1 443 1291
add 1 443 1291
return 1 443 1292
assign 1 448 1303
emitNameGet 0 448 1303
assign 1 448 1304
addValue 1 448 1304
assign 1 448 1305
new 0 448 1305
assign 1 448 1306
addValue 1 448 1306
assign 1 448 1307
addValue 1 448 1307
assign 1 448 1308
new 0 448 1308
addValue 1 448 1309
addValue 1 450 1310
assign 1 452 1311
new 0 452 1311
assign 1 452 1312
addValue 1 452 1312
addValue 1 452 1313
assign 1 457 1318
new 0 457 1318
return 1 457 1319
assign 1 461 1323
new 0 461 1323
return 1 461 1324
assign 1 465 1330
new 0 465 1330
assign 1 465 1331
add 1 465 1331
assign 1 465 1332
add 1 465 1332
return 1 465 1333
assign 1 470 1337
new 0 470 1337
return 1 470 1338
assign 1 474 1343
getClassConfig 1 474 1343
assign 1 475 1344
fullEmitNameGet 0 475 1344
emitNameSet 1 475 1345
return 1 476 1346
assign 1 480 1351
getLocalClassConfig 1 480 1351
assign 1 481 1352
fullEmitNameGet 0 481 1352
emitNameSet 1 481 1353
return 1 482 1354
return 1 0 1357
assign 1 0 1360
return 1 0 1364
assign 1 0 1367
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1954876952: return bem_iteratorGet_0();
case -652420671: return bem_nlGet_0();
case -614182873: return bem_fullLibEmitNameGet_0();
case 790178578: return bem_useDynMethodsGet_0();
case 1056835519: return bem_baseSmtdDecGet_0();
case -1472543572: return bem_nullValueGet_0();
case -798863684: return bem_nativeCSlotsGet_0();
case -961940661: return bem_exceptDecGet_0();
case -2147238234: return bem_classCallsGet_0();
case -153431309: return bem_newDecGet_0();
case -1102438277: return bem_instanceNotEqualGet_0();
case 403607649: return bem_dynMethodsGet_0();
case 579861734: return bem_mnodeGet_0();
case 1549429496: return bem_afterCast_0();
case -813159719: return bem_objectCcGet_0();
case -610139577: return bem_classEndGet_0();
case -520991113: return bem_buildCreate_0();
case 805906021: return bem_classesInDepthOrderGet_0();
case 1356338585: return bem_new_0();
case -1528532033: return bem_transGet_0();
case -1563286274: return bem_methodBodyGet_0();
case 1428575040: return bem_toString_0();
case 430061340: return bem_boolTypeGet_0();
case -401539803: return bem_floatNpGet_0();
case 605454147: return bem_baseMtdDecGet_0();
case 727420497: return bem_typeDecGet_0();
case -364705144: return bem_emitLib_0();
case -1253020993: return bem_allOnceDecsGet_0();
case -1563619869: return bem_getLibOutput_0();
case 1006744792: return bem_loadIds_0();
case 135097458: return bem_maxSpillArgsLenGet_0();
case 1769803364: return bem_falseValueGet_0();
case 1084529602: return bem_lastMethodsLinesGet_0();
case 341090687: return bem_msynGet_0();
case 802362264: return bem_ccCacheGet_0();
case 302455136: return bem_preClassOutput_0();
case -841996170: return bem_ntypesGet_0();
case 497719688: return bem_trueValueGet_0();
case -858217600: return bem_smnlcsGet_0();
case 758566765: return bem_constGet_0();
case 694326316: return bem_saveSyns_0();
case -49273694: return bem_superNameGet_0();
case -79240671: return bem_getClassOutput_0();
case -274216286: return bem_gcMarksGet_0();
case -2067114823: return bem_libEmitNameGet_0();
case -1591714028: return bem_beginNs_0();
case -1688203909: return bem_scvpGet_0();
case 1069615902: return bem_copy_0();
case -1874822566: return bem_libEmitPathGet_0();
case -251093561: return bem_writeBET_0();
case 1498474425: return bem_csynGet_0();
case -521709333: return bem_qGet_0();
case 1688314365: return bem_mainStartGet_0();
case -1585567544: return bem_propDecGet_0();
case 1910145317: return bem_preClassGet_0();
case 885091049: return bem_methodCallsGet_0();
case -1980259058: return bem_buildGet_0();
case 2066119706: return bem_lastMethodsSizeGet_0();
case 5317741: return bem_belslitsGet_0();
case -1696030071: return bem_idToNamePathGet_0();
case -124767533: return bem_buildInitial_0();
case -885358074: return bem_fileExtGet_0();
case -646792864: return bem_lastMethodBodyLinesGet_0();
case 655228907: return bem_invpGet_0();
case 625974468: return bem_callNamesGet_0();
case -1665716262: return bem_lineCountGet_0();
case 240300781: return bem_instOfGet_0();
case 1827062028: return bem_runtimeInitGet_0();
case 1227407747: return bem_overrideMtdDecGet_0();
case -1177729530: return bem_lastMethodBodySizeGet_0();
case -1008918648: return bem_shlibeGet_0();
case -2041117012: return bem_randGet_0();
case 118000892: return bem_classConfGet_0();
case 580466531: return bem_smnlecsGet_0();
case 129462453: return bem_instanceEqualGet_0();
case -705214115: return bem_objectNpGet_0();
case -1323638505: return bem_cnodeGet_0();
case -674869775: return bem_mainEndGet_0();
case -1404444: return bem_mainInClassGet_0();
case -1268673535: return bem_endNs_0();
case -1756334550: return bem_boolNpGet_0();
case -1955214992: return bem_spropDecGet_0();
case 1184582479: return bem_inClassGet_0();
case 747059312: return bem_saveIds_0();
case -1934982294: return bem_onceDecsGet_0();
case 99375833: return bem_returnTypeGet_0();
case -64268465: return bem_classEmitsGet_0();
case 1870853052: return bem_idToNameGet_0();
case 1745760195: return bem_boolCcGet_0();
case 1361204623: return bem_inFilePathedGet_0();
case -1435819830: return bem_emitLangGet_0();
case -687499683: return bem_ccMethodsGet_0();
case -617486994: return bem_propertyDecsGet_0();
case 109560388: return bem_synEmitPathGet_0();
case -2072993199: return bem_superCallsGet_0();
case -935641853: return bem_print_0();
case 1893185091: return bem_parentConfGet_0();
case 402153427: return bem_initialDecGet_0();
case 2050340239: return bem_intNpGet_0();
case -43191778: return bem_hashGet_0();
case -1968305332: return bem_buildPropList_0();
case 909037097: return bem_covariantReturnsGet_0();
case -1255426902: return bem_nameToIdGet_0();
case 1515338272: return bem_buildClassInfo_0();
case 885446903: return bem_lastCallGet_0();
case -1967725164: return bem_methodCatchGet_0();
case -1878788901: return bem_doEmit_0();
case -1161139651: return bem_stringNpGet_0();
case -9576857: return bem_maxDynArgsGet_0();
case 1247259478: return bem_nameToIdPathGet_0();
case -1629771427: return bem_create_0();
case -1276823998: return bem_methodsGet_0();
case 2051355073: return bem_mainOutsideNsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1359870273: return bem_mnodeSet_1(bevd_0);
case 1073716984: return bem_equals_1(bevd_0);
case -1989492595: return bem_lineCountSet_1(bevd_0);
case 844423645: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 2029717050: return bem_stringNpSet_1(bevd_0);
case -494801877: return bem_idToNamePathSet_1(bevd_0);
case 1001693949: return bem_idToNameSet_1(bevd_0);
case -1072732065: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 211543749: return bem_synEmitPathSet_1(bevd_0);
case 1384784022: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 632234294: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1389588051: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1402429593: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 609261315: return bem_intNpSet_1(bevd_0);
case -387796009: return bem_instOfSet_1(bevd_0);
case 1760988180: return bem_preClassSet_1(bevd_0);
case -1456518025: return bem_libEmitNameSet_1(bevd_0);
case 1577634774: return bem_lastMethodsSizeSet_1(bevd_0);
case -1474009602: return bem_dynMethodsSet_1(bevd_0);
case -1297874535: return bem_floatNpSet_1(bevd_0);
case 479996293: return bem_shlibeSet_1(bevd_0);
case 896979114: return bem_trueValueSet_1(bevd_0);
case 1726393204: return bem_decNameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1552728012: return bem_callNamesSet_1(bevd_0);
case -204178020: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1821894809: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -577358012: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -875398267: return bem_constSet_1(bevd_0);
case -1377122766: return bem_belslitsSet_1(bevd_0);
case -615433139: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -219298593: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1772887890: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 2021261894: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -215085906: return bem_methodCallsSet_1(bevd_0);
case -1876377682: return bem_gcMarksSet_1(bevd_0);
case 493663724: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1446602730: return bem_msynSet_1(bevd_0);
case 1888991404: return bem_ccCacheSet_1(bevd_0);
case 643912628: return bem_qSet_1(bevd_0);
case -847886463: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 425723994: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2046169365: return bem_classEmitsSet_1(bevd_0);
case -1618525374: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 838272616: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -246343503: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1388413072: return bem_copyTo_1(bevd_0);
case 870724511: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -772180528: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1325381960: return bem_fullLibEmitNameSet_1(bevd_0);
case -812454416: return bem_lastMethodBodySizeSet_1(bevd_0);
case -946351099: return bem_print_1(bevd_0);
case 1908910456: return bem_scvpSet_1(bevd_0);
case -1315835711: return bem_smnlecsSet_1(bevd_0);
case -807028433: return bem_buildSet_1(bevd_0);
case -1413055610: return bem_smnlcsSet_1(bevd_0);
case -42185481: return bem_cnodeSet_1(bevd_0);
case -1523462042: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -7067018: return bem_inFilePathedSet_1(bevd_0);
case 1865249683: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1841999472: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 162982224: return bem_classConfSet_1(bevd_0);
case 559357138: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -179556288: return bem_undef_1(bevd_0);
case -1585465194: return bem_lastMethodsLinesSet_1(bevd_0);
case 548030981: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1831135464: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1645472434: return bem_allOnceDecsSet_1(bevd_0);
case 676637099: return bem_objectNpSet_1(bevd_0);
case -527897249: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1686620785: return bem_libEmitPathSet_1(bevd_0);
case 647375870: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1376958747: return bem_instanceEqualSet_1(bevd_0);
case 852963422: return bem_parentConfSet_1(bevd_0);
case -1620436445: return bem_nameToIdPathSet_1(bevd_0);
case -1859473454: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -781513031: return bem_superCallsSet_1(bevd_0);
case 167503870: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1119124817: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -2136684024: return bem_methodCatchSet_1(bevd_0);
case 1758373716: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 856221906: return bem_objectCcSet_1(bevd_0);
case -1701329100: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1740272463: return bem_boolNpSet_1(bevd_0);
case 2058064646: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 882385533: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1669690608: return bem_inClassSet_1(bevd_0);
case 1045642251: return bem_maxSpillArgsLenSet_1(bevd_0);
case 679243418: return bem_exceptDecSet_1(bevd_0);
case 1886161096: return bem_nativeCSlotsSet_1(bevd_0);
case 228632558: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1791731399: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -40037916: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -751636461: return bem_emitLangSet_1(bevd_0);
case 1158654006: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2073228717: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -760659594: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1949081787: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 957913926: return bem_classCallsSet_1(bevd_0);
case -388243441: return bem_csynSet_1(bevd_0);
case -1451410028: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1366175642: return bem_def_1(bevd_0);
case -1647315545: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1479710727: return bem_returnTypeSet_1(bevd_0);
case -1496149131: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 58336761: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 985001455: return bem_invpSet_1(bevd_0);
case -1573968310: return bem_maxDynArgsSet_1(bevd_0);
case -305737835: return bem_ntypesSet_1(bevd_0);
case 1664610360: return bem_ccMethodsSet_1(bevd_0);
case 3170895: return bem_begin_1(bevd_0);
case 1539465705: return bem_instanceNotEqualSet_1(bevd_0);
case -1332172332: return bem_methodsSet_1(bevd_0);
case 2133335072: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1933530959: return bem_boolCcSet_1(bevd_0);
case 1756490514: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1234398294: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1274123920: return bem_nlSet_1(bevd_0);
case -96911152: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case 484780340: return bem_notEquals_1(bevd_0);
case -455980880: return bem_nameToIdSet_1(bevd_0);
case -656709060: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -410324455: return bem_methodBodySet_1(bevd_0);
case -1479095747: return bem_propertyDecsSet_1(bevd_0);
case -803545836: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1989726154: return bem_nullValueSet_1(bevd_0);
case 1507008386: return bem_randSet_1(bevd_0);
case 462731488: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1777394675: return bem_onceDecsSet_1(bevd_0);
case -1083965197: return bem_lastCallSet_1(bevd_0);
case -1965170344: return bem_falseValueSet_1(bevd_0);
case -1461277960: return bem_end_1(bevd_0);
case 802505188: return bem_transSet_1(bevd_0);
case 817138983: return bem_classesInDepthOrderSet_1(bevd_0);
case 1590857244: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 995103368: return bem_fileExtSet_1(bevd_0);
case 550903974: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1655058703: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 557358653: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1142937120: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1777172608: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1932865846: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 443231725: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1526227775: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1024239157: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -367301265: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1814157162: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -548042918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -570336382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1111008594: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2144340818: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1032816764: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 308894706: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 159189467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1371974373: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1934970347: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -2134980655: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 889721652: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1463185379: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -637123759: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 959816422: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1939848637: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1600641429: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1507421581: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
