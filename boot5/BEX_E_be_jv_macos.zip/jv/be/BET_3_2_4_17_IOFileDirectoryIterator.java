package be;
public class BET_3_2_4_17_IOFileDirectoryIterator extends BETS_Object {
public BET_3_2_4_17_IOFileDirectoryIterator() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "open_0", "hasNextGet_0", "nextGet_0", "advance_0", "close_0", "dirGet_0", "dirSet_1", "openedGet_0", "openedSet_1", "closedGet_0", "closedSet_1", "currentGet_0", "currentSet_1", "jsiterGet_0", "jsiterSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "dir", "opened", "closed", "current", "jsiter" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
}
