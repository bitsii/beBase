package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_7_IOFileReaderCommand extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
public static BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_1(BEC_2_6_6_SystemObject beva__command) throws Throwable {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) throws Throwable {
super.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool)/* Line: 832*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_command);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_ta_ph);
throw new be.BECS_ThrowBack(bevt_0_ta_ph);
} /* Line: 833*/
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_close_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public final BEC_2_4_6_TextString bem_commandGetDirect_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {795, 799, 803, 805, 816, 831, 833, 833, 833, 833, 833, 833, 846, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 23, 24, 35, 36, 38, 39, 40, 41, 42, 43, 48, 52, 55, 58, 62};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 795 15
commandNew 1 799 19
new 0 803 23
assign 1 805 24
assign 1 816 35
assign 1 831 36
assign 1 833 38
new 0 833 38
assign 1 833 39
add 1 833 39
assign 1 833 40
new 0 833 40
assign 1 833 41
add 1 833 41
assign 1 833 42
new 1 833 42
throw 1 833 43
assign 1 846 48
new 0 846 48
return 1 0 52
return 1 0 55
assign 1 0 58
assign 1 0 62
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 818210964: return bem_toAny_0();
case -407687427: return bem_fieldNamesGet_0();
case 2123863113: return bem_readBuffer_0();
case -1444183702: return bem_byteReaderGet_0();
case -1915666683: return bem_serializationIteratorGet_0();
case -1215164118: return bem_readString_0();
case 1596298204: return bem_readBufferLine_0();
case 826167413: return bem_classNameGet_0();
case 272213226: return bem_isClosedGet_0();
case -749268313: return bem_copy_0();
case 1175327021: return bem_open_0();
case -479412451: return bem_iteratorGet_0();
case 1210407094: return bem_tagGet_0();
case -344688418: return bem_new_0();
case -899256741: return bem_toString_0();
case -2077233598: return bem_close_0();
case 1248589642: return bem_readDiscard_0();
case -1514184278: return bem_serializeContents_0();
case 1315725661: return bem_hashGet_0();
case -196233987: return bem_readDiscardClose_0();
case -647206094: return bem_pathGet_0();
case 770986263: return bem_create_0();
case -1306772600: return bem_commandGetDirect_0();
case 1417557505: return bem_pathGetDirect_0();
case -1087983570: return bem_vfileGet_0();
case 1177850161: return bem_vfileGetDirect_0();
case -1959899288: return bem_fieldIteratorGet_0();
case 576618510: return bem_readStringClose_0();
case 887254713: return bem_sourceFileNameGet_0();
case -1471489845: return bem_isClosedGetDirect_0();
case 846353007: return bem_echo_0();
case 1889759273: return bem_blockSizeGet_0();
case -327712425: return bem_many_0();
case -2041899054: return bem_extOpen_0();
case -1945570638: return bem_once_0();
case 1247606789: return bem_blockSizeGetDirect_0();
case 1293575145: return bem_serializeToString_0();
case -1546386041: return bem_commandGet_0();
case -519581463: return bem_deserializeClassNameGet_0();
case 1270756764: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1779534016: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 1715370141: return bem_sameClass_1(bevd_0);
case 509956737: return bem_def_1(bevd_0);
case -1416448852: return bem_blockSizeSetDirect_1(bevd_0);
case -597164057: return bem_defined_1(bevd_0);
case 1352478915: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 2143576839: return bem_isClosedSet_1(bevd_0);
case -1548523977: return bem_otherClass_1(bevd_0);
case -1468949165: return bem_undefined_1(bevd_0);
case 509252275: return bem_sameObject_1(bevd_0);
case 1767090146: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 2011695784: return bem_new_1(bevd_0);
case 2144395088: return bem_undef_1(bevd_0);
case 434988919: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1145469747: return bem_vfileSet_1(bevd_0);
case -513171104: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 248598654: return bem_copyTo_1(bevd_0);
case 2033021383: return bem_pathSetDirect_1(bevd_0);
case -1175085799: return bem_commandSet_1(bevd_0);
case -1343727458: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1477732575: return bem_otherType_1(bevd_0);
case 1946977825: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 784918995: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2048787452: return bem_pathSet_1(bevd_0);
case -233300707: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1668670721: return bem_vfileSetDirect_1(bevd_0);
case 1772678539: return bem_notEquals_1(bevd_0);
case -1320319426: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1498119962: return bem_sameType_1(bevd_0);
case 997331927: return bem_equals_1(bevd_0);
case 1702987691: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1392931971: return bem_commandSetDirect_1(bevd_0);
case -68857763: return bem_blockSizeSet_1(bevd_0);
case -1525688502: return bem_isClosedSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1189130153: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -319997805: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1675736992: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -455603186: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -390764901: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 262774206: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1936737880: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -403771483: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1045041449: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 813093531: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
