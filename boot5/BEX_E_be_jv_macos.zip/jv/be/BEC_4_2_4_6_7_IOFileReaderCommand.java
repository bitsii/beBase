package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_7_IOFileReaderCommand extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
public static BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_new_1(BEC_2_6_6_SystemObject beva__command) throws Throwable {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) throws Throwable {
super.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool)/* Line: 838*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_command);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_ta_ph);
throw new be.BECS_ThrowBack(bevt_0_ta_ph);
} /* Line: 839*/
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_close_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {801, 805, 809, 811, 822, 837, 839, 839, 839, 839, 839, 839, 852, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 23, 24, 35, 36, 38, 39, 40, 41, 42, 43, 48, 52, 55};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 801 15
commandNew 1 805 19
new 0 809 23
assign 1 811 24
assign 1 822 35
assign 1 837 36
assign 1 839 38
new 0 839 38
assign 1 839 39
add 1 839 39
assign 1 839 40
new 0 839 40
assign 1 839 41
add 1 839 41
assign 1 839 42
new 1 839 42
throw 1 839 43
assign 1 852 48
new 0 852 48
return 1 0 52
assign 1 0 55
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 418297068: return bem_close_0();
case -1827671744: return bem_hashGet_0();
case -1824054207: return bem_readString_0();
case 201436634: return bem_print_0();
case 600162514: return bem_readStringClose_0();
case 565064356: return bem_readBufferLine_0();
case 121383218: return bem_readDiscard_0();
case -1202137630: return bem_byteReaderGet_0();
case -1975920852: return bem_readBuffer_0();
case -1620800860: return bem_commandGet_0();
case 167887552: return bem_open_0();
case -907463432: return bem_copy_0();
case -1602239310: return bem_new_0();
case 2021446686: return bem_create_0();
case -520950308: return bem_readDiscardClose_0();
case 1796866226: return bem_blockSizeGet_0();
case 1116049816: return bem_toString_0();
case 1407534539: return bem_iteratorGet_0();
case -931286738: return bem_extOpen_0();
case -1109903644: return bem_vfileGet_0();
case 1174510161: return bem_pathGet_0();
case 1536796686: return bem_isClosedGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1559003293: return bem_pathSet_1(bevd_0);
case 1729413977: return bem_print_1(bevd_0);
case -1291367990: return bem_equals_1(bevd_0);
case 1346132616: return bem_vfileSet_1(bevd_0);
case -899314062: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -873208261: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1812901017: return bem_def_1(bevd_0);
case 1989503752: return bem_copyTo_1(bevd_0);
case -35910427: return bem_isClosedSet_1(bevd_0);
case -26650563: return bem_new_1(bevd_0);
case -15129637: return bem_commandSet_1(bevd_0);
case -471447072: return bem_notEquals_1(bevd_0);
case -2121124764: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 821901940: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1532908360: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -499446373: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1645983195: return bem_blockSizeSet_1(bevd_0);
case 1212626042: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 505990086: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1018458287: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -994154646: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 241691596: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -993790175: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1588875712: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1625156105: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1983416321: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
