package be;
public class BET_2_9_3_ContainerSet extends BETS_Object {
public BET_2_9_3_ContainerSet() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "new_1", "isEmptyGet_0", "notEmptyGet_0", "insertAll_2", "rehash_1", "contentsEqual_1", "innerPut_4", "put_1", "get_1", "has_1", "delete_1", "clear_0", "setIteratorGet_0", "keyIteratorGet_0", "keysGet_0", "nodeIteratorGet_0", "nodesGet_0", "intersection_1", "union_1", "add_1", "addValue_1", "slotsGet_0", "slotsGetDirect_0", "slotsSet_1", "slotsSetDirect_1", "moduGet_0", "moduGetDirect_0", "moduSet_1", "moduSetDirect_1", "multiGet_0", "multiGetDirect_0", "multiSet_1", "multiSetDirect_1", "relGet_0", "relGetDirect_0", "relSet_1", "relSetDirect_1", "baseNodeGet_0", "baseNodeGetDirect_0", "baseNodeSet_1", "baseNodeSetDirect_1", "sizeGet_0", "sizeGetDirect_0", "sizeSet_1", "sizeSetDirect_1", "innerPutAddedGet_0", "innerPutAddedGetDirect_0", "innerPutAddedSet_1", "innerPutAddedSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "slots", "modu", "multi", "rel", "baseNode", "size", "innerPutAdded" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_9_3_ContainerSet();
}
}
