package be;
public class BET_2_9_3_ContainerSet extends BETS_Object {
public BET_2_9_3_ContainerSet() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "isEmptyGet_0", "notEmptyGet_0", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "insertAll_2", "rehash_1", "contentsEqual_1", "innerPut_4", "put_1", "get_1", "has_1", "remove_1", "clear_0", "setIteratorGet_0", "keyIteratorGet_0", "keysGet_0", "nodeIteratorGet_0", "nodesGet_0", "intersection_1", "union_1", "add_1", "addValue_1", "bucketsGet_0", "bucketsSet_1", "lengthGet_0", "lengthSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "buckets", "length" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_9_3_ContainerSet();
}
}
