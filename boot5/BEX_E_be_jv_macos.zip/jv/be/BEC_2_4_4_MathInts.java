package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_4_MathInts extends BEC_2_6_6_SystemObject {
public BEC_2_4_4_MathInts() { }
private static byte[] becc_BEC_2_4_4_MathInts_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_4_4_MathInts_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
public static BEC_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_inst;

public static BET_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_4_3_MathInt bevp_min;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public BEC_2_4_4_MathInts bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevl__max = null;
BEC_2_4_3_MathInt bevl__min = null;
bevl__max = (new BEC_2_4_3_MathInt());
bevl__min = (new BEC_2_4_3_MathInt());

      bevl__max.bevi_int = Integer.MAX_VALUE;
      bevl__min.bevi_int = Integer.MIN_VALUE;
      //System.out.println(bevl__max.bevi_int);
      //System.out.println(bevl__min.bevi_int);
      bevp_max = bevl__max;
bevp_min = bevl__min;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_one = (new BEC_2_4_3_MathInt(1));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_min_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 950*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 950*/ {
if (beva_a.bevi_int < beva_b.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 950*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 950*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 950*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 950*/ {
return beva_a;
} /* Line: 951*/
return beva_b;
} /*method end*/
public BEC_2_6_6_SystemObject bem_max_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 957*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 957*/ {
if (beva_a.bevi_int > beva_b.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 957*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 957*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 957*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 957*/ {
return beva_a;
} /* Line: 958*/
return beva_b;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() throws Throwable {
return bevp_max;
} /*method end*/
public final BEC_2_4_3_MathInt bem_maxGetDirect_0() throws Throwable {
return bevp_max;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_4_MathInts bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGet_0() throws Throwable {
return bevp_min;
} /*method end*/
public final BEC_2_4_3_MathInt bem_minGetDirect_0() throws Throwable {
return bevp_min;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_4_MathInts bem_minSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public final BEC_2_4_3_MathInt bem_zeroGetDirect_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_4_MathInts bem_zeroSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() throws Throwable {
return bevp_one;
} /*method end*/
public final BEC_2_4_3_MathInt bem_oneGetDirect_0() throws Throwable {
return bevp_one;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_4_MathInts bem_oneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {896, 897, 942, 943, 944, 945, 950, 950, 0, 950, 950, 0, 0, 951, 953, 957, 957, 0, 957, 957, 0, 0, 958, 960, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 28, 29, 30, 31, 38, 43, 44, 47, 52, 53, 56, 60, 62, 68, 73, 74, 77, 82, 83, 86, 90, 92, 95, 98, 101, 105, 109, 112, 115, 119, 123, 126, 129, 133, 137, 140, 143, 147};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 896 21
new 0 896 21
assign 1 897 22
new 0 897 22
assign 1 942 28
assign 1 943 29
assign 1 944 30
new 0 944 30
assign 1 945 31
new 0 945 31
assign 1 950 38
undef 1 950 43
assign 1 0 44
assign 1 950 47
lesser 1 950 52
assign 1 0 53
assign 1 0 56
return 1 951 60
return 1 953 62
assign 1 957 68
undef 1 957 73
assign 1 0 74
assign 1 957 77
greater 1 957 82
assign 1 0 83
assign 1 0 86
return 1 958 90
return 1 960 92
return 1 0 95
return 1 0 98
assign 1 0 101
assign 1 0 105
return 1 0 109
return 1 0 112
assign 1 0 115
assign 1 0 119
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1001743190: return bem_fieldNamesGet_0();
case -576836877: return bem_zeroGet_0();
case 1445801145: return bem_serializationIteratorGet_0();
case 1015053278: return bem_oneGet_0();
case -794718926: return bem_copy_0();
case 340030523: return bem_classNameGet_0();
case -1263154564: return bem_new_0();
case -224203459: return bem_maxGetDirect_0();
case 1333799692: return bem_tagGet_0();
case -794062933: return bem_hashGet_0();
case -676070096: return bem_sourceFileNameGet_0();
case 1546143657: return bem_echo_0();
case -800146552: return bem_serializeContents_0();
case 147497190: return bem_iteratorGet_0();
case -602007330: return bem_maxGet_0();
case 1179961651: return bem_serializeToString_0();
case 37637962: return bem_print_0();
case 219112807: return bem_toString_0();
case -1070051589: return bem_oneGetDirect_0();
case 1577124637: return bem_deserializeClassNameGet_0();
case 184626628: return bem_minGet_0();
case 154967714: return bem_default_0();
case 240615097: return bem_minGetDirect_0();
case -387280768: return bem_zeroGetDirect_0();
case 1615402015: return bem_create_0();
case -2095499202: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 250302014: return bem_equals_1(bevd_0);
case -19945451: return bem_notEquals_1(bevd_0);
case -633514449: return bem_zeroSet_1(bevd_0);
case 1419064041: return bem_sameObject_1(bevd_0);
case -1868129616: return bem_copyTo_1(bevd_0);
case -1828511587: return bem_maxSetDirect_1(bevd_0);
case 1405755430: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 863081423: return bem_minSet_1(bevd_0);
case -834839160: return bem_oneSet_1(bevd_0);
case 2044993814: return bem_sameClass_1(bevd_0);
case -1534545800: return bem_otherType_1(bevd_0);
case 1999068250: return bem_minSetDirect_1(bevd_0);
case -230623587: return bem_maxSet_1(bevd_0);
case -2022815028: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 550061094: return bem_undef_1(bevd_0);
case 1661150226: return bem_def_1(bevd_0);
case -1935405349: return bem_sameType_1(bevd_0);
case 952238285: return bem_zeroSetDirect_1(bevd_0);
case 1565857442: return bem_oneSetDirect_1(bevd_0);
case 739117568: return bem_otherClass_1(bevd_0);
case 1981346500: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -938540681: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1947872038: return bem_min_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1738406137: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1708873965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1935150950: return bem_max_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 853768892: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2112740717: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_MathInts_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_4_MathInts_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_4_MathInts();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst = (BEC_2_4_4_MathInts) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_type;
}
}
