package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_BEC_2_4_8_TimeInterval_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_BEC_2_4_8_TimeInterval_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_0 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_1 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_2 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_3 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_4 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_5 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_6 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_7 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_11 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_14 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_15 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_16 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_17 = (new BEC_2_4_3_MathInt(3600));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_0, 10));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_1, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_2, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_3 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_3, 1));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_4 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_4, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_5 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_5, 13));
public static BEC_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_inst;

public static BET_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_type;

public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt());
bevp_millis = (new BEC_2_4_3_MathInt());

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_0;
bevt_0_tmpany_phold = bevp_secs.bem_modulus_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_1;
bevt_0_tmpany_phold = bevp_secs.bem_divide_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_2;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_3;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_5;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_6;
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_tmpany_phold);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_7;
bevt_4_tmpany_phold = bevp_millis.bem_divide_1(bevt_5_tmpany_phold);
bevp_secs = bevp_secs.bem_add_1(bevt_4_tmpany_phold);
bevp_millis = bevl_mmod;
} /* Line: 226 */
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_8;
if (bevp_millis.bevi_int < bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_9;
if (bevp_secs.bevi_int > bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 228 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_10;
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_11;
bevp_millis = bevt_11_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 230 */
 else  /* Line: 228 */ {
bevt_13_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_12;
if (bevp_millis.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_13;
if (bevp_secs.bevi_int < bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 231 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 231 */
 else  /* Line: 231 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 231 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_14;
bevp_secs = bevp_secs.bem_add_1(bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_15;
bevt_19_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_16;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_subtract_1(bevt_19_tmpany_phold);
bevp_millis = bevt_17_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 233 */
} /* Line: 228 */
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
 else  /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 264 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 270 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 271 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 278 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 285 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_4_tmpany_phold = beva_other.bemd_0(92183996);
bevt_3_tmpany_phold = bevp_secs.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 291 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 291 */
 else  /* Line: 291 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 291 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-390339728);
bevt_5_tmpany_phold = bevp_millis.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 291 */
 else  /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 291 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 292 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(92183996);
bevt_4_tmpany_phold = bevp_secs.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 298 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(-390339728);
bevt_6_tmpany_phold = bevp_millis.bem_notEquals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 298 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 298 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_8_tmpany_phold;
} /* Line: 299 */
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
if (beva_other == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 306 */
bevt_3_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevt_7_tmpany_phold = beva_other.bem_secsGet_0();
bevt_6_tmpany_phold = bevp_secs.bem_subtract_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_abs_0();
bevt_8_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_17;
if (bevt_5_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 308 */ {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_9_tmpany_phold;
} /* Line: 309 */
} /* Line: 308 */
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_6_tmpany_phold = bem_minutesGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_toString_0();
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_18;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bem_secondInMinuteGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_19;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_20;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_secs.bem_toString_0();
bevt_3_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_21;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_millis.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_secs.bem_toString_0();
bevt_4_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_secsGetDirect_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_secsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public final BEC_2_4_3_MathInt bem_millisGetDirect_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_millisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {113, 114, 151, 152, 158, 159, 160, 164, 164, 168, 168, 168, 172, 176, 176, 176, 180, 184, 188, 192, 193, 197, 197, 197, 201, 201, 201, 205, 205, 205, 209, 209, 209, 214, 218, 219, 223, 223, 224, 224, 225, 225, 225, 226, 228, 228, 228, 228, 228, 228, 0, 0, 0, 229, 229, 230, 230, 231, 231, 231, 231, 231, 231, 0, 0, 0, 232, 232, 233, 233, 233, 233, 238, 242, 243, 247, 247, 248, 248, 249, 250, 251, 255, 255, 256, 256, 257, 258, 259, 263, 263, 263, 0, 263, 263, 263, 263, 263, 263, 0, 0, 0, 0, 0, 264, 264, 266, 266, 270, 270, 270, 0, 270, 270, 270, 270, 270, 270, 0, 0, 0, 0, 0, 271, 271, 273, 273, 277, 277, 277, 0, 277, 277, 277, 277, 277, 277, 0, 0, 0, 0, 0, 278, 278, 280, 280, 284, 284, 284, 0, 284, 284, 284, 284, 284, 284, 0, 0, 0, 0, 0, 285, 285, 287, 287, 291, 291, 291, 0, 0, 0, 291, 291, 0, 0, 0, 292, 292, 294, 294, 298, 298, 298, 0, 298, 298, 0, 0, 0, 298, 298, 0, 0, 299, 299, 301, 301, 306, 306, 306, 306, 307, 307, 307, 308, 308, 308, 308, 308, 308, 309, 309, 312, 312, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 320, 320, 320, 320, 320, 320, 324, 324, 324, 324, 324, 324, 324, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 53, 54, 58, 59, 60, 65, 66, 71, 72, 73, 76, 81, 82, 83, 86, 89, 93, 96, 97, 103, 104, 105, 111, 112, 113, 119, 120, 121, 127, 128, 129, 133, 137, 138, 163, 164, 165, 170, 171, 172, 173, 174, 176, 177, 182, 183, 184, 189, 190, 193, 197, 200, 201, 202, 203, 206, 207, 212, 213, 214, 219, 220, 223, 227, 230, 231, 232, 233, 234, 235, 241, 245, 246, 255, 256, 257, 258, 259, 260, 261, 269, 270, 271, 272, 273, 274, 275, 287, 288, 293, 294, 297, 298, 303, 304, 305, 310, 311, 314, 318, 321, 324, 328, 329, 331, 332, 344, 345, 350, 351, 354, 355, 360, 361, 362, 367, 368, 371, 375, 378, 381, 385, 386, 388, 389, 401, 402, 407, 408, 411, 412, 417, 418, 419, 424, 425, 428, 432, 435, 438, 442, 443, 445, 446, 458, 459, 464, 465, 468, 469, 474, 475, 476, 481, 482, 485, 489, 492, 495, 499, 500, 502, 503, 515, 517, 518, 520, 523, 527, 530, 531, 533, 536, 540, 543, 544, 546, 547, 560, 561, 566, 567, 570, 571, 573, 576, 580, 583, 584, 586, 589, 593, 594, 596, 597, 611, 616, 617, 618, 620, 621, 626, 627, 628, 629, 630, 631, 636, 637, 638, 641, 642, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 675, 676, 677, 678, 679, 680, 689, 690, 691, 692, 693, 694, 695, 698, 701, 704, 708, 712, 715, 718, 722};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 113 44
new 0 113 44
assign 1 114 45
new 0 114 45
assign 1 151 53
new 0 151 53
assign 1 152 54
new 0 152 54
assign 1 158 58
assign 1 159 59
carryMillis 0 160 60
assign 1 164 65
new 2 164 65
return 1 164 66
assign 1 168 71
new 0 168 71
assign 1 168 72
modulus 1 168 72
return 1 168 73
return 1 172 76
assign 1 176 81
new 0 176 81
assign 1 176 82
divide 1 176 82
return 1 176 83
return 1 180 86
assign 1 184 89
return 1 188 93
assign 1 192 96
carryMillis 0 193 97
assign 1 197 103
new 0 197 103
assign 1 197 104
multiply 1 197 104
assign 1 197 105
add 1 197 105
assign 1 201 111
new 0 201 111
assign 1 201 112
multiply 1 201 112
assign 1 201 113
add 1 201 113
assign 1 205 119
new 0 205 119
assign 1 205 120
multiply 1 205 120
assign 1 205 121
subtract 1 205 121
assign 1 209 127
new 0 209 127
assign 1 209 128
multiply 1 209 128
assign 1 209 129
subtract 1 209 129
assign 1 214 133
add 1 214 133
assign 1 218 137
add 1 218 137
carryMillis 0 219 138
assign 1 223 163
new 0 223 163
assign 1 223 164
modulus 1 223 164
assign 1 224 165
notEquals 1 224 170
assign 1 225 171
new 0 225 171
assign 1 225 172
divide 1 225 172
assign 1 225 173
add 1 225 173
assign 1 226 174
assign 1 228 176
new 0 228 176
assign 1 228 177
lesser 1 228 182
assign 1 228 183
new 0 228 183
assign 1 228 184
greater 1 228 189
assign 1 0 190
assign 1 0 193
assign 1 0 197
assign 1 229 200
new 0 229 200
assign 1 229 201
subtract 1 229 201
assign 1 230 202
new 0 230 202
assign 1 230 203
add 1 230 203
assign 1 231 206
new 0 231 206
assign 1 231 207
greater 1 231 212
assign 1 231 213
new 0 231 213
assign 1 231 214
lesser 1 231 219
assign 1 0 220
assign 1 0 223
assign 1 0 227
assign 1 232 230
new 0 232 230
assign 1 232 231
add 1 232 231
assign 1 233 232
new 0 233 232
assign 1 233 233
new 0 233 233
assign 1 233 234
subtract 1 233 234
assign 1 233 235
add 1 233 235
assign 1 238 241
subtract 1 238 241
assign 1 242 245
subtract 1 242 245
carryMillis 0 243 246
assign 1 247 255
secsGet 0 247 255
assign 1 247 256
add 1 247 256
assign 1 248 257
millisGet 0 248 257
assign 1 248 258
add 1 248 258
assign 1 249 259
new 2 249 259
carryMillis 0 250 260
return 1 251 261
assign 1 255 269
secsGet 0 255 269
assign 1 255 270
subtract 1 255 270
assign 1 256 271
millisGet 0 256 271
assign 1 256 272
subtract 1 256 272
assign 1 257 273
new 2 257 273
carryMillis 0 258 274
return 1 259 275
assign 1 263 287
secsGet 0 263 287
assign 1 263 288
greater 1 263 293
assign 1 0 294
assign 1 263 297
secsGet 0 263 297
assign 1 263 298
equals 1 263 303
assign 1 263 304
millisGet 0 263 304
assign 1 263 305
greater 1 263 310
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 0 321
assign 1 0 324
assign 1 264 328
new 0 264 328
return 1 264 329
assign 1 266 331
new 0 266 331
return 1 266 332
assign 1 270 344
secsGet 0 270 344
assign 1 270 345
lesser 1 270 350
assign 1 0 351
assign 1 270 354
secsGet 0 270 354
assign 1 270 355
equals 1 270 360
assign 1 270 361
millisGet 0 270 361
assign 1 270 362
lesser 1 270 367
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 0 378
assign 1 0 381
assign 1 271 385
new 0 271 385
return 1 271 386
assign 1 273 388
new 0 273 388
return 1 273 389
assign 1 277 401
secsGet 0 277 401
assign 1 277 402
greaterEquals 1 277 407
assign 1 0 408
assign 1 277 411
secsGet 0 277 411
assign 1 277 412
equals 1 277 417
assign 1 277 418
millisGet 0 277 418
assign 1 277 419
greaterEquals 1 277 424
assign 1 0 425
assign 1 0 428
assign 1 0 432
assign 1 0 435
assign 1 0 438
assign 1 278 442
new 0 278 442
return 1 278 443
assign 1 280 445
new 0 280 445
return 1 280 446
assign 1 284 458
secsGet 0 284 458
assign 1 284 459
lesserEquals 1 284 464
assign 1 0 465
assign 1 284 468
secsGet 0 284 468
assign 1 284 469
equals 1 284 474
assign 1 284 475
millisGet 0 284 475
assign 1 284 476
lesserEquals 1 284 481
assign 1 0 482
assign 1 0 485
assign 1 0 489
assign 1 0 492
assign 1 0 495
assign 1 285 499
new 0 285 499
return 1 285 500
assign 1 287 502
new 0 287 502
return 1 287 503
assign 1 291 515
sameClass 1 291 515
assign 1 291 517
secsGet 0 291 517
assign 1 291 518
equals 1 291 518
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 291 530
millisGet 0 291 530
assign 1 291 531
equals 1 291 531
assign 1 0 533
assign 1 0 536
assign 1 0 540
assign 1 292 543
new 0 292 543
return 1 292 544
assign 1 294 546
new 0 294 546
return 1 294 547
assign 1 298 560
sameClass 1 298 560
assign 1 298 561
not 0 298 566
assign 1 0 567
assign 1 298 570
secsGet 0 298 570
assign 1 298 571
notEquals 1 298 571
assign 1 0 573
assign 1 0 576
assign 1 0 580
assign 1 298 583
millisGet 0 298 583
assign 1 298 584
notEquals 1 298 584
assign 1 0 586
assign 1 0 589
assign 1 299 593
new 0 299 593
return 1 299 594
assign 1 301 596
new 0 301 596
return 1 301 597
assign 1 306 611
undef 1 306 616
assign 1 306 617
new 0 306 617
return 1 306 618
assign 1 307 620
millisGet 0 307 620
assign 1 307 621
equals 1 307 626
assign 1 308 627
secsGet 0 308 627
assign 1 308 628
subtract 1 308 628
assign 1 308 629
abs 0 308 629
assign 1 308 630
new 0 308 630
assign 1 308 631
equals 1 308 636
assign 1 309 637
new 0 309 637
return 1 309 638
assign 1 312 641
new 0 312 641
return 1 312 642
assign 1 316 656
minutesGet 0 316 656
assign 1 316 657
toString 0 316 657
assign 1 316 658
new 0 316 658
assign 1 316 659
add 1 316 659
assign 1 316 660
secondInMinuteGet 0 316 660
assign 1 316 661
add 1 316 661
assign 1 316 662
new 0 316 662
assign 1 316 663
add 1 316 663
assign 1 316 664
add 1 316 664
assign 1 316 665
new 0 316 665
assign 1 316 666
add 1 316 666
return 1 316 667
assign 1 320 675
toString 0 320 675
assign 1 320 676
new 0 320 676
assign 1 320 677
add 1 320 677
assign 1 320 678
toString 0 320 678
assign 1 320 679
add 1 320 679
return 1 320 680
assign 1 324 689
toString 0 324 689
assign 1 324 690
new 0 324 690
assign 1 324 691
add 1 324 691
assign 1 324 692
add 1 324 692
assign 1 324 693
new 0 324 693
assign 1 324 694
add 1 324 694
return 1 324 695
return 1 0 698
return 1 0 701
assign 1 0 704
assign 1 0 708
return 1 0 712
return 1 0 715
assign 1 0 718
assign 1 0 722
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2082927025: return bem_toString_0();
case 647020351: return bem_secondsGet_0();
case 766792083: return bem_new_0();
case 1790682890: return bem_fieldIteratorGet_0();
case -390339728: return bem_millisGet_0();
case 185075715: return bem_toAny_0();
case 755352436: return bem_now_0();
case -1945232493: return bem_echo_0();
case 811576986: return bem_minutesGet_0();
case 598542224: return bem_iteratorGet_0();
case 235139445: return bem_toStringMinutes_0();
case 619757843: return bem_once_0();
case -852280332: return bem_secondInMinuteGet_0();
case -1347905988: return bem_create_0();
case 1230480113: return bem_millisGetDirect_0();
case 92183996: return bem_secsGet_0();
case -1937236946: return bem_millisecondsGet_0();
case 1823740126: return bem_tagGet_0();
case -2077327881: return bem_serializationIteratorGet_0();
case 1289179027: return bem_toShortString_0();
case 438469697: return bem_fieldNamesGet_0();
case -1541505350: return bem_deserializeClassNameGet_0();
case 558155065: return bem_copy_0();
case 516740577: return bem_sourceFileNameGet_0();
case 66568862: return bem_serializeToString_0();
case -1404446512: return bem_hashGet_0();
case 1034158095: return bem_secsGetDirect_0();
case 1121159883: return bem_print_0();
case 1644437314: return bem_millisecondInSecondGet_0();
case -307935006: return bem_serializeContents_0();
case 1755722066: return bem_carryMillis_0();
case -301683900: return bem_many_0();
case 1100108870: return bem_classNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -95111894: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1530691970: return bem_otherClass_1(bevd_0);
case -907470247: return bem_sameObject_1(bevd_0);
case 1619296118: return bem_undefined_1(bevd_0);
case 138743388: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case -668310181: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 378746162: return bem_sameType_1(bevd_0);
case 620446157: return bem_millisSet_1(bevd_0);
case -1614351522: return bem_secsSet_1(bevd_0);
case 431153324: return bem_notEquals_1(bevd_0);
case 1279671780: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -25541341: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1315093896: return bem_defined_1(bevd_0);
case -887174444: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1872709810: return bem_equals_1(bevd_0);
case 314955640: return bem_def_1(bevd_0);
case 668057724: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1150573387: return bem_copyTo_1(bevd_0);
case 1868581166: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -37188374: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case -247467551: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1788117101: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -935074238: return bem_otherType_1(bevd_0);
case -656984361: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 486827812: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 860966827: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 844066392: return bem_sameClass_1(bevd_0);
case 328320361: return bem_millisSetDirect_1(bevd_0);
case -1011360434: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1378481920: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1407523089: return bem_undef_1(bevd_0);
case -1939653866: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -2024741503: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case -1665420080: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 2107748004: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case -768370819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1152490542: return bem_secsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 669366955: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -223228068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1903036726: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1132197362: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1915345411: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1939171826: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1309309215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 620336517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_TimeInterval_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_8_TimeInterval_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst = (BEC_2_4_8_TimeInterval) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_type;
}
}
