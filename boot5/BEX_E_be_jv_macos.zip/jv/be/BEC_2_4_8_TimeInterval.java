package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_BEC_2_4_8_TimeInterval_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_BEC_2_4_8_TimeInterval_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_0 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_1 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_2 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_3 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_4 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_5 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_6 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_7 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_11 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_14 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_15 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_16 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_17 = (new BEC_2_4_3_MathInt(3600));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_0, 10));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_1, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_2, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_3 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_3, 1));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_4 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_4, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_5 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_5, 13));
public static BEC_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_inst;

public static BET_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_type;

public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt());
bevp_millis = (new BEC_2_4_3_MathInt());

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_0;
bevt_0_tmpany_phold = bevp_secs.bem_modulus_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_1;
bevt_0_tmpany_phold = bevp_secs.bem_divide_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_2;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_3;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_5;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_6;
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_tmpany_phold);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_7;
bevt_4_tmpany_phold = bevp_millis.bem_divide_1(bevt_5_tmpany_phold);
bevp_secs = bevp_secs.bem_add_1(bevt_4_tmpany_phold);
bevp_millis = bevl_mmod;
} /* Line: 253 */
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_8;
if (bevp_millis.bevi_int < bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_9;
if (bevp_secs.bevi_int > bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 255 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 255 */
 else  /* Line: 255 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 255 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_10;
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_11;
bevp_millis = bevt_11_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 257 */
 else  /* Line: 255 */ {
bevt_13_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_12;
if (bevp_millis.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_13;
if (bevp_secs.bevi_int < bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 258 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 258 */
 else  /* Line: 258 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 258 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_14;
bevp_secs = bevp_secs.bem_add_1(bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_15;
bevt_19_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_16;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_subtract_1(bevt_19_tmpany_phold);
bevp_millis = bevt_17_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 260 */
} /* Line: 255 */
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 290 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 291 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
 else  /* Line: 297 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 297 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 297 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 298 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
 else  /* Line: 304 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 304 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 304 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 305 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 312 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_4_tmpany_phold = beva_other.bemd_0(-885717129);
bevt_3_tmpany_phold = bevp_secs.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 318 */
 else  /* Line: 318 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 318 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-460022558);
bevt_5_tmpany_phold = bevp_millis.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 318 */
 else  /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 318 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 319 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 325 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(-885717129);
bevt_4_tmpany_phold = bevp_secs.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 325 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 325 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 325 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 325 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(-460022558);
bevt_6_tmpany_phold = bevp_millis.bem_notEquals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 325 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 325 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 325 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_8_tmpany_phold;
} /* Line: 326 */
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
if (beva_other == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 333 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 333 */
bevt_3_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_7_tmpany_phold = beva_other.bem_secsGet_0();
bevt_6_tmpany_phold = bevp_secs.bem_subtract_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_abs_0();
bevt_8_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_17;
if (bevt_5_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 335 */ {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_9_tmpany_phold;
} /* Line: 336 */
} /* Line: 335 */
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_6_tmpany_phold = bem_minutesGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_toString_0();
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_18;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bem_secondInMinuteGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_19;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_20;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_secs.bem_toString_0();
bevt_3_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_21;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_millis.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_secs.bem_toString_0();
bevt_4_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_secsGetDirect_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_secsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public final BEC_2_4_3_MathInt bem_millisGetDirect_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_millisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {131, 132, 178, 179, 185, 186, 187, 191, 191, 195, 195, 195, 199, 203, 203, 203, 207, 211, 215, 219, 220, 224, 224, 224, 228, 228, 228, 232, 232, 232, 236, 236, 236, 241, 245, 246, 250, 250, 251, 251, 252, 252, 252, 253, 255, 255, 255, 255, 255, 255, 0, 0, 0, 256, 256, 257, 257, 258, 258, 258, 258, 258, 258, 0, 0, 0, 259, 259, 260, 260, 260, 260, 265, 269, 270, 274, 274, 275, 275, 276, 277, 278, 282, 282, 283, 283, 284, 285, 286, 290, 290, 290, 0, 290, 290, 290, 290, 290, 290, 0, 0, 0, 0, 0, 291, 291, 293, 293, 297, 297, 297, 0, 297, 297, 297, 297, 297, 297, 0, 0, 0, 0, 0, 298, 298, 300, 300, 304, 304, 304, 0, 304, 304, 304, 304, 304, 304, 0, 0, 0, 0, 0, 305, 305, 307, 307, 311, 311, 311, 0, 311, 311, 311, 311, 311, 311, 0, 0, 0, 0, 0, 312, 312, 314, 314, 318, 318, 318, 0, 0, 0, 318, 318, 0, 0, 0, 319, 319, 321, 321, 325, 325, 325, 0, 325, 325, 0, 0, 0, 325, 325, 0, 0, 326, 326, 328, 328, 333, 333, 333, 333, 334, 334, 334, 335, 335, 335, 335, 335, 335, 336, 336, 339, 339, 343, 343, 343, 343, 343, 343, 343, 343, 343, 343, 343, 343, 347, 347, 347, 347, 347, 347, 351, 351, 351, 351, 351, 351, 351, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 53, 54, 58, 59, 60, 65, 66, 71, 72, 73, 76, 81, 82, 83, 86, 89, 93, 96, 97, 103, 104, 105, 111, 112, 113, 119, 120, 121, 127, 128, 129, 133, 137, 138, 163, 164, 165, 170, 171, 172, 173, 174, 176, 177, 182, 183, 184, 189, 190, 193, 197, 200, 201, 202, 203, 206, 207, 212, 213, 214, 219, 220, 223, 227, 230, 231, 232, 233, 234, 235, 241, 245, 246, 255, 256, 257, 258, 259, 260, 261, 269, 270, 271, 272, 273, 274, 275, 287, 288, 293, 294, 297, 298, 303, 304, 305, 310, 311, 314, 318, 321, 324, 328, 329, 331, 332, 344, 345, 350, 351, 354, 355, 360, 361, 362, 367, 368, 371, 375, 378, 381, 385, 386, 388, 389, 401, 402, 407, 408, 411, 412, 417, 418, 419, 424, 425, 428, 432, 435, 438, 442, 443, 445, 446, 458, 459, 464, 465, 468, 469, 474, 475, 476, 481, 482, 485, 489, 492, 495, 499, 500, 502, 503, 515, 517, 518, 520, 523, 527, 530, 531, 533, 536, 540, 543, 544, 546, 547, 560, 561, 566, 567, 570, 571, 573, 576, 580, 583, 584, 586, 589, 593, 594, 596, 597, 611, 616, 617, 618, 620, 621, 626, 627, 628, 629, 630, 631, 636, 637, 638, 641, 642, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 675, 676, 677, 678, 679, 680, 689, 690, 691, 692, 693, 694, 695, 698, 701, 704, 708, 712, 715, 718, 722};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 131 44
new 0 131 44
assign 1 132 45
new 0 132 45
assign 1 178 53
new 0 178 53
assign 1 179 54
new 0 179 54
assign 1 185 58
assign 1 186 59
carryMillis 0 187 60
assign 1 191 65
new 2 191 65
return 1 191 66
assign 1 195 71
new 0 195 71
assign 1 195 72
modulus 1 195 72
return 1 195 73
return 1 199 76
assign 1 203 81
new 0 203 81
assign 1 203 82
divide 1 203 82
return 1 203 83
return 1 207 86
assign 1 211 89
return 1 215 93
assign 1 219 96
carryMillis 0 220 97
assign 1 224 103
new 0 224 103
assign 1 224 104
multiply 1 224 104
assign 1 224 105
add 1 224 105
assign 1 228 111
new 0 228 111
assign 1 228 112
multiply 1 228 112
assign 1 228 113
add 1 228 113
assign 1 232 119
new 0 232 119
assign 1 232 120
multiply 1 232 120
assign 1 232 121
subtract 1 232 121
assign 1 236 127
new 0 236 127
assign 1 236 128
multiply 1 236 128
assign 1 236 129
subtract 1 236 129
assign 1 241 133
add 1 241 133
assign 1 245 137
add 1 245 137
carryMillis 0 246 138
assign 1 250 163
new 0 250 163
assign 1 250 164
modulus 1 250 164
assign 1 251 165
notEquals 1 251 170
assign 1 252 171
new 0 252 171
assign 1 252 172
divide 1 252 172
assign 1 252 173
add 1 252 173
assign 1 253 174
assign 1 255 176
new 0 255 176
assign 1 255 177
lesser 1 255 182
assign 1 255 183
new 0 255 183
assign 1 255 184
greater 1 255 189
assign 1 0 190
assign 1 0 193
assign 1 0 197
assign 1 256 200
new 0 256 200
assign 1 256 201
subtract 1 256 201
assign 1 257 202
new 0 257 202
assign 1 257 203
add 1 257 203
assign 1 258 206
new 0 258 206
assign 1 258 207
greater 1 258 212
assign 1 258 213
new 0 258 213
assign 1 258 214
lesser 1 258 219
assign 1 0 220
assign 1 0 223
assign 1 0 227
assign 1 259 230
new 0 259 230
assign 1 259 231
add 1 259 231
assign 1 260 232
new 0 260 232
assign 1 260 233
new 0 260 233
assign 1 260 234
subtract 1 260 234
assign 1 260 235
add 1 260 235
assign 1 265 241
subtract 1 265 241
assign 1 269 245
subtract 1 269 245
carryMillis 0 270 246
assign 1 274 255
secsGet 0 274 255
assign 1 274 256
add 1 274 256
assign 1 275 257
millisGet 0 275 257
assign 1 275 258
add 1 275 258
assign 1 276 259
new 2 276 259
carryMillis 0 277 260
return 1 278 261
assign 1 282 269
secsGet 0 282 269
assign 1 282 270
subtract 1 282 270
assign 1 283 271
millisGet 0 283 271
assign 1 283 272
subtract 1 283 272
assign 1 284 273
new 2 284 273
carryMillis 0 285 274
return 1 286 275
assign 1 290 287
secsGet 0 290 287
assign 1 290 288
greater 1 290 293
assign 1 0 294
assign 1 290 297
secsGet 0 290 297
assign 1 290 298
equals 1 290 303
assign 1 290 304
millisGet 0 290 304
assign 1 290 305
greater 1 290 310
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 0 321
assign 1 0 324
assign 1 291 328
new 0 291 328
return 1 291 329
assign 1 293 331
new 0 293 331
return 1 293 332
assign 1 297 344
secsGet 0 297 344
assign 1 297 345
lesser 1 297 350
assign 1 0 351
assign 1 297 354
secsGet 0 297 354
assign 1 297 355
equals 1 297 360
assign 1 297 361
millisGet 0 297 361
assign 1 297 362
lesser 1 297 367
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 0 378
assign 1 0 381
assign 1 298 385
new 0 298 385
return 1 298 386
assign 1 300 388
new 0 300 388
return 1 300 389
assign 1 304 401
secsGet 0 304 401
assign 1 304 402
greaterEquals 1 304 407
assign 1 0 408
assign 1 304 411
secsGet 0 304 411
assign 1 304 412
equals 1 304 417
assign 1 304 418
millisGet 0 304 418
assign 1 304 419
greaterEquals 1 304 424
assign 1 0 425
assign 1 0 428
assign 1 0 432
assign 1 0 435
assign 1 0 438
assign 1 305 442
new 0 305 442
return 1 305 443
assign 1 307 445
new 0 307 445
return 1 307 446
assign 1 311 458
secsGet 0 311 458
assign 1 311 459
lesserEquals 1 311 464
assign 1 0 465
assign 1 311 468
secsGet 0 311 468
assign 1 311 469
equals 1 311 474
assign 1 311 475
millisGet 0 311 475
assign 1 311 476
lesserEquals 1 311 481
assign 1 0 482
assign 1 0 485
assign 1 0 489
assign 1 0 492
assign 1 0 495
assign 1 312 499
new 0 312 499
return 1 312 500
assign 1 314 502
new 0 314 502
return 1 314 503
assign 1 318 515
sameClass 1 318 515
assign 1 318 517
secsGet 0 318 517
assign 1 318 518
equals 1 318 518
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 318 530
millisGet 0 318 530
assign 1 318 531
equals 1 318 531
assign 1 0 533
assign 1 0 536
assign 1 0 540
assign 1 319 543
new 0 319 543
return 1 319 544
assign 1 321 546
new 0 321 546
return 1 321 547
assign 1 325 560
sameClass 1 325 560
assign 1 325 561
not 0 325 566
assign 1 0 567
assign 1 325 570
secsGet 0 325 570
assign 1 325 571
notEquals 1 325 571
assign 1 0 573
assign 1 0 576
assign 1 0 580
assign 1 325 583
millisGet 0 325 583
assign 1 325 584
notEquals 1 325 584
assign 1 0 586
assign 1 0 589
assign 1 326 593
new 0 326 593
return 1 326 594
assign 1 328 596
new 0 328 596
return 1 328 597
assign 1 333 611
undef 1 333 616
assign 1 333 617
new 0 333 617
return 1 333 618
assign 1 334 620
millisGet 0 334 620
assign 1 334 621
equals 1 334 626
assign 1 335 627
secsGet 0 335 627
assign 1 335 628
subtract 1 335 628
assign 1 335 629
abs 0 335 629
assign 1 335 630
new 0 335 630
assign 1 335 631
equals 1 335 636
assign 1 336 637
new 0 336 637
return 1 336 638
assign 1 339 641
new 0 339 641
return 1 339 642
assign 1 343 656
minutesGet 0 343 656
assign 1 343 657
toString 0 343 657
assign 1 343 658
new 0 343 658
assign 1 343 659
add 1 343 659
assign 1 343 660
secondInMinuteGet 0 343 660
assign 1 343 661
add 1 343 661
assign 1 343 662
new 0 343 662
assign 1 343 663
add 1 343 663
assign 1 343 664
add 1 343 664
assign 1 343 665
new 0 343 665
assign 1 343 666
add 1 343 666
return 1 343 667
assign 1 347 675
toString 0 347 675
assign 1 347 676
new 0 347 676
assign 1 347 677
add 1 347 677
assign 1 347 678
toString 0 347 678
assign 1 347 679
add 1 347 679
return 1 347 680
assign 1 351 689
toString 0 351 689
assign 1 351 690
new 0 351 690
assign 1 351 691
add 1 351 691
assign 1 351 692
add 1 351 692
assign 1 351 693
new 0 351 693
assign 1 351 694
add 1 351 694
return 1 351 695
return 1 0 698
return 1 0 701
assign 1 0 704
assign 1 0 708
return 1 0 712
return 1 0 715
assign 1 0 718
assign 1 0 722
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 853990827: return bem_secsGetDirect_0();
case 645874772: return bem_secondsGet_0();
case -1894090923: return bem_toString_0();
case -808123537: return bem_hashGet_0();
case -1706743432: return bem_iteratorGet_0();
case -1602615308: return bem_fieldIteratorGet_0();
case 1063076701: return bem_toShortString_0();
case 1606613844: return bem_echo_0();
case 1377047095: return bem_serializeToString_0();
case -1442653865: return bem_serializationIteratorGet_0();
case -460022558: return bem_millisGet_0();
case 126468261: return bem_carryMillis_0();
case -295553573: return bem_new_0();
case -885717129: return bem_secsGet_0();
case -1293087442: return bem_toStringMinutes_0();
case -1460543860: return bem_fieldNamesGet_0();
case -493975186: return bem_create_0();
case -41381797: return bem_copy_0();
case -802767414: return bem_deserializeClassNameGet_0();
case 1995263218: return bem_now_0();
case 954806602: return bem_millisecondInSecondGet_0();
case -1396413274: return bem_classNameGet_0();
case 899896295: return bem_print_0();
case -2071452709: return bem_serializeContents_0();
case 920799299: return bem_secondInMinuteGet_0();
case 85669346: return bem_once_0();
case -741296036: return bem_millisGetDirect_0();
case 874569701: return bem_toAny_0();
case -1794506213: return bem_many_0();
case 1654522783: return bem_minutesGet_0();
case -1333837278: return bem_tagGet_0();
case 1523861211: return bem_sourceFileNameGet_0();
case 1135468981: return bem_millisecondsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 302929355: return bem_millisSet_1(bevd_0);
case -1302857942: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1328285078: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -920243169: return bem_sameObject_1(bevd_0);
case -549009581: return bem_secsSetDirect_1(bevd_0);
case -2123613587: return bem_notEquals_1(bevd_0);
case 513235438: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case 1026839545: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case 1213137777: return bem_undef_1(bevd_0);
case 53407038: return bem_equals_1(bevd_0);
case 251588443: return bem_otherType_1(bevd_0);
case -1320627528: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case -467808258: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1013111015: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 511913436: return bem_millisSetDirect_1(bevd_0);
case 966131902: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -248445758: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 940992628: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case 681008598: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -272838728: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1829433968: return bem_otherClass_1(bevd_0);
case 94861458: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1820065451: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1152576261: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case -319164445: return bem_undefined_1(bevd_0);
case 391192402: return bem_copyTo_1(bevd_0);
case -194482552: return bem_sameType_1(bevd_0);
case 652115224: return bem_def_1(bevd_0);
case 1952247889: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 1605669271: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1989300932: return bem_sameClass_1(bevd_0);
case 284248916: return bem_defined_1(bevd_0);
case -1010277108: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -794252146: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 37539052: return bem_secsSet_1(bevd_0);
case -154652680: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case 418713924: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1874085610: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1865862746: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736065910: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1057911785: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -620653407: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1158884482: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126000923: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1221539498: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_TimeInterval_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_8_TimeInterval_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst = (BEC_2_4_8_TimeInterval) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_type;
}
}
