package be;
public class BET_2_5_6_BuildMethod extends BETS_Object {
public BET_2_5_6_BuildMethod() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "nameGet_0", "nameSet_1", "orgNameGet_0", "orgNameSet_1", "numargsGet_0", "numargsSet_1", "propertyGet_0", "propertySet_1", "rtypeGet_0", "rtypeSet_1", "tmpVarsGet_0", "tmpVarsSet_1", "anyMapGet_0", "anyMapSet_1", "orderedVarsGet_0", "orderedVarsSet_1", "tmpCntGet_0", "tmpCntSet_1", "isGenAccessorGet_0", "isGenAccessorSet_1", "tryDepthGet_0", "tryDepthSet_1", "isFinalGet_0", "isFinalSet_1", "amaxGet_0", "amaxSet_1", "hmaxGet_0", "hmaxSet_1", "mmaxGet_0", "mmaxSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "name", "orgName", "numargs", "property", "rtype", "tmpVars", "anyMap", "orderedVars", "tmpCnt", "isGenAccessor", "tryDepth", "isFinal", "amax", "hmax", "mmax" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_6_BuildMethod();
}
}
