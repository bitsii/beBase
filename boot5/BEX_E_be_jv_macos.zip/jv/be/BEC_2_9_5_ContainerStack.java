package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
private static byte[] becc_BEC_2_9_5_ContainerStack_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_BEC_2_9_5_ContainerStack_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_inst;

public static BET_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_5_ContainerStack bem_new_0() throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_push_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_ta_ph = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevp_holder == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 45*/ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 46*/
 else /* Line: 47*/ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 49*/
} /* Line: 45*/
 else /* Line: 44*/ {
bevt_3_ta_ph = bevp_top.bem_nextGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_4_ta_ph = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_ta_ph);
bevt_5_ta_ph = bevp_top.bem_nextGet_0();
bevt_5_ta_ph.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 54*/
 else /* Line: 55*/ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 56*/
} /* Line: 44*/
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_pop_0() throws Throwable {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 63*/ {
return bevp_top;
} /* Line: 64*/
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 68*/ {
bevp_holder = bevl_last;
} /* Line: 69*/
if (bevl_last == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 71*/ {
return null;
} /* Line: 72*/
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_2_6_6_SystemObject bem_peek_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 81*/ {
return bevp_top;
} /* Line: 82*/
bevt_1_ta_ph = bevp_top.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_top == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_pop_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_pop.bevi_bool)/* Line: 100*/ {
bevt_0_ta_ph = bem_pop_0();
return bevt_0_ta_ph;
} /* Line: 101*/
bevt_1_ta_ph = bem_peek_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() throws Throwable {
return bevp_holder;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 44, 44, 45, 45, 46, 48, 49, 51, 51, 51, 52, 52, 53, 53, 54, 56, 58, 59, 63, 63, 64, 66, 67, 68, 68, 69, 71, 71, 72, 74, 75, 76, 77, 81, 81, 82, 84, 84, 88, 88, 92, 96, 96, 101, 101, 103, 103, 107, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 25, 30, 31, 36, 37, 40, 41, 45, 46, 51, 52, 53, 54, 55, 56, 59, 62, 63, 72, 77, 78, 80, 81, 82, 87, 88, 90, 95, 96, 98, 99, 100, 101, 106, 111, 112, 114, 115, 119, 124, 127, 132, 133, 139, 140, 142, 143, 146, 150, 153, 157, 160, 164, 167};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 38 15
new 0 38 15
assign 1 44 25
undef 1 44 30
assign 1 45 31
undef 1 45 36
assign 1 46 37
new 0 46 37
assign 1 48 40
assign 1 49 41
assign 1 51 45
nextGet 0 51 45
assign 1 51 46
undef 1 51 51
assign 1 52 52
new 0 52 52
nextSet 1 52 53
assign 1 53 54
nextGet 0 53 54
priorSet 1 53 55
assign 1 54 56
nextGet 0 54 56
assign 1 56 59
nextGet 0 56 59
heldSet 1 58 62
assign 1 59 63
increment 0 59 63
assign 1 63 72
undef 1 63 77
return 1 64 78
assign 1 66 80
assign 1 67 81
priorGet 0 67 81
assign 1 68 82
undef 1 68 87
assign 1 69 88
assign 1 71 90
undef 1 71 95
return 1 72 96
assign 1 74 98
heldGet 0 74 98
heldSet 1 75 99
assign 1 76 100
decrement 0 76 100
return 1 77 101
assign 1 81 106
undef 1 81 111
return 1 82 112
assign 1 84 114
heldGet 0 84 114
return 1 84 115
assign 1 88 119
undef 1 88 124
return 1 88 124
push 1 92 127
assign 1 96 132
pop 0 96 132
return 1 96 133
assign 1 101 139
pop 0 101 139
return 1 101 140
assign 1 103 142
peek 0 103 142
return 1 103 143
push 1 107 146
return 1 0 150
assign 1 0 153
return 1 0 157
assign 1 0 160
return 1 0 164
assign 1 0 167
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1478791536: return bem_peek_0();
case -1924399923: return bem_sizeGet_0();
case -303434167: return bem_copy_0();
case -812427611: return bem_holderGet_0();
case -141417330: return bem_isEmptyGet_0();
case 694867988: return bem_toString_0();
case -290716967: return bem_pop_0();
case -814788939: return bem_create_0();
case 1680733853: return bem_print_0();
case -758107855: return bem_new_0();
case -2136008673: return bem_topGet_0();
case 1479557703: return bem_hashGet_0();
case 1173678142: return bem_get_0();
case 688799135: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1571586940: return bem_addValue_1(bevd_0);
case -64545429: return bem_sizeSet_1(bevd_0);
case -1721664005: return bem_copyTo_1(bevd_0);
case 283685995: return bem_equals_1(bevd_0);
case 1138444822: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case 76893949: return bem_push_1(bevd_0);
case -342347837: return bem_holderSet_1(bevd_0);
case 916104524: return bem_topSet_1(bevd_0);
case 342133054: return bem_undef_1(bevd_0);
case -1888177940: return bem_notEquals_1(bevd_0);
case 1906491870: return bem_put_1(bevd_0);
case -376840077: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1773263525: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 807856101: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -739362181: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1388702842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerStack_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerStack_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerStack();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst = (BEC_2_9_5_ContainerStack) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_type;
}
}
