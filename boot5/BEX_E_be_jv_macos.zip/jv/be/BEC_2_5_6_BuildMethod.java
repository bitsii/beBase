package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_6_BuildMethod extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
private static byte[] becc_BEC_2_5_6_BuildMethod_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_5_6_BuildMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_0 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_0, 1));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_1, 7));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_2, 10));
public static BEC_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_inst;

public static BET_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public BEC_2_5_6_BuildMethod bem_new_0() throws Throwable {
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = be.BECS_Runtime.boolFalse;
bevp_tryDepth = (new BEC_2_4_3_MathInt(0));
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_amax = (new BEC_2_4_3_MathInt(0));
bevp_hmax = (new BEC_2_4_3_MathInt(0));
bevp_mmax = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_0;
bevl_ret = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
if (bevp_name == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_1;
bevt_3_tmpany_phold = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 184 */
if (bevp_numargs == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_2;
bevt_7_tmpany_phold = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
} /* Line: 187 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() throws Throwable {
return bevp_property;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() throws Throwable {
return bevp_rtype;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() throws Throwable {
return bevp_tmpVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() throws Throwable {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() throws Throwable {
return bevp_tryDepth;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() throws Throwable {
return bevp_amax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() throws Throwable {
return bevp_hmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() throws Throwable {
return bevp_mmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {167, 168, 169, 170, 171, 172, 174, 175, 176, 182, 182, 182, 183, 183, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 189, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {33, 34, 35, 36, 37, 38, 39, 40, 41, 56, 57, 58, 59, 64, 65, 66, 67, 68, 70, 75, 76, 77, 78, 79, 81, 84, 87, 91, 94, 98, 101, 105, 108, 112, 115, 119, 122, 126, 129, 133, 136, 140, 143, 147, 150, 154, 157, 161, 164, 168, 171, 175, 178, 182, 185};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 167 33
new 0 167 33
assign 1 168 34
new 0 168 34
assign 1 169 35
new 0 169 35
assign 1 170 36
new 0 170 36
assign 1 171 37
new 0 171 37
assign 1 172 38
new 0 172 38
assign 1 174 39
new 0 174 39
assign 1 175 40
new 0 175 40
assign 1 176 41
new 0 176 41
assign 1 182 56
classNameGet 0 182 56
assign 1 182 57
new 0 182 57
assign 1 182 58
add 1 182 58
assign 1 183 59
def 1 183 64
assign 1 184 65
new 0 184 65
assign 1 184 66
add 1 184 66
assign 1 184 67
toString 0 184 67
assign 1 184 68
add 1 184 68
assign 1 186 70
def 1 186 75
assign 1 187 76
new 0 187 76
assign 1 187 77
add 1 187 77
assign 1 187 78
toString 0 187 78
assign 1 187 79
add 1 187 79
return 1 189 81
return 1 0 84
assign 1 0 87
return 1 0 91
assign 1 0 94
return 1 0 98
assign 1 0 101
return 1 0 105
assign 1 0 108
return 1 0 112
assign 1 0 115
return 1 0 119
assign 1 0 122
return 1 0 126
assign 1 0 129
return 1 0 133
assign 1 0 136
return 1 0 140
assign 1 0 143
return 1 0 147
assign 1 0 150
return 1 0 154
assign 1 0 157
return 1 0 161
assign 1 0 164
return 1 0 168
assign 1 0 171
return 1 0 175
assign 1 0 178
return 1 0 182
assign 1 0 185
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1793221455: return bem_copy_0();
case -980884323: return bem_new_0();
case -1226625126: return bem_once_0();
case 810966533: return bem_isGenAccessorGet_0();
case 385481188: return bem_propertyGet_0();
case 279012064: return bem_anyMapGet_0();
case 2049066942: return bem_fieldIteratorGet_0();
case 1310553601: return bem_toString_0();
case -1565549870: return bem_print_0();
case 489788599: return bem_serializeContents_0();
case -1216705188: return bem_rtypeGet_0();
case -388793920: return bem_amaxGet_0();
case 1924413487: return bem_hashGet_0();
case 1267038473: return bem_mmaxGet_0();
case 1150664853: return bem_create_0();
case 2052709534: return bem_many_0();
case 1627226096: return bem_isFinalGet_0();
case 332981262: return bem_deserializeClassNameGet_0();
case 1604962015: return bem_sourceFileNameGet_0();
case -290041240: return bem_serializeToString_0();
case -1897026239: return bem_echo_0();
case 194016774: return bem_iteratorGet_0();
case 10974216: return bem_tmpCntGet_0();
case 1535974186: return bem_nameGet_0();
case -732524867: return bem_tagGet_0();
case 1078093917: return bem_orderedVarsGet_0();
case -1535847383: return bem_toAny_0();
case -525681067: return bem_classNameGet_0();
case 1786697837: return bem_tmpVarsGet_0();
case -313910974: return bem_tryDepthGet_0();
case 855556032: return bem_hmaxGet_0();
case -1920531733: return bem_serializationIteratorGet_0();
case 683694998: return bem_numargsGet_0();
case -1441001025: return bem_orgNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1337443961: return bem_tmpVarsSet_1(bevd_0);
case -841467635: return bem_tryDepthSet_1(bevd_0);
case 1693216688: return bem_sameClass_1(bevd_0);
case -2056939433: return bem_numargsSet_1(bevd_0);
case 2046554140: return bem_orderedVarsSet_1(bevd_0);
case -1457264008: return bem_mmaxSet_1(bevd_0);
case -145738070: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 863435643: return bem_equals_1(bevd_0);
case -386255686: return bem_rtypeSet_1(bevd_0);
case 1868528499: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1545437990: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 420384947: return bem_def_1(bevd_0);
case 1998776126: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 595584893: return bem_isGenAccessorSet_1(bevd_0);
case 1056943378: return bem_amaxSet_1(bevd_0);
case -1021436824: return bem_sameType_1(bevd_0);
case -467299687: return bem_defined_1(bevd_0);
case -1834098557: return bem_notEquals_1(bevd_0);
case -140891486: return bem_propertySet_1(bevd_0);
case 562081982: return bem_undefined_1(bevd_0);
case -1966507736: return bem_undef_1(bevd_0);
case 1888138043: return bem_hmaxSet_1(bevd_0);
case 802820856: return bem_anyMapSet_1(bevd_0);
case 959360624: return bem_otherType_1(bevd_0);
case -800435727: return bem_tmpCntSet_1(bevd_0);
case 1804529497: return bem_orgNameSet_1(bevd_0);
case -785712890: return bem_isFinalSet_1(bevd_0);
case 257405303: return bem_copyTo_1(bevd_0);
case 386836188: return bem_otherClass_1(bevd_0);
case -2104330508: return bem_sameObject_1(bevd_0);
case -1635666086: return bem_nameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1240676558: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -371043039: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1325559256: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1035622269: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -145115514: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686918154: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1895634211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMethod_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_6_BuildMethod_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMethod();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst = (BEC_2_5_6_BuildMethod) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_type;
}
}
