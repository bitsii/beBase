package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_6_BuildMethod extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
private static byte[] becc_BEC_2_5_6_BuildMethod_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_5_6_BuildMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_0 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_0, 1));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_1, 7));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_2, 10));
public static BEC_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_inst;

public static BET_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public BEC_2_5_6_BuildMethod bem_new_0() throws Throwable {
bevp_anyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = be.BECS_Runtime.boolFalse;
bevp_tryDepth = (new BEC_2_4_3_MathInt(0));
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_amax = (new BEC_2_4_3_MathInt(0));
bevp_hmax = (new BEC_2_4_3_MathInt(0));
bevp_mmax = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_0;
bevl_ret = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
if (bevp_name == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_1;
bevt_3_tmpany_phold = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 184 */
if (bevp_numargs == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_2;
bevt_7_tmpany_phold = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
} /* Line: 187 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public final BEC_2_4_6_TextString bem_orgNameGetDirect_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public final BEC_2_4_3_MathInt bem_numargsGetDirect_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() throws Throwable {
return bevp_property;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_propertyGetDirect_0() throws Throwable {
return bevp_property;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_propertySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() throws Throwable {
return bevp_rtype;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_rtypeGetDirect_0() throws Throwable {
return bevp_rtype;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_rtypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() throws Throwable {
return bevp_tmpVars;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_tmpVarsGetDirect_0() throws Throwable {
return bevp_tmpVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_tmpVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() throws Throwable {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() throws Throwable {
return bevp_tmpCnt;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tmpCntGetDirect_0() throws Throwable {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_tmpCntSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isGenAccessorGetDirect_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_isGenAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() throws Throwable {
return bevp_tryDepth;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tryDepthGetDirect_0() throws Throwable {
return bevp_tryDepth;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_tryDepthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() throws Throwable {
return bevp_amax;
} /*method end*/
public final BEC_2_4_3_MathInt bem_amaxGetDirect_0() throws Throwable {
return bevp_amax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_amaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() throws Throwable {
return bevp_hmax;
} /*method end*/
public final BEC_2_4_3_MathInt bem_hmaxGetDirect_0() throws Throwable {
return bevp_hmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_hmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() throws Throwable {
return bevp_mmax;
} /*method end*/
public final BEC_2_4_3_MathInt bem_mmaxGetDirect_0() throws Throwable {
return bevp_mmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildMethod bem_mmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {167, 168, 169, 170, 171, 172, 174, 175, 176, 182, 182, 182, 183, 183, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 189, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {33, 34, 35, 36, 37, 38, 39, 40, 41, 56, 57, 58, 59, 64, 65, 66, 67, 68, 70, 75, 76, 77, 78, 79, 81, 84, 87, 90, 94, 98, 101, 104, 108, 112, 115, 118, 122, 126, 129, 132, 136, 140, 143, 146, 150, 154, 157, 160, 164, 168, 171, 174, 178, 182, 185, 188, 192, 196, 199, 202, 206, 210, 213, 216, 220, 224, 227, 230, 234, 238, 241, 244, 248, 252, 255, 258, 262, 266, 269, 272, 276, 280, 283, 286, 290};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 167 33
new 0 167 33
assign 1 168 34
new 0 168 34
assign 1 169 35
new 0 169 35
assign 1 170 36
new 0 170 36
assign 1 171 37
new 0 171 37
assign 1 172 38
new 0 172 38
assign 1 174 39
new 0 174 39
assign 1 175 40
new 0 175 40
assign 1 176 41
new 0 176 41
assign 1 182 56
classNameGet 0 182 56
assign 1 182 57
new 0 182 57
assign 1 182 58
add 1 182 58
assign 1 183 59
def 1 183 64
assign 1 184 65
new 0 184 65
assign 1 184 66
add 1 184 66
assign 1 184 67
toString 0 184 67
assign 1 184 68
add 1 184 68
assign 1 186 70
def 1 186 75
assign 1 187 76
new 0 187 76
assign 1 187 77
add 1 187 77
assign 1 187 78
toString 0 187 78
assign 1 187 79
add 1 187 79
return 1 189 81
return 1 0 84
return 1 0 87
assign 1 0 90
assign 1 0 94
return 1 0 98
return 1 0 101
assign 1 0 104
assign 1 0 108
return 1 0 112
return 1 0 115
assign 1 0 118
assign 1 0 122
return 1 0 126
return 1 0 129
assign 1 0 132
assign 1 0 136
return 1 0 140
return 1 0 143
assign 1 0 146
assign 1 0 150
return 1 0 154
return 1 0 157
assign 1 0 160
assign 1 0 164
return 1 0 168
return 1 0 171
assign 1 0 174
assign 1 0 178
return 1 0 182
return 1 0 185
assign 1 0 188
assign 1 0 192
return 1 0 196
return 1 0 199
assign 1 0 202
assign 1 0 206
return 1 0 210
return 1 0 213
assign 1 0 216
assign 1 0 220
return 1 0 224
return 1 0 227
assign 1 0 230
assign 1 0 234
return 1 0 238
return 1 0 241
assign 1 0 244
assign 1 0 248
return 1 0 252
return 1 0 255
assign 1 0 258
assign 1 0 262
return 1 0 266
return 1 0 269
assign 1 0 272
assign 1 0 276
return 1 0 280
return 1 0 283
assign 1 0 286
assign 1 0 290
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2077327881: return bem_serializationIteratorGet_0();
case 1502881634: return bem_nameGet_0();
case 766792083: return bem_new_0();
case -301683900: return bem_many_0();
case -2082927025: return bem_toString_0();
case 1655329034: return bem_orgNameGetDirect_0();
case 1457020879: return bem_orderedVarsGetDirect_0();
case 1451885891: return bem_rtypeGetDirect_0();
case 516740577: return bem_sourceFileNameGet_0();
case -1374721262: return bem_amaxGetDirect_0();
case -1945232493: return bem_echo_0();
case 1399200627: return bem_numargsGetDirect_0();
case -715582487: return bem_tryDepthGet_0();
case 163447479: return bem_isGenAccessorGet_0();
case 1870298171: return bem_mmaxGet_0();
case -405632135: return bem_nameGetDirect_0();
case 99385299: return bem_hmaxGetDirect_0();
case -1315114567: return bem_isFinalGet_0();
case 1178433090: return bem_propertyGetDirect_0();
case 619757843: return bem_once_0();
case 185075715: return bem_toAny_0();
case -1559595575: return bem_anyMapGet_0();
case -409487844: return bem_tmpVarsGetDirect_0();
case 598542224: return bem_iteratorGet_0();
case -1203097441: return bem_hmaxGet_0();
case 558155065: return bem_copy_0();
case -307935006: return bem_serializeContents_0();
case 471801935: return bem_tmpCntGet_0();
case 1121159883: return bem_print_0();
case -1358570017: return bem_propertyGet_0();
case 257956242: return bem_amaxGet_0();
case 1790682890: return bem_fieldIteratorGet_0();
case 1319243639: return bem_anyMapGetDirect_0();
case 1100108870: return bem_classNameGet_0();
case 1158242363: return bem_mmaxGetDirect_0();
case 1566572659: return bem_tmpCntGetDirect_0();
case 1361618286: return bem_tmpVarsGet_0();
case -536236851: return bem_isGenAccessorGetDirect_0();
case 1184972334: return bem_numargsGet_0();
case -438814914: return bem_isFinalGetDirect_0();
case -1404446512: return bem_hashGet_0();
case 66568862: return bem_serializeToString_0();
case 438469697: return bem_fieldNamesGet_0();
case -1347905988: return bem_create_0();
case -650846444: return bem_orderedVarsGet_0();
case -1242768835: return bem_rtypeGet_0();
case -179994472: return bem_orgNameGet_0();
case -1541505350: return bem_deserializeClassNameGet_0();
case -2071233721: return bem_tryDepthGetDirect_0();
case 1823740126: return bem_tagGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 431153324: return bem_notEquals_1(bevd_0);
case -485487099: return bem_tryDepthSetDirect_1(bevd_0);
case 314955640: return bem_def_1(bevd_0);
case -907470247: return bem_sameObject_1(bevd_0);
case 40744061: return bem_isGenAccessorSetDirect_1(bevd_0);
case -1079764316: return bem_propertySet_1(bevd_0);
case -1616378772: return bem_amaxSet_1(bevd_0);
case -935074238: return bem_otherType_1(bevd_0);
case -405079329: return bem_isGenAccessorSet_1(bevd_0);
case -307944692: return bem_orgNameSetDirect_1(bevd_0);
case 1619296118: return bem_undefined_1(bevd_0);
case 1575047697: return bem_mmaxSet_1(bevd_0);
case -491021656: return bem_numargsSet_1(bevd_0);
case 1872709810: return bem_equals_1(bevd_0);
case 1315093896: return bem_defined_1(bevd_0);
case -1435077746: return bem_nameSet_1(bevd_0);
case 378746162: return bem_sameType_1(bevd_0);
case 1575862482: return bem_hmaxSet_1(bevd_0);
case -1788117101: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1407523089: return bem_undef_1(bevd_0);
case 1095862977: return bem_anyMapSet_1(bevd_0);
case 262016470: return bem_orderedVarsSet_1(bevd_0);
case 1530691970: return bem_otherClass_1(bevd_0);
case 1014008402: return bem_isFinalSetDirect_1(bevd_0);
case 782142285: return bem_hmaxSetDirect_1(bevd_0);
case 844066392: return bem_sameClass_1(bevd_0);
case -576561066: return bem_orgNameSet_1(bevd_0);
case 1868581166: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -386234568: return bem_tmpVarsSetDirect_1(bevd_0);
case -1572431789: return bem_nameSetDirect_1(bevd_0);
case 51577753: return bem_rtypeSetDirect_1(bevd_0);
case 1150573387: return bem_copyTo_1(bevd_0);
case -768370819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2040383023: return bem_tryDepthSet_1(bevd_0);
case -447279189: return bem_amaxSetDirect_1(bevd_0);
case 1747278689: return bem_mmaxSetDirect_1(bevd_0);
case 2067852372: return bem_orderedVarsSetDirect_1(bevd_0);
case -1150320968: return bem_tmpCntSet_1(bevd_0);
case -1350837949: return bem_anyMapSetDirect_1(bevd_0);
case 1378481920: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1479200569: return bem_tmpVarsSet_1(bevd_0);
case -1809521000: return bem_isFinalSet_1(bevd_0);
case 589163645: return bem_numargsSetDirect_1(bevd_0);
case 131851758: return bem_tmpCntSetDirect_1(bevd_0);
case -898646557: return bem_rtypeSet_1(bevd_0);
case -1169010809: return bem_propertySetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 669366955: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -223228068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1903036726: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1915345411: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1939171826: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1309309215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 620336517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMethod_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_6_BuildMethod_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMethod();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst = (BEC_2_5_6_BuildMethod) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_type;
}
}
