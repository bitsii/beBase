package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_16_ContainerMapKeyValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_16_ContainerMapKeyValueIterator() { }
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4B,0x65,0x79,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;

public static BET_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bevp_onNode;
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_onNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 562*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 563*/
bevt_2_ta_ph = super.bem_hasNextGet_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_onNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 569*/ {
bevl_toRet = bevp_onNode.bemd_0(240072034);
bevp_onNode = null;
return bevl_toRet;
} /* Line: 572*/
bevp_onNode = super.bem_nextGet_0();
if (bevp_onNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 575*/ {
bevt_2_ta_ph = bevp_onNode.bemd_0(1284777964);
return bevt_2_ta_ph;
} /* Line: 576*/
return bevp_onNode;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {558, 562, 562, 563, 563, 565, 565, 569, 569, 570, 571, 572, 574, 575, 575, 576, 576, 578};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 20, 25, 26, 27, 29, 30, 37, 42, 43, 44, 45, 47, 48, 53, 54, 55, 57};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 558 13
assign 1 562 20
def 1 562 25
assign 1 563 26
new 0 563 26
return 1 563 27
assign 1 565 29
hasNextGet 0 565 29
return 1 565 30
assign 1 569 37
def 1 569 42
assign 1 570 43
valueGet 0 570 43
assign 1 571 44
return 1 572 45
assign 1 574 47
nextGet 0 574 47
assign 1 575 48
def 1 575 53
assign 1 576 54
keyGet 0 576 54
return 1 576 55
return 1 578 57
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1500345660: return bem_new_0();
case 1914698093: return bem_copy_0();
case -2044808959: return bem_create_0();
case 2085438758: return bem_hasNextGet_0();
case -575654519: return bem_nextGet_0();
case 1425769413: return bem_delete_0();
case 2041079581: return bem_nodeIteratorIteratorGet_0();
case 701056781: return bem_print_0();
case 403207358: return bem_hashGet_0();
case 332374972: return bem_toString_0();
case -411352811: return bem_iteratorGet_0();
case 1647228970: return bem_containerGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2093081199: return bem_equals_1(bevd_0);
case 1056390040: return bem_notEquals_1(bevd_0);
case -192085192: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -183213474: return bem_copyTo_1(bevd_0);
case -2091475700: return bem_def_1(bevd_0);
case 242448501: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1734287964: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1748111499: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1968238059: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1944821118: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_16_ContainerMapKeyValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst = (BEC_3_9_3_16_ContainerMapKeyValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;
}
}
