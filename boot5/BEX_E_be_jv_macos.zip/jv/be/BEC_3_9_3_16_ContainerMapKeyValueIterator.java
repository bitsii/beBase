package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_16_ContainerMapKeyValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_16_ContainerMapKeyValueIterator() { }
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4B,0x65,0x79,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;

public static BET_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bevp_onNode;
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_onNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 560*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 561*/
bevt_2_ta_ph = super.bem_hasNextGet_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_onNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 567*/ {
bevl_toRet = bevp_onNode.bemd_0(1173069690);
bevp_onNode = null;
return bevl_toRet;
} /* Line: 570*/
bevp_onNode = super.bem_nextGet_0();
if (bevp_onNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 573*/ {
bevt_2_ta_ph = bevp_onNode.bemd_0(-1209764892);
return bevt_2_ta_ph;
} /* Line: 574*/
return bevp_onNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onNodeGet_0() throws Throwable {
return bevp_onNode;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_onNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_onNode = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {556, 560, 560, 561, 561, 563, 563, 567, 567, 568, 569, 570, 572, 573, 573, 574, 574, 576, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 20, 25, 26, 27, 29, 30, 37, 42, 43, 44, 45, 47, 48, 53, 54, 55, 57, 60, 63};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 556 13
assign 1 560 20
def 1 560 25
assign 1 561 26
new 0 561 26
return 1 561 27
assign 1 563 29
hasNextGet 0 563 29
return 1 563 30
assign 1 567 37
def 1 567 42
assign 1 568 43
valueGet 0 568 43
assign 1 569 44
return 1 570 45
assign 1 572 47
nextGet 0 572 47
assign 1 573 48
def 1 573 53
assign 1 574 54
keyGet 0 574 54
return 1 574 55
return 1 576 57
return 1 0 60
assign 1 0 63
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -716837866: return bem_hashGet_0();
case 53308341: return bem_toString_0();
case -673721877: return bem_bucketsGet_0();
case 1156020119: return bem_nodeIteratorIteratorGet_0();
case -1087891034: return bem_copy_0();
case 1411957276: return bem_onNodeGet_0();
case 1658565917: return bem_nextGet_0();
case 380806302: return bem_new_0();
case 925974575: return bem_moduGet_0();
case -1978436114: return bem_delete_0();
case -615427058: return bem_iteratorGet_0();
case -1555278490: return bem_currentGet_0();
case -1510018049: return bem_hasNextGet_0();
case 115177130: return bem_setGet_0();
case 603718350: return bem_print_0();
case -1147088242: return bem_create_0();
case 2059154207: return bem_containerGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1554282063: return bem_notEquals_1(bevd_0);
case 1738005159: return bem_equals_1(bevd_0);
case -1265849325: return bem_onNodeSet_1(bevd_0);
case -1462940865: return bem_copyTo_1(bevd_0);
case -1237306698: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1172665016: return bem_bucketsSet_1(bevd_0);
case 971589665: return bem_def_1(bevd_0);
case 20832777: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1209125372: return bem_undef_1(bevd_0);
case -1248309888: return bem_setSet_1(bevd_0);
case 739924615: return bem_moduSet_1(bevd_0);
case -26957788: return bem_currentSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -29663031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1505420135: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2021917335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 559223927: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1581466981: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_16_ContainerMapKeyValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst = (BEC_3_9_3_16_ContainerMapKeyValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;
}
}
