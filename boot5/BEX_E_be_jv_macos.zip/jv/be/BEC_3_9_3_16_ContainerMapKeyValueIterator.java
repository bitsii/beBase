package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_16_ContainerMapKeyValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_16_ContainerMapKeyValueIterator() { }
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4B,0x65,0x79,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;

public static BET_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bevp_onNode;
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_onNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 607*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 608*/
bevt_2_ta_ph = super.bem_hasNextGet_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_onNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 614*/ {
bevl_toRet = bevp_onNode.bemd_0(1564044286);
bevp_onNode = null;
return bevl_toRet;
} /* Line: 617*/
bevp_onNode = super.bem_nextGet_0();
if (bevp_onNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 620*/ {
bevt_2_ta_ph = bevp_onNode.bemd_0(1150391758);
return bevt_2_ta_ph;
} /* Line: 621*/
return bevp_onNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onNodeGet_0() throws Throwable {
return bevp_onNode;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_onNodeGetDirect_0() throws Throwable {
return bevp_onNode;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_onNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_onNode = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_3_16_ContainerMapKeyValueIterator bem_onNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_onNode = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {603, 607, 607, 608, 608, 610, 610, 614, 614, 615, 616, 617, 619, 620, 620, 621, 621, 623, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 20, 25, 26, 27, 29, 30, 37, 42, 43, 44, 45, 47, 48, 53, 54, 55, 57, 60, 63, 66, 70};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 603 13
assign 1 607 20
def 1 607 25
assign 1 608 26
new 0 608 26
return 1 608 27
assign 1 610 29
hasNextGet 0 610 29
return 1 610 30
assign 1 614 37
def 1 614 42
assign 1 615 43
valueGet 0 615 43
assign 1 616 44
return 1 617 45
assign 1 619 47
nextGet 0 619 47
assign 1 620 48
def 1 620 53
assign 1 621 54
keyGet 0 621 54
return 1 621 55
return 1 623 57
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1263154564: return bem_new_0();
case 1615402015: return bem_create_0();
case 1428370594: return bem_containerGet_0();
case 1179961651: return bem_serializeToString_0();
case -1469355336: return bem_hasNextGet_0();
case 37637962: return bem_print_0();
case -2086232081: return bem_setGet_0();
case -2016559796: return bem_onNodeGet_0();
case -1935527841: return bem_moduGet_0();
case 1333799692: return bem_tagGet_0();
case 340030523: return bem_classNameGet_0();
case 1546143657: return bem_echo_0();
case -1001743190: return bem_fieldNamesGet_0();
case 1028332348: return bem_delete_0();
case 1445801145: return bem_serializationIteratorGet_0();
case -30316716: return bem_slotsGet_0();
case 1064927353: return bem_currentGet_0();
case -800146552: return bem_serializeContents_0();
case -2095499202: return bem_fieldIteratorGet_0();
case 147497190: return bem_iteratorGet_0();
case -794718926: return bem_copy_0();
case 1972868319: return bem_setGetDirect_0();
case 242021854: return bem_nextGet_0();
case -1225581584: return bem_moduGetDirect_0();
case -506507588: return bem_nodeIteratorIteratorGet_0();
case 311262497: return bem_currentGetDirect_0();
case -676070096: return bem_sourceFileNameGet_0();
case -794062933: return bem_hashGet_0();
case 1691692397: return bem_onNodeGetDirect_0();
case 1577124637: return bem_deserializeClassNameGet_0();
case 219112807: return bem_toString_0();
case -455009051: return bem_slotsGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1030894563: return bem_moduSet_1(bevd_0);
case 1981346500: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 550061094: return bem_undef_1(bevd_0);
case -1534545800: return bem_otherType_1(bevd_0);
case 1419064041: return bem_sameObject_1(bevd_0);
case -19945451: return bem_notEquals_1(bevd_0);
case 1661150226: return bem_def_1(bevd_0);
case 1005228504: return bem_onNodeSet_1(bevd_0);
case 739117568: return bem_otherClass_1(bevd_0);
case -1935405349: return bem_sameType_1(bevd_0);
case -1868129616: return bem_copyTo_1(bevd_0);
case 1334201528: return bem_setSetDirect_1(bevd_0);
case 2130943739: return bem_onNodeSetDirect_1(bevd_0);
case -1770416220: return bem_currentSetDirect_1(bevd_0);
case 250302014: return bem_equals_1(bevd_0);
case 176399872: return bem_slotsSet_1(bevd_0);
case 2060848098: return bem_moduSetDirect_1(bevd_0);
case -1592226787: return bem_currentSet_1(bevd_0);
case -876042788: return bem_setSet_1(bevd_0);
case 1405755430: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1800691088: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2022815028: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2044993814: return bem_sameClass_1(bevd_0);
case -422271543: return bem_slotsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -938540681: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1738406137: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1708873965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 853768892: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2112740717: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_16_ContainerMapKeyValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst = (BEC_3_9_3_16_ContainerMapKeyValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;
}
}
