package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public final class BEC_3_2_4_17_IOFileDirectoryIterator extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }

   java.io.File[] bevi_dir;
   int bevi_pos = 0;
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_0() throws Throwable {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolFalse;
bevp_current = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) throws Throwable {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 471 */
 else  /* Line: 473 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 474 */
if (bevp_closed.bevi_bool) /* Line: 477 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 479 */
if (bevp_opened.bevi_bool) /* Line: 481 */ {
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 482 */

      java.io.File bevls_f = new java.io.File(bevl_path.bems_toJvString());
      bevi_dir = bevls_f.listFiles();
      bevi_pos = 0;
      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 506 */
 else  /* Line: 507 */ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
} /* Line: 510 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 515 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 515 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 516 */ {
bem_open_0();
} /* Line: 516 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() throws Throwable {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 521 */ {
return null;
} /* Line: 521 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 522 */ {
bem_open_0();
} /* Line: 522 */
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() throws Throwable {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 532 */ {
return this;
} /* Line: 532 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 533 */ {
return this;
} /* Line: 533 */
if (bevp_current == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 534 */ {
return this;
} /* Line: 534 */

      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 550 */ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 552 */
 else  /* Line: 553 */ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 556 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() throws Throwable {

      bevi_dir = null;
      bevi_pos = 0;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() throws Throwable {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() throws Throwable {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() throws Throwable {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {453, 454, 455, 461, 462, 470, 470, 471, 471, 474, 474, 474, 479, 479, 479, 482, 482, 482, 503, 503, 505, 506, 509, 510, 515, 515, 516, 516, 516, 517, 517, 521, 522, 522, 522, 523, 524, 525, 532, 533, 533, 533, 534, 534, 534, 550, 550, 551, 552, 554, 555, 556, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 27, 28, 43, 48, 49, 50, 53, 54, 55, 58, 59, 60, 63, 64, 65, 75, 80, 81, 82, 85, 86, 95, 96, 98, 103, 104, 106, 111, 117, 119, 124, 125, 127, 128, 129, 137, 139, 144, 145, 147, 152, 153, 160, 165, 166, 167, 170, 171, 172, 183, 186, 190, 193, 197, 200, 204, 207};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 453 21
new 0 453 21
assign 1 454 22
new 0 454 22
assign 1 455 23
new 0 461 27
assign 1 462 28
assign 1 470 43
def 1 470 48
assign 1 471 49
pathGet 0 471 49
assign 1 471 50
toString 0 471 50
assign 1 474 53
new 0 474 53
assign 1 474 54
new 1 474 54
throw 1 474 55
assign 1 479 58
new 0 479 58
assign 1 479 59
new 1 479 59
throw 1 479 60
assign 1 482 63
new 0 482 63
assign 1 482 64
new 1 482 64
throw 1 482 65
assign 1 503 75
def 1 503 80
assign 1 505 81
new 0 505 81
assign 1 506 82
apNew 1 506 82
assign 1 509 85
new 0 509 85
assign 1 510 86
new 0 510 86
assign 1 515 95
new 0 515 95
return 1 515 96
assign 1 516 98
not 0 516 103
open 0 516 104
assign 1 517 106
def 1 517 111
return 1 517 111
return 1 521 117
assign 1 522 119
not 0 522 124
open 0 522 125
assign 1 523 127
advance 0 524 128
return 1 525 129
return 1 532 137
assign 1 533 139
not 0 533 144
return 1 533 145
assign 1 534 147
undef 1 534 152
return 1 534 153
assign 1 550 160
def 1 550 165
assign 1 551 166
new 0 551 166
assign 1 552 167
apNew 1 552 167
assign 1 554 170
new 0 554 170
assign 1 555 171
new 0 555 171
assign 1 556 172
return 1 0 183
assign 1 0 186
return 1 0 190
assign 1 0 193
return 1 0 197
assign 1 0 200
return 1 0 204
assign 1 0 207
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1187428942: return bem_close_0();
case -302965453: return bem_tagGet_0();
case 301206433: return bem_echo_0();
case 463541302: return bem_closedGet_0();
case 218234679: return bem_openedGet_0();
case -1141859925: return bem_nextGet_0();
case 1452879382: return bem_sourceFileNameGet_0();
case 1732876397: return bem_serializationIteratorGet_0();
case -755605420: return bem_dirGet_0();
case -803388239: return bem_deserializeClassNameGet_0();
case 737771364: return bem_toString_0();
case 1569517931: return bem_advance_0();
case -1980796873: return bem_copy_0();
case 366164054: return bem_serializeContents_0();
case 997723391: return bem_iteratorGet_0();
case 1023783415: return bem_create_0();
case 2033657832: return bem_hashGet_0();
case 737353003: return bem_new_0();
case -420235024: return bem_classNameGet_0();
case 482356666: return bem_toAny_0();
case 1222310146: return bem_many_0();
case -1866917929: return bem_serializeToString_0();
case 863439583: return bem_hasNextGet_0();
case 1314576819: return bem_print_0();
case -1773858310: return bem_currentGet_0();
case 1775715094: return bem_once_0();
case 526333334: return bem_open_0();
case -70500062: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1732568943: return bem_sameObject_1(bevd_0);
case 1732014863: return bem_equals_1(bevd_0);
case -313919489: return bem_currentSet_1(bevd_0);
case -369272378: return bem_undefined_1(bevd_0);
case 394262893: return bem_closedSet_1(bevd_0);
case 1452810576: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 808158717: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1112750632: return bem_otherType_1(bevd_0);
case 228693515: return bem_notEquals_1(bevd_0);
case 254712574: return bem_def_1(bevd_0);
case -71377467: return bem_dirSet_1(bevd_0);
case 1210677960: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1107846755: return bem_otherClass_1(bevd_0);
case -1294797719: return bem_openedSet_1(bevd_0);
case -1458727376: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case 1735205112: return bem_sameType_1(bevd_0);
case -10325606: return bem_undef_1(bevd_0);
case 235706821: return bem_defined_1(bevd_0);
case -1078688343: return bem_copyTo_1(bevd_0);
case 1940225088: return bem_sameClass_1(bevd_0);
case 1235111255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1747848637: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1990568085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1437812444: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -303274357: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815656517: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -70659423: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -164742720: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
}
