package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public final class BEC_3_2_4_17_IOFileDirectoryIterator extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }

   java.io.File[] bevi_dir;
   int bevi_pos = 0;
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_0() throws Throwable {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolFalse;
bevp_current = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) throws Throwable {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 545 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 546 */
 else  /* Line: 548 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 549 */
if (bevp_closed.bevi_bool) /* Line: 552 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 554 */
if (bevp_opened.bevi_bool) /* Line: 556 */ {
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 557 */

      java.io.File bevls_f = new java.io.File(bevl_path.bems_toJvString());
      bevi_dir = bevls_f.listFiles();
      bevi_pos = 0;
      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 578 */ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 581 */
 else  /* Line: 582 */ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
} /* Line: 585 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 590 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 590 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 591 */ {
bem_open_0();
} /* Line: 591 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() throws Throwable {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 596 */ {
return null;
} /* Line: 596 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 597 */ {
bem_open_0();
} /* Line: 597 */
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() throws Throwable {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 607 */ {
return this;
} /* Line: 607 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 608 */ {
return this;
} /* Line: 608 */
if (bevp_current == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 609 */ {
return this;
} /* Line: 609 */

      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 625 */ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 627 */
 else  /* Line: 628 */ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 631 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() throws Throwable {

      bevi_dir = null;
      bevi_pos = 0;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() throws Throwable {
return bevp_dir;
} /*method end*/
public final BEC_2_2_4_IOFile bem_dirGetDirect_0() throws Throwable {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() throws Throwable {
return bevp_opened;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_openedGetDirect_0() throws Throwable {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() throws Throwable {
return bevp_closed;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_closedGetDirect_0() throws Throwable {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public final BEC_2_2_4_IOFile bem_currentGetDirect_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {528, 529, 530, 536, 537, 545, 545, 546, 546, 549, 549, 549, 554, 554, 554, 557, 557, 557, 578, 578, 580, 581, 584, 585, 590, 590, 591, 591, 591, 592, 592, 596, 597, 597, 597, 598, 599, 600, 607, 608, 608, 608, 609, 609, 609, 625, 625, 626, 627, 629, 630, 631, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 25, 26, 30, 31, 46, 51, 52, 53, 56, 57, 58, 61, 62, 63, 66, 67, 68, 78, 83, 84, 85, 88, 89, 98, 99, 101, 106, 107, 109, 114, 120, 122, 127, 128, 130, 131, 132, 140, 142, 147, 148, 150, 155, 156, 163, 168, 169, 170, 173, 174, 175, 186, 189, 192, 196, 200, 203, 206, 210, 214, 217, 220, 224, 228, 231, 234, 238};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 528 24
new 0 528 24
assign 1 529 25
new 0 529 25
assign 1 530 26
new 0 536 30
assign 1 537 31
assign 1 545 46
def 1 545 51
assign 1 546 52
pathGet 0 546 52
assign 1 546 53
toString 0 546 53
assign 1 549 56
new 0 549 56
assign 1 549 57
new 1 549 57
throw 1 549 58
assign 1 554 61
new 0 554 61
assign 1 554 62
new 1 554 62
throw 1 554 63
assign 1 557 66
new 0 557 66
assign 1 557 67
new 1 557 67
throw 1 557 68
assign 1 578 78
def 1 578 83
assign 1 580 84
new 0 580 84
assign 1 581 85
apNew 1 581 85
assign 1 584 88
new 0 584 88
assign 1 585 89
new 0 585 89
assign 1 590 98
new 0 590 98
return 1 590 99
assign 1 591 101
not 0 591 106
open 0 591 107
assign 1 592 109
def 1 592 114
return 1 592 114
return 1 596 120
assign 1 597 122
not 0 597 127
open 0 597 128
assign 1 598 130
advance 0 599 131
return 1 600 132
return 1 607 140
assign 1 608 142
not 0 608 147
return 1 608 148
assign 1 609 150
undef 1 609 155
return 1 609 156
assign 1 625 163
def 1 625 168
assign 1 626 169
new 0 626 169
assign 1 627 170
apNew 1 627 170
assign 1 629 173
new 0 629 173
assign 1 630 174
new 0 630 174
assign 1 631 175
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
return 1 0 214
return 1 0 217
assign 1 0 220
assign 1 0 224
return 1 0 228
return 1 0 231
assign 1 0 234
assign 1 0 238
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2120270754: return bem_dirGetDirect_0();
case 9597572: return bem_close_0();
case 520238370: return bem_print_0();
case 1754760186: return bem_iteratorGet_0();
case 1841075196: return bem_deserializeClassNameGet_0();
case 288971190: return bem_open_0();
case 834974873: return bem_once_0();
case -1153621323: return bem_sourceFileNameGet_0();
case -516300936: return bem_many_0();
case 1837791355: return bem_currentGetDirect_0();
case -1662202956: return bem_closedGet_0();
case 895793301: return bem_currentGet_0();
case -260016569: return bem_new_0();
case 1363596807: return bem_toAny_0();
case 1024143585: return bem_dirGet_0();
case 1695553285: return bem_toString_0();
case 946079220: return bem_hasNextGet_0();
case 510740763: return bem_echo_0();
case -385649327: return bem_advance_0();
case -1906011811: return bem_classNameGet_0();
case 772185969: return bem_nextGet_0();
case -1481120: return bem_hashGet_0();
case 1934827441: return bem_tagGet_0();
case -2049404332: return bem_fieldIteratorGet_0();
case -1216083566: return bem_closedGetDirect_0();
case 1246525343: return bem_copy_0();
case 629513215: return bem_create_0();
case -1151122392: return bem_serializeToString_0();
case 1034996699: return bem_openedGetDirect_0();
case -319884304: return bem_serializationIteratorGet_0();
case 80505915: return bem_fieldNamesGet_0();
case 306221507: return bem_openedGet_0();
case -1784818407: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1512005598: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1407166430: return bem_dirSetDirect_1(bevd_0);
case -228195679: return bem_copyTo_1(bevd_0);
case -1875717244: return bem_currentSetDirect_1(bevd_0);
case 1240336100: return bem_closedSetDirect_1(bevd_0);
case 482689426: return bem_otherClass_1(bevd_0);
case 2122170094: return bem_otherType_1(bevd_0);
case -1430178609: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 216738391: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 667676722: return bem_dirSet_1(bevd_0);
case 1447735791: return bem_openedSet_1(bevd_0);
case 462621647: return bem_def_1(bevd_0);
case -753793171: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case -395850459: return bem_undefined_1(bevd_0);
case -1465560464: return bem_currentSet_1(bevd_0);
case -1144341678: return bem_notEquals_1(bevd_0);
case -1573802551: return bem_sameObject_1(bevd_0);
case 989721692: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1039966440: return bem_openedSetDirect_1(bevd_0);
case 1053596959: return bem_closedSet_1(bevd_0);
case -951929577: return bem_defined_1(bevd_0);
case 1049358928: return bem_equals_1(bevd_0);
case 1523343000: return bem_sameClass_1(bevd_0);
case 1632353878: return bem_undef_1(bevd_0);
case -1177836823: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1872811781: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 518732674: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1018924161: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 308804077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2072018670: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -357078730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -277637599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
