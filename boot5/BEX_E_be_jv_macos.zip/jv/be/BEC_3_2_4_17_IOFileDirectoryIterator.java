package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public final class BEC_3_2_4_17_IOFileDirectoryIterator extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }

   java.io.File[] bevi_dir;
   int bevi_pos = 0;
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public BEC_2_6_6_SystemObject bevp_jsiter;
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_0() throws Throwable {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolFalse;
bevp_current = null;
bevp_jsiter = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) throws Throwable {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_1_ta_ph = null;
BEC_2_6_9_SystemException bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_9_SystemException bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (bevp_dir == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 645*/ {
bevt_1_ta_ph = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_ta_ph.bem_toString_0();
} /* Line: 646*/
 else /* Line: 648*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_ta_ph);
throw new be.BECS_ThrowBack(bevt_2_ta_ph);
} /* Line: 649*/
if (bevp_closed.bevi_bool)/* Line: 652*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 654*/
if (bevp_opened.bevi_bool)/* Line: 656*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_ta_ph);
throw new be.BECS_ThrowBack(bevt_6_ta_ph);
} /* Line: 657*/

      java.io.File bevls_f = new java.io.File(bevl_path.bems_toJvString());
      bevi_dir = bevls_f.listFiles();
      bevi_pos = 0;
      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 710*/ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 713*/
 else /* Line: 714*/ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
} /* Line: 717*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_closed.bevi_bool)/* Line: 722*/ {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /* Line: 722*/
if (bevp_opened.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 723*/ {
bem_open_0();
} /* Line: 723*/
if (bevp_current == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() throws Throwable {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_closed.bevi_bool)/* Line: 728*/ {
return null;
} /* Line: 728*/
if (bevp_opened.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 729*/ {
bem_open_0();
} /* Line: 729*/
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() throws Throwable {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_closed.bevi_bool)/* Line: 739*/ {
return this;
} /* Line: 739*/
if (bevp_opened.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 740*/ {
return this;
} /* Line: 740*/
if (bevp_current == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 741*/ {
return this;
} /* Line: 741*/

      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 775*/ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 777*/
 else /* Line: 778*/ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 781*/
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() throws Throwable {

      bevi_dir = null;
      bevi_pos = 0;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() throws Throwable {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() throws Throwable {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() throws Throwable {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_jsiterGet_0() throws Throwable {
return bevp_jsiter;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_jsiterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_jsiter = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {628, 629, 630, 631, 636, 637, 645, 645, 646, 646, 649, 649, 649, 654, 654, 654, 657, 657, 657, 710, 710, 712, 713, 716, 717, 722, 722, 723, 723, 723, 724, 724, 728, 729, 729, 729, 730, 731, 732, 739, 740, 740, 740, 741, 741, 741, 775, 775, 776, 777, 779, 780, 781, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 32, 33, 48, 53, 54, 55, 58, 59, 60, 63, 64, 65, 68, 69, 70, 80, 85, 86, 87, 90, 91, 100, 101, 103, 108, 109, 111, 116, 122, 124, 129, 130, 132, 133, 134, 142, 144, 149, 150, 152, 157, 158, 165, 170, 171, 172, 175, 176, 177, 188, 191, 195, 198, 202, 205, 209, 212, 216, 219};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 628 25
new 0 628 25
assign 1 629 26
new 0 629 26
assign 1 630 27
assign 1 631 28
new 0 636 32
assign 1 637 33
assign 1 645 48
def 1 645 53
assign 1 646 54
pathGet 0 646 54
assign 1 646 55
toString 0 646 55
assign 1 649 58
new 0 649 58
assign 1 649 59
new 1 649 59
throw 1 649 60
assign 1 654 63
new 0 654 63
assign 1 654 64
new 1 654 64
throw 1 654 65
assign 1 657 68
new 0 657 68
assign 1 657 69
new 1 657 69
throw 1 657 70
assign 1 710 80
def 1 710 85
assign 1 712 86
new 0 712 86
assign 1 713 87
apNew 1 713 87
assign 1 716 90
new 0 716 90
assign 1 717 91
new 0 717 91
assign 1 722 100
new 0 722 100
return 1 722 101
assign 1 723 103
not 0 723 108
open 0 723 109
assign 1 724 111
def 1 724 116
return 1 724 116
return 1 728 122
assign 1 729 124
not 0 729 129
open 0 729 130
assign 1 730 132
advance 0 731 133
return 1 732 134
return 1 739 142
assign 1 740 144
not 0 740 149
return 1 740 150
assign 1 741 152
undef 1 741 157
return 1 741 158
assign 1 775 165
def 1 775 170
assign 1 776 171
new 0 776 171
assign 1 777 172
apNew 1 777 172
assign 1 779 175
new 0 779 175
assign 1 780 176
new 0 780 176
assign 1 781 177
return 1 0 188
assign 1 0 191
return 1 0 195
assign 1 0 198
return 1 0 202
assign 1 0 205
return 1 0 209
assign 1 0 212
return 1 0 216
assign 1 0 219
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1379718079: return bem_create_0();
case -773497799: return bem_new_0();
case 1893761429: return bem_hasNextGet_0();
case -193889657: return bem_toString_0();
case -2034012338: return bem_copy_0();
case -1071780394: return bem_advance_0();
case 1769223704: return bem_close_0();
case 251802057: return bem_jsiterGet_0();
case 923105887: return bem_print_0();
case 681528853: return bem_openedGet_0();
case 2114841698: return bem_nextGet_0();
case -856249453: return bem_closedGet_0();
case -883889248: return bem_iteratorGet_0();
case -923870371: return bem_hashGet_0();
case 338764011: return bem_dirGet_0();
case -928429954: return bem_currentGet_0();
case -667101608: return bem_open_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 554173292: return bem_print_1(bevd_0);
case -1364861315: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case -1622220498: return bem_copyTo_1(bevd_0);
case 1374247988: return bem_notEquals_1(bevd_0);
case 498156661: return bem_closedSet_1(bevd_0);
case 162701988: return bem_undef_1(bevd_0);
case -1212254790: return bem_def_1(bevd_0);
case 1842429123: return bem_jsiterSet_1(bevd_0);
case -1710018889: return bem_openedSet_1(bevd_0);
case -32520765: return bem_equals_1(bevd_0);
case -806626465: return bem_dirSet_1(bevd_0);
case 127527996: return bem_currentSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 92485648: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1317865236: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -661884340: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -149193823: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
