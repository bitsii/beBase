package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public final class BEC_3_2_4_17_IOFileDirectoryIterator extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }

   java.io.File[] bevi_dir;
   int bevi_pos = 0;
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public BEC_2_6_6_SystemObject bevp_jsiter;
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_0() throws Throwable {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolFalse;
bevp_current = null;
bevp_jsiter = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) throws Throwable {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_4_6_TextString bevl_ps = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_9_4_ContainerList bevl_jsfiles = null;
BEC_2_4_6_TextString bevl_currlp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_1_ta_ph = null;
BEC_2_6_9_SystemException bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_9_SystemException bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_7_TextStrings bevt_12_ta_ph = null;
BEC_2_4_12_JsonUnmarshaller bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
if (bevp_dir == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 636*/ {
bevt_1_ta_ph = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_ta_ph.bem_toString_0();
} /* Line: 637*/
 else /* Line: 639*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_ta_ph);
throw new be.BECS_ThrowBack(bevt_2_ta_ph);
} /* Line: 640*/
if (bevp_closed.bevi_bool)/* Line: 643*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 645*/
if (bevp_opened.bevi_bool)/* Line: 647*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_ta_ph);
throw new be.BECS_ThrowBack(bevt_6_ta_ph);
} /* Line: 648*/

      java.io.File bevls_f = new java.io.File(bevl_path.bems_toJvString());
      bevi_dir = bevls_f.listFiles();
      bevi_pos = 0;
      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 701*/ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 704*/
 else /* Line: 705*/ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
} /* Line: 708*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_closed.bevi_bool)/* Line: 713*/ {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /* Line: 713*/
if (bevp_opened.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 714*/ {
bem_open_0();
} /* Line: 714*/
if (bevp_current == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() throws Throwable {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_closed.bevi_bool)/* Line: 719*/ {
return null;
} /* Line: 719*/
if (bevp_opened.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 720*/ {
bem_open_0();
} /* Line: 720*/
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() throws Throwable {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_4_6_TextString bevl_currlp = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (bevp_closed.bevi_bool)/* Line: 730*/ {
return this;
} /* Line: 730*/
if (bevp_opened.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 731*/ {
return this;
} /* Line: 731*/
if (bevp_current == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 732*/ {
return this;
} /* Line: 732*/

      if (bevi_dir != null && bevi_dir.length > bevi_pos) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir[bevi_pos].getPath());
        bevi_pos++;
      }
      if (bevl_newName == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 766*/ {
bevp_opened = be.BECS_Runtime.boolTrue;
bevp_current = (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 768*/
 else /* Line: 769*/ {
bevp_opened = be.BECS_Runtime.boolFalse;
bevp_closed = be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 772*/
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() throws Throwable {

      bevi_dir = null;
      bevi_pos = 0;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() throws Throwable {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() throws Throwable {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() throws Throwable {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_jsiterGet_0() throws Throwable {
return bevp_jsiter;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_jsiterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_jsiter = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {619, 620, 621, 622, 627, 628, 636, 636, 637, 637, 640, 640, 640, 645, 645, 645, 648, 648, 648, 701, 701, 703, 704, 707, 708, 713, 713, 714, 714, 714, 715, 715, 719, 720, 720, 720, 721, 722, 723, 730, 731, 731, 731, 732, 732, 732, 766, 766, 767, 768, 770, 771, 772, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 32, 33, 62, 67, 68, 69, 72, 73, 74, 77, 78, 79, 82, 83, 84, 94, 99, 100, 101, 104, 105, 114, 115, 117, 122, 123, 125, 130, 136, 138, 143, 144, 146, 147, 148, 163, 165, 170, 171, 173, 178, 179, 186, 191, 192, 193, 196, 197, 198, 209, 212, 216, 219, 223, 226, 230, 233, 237, 240};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 619 25
new 0 619 25
assign 1 620 26
new 0 620 26
assign 1 621 27
assign 1 622 28
new 0 627 32
assign 1 628 33
assign 1 636 62
def 1 636 67
assign 1 637 68
pathGet 0 637 68
assign 1 637 69
toString 0 637 69
assign 1 640 72
new 0 640 72
assign 1 640 73
new 1 640 73
throw 1 640 74
assign 1 645 77
new 0 645 77
assign 1 645 78
new 1 645 78
throw 1 645 79
assign 1 648 82
new 0 648 82
assign 1 648 83
new 1 648 83
throw 1 648 84
assign 1 701 94
def 1 701 99
assign 1 703 100
new 0 703 100
assign 1 704 101
apNew 1 704 101
assign 1 707 104
new 0 707 104
assign 1 708 105
new 0 708 105
assign 1 713 114
new 0 713 114
return 1 713 115
assign 1 714 117
not 0 714 122
open 0 714 123
assign 1 715 125
def 1 715 130
return 1 715 130
return 1 719 136
assign 1 720 138
not 0 720 143
open 0 720 144
assign 1 721 146
advance 0 722 147
return 1 723 148
return 1 730 163
assign 1 731 165
not 0 731 170
return 1 731 171
assign 1 732 173
undef 1 732 178
return 1 732 179
assign 1 766 186
def 1 766 191
assign 1 767 192
new 0 767 192
assign 1 768 193
apNew 1 768 193
assign 1 770 196
new 0 770 196
assign 1 771 197
new 0 771 197
assign 1 772 198
return 1 0 209
assign 1 0 212
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
return 1 0 237
assign 1 0 240
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 49169285: return bem_create_0();
case -7476103: return bem_hashGet_0();
case 1975058912: return bem_openedGet_0();
case 1631198925: return bem_print_0();
case -2129238938: return bem_fieldNamesGet_0();
case 2115475884: return bem_new_0();
case 1691774645: return bem_open_0();
case 249846699: return bem_nextGet_0();
case 1360751251: return bem_advance_0();
case -965877700: return bem_jsiterGet_0();
case -1162180063: return bem_hasNextGet_0();
case -2146157966: return bem_close_0();
case -854129615: return bem_classNameGet_0();
case -2056929557: return bem_currentGet_0();
case -350069992: return bem_closedGet_0();
case 744789579: return bem_tagGet_0();
case 956564530: return bem_toString_0();
case -6785712: return bem_copy_0();
case 235554219: return bem_iteratorGet_0();
case 361205664: return bem_dirGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1005385637: return bem_copyTo_1(bevd_0);
case 404701215: return bem_dirSet_1(bevd_0);
case -76922352: return bem_equals_1(bevd_0);
case -2052423771: return bem_notEquals_1(bevd_0);
case -1554337727: return bem_sameObject_1(bevd_0);
case -133049324: return bem_closedSet_1(bevd_0);
case -1184273709: return bem_undef_1(bevd_0);
case -2142487980: return bem_sameType_1(bevd_0);
case -268082121: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case 1474044548: return bem_openedSet_1(bevd_0);
case 1338190085: return bem_def_1(bevd_0);
case 1222746233: return bem_currentSet_1(bevd_0);
case -1256020058: return bem_otherType_1(bevd_0);
case 1061031694: return bem_jsiterSet_1(bevd_0);
case 1149746123: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -829590487: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -744751889: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1116067959: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -383996467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1363599577: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
