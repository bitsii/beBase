package be;
/* IO:File: source/extended/Serialize.be */
public final class BEC_2_6_23_SystemNamedPropertiesIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_23_SystemNamedPropertiesIterator() { }
private static byte[] becc_BEC_2_6_23_SystemNamedPropertiesIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_23_SystemNamedPropertiesIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_0 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_1 = {0x53,0x65,0x74};
public static BEC_2_6_23_SystemNamedPropertiesIterator bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst;

public static BET_2_6_23_SystemNamedPropertiesIterator bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_propNames;
public BEC_3_9_4_8_ContainerListIterator bevp_subIter;
public BEC_2_6_6_SystemObject bevp_inst;
public BEC_2_9_4_ContainerList bevp_setArgs;
public BEC_2_9_4_ContainerList bevp_getArgs;
public BEC_2_6_23_SystemNamedPropertiesIterator bem_new_2(BEC_2_6_6_SystemObject beva__inst, BEC_2_9_4_ContainerList beva__propNames) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_propNames = beva__propNames;
bevp_inst = beva__inst;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevp_setArgs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_getArgs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_subIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_subIter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 446 */ {
bevp_subIter = bevp_propNames.bem_arrayIteratorGet_0();
} /* Line: 447 */
return bevp_subIter;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hasNextGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_nextGet_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_0));
bevl_name = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(1876093054, bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = bevp_inst.bemd_2(-1846932381, bevl_name, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 458 */ {
bevt_5_tmpany_phold = bevp_inst.bemd_2(1258452187, bevl_name, bevp_getArgs);
return bevt_5_tmpany_phold;
} /* Line: 459 */
return null;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_nextGet_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_1));
bevl_name = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(1876093054, bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_3_tmpany_phold = bevp_inst.bemd_2(-1846932381, bevl_name, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 466 */ {
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_setArgs.bem_put_2(bevt_5_tmpany_phold, beva_value);
bevp_inst.bemd_2(1258452187, bevl_name, bevp_setArgs);
} /* Line: 468 */
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 473 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 473 */ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 473 */
 else  /* Line: 473 */ {
break;
} /* Line: 473 */
} /* Line: 473 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_propNamesGet_0() throws Throwable {
return bevp_propNames;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_propNamesGetDirect_0() throws Throwable {
return bevp_propNames;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_propNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_propNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_23_SystemNamedPropertiesIterator bem_propNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_propNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_4_8_ContainerListIterator bem_subIterGetDirect_0() throws Throwable {
return bevp_subIter;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_subIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_23_SystemNamedPropertiesIterator bem_subIterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instGet_0() throws Throwable {
return bevp_inst;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_instGetDirect_0() throws Throwable {
return bevp_inst;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_instSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inst = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_23_SystemNamedPropertiesIterator bem_instSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inst = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_setArgsGet_0() throws Throwable {
return bevp_setArgs;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_setArgsGetDirect_0() throws Throwable {
return bevp_setArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_setArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_setArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_23_SystemNamedPropertiesIterator bem_setArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_setArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_getArgsGet_0() throws Throwable {
return bevp_getArgs;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_getArgsGetDirect_0() throws Throwable {
return bevp_getArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_getArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_23_SystemNamedPropertiesIterator bem_getArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_getArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {437, 439, 440, 440, 441, 441, 446, 446, 447, 449, 453, 453, 453, 457, 457, 457, 457, 458, 458, 459, 459, 461, 465, 465, 465, 465, 466, 466, 467, 467, 468, 473, 473, 473, 474, 473, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 24, 25, 26, 31, 36, 37, 39, 44, 45, 46, 56, 57, 58, 59, 60, 61, 63, 64, 66, 76, 77, 78, 79, 80, 81, 83, 84, 85, 92, 95, 100, 101, 102, 111, 114, 117, 121, 125, 128, 132, 136, 139, 142, 146, 150, 153, 156, 160, 164, 167, 170, 174};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 437 21
assign 1 439 22
assign 1 440 23
new 0 440 23
assign 1 440 24
new 1 440 24
assign 1 441 25
new 0 441 25
assign 1 441 26
new 1 441 26
assign 1 446 31
undef 1 446 36
assign 1 447 37
arrayIteratorGet 0 447 37
return 1 449 39
assign 1 453 44
subIterGet 0 453 44
assign 1 453 45
hasNextGet 0 453 45
return 1 453 46
assign 1 457 56
subIterGet 0 457 56
assign 1 457 57
nextGet 0 457 57
assign 1 457 58
new 0 457 58
assign 1 457 59
add 1 457 59
assign 1 458 60
new 0 458 60
assign 1 458 61
can 2 458 61
assign 1 459 63
invoke 2 459 63
return 1 459 64
return 1 461 66
assign 1 465 76
subIterGet 0 465 76
assign 1 465 77
nextGet 0 465 77
assign 1 465 78
new 0 465 78
assign 1 465 79
add 1 465 79
assign 1 466 80
new 0 466 80
assign 1 466 81
can 2 466 81
assign 1 467 83
new 0 467 83
put 2 467 84
invoke 2 468 85
assign 1 473 92
new 0 473 92
assign 1 473 95
lesser 1 473 100
nextSet 1 474 101
assign 1 473 102
increment 0 473 102
return 1 0 111
return 1 0 114
assign 1 0 117
assign 1 0 121
return 1 0 125
assign 1 0 128
assign 1 0 132
return 1 0 136
return 1 0 139
assign 1 0 142
assign 1 0 146
return 1 0 150
return 1 0 153
assign 1 0 156
assign 1 0 160
return 1 0 164
return 1 0 167
assign 1 0 170
assign 1 0 174
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1441040566: return bem_sourceFileNameGet_0();
case 250882712: return bem_instGet_0();
case 1015189081: return bem_subIterGet_0();
case 169213983: return bem_instGetDirect_0();
case -1302286153: return bem_fieldNamesGet_0();
case -1582894954: return bem_print_0();
case -1841553076: return bem_fieldIteratorGet_0();
case -749659777: return bem_serializeContents_0();
case 290847982: return bem_copy_0();
case 1455331056: return bem_hasNextGet_0();
case -716788899: return bem_propNamesGetDirect_0();
case -557497764: return bem_deserializeClassNameGet_0();
case -705961525: return bem_hashGet_0();
case -1607921594: return bem_iteratorGet_0();
case -94797444: return bem_tagGet_0();
case 1819620081: return bem_nextGet_0();
case -1076974459: return bem_once_0();
case -1392016164: return bem_propNamesGet_0();
case -991331785: return bem_serializationIteratorGet_0();
case -712270872: return bem_getArgsGetDirect_0();
case -547935816: return bem_echo_0();
case 782770507: return bem_toString_0();
case -741944257: return bem_serializeToString_0();
case -538052524: return bem_setArgsGet_0();
case 115525765: return bem_subIterGetDirect_0();
case 2110853105: return bem_setArgsGetDirect_0();
case 1461795953: return bem_toAny_0();
case -366665939: return bem_getArgsGet_0();
case -1838847527: return bem_many_0();
case -935373025: return bem_create_0();
case 618670577: return bem_classNameGet_0();
case 537383271: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 529067620: return bem_sameType_1(bevd_0);
case -1752858630: return bem_subIterSet_1(bevd_0);
case 239697519: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -707951440: return bem_propNamesSetDirect_1(bevd_0);
case -1929424915: return bem_propNamesSet_1(bevd_0);
case 293923702: return bem_def_1(bevd_0);
case 1834451547: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1237105374: return bem_notEquals_1(bevd_0);
case 1748491906: return bem_sameClass_1(bevd_0);
case 97981859: return bem_undef_1(bevd_0);
case 250864451: return bem_getArgsSet_1(bevd_0);
case 1806556653: return bem_instSetDirect_1(bevd_0);
case -1434736665: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -167158523: return bem_otherType_1(bevd_0);
case -1385290432: return bem_setArgsSet_1(bevd_0);
case -1330156098: return bem_copyTo_1(bevd_0);
case -228872039: return bem_otherClass_1(bevd_0);
case -1744663847: return bem_instSet_1(bevd_0);
case -2029391983: return bem_subIterSetDirect_1(bevd_0);
case -657442161: return bem_setArgsSetDirect_1(bevd_0);
case 1620843058: return bem_getArgsSetDirect_1(bevd_0);
case -2085686581: return bem_defined_1(bevd_0);
case -1830241337: return bem_equals_1(bevd_0);
case 659675994: return bem_undefined_1(bevd_0);
case 1483369915: return bem_sameObject_1(bevd_0);
case -926340668: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -141397341: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -205172447: return bem_nextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 246296720: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1363285011: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1258452187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1900266912: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1382151939: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 369468912: return bem_new_2(bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1846932381: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1600914698: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_2_6_23_SystemNamedPropertiesIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_23_SystemNamedPropertiesIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_23_SystemNamedPropertiesIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst = (BEC_2_6_23_SystemNamedPropertiesIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_type;
}
}
