package be;
public class BET_2_6_10_SystemSerializer extends BETS_Object {
public BET_2_6_10_SystemSerializer() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_10", "serialize_1", "serialize_2", "serializeI_2", "serializeC_2", "defineInstance_2", "deserialize_1", "groupGet_0", "groupSet_1", "defineReferenceGet_0", "defineReferenceSet_1", "getReferenceGet_0", "getReferenceSet_1", "constructStringGet_0", "constructStringSet_1", "nullMarkGet_0", "nullMarkSet_1", "getClassTagGet_0", "getClassTagSet_1", "shiftGet_0", "shiftSet_1", "defineClassTagGet_0", "defineClassTagSet_1", "multiNullMarkGet_0", "multiNullMarkSet_1", "endGroupGet_0", "endGroupSet_1", "tokerGet_0", "tokerSet_1", "encoderGet_0", "encoderSet_1", "saveIdentityGet_0", "saveIdentitySet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "group", "defineReference", "getReference", "constructString", "nullMark", "getClassTag", "shift", "defineClassTag", "multiNullMark", "endGroup", "toker", "encoder", "saveIdentity" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_10_SystemSerializer();
}
}
