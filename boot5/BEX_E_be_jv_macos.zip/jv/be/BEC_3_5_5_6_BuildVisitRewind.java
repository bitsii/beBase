package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_6_BuildVisitRewind extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_1, 11));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_2, 2));
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_2, 2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_4, 27));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_6, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_7, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_8, 17));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_9, 10));
public static BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;

public static BET_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;

public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_3_5_5_6_BuildVisitRewind bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_83_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_86_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevt_12_tmpany_phold = beva_node.bem_heldGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-868201389);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 348 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 348 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 348 */
 else  /* Line: 348 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 348 */ {
bevt_15_tmpany_phold = beva_node.bem_containerGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevt_20_tmpany_phold = beva_node.bem_containerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1521739407);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(-1755209627, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 350 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 350 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 350 */
 else  /* Line: 350 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 350 */ {
bevt_22_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 350 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 350 */
 else  /* Line: 350 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 350 */ {
bevt_26_tmpany_phold = beva_node.bem_containedGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_firstGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(1547933631);
bevt_27_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-1755209627, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 352 */ {
bevt_31_tmpany_phold = beva_node.bem_containedGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_firstGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(766752427);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(449899320);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 352 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 352 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 352 */
 else  /* Line: 352 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 352 */ {
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(766752427);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_tmpany_phold.bemd_0(553602060);
bevt_35_tmpany_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_lastGet_0();
bevt_39_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0;
bevt_40_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1;
bevt_38_tmpany_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpany_phold, bevt_40_tmpany_phold);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_lowerValue_0();
bevt_42_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_41_tmpany_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2;
bevl_fgin = bevt_36_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpany_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3;
bevt_45_tmpany_phold = bevl_fgin.bem_add_1(bevt_46_tmpany_phold);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_tmpany_phold.bem_get_1(bevt_45_tmpany_phold);
if (bevl_fgms == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 359 */ {
bevt_48_tmpany_phold = beva_node.bem_heldGet_0();
bevt_48_tmpany_phold.bemd_1(2124464866, bevl_fgin);
bevt_49_tmpany_phold = beva_node.bem_heldGet_0();
bevt_51_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4;
bevt_50_tmpany_phold = bevl_fgin.bem_add_1(bevt_51_tmpany_phold);
bevt_49_tmpany_phold.bemd_1(-1108467648, bevt_50_tmpany_phold);
} /* Line: 362 */
} /* Line: 359 */
} /* Line: 352 */
} /* Line: 350 */
bevt_53_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_tmpany_phold.bevi_int == bevt_54_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 367 */ {
bevp_inClass = beva_node;
bevt_55_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpany_phold.bemd_0(553602060);
bevt_56_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpany_phold.bemd_0(1094926296);
} /* Line: 370 */
bevt_58_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_59_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 374 */
 else  /* Line: 372 */ {
bevt_61_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpany_phold.bevi_int == bevt_62_tmpany_phold.bevi_int) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 375 */ {
bevt_64_tmpany_phold = beva_node.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(1064080907);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 375 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 375 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 375 */
 else  /* Line: 375 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 375 */ {
bevt_66_tmpany_phold = beva_node.bem_heldGet_0();
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_0(1320525264);
bevt_67_tmpany_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(560517072, bevt_65_tmpany_phold, bevt_67_tmpany_phold);
bevt_69_tmpany_phold = beva_node.bem_heldGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(1320525264);
bevl_ll = bevp_rmap.bemd_1(-1230021919, bevt_68_tmpany_phold);
if (bevl_ll == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 378 */ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = beva_node.bem_heldGet_0();
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(1320525264);
bevp_rmap.bemd_2(560517072, bevt_71_tmpany_phold, bevl_ll);
} /* Line: 380 */
bevl_ll.bemd_1(544331812, beva_node);
} /* Line: 382 */
 else  /* Line: 372 */ {
bevt_74_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_tmpany_phold.bevi_int == bevt_75_tmpany_phold.bevi_int) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_77_tmpany_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 383 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 383 */
 else  /* Line: 383 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 383 */ {
bevt_80_tmpany_phold = beva_node.bem_containerGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_containerGet_0();
if (bevt_79_tmpany_phold == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 383 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 383 */
 else  /* Line: 383 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 383 */ {
bevt_84_tmpany_phold = beva_node.bem_containerGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bem_containerGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_typenameGet_0();
bevt_85_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_tmpany_phold.bevi_int == bevt_85_tmpany_phold.bevi_int) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 383 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 383 */
 else  /* Line: 383 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 383 */ {
bem_processTmps_0();
} /* Line: 385 */
} /* Line: 372 */
} /* Line: 372 */
bevt_86_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpany_phold;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 399 */ {
if (((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool) /* Line: 399 */ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(1542910818);
while (true)
 /* Line: 401 */ {
bevt_9_tmpany_phold = bevl_i.bemd_0(1639542906);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 401 */ {
bevl_nv = bevl_i.bemd_0(-1466225858);
bevt_11_tmpany_phold = bevl_nv.bemd_0(449899320);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(343879769);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 404 */ {
bevl_nvname = bevl_nv.bemd_0(1320525264);
bevl_ll = bevp_rmap.bemd_1(-1230021919, bevl_nvname);
bevt_0_tmpany_loop = bevl_ll.bemd_0(-579194210);
while (true)
 /* Line: 409 */ {
bevt_12_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1639542906);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 409 */ {
bevl_k = bevt_0_tmpany_loop.bemd_0(-1466225858);
bevt_13_tmpany_phold = bevl_k.bemd_0(-1877380973);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 410 */ {
bevt_16_tmpany_phold = bevl_k.bemd_0(32824861);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1547933631);
bevt_17_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_1(-1755209627, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 410 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 410 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 410 */
 else  /* Line: 410 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 410 */ {
bevt_21_tmpany_phold = bevl_k.bemd_0(32824861);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(766752427);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-1521739407);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-1755209627, bevt_22_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 410 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 410 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 410 */
 else  /* Line: 410 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 410 */ {
bevt_26_tmpany_phold = bevl_k.bemd_0(32824861);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-895308102);
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(1547933631);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-1755209627, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 410 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 410 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 410 */
 else  /* Line: 410 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 410 */ {
bevt_28_tmpany_phold = bevl_k.bemd_0(32824861);
bevl_tcall = bevt_28_tmpany_phold.bemd_0(-895308102);
bevl_targNp = null;
bevt_31_tmpany_phold = bevl_tcall.bemd_0(766752427);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(374850386);
if (bevt_30_tmpany_phold == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 414 */ {
bevt_32_tmpany_phold = bevl_tcall.bemd_0(766752427);
bevl_targNp = bevt_32_tmpany_phold.bemd_0(374850386);
} /* Line: 415 */
 else  /* Line: 416 */ {
bevt_33_tmpany_phold = bevl_tcall.bemd_0(1053419574);
bevl_targ = bevt_33_tmpany_phold.bemd_0(1969592417);
bevt_35_tmpany_phold = bevl_targ.bemd_0(766752427);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(-1463355049);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 421 */ {
bevl_tany = bevl_targ.bemd_0(766752427);
} /* Line: 422 */
 else  /* Line: 423 */ {
bevt_37_tmpany_phold = bevp_inClassSyn.bemd_0(-1004592022);
bevt_39_tmpany_phold = bevl_targ.bemd_0(766752427);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(1320525264);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(-1230021919, bevt_38_tmpany_phold);
bevl_tany = bevt_36_tmpany_phold.bemd_0(706980239);
} /* Line: 424 */
bevt_40_tmpany_phold = bevl_tany.bemd_0(449899320);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 427 */ {
bevl_targNp = bevl_tany.bemd_0(553602060);
} /* Line: 428 */
} /* Line: 427 */
if (bevl_targNp == null) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 431 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_44_tmpany_phold = bevl_tcall.bemd_0(766752427);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(1320525264);
bevl_mtdc = bevt_42_tmpany_phold.bem_get_1(bevt_43_tmpany_phold);
if (bevl_mtdc == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 435 */ {
bevl_oany = bevl_mtdc.bemd_0(-914763285);
if (bevl_oany == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 438 */ {
bevt_47_tmpany_phold = bevl_oany.bemd_0(449899320);
if (((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 438 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 438 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 438 */
 else  /* Line: 438 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 438 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_tmpany_phold = bevl_oany.bemd_0(-1639093451);
if (((BEC_2_5_4_LogicBool) bevt_48_tmpany_phold).bevi_bool) /* Line: 441 */ {
bevl_nv.bemd_1(1055126381, bevl_targNp);
} /* Line: 442 */
 else  /* Line: 443 */ {
bevt_49_tmpany_phold = bevl_oany.bemd_0(553602060);
bevl_nv.bemd_1(1055126381, bevt_49_tmpany_phold);
} /* Line: 444 */
bevt_50_tmpany_phold = bevl_oany.bemd_0(449899320);
bevl_nv.bemd_1(-456726460, bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bevp_inClass.bemd_0(766752427);
bevt_52_tmpany_phold = bevl_nv.bemd_0(553602060);
bevt_51_tmpany_phold.bemd_1(828539200, bevt_52_tmpany_phold);
bevt_55_tmpany_phold = bevl_nv.bemd_0(553602060);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(2079582721);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_3));
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_1(-1755209627, bevt_56_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_53_tmpany_phold).bevi_bool) /* Line: 448 */ {
bevt_58_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5;
bevt_59_tmpany_phold = bevl_oany.bemd_0(-1639093451);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold.bem_print_0();
} /* Line: 448 */
} /* Line: 448 */
} /* Line: 438 */
 else  /* Line: 435 */ {
bevt_62_tmpany_phold = bevl_tcall.bemd_0(766752427);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-1521739407);
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_1(564481139, bevt_63_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 450 */ {
bevt_64_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_65_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_tmpany_phold.bem_get_1(bevt_65_tmpany_phold);
if (bevl_fcms == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 452 */ {
bevt_69_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_toString_0();
bevt_70_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7;
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_notEquals_1(bevt_70_tmpany_phold);
if (bevt_67_tmpany_phold.bevi_bool) /* Line: 452 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 452 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 452 */
 else  /* Line: 452 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 452 */ {
bevt_71_tmpany_phold = bevl_tcall.bemd_0(766752427);
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_71_tmpany_phold.bemd_1(-1562456540, bevt_72_tmpany_phold);
} /* Line: 453 */
 else  /* Line: 454 */ {
bevt_77_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8;
bevt_79_tmpany_phold = bevl_tcall.bemd_0(766752427);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(1320525264);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bem_add_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9;
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_add_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = bevl_targNp.bemd_0(2079582721);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_81_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 455 */
} /* Line: 452 */
} /* Line: 435 */
} /* Line: 435 */
} /* Line: 431 */
 else  /* Line: 410 */ {
bevt_82_tmpany_phold = bevl_k.bemd_0(-1877380973);
if (((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 461 */ {
bevt_85_tmpany_phold = bevl_k.bemd_0(32824861);
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bemd_0(1547933631);
bevt_86_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_1(-1755209627, bevt_86_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_83_tmpany_phold).bevi_bool) /* Line: 461 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 461 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 461 */
 else  /* Line: 461 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 461 */ {
bevt_90_tmpany_phold = bevl_k.bemd_0(32824861);
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_0(766752427);
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bemd_0(-1521739407);
bevt_91_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bemd_1(-1755209627, bevt_91_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_87_tmpany_phold).bevi_bool) /* Line: 461 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 461 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 461 */
 else  /* Line: 461 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 461 */ {
bevt_95_tmpany_phold = bevl_k.bemd_0(32824861);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_0(-895308102);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(1547933631);
bevt_96_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_1(-1755209627, bevt_96_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 461 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 461 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 461 */
 else  /* Line: 461 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 461 */ {
bevt_98_tmpany_phold = bevl_k.bemd_0(32824861);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_0(-895308102);
bevl_targ = bevt_97_tmpany_phold.bemd_0(766752427);
bevt_99_tmpany_phold = bevl_targ.bemd_0(449899320);
if (((BEC_2_5_4_LogicBool) bevt_99_tmpany_phold).bevi_bool) /* Line: 464 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_tmpany_phold = bevl_targ.bemd_0(449899320);
bevl_nv.bemd_1(-456726460, bevt_100_tmpany_phold);
bevt_101_tmpany_phold = bevl_targ.bemd_0(553602060);
bevl_nv.bemd_1(1055126381, bevt_101_tmpany_phold);
} /* Line: 469 */
} /* Line: 464 */
} /* Line: 410 */
} /* Line: 410 */
 else  /* Line: 409 */ {
break;
} /* Line: 409 */
} /* Line: 409 */
} /* Line: 409 */
} /* Line: 404 */
 else  /* Line: 401 */ {
break;
} /* Line: 401 */
} /* Line: 401 */
} /* Line: 401 */
 else  /* Line: 399 */ {
break;
} /* Line: 399 */
} /* Line: 399 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_tvmapGetDirect_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tvmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_tvmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tvmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_rmapGetDirect_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_rmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_inClassGetDirect_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_inClassNpGetDirect_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_inClassSynGetDirect_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_nlGetDirect_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {348, 348, 348, 348, 348, 348, 0, 0, 0, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 0, 0, 0, 350, 0, 0, 0, 352, 352, 352, 352, 352, 352, 352, 352, 352, 0, 0, 0, 353, 353, 353, 353, 354, 354, 355, 355, 355, 355, 355, 355, 355, 355, 355, 357, 358, 358, 358, 358, 359, 359, 361, 361, 362, 362, 362, 362, 367, 367, 367, 367, 368, 369, 369, 370, 370, 372, 372, 372, 372, 373, 374, 375, 375, 375, 375, 375, 375, 0, 0, 0, 376, 376, 376, 376, 377, 377, 377, 378, 378, 379, 380, 380, 380, 382, 383, 383, 383, 383, 383, 383, 383, 0, 0, 0, 383, 383, 383, 383, 0, 0, 0, 383, 383, 383, 383, 383, 383, 0, 0, 0, 385, 387, 387, 391, 400, 401, 401, 402, 404, 404, 407, 408, 409, 0, 409, 409, 410, 410, 410, 410, 410, 0, 0, 0, 410, 410, 410, 410, 410, 0, 0, 0, 410, 410, 410, 410, 410, 0, 0, 0, 412, 412, 413, 414, 414, 414, 414, 415, 415, 417, 417, 421, 421, 422, 424, 424, 424, 424, 424, 427, 428, 431, 431, 433, 434, 434, 434, 434, 435, 435, 437, 438, 438, 438, 0, 0, 0, 439, 441, 442, 444, 444, 446, 446, 447, 447, 447, 448, 448, 448, 448, 448, 448, 448, 448, 450, 450, 450, 450, 451, 451, 451, 452, 452, 452, 452, 452, 452, 0, 0, 0, 453, 453, 453, 455, 455, 455, 455, 455, 455, 455, 455, 455, 455, 461, 461, 461, 461, 461, 0, 0, 0, 461, 461, 461, 461, 461, 0, 0, 0, 461, 461, 461, 461, 461, 0, 0, 0, 462, 462, 462, 464, 466, 468, 468, 469, 469, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {135, 136, 137, 142, 143, 144, 146, 149, 153, 156, 157, 158, 159, 164, 165, 166, 167, 168, 169, 171, 174, 178, 181, 183, 186, 190, 193, 194, 195, 196, 197, 199, 200, 201, 202, 204, 207, 211, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 239, 240, 241, 242, 243, 244, 245, 250, 251, 252, 257, 258, 259, 260, 261, 262, 264, 265, 266, 271, 272, 273, 276, 277, 278, 283, 284, 285, 287, 290, 294, 297, 298, 299, 300, 301, 302, 303, 304, 309, 310, 311, 312, 313, 315, 318, 319, 320, 325, 326, 327, 332, 333, 336, 340, 343, 344, 345, 350, 351, 354, 358, 361, 362, 363, 364, 365, 370, 371, 374, 378, 381, 385, 386, 505, 509, 510, 513, 515, 516, 517, 519, 520, 521, 521, 524, 526, 527, 529, 530, 531, 532, 534, 537, 541, 544, 545, 546, 547, 548, 550, 553, 557, 560, 561, 562, 563, 564, 566, 569, 573, 576, 577, 578, 579, 580, 581, 586, 587, 588, 591, 592, 593, 594, 596, 599, 600, 601, 602, 603, 605, 607, 610, 615, 616, 617, 618, 619, 620, 621, 626, 627, 628, 633, 634, 636, 639, 643, 646, 647, 649, 652, 653, 655, 656, 657, 658, 659, 660, 661, 662, 663, 665, 666, 667, 668, 673, 674, 675, 676, 678, 679, 680, 681, 686, 687, 688, 689, 690, 692, 695, 699, 702, 703, 704, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 723, 725, 726, 727, 728, 730, 733, 737, 740, 741, 742, 743, 744, 746, 749, 753, 756, 757, 758, 759, 760, 762, 765, 769, 772, 773, 774, 775, 777, 778, 779, 780, 781, 804, 807, 810, 814, 818, 821, 824, 828, 832, 835, 838, 842, 846, 849, 852, 856, 860, 863, 866, 870, 874, 877, 880, 884, 888, 891, 894, 898};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 348 135
typenameGet 0 348 135
assign 1 348 136
CALLGet 0 348 136
assign 1 348 137
equals 1 348 142
assign 1 348 143
heldGet 0 348 143
assign 1 348 144
wasForeachGennedGet 0 348 144
assign 1 0 146
assign 1 0 149
assign 1 0 153
assign 1 350 156
containerGet 0 350 156
assign 1 350 157
typenameGet 0 350 157
assign 1 350 158
CALLGet 0 350 158
assign 1 350 159
equals 1 350 164
assign 1 350 165
containerGet 0 350 165
assign 1 350 166
heldGet 0 350 166
assign 1 350 167
orgNameGet 0 350 167
assign 1 350 168
new 0 350 168
assign 1 350 169
equals 1 350 169
assign 1 0 171
assign 1 0 174
assign 1 0 178
assign 1 350 181
isSecondGet 0 350 181
assign 1 0 183
assign 1 0 186
assign 1 0 190
assign 1 352 193
containedGet 0 352 193
assign 1 352 194
firstGet 0 352 194
assign 1 352 195
typenameGet 0 352 195
assign 1 352 196
VARGet 0 352 196
assign 1 352 197
equals 1 352 197
assign 1 352 199
containedGet 0 352 199
assign 1 352 200
firstGet 0 352 200
assign 1 352 201
heldGet 0 352 201
assign 1 352 202
isTypedGet 0 352 202
assign 1 0 204
assign 1 0 207
assign 1 0 211
assign 1 353 214
containedGet 0 353 214
assign 1 353 215
firstGet 0 353 215
assign 1 353 216
heldGet 0 353 216
assign 1 353 217
namepathGet 0 353 217
assign 1 354 218
stepsGet 0 354 218
assign 1 354 219
lastGet 0 354 219
assign 1 355 220
new 0 355 220
assign 1 355 221
new 0 355 221
assign 1 355 222
substring 2 355 222
assign 1 355 223
lowerValue 0 355 223
assign 1 355 224
new 0 355 224
assign 1 355 225
substring 1 355 225
assign 1 355 226
add 1 355 226
assign 1 355 227
new 0 355 227
assign 1 355 228
add 1 355 228
assign 1 357 229
getSynNp 1 357 229
assign 1 358 230
mtdMapGet 0 358 230
assign 1 358 231
new 0 358 231
assign 1 358 232
add 1 358 232
assign 1 358 233
get 1 358 233
assign 1 359 234
def 1 359 239
assign 1 361 240
heldGet 0 361 240
orgNameSet 1 361 241
assign 1 362 242
heldGet 0 362 242
assign 1 362 243
new 0 362 243
assign 1 362 244
add 1 362 244
nameSet 1 362 245
assign 1 367 250
typenameGet 0 367 250
assign 1 367 251
CLASSGet 0 367 251
assign 1 367 252
equals 1 367 257
assign 1 368 258
assign 1 369 259
heldGet 0 369 259
assign 1 369 260
namepathGet 0 369 260
assign 1 370 261
heldGet 0 370 261
assign 1 370 262
synGet 0 370 262
assign 1 372 264
typenameGet 0 372 264
assign 1 372 265
METHODGet 0 372 265
assign 1 372 266
equals 1 372 271
assign 1 373 272
new 0 373 272
assign 1 374 273
new 0 374 273
assign 1 375 276
typenameGet 0 375 276
assign 1 375 277
VARGet 0 375 277
assign 1 375 278
equals 1 375 283
assign 1 375 284
heldGet 0 375 284
assign 1 375 285
autoTypeGet 0 375 285
assign 1 0 287
assign 1 0 290
assign 1 0 294
assign 1 376 297
heldGet 0 376 297
assign 1 376 298
nameGet 0 376 298
assign 1 376 299
heldGet 0 376 299
put 2 376 300
assign 1 377 301
heldGet 0 377 301
assign 1 377 302
nameGet 0 377 302
assign 1 377 303
get 1 377 303
assign 1 378 304
undef 1 378 309
assign 1 379 310
new 0 379 310
assign 1 380 311
heldGet 0 380 311
assign 1 380 312
nameGet 0 380 312
put 2 380 313
addValue 1 382 315
assign 1 383 318
typenameGet 0 383 318
assign 1 383 319
RBRACESGet 0 383 319
assign 1 383 320
equals 1 383 325
assign 1 383 326
containerGet 0 383 326
assign 1 383 327
def 1 383 332
assign 1 0 333
assign 1 0 336
assign 1 0 340
assign 1 383 343
containerGet 0 383 343
assign 1 383 344
containerGet 0 383 344
assign 1 383 345
def 1 383 350
assign 1 0 351
assign 1 0 354
assign 1 0 358
assign 1 383 361
containerGet 0 383 361
assign 1 383 362
containerGet 0 383 362
assign 1 383 363
typenameGet 0 383 363
assign 1 383 364
METHODGet 0 383 364
assign 1 383 365
equals 1 383 370
assign 1 0 371
assign 1 0 374
assign 1 0 378
processTmps 0 385 381
assign 1 387 385
nextDescendGet 0 387 385
return 1 387 386
assign 1 391 505
new 0 391 505
assign 1 400 509
new 0 400 509
assign 1 401 510
valueIteratorGet 0 401 510
assign 1 401 513
hasNextGet 0 401 513
assign 1 402 515
nextGet 0 402 515
assign 1 404 516
isTypedGet 0 404 516
assign 1 404 517
not 0 404 517
assign 1 407 519
nameGet 0 407 519
assign 1 408 520
get 1 408 520
assign 1 409 521
iteratorGet 0 0 521
assign 1 409 524
hasNextGet 0 409 524
assign 1 409 526
nextGet 0 409 526
assign 1 410 527
isFirstGet 0 410 527
assign 1 410 529
containerGet 0 410 529
assign 1 410 530
typenameGet 0 410 530
assign 1 410 531
CALLGet 0 410 531
assign 1 410 532
equals 1 410 532
assign 1 0 534
assign 1 0 537
assign 1 0 541
assign 1 410 544
containerGet 0 410 544
assign 1 410 545
heldGet 0 410 545
assign 1 410 546
orgNameGet 0 410 546
assign 1 410 547
new 0 410 547
assign 1 410 548
equals 1 410 548
assign 1 0 550
assign 1 0 553
assign 1 0 557
assign 1 410 560
containerGet 0 410 560
assign 1 410 561
secondGet 0 410 561
assign 1 410 562
typenameGet 0 410 562
assign 1 410 563
CALLGet 0 410 563
assign 1 410 564
equals 1 410 564
assign 1 0 566
assign 1 0 569
assign 1 0 573
assign 1 412 576
containerGet 0 412 576
assign 1 412 577
secondGet 0 412 577
assign 1 413 578
assign 1 414 579
heldGet 0 414 579
assign 1 414 580
newNpGet 0 414 580
assign 1 414 581
def 1 414 586
assign 1 415 587
heldGet 0 415 587
assign 1 415 588
newNpGet 0 415 588
assign 1 417 591
containedGet 0 417 591
assign 1 417 592
firstGet 0 417 592
assign 1 421 593
heldGet 0 421 593
assign 1 421 594
isDeclaredGet 0 421 594
assign 1 422 596
heldGet 0 422 596
assign 1 424 599
ptyMapGet 0 424 599
assign 1 424 600
heldGet 0 424 600
assign 1 424 601
nameGet 0 424 601
assign 1 424 602
get 1 424 602
assign 1 424 603
memSynGet 0 424 603
assign 1 427 605
isTypedGet 0 427 605
assign 1 428 607
namepathGet 0 428 607
assign 1 431 610
def 1 431 615
assign 1 433 616
getSynNp 1 433 616
assign 1 434 617
mtdMapGet 0 434 617
assign 1 434 618
heldGet 0 434 618
assign 1 434 619
nameGet 0 434 619
assign 1 434 620
get 1 434 620
assign 1 435 621
def 1 435 626
assign 1 437 627
rsynGet 0 437 627
assign 1 438 628
def 1 438 633
assign 1 438 634
isTypedGet 0 438 634
assign 1 0 636
assign 1 0 639
assign 1 0 643
assign 1 439 646
new 0 439 646
assign 1 441 647
isSelfGet 0 441 647
namepathSet 1 442 649
assign 1 444 652
namepathGet 0 444 652
namepathSet 1 444 653
assign 1 446 655
isTypedGet 0 446 655
isTypedSet 1 446 656
assign 1 447 657
heldGet 0 447 657
assign 1 447 658
namepathGet 0 447 658
addUsed 1 447 659
assign 1 448 660
namepathGet 0 448 660
assign 1 448 661
toString 0 448 661
assign 1 448 662
new 0 448 662
assign 1 448 663
equals 1 448 663
assign 1 448 665
new 0 448 665
assign 1 448 666
isSelfGet 0 448 666
assign 1 448 667
add 1 448 667
print 0 448 668
assign 1 450 673
heldGet 0 450 673
assign 1 450 674
orgNameGet 0 450 674
assign 1 450 675
new 0 450 675
assign 1 450 676
notEquals 1 450 676
assign 1 451 678
mtdMapGet 0 451 678
assign 1 451 679
new 0 451 679
assign 1 451 680
get 1 451 680
assign 1 452 681
def 1 452 686
assign 1 452 687
originGet 0 452 687
assign 1 452 688
toString 0 452 688
assign 1 452 689
new 0 452 689
assign 1 452 690
notEquals 1 452 690
assign 1 0 692
assign 1 0 695
assign 1 0 699
assign 1 453 702
heldGet 0 453 702
assign 1 453 703
new 0 453 703
isForwardSet 1 453 704
assign 1 455 707
new 0 455 707
assign 1 455 708
heldGet 0 455 708
assign 1 455 709
nameGet 0 455 709
assign 1 455 710
add 1 455 710
assign 1 455 711
new 0 455 711
assign 1 455 712
add 1 455 712
assign 1 455 713
toString 0 455 713
assign 1 455 714
add 1 455 714
assign 1 455 715
new 2 455 715
throw 1 455 716
assign 1 461 723
isFirstGet 0 461 723
assign 1 461 725
containerGet 0 461 725
assign 1 461 726
typenameGet 0 461 726
assign 1 461 727
CALLGet 0 461 727
assign 1 461 728
equals 1 461 728
assign 1 0 730
assign 1 0 733
assign 1 0 737
assign 1 461 740
containerGet 0 461 740
assign 1 461 741
heldGet 0 461 741
assign 1 461 742
orgNameGet 0 461 742
assign 1 461 743
new 0 461 743
assign 1 461 744
equals 1 461 744
assign 1 0 746
assign 1 0 749
assign 1 0 753
assign 1 461 756
containerGet 0 461 756
assign 1 461 757
secondGet 0 461 757
assign 1 461 758
typenameGet 0 461 758
assign 1 461 759
VARGet 0 461 759
assign 1 461 760
equals 1 461 760
assign 1 0 762
assign 1 0 765
assign 1 0 769
assign 1 462 772
containerGet 0 462 772
assign 1 462 773
secondGet 0 462 773
assign 1 462 774
heldGet 0 462 774
assign 1 464 775
isTypedGet 0 464 775
assign 1 466 777
new 0 466 777
assign 1 468 778
isTypedGet 0 468 778
isTypedSet 1 468 779
assign 1 469 780
namepathGet 0 469 780
namepathSet 1 469 781
return 1 0 804
return 1 0 807
assign 1 0 810
assign 1 0 814
return 1 0 818
return 1 0 821
assign 1 0 824
assign 1 0 828
return 1 0 832
return 1 0 835
assign 1 0 838
assign 1 0 842
return 1 0 846
return 1 0 849
assign 1 0 852
assign 1 0 856
return 1 0 860
return 1 0 863
assign 1 0 866
assign 1 0 870
return 1 0 874
return 1 0 877
assign 1 0 880
assign 1 0 884
return 1 0 888
return 1 0 891
assign 1 0 894
assign 1 0 898
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2079582721: return bem_toString_0();
case 572016682: return bem_serializationIteratorGet_0();
case -165278261: return bem_hashGet_0();
case -468320702: return bem_buildGet_0();
case -980602152: return bem_sourceFileNameGet_0();
case 577869439: return bem_serializeToString_0();
case 1426663753: return bem_constGetDirect_0();
case -579194210: return bem_iteratorGet_0();
case 1582322711: return bem_inClassGetDirect_0();
case 37306956: return bem_inClassNpGet_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case 1924958515: return bem_inClassNpGetDirect_0();
case -1168657718: return bem_create_0();
case -666874899: return bem_rmapGetDirect_0();
case -683357679: return bem_nlGet_0();
case 659732166: return bem_ntypesGet_0();
case -2002478337: return bem_inClassSynGet_0();
case 1476265575: return bem_toAny_0();
case 448246445: return bem_fieldNamesGet_0();
case -851184133: return bem_transGetDirect_0();
case 11313755: return bem_echo_0();
case 75566354: return bem_nlGetDirect_0();
case -1791746868: return bem_print_0();
case -1045898755: return bem_classNameGet_0();
case 1568711247: return bem_fieldIteratorGet_0();
case -1489022328: return bem_once_0();
case -1116164859: return bem_processTmps_0();
case -1551951531: return bem_tvmapGet_0();
case -1406264904: return bem_copy_0();
case -1300457482: return bem_ntypesGetDirect_0();
case 334571614: return bem_many_0();
case -1430069919: return bem_serializeContents_0();
case 2100472403: return bem_emitterGetDirect_0();
case -1183731866: return bem_tvmapGetDirect_0();
case -960305035: return bem_inClassSynGetDirect_0();
case 542801456: return bem_buildGetDirect_0();
case -1105672836: return bem_emitterGet_0();
case -34821988: return bem_rmapGet_0();
case -380536911: return bem_transGet_0();
case -6461226: return bem_inClassGet_0();
case 1546949403: return bem_constGet_0();
case -1682958828: return bem_tagGet_0();
case -621270081: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case -1256507068: return bem_inClassSet_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case -1089335093: return bem_buildSet_1(bevd_0);
case 1512280155: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1585160793: return bem_transSet_1(bevd_0);
case -366425322: return bem_nlSet_1(bevd_0);
case -1994633283: return bem_buildSetDirect_1(bevd_0);
case -506975158: return bem_begin_1(bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
case 2133147267: return bem_rmapSetDirect_1(bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case 1605464704: return bem_ntypesSet_1(bevd_0);
case -1768975604: return bem_inClassSynSet_1(bevd_0);
case -1887185890: return bem_emitterSetDirect_1(bevd_0);
case 514359451: return bem_inClassNpSetDirect_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case 918677435: return bem_emitterSet_1(bevd_0);
case -841896783: return bem_inClassSynSetDirect_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case -627017966: return bem_ntypesSetDirect_1(bevd_0);
case -213196985: return bem_tvmapSet_1(bevd_0);
case 731342932: return bem_inClassSetDirect_1(bevd_0);
case -2087957875: return bem_transSetDirect_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case -1550414549: return bem_end_1(bevd_0);
case 1282837112: return bem_rmapSet_1(bevd_0);
case -31569567: return bem_inClassNpSet_1(bevd_0);
case -829247280: return bem_nlSetDirect_1(bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case -646810197: return bem_constSetDirect_1(bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1921567906: return bem_tvmapSetDirect_1(bevd_0);
case -2127484246: return bem_constSet_1(bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;
}
}
