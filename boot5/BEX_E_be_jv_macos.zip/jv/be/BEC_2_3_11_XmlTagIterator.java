package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator extends BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x2D,0x2D};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x20};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x2F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3D};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x3A};
public static BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;

public static BET_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_type;

public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public BEC_2_3_11_XmlTagIterator bem_new_0() throws Throwable {
bevp_started = be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_line = (new BEC_2_4_3_MathInt(1));
bevp_skip = be.BECS_Runtime.boolFalse;
bevp_debug = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) throws Throwable {
bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_restart_0() throws Throwable {
bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_start_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_2_ta_ph = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_ta_ph.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
while (true)
/* Line: 167*/ {
if (bevl_nxt == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_4_ta_ph = bevl_nxt.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 167*/
 else /* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 167*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 168*/
 else /* Line: 167*/ {
break;
} /* Line: 167*/
} /* Line: 167*/
if (bevl_nxt == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_7_ta_ph = bevl_nxt.bem_equals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 170*/
 else /* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 170*/ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 171*/
return this;
} /*method end*/
public BEC_2_3_3_XmlTag bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_12_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_13_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_14_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_15_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_16_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_17_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_18_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_19_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_4_7_TextStrings bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_3_8_XmlTextNode bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_3_7_XmlComment bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_5_4_LogicBool bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_5_4_LogicBool bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_5_4_LogicBool bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_5_4_LogicBool bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_5_4_LogicBool bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_5_4_LogicBool bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_5_4_LogicBool bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_5_4_LogicBool bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_4_LogicBool bevt_116_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_ta_ph = null;
BEC_2_4_6_TextString bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_5_4_LogicBool bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_5_4_LogicBool bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_5_4_LogicBool bevt_126_ta_ph = null;
BEC_2_4_6_TextString bevt_127_ta_ph = null;
BEC_2_5_4_LogicBool bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_5_4_LogicBool bevt_130_ta_ph = null;
BEC_2_4_6_TextString bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_ta_ph = null;
BEC_2_4_6_TextString bevt_134_ta_ph = null;
BEC_2_4_6_TextString bevt_135_ta_ph = null;
BEC_2_4_6_TextString bevt_136_ta_ph = null;
BEC_2_4_6_TextString bevt_137_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 176*/ {
bem_start_0();
} /* Line: 177*/
bevt_21_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_ta_ph.bem_quoteGet_0();
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_ta_ph.bem_newlineGet_0();
if (bevp_skip.bevi_bool)/* Line: 182*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(178947736);
bevp_skip = be.BECS_Runtime.boolFalse;
} /* Line: 184*/
 else /* Line: 185*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 186*/
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 189*/ {
if (bevp_textNode.bevi_bool)/* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 189*/
 else /* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 189*/ {
while (true)
/* Line: 190*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_24_ta_ph = bevl_nxt.bem_notEquals_1(bevt_25_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 190*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 192*/
 else /* Line: 190*/ {
break;
} /* Line: 190*/
} /* Line: 190*/
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_27_ta_ph = bevl_accum.bem_extractString_0();
bevt_26_ta_ph = (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_ta_ph);
return bevt_26_ta_ph;
} /* Line: 196*/
 else /* Line: 189*/ {
if (bevl_nxt == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_29_ta_ph = bevl_nxt.bem_equals_1(bevt_30_ta_ph);
if (bevt_29_ta_ph.bevi_bool)/* Line: 198*/ {
bevl_tagName = be.BECS_Runtime.boolTrue;
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolFalse;
bevl_isStart = be.BECS_Runtime.boolTrue;
while (true)
/* Line: 205*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_31_ta_ph = bevl_nxt.bem_notEquals_1(bevt_32_ta_ph);
if (bevt_31_ta_ph.bevi_bool)/* Line: 205*/ {
if (bevl_pinstruct.bevi_bool)/* Line: 206*/ {
bevl_instr = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 208*/ {
if (bevl_instr.bevi_bool)/* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 208*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_33_ta_ph = bevl_nxt.bem_notEquals_1(bevt_34_ta_ph);
if (bevt_33_ta_ph.bevi_bool)/* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 208*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 208*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_ta_ph = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_ta_ph.bevi_bool)/* Line: 210*/ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 211*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 213*/
 else /* Line: 208*/ {
break;
} /* Line: 208*/
} /* Line: 208*/
bevt_36_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_36_ta_ph);
bevl_pinstruct = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 217*/ {
if (bevl_nxt == null) {
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_38_ta_ph = bevl_nxt.bem_notEquals_1(bevt_39_ta_ph);
if (bevt_38_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 217*/
 else /* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 217*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 218*/
 else /* Line: 217*/ {
break;
} /* Line: 217*/
} /* Line: 217*/
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_41_ta_ph = bevl_accum.bem_toString_0();
bevt_40_ta_ph = (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_ta_ph);
return bevt_40_ta_ph;
} /* Line: 221*/
if (bevl_comment.bevi_bool)/* Line: 223*/ {
while (true)
/* Line: 224*/ {
bevt_43_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_42_ta_ph = bevl_nxt.bem_notEquals_1(bevt_43_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 224*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_44_ta_ph = bevl_nxt.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_48_ta_ph = bevl_accum.bem_toString_0();
bevt_49_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_2));
bevt_47_ta_ph = bevt_48_ta_ph.bem_ends_1(bevt_49_ta_ph);
if (bevt_47_ta_ph.bevi_bool) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 227*/
 else /* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 227*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 229*/
} /* Line: 227*/
 else /* Line: 224*/ {
break;
} /* Line: 224*/
} /* Line: 224*/
bevl_comment = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 233*/ {
if (bevl_nxt == null) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_51_ta_ph = bevl_nxt.bem_notEquals_1(bevt_52_ta_ph);
if (bevt_51_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 233*/
 else /* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 233*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 234*/
 else /* Line: 233*/ {
break;
} /* Line: 233*/
} /* Line: 233*/
bevt_53_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_53_ta_ph);
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_55_ta_ph = bevl_accum.bem_extractString_0();
bevt_54_ta_ph = (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_ta_ph);
return bevt_54_ta_ph;
} /* Line: 238*/
if (bevl_tagName.bevi_bool)/* Line: 240*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
while (true)
/* Line: 242*/ {
bevt_57_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_56_ta_ph = bevl_nxt.bem_equals_1(bevt_57_ta_ph);
if (bevt_56_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_58_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 242*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 242*/ {
bevt_59_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_ta_ph.bevi_bool)/* Line: 243*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 243*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 244*/
 else /* Line: 242*/ {
break;
} /* Line: 242*/
} /* Line: 242*/
bevt_61_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_4));
bevt_60_ta_ph = bevl_nxt.bem_equals_1(bevt_61_ta_ph);
if (bevt_60_ta_ph.bevi_bool)/* Line: 246*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
bevl_accum.bem_extractString_0();
bevt_62_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_5));
bevl_accum.bem_addValue_1(bevt_62_ta_ph);
} /* Line: 251*/
 else /* Line: 246*/ {
bevt_64_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_6));
bevt_63_ta_ph = bevl_nxt.bem_equals_1(bevt_64_ta_ph);
if (bevt_63_ta_ph.bevi_bool)/* Line: 252*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
bevl_accum.bem_extractString_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_7));
bevl_accum.bem_addValue_1(bevt_65_ta_ph);
} /* Line: 257*/
 else /* Line: 258*/ {
bevt_67_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_66_ta_ph = bevl_nxt.bem_equals_1(bevt_67_ta_ph);
if (bevt_66_ta_ph.bevi_bool)/* Line: 259*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 261*/
while (true)
/* Line: 263*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_68_ta_ph = bevl_nxt.bem_notEquals_1(bevt_69_ta_ph);
if (bevt_68_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_70_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 263*/ {
bevt_72_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_71_ta_ph = bevl_nxt.bem_notEquals_1(bevt_72_ta_ph);
if (bevt_71_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 263*/ {
bevt_74_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_73_ta_ph = bevl_nxt.bem_notEquals_1(bevt_74_ta_ph);
if (bevt_73_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 263*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 265*/
 else /* Line: 263*/ {
break;
} /* Line: 263*/
} /* Line: 263*/
bevt_75_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_ta_ph.bevi_bool)/* Line: 267*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 267*/
bevl_tagName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 269*/ {
bevl_myElement = (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_ta_ph);
} /* Line: 272*/
 else /* Line: 273*/ {
bevl_myEndElement = (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_ta_ph = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_ta_ph);
bevl_myTag = bevl_myEndElement;
} /* Line: 276*/
bevt_79_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_78_ta_ph = bevl_nxt.bem_equals_1(bevt_79_ta_ph);
if (bevt_78_ta_ph.bevi_bool)/* Line: 278*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 280*/ {
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 281*/
} /* Line: 280*/
 else /* Line: 278*/ {
bevt_81_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_80_ta_ph = bevl_nxt.bem_equals_1(bevt_81_ta_ph);
if (bevt_80_ta_ph.bevi_bool)/* Line: 283*/ {
if (bevl_isStart.bevi_bool)/* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 283*/
 else /* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 283*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 286*/
 else /* Line: 278*/ {
if (bevl_isStart.bevi_bool)/* Line: 287*/ {
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 288*/
 else /* Line: 289*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
} /* Line: 290*/
} /* Line: 278*/
} /* Line: 278*/
} /* Line: 278*/
} /* Line: 246*/
} /* Line: 246*/
if (bevl_attributeName.bevi_bool)/* Line: 294*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
while (true)
/* Line: 296*/ {
bevt_84_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_83_ta_ph = bevl_nxt.bem_equals_1(bevt_84_ta_ph);
if (bevt_83_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_85_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 296*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 296*/ {
bevt_86_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_ta_ph.bevi_bool)/* Line: 297*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 297*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 298*/
 else /* Line: 296*/ {
break;
} /* Line: 296*/
} /* Line: 296*/
while (true)
/* Line: 300*/ {
bevt_88_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_87_ta_ph = bevl_nxt.bem_notEquals_1(bevt_88_ta_ph);
if (bevt_87_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_89_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_14_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_91_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_90_ta_ph = bevl_nxt.bem_notEquals_1(bevt_91_ta_ph);
if (bevt_90_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_13_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_93_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_92_ta_ph = bevl_nxt.bem_notEquals_1(bevt_93_ta_ph);
if (bevt_92_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_12_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_95_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_9));
bevt_94_ta_ph = bevl_nxt.bem_notEquals_1(bevt_95_ta_ph);
if (bevt_94_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_11_ta_anchor.bevi_bool)/* Line: 300*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 302*/
 else /* Line: 300*/ {
break;
} /* Line: 300*/
} /* Line: 300*/
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_96_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_ta_ph.bevi_bool)/* Line: 305*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 305*/
bevt_98_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_97_ta_ph = bevl_nxt.bem_equals_1(bevt_98_ta_ph);
if (bevt_97_ta_ph.bevi_bool)/* Line: 306*/ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 308*/
 else /* Line: 306*/ {
bevt_100_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_99_ta_ph = bevl_nxt.bem_equals_1(bevt_100_ta_ph);
if (bevt_99_ta_ph.bevi_bool)/* Line: 309*/ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_101_ta_ph = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 312*/
 else /* Line: 313*/ {
bevt_102_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_ta_ph);
bevl_attributeValue = be.BECS_Runtime.boolTrue;
} /* Line: 315*/
} /* Line: 306*/
} /* Line: 306*/
if (bevl_attributeValue.bevi_bool)/* Line: 318*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
while (true)
/* Line: 320*/ {
bevt_104_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_103_ta_ph = bevl_nxt.bem_equals_1(bevt_104_ta_ph);
if (bevt_103_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_105_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 320*/
if (bevt_16_ta_anchor.bevi_bool)/* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_107_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_9));
bevt_106_ta_ph = bevl_nxt.bem_equals_1(bevt_107_ta_ph);
if (bevt_106_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 320*/
if (bevt_15_ta_anchor.bevi_bool)/* Line: 320*/ {
bevt_108_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_ta_ph.bevi_bool)/* Line: 322*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 322*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 323*/
 else /* Line: 320*/ {
break;
} /* Line: 320*/
} /* Line: 320*/
bevt_109_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_ta_ph.bevi_bool)/* Line: 325*/ {
bevt_112_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_3_11_XmlTagIterator_bels_10));
bevt_113_ta_ph = bevp_line.bem_toString_0();
bevt_111_ta_ph = bevt_112_ta_ph.bem_add_1(bevt_113_ta_ph);
bevt_110_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_ta_ph);
throw new be.BECS_ThrowBack(bevt_110_ta_ph);
} /* Line: 326*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
while (true)
/* Line: 329*/ {
bevt_114_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_115_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_ta_ph.bevi_bool)/* Line: 330*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 330*/
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 332*/
 else /* Line: 329*/ {
break;
} /* Line: 329*/
} /* Line: 329*/
bevt_116_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_ta_ph.bevi_bool)/* Line: 334*/ {
bevt_119_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_3_11_XmlTagIterator_bels_10));
bevt_120_ta_ph = bevp_line.bem_toString_0();
bevt_118_ta_ph = bevt_119_ta_ph.bem_add_1(bevt_120_ta_ph);
bevt_117_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_ta_ph);
throw new be.BECS_ThrowBack(bevt_117_ta_ph);
} /* Line: 335*/
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_121_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_ta_ph);
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 339*/
} /* Line: 318*/
 else /* Line: 205*/ {
break;
} /* Line: 205*/
} /* Line: 205*/
if (bevl_myEndElement == null) {
bevt_122_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_122_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
if (bevl_myElement == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_124_ta_ph = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 342*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 342*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 342*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
while (true)
/* Line: 344*/ {
if (bevl_nxt == null) {
bevt_125_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_125_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_127_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_126_ta_ph = bevl_nxt.bem_equals_1(bevt_127_ta_ph);
if (bevt_126_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_128_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 344*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 344*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 344*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(233311811);
} /* Line: 344*/
 else /* Line: 344*/ {
break;
} /* Line: 344*/
} /* Line: 344*/
if (bevl_nxt == null) {
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_131_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_130_ta_ph = bevl_nxt.bem_equals_1(bevt_131_ta_ph);
if (bevt_130_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 345*/
 else /* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_19_ta_anchor.bevi_bool)/* Line: 345*/ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 345*/
} /* Line: 345*/
} /* Line: 342*/
 else /* Line: 347*/ {
if (bevl_nxt == null) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 348*/ {
bevl_nxt = (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_11));
} /* Line: 348*/
bevt_136_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_3_11_XmlTagIterator_bels_12));
bevt_135_ta_ph = bevt_136_ta_ph.bem_add_1(bevl_nxt);
bevt_137_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_13));
bevt_134_ta_ph = bevt_135_ta_ph.bem_add_1(bevt_137_ta_ph);
bevt_133_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_ta_ph);
throw new be.BECS_ThrowBack(bevt_133_ta_ph);
} /* Line: 349*/
} /* Line: 198*/
} /* Line: 189*/
return bevl_myTag;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 356*/
bevt_2_ta_ph = bevp_iter.bemd_0(-1182092368);
return (BEC_2_5_4_LogicBool) bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_xmlStringGet_0() throws Throwable {
return bevp_xmlString;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startedGet_0() throws Throwable {
return bevp_started;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_xtGet_0() throws Throwable {
return bevp_xt;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_resGet_0() throws Throwable {
return bevp_res;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_iter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_textNodeGet_0() throws Throwable {
return bevp_textNode;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipGet_0() throws Throwable {
return bevp_skip;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {137, 138, 139, 140, 141, 142, 143, 144, 149, 150, 154, 158, 162, 162, 163, 164, 166, 167, 167, 167, 167, 0, 0, 0, 168, 170, 170, 170, 170, 0, 0, 0, 171, 176, 176, 177, 180, 180, 181, 181, 183, 184, 186, 188, 189, 189, 0, 0, 0, 190, 190, 191, 192, 194, 195, 196, 196, 196, 197, 197, 198, 198, 199, 200, 201, 202, 203, 204, 205, 205, 207, 0, 208, 208, 0, 0, 209, 210, 211, 211, 213, 215, 215, 216, 217, 217, 217, 217, 0, 0, 0, 218, 220, 221, 221, 221, 224, 224, 225, 226, 227, 227, 227, 227, 227, 227, 227, 0, 0, 0, 228, 229, 232, 233, 233, 233, 233, 0, 0, 0, 234, 236, 236, 237, 238, 238, 238, 241, 242, 242, 0, 242, 0, 0, 243, 243, 244, 246, 246, 247, 248, 249, 250, 251, 251, 252, 252, 253, 254, 255, 256, 257, 257, 259, 259, 260, 261, 263, 263, 263, 0, 0, 0, 263, 263, 0, 0, 0, 263, 263, 0, 0, 0, 264, 265, 267, 267, 268, 270, 271, 272, 272, 274, 275, 275, 276, 278, 278, 279, 281, 283, 283, 0, 0, 0, 284, 285, 285, 286, 288, 290, 295, 296, 296, 0, 296, 0, 0, 297, 297, 298, 300, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 301, 302, 304, 305, 305, 306, 306, 307, 308, 309, 309, 310, 311, 311, 312, 314, 314, 315, 319, 320, 320, 0, 320, 0, 0, 0, 320, 320, 0, 0, 322, 322, 323, 325, 326, 326, 326, 326, 326, 328, 329, 330, 330, 331, 332, 334, 335, 335, 335, 335, 335, 337, 338, 338, 339, 342, 342, 0, 342, 342, 342, 0, 0, 0, 0, 0, 343, 344, 344, 344, 344, 0, 344, 0, 0, 0, 0, 0, 344, 345, 345, 345, 345, 0, 0, 0, 345, 348, 348, 348, 349, 349, 349, 349, 349, 349, 352, 356, 356, 356, 356, 357, 357, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 46, 47, 51, 55, 68, 69, 70, 71, 72, 75, 80, 81, 82, 84, 87, 91, 94, 100, 105, 106, 107, 109, 112, 116, 119, 276, 281, 282, 284, 285, 286, 287, 289, 290, 293, 295, 296, 301, 303, 306, 310, 315, 316, 318, 319, 325, 326, 327, 328, 329, 332, 337, 338, 339, 341, 342, 343, 344, 345, 346, 349, 350, 353, 357, 360, 361, 363, 366, 370, 371, 373, 378, 379, 385, 386, 387, 390, 395, 396, 397, 399, 402, 406, 409, 415, 416, 417, 418, 423, 424, 426, 427, 428, 429, 431, 432, 433, 434, 439, 440, 443, 447, 450, 451, 458, 461, 466, 467, 468, 470, 473, 477, 480, 486, 487, 488, 489, 490, 491, 494, 497, 498, 500, 503, 505, 508, 512, 514, 516, 522, 523, 525, 526, 527, 528, 529, 530, 533, 534, 536, 537, 538, 539, 540, 541, 544, 545, 547, 548, 552, 553, 555, 557, 560, 564, 567, 568, 570, 573, 577, 580, 581, 583, 586, 590, 593, 594, 600, 602, 604, 606, 607, 608, 609, 612, 613, 614, 615, 617, 618, 620, 622, 626, 627, 630, 633, 637, 640, 641, 642, 643, 647, 650, 658, 661, 662, 664, 667, 669, 672, 676, 678, 680, 688, 689, 691, 693, 696, 700, 703, 704, 706, 709, 713, 716, 717, 719, 722, 726, 729, 730, 732, 735, 739, 742, 743, 749, 750, 752, 754, 755, 757, 758, 761, 762, 764, 765, 766, 767, 770, 771, 772, 777, 780, 781, 783, 786, 788, 791, 795, 798, 799, 801, 804, 808, 810, 812, 818, 820, 821, 822, 823, 824, 826, 829, 831, 833, 835, 836, 842, 844, 845, 846, 847, 848, 850, 851, 852, 853, 860, 865, 866, 869, 874, 875, 877, 880, 884, 887, 890, 894, 897, 902, 903, 904, 906, 909, 911, 914, 918, 921, 925, 928, 934, 939, 940, 941, 943, 946, 950, 953, 958, 963, 964, 966, 967, 968, 969, 970, 971, 975, 981, 986, 987, 988, 990, 991, 994, 997, 1001, 1004, 1008, 1011, 1015, 1018, 1022, 1025, 1029, 1032, 1036, 1039, 1043, 1046, 1050, 1053};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 137 35
new 0 137 35
assign 1 138 36
new 0 138 36
assign 1 139 37
assign 1 140 38
assign 1 141 39
new 0 141 39
assign 1 142 40
new 0 142 40
assign 1 143 41
new 0 143 41
assign 1 144 42
new 0 144 42
new 0 149 46
assign 1 150 47
new 0 154 51
return 1 158 55
assign 1 162 68
tokGet 0 162 68
assign 1 162 69
tokenize 1 162 69
assign 1 163 70
iteratorGet 0 163 70
assign 1 164 71
new 0 164 71
assign 1 166 72
nextGet 0 166 72
assign 1 167 75
def 1 167 80
assign 1 167 81
new 0 167 81
assign 1 167 82
notEquals 1 167 82
assign 1 0 84
assign 1 0 87
assign 1 0 91
assign 1 168 94
nextGet 0 168 94
assign 1 170 100
def 1 170 105
assign 1 170 106
new 0 170 106
assign 1 170 107
equals 1 170 107
assign 1 0 109
assign 1 0 112
assign 1 0 116
assign 1 171 119
new 0 171 119
assign 1 176 276
not 0 176 281
start 0 177 282
assign 1 180 284
new 0 180 284
assign 1 180 285
quoteGet 0 180 285
assign 1 181 286
new 0 181 286
assign 1 181 287
newlineGet 0 181 287
assign 1 183 289
currentGet 0 183 289
assign 1 184 290
new 0 184 290
assign 1 186 293
nextGet 0 186 293
assign 1 188 295
new 0 188 295
assign 1 189 296
def 1 189 301
assign 1 0 303
assign 1 0 306
assign 1 0 310
assign 1 190 315
new 0 190 315
assign 1 190 316
notEquals 1 190 316
addValue 1 191 318
assign 1 192 319
nextGet 0 192 319
assign 1 194 325
new 0 194 325
assign 1 195 326
new 0 195 326
assign 1 196 327
extractString 0 196 327
assign 1 196 328
new 1 196 328
return 1 196 329
assign 1 197 332
def 1 197 337
assign 1 198 338
new 0 198 338
assign 1 198 339
equals 1 198 339
assign 1 199 341
new 0 199 341
assign 1 200 342
new 0 200 342
assign 1 201 343
new 0 201 343
assign 1 202 344
new 0 202 344
assign 1 203 345
new 0 203 345
assign 1 204 346
new 0 204 346
assign 1 205 349
new 0 205 349
assign 1 205 350
notEquals 1 205 350
assign 1 207 353
new 0 207 353
assign 1 0 357
assign 1 208 360
new 0 208 360
assign 1 208 361
notEquals 1 208 361
assign 1 0 363
assign 1 0 366
addValue 1 209 370
assign 1 210 371
equals 1 210 371
assign 1 211 373
not 0 211 378
assign 1 213 379
nextGet 0 213 379
assign 1 215 385
new 0 215 385
addValue 1 215 386
assign 1 216 387
new 0 216 387
assign 1 217 390
def 1 217 395
assign 1 217 396
new 0 217 396
assign 1 217 397
notEquals 1 217 397
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 218 409
nextGet 0 218 409
assign 1 220 415
new 0 220 415
assign 1 221 416
toString 0 221 416
assign 1 221 417
new 1 221 417
return 1 221 418
assign 1 224 423
new 0 224 423
assign 1 224 424
notEquals 1 224 424
addValue 1 225 426
assign 1 226 427
nextGet 0 226 427
assign 1 227 428
new 0 227 428
assign 1 227 429
equals 1 227 429
assign 1 227 431
toString 0 227 431
assign 1 227 432
new 0 227 432
assign 1 227 433
ends 1 227 433
assign 1 227 434
not 0 227 439
assign 1 0 440
assign 1 0 443
assign 1 0 447
addValue 1 228 450
assign 1 229 451
nextGet 0 229 451
assign 1 232 458
new 0 232 458
assign 1 233 461
def 1 233 466
assign 1 233 467
new 0 233 467
assign 1 233 468
notEquals 1 233 468
assign 1 0 470
assign 1 0 473
assign 1 0 477
assign 1 234 480
nextGet 0 234 480
assign 1 236 486
new 0 236 486
addValue 1 236 487
assign 1 237 488
new 0 237 488
assign 1 238 489
extractString 0 238 489
assign 1 238 490
new 1 238 490
return 1 238 491
assign 1 241 494
nextGet 0 241 494
assign 1 242 497
new 0 242 497
assign 1 242 498
equals 1 242 498
assign 1 0 500
assign 1 242 503
equals 1 242 503
assign 1 0 505
assign 1 0 508
assign 1 243 512
equals 1 243 512
assign 1 243 514
increment 0 243 514
assign 1 244 516
nextGet 0 244 516
assign 1 246 522
new 0 246 522
assign 1 246 523
equals 1 246 523
assign 1 247 525
new 0 247 525
assign 1 248 526
new 0 248 526
assign 1 249 527
nextGet 0 249 527
extractString 0 250 528
assign 1 251 529
new 0 251 529
addValue 1 251 530
assign 1 252 533
new 0 252 533
assign 1 252 534
equals 1 252 534
assign 1 253 536
new 0 253 536
assign 1 254 537
new 0 254 537
assign 1 255 538
nextGet 0 255 538
extractString 0 256 539
assign 1 257 540
new 0 257 540
addValue 1 257 541
assign 1 259 544
new 0 259 544
assign 1 259 545
equals 1 259 545
assign 1 260 547
new 0 260 547
assign 1 261 548
nextGet 0 261 548
assign 1 263 552
new 0 263 552
assign 1 263 553
notEquals 1 263 553
assign 1 263 555
notEquals 1 263 555
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 263 567
new 0 263 567
assign 1 263 568
notEquals 1 263 568
assign 1 0 570
assign 1 0 573
assign 1 0 577
assign 1 263 580
new 0 263 580
assign 1 263 581
notEquals 1 263 581
assign 1 0 583
assign 1 0 586
assign 1 0 590
addValue 1 264 593
assign 1 265 594
nextGet 0 265 594
assign 1 267 600
equals 1 267 600
assign 1 267 602
increment 0 267 602
assign 1 268 604
new 0 268 604
assign 1 270 606
new 0 270 606
assign 1 271 607
assign 1 272 608
extractString 0 272 608
nameSet 1 272 609
assign 1 274 612
new 0 274 612
assign 1 275 613
extractString 0 275 613
nameSet 1 275 614
assign 1 276 615
assign 1 278 617
new 0 278 617
assign 1 278 618
equals 1 278 618
assign 1 279 620
new 0 279 620
assign 1 281 622
new 0 281 622
assign 1 283 626
new 0 283 626
assign 1 283 627
equals 1 283 627
assign 1 0 630
assign 1 0 633
assign 1 0 637
assign 1 284 640
new 0 284 640
assign 1 285 641
new 0 285 641
isClosedSet 1 285 642
assign 1 286 643
nextGet 0 286 643
assign 1 288 647
new 0 288 647
assign 1 290 650
new 0 290 650
assign 1 295 658
nextGet 0 295 658
assign 1 296 661
new 0 296 661
assign 1 296 662
equals 1 296 662
assign 1 0 664
assign 1 296 667
equals 1 296 667
assign 1 0 669
assign 1 0 672
assign 1 297 676
equals 1 297 676
assign 1 297 678
increment 0 297 678
assign 1 298 680
nextGet 0 298 680
assign 1 300 688
new 0 300 688
assign 1 300 689
notEquals 1 300 689
assign 1 300 691
notEquals 1 300 691
assign 1 0 693
assign 1 0 696
assign 1 0 700
assign 1 300 703
new 0 300 703
assign 1 300 704
notEquals 1 300 704
assign 1 0 706
assign 1 0 709
assign 1 0 713
assign 1 300 716
new 0 300 716
assign 1 300 717
notEquals 1 300 717
assign 1 0 719
assign 1 0 722
assign 1 0 726
assign 1 300 729
new 0 300 729
assign 1 300 730
notEquals 1 300 730
assign 1 0 732
assign 1 0 735
assign 1 0 739
addValue 1 301 742
assign 1 302 743
nextGet 0 302 743
assign 1 304 749
new 0 304 749
assign 1 305 750
equals 1 305 750
assign 1 305 752
increment 0 305 752
assign 1 306 754
new 0 306 754
assign 1 306 755
equals 1 306 755
assign 1 307 757
new 0 307 757
assign 1 308 758
new 0 308 758
assign 1 309 761
new 0 309 761
assign 1 309 762
equals 1 309 762
assign 1 310 764
new 0 310 764
assign 1 311 765
new 0 311 765
isClosedSet 1 311 766
assign 1 312 767
nextGet 0 312 767
assign 1 314 770
extractString 0 314 770
addAttributeName 1 314 771
assign 1 315 772
new 0 315 772
assign 1 319 777
nextGet 0 319 777
assign 1 320 780
new 0 320 780
assign 1 320 781
equals 1 320 781
assign 1 0 783
assign 1 320 786
equals 1 320 786
assign 1 0 788
assign 1 0 791
assign 1 0 795
assign 1 320 798
new 0 320 798
assign 1 320 799
equals 1 320 799
assign 1 0 801
assign 1 0 804
assign 1 322 808
equals 1 322 808
assign 1 322 810
increment 0 322 810
assign 1 323 812
nextGet 0 323 812
assign 1 325 818
notEquals 1 325 818
assign 1 326 820
new 0 326 820
assign 1 326 821
toString 0 326 821
assign 1 326 822
add 1 326 822
assign 1 326 823
new 1 326 823
throw 1 326 824
assign 1 328 826
nextGet 0 328 826
assign 1 329 829
notEquals 1 329 829
assign 1 330 831
equals 1 330 831
assign 1 330 833
increment 0 330 833
addValue 1 331 835
assign 1 332 836
nextGet 0 332 836
assign 1 334 842
notEquals 1 334 842
assign 1 335 844
new 0 335 844
assign 1 335 845
toString 0 335 845
assign 1 335 846
add 1 335 846
assign 1 335 847
new 1 335 847
throw 1 335 848
assign 1 337 850
new 0 337 850
assign 1 338 851
extractString 0 338 851
addAttributeValue 1 338 852
assign 1 339 853
new 0 339 853
assign 1 342 860
def 1 342 865
assign 1 0 866
assign 1 342 869
def 1 342 874
assign 1 342 875
isClosedGet 0 342 875
assign 1 0 877
assign 1 0 880
assign 1 0 884
assign 1 0 887
assign 1 0 890
assign 1 343 894
nextGet 0 343 894
assign 1 344 897
def 1 344 902
assign 1 344 903
new 0 344 903
assign 1 344 904
equals 1 344 904
assign 1 0 906
assign 1 344 909
equals 1 344 909
assign 1 0 911
assign 1 0 914
assign 1 0 918
assign 1 0 921
assign 1 0 925
assign 1 344 928
nextGet 0 344 928
assign 1 345 934
def 1 345 939
assign 1 345 940
new 0 345 940
assign 1 345 941
equals 1 345 941
assign 1 0 943
assign 1 0 946
assign 1 0 950
assign 1 345 953
new 0 345 953
assign 1 348 958
undef 1 348 963
assign 1 348 964
new 0 348 964
assign 1 349 966
new 0 349 966
assign 1 349 967
add 1 349 967
assign 1 349 968
new 0 349 968
assign 1 349 969
add 1 349 969
assign 1 349 970
new 1 349 970
throw 1 349 971
return 1 352 975
assign 1 356 981
not 0 356 986
assign 1 356 987
new 0 356 987
return 1 356 988
assign 1 357 990
hasNextGet 0 357 990
return 1 357 991
return 1 0 994
assign 1 0 997
return 1 0 1001
assign 1 0 1004
return 1 0 1008
assign 1 0 1011
return 1 0 1015
assign 1 0 1018
return 1 0 1022
assign 1 0 1025
return 1 0 1029
assign 1 0 1032
return 1 0 1036
assign 1 0 1039
return 1 0 1043
assign 1 0 1046
return 1 0 1050
assign 1 0 1053
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1215120664: return bem_textNodeGet_0();
case 716353022: return bem_copy_0();
case -268682254: return bem_skipGet_0();
case -615880915: return bem_hashGet_0();
case -1324622709: return bem_create_0();
case -1319517478: return bem_new_0();
case -219382951: return bem_iteratorGet_0();
case -486715824: return bem_xmlStringGet_0();
case -22208915: return bem_start_0();
case -1895970342: return bem_lineGet_0();
case -1937663110: return bem_iterGet_0();
case -1004422488: return bem_restart_0();
case 1676579031: return bem_xtGet_0();
case 1701589603: return bem_startedGet_0();
case 1787222330: return bem_toString_0();
case 1651626288: return bem_resGet_0();
case -369118516: return bem_print_0();
case -1182092368: return bem_hasNextGet_0();
case 233311811: return bem_nextGet_0();
case 1417471898: return bem_debugGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1501511462: return bem_skipSet_1(bevd_0);
case 1319692800: return bem_xmlStringSet_1(bevd_0);
case -956176892: return bem_debugSet_1(bevd_0);
case -1257706142: return bem_resSet_1(bevd_0);
case 1780191728: return bem_lineSet_1(bevd_0);
case 1603919423: return bem_equals_1(bevd_0);
case 175411203: return bem_startedSet_1(bevd_0);
case 17775460: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case -508758794: return bem_undef_1(bevd_0);
case 230387739: return bem_xtSet_1(bevd_0);
case -877452200: return bem_textNodeSet_1(bevd_0);
case 1073835775: return bem_copyTo_1(bevd_0);
case 1537717697: return bem_iterSet_1(bevd_0);
case -1254710410: return bem_notEquals_1(bevd_0);
case 1657786616: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1956825510: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1361437844: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 238044200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 900181049: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_11_XmlTagIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_type;
}
}
