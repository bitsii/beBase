package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_16_SystemGarbageCollector extends BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemGarbageCollector() { }
private static byte[] becc_BEC_2_6_16_SystemGarbageCollector_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x47,0x61,0x72,0x62,0x61,0x67,0x65,0x43,0x6F,0x6C,0x6C,0x65,0x63,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_16_SystemGarbageCollector_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_16_SystemGarbageCollector bece_BEC_2_6_16_SystemGarbageCollector_bevs_inst;

public static BET_2_6_16_SystemGarbageCollector bece_BEC_2_6_16_SystemGarbageCollector_bevs_type;

public BEC_2_6_16_SystemGarbageCollector bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemGarbageCollector bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemGarbageCollector bem_doFullCollection_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1894090923: return bem_toString_0();
case -808123537: return bem_hashGet_0();
case 1662840893: return bem_doFullCollection_0();
case -1706743432: return bem_iteratorGet_0();
case -1602615308: return bem_fieldIteratorGet_0();
case 1606613844: return bem_echo_0();
case 1377047095: return bem_serializeToString_0();
case -1442653865: return bem_serializationIteratorGet_0();
case -295553573: return bem_new_0();
case -1460543860: return bem_fieldNamesGet_0();
case -493975186: return bem_create_0();
case -41381797: return bem_copy_0();
case -802767414: return bem_deserializeClassNameGet_0();
case -1396413274: return bem_classNameGet_0();
case 899896295: return bem_print_0();
case -2071452709: return bem_serializeContents_0();
case 85669346: return bem_once_0();
case 874569701: return bem_toAny_0();
case -1794506213: return bem_many_0();
case -1333837278: return bem_tagGet_0();
case 1222474283: return bem_default_0();
case 1523861211: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 652115224: return bem_def_1(bevd_0);
case 1213137777: return bem_undef_1(bevd_0);
case -467808258: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 284248916: return bem_defined_1(bevd_0);
case 391192402: return bem_copyTo_1(bevd_0);
case 251588443: return bem_otherType_1(bevd_0);
case 1328285078: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -194482552: return bem_sameType_1(bevd_0);
case -1989300932: return bem_sameClass_1(bevd_0);
case -2123613587: return bem_notEquals_1(bevd_0);
case -794252146: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -319164445: return bem_undefined_1(bevd_0);
case -920243169: return bem_sameObject_1(bevd_0);
case 966131902: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 53407038: return bem_equals_1(bevd_0);
case 1829433968: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1874085610: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1865862746: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736065910: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1057911785: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1158884482: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126000923: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1221539498: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemGarbageCollector_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_16_SystemGarbageCollector_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemGarbageCollector();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemGarbageCollector.bece_BEC_2_6_16_SystemGarbageCollector_bevs_inst = (BEC_2_6_16_SystemGarbageCollector) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemGarbageCollector.bece_BEC_2_6_16_SystemGarbageCollector_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemGarbageCollector.bece_BEC_2_6_16_SystemGarbageCollector_bevs_type;
}
}
