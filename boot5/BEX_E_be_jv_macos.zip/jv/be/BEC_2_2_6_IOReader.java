package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOReader extends BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOReader() { }

    public java.io.InputStream bevi_is;
   private static byte[] becc_BEC_2_2_6_IOReader_clname = {0x49,0x4F,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_2 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_3 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_8 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_2_6_IOReader bece_BEC_2_2_6_IOReader_bevs_inst;

public static BET_2_2_6_IOReader bece_BEC_2_2_6_IOReader_bevs_type;

public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_3_MathInt bevp_blockSize;
public BEC_2_2_6_IOReader bem_new_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
bevp_blockSize = (new BEC_2_4_3_MathInt(256));
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_extOpen_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_close_0() throws Throwable {

      if (this.bevi_is != null) {
        this.bevi_is.close();
        this.bevi_is = null;
      }
      bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_vfileGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) throws Throwable {
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_byteReaderGet_0() throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_2_10_IOByteReader()).bem_readerNew_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_byteReader_1(BEC_2_4_3_MathInt beva_blockSize) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_2_10_IOByteReader()).bem_readerBlockNew_2(this, beva_blockSize);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_1(BEC_2_4_6_TextString beva_readBuf) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_0;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_readIntoBuffer_2(beva_readBuf, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_2(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_readIntoBuffer_3(beva_readBuf, beva_at, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_3(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at, BEC_2_4_3_MathInt beva_readsz) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;

      int bevls_read = this.bevi_is.read(beva_readBuf.bevi_bytes, beva_at.bevi_int, beva_readBuf.bevi_bytes.length - beva_at.bevi_int);
      if (bevls_read < 0) {
        bevls_read = 0;
      }
      beva_readsz.bevi_int = bevls_read + beva_at.bevi_int;
      bevt_0_tmpany_phold = beva_readBuf.bem_sizeGet_0();
bevt_0_tmpany_phold.bevi_int = beva_readsz.bevi_int;
return beva_readsz;
} /*method end*/
public BEC_2_2_6_IOReader bem_copyData_3(BEC_2_2_6_IOWriter beva_outw, BEC_2_4_6_TextString beva_rwbufE, BEC_2_4_3_MathInt beva_rsz) throws Throwable {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_at = bece_BEC_2_2_6_IOReader_bevo_1;
while (true)
 /* Line: 293 */ {
bevt_1_tmpany_phold = bem_readIntoBuffer_3(beva_rwbufE, bevl_at, beva_rsz);
bevt_2_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_2;
if (bevt_1_tmpany_phold.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 293 */ {
beva_outw.bem_write_1(beva_rwbufE);
} /* Line: 294 */
 else  /* Line: 293 */ {
break;
} /* Line: 293 */
} /* Line: 293 */
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_copyData_1(BEC_2_2_6_IOWriter beva_outw) throws Throwable {
BEC_2_4_6_TextString bevl_rwbufE = null;
BEC_2_4_3_MathInt bevl_rsz = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(4096));
bevl_rwbufE = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_rsz = (new BEC_2_4_3_MathInt());
bem_copyData_3(beva_outw, bevl_rwbufE, bevl_rsz);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevp_blockSize);
bevt_0_tmpany_phold = bem_readBuffer_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_4_3_MathInt bevl_nowAt = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevl_at = (new BEC_2_4_3_MathInt(0));
bevl_nowAt = (new BEC_2_4_3_MathInt());
bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
while (true)
 /* Line: 312 */ {
if (bevl_nowAt.bevi_int > bevl_at.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevl_at.bevi_int = bevl_nowAt.bevi_int;
bevt_3_tmpany_phold = beva_builder.bem_capacityGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_subtract_1(bevl_at);
bevt_4_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_3;
if (bevt_2_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_7_tmpany_phold = bevl_at.bem_add_1(bevp_blockSize);
bevt_8_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_4;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_5;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_multiply_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_6;
bevl_nsize = bevt_5_tmpany_phold.bem_divide_1(bevt_10_tmpany_phold);
beva_builder.bem_capacitySet_1(bevl_nsize);
} /* Line: 316 */
bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
} /* Line: 318 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
return beva_builder;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferLine_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = bem_readBufferLine_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferLine_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_6_TextString bevl_crb = null;
BEC_2_4_6_TextString bevl_rbuf = null;
BEC_2_4_3_MathInt bevl_got = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_newlineGet_0();
bevl_crb = bevt_0_tmpany_phold.bem_addValue_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_rbuf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_3_tmpany_phold);
bevl_got = bem_readIntoBuffer_1(bevl_rbuf);
bevt_5_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_7;
if (bevl_got.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 334 */ {
beva_builder = null;
return beva_builder;
} /* Line: 336 */
beva_builder.bem_addValue_1(bevl_rbuf);
while (true)
 /* Line: 339 */ {
bevt_7_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_8;
if (bevl_got.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 339 */ {
bevt_8_tmpany_phold = bevl_rbuf.bem_equals_1(bevl_crb);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 340 */ {
return beva_builder;
} /* Line: 341 */
bevl_got = bem_readIntoBuffer_1(bevl_rbuf);
beva_builder.bem_addValue_1(bevl_rbuf);
} /* Line: 344 */
 else  /* Line: 339 */ {
break;
} /* Line: 339 */
} /* Line: 339 */
return beva_builder;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_readBuffer_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_readBuffer_1(beva_builder);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readStringClose_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = bem_readString_0();
bem_close_0();
return bevl_res;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_vfileGetDirect_0() throws Throwable {
return bevp_vfile;
} /*method end*/
public final BEC_2_2_6_IOReader bem_vfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vfile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isClosedGetDirect_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_2_6_IOReader bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_6_IOReader bem_isClosedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_blockSizeGet_0() throws Throwable {
return bevp_blockSize;
} /*method end*/
public final BEC_2_4_3_MathInt bem_blockSizeGetDirect_0() throws Throwable {
return bevp_blockSize;
} /*method end*/
public BEC_2_2_6_IOReader bem_blockSizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_blockSize = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_6_IOReader bem_blockSizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_blockSize = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {174, 175, 181, 225, 233, 233, 237, 237, 241, 241, 241, 241, 245, 245, 245, 287, 287, 288, 292, 293, 293, 293, 293, 294, 299, 299, 300, 301, 305, 305, 305, 309, 310, 311, 312, 312, 313, 314, 314, 314, 314, 314, 315, 315, 315, 315, 315, 315, 315, 316, 318, 320, 324, 324, 324, 331, 331, 331, 331, 332, 332, 333, 334, 334, 334, 335, 336, 338, 339, 339, 339, 340, 341, 343, 344, 346, 350, 350, 354, 354, 358, 359, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 31, 40, 51, 52, 56, 57, 63, 64, 65, 66, 71, 72, 73, 83, 84, 85, 92, 95, 96, 97, 102, 103, 115, 116, 117, 118, 124, 125, 126, 143, 144, 145, 148, 153, 154, 155, 156, 157, 158, 163, 164, 165, 166, 167, 168, 169, 170, 171, 173, 179, 184, 185, 186, 201, 202, 203, 204, 205, 206, 207, 208, 209, 214, 215, 216, 218, 221, 222, 227, 228, 230, 232, 233, 239, 243, 244, 248, 249, 253, 254, 255, 258, 261, 265, 268, 271, 275, 279, 282, 285, 289};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 174 26
new 0 174 26
assign 1 175 27
new 0 175 27
assign 1 181 31
new 0 181 31
assign 1 225 40
new 0 225 40
assign 1 233 51
readerNew 1 233 51
return 1 233 52
assign 1 237 56
readerBlockNew 2 237 56
return 1 237 57
assign 1 241 63
new 0 241 63
assign 1 241 64
once 0 241 64
assign 1 241 65
readIntoBuffer 2 241 65
return 1 241 66
assign 1 245 71
new 0 245 71
assign 1 245 72
readIntoBuffer 3 245 72
return 1 245 73
assign 1 287 83
sizeGet 0 287 83
setValue 1 287 84
return 1 288 85
assign 1 292 92
new 0 292 92
assign 1 293 95
readIntoBuffer 3 293 95
assign 1 293 96
new 0 293 96
assign 1 293 97
greater 1 293 102
write 1 294 103
assign 1 299 115
new 0 299 115
assign 1 299 116
new 1 299 116
assign 1 300 117
new 0 300 117
copyData 3 301 118
assign 1 305 124
new 1 305 124
assign 1 305 125
readBuffer 1 305 125
return 1 305 126
assign 1 309 143
new 0 309 143
assign 1 310 144
new 0 310 144
readIntoBuffer 3 311 145
assign 1 312 148
greater 1 312 153
setValue 1 313 154
assign 1 314 155
capacityGet 0 314 155
assign 1 314 156
subtract 1 314 156
assign 1 314 157
new 0 314 157
assign 1 314 158
lesser 1 314 163
assign 1 315 164
add 1 315 164
assign 1 315 165
new 0 315 165
assign 1 315 166
add 1 315 166
assign 1 315 167
new 0 315 167
assign 1 315 168
multiply 1 315 168
assign 1 315 169
new 0 315 169
assign 1 315 170
divide 1 315 170
capacitySet 1 316 171
readIntoBuffer 3 318 173
return 1 320 179
assign 1 324 184
new 0 324 184
assign 1 324 185
readBufferLine 1 324 185
return 1 324 186
assign 1 331 201
new 0 331 201
assign 1 331 202
new 0 331 202
assign 1 331 203
newlineGet 0 331 203
assign 1 331 204
addValue 1 331 204
assign 1 332 205
new 0 332 205
assign 1 332 206
new 1 332 206
assign 1 333 207
readIntoBuffer 1 333 207
assign 1 334 208
new 0 334 208
assign 1 334 209
equals 1 334 214
assign 1 335 215
return 1 336 216
addValue 1 338 218
assign 1 339 221
new 0 339 221
assign 1 339 222
notEquals 1 339 227
assign 1 340 228
equals 1 340 228
return 1 341 230
assign 1 343 232
readIntoBuffer 1 343 232
addValue 1 344 233
return 1 346 239
assign 1 350 243
readBuffer 0 350 243
return 1 350 244
assign 1 354 248
readBuffer 1 354 248
return 1 354 249
assign 1 358 253
readString 0 358 253
close 0 359 254
return 1 360 255
return 1 0 258
assign 1 0 261
return 1 0 265
return 1 0 268
assign 1 0 271
assign 1 0 275
return 1 0 279
return 1 0 282
assign 1 0 285
assign 1 0 289
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 373871049: return bem_copy_0();
case -305967303: return bem_vfileGetDirect_0();
case 368405588: return bem_echo_0();
case -1004167434: return bem_blockSizeGet_0();
case 37115722: return bem_toAny_0();
case 844903630: return bem_close_0();
case 884758076: return bem_toString_0();
case -854469300: return bem_isClosedGet_0();
case -512173810: return bem_tagGet_0();
case 149300560: return bem_sourceFileNameGet_0();
case 144782273: return bem_once_0();
case 1712919396: return bem_serializationIteratorGet_0();
case 1467431111: return bem_byteReaderGet_0();
case -2047240643: return bem_readBuffer_0();
case 760337273: return bem_readString_0();
case -451287241: return bem_iteratorGet_0();
case 938978826: return bem_serializeContents_0();
case 166156356: return bem_hashGet_0();
case -83044426: return bem_readStringClose_0();
case 657440259: return bem_many_0();
case 1260713952: return bem_fieldNamesGet_0();
case -131396274: return bem_classNameGet_0();
case -1497736169: return bem_new_0();
case 1010970574: return bem_deserializeClassNameGet_0();
case 1012944178: return bem_create_0();
case -978449978: return bem_readBufferLine_0();
case 1549520308: return bem_vfileGet_0();
case -1127197743: return bem_extOpen_0();
case 652618710: return bem_print_0();
case 1928478085: return bem_blockSizeGetDirect_0();
case -1704173235: return bem_isClosedGetDirect_0();
case -1360047774: return bem_serializeToString_0();
case -794542805: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1107469839: return bem_isClosedSetDirect_1(bevd_0);
case 1530011542: return bem_isClosedSet_1(bevd_0);
case 394684708: return bem_vfileSet_1(bevd_0);
case -1849842647: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1450913634: return bem_defined_1(bevd_0);
case -2033993347: return bem_sameObject_1(bevd_0);
case 46811792: return bem_otherType_1(bevd_0);
case 1254932261: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 2044588239: return bem_otherClass_1(bevd_0);
case 773892154: return bem_sameClass_1(bevd_0);
case 1690521969: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 974930963: return bem_undefined_1(bevd_0);
case -449083652: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -926157429: return bem_equals_1(bevd_0);
case -1418198617: return bem_def_1(bevd_0);
case 316246650: return bem_vfileSetDirect_1(bevd_0);
case -1434589659: return bem_undef_1(bevd_0);
case 624001423: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1184632884: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1691038775: return bem_notEquals_1(bevd_0);
case -1340973491: return bem_sameType_1(bevd_0);
case -1504473874: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1567580437: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -87024745: return bem_blockSizeSet_1(bevd_0);
case -1952204646: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -442448216: return bem_copyTo_1(bevd_0);
case -6554289: return bem_blockSizeSetDirect_1(bevd_0);
case -675060011: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -330880231: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 60554289: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1368517810: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1351268593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1842958248: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 840782676: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 498622947: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1807714621: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1569070709: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1508041049: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_6_IOReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst = (BEC_2_2_6_IOReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_type;
}
}
