package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_5_IOFileReaderStdin extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_5_IOFileReaderStdin() { }
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x53,0x74,0x64,0x69,0x6E};
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;

public static BET_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;

public BEC_4_2_4_6_5_IOFileReaderStdin bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
bevp_blockSize = (new BEC_2_4_3_MathInt(1024));
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {743, 744, 749, 749};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 24, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 743 15
new 0 743 15
assign 1 744 16
new 0 744 16
assign 1 749 24
new 0 749 24
return 1 749 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1464527658: return bem_toString_0();
case 873828646: return bem_deserializeClassNameGet_0();
case 1172162434: return bem_readString_0();
case 1287563682: return bem_readDiscardClose_0();
case -2131640624: return bem_new_0();
case 2113534779: return bem_hashGet_0();
case -1104424295: return bem_close_0();
case 1673114189: return bem_blockSizeGet_0();
case -815193000: return bem_readDiscard_0();
case 1864861581: return bem_echo_0();
case -692450678: return bem_readStringClose_0();
case 1645989341: return bem_iteratorGet_0();
case 1393634620: return bem_serializeToString_0();
case 2106413196: return bem_blockSizeGetDirect_0();
case 1005443364: return bem_create_0();
case 239077256: return bem_print_0();
case 785161348: return bem_fieldNamesGet_0();
case -157777737: return bem_fieldIteratorGet_0();
case 350812655: return bem_copy_0();
case -1373120674: return bem_readBuffer_0();
case 1587133120: return bem_classNameGet_0();
case 1657688926: return bem_byteReaderGet_0();
case 2071875109: return bem_sourceFileNameGet_0();
case -1683759101: return bem_isClosedGetDirect_0();
case -1270780814: return bem_default_0();
case 432084728: return bem_open_0();
case -847465997: return bem_readBufferLine_0();
case 969994032: return bem_serializationIteratorGet_0();
case -378196579: return bem_pathGet_0();
case -281350604: return bem_serializeContents_0();
case -427471529: return bem_isClosedGet_0();
case 1657739777: return bem_extOpen_0();
case 1154816532: return bem_vfileGetDirect_0();
case 1209056714: return bem_pathGetDirect_0();
case -632441470: return bem_vfileGet_0();
case 566573794: return bem_tagGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -120784781: return bem_blockSizeSet_1(bevd_0);
case 1455101233: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -396283576: return bem_undef_1(bevd_0);
case 329088830: return bem_blockSizeSetDirect_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2096702167: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case -1021771752: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1151211311: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1713105998: return bem_isClosedSet_1(bevd_0);
case -1513541756: return bem_vfileSet_1(bevd_0);
case -1353668075: return bem_new_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1619730330: return bem_pathSetDirect_1(bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case -1871333137: return bem_pathSet_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
case 496029839: return bem_isClosedSetDirect_1(bevd_0);
case 477287968: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1147873117: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 690834381: return bem_vfileSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -544305739: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1860744000: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1660217048: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_5_IOFileReaderStdin();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst = (BEC_4_2_4_6_5_IOFileReaderStdin) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;
}
}
