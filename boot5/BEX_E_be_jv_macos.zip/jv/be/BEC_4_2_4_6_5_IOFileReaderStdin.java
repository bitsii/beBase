package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_5_IOFileReaderStdin extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_5_IOFileReaderStdin() { }
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x53,0x74,0x64,0x69,0x6E};
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;

public static BET_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;

public BEC_4_2_4_6_5_IOFileReaderStdin bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
bevp_blockSize = (new BEC_2_4_3_MathInt(1024));
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {749, 750, 755, 755};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 24, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 749 15
new 0 749 15
assign 1 750 16
new 0 750 16
assign 1 755 24
new 0 755 24
return 1 755 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1206052235: return bem_close_0();
case 1173320489: return bem_readBuffer_0();
case -1477018360: return bem_toString_0();
case 933573882: return bem_pathGet_0();
case -97418144: return bem_blockSizeGet_0();
case 474638961: return bem_byteReaderGet_0();
case 1886504563: return bem_readString_0();
case -308237316: return bem_readStringClose_0();
case 536481412: return bem_extOpen_0();
case 631790715: return bem_open_0();
case 292099292: return bem_readDiscardClose_0();
case 206542139: return bem_isClosedGet_0();
case -1141241291: return bem_copy_0();
case -166658492: return bem_default_0();
case 203394578: return bem_readBufferLine_0();
case 1379821961: return bem_create_0();
case 310309721: return bem_hashGet_0();
case 1030336271: return bem_new_0();
case 1155069902: return bem_print_0();
case -378681344: return bem_vfileGet_0();
case -1528185450: return bem_readDiscard_0();
case -662844650: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1786091368: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 278034565: return bem_equals_1(bevd_0);
case -2095886044: return bem_vfileSet_1(bevd_0);
case 1075706066: return bem_undef_1(bevd_0);
case -1863437771: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1117209842: return bem_new_1(bevd_0);
case 1678289452: return bem_pathSet_1(bevd_0);
case -1891816095: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1210592980: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1738502576: return bem_copyTo_1(bevd_0);
case -1814742686: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -783594042: return bem_isClosedSet_1(bevd_0);
case -1264563233: return bem_notEquals_1(bevd_0);
case 741113805: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1176436455: return bem_print_1(bevd_0);
case 1801291774: return bem_def_1(bevd_0);
case -681959186: return bem_blockSizeSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1078570514: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 752466488: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -844523032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1584274286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -880661396: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 414767711: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1797397280: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_5_IOFileReaderStdin();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst = (BEC_4_2_4_6_5_IOFileReaderStdin) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;
}
}
