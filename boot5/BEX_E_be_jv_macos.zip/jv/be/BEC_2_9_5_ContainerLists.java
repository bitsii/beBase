package be;
/* IO:File: source/base/List.be */
public class BEC_2_9_5_ContainerLists extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerLists() { }
private static byte[] becc_BEC_2_9_5_ContainerLists_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x73};
private static byte[] becc_BEC_2_9_5_ContainerLists_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_5_ContainerLists_bels_0 = {0x48,0x61,0x6E,0x64,0x6C,0x65,0x72};
public static BEC_2_9_5_ContainerLists bece_BEC_2_9_5_ContainerLists_bevs_inst;

public static BET_2_9_5_ContainerLists bece_BEC_2_9_5_ContainerLists_bevs_type;

public BEC_2_9_5_ContainerLists bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_9_4_ContainerList bevl_varargs = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_9_5_ContainerLists_bels_0));
beva_name = beva_name.bem_add_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bem_can_2(beva_name, bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 613*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_varargs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_varargs.bem_put_2(bevt_4_ta_ph, beva_args);
bevl_result = bem_invoke_2(beva_name, bevl_varargs);
} /* Line: 616*/
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromHandler_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
return beva_list;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {612, 612, 613, 613, 614, 614, 615, 615, 616, 618, 622};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 34, 37};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 612 23
new 0 612 23
assign 1 612 24
add 1 612 24
assign 1 613 25
new 0 613 25
assign 1 613 26
can 2 613 26
assign 1 614 28
new 0 614 28
assign 1 614 29
new 1 614 29
assign 1 615 30
new 0 615 30
put 2 615 31
assign 1 616 32
invoke 2 616 32
return 1 618 34
return 1 622 37
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1500345660: return bem_new_0();
case 1914698093: return bem_copy_0();
case -2044808959: return bem_create_0();
case 701056781: return bem_print_0();
case 403207358: return bem_hashGet_0();
case 332374972: return bem_toString_0();
case -411352811: return bem_iteratorGet_0();
case 2090148572: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2093081199: return bem_equals_1(bevd_0);
case 1056390040: return bem_notEquals_1(bevd_0);
case -183213474: return bem_copyTo_1(bevd_0);
case -2091475700: return bem_def_1(bevd_0);
case 242448501: return bem_undef_1(bevd_0);
case 620456560: return bem_fromHandler_1((BEC_2_9_4_ContainerList) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1734287964: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1748111499: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1968238059: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1944821118: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerLists_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_5_ContainerLists_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerLists();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerLists.bece_BEC_2_9_5_ContainerLists_bevs_inst = (BEC_2_9_5_ContainerLists) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerLists.bece_BEC_2_9_5_ContainerLists_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ContainerLists.bece_BEC_2_9_5_ContainerLists_bevs_type;
}
}
