package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_17_ContainerSetIdentityRelations extends BEC_3_9_3_9_ContainerSetRelations {
public BEC_3_9_3_17_ContainerSetIdentityRelations() { }
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;

public static BET_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;

public BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_k.bemd_0(566573794);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_k.bemd_1(-1115528588, beva_l);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {78, 78, 82, 82};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 78 13
tagGet 0 78 13
return 1 78 14
assign 1 82 18
sameObject 1 82 18
return 1 82 19
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1005443364: return bem_create_0();
case 350812655: return bem_copy_0();
case -281350604: return bem_serializeContents_0();
case 2113534779: return bem_hashGet_0();
case 239077256: return bem_print_0();
case 2071875109: return bem_sourceFileNameGet_0();
case -157777737: return bem_fieldIteratorGet_0();
case 1393634620: return bem_serializeToString_0();
case 566573794: return bem_tagGet_0();
case 785161348: return bem_fieldNamesGet_0();
case -1270780814: return bem_default_0();
case 1587133120: return bem_classNameGet_0();
case 1645989341: return bem_iteratorGet_0();
case -2131640624: return bem_new_0();
case 873828646: return bem_deserializeClassNameGet_0();
case 969994032: return bem_serializationIteratorGet_0();
case 1464527658: return bem_toString_0();
case 1864861581: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -396283576: return bem_undef_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -1397392842: return bem_getHash_1(bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1451979192: return bem_isEqual_2(bevd_0, bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(31, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_17_ContainerSetIdentityRelations();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst = (BEC_3_9_3_17_ContainerSetIdentityRelations) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;
}
}
