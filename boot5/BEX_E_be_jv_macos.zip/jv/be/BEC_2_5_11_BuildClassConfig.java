package be;
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig extends BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_11_BuildClassConfig_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_11_BuildClassConfig_bels_1, 4));
public static BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_tmpany_phold = bevp_emitPath.bem_copy_0();
bevt_3_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_1_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_2_tmpany_phold.bem_addStep_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_1_tmpany_phold.bem_addStep_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_5_tmpany_phold = bevp_emitName.bem_add_1(bevt_6_tmpany_phold);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bem_addStep_1(bevt_5_tmpany_phold);
bevt_9_tmpany_phold = bevp_emitPath.bem_copy_0();
bevt_10_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_9_tmpany_phold.bem_addStep_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_12_tmpany_phold = bevp_typeEmitName.bem_add_1(bevt_13_tmpany_phold);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_addStep_1(bevt_12_tmpany_phold);
bevp_classDir = bevp_classPath.bem_parentGet_0();
bevt_14_tmpany_phold = bevp_classDir.bem_copy_0();
bevt_16_tmpany_phold = bece_BEC_2_5_11_BuildClassConfig_bevo_0;
bevt_15_tmpany_phold = bevp_emitName.bem_add_1(bevt_16_tmpany_phold);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_tmpany_phold.bem_addStep_1(bevt_15_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_npGetDirect_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGet_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGet_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_emitNameGetDirect_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGet_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGet_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGet_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGet_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGet_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGet_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {2525, 2526, 2527, 2528, 2530, 2531, 2532, 2533, 2534, 2534, 2534, 2534, 2534, 2534, 2534, 2534, 2535, 2535, 2535, 2535, 2535, 2535, 2535, 2535, 2536, 2537, 2537, 2537, 2537, 2544, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 76, 79, 82, 85, 89, 93, 96, 99, 103, 107, 110, 113, 117, 121, 124, 127, 131, 135, 138, 141, 145, 149, 152, 155, 159, 163, 166, 169, 173, 177, 180, 183, 187, 191, 194, 197, 201, 205, 208, 211, 215, 219, 222, 225, 229, 233, 236, 239, 243};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 2525 44
assign 1 2526 45
assign 1 2527 46
assign 1 2528 47
assign 1 2530 48
getNameSpace 1 2530 48
assign 1 2531 49
getEmitName 1 2531 49
assign 1 2532 50
getTypeEmitName 1 2532 50
assign 1 2533 51
getFullEmitName 2 2533 51
assign 1 2534 52
copy 0 2534 52
assign 1 2534 53
emitLangGet 0 2534 53
assign 1 2534 54
addStep 1 2534 54
assign 1 2534 55
new 0 2534 55
assign 1 2534 56
addStep 1 2534 56
assign 1 2534 57
fileExtGet 0 2534 57
assign 1 2534 58
add 1 2534 58
assign 1 2534 59
addStep 1 2534 59
assign 1 2535 60
copy 0 2535 60
assign 1 2535 61
emitLangGet 0 2535 61
assign 1 2535 62
addStep 1 2535 62
assign 1 2535 63
new 0 2535 63
assign 1 2535 64
addStep 1 2535 64
assign 1 2535 65
fileExtGet 0 2535 65
assign 1 2535 66
add 1 2535 66
assign 1 2535 67
addStep 1 2535 67
assign 1 2536 68
parentGet 0 2536 68
assign 1 2537 69
copy 0 2537 69
assign 1 2537 70
new 0 2537 70
assign 1 2537 71
add 1 2537 71
assign 1 2537 72
addStep 1 2537 72
return 1 2544 76
return 1 0 79
return 1 0 82
assign 1 0 85
assign 1 0 89
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
return 1 0 107
return 1 0 110
assign 1 0 113
assign 1 0 117
return 1 0 121
return 1 0 124
assign 1 0 127
assign 1 0 131
return 1 0 135
return 1 0 138
assign 1 0 141
assign 1 0 145
return 1 0 149
return 1 0 152
assign 1 0 155
assign 1 0 159
return 1 0 163
return 1 0 166
assign 1 0 169
assign 1 0 173
return 1 0 177
return 1 0 180
assign 1 0 183
assign 1 0 187
return 1 0 191
return 1 0 194
assign 1 0 197
assign 1 0 201
return 1 0 205
return 1 0 208
assign 1 0 211
assign 1 0 215
return 1 0 219
return 1 0 222
assign 1 0 225
assign 1 0 229
return 1 0 233
return 1 0 236
assign 1 0 239
assign 1 0 243
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 313448517: return bem_npGet_0();
case -1765374005: return bem_classDirGetDirect_0();
case 1486332172: return bem_classDirGet_0();
case -1406264904: return bem_copy_0();
case -2067906174: return bem_fullEmitNameGet_0();
case -694754003: return bem_typeEmitNameGetDirect_0();
case -1478389071: return bem_classPathGetDirect_0();
case -980602152: return bem_sourceFileNameGet_0();
case 11313755: return bem_echo_0();
case 1476265575: return bem_toAny_0();
case -1430069919: return bem_serializeContents_0();
case 1794932317: return bem_emitPathGetDirect_0();
case 577869439: return bem_serializeToString_0();
case 1568711247: return bem_fieldIteratorGet_0();
case 613590276: return bem_libNameGetDirect_0();
case -1884541705: return bem_nameSpaceGet_0();
case -1105672836: return bem_emitterGet_0();
case 2132914481: return bem_emitNameGetDirect_0();
case 2079582721: return bem_toString_0();
case -1791746868: return bem_print_0();
case 448246445: return bem_fieldNamesGet_0();
case -1045898755: return bem_classNameGet_0();
case -1489022328: return bem_once_0();
case 1769189372: return bem_deserializeClassNameGet_0();
case -1168657718: return bem_create_0();
case 1241440710: return bem_typeEmitNameGet_0();
case 1478364395: return bem_libNameGet_0();
case 1258631071: return bem_emitNameGet_0();
case -2040030484: return bem_synPathGetDirect_0();
case -676012608: return bem_emitPathGet_0();
case -621270081: return bem_new_0();
case 418778707: return bem_npGetDirect_0();
case -579194210: return bem_iteratorGet_0();
case 2100472403: return bem_emitterGetDirect_0();
case -1168500292: return bem_fullEmitNameGetDirect_0();
case -1682958828: return bem_tagGet_0();
case 1246114295: return bem_synPathGet_0();
case 572016682: return bem_serializationIteratorGet_0();
case 2096741459: return bem_classPathGet_0();
case -165278261: return bem_hashGet_0();
case 1065448351: return bem_typePathGet_0();
case -1592172719: return bem_typePathGetDirect_0();
case 334571614: return bem_many_0();
case -1544056085: return bem_nameSpaceGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 788505873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 647745368: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1132509672: return bem_defined_1(bevd_0);
case 541459032: return bem_copyTo_1(bevd_0);
case 66099971: return bem_typePathSetDirect_1(bevd_0);
case -1325397925: return bem_fullEmitNameSetDirect_1(bevd_0);
case 1920519737: return bem_emitNameSet_1(bevd_0);
case 2094755861: return bem_nameSpaceSetDirect_1(bevd_0);
case 86677556: return bem_fullEmitNameSet_1(bevd_0);
case -1755209627: return bem_equals_1(bevd_0);
case -2085281126: return bem_undef_1(bevd_0);
case 323577926: return bem_sameType_1(bevd_0);
case 1502939516: return bem_otherClass_1(bevd_0);
case 778721196: return bem_sameClass_1(bevd_0);
case -1949768370: return bem_typeEmitNameSet_1(bevd_0);
case -1887185890: return bem_emitterSetDirect_1(bevd_0);
case -208082164: return bem_classPathSetDirect_1(bevd_0);
case -71352719: return bem_def_1(bevd_0);
case -1779461522: return bem_typeEmitNameSetDirect_1(bevd_0);
case 918677435: return bem_emitterSet_1(bevd_0);
case -1095365233: return bem_classPathSet_1(bevd_0);
case -949301426: return bem_classDirSet_1(bevd_0);
case -1588950309: return bem_sameObject_1(bevd_0);
case -56864629: return bem_libNameSet_1(bevd_0);
case -414748780: return bem_synPathSetDirect_1(bevd_0);
case 943052302: return bem_npSet_1(bevd_0);
case 564481139: return bem_notEquals_1(bevd_0);
case 239658714: return bem_emitPathSetDirect_1(bevd_0);
case -158267703: return bem_typePathSet_1(bevd_0);
case 1764304193: return bem_libNameSetDirect_1(bevd_0);
case -177242791: return bem_synPathSet_1(bevd_0);
case -480003972: return bem_undefined_1(bevd_0);
case 1898017961: return bem_emitNameSetDirect_1(bevd_0);
case -1038241966: return bem_classDirSetDirect_1(bevd_0);
case 612523025: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1925800074: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1889643775: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -791234482: return bem_emitPathSet_1(bevd_0);
case -134160297: return bem_npSetDirect_1(bevd_0);
case 219808522: return bem_nameSpaceSet_1(bevd_0);
case -599428669: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 475074339: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809010404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616024469: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2057452431: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1703033149: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -646220021: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2020076083: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 430249919: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_11_BuildClassConfig();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
