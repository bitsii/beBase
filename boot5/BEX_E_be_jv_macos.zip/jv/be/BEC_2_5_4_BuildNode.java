package be;
/* IO:File: source/build/Nodes.be */
public final class BEC_2_5_4_BuildNode extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
private static byte[] becc_BEC_2_5_4_BuildNode_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_2_5_4_BuildNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_0 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_1 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_5 = {0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_6 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_8 = {0x20,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_9 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_10 = {0x5F,0x74,0x61,0x5F};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_11 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_12 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_13 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_15 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_16 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
public static BEC_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_inst;

public static BET_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_type;

public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_3_9_10_9_ContainerLinkedListAwareNode bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_2_4_3_MathInt(0));
bevp_nlec = (new BEC_2_4_3_MathInt(0));
bevp_wideString = be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_fromNode.bem_nlcGet_0();
bevp_nlc = bevt_0_ta_ph.bem_copy_0();
bevt_1_ta_ph = beva_fromNode.bem_nlecGet_0();
bevp_nlec = bevt_1_ta_ph.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (bevp_contained == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 50*/ {
bevt_4_ta_ph = bevp_contained.bem_firstGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 50*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 50*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 50*/
 else /* Line: 50*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 50*/ {
bevt_5_ta_ph = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_ta_ph;
} /* Line: 51*/
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
/* Line: 55*/ {
if (bevl_ret == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 55*/ {
if (bevl_con == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 55*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 55*/
 else /* Line: 55*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 55*/ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 57*/
 else /* Line: 55*/ {
break;
} /* Line: 55*/
} /* Line: 55*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
/* Line: 65*/ {
if (bevl_ret == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 65*/ {
if (bevl_con == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 65*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 65*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 65*/
 else /* Line: 65*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 65*/ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 67*/
 else /* Line: 65*/ {
break;
} /* Line: 65*/
} /* Line: 65*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 73*/ {
return null;
} /* Line: 74*/
bevl_hh = bevp_heldBy.bem_nextGet_0();
if (bevl_hh == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 77*/ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 78*/
bevt_2_ta_ph = bevl_hh.bemd_0(498179510);
return (BEC_2_5_4_BuildNode) bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 84*/ {
return null;
} /* Line: 85*/
bevl_hh = bevp_heldBy.bem_priorGet_0();
if (bevl_hh == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 88*/ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 89*/
bevt_2_ta_ph = bevl_hh.bemd_0(498179510);
return (BEC_2_5_4_BuildNode) bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 108*/
bevt_3_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
if (bevp_heldBy == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 114*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 114*/ {
bevt_3_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 114*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 114*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 114*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 114*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 115*/
bevt_7_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_priorGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_11_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_12_ta_ph = null;
if (bevp_heldBy == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 121*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 121*/ {
bevt_4_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 121*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 121*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 121*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 121*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 121*/ {
bevt_7_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_priorGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 121*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 121*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 121*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 121*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 122*/
bevt_12_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_priorGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_priorGet_0();
if (bevt_10_ta_ph == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 132*/ {
return null;
} /* Line: 133*/
bevp_heldBy.bem_delete_0();
bem_containerSet_1(null);
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
BEC_2_5_4_BuildNode bevt_3_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 141*/ {
return null;
} /* Line: 142*/
bevt_2_ta_ph = bevp_heldBy.bem_mylistGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_newNode_1(beva_x);
bevp_heldBy.bem_insertBefore_1(bevt_1_ta_ph);
bevt_3_ta_ph = bem_containerGet_0();
beva_x.bem_containerSet_1(bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 149*/ {
bem_initContained_0();
} /* Line: 150*/
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 157*/ {
bem_initContained_0();
} /* Line: 158*/
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 169*/ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 170*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try /* Line: 176*/ {
bevl_res = bem_toStringCompact_0();
} /* Line: 177*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(289803372);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 180*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_7_TextStrings bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_7_TextStrings bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_7_TextStrings bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
bevl_prefix = bem_prefixGet_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_2_ta_ph = bevl_prefix.bemd_1(1170608688, bevt_3_ta_ph);
bevt_4_ta_ph = bevp_typename.bem_toString_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(1170608688, bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = bevt_1_ta_ph.bemd_1(1170608688, bevt_5_ta_ph);
bevt_10_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_9_ta_ph = bevt_10_ta_ph.bem_newlineGet_0();
bevt_8_ta_ph = bevl_ret.bemd_1(1170608688, bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(1170608688, bevl_prefix);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_2));
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(1170608688, bevt_11_ta_ph);
bevt_12_ta_ph = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bemd_1(1170608688, bevt_12_ta_ph);
if (bevp_inClassNp == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 189*/ {
if (bevp_inFile == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 189*/
 else /* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 189*/ {
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_21_ta_ph = bevt_22_ta_ph.bem_newlineGet_0();
bevt_20_ta_ph = bevl_ret.bemd_1(1170608688, bevt_21_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_1(1170608688, bevl_prefix);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_3));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(1170608688, bevt_23_ta_ph);
bevt_24_ta_ph = bevp_inClassNp.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(1170608688, bevt_24_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_4));
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(1170608688, bevt_25_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(1170608688, bevp_inFile);
bevt_27_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_26_ta_ph = bevt_27_ta_ph.bem_newlineGet_0();
bevl_ret = bevt_15_ta_ph.bemd_1(1170608688, bevt_26_ta_ph);
} /* Line: 190*/
if (bevp_held == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 192*/ {
bevt_32_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_31_ta_ph = bevt_32_ta_ph.bem_newlineGet_0();
bevt_30_ta_ph = bevl_ret.bemd_1(1170608688, bevt_31_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(1170608688, bevl_prefix);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevl_ret = bevt_29_ta_ph.bemd_1(1170608688, bevt_33_ta_ph);
bevt_34_ta_ph = bevp_held.bemd_0(1831549959);
bevl_ret = bevl_ret.bemd_1(1170608688, bevt_34_ta_ph);
} /* Line: 194*/
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
bevl_prefix = bem_prefixGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_1_ta_ph = bevl_prefix.bemd_1(1170608688, bevt_2_ta_ph);
bevt_3_ta_ph = bevp_typename.bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1170608688, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(1170608688, bevt_4_ta_ph);
if (bevp_nlc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 202*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_6));
bevt_6_ta_ph = bevl_ret.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
} /* Line: 203*/
if (bevp_inClassNp == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 205*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_7));
bevt_10_ta_ph = bevl_ret.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_ta_ph.bem_add_1(bevt_12_ta_ph);
} /* Line: 206*/
if (bevp_held == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 208*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevt_14_ta_ph = bevl_ret.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = bevp_held.bemd_0(1831549959);
bevl_ret = bevt_14_ta_ph.bem_add_1(bevt_16_ta_ph);
} /* Line: 209*/
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_d = (new BEC_2_4_3_MathInt(0));
bevl_c = bem_containerGet_0();
while (true)
/* Line: 217*/ {
if (bevl_c == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 217*/ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 219*/
 else /* Line: 217*/ {
break;
} /* Line: 217*/
} /* Line: 217*/
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_d = bem_depthGet_0();
bevl_p = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_4_BuildNode_bels_8));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 228*/ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 228*/ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 228*/
 else /* Line: 228*/ {
break;
} /* Line: 228*/
} /* Line: 228*/
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 236*/ {
if (bevl_targ == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_3_ta_ph = bevl_targ.bemd_0(1761813785);
bevt_4_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(1437244455, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
 else /* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 236*/ {
bevl_targ = bevl_targ.bemd_0(-209314394);
} /* Line: 237*/
 else /* Line: 236*/ {
break;
} /* Line: 236*/
} /* Line: 236*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_clnode = bem_scopeGet_0();
bevt_1_ta_ph = bevl_clnode.bemd_0(1761813785);
bevt_2_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1437244455, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 244*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildNode_bels_9));
bevt_3_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 245*/
bevt_6_ta_ph = bevl_clnode.bemd_0(498179510);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(93250510);
bevl_tmpanyn = bevt_5_ta_ph.bemd_0(1831549959);
bevt_8_ta_ph = bevl_clnode.bemd_0(498179510);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(93250510);
bevt_7_ta_ph.bemd_0(1550546882);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(1264034761, bevt_9_ta_ph);
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(-225820942, bevt_10_ta_ph);
bevl_tmpany.bemd_1(-106469251, beva_suffix);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_BuildNode_bels_10));
bevt_12_ta_ph = bevl_tmpanyn.bemd_1(1170608688, bevt_13_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(1170608688, beva_suffix);
bevl_tmpany.bemd_1(-1600379030, bevt_11_ta_ph);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevl_con = bem_containerGet_0();
while (true)
/* Line: 259*/ {
if (bevl_con == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 259*/ {
bevt_3_ta_ph = bevl_con.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_SLOTSGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 260*/ {
bevt_6_ta_ph = bevl_con.bem_typenameGet_0();
bevt_7_ta_ph = bevp_ntypes.bem_FIELDSGet_0();
if (bevt_6_ta_ph.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 260*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 260*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_8_ta_ph;
} /* Line: 261*/
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 263*/
 else /* Line: 259*/ {
break;
} /* Line: 259*/
} /* Line: 259*/
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inSlotsGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_con = bem_containerGet_0();
while (true)
/* Line: 270*/ {
if (bevl_con == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 270*/ {
bevt_2_ta_ph = bevl_con.bem_typenameGet_0();
bevt_3_ta_ph = bevp_ntypes.bem_SLOTSGet_0();
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 271*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 272*/
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 274*/
 else /* Line: 270*/ {
break;
} /* Line: 270*/
} /* Line: 270*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
bevl_v = bevp_held;
bevt_2_ta_ph = bevl_v.bemd_0(-639343856);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-876117666);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 281*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1874877098, bevt_3_ta_ph);
bevl_sco = bem_scopeGet_0();
bevt_5_ta_ph = bevl_sco.bemd_0(1761813785);
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(2142068391, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 284*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_4_BuildNode_bels_11));
bevt_7_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_7_ta_ph);
} /* Line: 285*/
bevt_9_ta_ph = bem_inPropertiesGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 287*/ {
bevt_11_ta_ph = bevl_v.bemd_0(-251153985);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-876117666);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 287*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 287*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 287*/
 else /* Line: 287*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 287*/ {
bevl_sco = bem_classGet_0();
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-275607585, bevt_12_ta_ph);
bevt_13_ta_ph = bem_inSlotsGet_0();
if (bevt_13_ta_ph.bevi_bool)/* Line: 290*/ {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(794902988, bevt_14_ta_ph);
} /* Line: 291*/
} /* Line: 290*/
bevl_sc = bevl_sco.bemd_0(498179510);
bevt_16_ta_ph = bevl_sc.bemd_0(-692514859);
bevt_17_ta_ph = bevl_v.bemd_0(-949106404);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(2027028368, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 295*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_4_BuildNode_bels_12));
bevt_18_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_18_ta_ph);
} /* Line: 296*/
bevt_20_ta_ph = bevl_sc.bemd_0(-692514859);
bevt_21_ta_ph = bevl_v.bemd_0(-949106404);
bevt_20_ta_ph.bemd_2(1850023609, bevt_21_ta_ph, this);
bevt_22_ta_ph = bevl_sc.bemd_0(-594200197);
bevt_22_ta_ph.bemd_1(-467299247, this);
} /* Line: 299*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevl_v = bevp_held;
bevt_1_ta_ph = bevl_v.bemd_0(-639343856);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-876117666);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 305*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1874877098, bevt_2_ta_ph);
bevl_sco = bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(498179510);
bevt_4_ta_ph = bevl_sc.bemd_0(-692514859);
bevt_5_ta_ph = bevl_v.bemd_0(-949106404);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(2027028368, bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 309*/ {
bevt_6_ta_ph = bevl_sc.bemd_0(-692514859);
bevt_7_ta_ph = bevl_v.bemd_0(-949106404);
bevp_held = bevt_6_ta_ph.bemd_1(-1910274594, bevt_7_ta_ph);
} /* Line: 310*/
 else /* Line: 311*/ {
bevt_8_ta_ph = bem_classGet_0();
bevl_cl = bevt_8_ta_ph.bemd_0(498179510);
bevt_10_ta_ph = bevl_cl.bemd_0(-692514859);
bevt_11_ta_ph = bevl_v.bemd_0(-949106404);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(2027028368, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 313*/ {
bevt_12_ta_ph = bevl_cl.bemd_0(-692514859);
bevt_13_ta_ph = bevl_v.bemd_0(-949106404);
bevp_held = bevt_12_ta_ph.bemd_1(-1910274594, bevt_13_ta_ph);
} /* Line: 314*/
 else /* Line: 315*/ {
bevt_14_ta_ph = bevl_sc.bemd_0(-692514859);
bevt_15_ta_ph = bevl_v.bemd_0(-949106404);
bevt_14_ta_ph.bemd_2(1850023609, bevt_15_ta_ph, this);
bevt_16_ta_ph = bevl_sc.bemd_0(-594200197);
bevt_16_ta_ph.bemd_1(-467299247, this);
bevt_18_ta_ph = bevl_sco.bemd_0(1761813785);
bevt_19_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(2142068391, bevt_19_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 318*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_4_BuildNode_bels_13));
bevt_20_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_20_ta_ph);
} /* Line: 319*/
} /* Line: 318*/
} /* Line: 313*/
} /* Line: 309*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_13_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
bevl_vname = bevp_held;
bevt_0_ta_ph = bem_scopeGet_0();
bevl_sc = bevt_0_ta_ph.bemd_0(498179510);
bevt_2_ta_ph = bevl_sc.bemd_0(-692514859);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(2027028368, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 330*/ {
bevt_4_ta_ph = bevl_sc.bemd_0(-692514859);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(-1910274594, bevl_vname);
bevp_held = bevt_3_ta_ph.bemd_0(498179510);
} /* Line: 331*/
 else /* Line: 332*/ {
bevt_5_ta_ph = bem_classGet_0();
bevl_cl = bevt_5_ta_ph.bemd_0(498179510);
bevt_7_ta_ph = bevl_cl.bemd_0(-692514859);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(2027028368, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 334*/ {
bevt_9_ta_ph = bevl_cl.bemd_0(-692514859);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_1(-1910274594, bevl_vname);
bevp_held = bevt_8_ta_ph.bemd_0(498179510);
} /* Line: 335*/
 else /* Line: 336*/ {
bevl_tunode = bem_transUnitGet_0();
bevt_11_ta_ph = bevl_tunode.bemd_0(498179510);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1072241893);
bevl_np = bevt_10_ta_ph.bemd_1(-1910274594, bevl_vname);
if (bevl_np == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 339*/ {
bevt_14_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_aliasedGet_0();
bevl_np = bevt_13_ta_ph.bem_get_1(bevl_vname);
} /* Line: 340*/
if (bevl_np == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_14));
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(bevl_np);
bevt_16_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_16_ta_ph);
} /* Line: 343*/
 else /* Line: 344*/ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(-1600379030, bevl_vname);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_15));
bevt_19_ta_ph = bevl_vname.bemd_1(2142068391, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_19_ta_ph).bevi_bool)/* Line: 348*/ {
bevp_held = bevl_v;
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-2023032421, bevt_21_ta_ph);
bevt_22_ta_ph = bevl_cl.bemd_0(763963289);
bevl_v.bemd_1(132096259, bevt_22_ta_ph);
bevt_23_ta_ph = bevl_sc.bemd_0(-692514859);
bevt_23_ta_ph.bemd_2(1850023609, bevl_vname, this);
bevt_24_ta_ph = bevl_sc.bemd_0(-594200197);
bevt_24_ta_ph.bemd_1(-467299247, this);
} /* Line: 353*/
 else /* Line: 354*/ {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(460497301, bevt_25_ta_ph);
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-275607585, bevt_26_ta_ph);
bevp_held = bevl_v;
bevt_27_ta_ph = bevl_cl.bemd_0(-692514859);
bevt_27_ta_ph.bemd_2(1850023609, bevl_vname, this);
bevt_28_ta_ph = bevl_cl.bemd_0(-594200197);
bevt_28_ta_ph.bemd_1(-467299247, this);
} /* Line: 359*/
} /* Line: 348*/
} /* Line: 342*/
} /* Line: 334*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_node = this;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 368*/ {
while (true)
/* Line: 369*/ {
bevt_2_ta_ph = bevp_constants.bem_anchorTypesGet_0();
bevt_3_ta_ph = bevl_node.bemd_0(1761813785);
bevt_1_ta_ph = bevt_2_ta_ph.bem_contains_1(bevt_3_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 370*/ {
return bevl_node;
} /* Line: 371*/
 else /* Line: 372*/ {
bevl_node = bevl_node.bemd_0(-209314394);
if (bevl_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 374*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_16));
bevt_5_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 375*/
} /* Line: 374*/
} /* Line: 370*/
} /* Line: 369*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 384*/ {
if (bevl_targ == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 384*/ {
bevt_3_ta_ph = bevl_targ.bemd_0(1761813785);
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(1437244455, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 384*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 384*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 384*/
 else /* Line: 384*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 384*/ {
bevl_targ = bevl_targ.bemd_0(-209314394);
} /* Line: 385*/
 else /* Line: 384*/ {
break;
} /* Line: 384*/
} /* Line: 384*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 392*/ {
if (bevl_targ == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 392*/ {
bevt_5_ta_ph = bevl_targ.bemd_0(1761813785);
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(1437244455, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 392*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 392*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 392*/
 else /* Line: 392*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 392*/ {
bevt_8_ta_ph = bevl_targ.bemd_0(1761813785);
bevt_9_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(1437244455, bevt_9_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 392*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 392*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 392*/
 else /* Line: 392*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 392*/ {
bevt_11_ta_ph = bevl_targ.bemd_0(1761813785);
bevt_12_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(1437244455, bevt_12_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 392*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 392*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 392*/
 else /* Line: 392*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 392*/ {
bevl_targ = bevl_targ.bemd_0(-209314394);
} /* Line: 393*/
 else /* Line: 392*/ {
break;
} /* Line: 392*/
} /* Line: 392*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_BuildNode bevt_1_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 399*/ {
return null;
} /* Line: 400*/
bevt_1_ta_ph = bem_containerGet_0();
beva_other.bem_containerSet_1(bevt_1_ta_ph);
bevp_heldBy.bem_heldSet_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
/* Line: 413*/ {
bevt_0_ta_ph = bevl_it.bemd_0(1936605887);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 413*/ {
bevl_i = bevl_it.bemd_0(404000237);
bevl_i.bemd_1(156210675, this);
} /* Line: 415*/
 else /* Line: 413*/ {
break;
} /* Line: 413*/
} /* Line: 413*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
bevt_1_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 421*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 423*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 424*/
} /* Line: 423*/
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 427*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-1747321408);
if (bevl_np == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 429*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 430*/
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(763963289);
if (bevl_np == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 433*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 434*/
bevt_8_ta_ph = bevp_held.bemd_0(-1747321408);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(1831549959);
bevp_held.bemd_1(-1600379030, bevt_7_ta_ph);
} /* Line: 436*/
bevt_10_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 438*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-1747321408);
if (bevl_np == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 440*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 441*/
} /* Line: 440*/
return this;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() throws Throwable {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_condany = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typeDetail = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {29, 30, 31, 32, 34, 35, 36, 37, 38, 43, 43, 44, 44, 45, 46, 50, 50, 50, 50, 50, 0, 0, 0, 51, 51, 53, 54, 55, 55, 55, 55, 0, 0, 0, 56, 57, 59, 63, 64, 65, 65, 65, 65, 0, 0, 0, 66, 67, 69, 73, 73, 74, 76, 77, 77, 78, 80, 80, 84, 84, 85, 87, 88, 88, 89, 91, 91, 95, 95, 99, 99, 103, 103, 107, 107, 108, 108, 110, 110, 110, 114, 114, 0, 114, 114, 114, 0, 0, 115, 115, 117, 117, 117, 117, 121, 121, 0, 121, 121, 121, 0, 0, 0, 121, 121, 121, 121, 0, 0, 122, 122, 124, 124, 124, 124, 124, 128, 132, 132, 133, 135, 136, 137, 141, 141, 142, 144, 144, 144, 145, 145, 149, 149, 150, 152, 153, 157, 157, 158, 160, 161, 165, 169, 169, 170, 177, 179, 180, 182, 186, 187, 187, 187, 187, 187, 187, 188, 188, 188, 188, 188, 188, 188, 188, 189, 189, 189, 189, 0, 0, 0, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 192, 192, 193, 193, 193, 193, 193, 193, 194, 194, 196, 200, 201, 201, 201, 201, 201, 201, 202, 202, 203, 203, 203, 203, 205, 205, 206, 206, 206, 206, 208, 208, 209, 209, 209, 209, 211, 215, 216, 217, 217, 218, 219, 221, 225, 226, 227, 228, 228, 228, 229, 228, 231, 235, 236, 236, 236, 236, 236, 0, 0, 0, 237, 239, 243, 244, 244, 244, 245, 245, 245, 247, 247, 247, 248, 248, 248, 249, 250, 250, 251, 251, 252, 253, 253, 253, 253, 254, 258, 259, 259, 260, 260, 260, 260, 0, 260, 260, 260, 260, 0, 0, 261, 261, 263, 265, 265, 269, 270, 270, 271, 271, 271, 271, 272, 272, 274, 276, 276, 280, 281, 281, 282, 282, 283, 284, 284, 284, 285, 285, 285, 287, 287, 287, 0, 0, 0, 288, 289, 289, 290, 291, 291, 294, 295, 295, 295, 296, 296, 296, 298, 298, 298, 299, 299, 304, 305, 305, 306, 306, 307, 308, 309, 309, 309, 310, 310, 310, 312, 312, 313, 313, 313, 314, 314, 314, 316, 316, 316, 317, 317, 318, 318, 318, 319, 319, 319, 328, 329, 329, 330, 330, 331, 331, 331, 333, 333, 334, 334, 335, 335, 335, 337, 338, 338, 338, 339, 339, 340, 340, 340, 342, 342, 343, 343, 343, 343, 346, 347, 348, 348, 349, 350, 350, 351, 351, 352, 352, 353, 353, 355, 355, 356, 356, 357, 358, 358, 359, 359, 367, 368, 370, 370, 370, 371, 373, 374, 374, 375, 375, 375, 383, 384, 384, 384, 384, 384, 0, 0, 0, 385, 387, 391, 392, 392, 392, 392, 392, 0, 0, 0, 392, 392, 392, 0, 0, 0, 392, 392, 392, 0, 0, 0, 393, 395, 399, 399, 400, 402, 402, 403, 407, 408, 412, 413, 413, 414, 415, 421, 421, 421, 422, 423, 423, 424, 427, 427, 427, 428, 429, 429, 430, 432, 433, 433, 434, 436, 436, 436, 438, 438, 438, 439, 440, 440, 441, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 60, 61, 62, 63, 64, 65, 79, 84, 85, 86, 91, 92, 95, 99, 102, 103, 105, 106, 109, 114, 115, 120, 121, 124, 128, 131, 132, 138, 146, 147, 150, 155, 156, 161, 162, 165, 169, 172, 173, 179, 186, 191, 192, 194, 195, 200, 201, 203, 204, 211, 216, 217, 219, 220, 225, 226, 228, 229, 233, 234, 238, 239, 243, 244, 251, 256, 257, 258, 260, 261, 266, 277, 282, 283, 286, 287, 292, 293, 296, 300, 301, 303, 304, 305, 310, 326, 331, 332, 335, 336, 341, 342, 345, 349, 352, 353, 354, 359, 360, 363, 367, 368, 370, 371, 372, 373, 378, 381, 386, 391, 392, 394, 395, 396, 404, 409, 410, 412, 413, 414, 415, 416, 421, 426, 427, 429, 430, 435, 440, 441, 443, 444, 448, 453, 458, 459, 467, 471, 472, 474, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 534, 535, 540, 541, 544, 548, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 566, 571, 572, 573, 574, 575, 576, 577, 578, 579, 581, 603, 604, 605, 606, 607, 608, 609, 610, 615, 616, 617, 618, 619, 621, 626, 627, 628, 629, 630, 632, 637, 638, 639, 640, 641, 643, 649, 650, 653, 658, 659, 660, 666, 674, 675, 676, 677, 680, 685, 686, 687, 693, 702, 705, 710, 711, 712, 713, 715, 718, 722, 725, 731, 751, 752, 753, 754, 756, 757, 758, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 790, 793, 798, 799, 800, 801, 806, 807, 810, 811, 812, 817, 818, 821, 825, 826, 828, 834, 835, 845, 848, 853, 854, 855, 856, 861, 862, 863, 865, 871, 872, 901, 902, 903, 905, 906, 907, 908, 909, 910, 912, 913, 914, 916, 918, 919, 921, 924, 928, 931, 932, 933, 934, 936, 937, 940, 941, 942, 943, 945, 946, 947, 949, 950, 951, 952, 953, 984, 985, 986, 988, 989, 990, 991, 992, 993, 994, 996, 997, 998, 1001, 1002, 1003, 1004, 1005, 1007, 1008, 1009, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1021, 1022, 1023, 1066, 1067, 1068, 1069, 1070, 1072, 1073, 1074, 1077, 1078, 1079, 1080, 1082, 1083, 1084, 1087, 1088, 1089, 1090, 1091, 1096, 1097, 1098, 1099, 1101, 1106, 1107, 1108, 1109, 1110, 1113, 1114, 1115, 1116, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1153, 1154, 1158, 1159, 1160, 1162, 1165, 1166, 1171, 1172, 1173, 1174, 1188, 1191, 1196, 1197, 1198, 1199, 1201, 1204, 1208, 1211, 1217, 1234, 1237, 1242, 1243, 1244, 1245, 1247, 1250, 1254, 1257, 1258, 1259, 1261, 1264, 1268, 1271, 1272, 1273, 1275, 1278, 1282, 1285, 1291, 1296, 1301, 1302, 1304, 1305, 1306, 1310, 1311, 1318, 1319, 1322, 1324, 1325, 1347, 1348, 1353, 1354, 1355, 1360, 1361, 1364, 1365, 1370, 1371, 1372, 1377, 1378, 1380, 1381, 1386, 1387, 1389, 1390, 1391, 1393, 1394, 1399, 1400, 1401, 1406, 1407, 1413, 1416, 1420, 1423, 1427, 1430, 1434, 1437, 1441, 1444, 1448, 1451, 1455, 1458, 1462, 1465, 1469, 1472, 1476, 1479, 1483, 1486, 1490, 1493, 1497, 1500, 1504, 1507, 1511, 1514, 1518, 1521, 1525, 1528};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 29 46
new 0 29 46
assign 1 30 47
new 0 30 47
assign 1 31 48
new 0 31 48
assign 1 32 49
new 0 32 49
assign 1 34 50
assign 1 35 51
constantsGet 0 35 51
assign 1 36 52
ntypesGet 0 36 52
assign 1 37 53
TOKENGet 0 37 53
assign 1 38 54
new 0 38 54
assign 1 43 60
nlcGet 0 43 60
assign 1 43 61
copy 0 43 61
assign 1 44 62
nlecGet 0 44 62
assign 1 44 63
copy 0 44 63
assign 1 45 64
inClassNpGet 0 45 64
assign 1 46 65
inFileGet 0 46 65
assign 1 50 79
def 1 50 84
assign 1 50 85
firstGet 0 50 85
assign 1 50 86
def 1 50 91
assign 1 0 92
assign 1 0 95
assign 1 0 99
assign 1 51 102
firstGet 0 51 102
return 1 51 103
assign 1 53 105
nextPeerGet 0 53 105
assign 1 54 106
containerGet 0 54 106
assign 1 55 109
undef 1 55 114
assign 1 55 115
def 1 55 120
assign 1 0 121
assign 1 0 124
assign 1 0 128
assign 1 56 131
nextPeerGet 0 56 131
assign 1 57 132
containerGet 0 57 132
return 1 59 138
assign 1 63 146
nextPeerGet 0 63 146
assign 1 64 147
containerGet 0 64 147
assign 1 65 150
undef 1 65 155
assign 1 65 156
def 1 65 161
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 66 172
nextPeerGet 0 66 172
assign 1 67 173
containerGet 0 67 173
return 1 69 179
assign 1 73 186
undef 1 73 191
return 1 74 192
assign 1 76 194
nextGet 0 76 194
assign 1 77 195
undef 1 77 200
return 1 78 201
assign 1 80 203
heldGet 0 80 203
return 1 80 204
assign 1 84 211
undef 1 84 216
return 1 85 217
assign 1 87 219
priorGet 0 87 219
assign 1 88 220
undef 1 88 225
return 1 89 226
assign 1 91 228
heldGet 0 91 228
return 1 91 229
assign 1 95 233
firstGet 0 95 233
return 1 95 234
assign 1 99 238
secondGet 0 99 238
return 1 99 239
assign 1 103 243
thirdGet 0 103 243
return 1 103 244
assign 1 107 251
undef 1 107 256
assign 1 108 257
new 0 108 257
return 1 108 258
assign 1 110 260
priorGet 0 110 260
assign 1 110 261
undef 1 110 266
return 1 110 266
assign 1 114 277
undef 1 114 282
assign 1 0 283
assign 1 114 286
priorGet 0 114 286
assign 1 114 287
undef 1 114 292
assign 1 0 293
assign 1 0 296
assign 1 115 300
new 0 115 300
return 1 115 301
assign 1 117 303
priorGet 0 117 303
assign 1 117 304
priorGet 0 117 304
assign 1 117 305
undef 1 117 310
return 1 117 310
assign 1 121 326
undef 1 121 331
assign 1 0 332
assign 1 121 335
priorGet 0 121 335
assign 1 121 336
undef 1 121 341
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 121 352
priorGet 0 121 352
assign 1 121 353
priorGet 0 121 353
assign 1 121 354
undef 1 121 359
assign 1 0 360
assign 1 0 363
assign 1 122 367
new 0 122 367
return 1 122 368
assign 1 124 370
priorGet 0 124 370
assign 1 124 371
priorGet 0 124 371
assign 1 124 372
priorGet 0 124 372
assign 1 124 373
undef 1 124 378
return 1 124 378
assign 1 128 381
new 0 128 381
assign 1 132 386
undef 1 132 391
return 1 133 392
delete 0 135 394
containerSet 1 136 395
assign 1 137 396
assign 1 141 404
undef 1 141 409
return 1 142 410
assign 1 144 412
mylistGet 0 144 412
assign 1 144 413
newNode 1 144 413
insertBefore 1 144 414
assign 1 145 415
containerGet 0 145 415
containerSet 1 145 416
assign 1 149 421
undef 1 149 426
initContained 0 150 427
prepend 1 152 429
containerSet 1 153 430
assign 1 157 435
undef 1 157 440
initContained 0 158 441
addValue 1 160 443
containerSet 1 161 444
assign 1 165 448
new 0 165 448
assign 1 169 453
undef 1 169 458
assign 1 170 459
new 0 170 459
assign 1 177 467
toStringCompact 0 177 467
print 0 179 471
throw 1 180 472
return 1 182 474
assign 1 186 514
prefixGet 0 186 514
assign 1 187 515
new 0 187 515
assign 1 187 516
add 1 187 516
assign 1 187 517
toString 0 187 517
assign 1 187 518
add 1 187 518
assign 1 187 519
new 0 187 519
assign 1 187 520
add 1 187 520
assign 1 188 521
new 0 188 521
assign 1 188 522
newlineGet 0 188 522
assign 1 188 523
add 1 188 523
assign 1 188 524
add 1 188 524
assign 1 188 525
new 0 188 525
assign 1 188 526
add 1 188 526
assign 1 188 527
toString 0 188 527
assign 1 188 528
add 1 188 528
assign 1 189 529
def 1 189 534
assign 1 189 535
def 1 189 540
assign 1 0 541
assign 1 0 544
assign 1 0 548
assign 1 190 551
new 0 190 551
assign 1 190 552
newlineGet 0 190 552
assign 1 190 553
add 1 190 553
assign 1 190 554
add 1 190 554
assign 1 190 555
new 0 190 555
assign 1 190 556
add 1 190 556
assign 1 190 557
toString 0 190 557
assign 1 190 558
add 1 190 558
assign 1 190 559
new 0 190 559
assign 1 190 560
add 1 190 560
assign 1 190 561
add 1 190 561
assign 1 190 562
new 0 190 562
assign 1 190 563
newlineGet 0 190 563
assign 1 190 564
add 1 190 564
assign 1 192 566
def 1 192 571
assign 1 193 572
new 0 193 572
assign 1 193 573
newlineGet 0 193 573
assign 1 193 574
add 1 193 574
assign 1 193 575
add 1 193 575
assign 1 193 576
new 0 193 576
assign 1 193 577
add 1 193 577
assign 1 194 578
toString 0 194 578
assign 1 194 579
add 1 194 579
return 1 196 581
assign 1 200 603
prefixGet 0 200 603
assign 1 201 604
new 0 201 604
assign 1 201 605
add 1 201 605
assign 1 201 606
toString 0 201 606
assign 1 201 607
add 1 201 607
assign 1 201 608
new 0 201 608
assign 1 201 609
add 1 201 609
assign 1 202 610
def 1 202 615
assign 1 203 616
new 0 203 616
assign 1 203 617
add 1 203 617
assign 1 203 618
toString 0 203 618
assign 1 203 619
add 1 203 619
assign 1 205 621
def 1 205 626
assign 1 206 627
new 0 206 627
assign 1 206 628
add 1 206 628
assign 1 206 629
toString 0 206 629
assign 1 206 630
add 1 206 630
assign 1 208 632
def 1 208 637
assign 1 209 638
new 0 209 638
assign 1 209 639
add 1 209 639
assign 1 209 640
toString 0 209 640
assign 1 209 641
add 1 209 641
return 1 211 643
assign 1 215 649
new 0 215 649
assign 1 216 650
containerGet 0 216 650
assign 1 217 653
def 1 217 658
incrementValue 0 218 659
assign 1 219 660
containerGet 0 219 660
return 1 221 666
assign 1 225 674
depthGet 0 225 674
assign 1 226 675
new 0 226 675
assign 1 227 676
new 0 227 676
assign 1 228 677
new 0 228 677
assign 1 228 680
lesser 1 228 685
assign 1 229 686
add 1 229 686
incrementValue 0 228 687
return 1 231 693
assign 1 235 702
assign 1 236 705
def 1 236 710
assign 1 236 711
typenameGet 0 236 711
assign 1 236 712
TRANSUNITGet 0 236 712
assign 1 236 713
notEquals 1 236 713
assign 1 0 715
assign 1 0 718
assign 1 0 722
assign 1 237 725
containerGet 0 237 725
return 1 239 731
assign 1 243 751
scopeGet 0 243 751
assign 1 244 752
typenameGet 0 244 752
assign 1 244 753
METHODGet 0 244 753
assign 1 244 754
notEquals 1 244 754
assign 1 245 756
new 0 245 756
assign 1 245 757
new 2 245 757
throw 1 245 758
assign 1 247 760
heldGet 0 247 760
assign 1 247 761
tmpCntGet 0 247 761
assign 1 247 762
toString 0 247 762
assign 1 248 763
heldGet 0 248 763
assign 1 248 764
tmpCntGet 0 248 764
incrementValue 0 248 765
assign 1 249 766
new 0 249 766
assign 1 250 767
new 0 250 767
isTmpVarSet 1 250 768
assign 1 251 769
new 0 251 769
autoTypeSet 1 251 770
suffixSet 1 252 771
assign 1 253 772
new 0 253 772
assign 1 253 773
add 1 253 773
assign 1 253 774
add 1 253 774
nameSet 1 253 775
return 1 254 776
assign 1 258 790
containerGet 0 258 790
assign 1 259 793
def 1 259 798
assign 1 260 799
typenameGet 0 260 799
assign 1 260 800
SLOTSGet 0 260 800
assign 1 260 801
equals 1 260 806
assign 1 0 807
assign 1 260 810
typenameGet 0 260 810
assign 1 260 811
FIELDSGet 0 260 811
assign 1 260 812
equals 1 260 817
assign 1 0 818
assign 1 0 821
assign 1 261 825
new 0 261 825
return 1 261 826
assign 1 263 828
containerGet 0 263 828
assign 1 265 834
new 0 265 834
return 1 265 835
assign 1 269 845
containerGet 0 269 845
assign 1 270 848
def 1 270 853
assign 1 271 854
typenameGet 0 271 854
assign 1 271 855
SLOTSGet 0 271 855
assign 1 271 856
equals 1 271 861
assign 1 272 862
new 0 272 862
return 1 272 863
assign 1 274 865
containerGet 0 274 865
assign 1 276 871
new 0 276 871
return 1 276 872
assign 1 280 901
assign 1 281 902
isAddedGet 0 281 902
assign 1 281 903
not 0 281 903
assign 1 282 905
new 0 282 905
isAddedSet 1 282 906
assign 1 283 907
scopeGet 0 283 907
assign 1 284 908
typenameGet 0 284 908
assign 1 284 909
CLASSGet 0 284 909
assign 1 284 910
equals 1 284 910
assign 1 285 912
new 0 285 912
assign 1 285 913
new 2 285 913
throw 1 285 914
assign 1 287 916
inPropertiesGet 0 287 916
assign 1 287 918
isTmpVarGet 0 287 918
assign 1 287 919
not 0 287 919
assign 1 0 921
assign 1 0 924
assign 1 0 928
assign 1 288 931
classGet 0 288 931
assign 1 289 932
new 0 289 932
isPropertySet 1 289 933
assign 1 290 934
inSlotsGet 0 290 934
assign 1 291 936
new 0 291 936
isSlotSet 1 291 937
assign 1 294 940
heldGet 0 294 940
assign 1 295 941
anyMapGet 0 295 941
assign 1 295 942
nameGet 0 295 942
assign 1 295 943
contains 1 295 943
assign 1 296 945
new 0 296 945
assign 1 296 946
new 2 296 946
throw 1 296 947
assign 1 298 949
anyMapGet 0 298 949
assign 1 298 950
nameGet 0 298 950
put 2 298 951
assign 1 299 952
orderedVarsGet 0 299 952
addValue 1 299 953
assign 1 304 984
assign 1 305 985
isAddedGet 0 305 985
assign 1 305 986
not 0 305 986
assign 1 306 988
new 0 306 988
isAddedSet 1 306 989
assign 1 307 990
scopeGet 0 307 990
assign 1 308 991
heldGet 0 308 991
assign 1 309 992
anyMapGet 0 309 992
assign 1 309 993
nameGet 0 309 993
assign 1 309 994
contains 1 309 994
assign 1 310 996
anyMapGet 0 310 996
assign 1 310 997
nameGet 0 310 997
assign 1 310 998
get 1 310 998
assign 1 312 1001
classGet 0 312 1001
assign 1 312 1002
heldGet 0 312 1002
assign 1 313 1003
anyMapGet 0 313 1003
assign 1 313 1004
nameGet 0 313 1004
assign 1 313 1005
contains 1 313 1005
assign 1 314 1007
anyMapGet 0 314 1007
assign 1 314 1008
nameGet 0 314 1008
assign 1 314 1009
get 1 314 1009
assign 1 316 1012
anyMapGet 0 316 1012
assign 1 316 1013
nameGet 0 316 1013
put 2 316 1014
assign 1 317 1015
orderedVarsGet 0 317 1015
addValue 1 317 1016
assign 1 318 1017
typenameGet 0 318 1017
assign 1 318 1018
CLASSGet 0 318 1018
assign 1 318 1019
equals 1 318 1019
assign 1 319 1021
new 0 319 1021
assign 1 319 1022
new 2 319 1022
throw 1 319 1023
assign 1 328 1066
assign 1 329 1067
scopeGet 0 329 1067
assign 1 329 1068
heldGet 0 329 1068
assign 1 330 1069
anyMapGet 0 330 1069
assign 1 330 1070
contains 1 330 1070
assign 1 331 1072
anyMapGet 0 331 1072
assign 1 331 1073
get 1 331 1073
assign 1 331 1074
heldGet 0 331 1074
assign 1 333 1077
classGet 0 333 1077
assign 1 333 1078
heldGet 0 333 1078
assign 1 334 1079
anyMapGet 0 334 1079
assign 1 334 1080
contains 1 334 1080
assign 1 335 1082
anyMapGet 0 335 1082
assign 1 335 1083
get 1 335 1083
assign 1 335 1084
heldGet 0 335 1084
assign 1 337 1087
transUnitGet 0 337 1087
assign 1 338 1088
heldGet 0 338 1088
assign 1 338 1089
aliasedGet 0 338 1089
assign 1 338 1090
get 1 338 1090
assign 1 339 1091
undef 1 339 1096
assign 1 340 1097
emitDataGet 0 340 1097
assign 1 340 1098
aliasedGet 0 340 1098
assign 1 340 1099
get 1 340 1099
assign 1 342 1101
def 1 342 1106
assign 1 343 1107
new 0 343 1107
assign 1 343 1108
add 1 343 1108
assign 1 343 1109
new 2 343 1109
throw 1 343 1110
assign 1 346 1113
new 0 346 1113
nameSet 1 347 1114
assign 1 348 1115
new 0 348 1115
assign 1 348 1116
equals 1 348 1116
assign 1 349 1118
assign 1 350 1119
new 0 350 1119
isTypedSet 1 350 1120
assign 1 351 1121
extendsGet 0 351 1121
namepathSet 1 351 1122
assign 1 352 1123
anyMapGet 0 352 1123
put 2 352 1124
assign 1 353 1125
orderedVarsGet 0 353 1125
addValue 1 353 1126
assign 1 355 1129
new 0 355 1129
isDeclaredSet 1 355 1130
assign 1 356 1131
new 0 356 1131
isPropertySet 1 356 1132
assign 1 357 1133
assign 1 358 1134
anyMapGet 0 358 1134
put 2 358 1135
assign 1 359 1136
orderedVarsGet 0 359 1136
addValue 1 359 1137
assign 1 367 1153
assign 1 368 1154
new 0 368 1154
assign 1 370 1158
anchorTypesGet 0 370 1158
assign 1 370 1159
typenameGet 0 370 1159
assign 1 370 1160
contains 1 370 1160
return 1 371 1162
assign 1 373 1165
containerGet 0 373 1165
assign 1 374 1166
undef 1 374 1171
assign 1 375 1172
new 0 375 1172
assign 1 375 1173
new 2 375 1173
throw 1 375 1174
assign 1 383 1188
assign 1 384 1191
def 1 384 1196
assign 1 384 1197
typenameGet 0 384 1197
assign 1 384 1198
CLASSGet 0 384 1198
assign 1 384 1199
notEquals 1 384 1199
assign 1 0 1201
assign 1 0 1204
assign 1 0 1208
assign 1 385 1211
containerGet 0 385 1211
return 1 387 1217
assign 1 391 1234
assign 1 392 1237
def 1 392 1242
assign 1 392 1243
typenameGet 0 392 1243
assign 1 392 1244
CLASSGet 0 392 1244
assign 1 392 1245
notEquals 1 392 1245
assign 1 0 1247
assign 1 0 1250
assign 1 0 1254
assign 1 392 1257
typenameGet 0 392 1257
assign 1 392 1258
METHODGet 0 392 1258
assign 1 392 1259
notEquals 1 392 1259
assign 1 0 1261
assign 1 0 1264
assign 1 0 1268
assign 1 392 1271
typenameGet 0 392 1271
assign 1 392 1272
TRANSUNITGet 0 392 1272
assign 1 392 1273
notEquals 1 392 1273
assign 1 0 1275
assign 1 0 1278
assign 1 0 1282
assign 1 393 1285
containerGet 0 393 1285
return 1 395 1291
assign 1 399 1296
undef 1 399 1301
return 1 400 1302
assign 1 402 1304
containerGet 0 402 1304
containerSet 1 402 1305
heldSet 1 403 1306
delete 0 407 1310
addValue 1 408 1311
assign 1 412 1318
containedGet 0 412 1318
assign 1 413 1319
iteratorGet 0 413 1319
assign 1 413 1322
hasNextGet 0 413 1322
assign 1 414 1324
nextGet 0 414 1324
containerSet 1 415 1325
assign 1 421 1347
NAMEPATHGet 0 421 1347
assign 1 421 1348
equals 1 421 1353
assign 1 422 1354
assign 1 423 1355
def 1 423 1360
resolve 1 424 1361
assign 1 427 1364
CLASSGet 0 427 1364
assign 1 427 1365
equals 1 427 1370
assign 1 428 1371
namepathGet 0 428 1371
assign 1 429 1372
def 1 429 1377
resolve 1 430 1378
assign 1 432 1380
extendsGet 0 432 1380
assign 1 433 1381
def 1 433 1386
resolve 1 434 1387
assign 1 436 1389
namepathGet 0 436 1389
assign 1 436 1390
toString 0 436 1390
nameSet 1 436 1391
assign 1 438 1393
VARGet 0 438 1393
assign 1 438 1394
equals 1 438 1399
assign 1 439 1400
namepathGet 0 439 1400
assign 1 440 1401
def 1 440 1406
resolve 1 441 1407
return 1 0 1413
assign 1 0 1416
return 1 0 1420
assign 1 0 1423
return 1 0 1427
assign 1 0 1430
return 1 0 1434
assign 1 0 1437
return 1 0 1441
assign 1 0 1444
return 1 0 1448
assign 1 0 1451
return 1 0 1455
assign 1 0 1458
return 1 0 1462
assign 1 0 1465
return 1 0 1469
assign 1 0 1472
return 1 0 1476
assign 1 0 1479
return 1 0 1483
assign 1 0 1486
return 1 0 1490
assign 1 0 1493
return 1 0 1497
assign 1 0 1500
return 1 0 1504
assign 1 0 1507
return 1 0 1511
assign 1 0 1514
return 1 0 1518
assign 1 0 1521
return 1 0 1525
assign 1 0 1528
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1293580752: return bem_inClassNpGet_0();
case -2120170757: return bem_secondGet_0();
case 289803372: return bem_print_0();
case 795136280: return bem_toStringBig_0();
case 139969095: return bem_constantsGet_0();
case -1779465422: return bem_inSlotsGet_0();
case -866104909: return bem_prefixGet_0();
case -534192561: return bem_isThirdGet_0();
case 2143297369: return bem_isSecondGet_0();
case -1900415898: return bem_inFileGet_0();
case -579448567: return bem_wideStringGet_0();
case -2051280467: return bem_initContained_0();
case -322779852: return bem_new_0();
case -1956583947: return bem_firstGet_0();
case 1831625658: return bem_thirdGet_0();
case -839128000: return bem_toStringCompact_0();
case 867307316: return bem_nlcGet_0();
case -1570299634: return bem_containedGet_0();
case -1196056939: return bem_inPropertiesGet_0();
case -1828484911: return bem_delayDeleteGet_0();
case 716551025: return bem_ntypesGet_0();
case -635257914: return bem_scopeGet_0();
case 1249385278: return bem_nlecGet_0();
case -118612185: return bem_hashGet_0();
case 1831549959: return bem_toString_0();
case -1608874055: return bem_heldByGet_0();
case 398468705: return bem_nextDescendGet_0();
case -1136971472: return bem_isFirstGet_0();
case 1475276754: return bem_nextAscendGet_0();
case 1621218705: return bem_buildGet_0();
case -903215656: return bem_copy_0();
case 1761813785: return bem_typenameGet_0();
case 1931442865: return bem_depthGet_0();
case 1258226475: return bem_priorPeerGet_0();
case 849029620: return bem_create_0();
case -209314394: return bem_containerGet_0();
case 498179510: return bem_heldGet_0();
case 1776517350: return bem_transUnitGet_0();
case 1522337273: return bem_resolveNp_0();
case -2108481680: return bem_condanyGet_0();
case 901373857: return bem_reInitContained_0();
case 657904105: return bem_nextPeerGet_0();
case 229948903: return bem_anchorGet_0();
case -411978444: return bem_inlinedGet_0();
case -1887301910: return bem_delete_0();
case 668841590: return bem_syncAddVariable_0();
case 635080559: return bem_delayDelete_0();
case 1510262582: return bem_addVariable_0();
case 1621091766: return bem_typeDetailGet_0();
case -1292167797: return bem_iteratorGet_0();
case -1418001968: return bem_classGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1629142694: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case 524415592: return bem_heldSet_1(bevd_0);
case -593963755: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case -528474096: return bem_typenameSet_1(bevd_0);
case 156210675: return bem_containerSet_1(bevd_0);
case -1446729514: return bem_heldBySet_1(bevd_0);
case -299202550: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case 1923597539: return bem_condanySet_1(bevd_0);
case -1069704888: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case 902814626: return bem_inFileSet_1(bevd_0);
case 2142068391: return bem_equals_1(bevd_0);
case -1615314575: return bem_nlcSet_1(bevd_0);
case 1782373190: return bem_buildSet_1(bevd_0);
case 1071396923: return bem_inClassNpSet_1(bevd_0);
case -703550730: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1837554786: return bem_copyTo_1(bevd_0);
case 1578291106: return bem_wideStringSet_1(bevd_0);
case -467299247: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case -150307161: return bem_inlinedSet_1(bevd_0);
case 1115338500: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case -884781709: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1455637700: return bem_containedSet_1(bevd_0);
case 1163005337: return bem_delayDeleteSet_1(bevd_0);
case -623814883: return bem_typeDetailSet_1(bevd_0);
case 547498877: return bem_constantsSet_1(bevd_0);
case -867373734: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 873549500: return bem_print_1(bevd_0);
case -1628845026: return bem_undef_1(bevd_0);
case 1302870683: return bem_nlecSet_1(bevd_0);
case -880105693: return bem_ntypesSet_1(bevd_0);
case 1437244455: return bem_notEquals_1(bevd_0);
case -1630529294: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1272784505: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -420380206: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1828799483: return bem_tmpVar_2(bevd_0, bevd_1);
case -1187012801: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -918627939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_4_BuildNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst = (BEC_2_5_4_BuildNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_type;
}
}
