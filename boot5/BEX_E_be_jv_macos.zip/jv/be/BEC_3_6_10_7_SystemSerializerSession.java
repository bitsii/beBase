package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_3_6_10_7_SystemSerializerSession extends BEC_2_6_6_SystemObject {
public BEC_3_6_10_7_SystemSerializerSession() { }
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x3A,0x53,0x65,0x73,0x73,0x69,0x6F,0x6E};
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static BEC_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;

public static BET_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;

public BEC_2_9_3_ContainerMap bevp_classTagMap;
public BEC_2_4_3_MathInt bevp_classTagCount;
public BEC_2_4_3_MathInt bevp_serialCount;
public BEC_2_9_11_ContainerIdentityMap bevp_unique;
public BEC_2_6_6_SystemObject bevp_instWriter;
public BEC_3_6_10_7_SystemSerializerSession bem_new_0() throws Throwable {
bevp_classTagMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classTagCount = (new BEC_2_4_3_MathInt(1));
bevp_serialCount = (new BEC_2_4_3_MathInt(1));
bevp_unique = (new BEC_2_9_11_ContainerIdentityMap()).bem_new_0();
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_new_1(BEC_2_6_6_SystemObject beva__instWriter) throws Throwable {
bem_new_0();
bevp_instWriter = beva__instWriter;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classTagMapGet_0() throws Throwable {
return bevp_classTagMap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_classTagMapGetDirect_0() throws Throwable {
return bevp_classTagMap;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_classTagCountGet_0() throws Throwable {
return bevp_classTagCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_classTagCountGetDirect_0() throws Throwable {
return bevp_classTagCount;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_serialCountGet_0() throws Throwable {
return bevp_serialCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_serialCountGetDirect_0() throws Throwable {
return bevp_serialCount;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_serialCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_serialCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_uniqueGet_0() throws Throwable {
return bevp_unique;
} /*method end*/
public final BEC_2_9_11_ContainerIdentityMap bem_uniqueGetDirect_0() throws Throwable {
return bevp_unique;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_uniqueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_uniqueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instWriterGet_0() throws Throwable {
return bevp_instWriter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_instWriterGetDirect_0() throws Throwable {
return bevp_instWriter;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_instWriterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instWriter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_10_7_SystemSerializerSession bem_instWriterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instWriter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {29, 30, 31, 32, 38, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 20, 24, 25, 29, 32, 35, 39, 43, 46, 49, 53, 57, 60, 63, 67, 71, 74, 77, 81, 85, 88, 91, 95};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 29 17
new 0 29 17
assign 1 30 18
new 0 30 18
assign 1 31 19
new 0 31 19
assign 1 32 20
new 0 32 20
new 0 38 24
assign 1 39 25
return 1 0 29
return 1 0 32
assign 1 0 35
assign 1 0 39
return 1 0 43
return 1 0 46
assign 1 0 49
assign 1 0 53
return 1 0 57
return 1 0 60
assign 1 0 63
assign 1 0 67
return 1 0 71
return 1 0 74
assign 1 0 77
assign 1 0 81
return 1 0 85
return 1 0 88
assign 1 0 91
assign 1 0 95
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1191299721: return bem_deserializeClassNameGet_0();
case 1387874104: return bem_serialCountGet_0();
case -260111055: return bem_print_0();
case -1486852325: return bem_copy_0();
case -1166462165: return bem_iteratorGet_0();
case -243903584: return bem_fieldNamesGet_0();
case -1439713241: return bem_classTagMapGetDirect_0();
case -557938157: return bem_toString_0();
case 740465458: return bem_new_0();
case -383147285: return bem_serializationIteratorGet_0();
case 1540627001: return bem_classNameGet_0();
case 351178267: return bem_echo_0();
case -478864541: return bem_serialCountGetDirect_0();
case -1772776515: return bem_instWriterGetDirect_0();
case -317369109: return bem_classTagMapGet_0();
case 402720151: return bem_uniqueGetDirect_0();
case 245697123: return bem_instWriterGet_0();
case 1227289471: return bem_hashGet_0();
case 615337378: return bem_uniqueGet_0();
case 1840305191: return bem_serializeToString_0();
case -2039624597: return bem_sourceFileNameGet_0();
case -1348350074: return bem_create_0();
case -295279542: return bem_once_0();
case -844497155: return bem_tagGet_0();
case 1791742257: return bem_classTagCountGetDirect_0();
case -736476180: return bem_serializeContents_0();
case -1203535797: return bem_toAny_0();
case 1567955799: return bem_fieldIteratorGet_0();
case 1636561855: return bem_classTagCountGet_0();
case -5604421: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 681538010: return bem_notEquals_1(bevd_0);
case 175541240: return bem_uniqueSetDirect_1(bevd_0);
case 1652537276: return bem_uniqueSet_1(bevd_0);
case 640383712: return bem_classTagMapSetDirect_1(bevd_0);
case -1258811879: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 962732124: return bem_classTagCountSetDirect_1(bevd_0);
case 2039711690: return bem_undef_1(bevd_0);
case 1839755987: return bem_otherType_1(bevd_0);
case 1544353280: return bem_otherClass_1(bevd_0);
case 958315163: return bem_sameType_1(bevd_0);
case 1635265370: return bem_classTagCountSet_1(bevd_0);
case 1647627603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -593937181: return bem_copyTo_1(bevd_0);
case 572608181: return bem_instWriterSet_1(bevd_0);
case -218864081: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1748281966: return bem_sameObject_1(bevd_0);
case -1648138128: return bem_classTagMapSet_1(bevd_0);
case 1724749097: return bem_undefined_1(bevd_0);
case -1670790162: return bem_sameClass_1(bevd_0);
case -387830191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2100440987: return bem_def_1(bevd_0);
case 312966472: return bem_instWriterSetDirect_1(bevd_0);
case 1914362936: return bem_serialCountSet_1(bevd_0);
case 551786219: return bem_new_1(bevd_0);
case -67300059: return bem_equals_1(bevd_0);
case 182901076: return bem_serialCountSetDirect_1(bevd_0);
case 1187046692: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1783125070: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1046047039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1868703996: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -528171684: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1304899076: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1671846119: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 520681709: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_6_10_7_SystemSerializerSession_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_3_6_10_7_SystemSerializerSession_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_10_7_SystemSerializerSession();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst = (BEC_3_6_10_7_SystemSerializerSession) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;
}
}
