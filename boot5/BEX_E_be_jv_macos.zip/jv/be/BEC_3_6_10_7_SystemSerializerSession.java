package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_3_6_10_7_SystemSerializerSession extends BEC_2_6_6_SystemObject {
public BEC_3_6_10_7_SystemSerializerSession() { }
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x3A,0x53,0x65,0x73,0x73,0x69,0x6F,0x6E};
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static BEC_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;

public static BET_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;

public BEC_2_9_3_ContainerMap bevp_classTagMap;
public BEC_2_4_3_MathInt bevp_classTagCount;
public BEC_2_4_3_MathInt bevp_serialCount;
public BEC_2_9_11_ContainerIdentityMap bevp_unique;
public BEC_2_6_6_SystemObject bevp_instWriter;
public BEC_3_6_10_7_SystemSerializerSession bem_new_0() throws Throwable {
bevp_classTagMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classTagCount = (new BEC_2_4_3_MathInt(1));
bevp_serialCount = (new BEC_2_4_3_MathInt(1));
bevp_unique = (new BEC_2_9_11_ContainerIdentityMap()).bem_new_0();
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_new_1(BEC_2_6_6_SystemObject beva__instWriter) throws Throwable {
bem_new_0();
bevp_instWriter = beva__instWriter;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classTagMapGet_0() throws Throwable {
return bevp_classTagMap;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_classTagCountGet_0() throws Throwable {
return bevp_classTagCount;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_serialCountGet_0() throws Throwable {
return bevp_serialCount;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_serialCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_uniqueGet_0() throws Throwable {
return bevp_unique;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_uniqueSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instWriterGet_0() throws Throwable {
return bevp_instWriter;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_instWriterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_instWriter = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {28, 29, 30, 31, 37, 38, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 20, 24, 25, 29, 32, 36, 39, 43, 46, 50, 53, 57, 60};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 28 17
new 0 28 17
assign 1 29 18
new 0 29 18
assign 1 30 19
new 0 30 19
assign 1 31 20
new 0 31 20
new 0 37 24
assign 1 38 25
return 1 0 29
assign 1 0 32
return 1 0 36
assign 1 0 39
return 1 0 43
assign 1 0 46
return 1 0 50
assign 1 0 53
return 1 0 57
assign 1 0 60
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1497890237: return bem_print_0();
case 284003800: return bem_uniqueGet_0();
case -2069643406: return bem_iteratorGet_0();
case 226309800: return bem_classTagMapGet_0();
case -1773608927: return bem_toString_0();
case 251273900: return bem_create_0();
case -463012056: return bem_classTagCountGet_0();
case 814616851: return bem_new_0();
case 474426623: return bem_serialCountGet_0();
case 187681083: return bem_copy_0();
case -2006745410: return bem_instWriterGet_0();
case -1191602699: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1472371585: return bem_equals_1(bevd_0);
case -480135129: return bem_classTagMapSet_1(bevd_0);
case 1230809966: return bem_new_1(bevd_0);
case 1149315682: return bem_undef_1(bevd_0);
case -61251069: return bem_def_1(bevd_0);
case -283607422: return bem_instWriterSet_1(bevd_0);
case 361548891: return bem_serialCountSet_1(bevd_0);
case 1056837285: return bem_notEquals_1(bevd_0);
case 2118007658: return bem_copyTo_1(bevd_0);
case -137743549: return bem_uniqueSet_1(bevd_0);
case -1068045903: return bem_classTagCountSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2080349703: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -832674110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1079693664: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1492322303: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_6_10_7_SystemSerializerSession_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_3_6_10_7_SystemSerializerSession_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_10_7_SystemSerializerSession();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst = (BEC_3_6_10_7_SystemSerializerSession) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;
}
}
