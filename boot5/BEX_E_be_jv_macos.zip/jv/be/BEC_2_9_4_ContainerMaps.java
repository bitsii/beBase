package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerMaps extends BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerMaps() { }
private static byte[] becc_BEC_2_9_4_ContainerMaps_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x73};
private static byte[] becc_BEC_2_9_4_ContainerMaps_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerMaps_bevo_0 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_inst;

public static BET_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_type;

public BEC_2_9_4_ContainerMaps bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_4_3_MathInt bevl_ls = null;
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_ls = beva_list.bem_sizeGet_0();
bevt_1_ta_ph = bece_BEC_2_9_4_ContainerMaps_bevo_0;
bevt_0_ta_ph = bevl_ls.bem_add_1(bevt_1_ta_ph);
bevl_map = (new BEC_2_9_3_ContainerMap()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 725*/ {
if (bevl_i.bevi_int < bevl_ls.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 725*/ {
bevt_3_ta_ph = beva_list.bem_get_1(bevl_i);
bevl_i.bevi_int++;
bevt_5_ta_ph = bevl_i;
bevt_4_ta_ph = beva_list.bem_get_1(bevt_5_ta_ph);
bevl_map.bem_put_2(bevt_3_ta_ph, bevt_4_ta_ph);
bevl_i.bevi_int++;
} /* Line: 725*/
 else /* Line: 725*/ {
break;
} /* Line: 725*/
} /* Line: 725*/
return bevl_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fieldsIntoMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_9_3_ContainerMap beva_res) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_i = beva_inst.bemd_0(-1606863806);
while (true)
/* Line: 732*/ {
bevt_0_ta_ph = bevl_i.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 732*/ {
bevt_1_ta_ph = bevl_i.bemd_0(195905731);
bevt_2_ta_ph = bevl_i.bemd_0(-1338738171);
beva_res.bem_put_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 733*/
 else /* Line: 732*/ {
break;
} /* Line: 732*/
} /* Line: 732*/
return beva_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapIntoFields_2(BEC_2_9_3_ContainerMap beva_from, BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_i = beva_inst.bemd_0(-1606863806);
while (true)
/* Line: 739*/ {
bevt_0_ta_ph = bevl_i.bemd_0(2021396727);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 739*/ {
bevt_2_ta_ph = bevl_i.bemd_0(195905731);
bevt_1_ta_ph = beva_from.bem_get_1(bevt_2_ta_ph);
bevl_i.bemd_1(-1270708542, bevt_1_ta_ph);
} /* Line: 740*/
 else /* Line: 739*/ {
break;
} /* Line: 739*/
} /* Line: 739*/
return beva_inst;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {723, 724, 724, 724, 725, 725, 725, 726, 726, 726, 726, 725, 728, 732, 732, 733, 733, 733, 735, 739, 739, 740, 740, 740, 742};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 29, 32, 37, 38, 39, 41, 42, 43, 49, 56, 59, 61, 62, 63, 69, 76, 79, 81, 82, 83, 89};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 723 25
sizeGet 0 723 25
assign 1 724 26
new 0 724 26
assign 1 724 27
add 1 724 27
assign 1 724 28
new 1 724 28
assign 1 725 29
new 0 725 29
assign 1 725 32
lesser 1 725 37
assign 1 726 38
get 1 726 38
assign 1 726 39
incrementValue 0 726 39
assign 1 726 41
get 1 726 41
put 2 726 42
incrementValue 0 725 43
return 1 728 49
assign 1 732 56
fieldIteratorGet 0 732 56
assign 1 732 59
hasNextGet 0 732 59
assign 1 733 61
nextNameGet 0 733 61
assign 1 733 62
currentGet 0 733 62
put 2 733 63
return 1 735 69
assign 1 739 76
fieldIteratorGet 0 739 76
assign 1 739 79
hasNextGet 0 739 79
assign 1 740 81
nextNameGet 0 740 81
assign 1 740 82
get 1 740 82
currentSet 1 740 83
return 1 742 89
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1938521961: return bem_create_0();
case 1428196909: return bem_deserializeClassNameGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case 1469761457: return bem_serializeToString_0();
case -1120775249: return bem_classNameGet_0();
case -559654393: return bem_sourceFileNameGet_0();
case 976077722: return bem_new_0();
case -1359840989: return bem_toAny_0();
case -129765629: return bem_print_0();
case -1677294751: return bem_hashGet_0();
case -1660007365: return bem_iteratorGet_0();
case 126164297: return bem_serializationIteratorGet_0();
case -1640020074: return bem_toString_0();
case -374496050: return bem_tagGet_0();
case -1530492540: return bem_many_0();
case 921209725: return bem_echo_0();
case -1606863806: return bem_fieldIteratorGet_0();
case -1483834827: return bem_copy_0();
case 510046831: return bem_default_0();
case 2028199664: return bem_once_0();
case 1963846645: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1414981672: return bem_defined_1(bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 784609499: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case -1789648416: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 478273283: return bem_fieldsIntoMap_2(bevd_0, (BEC_2_9_3_ContainerMap) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -690930201: return bem_mapIntoFields_2((BEC_2_9_3_ContainerMap) bevd_0, bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerMaps_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerMaps_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerMaps();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst = (BEC_2_9_4_ContainerMaps) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_type;
}
}
