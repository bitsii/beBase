package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerMaps extends BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerMaps() { }
private static byte[] becc_BEC_2_9_4_ContainerMaps_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x73};
private static byte[] becc_BEC_2_9_4_ContainerMaps_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_inst;

public static BET_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_type;

public BEC_2_9_4_ContainerMaps bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_4_3_MathInt bevl_ls = null;
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_ls = beva_list.bem_sizeGet_0();
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevl_ls.bem_add_1(bevt_1_ta_ph);
bevl_map = (new BEC_2_9_3_ContainerMap()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 725*/ {
if (bevl_i.bevi_int < bevl_ls.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 725*/ {
bevt_3_ta_ph = beva_list.bem_get_1(bevl_i);
bevl_i.bevi_int++;
bevt_5_ta_ph = bevl_i;
bevt_4_ta_ph = beva_list.bem_get_1(bevt_5_ta_ph);
bevl_map.bem_put_2(bevt_3_ta_ph, bevt_4_ta_ph);
bevl_i.bevi_int++;
} /* Line: 725*/
 else /* Line: 725*/ {
break;
} /* Line: 725*/
} /* Line: 725*/
return bevl_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fieldsIntoMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_9_3_ContainerMap beva_res) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_i = beva_inst.bemd_0(-1959899288);
while (true)
/* Line: 732*/ {
bevt_0_ta_ph = bevl_i.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 732*/ {
bevt_1_ta_ph = bevl_i.bemd_0(269976565);
bevt_2_ta_ph = bevl_i.bemd_0(1600154727);
beva_res.bem_put_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 733*/
 else /* Line: 732*/ {
break;
} /* Line: 732*/
} /* Line: 732*/
return beva_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapIntoFields_2(BEC_2_9_3_ContainerMap beva_from, BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_i = beva_inst.bemd_0(-1959899288);
while (true)
/* Line: 739*/ {
bevt_0_ta_ph = bevl_i.bemd_0(729437002);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 739*/ {
bevt_2_ta_ph = bevl_i.bemd_0(269976565);
bevt_1_ta_ph = beva_from.bem_get_1(bevt_2_ta_ph);
bevl_i.bemd_1(2142114736, bevt_1_ta_ph);
} /* Line: 740*/
 else /* Line: 739*/ {
break;
} /* Line: 739*/
} /* Line: 739*/
return beva_inst;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {723, 724, 724, 724, 725, 725, 725, 726, 726, 726, 726, 725, 728, 732, 732, 733, 733, 733, 735, 739, 739, 740, 740, 740, 742};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 25, 26, 27, 28, 31, 36, 37, 38, 40, 41, 42, 48, 55, 58, 60, 61, 62, 68, 75, 78, 80, 81, 82, 88};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 723 24
sizeGet 0 723 24
assign 1 724 25
new 0 724 25
assign 1 724 26
add 1 724 26
assign 1 724 27
new 1 724 27
assign 1 725 28
new 0 725 28
assign 1 725 31
lesser 1 725 36
assign 1 726 37
get 1 726 37
assign 1 726 38
incrementValue 0 726 38
assign 1 726 40
get 1 726 40
put 2 726 41
incrementValue 0 725 42
return 1 728 48
assign 1 732 55
fieldIteratorGet 0 732 55
assign 1 732 58
hasNextGet 0 732 58
assign 1 733 60
nextNameGet 0 733 60
assign 1 733 61
currentGet 0 733 61
put 2 733 62
return 1 735 68
assign 1 739 75
fieldIteratorGet 0 739 75
assign 1 739 78
hasNextGet 0 739 78
assign 1 740 80
nextNameGet 0 740 80
assign 1 740 81
get 1 740 81
currentSet 1 740 82
return 1 742 88
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -749268313: return bem_copy_0();
case 1315725661: return bem_hashGet_0();
case 770986263: return bem_create_0();
case 826167413: return bem_classNameGet_0();
case -344688418: return bem_new_0();
case -899256741: return bem_toString_0();
case 1210407094: return bem_tagGet_0();
case 1293575145: return bem_serializeToString_0();
case -407687427: return bem_fieldNamesGet_0();
case -1915666683: return bem_serializationIteratorGet_0();
case -1589221369: return bem_default_0();
case -519581463: return bem_deserializeClassNameGet_0();
case -1514184278: return bem_serializeContents_0();
case 846353007: return bem_echo_0();
case -327712425: return bem_many_0();
case -1959899288: return bem_fieldIteratorGet_0();
case 887254713: return bem_sourceFileNameGet_0();
case -479412451: return bem_iteratorGet_0();
case 818210964: return bem_toAny_0();
case 1270756764: return bem_print_0();
case -1945570638: return bem_once_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 784918995: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1772678539: return bem_notEquals_1(bevd_0);
case 2144395088: return bem_undef_1(bevd_0);
case -1548523977: return bem_otherClass_1(bevd_0);
case 1946977825: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1343727458: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 509956737: return bem_def_1(bevd_0);
case -1468949165: return bem_undefined_1(bevd_0);
case 1596966913: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case -597164057: return bem_defined_1(bevd_0);
case 509252275: return bem_sameObject_1(bevd_0);
case 1477732575: return bem_otherType_1(bevd_0);
case 1498119962: return bem_sameType_1(bevd_0);
case 997331927: return bem_equals_1(bevd_0);
case 1715370141: return bem_sameClass_1(bevd_0);
case 248598654: return bem_copyTo_1(bevd_0);
case -233300707: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -778400958: return bem_fieldsIntoMap_2(bevd_0, (BEC_2_9_3_ContainerMap) bevd_1);
case -1189130153: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1675736992: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 262774206: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403771483: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -662479324: return bem_mapIntoFields_2((BEC_2_9_3_ContainerMap) bevd_0, bevd_1);
case -455603186: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -390764901: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -319997805: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerMaps_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerMaps_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerMaps();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst = (BEC_2_9_4_ContainerMaps) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_type;
}
}
