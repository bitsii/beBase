package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerMaps extends BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerMaps() { }
private static byte[] becc_BEC_2_9_4_ContainerMaps_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x73};
private static byte[] becc_BEC_2_9_4_ContainerMaps_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_inst;

public static BET_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_type;

public BEC_2_9_4_ContainerMaps bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_4_3_MathInt bevl_ls = null;
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevl_ls = beva_list.bem_sizeGet_0();
bevl_map = (new BEC_2_9_3_ContainerMap()).bem_new_1(bevl_ls);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 723 */ {
if (bevl_i.bevi_int < bevl_ls.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 723 */ {
bevt_1_tmpany_phold = beva_list.bem_get_1(bevl_i);
bevl_i.bevi_int++;
bevt_3_tmpany_phold = bevl_i;
bevt_2_tmpany_phold = beva_list.bem_get_1(bevt_3_tmpany_phold);
bevl_map.bem_put_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 723 */
 else  /* Line: 723 */ {
break;
} /* Line: 723 */
} /* Line: 723 */
return bevl_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fieldsIntoMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_9_3_ContainerMap beva_res) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(-794542805);
while (true)
 /* Line: 730 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(1540410692);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 730 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(-1258889836);
bevt_2_tmpany_phold = bevl_i.bemd_0(2135450581);
beva_res.bem_put_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 731 */
 else  /* Line: 730 */ {
break;
} /* Line: 730 */
} /* Line: 730 */
return beva_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapIntoFields_2(BEC_2_9_3_ContainerMap beva_from, BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(-794542805);
while (true)
 /* Line: 737 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(1540410692);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 737 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(-1258889836);
bevt_1_tmpany_phold = beva_from.bem_get_1(bevt_2_tmpany_phold);
bevl_i.bemd_1(1809071188, bevt_1_tmpany_phold);
} /* Line: 738 */
 else  /* Line: 737 */ {
break;
} /* Line: 737 */
} /* Line: 737 */
return beva_inst;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {721, 722, 723, 723, 723, 724, 724, 724, 724, 723, 726, 730, 730, 731, 731, 731, 733, 737, 737, 738, 738, 738, 740};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 27, 32, 33, 34, 36, 37, 38, 44, 51, 54, 56, 57, 58, 64, 71, 74, 76, 77, 78, 84};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 721 22
sizeGet 0 721 22
assign 1 722 23
new 1 722 23
assign 1 723 24
new 0 723 24
assign 1 723 27
lesser 1 723 32
assign 1 724 33
get 1 724 33
assign 1 724 34
incrementValue 0 724 34
assign 1 724 36
get 1 724 36
put 2 724 37
incrementValue 0 723 38
return 1 726 44
assign 1 730 51
fieldIteratorGet 0 730 51
assign 1 730 54
hasNextGet 0 730 54
assign 1 731 56
nextNameGet 0 731 56
assign 1 731 57
currentGet 0 731 57
put 2 731 58
return 1 733 64
assign 1 737 71
fieldIteratorGet 0 737 71
assign 1 737 74
hasNextGet 0 737 74
assign 1 738 76
nextNameGet 0 738 76
assign 1 738 77
get 1 738 77
currentSet 1 738 78
return 1 740 84
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -451287241: return bem_iteratorGet_0();
case 1260713952: return bem_fieldNamesGet_0();
case -512173810: return bem_tagGet_0();
case 166156356: return bem_hashGet_0();
case 1012944178: return bem_create_0();
case -1360047774: return bem_serializeToString_0();
case -794542805: return bem_fieldIteratorGet_0();
case 1712919396: return bem_serializationIteratorGet_0();
case 1010970574: return bem_deserializeClassNameGet_0();
case 368405588: return bem_echo_0();
case 652618710: return bem_print_0();
case 938978826: return bem_serializeContents_0();
case -131396274: return bem_classNameGet_0();
case 373871049: return bem_copy_0();
case 657440259: return bem_many_0();
case 37115722: return bem_toAny_0();
case 149300560: return bem_sourceFileNameGet_0();
case -1497736169: return bem_new_0();
case 884758076: return bem_toString_0();
case 144782273: return bem_once_0();
case 542819736: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 51222701: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case -1849842647: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1450913634: return bem_defined_1(bevd_0);
case -2033993347: return bem_sameObject_1(bevd_0);
case 46811792: return bem_otherType_1(bevd_0);
case 2044588239: return bem_otherClass_1(bevd_0);
case 773892154: return bem_sameClass_1(bevd_0);
case 974930963: return bem_undefined_1(bevd_0);
case -926157429: return bem_equals_1(bevd_0);
case -1418198617: return bem_def_1(bevd_0);
case -1434589659: return bem_undef_1(bevd_0);
case 1184632884: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1691038775: return bem_notEquals_1(bevd_0);
case -1340973491: return bem_sameType_1(bevd_0);
case -1952204646: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -442448216: return bem_copyTo_1(bevd_0);
case -675060011: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 840782676: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1456192500: return bem_mapIntoFields_2((BEC_2_9_3_ContainerMap) bevd_0, bevd_1);
case 1368517810: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1807714621: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1601874845: return bem_fieldsIntoMap_2(bevd_0, (BEC_2_9_3_ContainerMap) bevd_1);
case 1351268593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1842958248: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 498622947: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -330880231: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerMaps_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerMaps_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerMaps();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst = (BEC_2_9_4_ContainerMaps) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_type;
}
}
