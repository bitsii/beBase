package be;
public class BET_2_6_8_SystemBasePath extends BETS_Object {
public BET_2_6_8_SystemBasePath() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameType_1", "otherType_1", "new_1", "fromString_1", "toString_1", "toStringWithSeparator_1", "stepListGet_0", "firstStepGet_0", "lastStepGet_0", "add_1", "parentGet_0", "isAbsoluteGet_0", "makeNonAbsolute_0", "makeAbsolute_0", "trimParents_1", "addStep_1", "deleteFirstStep_0", "addStepList_1", "addSteps_1", "addSteps_2", "stepsGet_0", "subPath_1", "subPath_2", "separatorGet_0", "separatorSet_1", "pathGet_0", "pathSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "separator", "path" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_8_SystemBasePath();
}
}
