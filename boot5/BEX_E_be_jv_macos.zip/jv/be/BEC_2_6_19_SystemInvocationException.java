package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_19_SystemInvocationException extends BEC_2_6_9_SystemException {
public BEC_2_6_19_SystemInvocationException() { }
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_inst;

public static BET_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1260225135: return bem_vvGet_0();
case -899256741: return bem_toString_0();
case -1961371045: return bem_lineNumberGetDirect_0();
case 580716253: return bem_methodNameGet_0();
case 1315725661: return bem_hashGet_0();
case 703575232: return bem_langGet_0();
case 984019358: return bem_framesGetDirect_0();
case -1036335715: return bem_langGetDirect_0();
case 887254713: return bem_sourceFileNameGet_0();
case 460274340: return bem_emitLangGet_0();
case 61067620: return bem_methodNameGetDirect_0();
case -556434115: return bem_translatedGetDirect_0();
case -792704504: return bem_translateEmittedExceptionInner_0();
case -1945570638: return bem_once_0();
case -519581463: return bem_deserializeClassNameGet_0();
case 1277659956: return bem_descriptionGet_0();
case -509699646: return bem_translatedGet_0();
case 1270756764: return bem_print_0();
case -479412451: return bem_iteratorGet_0();
case 1537622088: return bem_descriptionGetDirect_0();
case -553928998: return bem_emitLangGetDirect_0();
case -327712425: return bem_many_0();
case 1092244444: return bem_klassNameGetDirect_0();
case -1514184278: return bem_serializeContents_0();
case -1959899288: return bem_fieldIteratorGet_0();
case -404876081: return bem_translateEmittedException_0();
case 538502757: return bem_framesTextGet_0();
case -749268313: return bem_copy_0();
case -1726253220: return bem_getFrameText_0();
case -1022912205: return bem_fileNameGet_0();
case 241290978: return bem_framesTextGetDirect_0();
case 818210964: return bem_toAny_0();
case 1293575145: return bem_serializeToString_0();
case -1915666683: return bem_serializationIteratorGet_0();
case 770986263: return bem_create_0();
case -407687427: return bem_fieldNamesGet_0();
case 1199613442: return bem_vvGetDirect_0();
case -156734141: return bem_framesGet_0();
case 846353007: return bem_echo_0();
case 1210407094: return bem_tagGet_0();
case 1122833767: return bem_lineNumberGet_0();
case -344688418: return bem_new_0();
case 826167413: return bem_classNameGet_0();
case -1238556728: return bem_klassNameGet_0();
case -2107562528: return bem_fileNameGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1498119962: return bem_sameType_1(bevd_0);
case 1033789283: return bem_klassNameSet_1(bevd_0);
case 2011695784: return bem_new_1(bevd_0);
case 43760314: return bem_emitLangSetDirect_1(bevd_0);
case -1468949165: return bem_undefined_1(bevd_0);
case -734442156: return bem_translatedSet_1(bevd_0);
case -180182582: return bem_methodNameSet_1(bevd_0);
case 1785922348: return bem_vvSetDirect_1(bevd_0);
case 1946977825: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -349002851: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1220746835: return bem_klassNameSetDirect_1(bevd_0);
case 997331927: return bem_equals_1(bevd_0);
case -1343727458: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2142682416: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 668767624: return bem_lineNumberSetDirect_1(bevd_0);
case -200493562: return bem_framesSetDirect_1(bevd_0);
case -1385037482: return bem_descriptionSetDirect_1(bevd_0);
case 1772678539: return bem_notEquals_1(bevd_0);
case -233300707: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1769531159: return bem_vvSet_1(bevd_0);
case 143017201: return bem_framesTextSet_1(bevd_0);
case -597164057: return bem_defined_1(bevd_0);
case 755902182: return bem_fileNameSetDirect_1(bevd_0);
case 918955224: return bem_methodNameSetDirect_1(bevd_0);
case 1715370141: return bem_sameClass_1(bevd_0);
case 248598654: return bem_copyTo_1(bevd_0);
case -311679871: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1548523977: return bem_otherClass_1(bevd_0);
case 784918995: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1219877874: return bem_descriptionSet_1(bevd_0);
case -1334572722: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1899168562: return bem_langSetDirect_1(bevd_0);
case -1539166222: return bem_translatedSetDirect_1(bevd_0);
case 509252275: return bem_sameObject_1(bevd_0);
case 509956737: return bem_def_1(bevd_0);
case 2144395088: return bem_undef_1(bevd_0);
case 166544837: return bem_emitLangSet_1(bevd_0);
case 98519678: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1548799649: return bem_framesSet_1(bevd_0);
case 1716219745: return bem_langSet_1(bevd_0);
case 1477732575: return bem_otherType_1(bevd_0);
case -1945681275: return bem_framesTextSetDirect_1(bevd_0);
case -326027049: return bem_lineNumberSet_1(bevd_0);
case 1735214518: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -744710733: return bem_fileNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1189130153: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -319997805: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1675736992: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -455603186: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -390764901: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 262774206: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403771483: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -83201963: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemInvocationException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_19_SystemInvocationException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemInvocationException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst = (BEC_2_6_19_SystemInvocationException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_type;
}
}
