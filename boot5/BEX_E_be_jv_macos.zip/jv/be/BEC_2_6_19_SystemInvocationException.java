package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_19_SystemInvocationException extends BEC_2_6_9_SystemException {
public BEC_2_6_19_SystemInvocationException() { }
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_inst;

public static BET_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1894629385: return bem_translateEmittedException_0();
case 1179050186: return bem_langGetDirect_0();
case -1039280865: return bem_framesGet_0();
case -258572133: return bem_descriptionGet_0();
case -1175877060: return bem_serializationIteratorGet_0();
case 1549025535: return bem_emitLangGet_0();
case 611357290: return bem_framesGetDirect_0();
case -2087109931: return bem_descriptionGetDirect_0();
case 1143341249: return bem_hashGet_0();
case -4676511: return bem_klassNameGet_0();
case 1101964237: return bem_methodNameGetDirect_0();
case 1416939995: return bem_fieldNamesGet_0();
case -821330970: return bem_fieldIteratorGet_0();
case 181352533: return bem_toString_0();
case 1426181439: return bem_print_0();
case -1149304618: return bem_langGet_0();
case 631110600: return bem_classNameGet_0();
case -1629315459: return bem_once_0();
case 1235873731: return bem_framesTextGetDirect_0();
case -759614770: return bem_serializeToString_0();
case 2144681422: return bem_vvGetDirect_0();
case -371016083: return bem_lineNumberGet_0();
case -405562305: return bem_toAny_0();
case 1386516464: return bem_tagGet_0();
case -1274019410: return bem_copy_0();
case 418678181: return bem_create_0();
case 2123370591: return bem_translatedGetDirect_0();
case -870926142: return bem_serializeContents_0();
case -807409811: return bem_deserializeClassNameGet_0();
case 1366983154: return bem_emitLangGetDirect_0();
case -23168295: return bem_lineNumberGetDirect_0();
case 1571685559: return bem_fileNameGet_0();
case -285809792: return bem_iteratorGet_0();
case -1588300494: return bem_many_0();
case -1869499879: return bem_methodNameGet_0();
case 1493048824: return bem_echo_0();
case -229203981: return bem_klassNameGetDirect_0();
case -464667787: return bem_fileNameGetDirect_0();
case 1802423601: return bem_framesTextGet_0();
case -1041497205: return bem_getFrameText_0();
case 1149256181: return bem_translatedGet_0();
case 769814255: return bem_sourceFileNameGet_0();
case 1243407941: return bem_vvGet_0();
case 1221728998: return bem_translateEmittedExceptionInner_0();
case -1829424765: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -339502058: return bem_sameClass_1(bevd_0);
case -815999382: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1075028542: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -242416125: return bem_framesSet_1(bevd_0);
case -2049513745: return bem_vvSetDirect_1(bevd_0);
case 1468755134: return bem_sameType_1(bevd_0);
case -939587758: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1970703390: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -629130292: return bem_fileNameSetDirect_1(bevd_0);
case -34399643: return bem_emitLangSetDirect_1(bevd_0);
case -859534092: return bem_equals_1(bevd_0);
case 1378844995: return bem_def_1(bevd_0);
case -1366545491: return bem_otherClass_1(bevd_0);
case 1261908232: return bem_methodNameSet_1(bevd_0);
case 1628109142: return bem_lineNumberSet_1(bevd_0);
case 1203647718: return bem_translatedSet_1(bevd_0);
case -1027507443: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 621653151: return bem_notEquals_1(bevd_0);
case -1158066553: return bem_fileNameSet_1(bevd_0);
case -1040190259: return bem_langSet_1(bevd_0);
case 921019711: return bem_lineNumberSetDirect_1(bevd_0);
case 668842442: return bem_framesTextSetDirect_1(bevd_0);
case -2074685332: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 428227432: return bem_sameObject_1(bevd_0);
case 377860994: return bem_vvSet_1(bevd_0);
case -2046792613: return bem_defined_1(bevd_0);
case 537235008: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1998461174: return bem_framesSetDirect_1(bevd_0);
case 1277897247: return bem_descriptionSet_1(bevd_0);
case 1309946830: return bem_descriptionSetDirect_1(bevd_0);
case 498691023: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1370653058: return bem_langSetDirect_1(bevd_0);
case 402602889: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1293150441: return bem_klassNameSetDirect_1(bevd_0);
case 917188775: return bem_methodNameSetDirect_1(bevd_0);
case 1723573660: return bem_otherType_1(bevd_0);
case -2052556066: return bem_framesTextSet_1(bevd_0);
case 1841830185: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 100317461: return bem_klassNameSet_1(bevd_0);
case 1747277191: return bem_undef_1(bevd_0);
case -2055717440: return bem_undefined_1(bevd_0);
case 599422049: return bem_copyTo_1(bevd_0);
case 1744529264: return bem_translatedSetDirect_1(bevd_0);
case -327213722: return bem_emitLangSet_1(bevd_0);
case 1734141663: return bem_new_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 310321751: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -496019130: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1992393015: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1454137039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 981296949: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885634458: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 999054655: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -77420412: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemInvocationException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_19_SystemInvocationException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemInvocationException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst = (BEC_2_6_19_SystemInvocationException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_type;
}
}
