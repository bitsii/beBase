package be;
/* IO:File: source/base/System.be */
public final class BEC_2_6_11_SystemInitializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemInitializer() { }
private static byte[] becc_BEC_2_6_11_SystemInitializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_11_SystemInitializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_11_SystemInitializer_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
public static BEC_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_inst;

public static BET_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_type;

public BEC_2_6_6_SystemObject bem_initializeIfShould_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = beva_inst.bemd_2(-240446712, bevt_1_ta_ph, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 21*/ {
bevt_3_ta_ph = bem_initializeIt_1(beva_inst);
return bevt_3_ta_ph;
} /* Line: 22*/
bevt_4_ta_ph = beva_inst.bemd_0(-2131640624);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitConstruct_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 42*/ {
bevl_init = beva_inst;

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 49*/
return bevl_init;
} /*method end*/
public BEC_2_6_11_SystemInitializer bem_notNullInitDefault_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;

      bevl_init = beva_inst.bemc_getInitial();
      bevl_init.bemd_0(-1270780814);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitIt_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 95*/ {
bevl_init = beva_inst;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = bevl_init.bemd_2(-240446712, bevt_2_ta_ph, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 97*/ {
bevl_init.bemd_0(-1270780814);
} /* Line: 98*/

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 106*/
return bevl_init;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initializeIt_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 135*/ {
bevl_init = beva_inst;
bevl_init.bemd_0(-1270780814);

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 144*/
return bevl_init;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 21, 21, 22, 22, 24, 24, 42, 42, 43, 55, 71, 95, 95, 96, 97, 97, 97, 98, 112, 135, 135, 136, 137, 150};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 22, 23, 25, 26, 33, 38, 39, 43, 49, 60, 65, 66, 67, 68, 69, 71, 76, 83, 88, 89, 90, 94};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 21 18
new 0 21 18
assign 1 21 19
new 0 21 19
assign 1 21 20
can 2 21 20
assign 1 22 22
initializeIt 1 22 22
return 1 22 23
assign 1 24 25
new 0 24 25
return 1 24 26
assign 1 42 33
undef 1 42 38
assign 1 43 39
return 1 55 43
default 0 71 49
assign 1 95 60
undef 1 95 65
assign 1 96 66
assign 1 97 67
new 0 97 67
assign 1 97 68
new 0 97 68
assign 1 97 69
can 2 97 69
default 0 98 71
return 1 112 76
assign 1 135 83
undef 1 135 88
assign 1 136 89
default 0 137 90
return 1 150 94
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1005443364: return bem_create_0();
case 350812655: return bem_copy_0();
case -281350604: return bem_serializeContents_0();
case 2113534779: return bem_hashGet_0();
case 239077256: return bem_print_0();
case 2071875109: return bem_sourceFileNameGet_0();
case -157777737: return bem_fieldIteratorGet_0();
case 1393634620: return bem_serializeToString_0();
case 566573794: return bem_tagGet_0();
case 785161348: return bem_fieldNamesGet_0();
case 1587133120: return bem_classNameGet_0();
case 1645989341: return bem_iteratorGet_0();
case -2131640624: return bem_new_0();
case 873828646: return bem_deserializeClassNameGet_0();
case 969994032: return bem_serializationIteratorGet_0();
case 1464527658: return bem_toString_0();
case 1864861581: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -396283576: return bem_undef_1(bevd_0);
case -1019341637: return bem_notNullInitIt_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case -453608452: return bem_initializeIfShould_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 110122518: return bem_notNullInitConstruct_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case 1752993761: return bem_initializeIt_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
case 2135044581: return bem_notNullInitDefault_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemInitializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_11_SystemInitializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_11_SystemInitializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst = (BEC_2_6_11_SystemInitializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_type;
}
}
