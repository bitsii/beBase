package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_2 = (new BEC_2_4_3_MathInt(0));
public static BEC_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;

public static BET_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;

public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_set = beva__set;
bevp_slots = bevp_set.bem_slotsGet_0();
bevp_modu = bevp_slots.bem_sizeGet_0();
bevp_current = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_containerGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 657 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 657 */ {
bevt_2_tmpany_phold = bevp_slots.bem_get_1(bevl_i);
if (bevt_2_tmpany_phold == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 658 */ {
bevp_current = bevl_i;
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 660 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 657 */
 else  /* Line: 657 */ {
break;
} /* Line: 657 */
} /* Line: 657 */
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 667 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 667 */ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 669 */ {
bevt_2_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_0;
bevp_current = bevl_i.bem_add_1(bevt_2_tmpany_phold);
return bevl_toRet;
} /* Line: 671 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 667 */
 else  /* Line: 667 */ {
break;
} /* Line: 667 */
} /* Line: 667 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delete_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_1;
bevl_i = bevp_current.bem_subtract_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_2;
if (bevl_i.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 679 */ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 681 */ {
bevt_5_tmpany_phold = bevl_sn.bem_keyGet_0();
bevt_4_tmpany_phold = bevp_set.bem_delete_1(bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 682 */ {
bevp_current = bevl_i;
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 684 */
} /* Line: 682 */
} /* Line: 681 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_setGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_setGetDirect_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_setSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_3_12_ContainerSetNodeIterator bem_setSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_slotsGetDirect_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public final BEC_2_4_3_MathInt bem_moduGetDirect_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public final BEC_2_4_3_MathInt bem_currentGetDirect_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {644, 645, 646, 647, 653, 657, 657, 657, 658, 658, 658, 659, 660, 660, 657, 663, 663, 667, 667, 667, 668, 669, 669, 670, 670, 671, 667, 674, 678, 678, 679, 679, 679, 680, 681, 681, 682, 682, 683, 684, 684, 688, 688, 693, 697, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 22, 26, 35, 38, 43, 44, 45, 50, 51, 52, 53, 55, 61, 62, 70, 73, 78, 79, 80, 85, 86, 87, 88, 90, 96, 109, 110, 111, 112, 117, 118, 119, 124, 125, 126, 128, 129, 130, 134, 135, 138, 141, 144, 147, 150, 154, 158, 161, 164, 168, 172, 175, 178, 182, 186, 189, 192, 196};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 644 19
assign 1 645 20
slotsGet 0 645 20
assign 1 646 21
sizeGet 0 646 21
assign 1 647 22
new 0 647 22
return 1 653 26
assign 1 657 35
assign 1 657 38
lesser 1 657 43
assign 1 658 44
get 1 658 44
assign 1 658 45
def 1 658 50
assign 1 659 51
assign 1 660 52
new 0 660 52
return 1 660 53
assign 1 657 55
increment 0 657 55
assign 1 663 61
new 0 663 61
return 1 663 62
assign 1 667 70
assign 1 667 73
lesser 1 667 78
assign 1 668 79
get 1 668 79
assign 1 669 80
def 1 669 85
assign 1 670 86
new 0 670 86
assign 1 670 87
add 1 670 87
return 1 671 88
assign 1 667 90
increment 0 667 90
return 1 674 96
assign 1 678 109
new 0 678 109
assign 1 678 110
subtract 1 678 110
assign 1 679 111
new 0 679 111
assign 1 679 112
greaterEquals 1 679 117
assign 1 680 118
get 1 680 118
assign 1 681 119
def 1 681 124
assign 1 682 125
keyGet 0 682 125
assign 1 682 126
delete 1 682 126
assign 1 683 128
assign 1 684 129
new 0 684 129
return 1 684 130
assign 1 688 134
new 0 688 134
return 1 688 135
return 1 693 138
return 1 697 141
return 1 0 144
return 1 0 147
assign 1 0 150
assign 1 0 154
return 1 0 158
return 1 0 161
assign 1 0 164
assign 1 0 168
return 1 0 172
return 1 0 175
assign 1 0 178
assign 1 0 182
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -301683900: return bem_many_0();
case -307935006: return bem_serializeContents_0();
case 16925706: return bem_nextGet_0();
case -1404446512: return bem_hashGet_0();
case -484233814: return bem_setGet_0();
case 185075715: return bem_toAny_0();
case -1547441220: return bem_containerGet_0();
case 598542224: return bem_iteratorGet_0();
case -2082927025: return bem_toString_0();
case 624309426: return bem_setGetDirect_0();
case 1823740126: return bem_tagGet_0();
case 781134929: return bem_moduGetDirect_0();
case 527027234: return bem_slotsGetDirect_0();
case -2027443534: return bem_nodeIteratorIteratorGet_0();
case 619757843: return bem_once_0();
case -1541505350: return bem_deserializeClassNameGet_0();
case 466095054: return bem_currentGet_0();
case 454931159: return bem_currentGetDirect_0();
case 497780160: return bem_moduGet_0();
case 66568862: return bem_serializeToString_0();
case 558155065: return bem_copy_0();
case 1100108870: return bem_classNameGet_0();
case 13011574: return bem_slotsGet_0();
case 516740577: return bem_sourceFileNameGet_0();
case -866395979: return bem_delete_0();
case -2077327881: return bem_serializationIteratorGet_0();
case 766792083: return bem_new_0();
case 1121159883: return bem_print_0();
case -1347905988: return bem_create_0();
case 1790682890: return bem_fieldIteratorGet_0();
case -1945232493: return bem_echo_0();
case 1790405996: return bem_hasNextGet_0();
case 438469697: return bem_fieldNamesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1378481920: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 104448131: return bem_currentSet_1(bevd_0);
case -637962813: return bem_slotsSet_1(bevd_0);
case 431153324: return bem_notEquals_1(bevd_0);
case 1530691970: return bem_otherClass_1(bevd_0);
case -1605245886: return bem_slotsSetDirect_1(bevd_0);
case -1047922884: return bem_currentSetDirect_1(bevd_0);
case -1788117101: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1619296118: return bem_undefined_1(bevd_0);
case 844066392: return bem_sameClass_1(bevd_0);
case -907470247: return bem_sameObject_1(bevd_0);
case 1868581166: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -778155301: return bem_setSet_1(bevd_0);
case 1407523089: return bem_undef_1(bevd_0);
case 314955640: return bem_def_1(bevd_0);
case 1775045888: return bem_moduSetDirect_1(bevd_0);
case -262755334: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1315093896: return bem_defined_1(bevd_0);
case 378746162: return bem_sameType_1(bevd_0);
case -935074238: return bem_otherType_1(bevd_0);
case 1150573387: return bem_copyTo_1(bevd_0);
case 1872709810: return bem_equals_1(bevd_0);
case -768370819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1965279336: return bem_moduSet_1(bevd_0);
case 1882815354: return bem_setSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 669366955: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -223228068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1903036726: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1915345411: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1939171826: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1309309215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 620336517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;
}
}
