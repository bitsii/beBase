package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;

public static BET_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;

public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_buckets;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_set = beva__set;
bevp_buckets = bevp_set.bem_bucketsGet_0();
bevp_modu = bevp_buckets.bem_sizeGet_0();
bevp_current = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_containerGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = bevp_current;
while (true)
/* Line: 621*/ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 621*/ {
bevt_2_ta_ph = bevp_buckets.bem_get_1(bevl_i);
if (bevt_2_ta_ph == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 622*/ {
bevp_current = bevl_i;
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 624*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 621*/
 else /* Line: 621*/ {
break;
} /* Line: 621*/
} /* Line: 621*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_i = bevp_current;
while (true)
/* Line: 631*/ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 631*/ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 633*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_current = bevl_i.bem_add_1(bevt_2_ta_ph);
return bevl_toRet;
} /* Line: 635*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 631*/
 else /* Line: 631*/ {
break;
} /* Line: 631*/
} /* Line: 631*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delete_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_i = bevp_current.bem_subtract_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_i.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 643*/ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_buckets.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 645*/ {
bevt_5_ta_ph = bevl_sn.bem_keyGet_0();
bevt_4_ta_ph = bevp_set.bem_delete_1(bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 646*/ {
bevp_current = bevl_i;
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 648*/
} /* Line: 646*/
} /* Line: 645*/
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {608, 609, 610, 611, 617, 621, 621, 621, 622, 622, 622, 623, 624, 624, 621, 627, 627, 631, 631, 631, 632, 633, 633, 634, 634, 635, 631, 638, 642, 642, 643, 643, 643, 644, 645, 645, 646, 646, 647, 648, 648, 652, 652, 657, 661};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 23, 32, 35, 40, 41, 42, 47, 48, 49, 50, 52, 58, 59, 67, 70, 75, 76, 77, 82, 83, 84, 85, 87, 93, 106, 107, 108, 109, 114, 115, 116, 121, 122, 123, 125, 126, 127, 131, 132, 135, 138};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 608 16
assign 1 609 17
bucketsGet 0 609 17
assign 1 610 18
sizeGet 0 610 18
assign 1 611 19
new 0 611 19
return 1 617 23
assign 1 621 32
assign 1 621 35
lesser 1 621 40
assign 1 622 41
get 1 622 41
assign 1 622 42
def 1 622 47
assign 1 623 48
assign 1 624 49
new 0 624 49
return 1 624 50
assign 1 621 52
increment 0 621 52
assign 1 627 58
new 0 627 58
return 1 627 59
assign 1 631 67
assign 1 631 70
lesser 1 631 75
assign 1 632 76
get 1 632 76
assign 1 633 77
def 1 633 82
assign 1 634 83
new 0 634 83
assign 1 634 84
add 1 634 84
return 1 635 85
assign 1 631 87
increment 0 631 87
return 1 638 93
assign 1 642 106
new 0 642 106
assign 1 642 107
subtract 1 642 107
assign 1 643 108
new 0 643 108
assign 1 643 109
greaterEquals 1 643 114
assign 1 644 115
get 1 644 115
assign 1 645 116
def 1 645 121
assign 1 646 122
keyGet 0 646 122
assign 1 646 123
delete 1 646 123
assign 1 647 125
assign 1 648 126
new 0 648 126
return 1 648 127
assign 1 652 131
new 0 652 131
return 1 652 132
return 1 657 135
return 1 661 138
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -52976429: return bem_new_0();
case -424614227: return bem_print_0();
case -1706993112: return bem_nodeIteratorIteratorGet_0();
case -676802561: return bem_create_0();
case 1371110439: return bem_nextGet_0();
case -739889867: return bem_containerGet_0();
case -691559580: return bem_delete_0();
case -2046929697: return bem_toString_0();
case -1648793551: return bem_hashGet_0();
case 1293705497: return bem_iteratorGet_0();
case -1337014400: return bem_copy_0();
case -550521573: return bem_hasNextGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1236627689: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1651082390: return bem_undef_1(bevd_0);
case -1337452029: return bem_notEquals_1(bevd_0);
case 1346074140: return bem_equals_1(bevd_0);
case 526222373: return bem_def_1(bevd_0);
case 322005879: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 964580200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1649942408: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -628094110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1488275060: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;
}
}
