package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_3_BuildVar extends BEC_2_6_6_SystemObject {
public BEC_2_5_3_BuildVar() { }
private static byte[] becc_BEC_2_5_3_BuildVar_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72};
private static byte[] becc_BEC_2_5_3_BuildVar_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_1 = {0x20,0x69,0x73,0x41,0x72,0x67};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_2 = {0x20,0x69,0x73,0x54,0x6D,0x70,0x56,0x61,0x72};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_3 = {0x20,0x6E,0x6F,0x74,0x44,0x65,0x63,0x6C,0x61,0x72,0x65,0x64};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_4 = {0x20,0x69,0x73,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
public static BEC_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_inst;

public static BET_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_6_6_SystemObject bevp_refs;
public BEC_2_9_3_ContainerSet bevp_allCalls;
public BEC_2_4_6_TextString bevp_suffix;
public BEC_2_5_4_LogicBool bevp_isArg;
public BEC_2_5_4_LogicBool bevp_isAdded;
public BEC_2_5_4_LogicBool bevp_isTmpVar;
public BEC_2_5_4_LogicBool bevp_autoType;
public BEC_2_5_4_LogicBool bevp_isDeclared;
public BEC_2_5_4_LogicBool bevp_isProperty;
public BEC_2_5_4_LogicBool bevp_isSlot;
public BEC_2_4_3_MathInt bevp_numAssigns;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_4_3_MathInt bevp_vpos;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public BEC_2_5_4_LogicBool bevp_implied;
public BEC_2_4_3_MathInt bevp_maxCpos;
public BEC_2_4_3_MathInt bevp_minCpos;
public BEC_2_4_6_TextString bevp_nativeName;
public BEC_2_5_3_BuildVar bem_new_0() throws Throwable {
BEC_2_4_4_MathInts bevt_0_ta_ph = null;
bevp_isArg = be.BECS_Runtime.boolFalse;
bevp_isAdded = be.BECS_Runtime.boolFalse;
bevp_isTmpVar = be.BECS_Runtime.boolFalse;
bevp_autoType = be.BECS_Runtime.boolFalse;
bevp_isDeclared = be.BECS_Runtime.boolTrue;
bevp_isProperty = be.BECS_Runtime.boolFalse;
bevp_isSlot = be.BECS_Runtime.boolFalse;
bevp_numAssigns = (new BEC_2_4_3_MathInt(0));
bevp_isTyped = be.BECS_Runtime.boolFalse;
bevp_vpos = (new BEC_2_4_3_MathInt(-1));
bevp_isSelf = be.BECS_Runtime.boolFalse;
bevp_isThis = be.BECS_Runtime.boolFalse;
bevp_implied = be.BECS_Runtime.boolFalse;
bevp_maxCpos = (new BEC_2_4_3_MathInt(-1));
bevt_0_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevp_minCpos = bevt_0_ta_ph.bem_maxGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_synNew_1(BEC_2_5_3_BuildVar beva_full) throws Throwable {
bevp_isArg = beva_full.bem_isArgGet_0();
bevp_name = beva_full.bem_nameGet_0();
bevp_isAdded = beva_full.bem_isAddedGet_0();
bevp_isTmpVar = beva_full.bem_isTmpVarGet_0();
bevp_isProperty = beva_full.bem_isPropertyGet_0();
bevp_isSlot = beva_full.bem_isSlotGet_0();
bevp_numAssigns = (new BEC_2_4_3_MathInt(0));
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_vpos = beva_full.bem_vposGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
bevp_implied = beva_full.bem_impliedGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_addCall_1(BEC_2_5_4_BuildNode beva_call) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_allCalls == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 245*/ {
bevp_allCalls = (new BEC_2_9_3_ContainerSet()).bem_new_0();
} /* Line: 246*/
bevp_allCalls.bem_addValue_1(beva_call);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(-1));
if (bevp_maxCpos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 252*/ {
return bevp_maxCpos;
} /* Line: 252*/
bevt_0_ta_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
/* Line: 253*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 253*/ {
bevl_n = bevt_0_ta_loop.bem_nextGet_0();
bevt_6_ta_ph = bevl_n.bemd_0(1080831071);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(-1309254003);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(1704517711, bevp_maxCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 254*/ {
bevt_7_ta_ph = bevl_n.bemd_0(1080831071);
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bemd_0(-1309254003);
} /* Line: 255*/
} /* Line: 254*/
 else /* Line: 253*/ {
break;
} /* Line: 253*/
} /* Line: 253*/
return bevp_maxCpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_bigun = null;
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_4_4_MathInts bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevl_bigun = bevt_1_ta_ph.bem_maxGet_0();
if (bevp_minCpos.bevi_int < bevl_bigun.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 264*/ {
return bevp_minCpos;
} /* Line: 264*/
bevt_0_ta_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
/* Line: 265*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 265*/ {
bevl_n = bevt_0_ta_loop.bem_nextGet_0();
bevt_6_ta_ph = bevl_n.bemd_0(1080831071);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(-1309254003);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(152428237, bevp_minCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 266*/ {
bevt_7_ta_ph = bevl_n.bemd_0(1080831071);
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bemd_0(-1309254003);
} /* Line: 267*/
} /* Line: 266*/
 else /* Line: 265*/ {
break;
} /* Line: 265*/
} /* Line: 265*/
return bevp_minCpos;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_7_SystemClasses bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_ret = bevt_0_ta_ph.bem_className_1(this);
if (bevp_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_3_BuildVar_bels_0));
bevt_2_ta_ph = bevl_ret.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
} /* Line: 276*/
if (bevp_isArg.bevi_bool)/* Line: 278*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_3_BuildVar_bels_1));
bevl_ret = bevl_ret.bem_add_1(bevt_5_ta_ph);
} /* Line: 279*/
if (bevp_isTmpVar.bevi_bool)/* Line: 281*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_3_BuildVar_bels_2));
bevl_ret = bevl_ret.bem_add_1(bevt_6_ta_ph);
} /* Line: 282*/
if (bevp_isDeclared.bevi_bool) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 284*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_3_BuildVar_bels_3));
bevl_ret = bevl_ret.bem_add_1(bevt_8_ta_ph);
} /* Line: 285*/
if (bevp_isProperty.bevi_bool)/* Line: 287*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_3_BuildVar_bels_4));
bevl_ret = bevl_ret.bem_add_1(bevt_9_ta_ph);
} /* Line: 288*/
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_3_BuildVar bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGet_0() throws Throwable {
return bevp_refs;
} /*method end*/
public BEC_2_5_3_BuildVar bem_refsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_refs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGet_0() throws Throwable {
return bevp_allCalls;
} /*method end*/
public BEC_2_5_3_BuildVar bem_allCallsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGet_0() throws Throwable {
return bevp_suffix;
} /*method end*/
public BEC_2_5_3_BuildVar bem_suffixSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGet_0() throws Throwable {
return bevp_isArg;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isArgSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGet_0() throws Throwable {
return bevp_isAdded;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isAddedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGet_0() throws Throwable {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTmpVarSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_autoTypeGet_0() throws Throwable {
return bevp_autoType;
} /*method end*/
public BEC_2_5_3_BuildVar bem_autoTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_autoType = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGet_0() throws Throwable {
return bevp_isDeclared;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isDeclaredSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGet_0() throws Throwable {
return bevp_isProperty;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isPropertySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSlotGet_0() throws Throwable {
return bevp_isSlot;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSlotSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGet_0() throws Throwable {
return bevp_numAssigns;
} /*method end*/
public BEC_2_5_3_BuildVar bem_numAssignsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() throws Throwable {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGet_0() throws Throwable {
return bevp_vpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_vposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() throws Throwable {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() throws Throwable {
return bevp_isThis;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_impliedGet_0() throws Throwable {
return bevp_implied;
} /*method end*/
public BEC_2_5_3_BuildVar bem_impliedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_implied = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_maxCposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_minCposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGet_0() throws Throwable {
return bevp_nativeName;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nativeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 222, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 245, 245, 246, 248, 252, 252, 252, 252, 253, 0, 253, 253, 254, 254, 254, 255, 255, 258, 262, 262, 264, 264, 264, 265, 0, 265, 265, 266, 266, 266, 267, 267, 270, 274, 274, 275, 275, 276, 276, 276, 276, 279, 279, 282, 282, 284, 284, 285, 285, 288, 288, 290, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 75, 80, 81, 83, 96, 97, 102, 103, 105, 105, 108, 110, 111, 112, 113, 115, 116, 123, 136, 137, 138, 143, 144, 146, 146, 149, 151, 152, 153, 154, 156, 157, 164, 178, 179, 180, 185, 186, 187, 188, 189, 192, 193, 196, 197, 199, 204, 205, 206, 209, 210, 212, 215, 218, 222, 225, 229, 232, 236, 239, 243, 246, 250, 253, 257, 260, 264, 267, 271, 274, 278, 281, 285, 288, 292, 295, 299, 302, 306, 309, 313, 316, 320, 323, 327, 330, 334, 337, 341, 345, 349, 352};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 208 39
new 0 208 39
assign 1 209 40
new 0 209 40
assign 1 210 41
new 0 210 41
assign 1 211 42
new 0 211 42
assign 1 212 43
new 0 212 43
assign 1 213 44
new 0 213 44
assign 1 214 45
new 0 214 45
assign 1 215 46
new 0 215 46
assign 1 216 47
new 0 216 47
assign 1 217 48
new 0 217 48
assign 1 218 49
new 0 218 49
assign 1 219 50
new 0 219 50
assign 1 220 51
new 0 220 51
assign 1 221 52
new 0 221 52
assign 1 222 53
new 0 222 53
assign 1 222 54
maxGet 0 222 54
assign 1 229 58
isArgGet 0 229 58
assign 1 230 59
nameGet 0 230 59
assign 1 231 60
isAddedGet 0 231 60
assign 1 232 61
isTmpVarGet 0 232 61
assign 1 233 62
isPropertyGet 0 233 62
assign 1 234 63
isSlotGet 0 234 63
assign 1 235 64
new 0 235 64
assign 1 236 65
namepathGet 0 236 65
assign 1 237 66
isTypedGet 0 237 66
assign 1 238 67
vposGet 0 238 67
assign 1 239 68
isSelfGet 0 239 68
assign 1 240 69
isThisGet 0 240 69
assign 1 241 70
impliedGet 0 241 70
assign 1 245 75
undef 1 245 80
assign 1 246 81
new 0 246 81
addValue 1 248 83
assign 1 252 96
new 0 252 96
assign 1 252 97
greater 1 252 102
return 1 252 103
assign 1 253 105
setIteratorGet 0 0 105
assign 1 253 108
hasNextGet 0 253 108
assign 1 253 110
nextGet 0 253 110
assign 1 254 111
heldGet 0 254 111
assign 1 254 112
cposGet 0 254 112
assign 1 254 113
greater 1 254 113
assign 1 255 115
heldGet 0 255 115
assign 1 255 116
cposGet 0 255 116
return 1 258 123
assign 1 262 136
new 0 262 136
assign 1 262 137
maxGet 0 262 137
assign 1 264 138
lesser 1 264 143
return 1 264 144
assign 1 265 146
setIteratorGet 0 0 146
assign 1 265 149
hasNextGet 0 265 149
assign 1 265 151
nextGet 0 265 151
assign 1 266 152
heldGet 0 266 152
assign 1 266 153
cposGet 0 266 153
assign 1 266 154
lesser 1 266 154
assign 1 267 156
heldGet 0 267 156
assign 1 267 157
cposGet 0 267 157
return 1 270 164
assign 1 274 178
new 0 274 178
assign 1 274 179
className 1 274 179
assign 1 275 180
def 1 275 185
assign 1 276 186
new 0 276 186
assign 1 276 187
add 1 276 187
assign 1 276 188
toString 0 276 188
assign 1 276 189
add 1 276 189
assign 1 279 192
new 0 279 192
assign 1 279 193
add 1 279 193
assign 1 282 196
new 0 282 196
assign 1 282 197
add 1 282 197
assign 1 284 199
not 0 284 204
assign 1 285 205
new 0 285 205
assign 1 285 206
add 1 285 206
assign 1 288 209
new 0 288 209
assign 1 288 210
add 1 288 210
return 1 290 212
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
return 1 0 250
assign 1 0 253
return 1 0 257
assign 1 0 260
return 1 0 264
assign 1 0 267
return 1 0 271
assign 1 0 274
return 1 0 278
assign 1 0 281
return 1 0 285
assign 1 0 288
return 1 0 292
assign 1 0 295
return 1 0 299
assign 1 0 302
return 1 0 306
assign 1 0 309
return 1 0 313
assign 1 0 316
return 1 0 320
assign 1 0 323
return 1 0 327
assign 1 0 330
return 1 0 334
assign 1 0 337
assign 1 0 341
assign 1 0 345
return 1 0 349
assign 1 0 352
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1265008506: return bem_nameGet_0();
case 1294948233: return bem_nativeNameGet_0();
case -499883927: return bem_autoTypeGet_0();
case -323224781: return bem_isTmpVarGet_0();
case -1603470907: return bem_vposGet_0();
case 1103636209: return bem_isAddedGet_0();
case 860012891: return bem_isSlotGet_0();
case -1418219972: return bem_isSelfGet_0();
case 1284782120: return bem_namepathGet_0();
case 27918539: return bem_maxCposGet_0();
case -1474044069: return bem_refsGet_0();
case -1885721916: return bem_suffixGet_0();
case -2046929697: return bem_toString_0();
case 1219712831: return bem_numAssignsGet_0();
case -424614227: return bem_print_0();
case -1142435748: return bem_minCposGet_0();
case 310803089: return bem_isTypedGet_0();
case -676802561: return bem_create_0();
case -1648793551: return bem_hashGet_0();
case 1293705497: return bem_iteratorGet_0();
case -52976429: return bem_new_0();
case -1609008031: return bem_isPropertyGet_0();
case -145724084: return bem_allCallsGet_0();
case -360174139: return bem_isDeclaredGet_0();
case -1690684389: return bem_impliedGet_0();
case -1337014400: return bem_copy_0();
case -1672002562: return bem_isThisGet_0();
case 333845104: return bem_isArgGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -729736044: return bem_nativeNameSet_1(bevd_0);
case 1702969154: return bem_addCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -81935614: return bem_isPropertySet_1(bevd_0);
case 209789274: return bem_maxCposSet_1(bevd_0);
case -516448896: return bem_nameSet_1(bevd_0);
case -1162329484: return bem_vposSet_1(bevd_0);
case 769065218: return bem_isDeclaredSet_1(bevd_0);
case 538034913: return bem_namepathSet_1(bevd_0);
case -1337452029: return bem_notEquals_1(bevd_0);
case 968900482: return bem_impliedSet_1(bevd_0);
case 1346074140: return bem_equals_1(bevd_0);
case 73936172: return bem_isTypedSet_1(bevd_0);
case 322005879: return bem_copyTo_1(bevd_0);
case 1779257240: return bem_isTmpVarSet_1(bevd_0);
case 1651082390: return bem_undef_1(bevd_0);
case 349127626: return bem_numAssignsSet_1(bevd_0);
case -537930344: return bem_minCposSet_1(bevd_0);
case -2015802597: return bem_isSelfSet_1(bevd_0);
case 41060591: return bem_isAddedSet_1(bevd_0);
case 1370749088: return bem_isSlotSet_1(bevd_0);
case 2018596079: return bem_isThisSet_1(bevd_0);
case 767798055: return bem_autoTypeSet_1(bevd_0);
case 152341412: return bem_refsSet_1(bevd_0);
case 2064148392: return bem_suffixSet_1(bevd_0);
case -80953570: return bem_allCallsSet_1(bevd_0);
case -1393017572: return bem_synNew_1((BEC_2_5_3_BuildVar) bevd_0);
case 526222373: return bem_def_1(bevd_0);
case 1371351214: return bem_isArgSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 964580200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1649942408: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -628094110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1488275060: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_5_3_BuildVar_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_3_BuildVar_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_3_BuildVar();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst = (BEC_2_5_3_BuildVar) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_type;
}
}
