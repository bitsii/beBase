package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_8_ContainerLinkedListIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_10_8_ContainerLinkedListIterator() { }
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_8_ContainerLinkedListIterator bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst;

public static BET_3_9_10_8_ContainerLinkedListIterator bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_list;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_currNode;
public BEC_2_5_4_LogicBool bevp_starting;
public BEC_3_9_10_8_ContainerLinkedListIterator bem_new_1(BEC_2_9_10_ContainerLinkedList beva_l) throws Throwable {
bevp_list = beva_l;
bevp_starting = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_containerGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_6_6_SystemObject bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 449*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 450*/
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
if (bevp_starting.bevi_bool)/* Line: 456*/ {
bevt_2_ta_ph = bevp_list.bem_firstNodeGet_0();
if (bevt_2_ta_ph == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 458*/
 else /* Line: 459*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 460*/
} /* Line: 457*/
if (bevp_currNode == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 463*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 463*/ {
bevt_7_ta_ph = bevp_currNode.bem_nextGet_0();
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 463*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 463*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 463*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 463*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 464*/
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_9_ta_ph;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_nxnode = (BEC_3_9_10_4_ContainerLinkedListNode) bem_nextNodeGet_0();
if (bevl_nxnode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 471*/ {
bevp_list.bem_addValue_1(beva_value);
bem_nextNodeGet_0();
} /* Line: 473*/
 else /* Line: 474*/ {
bevl_nxnode.bem_heldSet_1(beva_value);
} /* Line: 475*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextNodeGet_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_starting.bevi_bool)/* Line: 481*/ {
bevp_starting = be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 483*/
 else /* Line: 484*/ {
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 485*/ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 486*/
} /* Line: 485*/
bevp_currNode = bevl_nxnode;
return bevp_currNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva__currNode) throws Throwable {
bevp_starting = be.BECS_Runtime.boolFalse;
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva__currNode;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 503*/ {
return null;
} /* Line: 504*/
bevt_1_ta_ph = bevp_currNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 510*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 511*/
bevp_currNode.bem_heldSet_1(beva_x);
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_starting.bevi_bool)/* Line: 519*/ {
bevp_starting = be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 521*/
 else /* Line: 522*/ {
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 523*/ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 524*/
} /* Line: 523*/
bevp_currNode = bevl_nxnode;
if (bevp_currNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 528*/ {
bevt_2_ta_ph = bevp_currNode.bem_heldGet_0();
return bevt_2_ta_ph;
} /* Line: 529*/
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 535*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 535*/ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 535*/
 else /* Line: 535*/ {
break;
} /* Line: 535*/
} /* Line: 535*/
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGet_0() throws Throwable {
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_currNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startingGet_0() throws Throwable {
return bevp_starting;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_startingSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {437, 439, 445, 449, 449, 450, 450, 452, 452, 457, 457, 457, 458, 458, 460, 460, 463, 463, 0, 463, 463, 463, 0, 0, 464, 464, 466, 466, 470, 471, 471, 472, 473, 475, 482, 483, 485, 485, 486, 489, 490, 494, 498, 499, 503, 503, 504, 506, 506, 510, 510, 511, 511, 513, 514, 514, 520, 521, 523, 523, 524, 527, 528, 528, 529, 529, 531, 535, 535, 535, 536, 535, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 20, 26, 31, 32, 33, 35, 36, 50, 51, 56, 57, 58, 61, 62, 65, 70, 71, 74, 75, 80, 81, 84, 88, 89, 91, 92, 97, 98, 103, 104, 105, 108, 116, 117, 120, 125, 126, 129, 130, 133, 136, 137, 143, 148, 149, 151, 152, 158, 163, 164, 165, 167, 168, 169, 177, 178, 181, 186, 187, 190, 191, 196, 197, 198, 200, 205, 208, 213, 214, 215, 224, 227, 231, 234, 238, 241};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 437 15
assign 1 439 16
new 0 439 16
return 1 445 20
assign 1 449 26
undef 1 449 31
assign 1 450 32
new 0 450 32
return 1 450 33
assign 1 452 35
new 0 452 35
return 1 452 36
assign 1 457 50
firstNodeGet 0 457 50
assign 1 457 51
undef 1 457 56
assign 1 458 57
new 0 458 57
return 1 458 58
assign 1 460 61
new 0 460 61
return 1 460 62
assign 1 463 65
undef 1 463 70
assign 1 0 71
assign 1 463 74
nextGet 0 463 74
assign 1 463 75
undef 1 463 80
assign 1 0 81
assign 1 0 84
assign 1 464 88
new 0 464 88
return 1 464 89
assign 1 466 91
new 0 466 91
return 1 466 92
assign 1 470 97
nextNodeGet 0 470 97
assign 1 471 98
undef 1 471 103
addValue 1 472 104
nextNodeGet 0 473 105
heldSet 1 475 108
assign 1 482 116
new 0 482 116
assign 1 483 117
firstNodeGet 0 483 117
assign 1 485 120
def 1 485 125
assign 1 486 126
nextGet 0 486 126
assign 1 489 129
return 1 490 130
return 1 494 133
assign 1 498 136
new 0 498 136
assign 1 499 137
assign 1 503 143
undef 1 503 148
return 1 504 149
assign 1 506 151
heldGet 0 506 151
return 1 506 152
assign 1 510 158
undef 1 510 163
assign 1 511 164
new 0 511 164
return 1 511 165
heldSet 1 513 167
assign 1 514 168
new 0 514 168
return 1 514 169
assign 1 520 177
new 0 520 177
assign 1 521 178
firstNodeGet 0 521 178
assign 1 523 181
def 1 523 186
assign 1 524 187
nextGet 0 524 187
assign 1 527 190
assign 1 528 191
def 1 528 196
assign 1 529 197
heldGet 0 529 197
return 1 529 198
return 1 531 200
assign 1 535 205
new 0 535 205
assign 1 535 208
lesser 1 535 213
nextSet 1 536 214
incrementValue 0 535 215
return 1 0 224
assign 1 0 227
return 1 0 231
assign 1 0 234
return 1 0 238
assign 1 0 241
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 603718350: return bem_print_0();
case -795498275: return bem_startingGet_0();
case -1147088242: return bem_create_0();
case 1661593242: return bem_hasCurrentGet_0();
case 380806302: return bem_new_0();
case 53308341: return bem_toString_0();
case 2059154207: return bem_containerGet_0();
case -948604495: return bem_currNodeGet_0();
case -832631539: return bem_listGet_0();
case -1555278490: return bem_currentGet_0();
case -615427058: return bem_iteratorGet_0();
case -1087891034: return bem_copy_0();
case 1658565917: return bem_nextGet_0();
case -716837866: return bem_hashGet_0();
case -81096347: return bem_currentNodeGet_0();
case -1510018049: return bem_hasNextGet_0();
case -695412724: return bem_nextNodeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -122894189: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -314452865: return bem_nextSet_1(bevd_0);
case 20832777: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 249425211: return bem_currentNodeSet_1(bevd_0);
case 1070474623: return bem_currNodeSet_1(bevd_0);
case -26957788: return bem_currentSet_1(bevd_0);
case -1462940865: return bem_copyTo_1(bevd_0);
case 1209125372: return bem_undef_1(bevd_0);
case 1003051470: return bem_startingSet_1(bevd_0);
case 1554282063: return bem_notEquals_1(bevd_0);
case 1738005159: return bem_equals_1(bevd_0);
case -1237306698: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 971589665: return bem_def_1(bevd_0);
case -2048863291: return bem_listSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -29663031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1505420135: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2021917335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 559223927: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1581466981: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_8_ContainerLinkedListIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst = (BEC_3_9_10_8_ContainerLinkedListIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_type;
}
}
