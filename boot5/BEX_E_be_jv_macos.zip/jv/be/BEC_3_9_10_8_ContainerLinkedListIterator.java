package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_8_ContainerLinkedListIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_10_8_ContainerLinkedListIterator() { }
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_8_ContainerLinkedListIterator bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst;

public static BET_3_9_10_8_ContainerLinkedListIterator bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_list;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_currNode;
public BEC_2_5_4_LogicBool bevp_starting;
public BEC_3_9_10_8_ContainerLinkedListIterator bem_new_1(BEC_2_9_10_ContainerLinkedList beva_l) throws Throwable {
bevp_list = beva_l;
bevp_starting = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_containerGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_6_6_SystemObject bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 448 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 449 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 455 */ {
bevt_2_tmpany_phold = bevp_list.bem_firstNodeGet_0();
if (bevt_2_tmpany_phold == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /* Line: 457 */
 else  /* Line: 458 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 459 */
} /* Line: 456 */
if (bevp_currNode == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_7_tmpany_phold = bevp_currNode.bem_nextGet_0();
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 463 */
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_nxnode = (BEC_3_9_10_4_ContainerLinkedListNode) bem_nextNodeGet_0();
if (bevl_nxnode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevp_list.bem_addValue_1(beva_value);
bem_nextNodeGet_0();
} /* Line: 472 */
 else  /* Line: 473 */ {
bevl_nxnode.bem_heldSet_1(beva_value);
} /* Line: 474 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextNodeGet_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 480 */ {
bevp_starting = be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 482 */
 else  /* Line: 483 */ {
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 485 */
} /* Line: 484 */
bevp_currNode = bevl_nxnode;
return bevp_currNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva__currNode) throws Throwable {
bevp_starting = be.BECS_Runtime.boolFalse;
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva__currNode;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 502 */ {
return null;
} /* Line: 503 */
bevt_1_tmpany_phold = bevp_currNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 509 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 510 */
bevp_currNode.bem_heldSet_1(beva_x);
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 518 */ {
bevp_starting = be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 520 */
 else  /* Line: 521 */ {
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 523 */
} /* Line: 522 */
bevp_currNode = bevl_nxnode;
if (bevp_currNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 527 */ {
bevt_2_tmpany_phold = bevp_currNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 528 */
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 534 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 534 */ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 534 */
 else  /* Line: 534 */ {
break;
} /* Line: 534 */
} /* Line: 534 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_listGetDirect_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_10_8_ContainerLinkedListIterator bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGet_0() throws Throwable {
return bevp_currNode;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGetDirect_0() throws Throwable {
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_currNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_10_8_ContainerLinkedListIterator bem_currNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startingGet_0() throws Throwable {
return bevp_starting;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_startingGetDirect_0() throws Throwable {
return bevp_starting;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_startingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_10_8_ContainerLinkedListIterator bem_startingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {436, 438, 444, 448, 448, 449, 449, 451, 451, 456, 456, 456, 457, 457, 459, 459, 462, 462, 0, 462, 462, 462, 0, 0, 463, 463, 465, 465, 469, 470, 470, 471, 472, 474, 481, 482, 484, 484, 485, 488, 489, 493, 497, 498, 502, 502, 503, 505, 505, 509, 509, 510, 510, 512, 513, 513, 519, 520, 522, 522, 523, 526, 527, 527, 528, 528, 530, 534, 534, 534, 535, 534, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 20, 26, 31, 32, 33, 35, 36, 50, 51, 56, 57, 58, 61, 62, 65, 70, 71, 74, 75, 80, 81, 84, 88, 89, 91, 92, 97, 98, 103, 104, 105, 108, 116, 117, 120, 125, 126, 129, 130, 133, 136, 137, 143, 148, 149, 151, 152, 158, 163, 164, 165, 167, 168, 169, 177, 178, 181, 186, 187, 190, 191, 196, 197, 198, 200, 205, 208, 213, 214, 215, 224, 227, 230, 234, 238, 241, 244, 248, 252, 255, 258, 262};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 436 15
assign 1 438 16
new 0 438 16
return 1 444 20
assign 1 448 26
undef 1 448 31
assign 1 449 32
new 0 449 32
return 1 449 33
assign 1 451 35
new 0 451 35
return 1 451 36
assign 1 456 50
firstNodeGet 0 456 50
assign 1 456 51
undef 1 456 56
assign 1 457 57
new 0 457 57
return 1 457 58
assign 1 459 61
new 0 459 61
return 1 459 62
assign 1 462 65
undef 1 462 70
assign 1 0 71
assign 1 462 74
nextGet 0 462 74
assign 1 462 75
undef 1 462 80
assign 1 0 81
assign 1 0 84
assign 1 463 88
new 0 463 88
return 1 463 89
assign 1 465 91
new 0 465 91
return 1 465 92
assign 1 469 97
nextNodeGet 0 469 97
assign 1 470 98
undef 1 470 103
addValue 1 471 104
nextNodeGet 0 472 105
heldSet 1 474 108
assign 1 481 116
new 0 481 116
assign 1 482 117
firstNodeGet 0 482 117
assign 1 484 120
def 1 484 125
assign 1 485 126
nextGet 0 485 126
assign 1 488 129
return 1 489 130
return 1 493 133
assign 1 497 136
new 0 497 136
assign 1 498 137
assign 1 502 143
undef 1 502 148
return 1 503 149
assign 1 505 151
heldGet 0 505 151
return 1 505 152
assign 1 509 158
undef 1 509 163
assign 1 510 164
new 0 510 164
return 1 510 165
heldSet 1 512 167
assign 1 513 168
new 0 513 168
return 1 513 169
assign 1 519 177
new 0 519 177
assign 1 520 178
firstNodeGet 0 520 178
assign 1 522 181
def 1 522 186
assign 1 523 187
nextGet 0 523 187
assign 1 526 190
assign 1 527 191
def 1 527 196
assign 1 528 197
heldGet 0 528 197
return 1 528 198
return 1 530 200
assign 1 534 205
new 0 534 205
assign 1 534 208
lesser 1 534 213
nextSet 1 535 214
incrementValue 0 534 215
return 1 0 224
return 1 0 227
assign 1 0 230
assign 1 0 234
return 1 0 238
return 1 0 241
assign 1 0 244
assign 1 0 248
return 1 0 252
return 1 0 255
assign 1 0 258
assign 1 0 262
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2061412556: return bem_classNameGet_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case -1896922217: return bem_currNodeGet_0();
case -868741030: return bem_nextGet_0();
case 605755759: return bem_fieldNamesGet_0();
case -39706070: return bem_serializeContents_0();
case 2069196027: return bem_print_0();
case 1359777543: return bem_toAny_0();
case -1854969613: return bem_currentNodeGet_0();
case 874968344: return bem_once_0();
case 344752250: return bem_hashGet_0();
case -1437630621: return bem_nextNodeGet_0();
case -1276472965: return bem_hasNextGet_0();
case 27033645: return bem_sourceFileNameGet_0();
case 502031978: return bem_iteratorGet_0();
case -668135281: return bem_listGetDirect_0();
case 1480415803: return bem_serializationIteratorGet_0();
case 258776523: return bem_currentGet_0();
case -1864610205: return bem_startingGet_0();
case 461453475: return bem_listGet_0();
case 325964466: return bem_echo_0();
case -260947287: return bem_startingGetDirect_0();
case 1965613314: return bem_tagGet_0();
case -966316218: return bem_currNodeGetDirect_0();
case 1578098134: return bem_toString_0();
case 26417469: return bem_create_0();
case 962099177: return bem_fieldIteratorGet_0();
case -1878305271: return bem_many_0();
case -1026471237: return bem_hasCurrentGet_0();
case 334767424: return bem_copy_0();
case 159014997: return bem_containerGet_0();
case 2132890711: return bem_new_0();
case -799200084: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -386059970: return bem_listSet_1(bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 334263941: return bem_currNodeSetDirect_1(bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1162406138: return bem_currentSet_1(bevd_0);
case 47371806: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -163977931: return bem_startingSetDirect_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2051609519: return bem_startingSet_1(bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case 1717866197: return bem_currNodeSet_1(bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case 419124452: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case -1303511503: return bem_currentNodeSet_1(bevd_0);
case 1551212143: return bem_nextSet_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
case 675298367: return bem_listSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_8_ContainerLinkedListIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst = (BEC_3_9_10_8_ContainerLinkedListIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_type;
}
}
