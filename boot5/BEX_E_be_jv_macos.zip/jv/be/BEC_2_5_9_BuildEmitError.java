package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError extends BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 126164297: return bem_serializationIteratorGet_0();
case -374496050: return bem_tagGet_0();
case 608015252: return bem_langGet_0();
case 1698849909: return bem_framesGet_0();
case -1530492540: return bem_many_0();
case -1254835658: return bem_nodeGet_0();
case 200009796: return bem_vvGetDirect_0();
case 144878382: return bem_descriptionGet_0();
case -1606863806: return bem_fieldIteratorGet_0();
case 1963846645: return bem_serializeContents_0();
case -1359840989: return bem_toAny_0();
case -1938521961: return bem_create_0();
case 1556017976: return bem_emitLangGetDirect_0();
case 671702018: return bem_lineNumberGet_0();
case 1469761457: return bem_serializeToString_0();
case -1640020074: return bem_toString_0();
case -1483834827: return bem_copy_0();
case -1677294751: return bem_hashGet_0();
case 921209725: return bem_echo_0();
case 559053532: return bem_translatedGet_0();
case -1660007365: return bem_iteratorGet_0();
case 1828306275: return bem_msgGet_0();
case 976077722: return bem_new_0();
case 2028199664: return bem_once_0();
case 1646847111: return bem_framesTextGet_0();
case 1299349454: return bem_fileNameGetDirect_0();
case -1052253488: return bem_methodNameGet_0();
case -1120775249: return bem_classNameGet_0();
case 793972788: return bem_nodeGetDirect_0();
case -515744959: return bem_framesTextGetDirect_0();
case -955474037: return bem_descriptionGetDirect_0();
case -246366949: return bem_fileNameGet_0();
case -559654393: return bem_sourceFileNameGet_0();
case 1842462478: return bem_methodNameGetDirect_0();
case -103060207: return bem_vvGet_0();
case 152503532: return bem_translateEmittedException_0();
case 1394647095: return bem_lineNumberGetDirect_0();
case -1618899972: return bem_klassNameGetDirect_0();
case -1410376018: return bem_translatedGetDirect_0();
case 1505634064: return bem_fieldNamesGet_0();
case -129765629: return bem_print_0();
case 170125017: return bem_msgGetDirect_0();
case -2133008556: return bem_translateEmittedExceptionInner_0();
case -499794894: return bem_langGetDirect_0();
case 869857920: return bem_emitLangGet_0();
case -926050067: return bem_getFrameText_0();
case 1629221068: return bem_framesGetDirect_0();
case -740631509: return bem_klassNameGet_0();
case 1428196909: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1414981672: return bem_defined_1(bevd_0);
case 807388910: return bem_msgSetDirect_1(bevd_0);
case 1824093944: return bem_msgSet_1(bevd_0);
case 1032669404: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case 1594497446: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case -247231398: return bem_new_1(bevd_0);
case 1468960611: return bem_framesSetDirect_1(bevd_0);
case -1829739366: return bem_vvSetDirect_1(bevd_0);
case -2067672088: return bem_klassNameSetDirect_1(bevd_0);
case -41123889: return bem_descriptionSet_1(bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case -180380462: return bem_translatedSet_1(bevd_0);
case -55952371: return bem_lineNumberSetDirect_1(bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case -619909670: return bem_framesTextSet_1(bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case 88142186: return bem_langSetDirect_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case 1204396042: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case 445490394: return bem_langSet_1(bevd_0);
case 938840927: return bem_emitLangSetDirect_1(bevd_0);
case 1245546629: return bem_methodNameSet_1(bevd_0);
case 2068137027: return bem_fileNameSetDirect_1(bevd_0);
case -1820249970: return bem_framesTextSetDirect_1(bevd_0);
case -194410415: return bem_emitLangSet_1(bevd_0);
case 1091713906: return bem_nodeSetDirect_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case -684166321: return bem_lineNumberSet_1(bevd_0);
case 1452458290: return bem_klassNameSet_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1848755034: return bem_framesSet_1(bevd_0);
case -1391012648: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -65371231: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case -1472672418: return bem_methodNameSetDirect_1(bevd_0);
case -782894068: return bem_descriptionSetDirect_1(bevd_0);
case -1143929528: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1719953059: return bem_fileNameSet_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case 1002422033: return bem_translatedSetDirect_1(bevd_0);
case 1113486054: return bem_vvSet_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1856930065: return bem_nodeSet_1(bevd_0);
case -1789648416: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1157579770: return bem_new_2(bevd_0, bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -721656358: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildEmitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
