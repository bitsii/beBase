package be;
/* IO:File: source/extended/Command.be */
public final class BEC_2_6_7_SystemCommand extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
public static BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;
public BEC_2_4_6_TextString bevp_command;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) throws Throwable {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bem_new_1(beva__command);
bevt_0_tmpany_phold = bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;

      bevi_p = Runtime.getRuntime().exec(bevp_command.bems_toJvString());
      return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() throws Throwable {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 93 */ {
return bevp_outputReader;
} /* Line: 94 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.getInputStream();
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 114 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() throws Throwable {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 43, 44, 44, 82, 86, 93, 93, 94, 96, 107, 108, 112, 112, 113, 114, 119, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 18, 19, 20, 34, 37, 42, 47, 48, 50, 53, 54, 58, 63, 64, 65, 70, 76, 79, 83, 86};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 38 13
new 1 43 18
assign 1 44 19
run 0 44 19
return 1 44 20
return 1 82 34
run 0 86 37
assign 1 93 42
def 1 93 47
return 1 94 48
assign 1 96 50
new 0 96 50
extOpen 0 107 53
return 1 108 54
assign 1 112 58
def 1 112 63
close 0 113 64
assign 1 114 65
closeOutput 0 119 70
return 1 0 76
assign 1 0 79
return 1 0 83
assign 1 0 86
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case 830183237: return bem_outputGet_0();
case -1436664914: return bem_print_0();
case -373295708: return bem_serializeContents_0();
case -180143514: return bem_serializationIteratorGet_0();
case -829651994: return bem_open_0();
case -1860146814: return bem_tagGet_0();
case -2116220804: return bem_new_0();
case -268338848: return bem_fieldIteratorGet_0();
case -1859117850: return bem_closeOutput_0();
case -401631898: return bem_close_0();
case -1679191914: return bem_outputReaderGet_0();
case -454647513: return bem_once_0();
case -1021276807: return bem_copy_0();
case -2018228316: return bem_run_0();
case -453378259: return bem_deserializeClassNameGet_0();
case -2006878754: return bem_create_0();
case -1274969629: return bem_iteratorGet_0();
case 810650310: return bem_serializeToString_0();
case -1329156032: return bem_echo_0();
case 1737839713: return bem_toString_0();
case -1682959242: return bem_many_0();
case -681406586: return bem_hashGet_0();
case -605259456: return bem_toAny_0();
case -2091574346: return bem_commandGet_0();
case -1250381101: return bem_classNameGet_0();
case -416881840: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case -1196486530: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1480218954: return bem_def_1(bevd_0);
case 1468796062: return bem_sameType_1(bevd_0);
case 1922760127: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -935094060: return bem_undefined_1(bevd_0);
case 1096308396: return bem_notEquals_1(bevd_0);
case -779433144: return bem_undef_1(bevd_0);
case 1913707401: return bem_outputReaderSet_1(bevd_0);
case 312688457: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -417583753: return bem_defined_1(bevd_0);
case -1274187353: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case 34267686: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 14292419: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 434478091: return bem_equals_1(bevd_0);
case -1728638213: return bem_otherClass_1(bevd_0);
case -461593490: return bem_copyTo_1(bevd_0);
case 994394248: return bem_commandSet_1(bevd_0);
case -888403607: return bem_sameObject_1(bevd_0);
case -1688597634: return bem_sameClass_1(bevd_0);
case 98957888: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 811659277: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -140724102: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 565033879: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1767747865: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2047096971: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 656540134: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1888103: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
}
