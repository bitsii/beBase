package be;
/* IO:File: source/extended/Command.be */
public final class BEC_2_6_7_SystemCommand extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_0 = {};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_1 = {0x20};
public static BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;

public static BET_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_2_9_4_ContainerList bevp_commands;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) throws Throwable {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_listNew_1(BEC_2_9_4_ContainerList beva__commands) throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevp_commands = beva__commands;
bevp_command = (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_0));
bevt_0_tmpany_loop = bevp_commands.bem_iteratorGet_0();
while (true)
 /* Line: 46 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1239585548);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 46 */ {
bevl_c = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1161084880);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(bevp_command);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_7_SystemCommand_bels_1));
bevp_command.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 48 */
bevp_command.bem_addValue_1(bevl_c);
} /* Line: 50 */
 else  /* Line: 46 */ {
break;
} /* Line: 46 */
} /* Line: 46 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bem_new_1(beva__command);
bevt_0_tmpany_phold = bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_3_MathInt bevl_cl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_cmdi = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (bevp_commands == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 89 */ {
bevl_cl = bevp_commands.bem_sizeGet_0();

        String[] cmds = new String[bevl_cl.bevi_int]; 
        bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 96 */ {
if (bevl_i.bevi_int < bevl_cl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevl_cmdi = (BEC_2_4_6_TextString) bevp_commands.bem_get_1(bevl_i);

          cmds[bevl_i.bevi_int] = bevl_cmdi.bems_toJvString();
          bevl_i.bevi_int++;
} /* Line: 96 */
 else  /* Line: 96 */ {
break;
} /* Line: 96 */
} /* Line: 96 */

        bevi_p = Runtime.getRuntime().exec(cmds);
        } /* Line: 105 */
 else  /* Line: 111 */ {

        bevi_p = Runtime.getRuntime().exec(bevp_command.bems_toJvString());
        } /* Line: 113 */
return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() throws Throwable {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 132 */ {
return bevp_outputReader;
} /* Line: 133 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.getInputStream();
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 151 */ {
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 154 */
} /* Line: 152 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 156 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() throws Throwable {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_outputContentGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_ee = null;
BEC_3_2_4_6_IOFileReader bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemCommand bevt_1_tmpany_phold = null;
try  /* Line: 175 */ {
bevt_1_tmpany_phold = bem_open_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_outputGet_0();
bevl_res = bevt_0_tmpany_phold.bem_readString_0();
bem_close_0();
} /* Line: 177 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
try  /* Line: 179 */ {
bem_close_0();
} /* Line: 180 */
 catch (Throwable beve_1) {
bevl_ee = (be.BECS_ThrowBack.handleThrow(beve_1));
} /* Line: 181 */
} /* Line: 181 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public final BEC_2_4_6_TextString bem_commandGetDirect_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGet_0() throws Throwable {
return bevp_commands;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_commandsGetDirect_0() throws Throwable {
return bevp_commands;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemCommand bem_commandsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public final BEC_3_2_4_6_IOFileReader bem_outputReaderGetDirect_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemCommand bem_outputReaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {37, 43, 45, 46, 0, 46, 46, 47, 47, 48, 48, 50, 55, 56, 56, 89, 89, 90, 96, 96, 96, 97, 96, 121, 125, 132, 132, 133, 135, 146, 147, 152, 152, 153, 154, 160, 176, 176, 176, 177, 180, 183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 29, 30, 31, 31, 34, 36, 37, 38, 40, 41, 43, 53, 54, 55, 72, 77, 78, 81, 84, 89, 90, 93, 106, 109, 114, 119, 120, 122, 125, 126, 132, 137, 138, 139, 148, 160, 161, 162, 163, 168, 174, 177, 180, 183, 187, 191, 194, 197, 201, 205, 208, 211, 215};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 37 19
assign 1 43 29
assign 1 45 30
new 0 45 30
assign 1 46 31
iteratorGet 0 0 31
assign 1 46 34
hasNextGet 0 46 34
assign 1 46 36
nextGet 0 46 36
assign 1 47 37
new 0 47 37
assign 1 47 38
notEmpty 1 47 38
assign 1 48 40
new 0 48 40
addValue 1 48 41
addValue 1 50 43
new 1 55 53
assign 1 56 54
run 0 56 54
return 1 56 55
assign 1 89 72
def 1 89 77
assign 1 90 78
sizeGet 0 90 78
assign 1 96 81
new 0 96 81
assign 1 96 84
lesser 1 96 89
assign 1 97 90
get 1 97 90
incrementValue 0 96 93
return 1 121 106
run 0 125 109
assign 1 132 114
def 1 132 119
return 1 133 120
assign 1 135 122
new 0 135 122
extOpen 0 146 125
return 1 147 126
assign 1 152 132
def 1 152 137
close 0 153 138
assign 1 154 139
closeOutput 0 160 148
assign 1 176 160
open 0 176 160
assign 1 176 161
outputGet 0 176 161
assign 1 176 162
readString 0 176 162
close 0 177 163
close 0 180 168
return 1 183 174
return 1 0 177
return 1 0 180
assign 1 0 183
assign 1 0 187
return 1 0 191
return 1 0 194
assign 1 0 197
assign 1 0 201
return 1 0 205
return 1 0 208
assign 1 0 211
assign 1 0 215
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1544637441: return bem_fieldIteratorGet_0();
case -916808790: return bem_serializeToString_0();
case -1440519528: return bem_new_0();
case 1516528362: return bem_copy_0();
case -352222734: return bem_echo_0();
case -1857169421: return bem_print_0();
case -1019129421: return bem_iteratorGet_0();
case 1256493526: return bem_create_0();
case 1966604989: return bem_deserializeClassNameGet_0();
case -796432226: return bem_close_0();
case 415444144: return bem_many_0();
case -849400166: return bem_closeOutput_0();
case 2093955214: return bem_open_0();
case 1977268733: return bem_toAny_0();
case 1640160430: return bem_serializationIteratorGet_0();
case -2042442149: return bem_run_0();
case 1665936268: return bem_outputGet_0();
case 188875213: return bem_commandsGet_0();
case -1810436946: return bem_outputReaderGet_0();
case 1138214557: return bem_commandsGetDirect_0();
case -1459660688: return bem_once_0();
case 764111846: return bem_classNameGet_0();
case 1458457396: return bem_outputReaderGetDirect_0();
case -2000107231: return bem_outputContentGet_0();
case -2027075098: return bem_sourceFileNameGet_0();
case 1464556610: return bem_serializeContents_0();
case 1764409231: return bem_commandGet_0();
case 647733846: return bem_hashGet_0();
case -1322750582: return bem_fieldNamesGet_0();
case 1211088551: return bem_commandGetDirect_0();
case 810516096: return bem_tagGet_0();
case -2042019182: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 81937219: return bem_listNew_1((BEC_2_9_4_ContainerList) bevd_0);
case 2019874046: return bem_commandsSetDirect_1(bevd_0);
case 1529930548: return bem_def_1(bevd_0);
case -1884560238: return bem_sameClass_1(bevd_0);
case -1726382580: return bem_undef_1(bevd_0);
case 604142168: return bem_commandsSet_1(bevd_0);
case -62499290: return bem_notEquals_1(bevd_0);
case 129664577: return bem_undefined_1(bevd_0);
case -2113151813: return bem_otherClass_1(bevd_0);
case 1686689499: return bem_sameType_1(bevd_0);
case 173437066: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 858949566: return bem_sameObject_1(bevd_0);
case -1103921791: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1897376518: return bem_commandSetDirect_1(bevd_0);
case 1303995883: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -635052720: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1066262854: return bem_copyTo_1(bevd_0);
case 456604916: return bem_defined_1(bevd_0);
case 63462813: return bem_outputReaderSetDirect_1(bevd_0);
case -2122782570: return bem_outputReaderSet_1(bevd_0);
case 42856182: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case 1149328783: return bem_equals_1(bevd_0);
case -1693595005: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 140294564: return bem_commandSet_1(bevd_0);
case -1451816788: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -840184945: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2113325337: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1732137967: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1058450326: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1752849240: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1337367239: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 572204899: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_type;
}
}
