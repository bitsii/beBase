package be;
/* IO:File: source/extended/Command.be */
public final class BEC_2_6_7_SystemCommand extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_0 = {};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_1 = {0x20};
public static BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;

public static BET_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_2_9_4_ContainerList bevp_commands;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) throws Throwable {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_listNew_1(BEC_2_9_4_ContainerList beva__commands) throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevp_commands = beva__commands;
bevp_command = (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_0));
bevt_0_ta_loop = bevp_commands.bem_iteratorGet_0();
while (true)
/* Line: 52*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-1866674687);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 52*/ {
bevl_c = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(619786720);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(bevp_command);
if (bevt_2_ta_ph.bevi_bool)/* Line: 53*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_7_SystemCommand_bels_1));
bevp_command.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 54*/
bevp_command.bem_addValue_1(bevl_c);
} /* Line: 56*/
 else /* Line: 52*/ {
break;
} /* Line: 52*/
} /* Line: 52*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bem_new_1(beva__command);
bevt_0_ta_ph = bem_run_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_cl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_cmdi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevp_commands == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 95*/ {
bevl_cl = bevp_commands.bem_lengthGet_0();

        String[] cmds = new String[bevl_cl.bevi_int]; 
        bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 102*/ {
if (bevl_i.bevi_int < bevl_cl.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 102*/ {
bevl_cmdi = (BEC_2_4_6_TextString) bevp_commands.bem_get_1(bevl_i);

          cmds[bevl_i.bevi_int] = bevl_cmdi.bems_toJvString();
          bevl_i.bevi_int++;
} /* Line: 102*/
 else /* Line: 102*/ {
break;
} /* Line: 102*/
} /* Line: 102*/

        bevi_p = Runtime.getRuntime().exec(cmds);
        } /* Line: 111*/
 else /* Line: 117*/ {

        bevi_p = Runtime.getRuntime().exec(bevp_command.bems_toJvString());
        } /* Line: 119*/
return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() throws Throwable {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_outputReader == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 138*/ {
return bevp_outputReader;
} /* Line: 139*/
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.getInputStream();
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
try /* Line: 157*/ {
if (bevp_outputReader == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 158*/ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 160*/
} /* Line: 158*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 162*/
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() throws Throwable {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_outputContentGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_ee = null;
BEC_3_2_4_6_IOFileReader bevt_0_ta_ph = null;
BEC_2_6_7_SystemCommand bevt_1_ta_ph = null;
try /* Line: 181*/ {
bevt_1_ta_ph = bem_open_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_outputGet_0();
bevl_res = bevt_0_ta_ph.bem_readString_0();
bem_close_0();
} /* Line: 183*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
try /* Line: 185*/ {
bem_close_0();
} /* Line: 186*/
 catch (Throwable beve_1) {
bevl_ee = (be.BECS_ThrowBack.handleThrow(beve_1));
} /* Line: 187*/
} /* Line: 187*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGet_0() throws Throwable {
return bevp_commands;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {43, 49, 51, 52, 0, 52, 52, 53, 53, 54, 54, 56, 61, 62, 62, 95, 95, 96, 102, 102, 102, 103, 102, 127, 131, 138, 138, 139, 141, 152, 153, 158, 158, 159, 160, 166, 182, 182, 182, 183, 186, 189, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 29, 30, 31, 31, 34, 36, 37, 38, 40, 41, 43, 53, 54, 55, 64, 69, 70, 73, 76, 81, 82, 85, 98, 101, 106, 111, 112, 114, 117, 118, 124, 129, 130, 131, 140, 152, 153, 154, 155, 160, 166, 169, 172, 176, 179, 183, 186};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 43 19
assign 1 49 29
assign 1 51 30
new 0 51 30
assign 1 52 31
iteratorGet 0 0 31
assign 1 52 34
hasNextGet 0 52 34
assign 1 52 36
nextGet 0 52 36
assign 1 53 37
new 0 53 37
assign 1 53 38
notEmpty 1 53 38
assign 1 54 40
new 0 54 40
addValue 1 54 41
addValue 1 56 43
new 1 61 53
assign 1 62 54
run 0 62 54
return 1 62 55
assign 1 95 64
def 1 95 69
assign 1 96 70
lengthGet 0 96 70
assign 1 102 73
new 0 102 73
assign 1 102 76
lesser 1 102 81
assign 1 103 82
get 1 103 82
incrementValue 0 102 85
return 1 127 98
run 0 131 101
assign 1 138 106
def 1 138 111
return 1 139 112
assign 1 141 114
new 0 141 114
extOpen 0 152 117
return 1 153 118
assign 1 158 124
def 1 158 129
close 0 159 130
assign 1 160 131
closeOutput 0 166 140
assign 1 182 152
open 0 182 152
assign 1 182 153
outputGet 0 182 153
assign 1 182 154
readString 0 182 154
close 0 183 155
close 0 186 160
return 1 189 166
return 1 0 169
assign 1 0 172
return 1 0 176
assign 1 0 179
return 1 0 183
assign 1 0 186
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1187859001: return bem_commandGet_0();
case -662844650: return bem_iteratorGet_0();
case 631790715: return bem_open_0();
case -2032740388: return bem_commandsGet_0();
case 1475185710: return bem_outputReaderGet_0();
case -2045168097: return bem_closeOutput_0();
case 2078046754: return bem_outputGet_0();
case -1141241291: return bem_copy_0();
case 1206052235: return bem_close_0();
case 1155069902: return bem_print_0();
case -734124326: return bem_outputContentGet_0();
case -1477018360: return bem_toString_0();
case 1379821961: return bem_create_0();
case 310309721: return bem_hashGet_0();
case -643243241: return bem_run_0();
case 1030336271: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1801291774: return bem_def_1(bevd_0);
case -273474418: return bem_commandsSet_1(bevd_0);
case 1738502576: return bem_copyTo_1(bevd_0);
case -2130006452: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case -1117209842: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 278034565: return bem_equals_1(bevd_0);
case -1176436455: return bem_print_1(bevd_0);
case -1861613035: return bem_listNew_1((BEC_2_9_4_ContainerList) bevd_0);
case 1075706066: return bem_undef_1(bevd_0);
case 1705970373: return bem_outputReaderSet_1(bevd_0);
case -1264563233: return bem_notEquals_1(bevd_0);
case 709176042: return bem_commandSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -844523032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1584274286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 752466488: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -880661396: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_type;
}
}
