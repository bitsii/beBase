package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_11_ContainerSetKeyIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_11_ContainerSetKeyIterator() { }
private static byte[] becc_BEC_3_9_3_11_ContainerSetKeyIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4B,0x65,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_11_ContainerSetKeyIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_11_ContainerSetKeyIterator bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst;

public static BET_3_9_3_11_ContainerSetKeyIterator bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_type;

public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tr = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_tr = super.bem_nextGet_0();
if (bevl_tr == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 489*/ {
bevt_1_ta_ph = bevl_tr.bemd_0(-656239110);
return bevt_1_ta_ph;
} /* Line: 490*/
return bevl_tr;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {488, 489, 489, 490, 490, 492};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 21, 22, 23, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 488 15
nextGet 0 488 15
assign 1 489 16
def 1 489 21
assign 1 490 22
keyGet 0 490 22
return 1 490 23
return 1 492 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1844269288: return bem_create_0();
case -125764532: return bem_containerGet_0();
case -430730425: return bem_nextGet_0();
case 1861855516: return bem_copy_0();
case 1031776864: return bem_hasNextGet_0();
case -1425898375: return bem_new_0();
case 1676715436: return bem_iteratorGet_0();
case -2042483961: return bem_toString_0();
case 2050464938: return bem_delete_0();
case 1736771156: return bem_nodeIteratorIteratorGet_0();
case 436863164: return bem_hashGet_0();
case -1757033570: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -272587445: return bem_notEquals_1(bevd_0);
case 324846295: return bem_def_1(bevd_0);
case 1306600423: return bem_equals_1(bevd_0);
case -371582843: return bem_copyTo_1(bevd_0);
case 2015800048: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1051624606: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1704989212: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1725892051: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1176905374: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1263166407: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_3_11_ContainerSetKeyIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_11_ContainerSetKeyIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_11_ContainerSetKeyIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst = (BEC_3_9_3_11_ContainerSetKeyIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_type;
}
}
