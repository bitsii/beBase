package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_11_ContainerSetKeyIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_11_ContainerSetKeyIterator() { }
private static byte[] becc_BEC_3_9_3_11_ContainerSetKeyIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4B,0x65,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_11_ContainerSetKeyIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_11_ContainerSetKeyIterator bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst;

public static BET_3_9_3_11_ContainerSetKeyIterator bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_type;

public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_tr = super.bem_nextGet_0();
if (bevl_tr == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 531 */ {
bevt_1_tmpany_phold = bevl_tr.bemd_0(1050444670);
return bevt_1_tmpany_phold;
} /* Line: 532 */
return bevl_tr;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {530, 531, 531, 532, 532, 534};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 21, 22, 23, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 530 15
nextGet 0 530 15
assign 1 531 16
def 1 531 21
assign 1 532 22
keyGet 0 532 22
return 1 532 23
return 1 534 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 373871049: return bem_copy_0();
case 368405588: return bem_echo_0();
case 218681458: return bem_containerGet_0();
case 37115722: return bem_toAny_0();
case 884758076: return bem_toString_0();
case -512173810: return bem_tagGet_0();
case 153421376: return bem_currentGetDirect_0();
case 1670681260: return bem_delete_0();
case 149300560: return bem_sourceFileNameGet_0();
case 144782273: return bem_once_0();
case 1712919396: return bem_serializationIteratorGet_0();
case -227431796: return bem_nodeIteratorIteratorGet_0();
case -451287241: return bem_iteratorGet_0();
case 1540410692: return bem_hasNextGet_0();
case 938978826: return bem_serializeContents_0();
case 2135450581: return bem_currentGet_0();
case -1060868541: return bem_slotsGet_0();
case 166156356: return bem_hashGet_0();
case 657440259: return bem_many_0();
case 367649330: return bem_nextGet_0();
case 1260713952: return bem_fieldNamesGet_0();
case -131396274: return bem_classNameGet_0();
case -499985400: return bem_slotsGetDirect_0();
case -1497736169: return bem_new_0();
case 1010970574: return bem_deserializeClassNameGet_0();
case 1012944178: return bem_create_0();
case -562898333: return bem_setGetDirect_0();
case -300279659: return bem_setGet_0();
case -2018704372: return bem_moduGetDirect_0();
case 652618710: return bem_print_0();
case 670883289: return bem_moduGet_0();
case -1360047774: return bem_serializeToString_0();
case -794542805: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1941022132: return bem_setSet_1(bevd_0);
case -1651139344: return bem_moduSet_1(bevd_0);
case -1849842647: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1450913634: return bem_defined_1(bevd_0);
case -2033993347: return bem_sameObject_1(bevd_0);
case 1809071188: return bem_currentSet_1(bevd_0);
case 46811792: return bem_otherType_1(bevd_0);
case 2044588239: return bem_otherClass_1(bevd_0);
case 773892154: return bem_sameClass_1(bevd_0);
case 974930963: return bem_undefined_1(bevd_0);
case -926157429: return bem_equals_1(bevd_0);
case -1418198617: return bem_def_1(bevd_0);
case 298108366: return bem_setSetDirect_1(bevd_0);
case 1364259760: return bem_slotsSet_1(bevd_0);
case -1434589659: return bem_undef_1(bevd_0);
case -865257787: return bem_moduSetDirect_1(bevd_0);
case 1184632884: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1691038775: return bem_notEquals_1(bevd_0);
case -1340973491: return bem_sameType_1(bevd_0);
case -1100756134: return bem_slotsSetDirect_1(bevd_0);
case -367147919: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1952204646: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -442448216: return bem_copyTo_1(bevd_0);
case -2046322567: return bem_currentSetDirect_1(bevd_0);
case -675060011: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -330880231: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1368517810: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1351268593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1842958248: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 840782676: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 498622947: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1807714621: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_3_11_ContainerSetKeyIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_11_ContainerSetKeyIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_11_ContainerSetKeyIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst = (BEC_3_9_3_11_ContainerSetKeyIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_type;
}
}
