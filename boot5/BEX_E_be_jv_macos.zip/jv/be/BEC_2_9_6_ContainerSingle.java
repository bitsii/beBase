package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_6_ContainerSingle extends BEC_2_6_6_SystemObject {
public BEC_2_9_6_ContainerSingle() { }
private static byte[] becc_BEC_2_9_6_ContainerSingle_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x69,0x6E,0x67,0x6C,0x65};
private static byte[] becc_BEC_2_9_6_ContainerSingle_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_6_ContainerSingle bece_BEC_2_9_6_ContainerSingle_bevs_inst;

public static BET_2_9_6_ContainerSingle bece_BEC_2_9_6_ContainerSingle_bevs_type;

public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_6_ContainerSingle bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_6_ContainerSingle bem_new_1(BEC_2_6_6_SystemObject beva__first) throws Throwable {
bevp_first = beva__first;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_firstGetDirect_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_9_6_ContainerSingle bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_6_ContainerSingle bem_firstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 20, 23, 26, 30};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 16
return 1 0 20
return 1 0 23
assign 1 0 26
assign 1 0 30
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -907702096: return bem_once_0();
case 1159622845: return bem_echo_0();
case -649199060: return bem_serializeContents_0();
case 1294757574: return bem_tagGet_0();
case 1097464934: return bem_print_0();
case -730552231: return bem_fieldIteratorGet_0();
case 1521004371: return bem_copy_0();
case -2010885181: return bem_many_0();
case 268640521: return bem_hashGet_0();
case 1448363529: return bem_firstGet_0();
case -2060917023: return bem_classNameGet_0();
case -843126344: return bem_serializationIteratorGet_0();
case 84009197: return bem_deserializeClassNameGet_0();
case 1892998488: return bem_firstGetDirect_0();
case -1333696208: return bem_toString_0();
case 831513957: return bem_iteratorGet_0();
case 1523724038: return bem_sourceFileNameGet_0();
case 885128203: return bem_create_0();
case 2057652625: return bem_fieldNamesGet_0();
case 1121605448: return bem_serializeToString_0();
case 2143550869: return bem_new_0();
case 444413474: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1863207166: return bem_def_1(bevd_0);
case -1114550651: return bem_undefined_1(bevd_0);
case -2022043756: return bem_firstSet_1(bevd_0);
case -1035577062: return bem_equals_1(bevd_0);
case 899961531: return bem_new_1(bevd_0);
case -351226620: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1417473277: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -933911215: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1776510589: return bem_copyTo_1(bevd_0);
case 2123468926: return bem_sameObject_1(bevd_0);
case 775033796: return bem_sameClass_1(bevd_0);
case 544363262: return bem_otherClass_1(bevd_0);
case 459298083: return bem_otherType_1(bevd_0);
case 1189274855: return bem_sameType_1(bevd_0);
case 1719411527: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 171056025: return bem_defined_1(bevd_0);
case -839680850: return bem_undef_1(bevd_0);
case -571354968: return bem_notEquals_1(bevd_0);
case 2035017503: return bem_firstSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 661608167: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 319580096: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -111616333: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -87616259: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 710208868: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 520958435: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -842656681: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_9_6_ContainerSingle_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_6_ContainerSingle_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_6_ContainerSingle();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_inst = (BEC_2_9_6_ContainerSingle) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_type;
}
}
