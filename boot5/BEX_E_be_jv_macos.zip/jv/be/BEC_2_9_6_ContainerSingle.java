package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_6_ContainerSingle extends BEC_2_6_6_SystemObject {
public BEC_2_9_6_ContainerSingle() { }
private static byte[] becc_BEC_2_9_6_ContainerSingle_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x69,0x6E,0x67,0x6C,0x65};
private static byte[] becc_BEC_2_9_6_ContainerSingle_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_6_ContainerSingle bece_BEC_2_9_6_ContainerSingle_bevs_inst;

public static BET_2_9_6_ContainerSingle bece_BEC_2_9_6_ContainerSingle_bevs_type;

public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_6_ContainerSingle bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_6_ContainerSingle bem_new_1(BEC_2_6_6_SystemObject beva__first) throws Throwable {
bevp_first = beva__first;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_firstGetDirect_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_9_6_ContainerSingle bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_6_ContainerSingle bem_firstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {19, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 20, 23, 26, 30};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 19 16
return 1 0 20
return 1 0 23
assign 1 0 26
assign 1 0 30
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 647733846: return bem_hashGet_0();
case 1977268733: return bem_toAny_0();
case -1019129421: return bem_iteratorGet_0();
case 1966604989: return bem_deserializeClassNameGet_0();
case 415444144: return bem_many_0();
case -1322750582: return bem_fieldNamesGet_0();
case -1459660688: return bem_once_0();
case 1464556610: return bem_serializeContents_0();
case 810516096: return bem_tagGet_0();
case 1516528362: return bem_copy_0();
case -1440519528: return bem_new_0();
case 1544637441: return bem_fieldIteratorGet_0();
case 764111846: return bem_classNameGet_0();
case -2027075098: return bem_sourceFileNameGet_0();
case 1640160430: return bem_serializationIteratorGet_0();
case 1256493526: return bem_create_0();
case -1870984500: return bem_firstGetDirect_0();
case -352222734: return bem_echo_0();
case -2042019182: return bem_toString_0();
case -1857169421: return bem_print_0();
case -916808790: return bem_serializeToString_0();
case -1967138775: return bem_firstGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1529930548: return bem_def_1(bevd_0);
case -1884560238: return bem_sameClass_1(bevd_0);
case -1726382580: return bem_undef_1(bevd_0);
case -62499290: return bem_notEquals_1(bevd_0);
case 129664577: return bem_undefined_1(bevd_0);
case -2113151813: return bem_otherClass_1(bevd_0);
case 1686689499: return bem_sameType_1(bevd_0);
case 173437066: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 858949566: return bem_sameObject_1(bevd_0);
case -1103921791: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1303995883: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1026712353: return bem_firstSet_1(bevd_0);
case -635052720: return bem_new_1(bevd_0);
case -1066262854: return bem_copyTo_1(bevd_0);
case 456604916: return bem_defined_1(bevd_0);
case 1149328783: return bem_equals_1(bevd_0);
case -1693595005: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1451816788: return bem_otherType_1(bevd_0);
case -682037489: return bem_firstSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -840184945: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2113325337: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1732137967: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1058450326: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1752849240: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1337367239: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 572204899: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_9_6_ContainerSingle_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_6_ContainerSingle_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_6_ContainerSingle();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_inst = (BEC_2_9_6_ContainerSingle) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_type;
}
}
