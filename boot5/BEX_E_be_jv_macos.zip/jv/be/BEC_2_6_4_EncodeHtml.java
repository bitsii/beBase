package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_EncodeHtml extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_EncodeHtml() { }
private static byte[] becc_BEC_2_6_4_EncodeHtml_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x74,0x6D,0x6C};
private static byte[] becc_BEC_2_6_4_EncodeHtml_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_4_EncodeHtml_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_4_EncodeHtml_bevo_1 = (new BEC_2_4_3_MathInt(127));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_0 = {0x22};
private static BEC_2_4_6_TextString bece_BEC_2_6_4_EncodeHtml_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_4_EncodeHtml_bels_0, 1));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_1 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_6_4_EncodeHtml_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_4_EncodeHtml_bels_1, 1));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_2 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_6_4_EncodeHtml_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_4_EncodeHtml_bels_2, 1));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_3 = {0x26};
private static BEC_2_4_6_TextString bece_BEC_2_6_4_EncodeHtml_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_4_EncodeHtml_bels_3, 1));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_4 = {0x26,0x23};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_5 = {0x3B};
public static BEC_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_inst;
public BEC_2_6_4_EncodeHtml bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_EncodeHtml bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_6_tmpany_phold = bece_BEC_2_6_4_EncodeHtml_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_tmpany_phold);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_7_tmpany_phold);
while (true)
 /* Line: 186 */ {
bevt_8_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_9_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_4_EncodeHtml_bevo_1;
if (bevl_ac.bevi_int > bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_13_tmpany_phold = bece_BEC_2_6_4_EncodeHtml_bevo_2;
bevt_12_tmpany_phold = bevl_pt.bem_equals_1(bevt_13_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 189 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_4_EncodeHtml_bevo_3;
bevt_14_tmpany_phold = bevl_pt.bem_equals_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 189 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_17_tmpany_phold = bece_BEC_2_6_4_EncodeHtml_bevo_4;
bevt_16_tmpany_phold = bevl_pt.bem_equals_1(bevt_17_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 189 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_4_EncodeHtml_bevo_5;
bevt_18_tmpany_phold = bevl_pt.bem_equals_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 189 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_4_EncodeHtml_bels_4));
bevl_r.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = bevl_ac.bem_toString_0();
bevl_r.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_5));
bevl_r.bem_addValue_1(bevt_22_tmpany_phold);
} /* Line: 192 */
 else  /* Line: 193 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 194 */
} /* Line: 189 */
 else  /* Line: 186 */ {
break;
} /* Line: 186 */
} /* Line: 186 */
return bevl_r;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {183, 183, 183, 183, 184, 185, 185, 186, 187, 188, 188, 189, 189, 189, 0, 189, 189, 0, 0, 0, 189, 189, 0, 0, 0, 189, 189, 0, 0, 0, 189, 189, 0, 0, 190, 190, 191, 191, 192, 192, 194, 197};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {56, 57, 58, 59, 60, 61, 62, 65, 67, 68, 69, 70, 71, 76, 77, 80, 81, 83, 86, 90, 93, 94, 96, 99, 103, 106, 107, 109, 112, 116, 119, 120, 122, 125, 129, 130, 131, 132, 133, 134, 137, 144};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 183 56
sizeGet 0 183 56
assign 1 183 57
new 0 183 57
assign 1 183 58
multiply 1 183 58
assign 1 183 59
new 1 183 59
assign 1 184 60
new 1 184 60
assign 1 185 61
new 0 185 61
assign 1 185 62
new 1 185 62
assign 1 186 65
hasNextGet 0 186 65
next 1 187 67
assign 1 188 68
new 0 188 68
assign 1 188 69
getCode 1 188 69
assign 1 189 70
new 0 189 70
assign 1 189 71
greater 1 189 76
assign 1 0 77
assign 1 189 80
new 0 189 80
assign 1 189 81
equals 1 189 81
assign 1 0 83
assign 1 0 86
assign 1 0 90
assign 1 189 93
new 0 189 93
assign 1 189 94
equals 1 189 94
assign 1 0 96
assign 1 0 99
assign 1 0 103
assign 1 189 106
new 0 189 106
assign 1 189 107
equals 1 189 107
assign 1 0 109
assign 1 0 112
assign 1 0 116
assign 1 189 119
new 0 189 119
assign 1 189 120
equals 1 189 120
assign 1 0 122
assign 1 0 125
assign 1 190 129
new 0 190 129
addValue 1 190 130
assign 1 191 131
toString 0 191 131
addValue 1 191 132
assign 1 192 133
new 0 192 133
addValue 1 192 134
addValue 1 194 137
return 1 197 144
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -302965453: return bem_tagGet_0();
case 301206433: return bem_echo_0();
case 1452879382: return bem_sourceFileNameGet_0();
case 1732876397: return bem_serializationIteratorGet_0();
case -803388239: return bem_deserializeClassNameGet_0();
case 737771364: return bem_toString_0();
case -1980796873: return bem_copy_0();
case -364483975: return bem_default_0();
case 366164054: return bem_serializeContents_0();
case 997723391: return bem_iteratorGet_0();
case 1023783415: return bem_create_0();
case 2033657832: return bem_hashGet_0();
case 737353003: return bem_new_0();
case -420235024: return bem_classNameGet_0();
case 482356666: return bem_toAny_0();
case 1222310146: return bem_many_0();
case -1866917929: return bem_serializeToString_0();
case 1314576819: return bem_print_0();
case 1775715094: return bem_once_0();
case -70500062: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1732568943: return bem_sameObject_1(bevd_0);
case 1732014863: return bem_equals_1(bevd_0);
case -369272378: return bem_undefined_1(bevd_0);
case 1452810576: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 808158717: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1112750632: return bem_otherType_1(bevd_0);
case 228693515: return bem_notEquals_1(bevd_0);
case 254712574: return bem_def_1(bevd_0);
case 1210677960: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1107846755: return bem_otherClass_1(bevd_0);
case 1735205112: return bem_sameType_1(bevd_0);
case -10325606: return bem_undef_1(bevd_0);
case 235706821: return bem_defined_1(bevd_0);
case -1078688343: return bem_copyTo_1(bevd_0);
case 1940225088: return bem_sameClass_1(bevd_0);
case 1235111255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 583536207: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1747848637: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1990568085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1437812444: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -303274357: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815656517: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -70659423: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -164742720: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_EncodeHtml_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_4_EncodeHtml_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_EncodeHtml();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst = (BEC_2_6_4_EncodeHtml) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst;
}
}
