package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static byte[] bels_1 = {0x0D,0x0A};
private static byte[] bels_2 = {0x0A};
private static byte[] bels_3 = {0x0A};
private static byte[] bels_4 = {0x3A};
private static byte[] bels_5 = {};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_6 = {};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_6, 0));
public static BEC_2_4_7_TextStrings bevs_inst;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevp_space = (new BEC_2_4_6_TextString(1, bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpany_phold);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bels_2));
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpany_phold);
bevp_lf = (new BEC_2_4_6_TextString(1, bels_3));
bevp_colon = (new BEC_2_4_6_TextString(1, bels_4));
bevp_lineSplitter = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_splits.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
bevt_1_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 1113 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpany_phold;
} /* Line: 1114 */
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpany_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_3_tmpany_phold);
while (true)
 /* Line: 1118 */ {
bevt_4_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 1118 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpany_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 1120 */
 else  /* Line: 1118 */ {
break;
} /* Line: 1118 */
} /* Line: 1118 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1130 */ {
bevt_0_tmpany_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1130 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpany_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1132 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1133 */ {
bevl_end.bevi_int++;
} /* Line: 1134 */
 else  /* Line: 1135 */ {
bevl_beg.bevi_int++;
} /* Line: 1136 */
} /* Line: 1133 */
 else  /* Line: 1138 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1140 */
} /* Line: 1132 */
 else  /* Line: 1130 */ {
break;
} /* Line: 1130 */
} /* Line: 1130 */
if (bevl_foundChar.bevi_bool) /* Line: 1143 */ {
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_tmpany_phold);
} /* Line: 1144 */
 else  /* Line: 1145 */ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bels_5));
} /* Line: 1146 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1152 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1152 */ {
if (beva_b == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1152 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1152 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1152 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1152 */ {
return null;
} /* Line: 1152 */
bevt_3_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bevs_inst;
bevt_4_tmpany_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpany_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_min_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1158 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1158 */ {
bevl_ai.bemd_1(-1048795675, BEL_4_Base.bevn_next_1, bevl_av);
bevl_bi.bemd_1(-1048795675, BEL_4_Base.bevn_next_1, bevl_bv);
bevt_7_tmpany_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1161 */ {
bevt_9_tmpany_phold = bevo_0;
bevt_8_tmpany_phold = beva_a.bem_substring_2(bevt_9_tmpany_phold, bevl_i);
return bevt_8_tmpany_phold;
} /* Line: 1162 */
bevl_i.bevi_int++;
} /* Line: 1158 */
 else  /* Line: 1158 */ {
break;
} /* Line: 1158 */
} /* Line: 1158 */
bevt_11_tmpany_phold = bevo_1;
bevt_10_tmpany_phold = beva_a.bem_substring_2(bevt_11_tmpany_phold, bevl_i);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevt_0_tmpany_loop = beva_strs.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 1169 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 1169 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpany_phold = this.bem_isEmpty_1(bevl_i);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1170 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 1171 */
} /* Line: 1170 */
 else  /* Line: 1169 */ {
break;
} /* Line: 1169 */
} /* Line: 1169 */
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1178 */ {
bevt_3_tmpany_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpany_phold = bevo_2;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1178 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1178 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 1179 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1185 */ {
bevt_3_tmpany_phold = bevo_3;
bevt_2_tmpany_phold = beva_value.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1185 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1185 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1185 */
 else  /* Line: 1185 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1185 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 1186 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1087, 1088, 1089, 1089, 1090, 1090, 1091, 1092, 1094, 1094, 1095, 1096, 1097, 1098, 1101, 1102, 1103, 1104, 1108, 1108, 1112, 1113, 1113, 1114, 1114, 1116, 1117, 1117, 1118, 1119, 1120, 1120, 1122, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1134, 1136, 1139, 1139, 1140, 1144, 1144, 1144, 1146, 1148, 1152, 1152, 0, 1152, 1152, 0, 0, 1152, 1153, 1153, 1153, 1153, 1154, 1155, 1156, 1157, 1158, 1158, 1158, 1159, 1160, 1161, 1162, 1162, 1162, 1158, 1165, 1165, 1165, 1169, 0, 1169, 1169, 1170, 1171, 1171, 1174, 1174, 1178, 1178, 0, 1178, 1178, 1178, 1178, 0, 0, 1179, 1179, 1181, 1181, 1185, 1185, 1185, 1185, 0, 0, 0, 1186, 1186, 1188, 1188, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 60, 61, 72, 73, 74, 76, 77, 79, 80, 81, 84, 86, 87, 88, 94, 108, 109, 110, 111, 114, 116, 117, 120, 123, 127, 128, 129, 137, 138, 139, 142, 144, 165, 170, 171, 174, 179, 180, 183, 187, 189, 190, 191, 192, 193, 194, 195, 196, 197, 200, 205, 206, 207, 208, 210, 211, 212, 214, 220, 221, 222, 231, 231, 234, 236, 237, 239, 240, 247, 248, 258, 263, 264, 267, 268, 269, 274, 275, 278, 282, 283, 285, 286, 295, 300, 301, 302, 304, 307, 311, 314, 315, 317, 318, 321, 324, 328, 331, 335, 338, 342, 345, 349, 352, 356, 359, 363, 366, 370, 373, 377, 380, 384, 387, 391, 394, 398, 401};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1087 38
new 0 1087 38
assign 1 1088 39
new 0 1088 39
assign 1 1089 40
new 0 1089 40
assign 1 1089 41
codeNew 1 1089 41
assign 1 1090 42
new 0 1090 42
assign 1 1090 43
codeNew 1 1090 43
assign 1 1091 44
new 0 1091 44
assign 1 1092 45
new 0 1092 45
assign 1 1094 46
new 0 1094 46
assign 1 1094 47
codeNew 1 1094 47
assign 1 1095 48
new 0 1095 48
assign 1 1096 49
new 0 1096 49
assign 1 1097 50
new 1 1097 50
assign 1 1098 51
new 0 1098 51
put 1 1101 52
put 1 1102 53
put 1 1103 54
put 1 1104 55
assign 1 1108 60
joinBuffer 2 1108 60
return 1 1108 61
assign 1 1112 72
iteratorGet 0 1112 72
assign 1 1113 73
hasNextGet 0 1113 73
assign 1 1113 74
not 0 1113 74
assign 1 1114 76
new 0 1114 76
return 1 1114 77
assign 1 1116 79
new 0 1116 79
assign 1 1117 80
nextGet 0 1117 80
addValue 1 1117 81
assign 1 1118 84
hasNextGet 0 1118 84
addValue 1 1119 86
assign 1 1120 87
nextGet 0 1120 87
addValue 1 1120 88
return 1 1122 94
assign 1 1126 108
new 0 1126 108
assign 1 1127 109
new 0 1127 109
assign 1 1128 110
new 0 1128 110
assign 1 1129 111
mbiterGet 0 1129 111
assign 1 1130 114
hasNextGet 0 1130 114
assign 1 1131 116
nextGet 0 1131 116
assign 1 1132 117
has 1 1132 117
incrementValue 0 1134 120
incrementValue 0 1136 123
assign 1 1139 127
new 0 1139 127
setValue 1 1139 128
assign 1 1140 129
new 0 1140 129
assign 1 1144 137
sizeGet 0 1144 137
assign 1 1144 138
subtract 1 1144 138
assign 1 1144 139
substring 2 1144 139
assign 1 1146 142
new 0 1146 142
return 1 1148 144
assign 1 1152 165
undef 1 1152 170
assign 1 0 171
assign 1 1152 174
undef 1 1152 179
assign 1 0 180
assign 1 0 183
return 1 1152 187
assign 1 1153 189
new 0 1153 189
assign 1 1153 190
sizeGet 0 1153 190
assign 1 1153 191
sizeGet 0 1153 191
assign 1 1153 192
min 2 1153 192
assign 1 1154 193
biterGet 0 1154 193
assign 1 1155 194
biterGet 0 1155 194
assign 1 1156 195
new 0 1156 195
assign 1 1157 196
new 0 1157 196
assign 1 1158 197
new 0 1158 197
assign 1 1158 200
lesser 1 1158 205
next 1 1159 206
next 1 1160 207
assign 1 1161 208
notEquals 1 1161 208
assign 1 1162 210
new 0 1162 210
assign 1 1162 211
substring 2 1162 211
return 1 1162 212
incrementValue 0 1158 214
assign 1 1165 220
new 0 1165 220
assign 1 1165 221
substring 2 1165 221
return 1 1165 222
assign 1 1169 231
iteratorGet 0 0 231
assign 1 1169 234
hasNextGet 0 1169 234
assign 1 1169 236
nextGet 0 1169 236
assign 1 1170 237
isEmpty 1 1170 237
assign 1 1171 239
new 0 1171 239
return 1 1171 240
assign 1 1174 247
new 0 1174 247
return 1 1174 248
assign 1 1178 258
undef 1 1178 263
assign 1 0 264
assign 1 1178 267
sizeGet 0 1178 267
assign 1 1178 268
new 0 1178 268
assign 1 1178 269
lesser 1 1178 274
assign 1 0 275
assign 1 0 278
assign 1 1179 282
new 0 1179 282
return 1 1179 283
assign 1 1181 285
new 0 1181 285
return 1 1181 286
assign 1 1185 295
def 1 1185 300
assign 1 1185 301
new 0 1185 301
assign 1 1185 302
notEquals 1 1185 302
assign 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 1186 314
new 0 1186 314
return 1 1186 315
assign 1 1188 317
new 0 1188 317
return 1 1188 318
return 1 0 321
assign 1 0 324
return 1 0 328
assign 1 0 331
return 1 0 335
assign 1 0 338
return 1 0 342
assign 1 0 345
return 1 0 349
assign 1 0 352
return 1 0 356
assign 1 0 359
return 1 0 363
assign 1 0 366
return 1 0 370
assign 1 0 373
return 1 0 377
assign 1 0 380
return 1 0 384
assign 1 0 387
return 1 0 391
assign 1 0 394
return 1 0 398
assign 1 0 401
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 482013217: return bem_spaceGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -1081741254: return bem_emptyGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 1259904107: return bem_quoteGet_0();
case -1502128718: return bem_default_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1708371387: return bem_dosNewlineGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1599801355: return bem_wsGet_0();
case 55016493: return bem_lfGet_0();
case -929570062: return bem_tabGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 776765523: return bem_newlineGet_0();
case 1000967768: return bem_crGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1152565608: return bem_colonGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -527120532: return bem_lineSplitterGet_0();
case -1354714650: return bem_copy_0();
case 1567400443: return bem_unixNewlineGet_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1270986360: return bem_quoteSet_1(bevd_0);
case 1719453640: return bem_dosNewlineSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -516038279: return bem_lineSplitterSet_1(bevd_0);
case 1629015603: return bem_anyEmpty_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1012050021: return bem_crSet_1(bevd_0);
case 66098746: return bem_lfSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1437735788: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 493095470: return bem_spaceSet_1(bevd_0);
case -918487809: return bem_tabSet_1(bevd_0);
case 1578482696: return bem_unixNewlineSet_1(bevd_0);
case 1610883608: return bem_wsSet_1(bevd_0);
case 2091366709: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1070659001: return bem_emptySet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1163647861: return bem_colonSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1881757494: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1154529699: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -941304624: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1331758909: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bevs_inst = (BEC_2_4_7_TextStrings)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bevs_inst;
}
}
