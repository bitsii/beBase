package be;
/* IO:File: source/build/EmitData.be */
public final class BEC_2_5_8_BuildEmitData extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildEmitData() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static BEC_2_5_8_BuildEmitData bevs_inst;
public BEC_2_9_3_ContainerMap bevp_ptsp;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_9_3_ContainerMap bevp_nameEntries;
public BEC_2_9_3_ContainerMap bevp_classes;
public BEC_2_9_10_ContainerLinkedList bevp_parseOrderClassNames;
public BEC_2_9_3_ContainerMap bevp_justParsed;
public BEC_2_9_3_ContainerMap bevp_synClasses;
public BEC_2_9_3_ContainerMap bevp_midNames;
public BEC_2_9_3_ContainerMap bevp_usedBy;
public BEC_2_9_3_ContainerMap bevp_subClasses;
public BEC_2_9_3_ContainerSet bevp_propertyIndexes;
public BEC_2_9_3_ContainerSet bevp_methodIndexes;
public BEC_2_9_3_ContainerSet bevp_shouldEmit;
public BEC_2_9_3_ContainerMap bevp_aliased;
public BEC_2_5_8_BuildEmitData bem_new_0() throws Throwable {
bevp_ptsp = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_nameEntries = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parseOrderClassNames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_justParsed = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_synClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_midNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_usedBy = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_subClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_propertyIndexes = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_methodIndexes = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_aliased = (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addSynClass_2(BEC_2_4_6_TextString beva_npstr, BEC_2_5_8_BuildClassSyn beva_syn) throws Throwable {
BEC_2_4_6_TextString bevl_myname = null;
BEC_2_4_6_TextString bevl_s = null;
BEC_2_9_3_ContainerSet bevl_ub = null;
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_8_BuildNamePath bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevp_synClasses.bem_put_2(beva_npstr, beva_syn);
bevt_1_tmpany_phold = beva_syn.bem_namepathGet_0();
bevl_myname = bevt_1_tmpany_phold.bem_toString_0();
bevt_2_tmpany_phold = beva_syn.bem_usesGet_0();
bevt_0_tmpany_loop = bevt_2_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 44 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 44 */ {
bevl_s = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_usedBy.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevl_ub = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_usedBy.bem_put_2(bevl_s, bevl_ub);
} /* Line: 48 */
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 50 */
 else  /* Line: 44 */ {
break;
} /* Line: 44 */
} /* Line: 44 */
bevt_5_tmpany_phold = beva_syn.bem_superListGet_0();
bevl_iu = bevt_5_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 52 */ {
bevt_6_tmpany_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 52 */ {
bevt_7_tmpany_phold = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_s = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_subClasses.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevl_ub = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_subClasses.bem_put_2(bevl_s, bevl_ub);
} /* Line: 57 */
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 59 */
 else  /* Line: 52 */ {
break;
} /* Line: 52 */
} /* Line: 52 */
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addParsedClass_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_1_tmpany_phold = bevp_classes.bem_has_1(bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 64 */ {
bevt_5_tmpany_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_parseOrderClassNames.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 65 */
bevt_7_tmpany_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_classes.bem_put_2(bevt_6_tmpany_phold, beva_node);
bevt_9_tmpany_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_justParsed.bem_put_2(bevt_8_tmpany_phold, beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGet_0() throws Throwable {
return bevp_ptsp;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGet_0() throws Throwable {
return bevp_nameEntries;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGet_0() throws Throwable {
return bevp_classes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGet_0() throws Throwable {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGet_0() throws Throwable {
return bevp_justParsed;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGet_0() throws Throwable {
return bevp_synClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGet_0() throws Throwable {
return bevp_midNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGet_0() throws Throwable {
return bevp_usedBy;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGet_0() throws Throwable {
return bevp_subClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGet_0() throws Throwable {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGet_0() throws Throwable {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGet_0() throws Throwable {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() throws Throwable {
return bevp_aliased;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 34, 35, 36, 37, 42, 43, 43, 44, 44, 0, 44, 44, 45, 46, 46, 47, 48, 50, 52, 52, 52, 53, 53, 54, 55, 55, 56, 57, 59, 64, 64, 64, 64, 64, 65, 65, 65, 67, 67, 67, 68, 68, 68, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 55, 56, 57, 58, 59, 59, 62, 64, 65, 66, 71, 72, 73, 75, 81, 82, 85, 87, 88, 89, 90, 95, 96, 97, 99, 118, 119, 120, 121, 126, 127, 128, 129, 131, 132, 133, 134, 135, 136, 140, 143, 147, 150, 154, 157, 161, 164, 168, 171, 175, 178, 182, 185, 189, 192, 196, 199, 203, 206, 210, 213, 217, 220, 224, 227, 231, 234, 238, 241};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 21 24
new 0 21 24
assign 1 22 25
new 0 22 25
assign 1 23 26
new 0 23 26
assign 1 24 27
new 0 24 27
assign 1 25 28
new 0 25 28
assign 1 26 29
new 0 26 29
assign 1 27 30
new 0 27 30
assign 1 28 31
new 0 28 31
assign 1 29 32
new 0 29 32
assign 1 31 33
new 0 31 33
assign 1 33 34
new 0 33 34
assign 1 34 35
new 0 34 35
assign 1 35 36
new 0 35 36
assign 1 36 37
new 0 36 37
assign 1 37 38
new 0 37 38
put 2 42 55
assign 1 43 56
namepathGet 0 43 56
assign 1 43 57
toString 0 43 57
assign 1 44 58
usesGet 0 44 58
assign 1 44 59
iteratorGet 0 0 59
assign 1 44 62
hasNextGet 0 44 62
assign 1 44 64
nextGet 0 44 64
assign 1 45 65
get 1 45 65
assign 1 46 66
undef 1 46 71
assign 1 47 72
new 0 47 72
put 2 48 73
put 1 50 75
assign 1 52 81
superListGet 0 52 81
assign 1 52 82
iteratorGet 0 52 82
assign 1 52 85
hasNextGet 0 52 85
assign 1 53 87
nextGet 0 53 87
assign 1 53 88
toString 0 53 88
assign 1 54 89
get 1 54 89
assign 1 55 90
undef 1 55 95
assign 1 56 96
new 0 56 96
put 2 57 97
put 1 59 99
assign 1 64 118
heldGet 0 64 118
assign 1 64 119
nameGet 0 64 119
assign 1 64 120
has 1 64 120
assign 1 64 121
not 0 64 126
assign 1 65 127
heldGet 0 65 127
assign 1 65 128
nameGet 0 65 128
addValue 1 65 129
assign 1 67 131
heldGet 0 67 131
assign 1 67 132
nameGet 0 67 132
put 2 67 133
assign 1 68 134
heldGet 0 68 134
assign 1 68 135
nameGet 0 68 135
put 2 68 136
return 1 0 140
assign 1 0 143
return 1 0 147
assign 1 0 150
return 1 0 154
assign 1 0 157
return 1 0 161
assign 1 0 164
return 1 0 168
assign 1 0 171
return 1 0 175
assign 1 0 178
return 1 0 182
assign 1 0 185
return 1 0 189
assign 1 0 192
return 1 0 196
assign 1 0 199
return 1 0 203
assign 1 0 206
return 1 0 210
assign 1 0 213
return 1 0 217
assign 1 0 220
return 1 0 224
assign 1 0 227
return 1 0 231
assign 1 0 234
return 1 0 238
assign 1 0 241
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1175592193: return bem_classesGet_0();
case 1163811074: return bem_nameEntriesGet_0();
case -314718434: return bem_print_0();
case -444099364: return bem_parseOrderClassNamesGet_0();
case 1102720804: return bem_classNameGet_0();
case 1989965478: return bem_ptspGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 905170785: return bem_subClassesGet_0();
case -729571811: return bem_serializeToString_0();
case -113008932: return bem_propertyIndexesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1631955979: return bem_foreignClassesGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -342932503: return bem_synClassesGet_0();
case 1385290712: return bem_aliasedGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -311680096: return bem_allNamesGet_0();
case 1565911943: return bem_midNamesGet_0();
case 1712356202: return bem_justParsedGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case 1382460659: return bem_usedByGet_0();
case -955555864: return bem_methodIndexesGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
case -106869503: return bem_shouldEmitGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -331850250: return bem_synClassesSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1186674446: return bem_classesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -944473611: return bem_methodIndexesSet_1(bevd_0);
case -101926679: return bem_propertyIndexesSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -300597843: return bem_allNamesSet_1(bevd_0);
case -433017111: return bem_parseOrderClassNamesSet_1(bevd_0);
case -1620873726: return bem_foreignClassesSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1174893327: return bem_nameEntriesSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1723438455: return bem_justParsedSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -205286728: return bem_addParsedClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1396372965: return bem_aliasedSet_1(bevd_0);
case 916253038: return bem_subClassesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1576994196: return bem_midNamesSet_1(bevd_0);
case 2001047731: return bem_ptspSet_1(bevd_0);
case -95787250: return bem_shouldEmitSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1393542912: return bem_usedBySet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 191045316: return bem_addSynClass_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_8_BuildClassSyn) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildEmitData();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildEmitData.bevs_inst = (BEC_2_5_8_BuildEmitData)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildEmitData.bevs_inst;
}
}
