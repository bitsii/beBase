package be;
/* IO:File: source/build/Pass7.be */
public final class BEC_3_5_5_5_BuildVisitPass7 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x65,0x77};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_4 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_5 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_6 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_7 = {0x74,0x72,0x75,0x65};
private static byte[] bels_8 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_9 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_10 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_11, 41));
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_17 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_18 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_20 = {0x6E,0x65,0x77};
public static BEC_3_5_5_5_BuildVisitPass7 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_3_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-630006451, BEL_4_Base.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_0));
bevl_nlc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEL_4_Base.bevn_isLiteralSet_1, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_11_tmpany_phold);
beva_node.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_12_tmpany_phold);
beva_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bels_1));
bevt_13_tmpany_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 46 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_2));
bevt_15_tmpany_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 46 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 46 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpany_phold);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_23_tmpany_phold);
if (bevt_21_tmpany_phold != null && bevt_21_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_27_tmpany_phold);
if (bevt_25_tmpany_phold != null && bevt_25_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold != null && bevt_28_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_33_tmpany_phold);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_36_tmpany_phold);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_37_tmpany_phold);
bevl_pn.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 57 */
} /* Line: 50 */
} /* Line: 48 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 88 */
if (bevp_inClassNp == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 90 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 92 */
bevt_16_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpany_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(8, bels_3));
this.bem_buildLiteral_2(beva_node, bevt_18_tmpany_phold);
} /* Line: 95 */
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_4));
this.bem_buildLiteral_2(beva_node, bevt_22_tmpany_phold);
} /* Line: 98 */
bevt_24_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpany_phold.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 100 */ {
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_5));
this.bem_buildLiteral_2(beva_node, bevt_26_tmpany_phold);
} /* Line: 101 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_6));
this.bem_buildLiteral_2(beva_node, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpany_phold);
} /* Line: 106 */
bevt_33_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpany_phold.bevi_int == bevt_34_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_7));
beva_node.bem_heldSet_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_8));
this.bem_buildLiteral_2(beva_node, bevt_36_tmpany_phold);
} /* Line: 110 */
bevt_38_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpany_phold.bevi_int == bevt_39_tmpany_phold.bevi_int) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_9));
beva_node.bem_heldSet_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_10));
this.bem_buildLiteral_2(beva_node, bevt_41_tmpany_phold);
} /* Line: 118 */
 else  /* Line: 116 */ {
bevt_43_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpany_phold.bevi_int == bevt_44_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpany_phold).bevi_bool) /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_50_tmpany_phold = beva_node.bem_heldGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_49_tmpany_phold == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 121 */ {
if (bevl_nnode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_53_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_54_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_54_tmpany_phold);
if (bevt_52_tmpany_phold != null && bevt_52_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpany_phold).bevi_bool) /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 121 */ {
bevt_57_tmpany_phold = bevo_0;
bevt_59_tmpany_phold = beva_node.bem_heldGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_55_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_55_tmpany_phold);
} /* Line: 122 */
 else  /* Line: 123 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpany_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_62_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpany_phold;
} /* Line: 130 */
} /* Line: 121 */
 else  /* Line: 116 */ {
bevt_64_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 132 */ {
if (bevl_nnode == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 133 */ {
bevt_68_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpany_phold);
if (bevt_67_tmpany_phold != null && bevt_67_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 133 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 133 */
 else  /* Line: 133 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 133 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_71_tmpany_phold == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_72_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 136 */ {
bevt_73_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpany_phold != null && bevt_73_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_75_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpany_phold);
if (bevt_74_tmpany_phold != null && bevt_74_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpany_phold).bevi_bool) /* Line: 138 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 139 */
} /* Line: 138 */
 else  /* Line: 136 */ {
break;
} /* Line: 136 */
} /* Line: 136 */
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 142 */ {
bevt_77_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_77_tmpany_phold != null && bevt_77_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_77_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 144 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
} /* Line: 142 */
bevl_pc = bevl_nnode;
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpany_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_79_tmpany_phold);
bevl_pc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevt_82_tmpany_phold = bevl_dnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_83_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpany_phold);
if (bevt_81_tmpany_phold != null && bevt_81_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_81_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 155 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 155 */
 else  /* Line: 155 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 155 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_onode == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(38, bels_12));
bevt_85_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpany_phold);
} /* Line: 158 */
 else  /* Line: 157 */ {
bevt_88_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpany_phold.bevi_int == bevt_89_tmpany_phold.bevi_int) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 159 */ {
bevt_91_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpany_phold);
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 160 */ {
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_94_tmpany_phold);
} /* Line: 163 */
 else  /* Line: 164 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 165 */
} /* Line: 160 */
 else  /* Line: 157 */ {
bevt_96_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpany_phold.bevi_int == bevt_97_tmpany_phold.bevi_int) {
bevt_95_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_101_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_99_tmpany_phold = bevt_100_tmpany_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_102_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_102_tmpany_phold);
if (bevt_98_tmpany_phold != null && bevt_98_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_98_tmpany_phold).bevi_bool) /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 167 */ {
bevt_105_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_aliasedGet_0();
bevt_106_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpany_phold = bevt_104_tmpany_phold.bem_has_1(bevt_106_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 167 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 167 */
 else  /* Line: 167 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 167 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_109_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpany_phold);
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevt_111_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_113_tmpany_phold);
} /* Line: 176 */
 else  /* Line: 177 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 178 */
} /* Line: 173 */
 else  /* Line: 157 */ {
bevt_115_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_116_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_13));
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpany_phold);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpany_phold).bevi_bool) /* Line: 180 */ {
bevt_118_tmpany_phold = (new BEC_2_4_6_TextString(70, bels_14));
bevt_117_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 181 */
 else  /* Line: 157 */ {
bevt_120_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_121_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_15));
bevt_119_tmpany_phold = bevt_120_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpany_phold);
if (bevt_119_tmpany_phold != null && bevt_119_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_119_tmpany_phold).bevi_bool) /* Line: 182 */ {
bevt_123_tmpany_phold = (new BEC_2_4_6_TextString(65, bels_16));
bevt_122_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_122_tmpany_phold);
} /* Line: 183 */
} /* Line: 157 */
} /* Line: 157 */
} /* Line: 157 */
} /* Line: 157 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_onode);
bevl_dnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 188 */
 else  /* Line: 189 */ {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_124_tmpany_phold);
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_125_tmpany_phold);
} /* Line: 191 */
} /* Line: 155 */
} /* Line: 133 */
 else  /* Line: 116 */ {
bevt_127_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpany_phold.bevi_int == bevt_128_tmpany_phold.bevi_int) {
bevt_126_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_131_tmpany_phold = (new BEC_2_4_6_TextString(34, bels_17));
bevt_130_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_130_tmpany_phold);
} /* Line: 200 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpany_phold.bevi_int == bevt_134_tmpany_phold.bevi_int) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 204 */ {
bevt_136_tmpany_phold = (new BEC_2_4_6_TextString(84, bels_18));
bevt_135_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_135_tmpany_phold);
} /* Line: 205 */
bevt_137_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpany_phold);
} /* Line: 207 */
 else  /* Line: 116 */ {
bevt_139_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpany_phold.bevi_int == bevt_140_tmpany_phold.bevi_int) {
bevt_138_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
if (bevl_onode == null) {
bevt_142_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 213 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 213 */ {
bevt_144_tmpany_phold = (new BEC_2_4_6_TextString(34, bels_19));
bevt_143_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpany_phold);
} /* Line: 214 */
bevt_146_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_147_tmpany_phold);
if (bevt_145_tmpany_phold != null && bevt_145_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_145_tmpany_phold).bevi_bool) /* Line: 216 */ {
bevl_pnode = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_pnode == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_150_tmpany_phold = bevl_pnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_151_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_151_tmpany_phold);
if (bevt_149_tmpany_phold != null && bevt_149_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpany_phold).bevi_bool) /* Line: 218 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 218 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpany_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpany_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_ga.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_153_tmpany_phold);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpany_phold.bevi_int == bevt_156_tmpany_phold.bevi_int) {
bevt_154_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpany_phold.bevi_bool) /* Line: 227 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 228 */
 else  /* Line: 227 */ {
bevt_158_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpany_phold.bevi_int == bevt_159_tmpany_phold.bevi_int) {
bevt_157_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpany_phold.bevi_bool) /* Line: 229 */ {
bevt_163_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_164_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_164_tmpany_phold);
if (bevt_160_tmpany_phold != null && bevt_160_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_160_tmpany_phold).bevi_bool) /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_167_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bem_aliasedGet_0();
bevt_168_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bem_has_1(bevt_168_tmpany_phold);
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 229 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 229 */
 else  /* Line: 229 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 229 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpany_phold);
bevl_onode.bem_resolveNp_0();
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 235 */
} /* Line: 227 */
} /* Line: 227 */
} /* Line: 218 */
} /* Line: 216 */
} /* Line: 116 */
} /* Line: 116 */
} /* Line: 116 */
} /* Line: 116 */
bevt_171_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpany_phold;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) throws Throwable {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpany_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_20));
bevl_gnc.bem_nameSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpany_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 26, 27, 27, 28, 29, 31, 32, 32, 33, 33, 34, 34, 35, 35, 36, 36, 37, 37, 39, 41, 41, 42, 44, 46, 46, 0, 46, 46, 0, 0, 47, 48, 48, 48, 48, 48, 0, 48, 48, 48, 0, 0, 0, 0, 0, 49, 50, 50, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 50, 50, 50, 0, 0, 0, 50, 50, 50, 0, 0, 0, 0, 0, 56, 56, 56, 56, 57, 83, 86, 86, 86, 86, 87, 87, 88, 88, 88, 90, 90, 91, 92, 94, 94, 94, 94, 95, 95, 97, 97, 97, 97, 98, 98, 100, 100, 100, 100, 101, 101, 103, 103, 103, 103, 105, 105, 106, 106, 108, 108, 108, 108, 109, 109, 110, 110, 116, 116, 116, 116, 117, 117, 118, 118, 120, 120, 120, 120, 120, 120, 120, 0, 0, 0, 121, 121, 121, 121, 121, 121, 0, 121, 121, 121, 0, 0, 0, 0, 0, 122, 122, 122, 122, 122, 122, 124, 124, 124, 125, 126, 130, 130, 132, 132, 132, 132, 133, 133, 133, 133, 133, 0, 0, 0, 134, 134, 134, 135, 136, 136, 136, 137, 138, 138, 138, 139, 142, 142, 143, 144, 147, 148, 148, 149, 150, 150, 151, 152, 153, 154, 155, 155, 155, 155, 155, 0, 0, 0, 156, 157, 157, 158, 158, 158, 159, 159, 159, 159, 160, 160, 161, 161, 162, 162, 163, 163, 165, 167, 167, 167, 167, 167, 167, 167, 167, 167, 0, 167, 167, 167, 167, 0, 0, 0, 0, 0, 168, 169, 169, 170, 171, 171, 172, 173, 173, 174, 174, 175, 175, 176, 176, 178, 180, 180, 180, 181, 181, 181, 182, 182, 182, 183, 183, 183, 186, 187, 188, 190, 190, 191, 191, 195, 195, 195, 195, 198, 199, 199, 200, 200, 200, 202, 203, 204, 204, 204, 204, 205, 205, 205, 207, 207, 208, 208, 208, 208, 210, 213, 213, 0, 213, 213, 0, 0, 214, 214, 214, 216, 216, 216, 217, 218, 218, 0, 218, 218, 218, 0, 0, 219, 220, 220, 221, 222, 222, 223, 224, 225, 226, 227, 227, 227, 227, 228, 229, 229, 229, 229, 229, 229, 229, 229, 229, 0, 229, 229, 229, 229, 0, 0, 0, 0, 0, 230, 231, 231, 232, 233, 233, 234, 235, 240, 240, 244, 245, 246, 246, 247, 247, 248, 250, 251, 251, 252, 252, 253, 253, 254, 254, 255, 255, 256, 257, 257, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 109, 112, 113, 115, 118, 122, 123, 128, 129, 130, 131, 133, 136, 137, 138, 140, 143, 147, 150, 154, 157, 158, 163, 164, 167, 168, 169, 171, 172, 173, 175, 178, 182, 185, 186, 187, 189, 192, 196, 199, 200, 201, 203, 206, 210, 213, 216, 220, 221, 222, 223, 224, 417, 418, 419, 420, 425, 426, 427, 428, 429, 430, 432, 437, 438, 439, 441, 442, 443, 448, 449, 450, 452, 453, 454, 459, 460, 461, 463, 464, 465, 470, 471, 472, 474, 475, 476, 481, 482, 483, 484, 485, 487, 488, 489, 494, 495, 496, 497, 498, 500, 501, 502, 507, 508, 509, 510, 511, 514, 515, 516, 521, 522, 523, 524, 526, 529, 533, 536, 537, 538, 543, 544, 549, 550, 553, 554, 555, 557, 560, 564, 567, 571, 574, 575, 576, 577, 578, 579, 582, 583, 584, 585, 586, 587, 588, 592, 593, 594, 599, 600, 605, 606, 607, 608, 610, 613, 617, 620, 621, 626, 627, 628, 629, 632, 634, 635, 636, 637, 639, 646, 649, 651, 652, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 674, 675, 676, 677, 679, 682, 686, 689, 690, 695, 696, 697, 698, 701, 702, 703, 708, 709, 710, 712, 713, 714, 715, 716, 717, 720, 724, 725, 726, 731, 732, 733, 734, 735, 736, 738, 741, 742, 743, 744, 746, 749, 753, 756, 760, 763, 764, 765, 766, 767, 768, 769, 770, 771, 773, 774, 775, 776, 777, 778, 781, 785, 786, 787, 789, 790, 791, 794, 795, 796, 798, 799, 800, 806, 807, 808, 811, 812, 813, 814, 819, 820, 821, 826, 827, 828, 833, 834, 835, 836, 838, 839, 840, 841, 842, 847, 848, 849, 850, 852, 853, 856, 857, 858, 863, 864, 865, 870, 871, 874, 879, 880, 883, 887, 888, 889, 891, 892, 893, 895, 896, 901, 902, 905, 906, 907, 909, 912, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 933, 934, 937, 938, 939, 944, 945, 946, 947, 948, 949, 951, 954, 955, 956, 957, 959, 962, 966, 969, 973, 976, 977, 978, 979, 980, 981, 982, 983, 993, 994, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1031, 1034, 1038, 1041};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 81
new 0 23 81
fromString 1 24 82
assign 1 26 83
new 1 26 83
assign 1 27 84
NAMEPATHGet 0 27 84
typenameSet 1 27 85
heldSet 1 28 86
copyLoc 1 29 87
assign 1 31 88
new 0 31 88
assign 1 32 89
new 0 32 89
nameSet 1 32 90
assign 1 33 91
new 0 33 91
wasBoundSet 1 33 92
assign 1 34 93
new 0 34 93
boundSet 1 34 94
assign 1 35 95
new 0 35 95
isConstructSet 1 35 96
assign 1 36 97
new 0 36 97
isLiteralSet 1 36 98
assign 1 37 99
heldGet 0 37 99
literalValueSet 1 37 100
addValue 1 39 101
assign 1 41 102
CALLGet 0 41 102
typenameSet 1 41 103
heldSet 1 42 104
resolveNp 0 44 105
assign 1 46 106
new 0 46 106
assign 1 46 107
equals 1 46 107
assign 1 0 109
assign 1 46 112
new 0 46 112
assign 1 46 113
equals 1 46 113
assign 1 0 115
assign 1 0 118
assign 1 47 122
priorPeerGet 0 47 122
assign 1 48 123
def 1 48 128
assign 1 48 129
typenameGet 0 48 129
assign 1 48 130
SUBTRACTGet 0 48 130
assign 1 48 131
equals 1 48 131
assign 1 0 133
assign 1 48 136
typenameGet 0 48 136
assign 1 48 137
ADDGet 0 48 137
assign 1 48 138
equals 1 48 138
assign 1 0 140
assign 1 0 143
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 49 157
priorPeerGet 0 49 157
assign 1 50 158
undef 1 50 163
assign 1 0 164
assign 1 50 167
typenameGet 0 50 167
assign 1 50 168
CALLGet 0 50 168
assign 1 50 169
notEquals 1 50 169
assign 1 50 171
typenameGet 0 50 171
assign 1 50 172
IDGet 0 50 172
assign 1 50 173
notEquals 1 50 173
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 50 185
typenameGet 0 50 185
assign 1 50 186
VARGet 0 50 186
assign 1 50 187
notEquals 1 50 187
assign 1 0 189
assign 1 0 192
assign 1 0 196
assign 1 50 199
typenameGet 0 50 199
assign 1 50 200
ACCESSORGet 0 50 200
assign 1 50 201
notEquals 1 50 201
assign 1 0 203
assign 1 0 206
assign 1 0 210
assign 1 0 213
assign 1 0 216
assign 1 56 220
heldGet 0 56 220
assign 1 56 221
literalValueGet 0 56 221
assign 1 56 222
add 1 56 222
literalValueSet 1 56 223
delete 0 57 224
assign 1 83 417
nextPeerGet 0 83 417
assign 1 86 418
typenameGet 0 86 418
assign 1 86 419
CLASSGet 0 86 419
assign 1 86 420
equals 1 86 425
assign 1 87 426
heldGet 0 87 426
assign 1 87 427
namepathGet 0 87 427
assign 1 88 428
heldGet 0 88 428
assign 1 88 429
fromFileGet 0 88 429
assign 1 88 430
toString 0 88 430
assign 1 90 432
def 1 90 437
inClassNpSet 1 91 438
inFileSet 1 92 439
assign 1 94 441
typenameGet 0 94 441
assign 1 94 442
INTLGet 0 94 442
assign 1 94 443
equals 1 94 448
assign 1 95 449
new 0 95 449
buildLiteral 2 95 450
assign 1 97 452
typenameGet 0 97 452
assign 1 97 453
FLOATLGet 0 97 453
assign 1 97 454
equals 1 97 459
assign 1 98 460
new 0 98 460
buildLiteral 2 98 461
assign 1 100 463
typenameGet 0 100 463
assign 1 100 464
STRINGLGet 0 100 464
assign 1 100 465
equals 1 100 470
assign 1 101 471
new 0 101 471
buildLiteral 2 101 472
assign 1 103 474
typenameGet 0 103 474
assign 1 103 475
WSTRINGLGet 0 103 475
assign 1 103 476
equals 1 103 481
assign 1 105 482
new 0 105 482
buildLiteral 2 105 483
assign 1 106 484
new 0 106 484
wideStringSet 1 106 485
assign 1 108 487
typenameGet 0 108 487
assign 1 108 488
TRUEGet 0 108 488
assign 1 108 489
equals 1 108 494
assign 1 109 495
new 0 109 495
heldSet 1 109 496
assign 1 110 497
new 0 110 497
buildLiteral 2 110 498
assign 1 116 500
typenameGet 0 116 500
assign 1 116 501
FALSEGet 0 116 501
assign 1 116 502
equals 1 116 507
assign 1 117 508
new 0 117 508
heldSet 1 117 509
assign 1 118 510
new 0 118 510
buildLiteral 2 118 511
assign 1 120 514
typenameGet 0 120 514
assign 1 120 515
VARGet 0 120 515
assign 1 120 516
equals 1 120 521
assign 1 120 522
heldGet 0 120 522
assign 1 120 523
isArgGet 0 120 523
assign 1 120 524
not 0 120 524
assign 1 0 526
assign 1 0 529
assign 1 0 533
assign 1 121 536
heldGet 0 121 536
assign 1 121 537
nameGet 0 121 537
assign 1 121 538
undef 1 121 543
assign 1 121 544
undef 1 121 549
assign 1 0 550
assign 1 121 553
typenameGet 0 121 553
assign 1 121 554
IDGet 0 121 554
assign 1 121 555
notEquals 1 121 555
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 0 567
assign 1 0 571
assign 1 122 574
new 0 122 574
assign 1 122 575
heldGet 0 122 575
assign 1 122 576
nameGet 0 122 576
assign 1 122 577
add 1 122 577
assign 1 122 578
new 2 122 578
throw 1 122 579
assign 1 124 582
heldGet 0 124 582
assign 1 124 583
heldGet 0 124 583
nameSet 1 124 584
addVariable 0 125 585
delete 0 126 586
assign 1 130 587
nextDescendGet 0 130 587
return 1 130 588
assign 1 132 592
typenameGet 0 132 592
assign 1 132 593
IDGet 0 132 593
assign 1 132 594
equals 1 132 599
assign 1 133 600
def 1 133 605
assign 1 133 606
typenameGet 0 133 606
assign 1 133 607
PARENSGet 0 133 607
assign 1 133 608
equals 1 133 608
assign 1 0 610
assign 1 0 613
assign 1 0 617
assign 1 134 620
containedGet 0 134 620
assign 1 134 621
def 1 134 626
assign 1 135 627
new 0 135 627
assign 1 136 628
containedGet 0 136 628
assign 1 136 629
iteratorGet 0 136 629
assign 1 136 632
hasNextGet 0 136 632
assign 1 137 634
nextGet 0 137 634
assign 1 138 635
typenameGet 0 138 635
assign 1 138 636
COMMAGet 0 138 636
assign 1 138 637
equals 1 138 637
addValue 1 139 639
assign 1 142 646
iteratorGet 0 142 646
assign 1 142 649
hasNextGet 0 142 649
assign 1 143 651
nextGet 0 143 651
delete 0 144 652
assign 1 147 659
assign 1 148 660
CALLGet 0 148 660
typenameSet 1 148 661
assign 1 149 662
new 0 149 662
assign 1 150 663
heldGet 0 150 663
nameSet 1 150 664
heldSet 1 151 665
delete 0 152 666
assign 1 153 667
assign 1 154 668
priorPeerGet 0 154 668
assign 1 155 669
def 1 155 674
assign 1 155 675
typenameGet 0 155 675
assign 1 155 676
DOTGet 0 155 676
assign 1 155 677
equals 1 155 677
assign 1 0 679
assign 1 0 682
assign 1 0 686
assign 1 156 689
priorPeerGet 0 156 689
assign 1 157 690
undef 1 157 695
assign 1 158 696
new 0 158 696
assign 1 158 697
new 2 158 697
throw 1 158 698
assign 1 159 701
typenameGet 0 159 701
assign 1 159 702
NAMEPATHGet 0 159 702
assign 1 159 703
equals 1 159 708
assign 1 160 709
nameGet 0 160 709
assign 1 160 710
isNewish 1 160 710
assign 1 161 712
new 0 161 712
wasBoundSet 1 161 713
assign 1 162 714
new 0 162 714
boundSet 1 162 715
assign 1 163 716
new 0 163 716
isConstructSet 1 163 717
createImpliedConstruct 2 165 720
assign 1 167 724
typenameGet 0 167 724
assign 1 167 725
IDGet 0 167 725
assign 1 167 726
equals 1 167 731
assign 1 167 732
transUnitGet 0 167 732
assign 1 167 733
heldGet 0 167 733
assign 1 167 734
aliasedGet 0 167 734
assign 1 167 735
heldGet 0 167 735
assign 1 167 736
has 1 167 736
assign 1 0 738
assign 1 167 741
emitDataGet 0 167 741
assign 1 167 742
aliasedGet 0 167 742
assign 1 167 743
heldGet 0 167 743
assign 1 167 744
has 1 167 744
assign 1 0 746
assign 1 0 749
assign 1 0 753
assign 1 0 756
assign 1 0 760
assign 1 168 763
new 0 168 763
assign 1 169 764
heldGet 0 169 764
addStep 1 169 765
heldSet 1 170 766
assign 1 171 767
NAMEPATHGet 0 171 767
typenameSet 1 171 768
resolveNp 0 172 769
assign 1 173 770
nameGet 0 173 770
assign 1 173 771
isNewish 1 173 771
assign 1 174 773
new 0 174 773
wasBoundSet 1 174 774
assign 1 175 775
new 0 175 775
boundSet 1 175 776
assign 1 176 777
new 0 176 777
isConstructSet 1 176 778
createImpliedConstruct 2 178 781
assign 1 180 785
nameGet 0 180 785
assign 1 180 786
new 0 180 786
assign 1 180 787
equals 1 180 787
assign 1 181 789
new 0 181 789
assign 1 181 790
new 2 181 790
throw 1 181 791
assign 1 182 794
nameGet 0 182 794
assign 1 182 795
new 0 182 795
assign 1 182 796
equals 1 182 796
assign 1 183 798
new 0 183 798
assign 1 183 799
new 2 183 799
throw 1 183 800
delete 0 186 806
prepend 1 187 807
delete 0 188 808
assign 1 190 811
new 0 190 811
boundSet 1 190 812
assign 1 191 813
new 0 191 813
wasBoundSet 1 191 814
assign 1 195 819
typenameGet 0 195 819
assign 1 195 820
IDXGet 0 195 820
assign 1 195 821
equals 1 195 826
assign 1 198 827
priorPeerGet 0 198 827
assign 1 199 828
undef 1 199 833
assign 1 200 834
new 0 200 834
assign 1 200 835
new 2 200 835
throw 1 200 836
delete 0 202 838
prepend 1 203 839
assign 1 204 840
typenameGet 0 204 840
assign 1 204 841
NAMEPATHGet 0 204 841
assign 1 204 842
equals 1 204 847
assign 1 205 848
new 0 205 848
assign 1 205 849
new 2 205 849
throw 1 205 850
assign 1 207 852
IDXACCGet 0 207 852
typenameSet 1 207 853
assign 1 208 856
typenameGet 0 208 856
assign 1 208 857
DOTGet 0 208 857
assign 1 208 858
equals 1 208 863
assign 1 210 864
priorPeerGet 0 210 864
assign 1 213 865
undef 1 213 870
assign 1 0 871
assign 1 213 874
undef 1 213 879
assign 1 0 880
assign 1 0 883
assign 1 214 887
new 0 214 887
assign 1 214 888
new 2 214 888
throw 1 214 889
assign 1 216 891
typenameGet 0 216 891
assign 1 216 892
IDGet 0 216 892
assign 1 216 893
equals 1 216 893
assign 1 217 895
nextPeerGet 0 217 895
assign 1 218 896
undef 1 218 901
assign 1 0 902
assign 1 218 905
typenameGet 0 218 905
assign 1 218 906
PARENSGet 0 218 906
assign 1 218 907
notEquals 1 218 907
assign 1 0 909
assign 1 0 912
assign 1 219 916
priorPeerGet 0 219 916
assign 1 220 917
ACCESSORGet 0 220 917
typenameSet 1 220 918
assign 1 221 919
new 0 221 919
assign 1 222 920
heldGet 0 222 920
nameSet 1 222 921
delete 0 223 922
delete 0 224 923
heldSet 1 225 924
addValue 1 226 925
assign 1 227 926
typenameGet 0 227 926
assign 1 227 927
NAMEPATHGet 0 227 927
assign 1 227 928
equals 1 227 933
createImpliedConstruct 2 228 934
assign 1 229 937
typenameGet 0 229 937
assign 1 229 938
IDGet 0 229 938
assign 1 229 939
equals 1 229 944
assign 1 229 945
transUnitGet 0 229 945
assign 1 229 946
heldGet 0 229 946
assign 1 229 947
aliasedGet 0 229 947
assign 1 229 948
heldGet 0 229 948
assign 1 229 949
has 1 229 949
assign 1 0 951
assign 1 229 954
emitDataGet 0 229 954
assign 1 229 955
aliasedGet 0 229 955
assign 1 229 956
heldGet 0 229 956
assign 1 229 957
has 1 229 957
assign 1 0 959
assign 1 0 962
assign 1 0 966
assign 1 0 969
assign 1 0 973
assign 1 230 976
new 0 230 976
assign 1 231 977
heldGet 0 231 977
addStep 1 231 978
heldSet 1 232 979
assign 1 233 980
NAMEPATHGet 0 233 980
typenameSet 1 233 981
resolveNp 0 234 982
createImpliedConstruct 2 235 983
assign 1 240 993
nextDescendGet 0 240 993
return 1 240 994
assign 1 244 1007
new 0 244 1007
heldSet 1 245 1008
assign 1 246 1009
NAMEPATHGet 0 246 1009
typenameSet 1 246 1010
assign 1 247 1011
heldGet 0 247 1011
heldSet 1 247 1012
prepend 1 248 1013
assign 1 250 1014
new 0 250 1014
assign 1 251 1015
new 0 251 1015
nameSet 1 251 1016
assign 1 252 1017
new 0 252 1017
wasBoundSet 1 252 1018
assign 1 253 1019
new 0 253 1019
boundSet 1 253 1020
assign 1 254 1021
new 0 254 1021
isConstructSet 1 254 1022
assign 1 255 1023
new 0 255 1023
wasImpliedConstructSet 1 255 1024
heldSet 1 256 1025
assign 1 257 1026
CALLGet 0 257 1026
typenameSet 1 257 1027
return 1 0 1031
assign 1 0 1034
return 1 0 1038
assign 1 0 1041
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 822104518: return bem_inFileGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 856627742: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass7.bevs_inst = (BEC_3_5_5_5_BuildVisitPass7)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bevs_inst;
}
}
