package be.BEL_4_Base;
/* IO:File: source/build/Pass12.be */
public class BEC_5_5_6_BuildVisitRewind extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_6_BuildVisitRewind() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_1 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_2 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_2, 27));
private static byte[] bels_3 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_4 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_4, 13));
private static byte[] bels_5 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_5, 10));
private static byte[] bels_6 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_5_5_6_BuildVisitRewind bevs_inst;
public BEC_6_6_SystemObject bevp_tvmap;
public BEC_6_6_SystemObject bevp_rmap;
public BEC_6_6_SystemObject bevp_inClass;
public BEC_6_6_SystemObject bevp_inClassNp;
public BEC_6_6_SystemObject bevp_inClassSyn;
public BEC_6_6_SystemObject bevp_nl;
public BEC_6_6_SystemObject bevp_emitter;
public BEC_5_5_6_BuildVisitRewind bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevl_ll = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_31_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_32_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_35_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_38_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevp_inClass = beva_node;
bevt_7_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_7_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_8_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 250 */
bevt_10_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_11_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevp_tvmap = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_9_3_ContainerMap()).bem_new_0();
} /* Line: 254 */
 else  /* Line: 252 */ {
bevt_13_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_14_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 255 */ {
bevt_16_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 255 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 255 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 255 */
 else  /* Line: 255 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 255 */ {
bevt_18_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_19_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_17_tmpvar_phold, bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_20_tmpvar_phold);
if (bevl_ll == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevl_ll = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_24_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_rmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_23_tmpvar_phold, bevl_ll);
} /* Line: 260 */
bevl_ll.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 262 */
 else  /* Line: 252 */ {
bevt_26_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_equals_1(bevt_27_tmpvar_phold);
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_29_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_29_tmpvar_phold == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
 else  /* Line: 263 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 263 */ {
bevt_32_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_containerGet_0();
if (bevt_31_tmpvar_phold == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
 else  /* Line: 263 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 263 */ {
bevt_36_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_containerGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_typenameGet_0();
bevt_37_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_equals_1(bevt_37_tmpvar_phold);
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
 else  /* Line: 263 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 263 */ {
this.bem_processTmps_0();
} /* Line: 265 */
} /* Line: 252 */
} /* Line: 252 */
bevt_38_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_38_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_processTmps_0() throws Throwable {
BEC_6_6_SystemObject bevl_foundone = null;
BEC_6_6_SystemObject bevl_targ = null;
BEC_6_6_SystemObject bevl_tvar = null;
BEC_6_6_SystemObject bevl_tcall = null;
BEC_5_8_BuildClassSyn bevl_syn = null;
BEC_6_6_SystemObject bevl_targNp = null;
BEC_6_6_SystemObject bevl_mtdc = null;
BEC_6_6_SystemObject bevl_ovar = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_nv = null;
BEC_6_6_SystemObject bevl_nvname = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_k = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_91_tmpvar_phold = null;
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
while (true)
 /* Line: 279 */ {
if (bevl_foundone != null && bevl_foundone instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_foundone).bevi_bool) /* Line: 279 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(2145224760, BEL_4_Base.bevn_valueIteratorGet_0);
while (true)
 /* Line: 281 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_nv = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_nv.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 284 */ {
bevl_nvname = bevl_nv.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_nvname);
bevt_0_tmpvar_loop = bevl_ll.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 289 */ {
bevt_11_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 289 */ {
bevl_k = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_15_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
bevt_20_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(6, bels_0));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
bevt_25_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_26_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_26_tmpvar_phold);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
bevt_27_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevl_tcall = bevt_27_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targNp = null;
bevt_30_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_29_tmpvar_phold == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_31_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_targNp = bevt_31_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
} /* Line: 295 */
 else  /* Line: 296 */ {
bevt_32_tmpvar_phold = bevl_tcall.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_targ = bevt_32_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_34_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 301 */ {
bevl_tvar = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 302 */
 else  /* Line: 303 */ {
bevt_36_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_38_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_37_tmpvar_phold);
bevl_tvar = bevt_35_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 304 */
bevt_39_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 307 */ {
bevl_targNp = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 308 */
} /* Line: 307 */
if (bevl_targNp == null) {
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_41_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_43_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_41_tmpvar_phold.bem_get_1(bevt_42_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevl_ovar == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 318 */ {
bevt_46_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 318 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 318 */
 else  /* Line: 318 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 318 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_47_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_targNp);
} /* Line: 321 */
 else  /* Line: 322 */ {
bevt_48_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_48_tmpvar_phold);
} /* Line: 323 */
bevt_49_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = bevp_inClass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_50_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_51_tmpvar_phold);
bevt_54_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(4, bels_1));
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 327 */ {
bevt_57_tmpvar_phold = bevo_0;
bevt_58_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 327 */
} /* Line: 327 */
} /* Line: 318 */
 else  /* Line: 315 */ {
bevt_61_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_62_tmpvar_phold = (new BEC_4_6_TextString(6, bels_3));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_62_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 329 */ {
bevt_67_tmpvar_phold = bevo_1;
bevt_69_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = bevo_2;
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_add_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_targNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_add_1(bevt_71_tmpvar_phold);
bevt_63_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpvar_phold, bevl_tcall);
throw new be.BELS_Base.BECS_ThrowBack(bevt_63_tmpvar_phold);
} /* Line: 330 */
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 311 */
 else  /* Line: 290 */ {
bevt_72_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_72_tmpvar_phold != null && bevt_72_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_72_tmpvar_phold).bevi_bool) /* Line: 335 */ {
bevt_75_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 335 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 335 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 335 */
 else  /* Line: 335 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 335 */ {
bevt_80_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_81_tmpvar_phold = (new BEC_4_6_TextString(6, bels_6));
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 335 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 335 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 335 */
 else  /* Line: 335 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 335 */ {
bevt_85_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_84_tmpvar_phold = bevt_85_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_86_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 335 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 335 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 335 */
 else  /* Line: 335 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 335 */ {
bevt_88_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targ = bevt_87_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_89_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_89_tmpvar_phold != null && bevt_89_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_89_tmpvar_phold).bevi_bool) /* Line: 338 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_90_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_targ.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_91_tmpvar_phold);
} /* Line: 342 */
} /* Line: 338 */
} /* Line: 290 */
} /* Line: 290 */
 else  /* Line: 289 */ {
break;
} /* Line: 289 */
} /* Line: 289 */
} /* Line: 289 */
} /* Line: 284 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
} /* Line: 281 */
 else  /* Line: 279 */ {
break;
} /* Line: 279 */
} /* Line: 279 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_tvmapGet_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public BEC_6_6_SystemObject bem_tvmapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_tvmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_rmapGet_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public BEC_6_6_SystemObject bem_rmapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_rmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClass = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {247, 247, 247, 248, 249, 249, 250, 250, 252, 252, 252, 253, 254, 255, 255, 255, 255, 255, 0, 0, 0, 256, 256, 256, 256, 257, 257, 257, 258, 258, 259, 260, 260, 260, 262, 263, 263, 263, 263, 263, 263, 0, 0, 0, 263, 263, 263, 263, 0, 0, 0, 263, 263, 263, 263, 263, 0, 0, 0, 265, 267, 267, 271, 280, 281, 281, 282, 284, 284, 287, 288, 289, 0, 289, 289, 290, 290, 290, 290, 290, 0, 0, 0, 290, 290, 290, 290, 290, 0, 0, 0, 290, 290, 290, 290, 290, 0, 0, 0, 292, 292, 293, 294, 294, 294, 294, 295, 295, 297, 297, 301, 301, 302, 304, 304, 304, 304, 304, 307, 308, 311, 311, 313, 314, 314, 314, 314, 315, 315, 317, 318, 318, 318, 0, 0, 0, 319, 320, 321, 323, 323, 325, 325, 326, 326, 326, 327, 327, 327, 327, 327, 327, 327, 327, 329, 329, 329, 329, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 335, 335, 335, 335, 335, 0, 0, 0, 335, 335, 335, 335, 335, 0, 0, 0, 335, 335, 335, 335, 335, 0, 0, 0, 336, 336, 336, 338, 340, 341, 341, 342, 342, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {69, 70, 71, 73, 74, 75, 76, 77, 79, 80, 81, 83, 84, 87, 88, 89, 91, 92, 94, 97, 101, 104, 105, 106, 107, 108, 109, 110, 111, 116, 117, 118, 119, 120, 122, 125, 126, 127, 129, 130, 135, 136, 139, 143, 146, 147, 148, 153, 154, 157, 161, 164, 165, 166, 167, 168, 170, 173, 177, 180, 184, 185, 293, 297, 298, 301, 303, 304, 305, 307, 308, 309, 309, 312, 314, 315, 317, 318, 319, 320, 322, 325, 329, 332, 333, 334, 335, 336, 338, 341, 345, 348, 349, 350, 351, 352, 354, 357, 361, 364, 365, 366, 367, 368, 369, 374, 375, 376, 379, 380, 381, 382, 384, 387, 388, 389, 390, 391, 393, 395, 398, 403, 404, 405, 406, 407, 408, 409, 414, 415, 416, 421, 422, 424, 427, 431, 434, 435, 437, 440, 441, 443, 444, 445, 446, 447, 448, 449, 450, 451, 453, 454, 455, 456, 461, 462, 463, 464, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 481, 483, 484, 485, 486, 488, 491, 495, 498, 499, 500, 501, 502, 504, 507, 511, 514, 515, 516, 517, 518, 520, 523, 527, 530, 531, 532, 533, 535, 536, 537, 538, 539, 562, 565, 569, 572, 576, 579, 583, 586, 590, 593, 597, 600, 604, 607};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 247 69
typenameGet 0 247 69
assign 1 247 70
CLASSGet 0 247 70
assign 1 247 71
equals 1 247 71
assign 1 248 73
assign 1 249 74
heldGet 0 249 74
assign 1 249 75
namepathGet 0 249 75
assign 1 250 76
heldGet 0 250 76
assign 1 250 77
synGet 0 250 77
assign 1 252 79
typenameGet 0 252 79
assign 1 252 80
METHODGet 0 252 80
assign 1 252 81
equals 1 252 81
assign 1 253 83
new 0 253 83
assign 1 254 84
new 0 254 84
assign 1 255 87
typenameGet 0 255 87
assign 1 255 88
VARGet 0 255 88
assign 1 255 89
equals 1 255 89
assign 1 255 91
heldGet 0 255 91
assign 1 255 92
isTmpVarGet 0 255 92
assign 1 0 94
assign 1 0 97
assign 1 0 101
assign 1 256 104
heldGet 0 256 104
assign 1 256 105
nameGet 0 256 105
assign 1 256 106
heldGet 0 256 106
put 2 256 107
assign 1 257 108
heldGet 0 257 108
assign 1 257 109
nameGet 0 257 109
assign 1 257 110
get 1 257 110
assign 1 258 111
undef 1 258 116
assign 1 259 117
new 0 259 117
assign 1 260 118
heldGet 0 260 118
assign 1 260 119
nameGet 0 260 119
put 2 260 120
addValue 1 262 122
assign 1 263 125
typenameGet 0 263 125
assign 1 263 126
RBRACESGet 0 263 126
assign 1 263 127
equals 1 263 127
assign 1 263 129
containerGet 0 263 129
assign 1 263 130
def 1 263 135
assign 1 0 136
assign 1 0 139
assign 1 0 143
assign 1 263 146
containerGet 0 263 146
assign 1 263 147
containerGet 0 263 147
assign 1 263 148
def 1 263 153
assign 1 0 154
assign 1 0 157
assign 1 0 161
assign 1 263 164
containerGet 0 263 164
assign 1 263 165
containerGet 0 263 165
assign 1 263 166
typenameGet 0 263 166
assign 1 263 167
METHODGet 0 263 167
assign 1 263 168
equals 1 263 168
assign 1 0 170
assign 1 0 173
assign 1 0 177
processTmps 0 265 180
assign 1 267 184
nextDescendGet 0 267 184
return 1 267 185
assign 1 271 293
new 0 271 293
assign 1 280 297
new 0 280 297
assign 1 281 298
valueIteratorGet 0 281 298
assign 1 281 301
hasNextGet 0 281 301
assign 1 282 303
nextGet 0 282 303
assign 1 284 304
isTypedGet 0 284 304
assign 1 284 305
not 0 284 305
assign 1 287 307
nameGet 0 287 307
assign 1 288 308
get 1 288 308
assign 1 289 309
iteratorGet 0 0 309
assign 1 289 312
hasNextGet 0 289 312
assign 1 289 314
nextGet 0 289 314
assign 1 290 315
isFirstGet 0 290 315
assign 1 290 317
containerGet 0 290 317
assign 1 290 318
typenameGet 0 290 318
assign 1 290 319
CALLGet 0 290 319
assign 1 290 320
equals 1 290 320
assign 1 0 322
assign 1 0 325
assign 1 0 329
assign 1 290 332
containerGet 0 290 332
assign 1 290 333
heldGet 0 290 333
assign 1 290 334
orgNameGet 0 290 334
assign 1 290 335
new 0 290 335
assign 1 290 336
equals 1 290 336
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 290 348
containerGet 0 290 348
assign 1 290 349
secondGet 0 290 349
assign 1 290 350
typenameGet 0 290 350
assign 1 290 351
CALLGet 0 290 351
assign 1 290 352
equals 1 290 352
assign 1 0 354
assign 1 0 357
assign 1 0 361
assign 1 292 364
containerGet 0 292 364
assign 1 292 365
secondGet 0 292 365
assign 1 293 366
assign 1 294 367
heldGet 0 294 367
assign 1 294 368
newNpGet 0 294 368
assign 1 294 369
def 1 294 374
assign 1 295 375
heldGet 0 295 375
assign 1 295 376
newNpGet 0 295 376
assign 1 297 379
containedGet 0 297 379
assign 1 297 380
firstGet 0 297 380
assign 1 301 381
heldGet 0 301 381
assign 1 301 382
isDeclaredGet 0 301 382
assign 1 302 384
heldGet 0 302 384
assign 1 304 387
ptyMapGet 0 304 387
assign 1 304 388
heldGet 0 304 388
assign 1 304 389
nameGet 0 304 389
assign 1 304 390
get 1 304 390
assign 1 304 391
memSynGet 0 304 391
assign 1 307 393
isTypedGet 0 307 393
assign 1 308 395
namepathGet 0 308 395
assign 1 311 398
def 1 311 403
assign 1 313 404
getSynNp 1 313 404
assign 1 314 405
mtdMapGet 0 314 405
assign 1 314 406
heldGet 0 314 406
assign 1 314 407
nameGet 0 314 407
assign 1 314 408
get 1 314 408
assign 1 315 409
def 1 315 414
assign 1 317 415
rsynGet 0 317 415
assign 1 318 416
def 1 318 421
assign 1 318 422
isTypedGet 0 318 422
assign 1 0 424
assign 1 0 427
assign 1 0 431
assign 1 319 434
new 0 319 434
assign 1 320 435
isSelfGet 0 320 435
namepathSet 1 321 437
assign 1 323 440
namepathGet 0 323 440
namepathSet 1 323 441
assign 1 325 443
isTypedGet 0 325 443
isTypedSet 1 325 444
assign 1 326 445
heldGet 0 326 445
assign 1 326 446
namepathGet 0 326 446
addUsed 1 326 447
assign 1 327 448
namepathGet 0 327 448
assign 1 327 449
toString 0 327 449
assign 1 327 450
new 0 327 450
assign 1 327 451
equals 1 327 451
assign 1 327 453
new 0 327 453
assign 1 327 454
isSelfGet 0 327 454
assign 1 327 455
add 1 327 455
print 0 327 456
assign 1 329 461
heldGet 0 329 461
assign 1 329 462
orgNameGet 0 329 462
assign 1 329 463
new 0 329 463
assign 1 329 464
notEquals 1 329 464
assign 1 330 466
new 0 330 466
assign 1 330 467
heldGet 0 330 467
assign 1 330 468
nameGet 0 330 468
assign 1 330 469
add 1 330 469
assign 1 330 470
new 0 330 470
assign 1 330 471
add 1 330 471
assign 1 330 472
toString 0 330 472
assign 1 330 473
add 1 330 473
assign 1 330 474
new 2 330 474
throw 1 330 475
assign 1 335 481
isFirstGet 0 335 481
assign 1 335 483
containerGet 0 335 483
assign 1 335 484
typenameGet 0 335 484
assign 1 335 485
CALLGet 0 335 485
assign 1 335 486
equals 1 335 486
assign 1 0 488
assign 1 0 491
assign 1 0 495
assign 1 335 498
containerGet 0 335 498
assign 1 335 499
heldGet 0 335 499
assign 1 335 500
orgNameGet 0 335 500
assign 1 335 501
new 0 335 501
assign 1 335 502
equals 1 335 502
assign 1 0 504
assign 1 0 507
assign 1 0 511
assign 1 335 514
containerGet 0 335 514
assign 1 335 515
secondGet 0 335 515
assign 1 335 516
typenameGet 0 335 516
assign 1 335 517
VARGet 0 335 517
assign 1 335 518
equals 1 335 518
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 336 530
containerGet 0 336 530
assign 1 336 531
secondGet 0 336 531
assign 1 336 532
heldGet 0 336 532
assign 1 338 533
isTypedGet 0 338 533
assign 1 340 535
new 0 340 535
assign 1 341 536
isTypedGet 0 341 536
isTypedSet 1 341 537
assign 1 342 538
namepathGet 0 342 538
namepathSet 1 342 539
return 1 0 562
assign 1 0 565
return 1 0 569
assign 1 0 572
return 1 0 576
assign 1 0 579
return 1 0 583
assign 1 0 586
return 1 0 590
assign 1 0 593
return 1 0 597
assign 1 0 600
return 1 0 604
assign 1 0 607
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2001798761: return bem_nlGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 304475661: return bem_tvmapGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 1344145980: return bem_processTmps_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
case 265089021: return bem_rmapGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 315557914: return bem_tvmapSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 276171274: return bem_rmapSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_6_BuildVisitRewind();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_6_BuildVisitRewind.bevs_inst = (BEC_5_5_6_BuildVisitRewind)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_6_BuildVisitRewind.bevs_inst;
}
}
