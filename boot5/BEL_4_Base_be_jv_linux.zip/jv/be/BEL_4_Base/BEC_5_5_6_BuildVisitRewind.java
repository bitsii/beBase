package be.BEL_4_Base;
/* IO:File: source/build/Pass12.be */
public class BEC_5_5_6_BuildVisitRewind extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_6_BuildVisitRewind() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(1));
private static byte[] bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_1, 11));
private static byte[] bels_2 = {0x5F,0x30};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_2, 2));
private static byte[] bels_3 = {0x5F,0x30};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_3, 2));
private static byte[] bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_6 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_6, 27));
private static byte[] bels_7 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_8 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_8, 13));
private static byte[] bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_9, 10));
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_5_5_6_BuildVisitRewind bevs_inst;
public BEC_6_6_SystemObject bevp_tvmap;
public BEC_6_6_SystemObject bevp_rmap;
public BEC_6_6_SystemObject bevp_inClass;
public BEC_6_6_SystemObject bevp_inClassNp;
public BEC_6_6_SystemObject bevp_inClassSyn;
public BEC_6_6_SystemObject bevp_nl;
public BEC_6_6_SystemObject bevp_emitter;
public BEC_5_5_6_BuildVisitRewind bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_8_BuildNamePath bevl_fgnp = null;
BEC_4_6_TextString bevl_fgcn = null;
BEC_4_6_TextString bevl_fgin = null;
BEC_5_8_BuildClassSyn bevl_fgsy = null;
BEC_5_6_BuildMtdSyn bevl_fgms = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_79_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_80_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_83_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_84_tmpvar_phold = null;
BEC_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_86_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_12_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(654935401, BEL_4_Base.bevn_wasForeachGennedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 247 */
 else  /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 247 */ {
bevt_15_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_20_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(6, bels_0));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 249 */
 else  /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 249 */ {
bevt_22_tmpvar_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 249 */
 else  /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 249 */ {
bevt_26_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_firstGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 251 */ {
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_firstGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 251 */ {
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_firstGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_fgnp = (BEC_5_8_BuildNamePath) bevt_32_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_4_6_TextString) bevt_35_tmpvar_phold.bem_lastGet_0();
bevt_39_tmpvar_phold = bevo_0;
bevt_40_tmpvar_phold = bevo_1;
bevt_38_tmpvar_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpvar_phold, bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_lowerValue_0();
bevt_42_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevt_41_tmpvar_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_add_1(bevt_41_tmpvar_phold);
bevt_43_tmpvar_phold = bevo_2;
bevl_fgin = bevt_36_tmpvar_phold.bem_add_1(bevt_43_tmpvar_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpvar_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpvar_phold = bevo_3;
bevt_45_tmpvar_phold = bevl_fgin.bem_add_1(bevt_46_tmpvar_phold);
bevl_fgms = (BEC_5_6_BuildMtdSyn) bevt_44_tmpvar_phold.bem_get_1(bevt_45_tmpvar_phold);
if (bevl_fgms == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_48_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_48_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_fgin);
bevt_49_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = bevo_4;
bevt_50_tmpvar_phold = bevl_fgin.bem_add_1(bevt_51_tmpvar_phold);
bevt_49_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpvar_phold);
} /* Line: 261 */
} /* Line: 258 */
} /* Line: 251 */
} /* Line: 249 */
bevt_53_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_equals_1(bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevp_inClass = beva_node;
bevt_55_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_56_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 269 */
bevt_58_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_equals_1(bevt_59_tmpvar_phold);
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevp_tvmap = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_9_3_ContainerMap()).bem_new_0();
} /* Line: 273 */
 else  /* Line: 271 */ {
bevt_61_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_equals_1(bevt_62_tmpvar_phold);
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 274 */ {
bevt_64_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 274 */
 else  /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 274 */ {
bevt_66_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_67_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_65_tmpvar_phold, bevt_67_tmpvar_phold);
bevt_69_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_68_tmpvar_phold);
if (bevl_ll == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevl_ll = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_rmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_71_tmpvar_phold, bevl_ll);
} /* Line: 279 */
bevl_ll.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 281 */
 else  /* Line: 271 */ {
bevt_74_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bem_equals_1(bevt_75_tmpvar_phold);
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_77_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpvar_phold == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
bevt_80_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_containerGet_0();
if (bevt_79_tmpvar_phold == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
bevt_84_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_containerGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_typenameGet_0();
bevt_85_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_equals_1(bevt_85_tmpvar_phold);
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
this.bem_processTmps_0();
} /* Line: 284 */
} /* Line: 271 */
} /* Line: 271 */
bevt_86_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_processTmps_0() throws Throwable {
BEC_6_6_SystemObject bevl_foundone = null;
BEC_6_6_SystemObject bevl_targ = null;
BEC_6_6_SystemObject bevl_tvar = null;
BEC_6_6_SystemObject bevl_tcall = null;
BEC_5_8_BuildClassSyn bevl_syn = null;
BEC_6_6_SystemObject bevl_targNp = null;
BEC_6_6_SystemObject bevl_mtdc = null;
BEC_6_6_SystemObject bevl_ovar = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_nv = null;
BEC_6_6_SystemObject bevl_nvname = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_k = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_91_tmpvar_phold = null;
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
while (true)
 /* Line: 298 */ {
if (bevl_foundone != null && bevl_foundone instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_foundone).bevi_bool) /* Line: 298 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(2145224760, BEL_4_Base.bevn_valueIteratorGet_0);
while (true)
 /* Line: 300 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 300 */ {
bevl_nv = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_nv.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevl_nvname = bevl_nv.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_nvname);
bevt_0_tmpvar_loop = bevl_ll.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 308 */ {
bevt_11_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 308 */ {
bevl_k = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_15_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_20_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(6, bels_4));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_25_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_26_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_26_tmpvar_phold);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_27_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevl_tcall = bevt_27_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targNp = null;
bevt_30_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_29_tmpvar_phold == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_31_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_targNp = bevt_31_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
} /* Line: 314 */
 else  /* Line: 315 */ {
bevt_32_tmpvar_phold = bevl_tcall.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_targ = bevt_32_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_34_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_tvar = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 321 */
 else  /* Line: 322 */ {
bevt_36_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_38_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_37_tmpvar_phold);
bevl_tvar = bevt_35_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 323 */
bevt_39_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 326 */ {
bevl_targNp = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 327 */
} /* Line: 326 */
if (bevl_targNp == null) {
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 330 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_41_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_43_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_41_tmpvar_phold.bem_get_1(bevt_42_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 334 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevl_ovar == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 337 */ {
bevt_46_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 337 */
 else  /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 337 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_47_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 340 */ {
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_targNp);
} /* Line: 341 */
 else  /* Line: 342 */ {
bevt_48_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_48_tmpvar_phold);
} /* Line: 343 */
bevt_49_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = bevp_inClass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_50_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_51_tmpvar_phold);
bevt_54_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(4, bels_5));
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 347 */ {
bevt_57_tmpvar_phold = bevo_5;
bevt_58_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 347 */
} /* Line: 347 */
} /* Line: 337 */
 else  /* Line: 334 */ {
bevt_61_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_62_tmpvar_phold = (new BEC_4_6_TextString(6, bels_7));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_62_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 349 */ {
bevt_67_tmpvar_phold = bevo_6;
bevt_69_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = bevo_7;
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_add_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_targNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_add_1(bevt_71_tmpvar_phold);
bevt_63_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpvar_phold, bevl_tcall);
throw new be.BELS_Base.BECS_ThrowBack(bevt_63_tmpvar_phold);
} /* Line: 350 */
} /* Line: 334 */
} /* Line: 334 */
} /* Line: 330 */
 else  /* Line: 309 */ {
bevt_72_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_72_tmpvar_phold != null && bevt_72_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_72_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_75_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_80_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_81_tmpvar_phold = (new BEC_4_6_TextString(6, bels_10));
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_85_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_84_tmpvar_phold = bevt_85_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_86_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_88_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targ = bevt_87_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_89_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_89_tmpvar_phold != null && bevt_89_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_89_tmpvar_phold).bevi_bool) /* Line: 358 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_90_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_targ.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_91_tmpvar_phold);
} /* Line: 363 */
} /* Line: 358 */
} /* Line: 309 */
} /* Line: 309 */
 else  /* Line: 308 */ {
break;
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 303 */
 else  /* Line: 300 */ {
break;
} /* Line: 300 */
} /* Line: 300 */
} /* Line: 300 */
 else  /* Line: 298 */ {
break;
} /* Line: 298 */
} /* Line: 298 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_tvmapGet_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public BEC_6_6_SystemObject bem_tvmapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_tvmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_rmapGet_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public BEC_6_6_SystemObject bem_rmapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_rmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClass = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {247, 247, 247, 247, 247, 0, 0, 0, 249, 249, 249, 249, 249, 249, 249, 249, 249, 0, 0, 0, 249, 0, 0, 0, 251, 251, 251, 251, 251, 251, 251, 251, 251, 0, 0, 0, 252, 252, 252, 252, 253, 253, 254, 254, 254, 254, 254, 254, 254, 254, 254, 256, 257, 257, 257, 257, 258, 258, 260, 260, 261, 261, 261, 261, 266, 266, 266, 267, 268, 268, 269, 269, 271, 271, 271, 272, 273, 274, 274, 274, 274, 274, 0, 0, 0, 275, 275, 275, 275, 276, 276, 276, 277, 277, 278, 279, 279, 279, 281, 282, 282, 282, 282, 282, 282, 0, 0, 0, 282, 282, 282, 282, 0, 0, 0, 282, 282, 282, 282, 282, 0, 0, 0, 284, 286, 286, 290, 299, 300, 300, 301, 303, 303, 306, 307, 308, 0, 308, 308, 309, 309, 309, 309, 309, 0, 0, 0, 309, 309, 309, 309, 309, 0, 0, 0, 309, 309, 309, 309, 309, 0, 0, 0, 311, 311, 312, 313, 313, 313, 313, 314, 314, 316, 316, 320, 320, 321, 323, 323, 323, 323, 323, 326, 327, 330, 330, 332, 333, 333, 333, 333, 334, 334, 336, 337, 337, 337, 0, 0, 0, 338, 340, 341, 343, 343, 345, 345, 346, 346, 346, 347, 347, 347, 347, 347, 347, 347, 347, 349, 349, 349, 349, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 355, 355, 355, 355, 355, 0, 0, 0, 355, 355, 355, 355, 355, 0, 0, 0, 355, 355, 355, 355, 355, 0, 0, 0, 356, 356, 356, 358, 360, 362, 362, 363, 363, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {131, 132, 133, 135, 136, 138, 141, 145, 148, 149, 150, 151, 153, 154, 155, 156, 157, 159, 162, 166, 169, 171, 174, 178, 181, 182, 183, 184, 185, 187, 188, 189, 190, 192, 195, 199, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 227, 228, 229, 230, 231, 232, 233, 238, 239, 240, 242, 243, 244, 245, 246, 248, 249, 250, 252, 253, 256, 257, 258, 260, 261, 263, 266, 270, 273, 274, 275, 276, 277, 278, 279, 280, 285, 286, 287, 288, 289, 291, 294, 295, 296, 298, 299, 304, 305, 308, 312, 315, 316, 317, 322, 323, 326, 330, 333, 334, 335, 336, 337, 339, 342, 346, 349, 353, 354, 462, 466, 467, 470, 472, 473, 474, 476, 477, 478, 478, 481, 483, 484, 486, 487, 488, 489, 491, 494, 498, 501, 502, 503, 504, 505, 507, 510, 514, 517, 518, 519, 520, 521, 523, 526, 530, 533, 534, 535, 536, 537, 538, 543, 544, 545, 548, 549, 550, 551, 553, 556, 557, 558, 559, 560, 562, 564, 567, 572, 573, 574, 575, 576, 577, 578, 583, 584, 585, 590, 591, 593, 596, 600, 603, 604, 606, 609, 610, 612, 613, 614, 615, 616, 617, 618, 619, 620, 622, 623, 624, 625, 630, 631, 632, 633, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 650, 652, 653, 654, 655, 657, 660, 664, 667, 668, 669, 670, 671, 673, 676, 680, 683, 684, 685, 686, 687, 689, 692, 696, 699, 700, 701, 702, 704, 705, 706, 707, 708, 731, 734, 738, 741, 745, 748, 752, 755, 759, 762, 766, 769, 773, 776};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 247 131
typenameGet 0 247 131
assign 1 247 132
CALLGet 0 247 132
assign 1 247 133
equals 1 247 133
assign 1 247 135
heldGet 0 247 135
assign 1 247 136
wasForeachGennedGet 0 247 136
assign 1 0 138
assign 1 0 141
assign 1 0 145
assign 1 249 148
containerGet 0 249 148
assign 1 249 149
typenameGet 0 249 149
assign 1 249 150
CALLGet 0 249 150
assign 1 249 151
equals 1 249 151
assign 1 249 153
containerGet 0 249 153
assign 1 249 154
heldGet 0 249 154
assign 1 249 155
orgNameGet 0 249 155
assign 1 249 156
new 0 249 156
assign 1 249 157
equals 1 249 157
assign 1 0 159
assign 1 0 162
assign 1 0 166
assign 1 249 169
isSecondGet 0 249 169
assign 1 0 171
assign 1 0 174
assign 1 0 178
assign 1 251 181
containedGet 0 251 181
assign 1 251 182
firstGet 0 251 182
assign 1 251 183
typenameGet 0 251 183
assign 1 251 184
VARGet 0 251 184
assign 1 251 185
equals 1 251 185
assign 1 251 187
containedGet 0 251 187
assign 1 251 188
firstGet 0 251 188
assign 1 251 189
heldGet 0 251 189
assign 1 251 190
isTypedGet 0 251 190
assign 1 0 192
assign 1 0 195
assign 1 0 199
assign 1 252 202
containedGet 0 252 202
assign 1 252 203
firstGet 0 252 203
assign 1 252 204
heldGet 0 252 204
assign 1 252 205
namepathGet 0 252 205
assign 1 253 206
stepsGet 0 253 206
assign 1 253 207
lastGet 0 253 207
assign 1 254 208
new 0 254 208
assign 1 254 209
new 0 254 209
assign 1 254 210
substring 2 254 210
assign 1 254 211
lowerValue 0 254 211
assign 1 254 212
new 0 254 212
assign 1 254 213
substring 1 254 213
assign 1 254 214
add 1 254 214
assign 1 254 215
new 0 254 215
assign 1 254 216
add 1 254 216
assign 1 256 217
getSynNp 1 256 217
assign 1 257 218
mtdMapGet 0 257 218
assign 1 257 219
new 0 257 219
assign 1 257 220
add 1 257 220
assign 1 257 221
get 1 257 221
assign 1 258 222
def 1 258 227
assign 1 260 228
heldGet 0 260 228
orgNameSet 1 260 229
assign 1 261 230
heldGet 0 261 230
assign 1 261 231
new 0 261 231
assign 1 261 232
add 1 261 232
nameSet 1 261 233
assign 1 266 238
typenameGet 0 266 238
assign 1 266 239
CLASSGet 0 266 239
assign 1 266 240
equals 1 266 240
assign 1 267 242
assign 1 268 243
heldGet 0 268 243
assign 1 268 244
namepathGet 0 268 244
assign 1 269 245
heldGet 0 269 245
assign 1 269 246
synGet 0 269 246
assign 1 271 248
typenameGet 0 271 248
assign 1 271 249
METHODGet 0 271 249
assign 1 271 250
equals 1 271 250
assign 1 272 252
new 0 272 252
assign 1 273 253
new 0 273 253
assign 1 274 256
typenameGet 0 274 256
assign 1 274 257
VARGet 0 274 257
assign 1 274 258
equals 1 274 258
assign 1 274 260
heldGet 0 274 260
assign 1 274 261
isTmpVarGet 0 274 261
assign 1 0 263
assign 1 0 266
assign 1 0 270
assign 1 275 273
heldGet 0 275 273
assign 1 275 274
nameGet 0 275 274
assign 1 275 275
heldGet 0 275 275
put 2 275 276
assign 1 276 277
heldGet 0 276 277
assign 1 276 278
nameGet 0 276 278
assign 1 276 279
get 1 276 279
assign 1 277 280
undef 1 277 285
assign 1 278 286
new 0 278 286
assign 1 279 287
heldGet 0 279 287
assign 1 279 288
nameGet 0 279 288
put 2 279 289
addValue 1 281 291
assign 1 282 294
typenameGet 0 282 294
assign 1 282 295
RBRACESGet 0 282 295
assign 1 282 296
equals 1 282 296
assign 1 282 298
containerGet 0 282 298
assign 1 282 299
def 1 282 304
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 282 315
containerGet 0 282 315
assign 1 282 316
containerGet 0 282 316
assign 1 282 317
def 1 282 322
assign 1 0 323
assign 1 0 326
assign 1 0 330
assign 1 282 333
containerGet 0 282 333
assign 1 282 334
containerGet 0 282 334
assign 1 282 335
typenameGet 0 282 335
assign 1 282 336
METHODGet 0 282 336
assign 1 282 337
equals 1 282 337
assign 1 0 339
assign 1 0 342
assign 1 0 346
processTmps 0 284 349
assign 1 286 353
nextDescendGet 0 286 353
return 1 286 354
assign 1 290 462
new 0 290 462
assign 1 299 466
new 0 299 466
assign 1 300 467
valueIteratorGet 0 300 467
assign 1 300 470
hasNextGet 0 300 470
assign 1 301 472
nextGet 0 301 472
assign 1 303 473
isTypedGet 0 303 473
assign 1 303 474
not 0 303 474
assign 1 306 476
nameGet 0 306 476
assign 1 307 477
get 1 307 477
assign 1 308 478
iteratorGet 0 0 478
assign 1 308 481
hasNextGet 0 308 481
assign 1 308 483
nextGet 0 308 483
assign 1 309 484
isFirstGet 0 309 484
assign 1 309 486
containerGet 0 309 486
assign 1 309 487
typenameGet 0 309 487
assign 1 309 488
CALLGet 0 309 488
assign 1 309 489
equals 1 309 489
assign 1 0 491
assign 1 0 494
assign 1 0 498
assign 1 309 501
containerGet 0 309 501
assign 1 309 502
heldGet 0 309 502
assign 1 309 503
orgNameGet 0 309 503
assign 1 309 504
new 0 309 504
assign 1 309 505
equals 1 309 505
assign 1 0 507
assign 1 0 510
assign 1 0 514
assign 1 309 517
containerGet 0 309 517
assign 1 309 518
secondGet 0 309 518
assign 1 309 519
typenameGet 0 309 519
assign 1 309 520
CALLGet 0 309 520
assign 1 309 521
equals 1 309 521
assign 1 0 523
assign 1 0 526
assign 1 0 530
assign 1 311 533
containerGet 0 311 533
assign 1 311 534
secondGet 0 311 534
assign 1 312 535
assign 1 313 536
heldGet 0 313 536
assign 1 313 537
newNpGet 0 313 537
assign 1 313 538
def 1 313 543
assign 1 314 544
heldGet 0 314 544
assign 1 314 545
newNpGet 0 314 545
assign 1 316 548
containedGet 0 316 548
assign 1 316 549
firstGet 0 316 549
assign 1 320 550
heldGet 0 320 550
assign 1 320 551
isDeclaredGet 0 320 551
assign 1 321 553
heldGet 0 321 553
assign 1 323 556
ptyMapGet 0 323 556
assign 1 323 557
heldGet 0 323 557
assign 1 323 558
nameGet 0 323 558
assign 1 323 559
get 1 323 559
assign 1 323 560
memSynGet 0 323 560
assign 1 326 562
isTypedGet 0 326 562
assign 1 327 564
namepathGet 0 327 564
assign 1 330 567
def 1 330 572
assign 1 332 573
getSynNp 1 332 573
assign 1 333 574
mtdMapGet 0 333 574
assign 1 333 575
heldGet 0 333 575
assign 1 333 576
nameGet 0 333 576
assign 1 333 577
get 1 333 577
assign 1 334 578
def 1 334 583
assign 1 336 584
rsynGet 0 336 584
assign 1 337 585
def 1 337 590
assign 1 337 591
isTypedGet 0 337 591
assign 1 0 593
assign 1 0 596
assign 1 0 600
assign 1 338 603
new 0 338 603
assign 1 340 604
isSelfGet 0 340 604
namepathSet 1 341 606
assign 1 343 609
namepathGet 0 343 609
namepathSet 1 343 610
assign 1 345 612
isTypedGet 0 345 612
isTypedSet 1 345 613
assign 1 346 614
heldGet 0 346 614
assign 1 346 615
namepathGet 0 346 615
addUsed 1 346 616
assign 1 347 617
namepathGet 0 347 617
assign 1 347 618
toString 0 347 618
assign 1 347 619
new 0 347 619
assign 1 347 620
equals 1 347 620
assign 1 347 622
new 0 347 622
assign 1 347 623
isSelfGet 0 347 623
assign 1 347 624
add 1 347 624
print 0 347 625
assign 1 349 630
heldGet 0 349 630
assign 1 349 631
orgNameGet 0 349 631
assign 1 349 632
new 0 349 632
assign 1 349 633
notEquals 1 349 633
assign 1 350 635
new 0 350 635
assign 1 350 636
heldGet 0 350 636
assign 1 350 637
nameGet 0 350 637
assign 1 350 638
add 1 350 638
assign 1 350 639
new 0 350 639
assign 1 350 640
add 1 350 640
assign 1 350 641
toString 0 350 641
assign 1 350 642
add 1 350 642
assign 1 350 643
new 2 350 643
throw 1 350 644
assign 1 355 650
isFirstGet 0 355 650
assign 1 355 652
containerGet 0 355 652
assign 1 355 653
typenameGet 0 355 653
assign 1 355 654
CALLGet 0 355 654
assign 1 355 655
equals 1 355 655
assign 1 0 657
assign 1 0 660
assign 1 0 664
assign 1 355 667
containerGet 0 355 667
assign 1 355 668
heldGet 0 355 668
assign 1 355 669
orgNameGet 0 355 669
assign 1 355 670
new 0 355 670
assign 1 355 671
equals 1 355 671
assign 1 0 673
assign 1 0 676
assign 1 0 680
assign 1 355 683
containerGet 0 355 683
assign 1 355 684
secondGet 0 355 684
assign 1 355 685
typenameGet 0 355 685
assign 1 355 686
VARGet 0 355 686
assign 1 355 687
equals 1 355 687
assign 1 0 689
assign 1 0 692
assign 1 0 696
assign 1 356 699
containerGet 0 356 699
assign 1 356 700
secondGet 0 356 700
assign 1 356 701
heldGet 0 356 701
assign 1 358 702
isTypedGet 0 358 702
assign 1 360 704
new 0 360 704
assign 1 362 705
isTypedGet 0 362 705
isTypedSet 1 362 706
assign 1 363 707
namepathGet 0 363 707
namepathSet 1 363 708
return 1 0 731
assign 1 0 734
return 1 0 738
assign 1 0 741
return 1 0 745
assign 1 0 748
return 1 0 752
assign 1 0 755
return 1 0 759
assign 1 0 762
return 1 0 766
assign 1 0 769
return 1 0 773
assign 1 0 776
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2001798761: return bem_nlGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 304475661: return bem_tvmapGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 1344145980: return bem_processTmps_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
case 265089021: return bem_rmapGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 315557914: return bem_tvmapSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 276171274: return bem_rmapSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_6_BuildVisitRewind();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_6_BuildVisitRewind.bevs_inst = (BEC_5_5_6_BuildVisitRewind)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_6_BuildVisitRewind.bevs_inst;
}
}
