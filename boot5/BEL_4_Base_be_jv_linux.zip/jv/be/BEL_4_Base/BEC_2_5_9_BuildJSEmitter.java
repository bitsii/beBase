package be.BEL_4_Base;
/* IO:File: source/build/JSEmitter.be */
public class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6A,0x73};
private static byte[] bels_1 = {0x2E,0x6A,0x73};
private static byte[] bels_2 = {};
private static byte[] bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bels_7 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_8 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bels_9 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_9, 5));
private static byte[] bels_10 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bels_11 = {0x29,0x20,0x7B};
private static byte[] bels_12 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_12, 41));
private static byte[] bels_13 = {0x29,0x29};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bels_15 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_18 = {0x28,0x29,0x3B};
private static byte[] bels_19 = {0x7D};
private static byte[] bels_20 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bels_21 = {0x2C,0x20};
private static byte[] bels_22 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_23 = {0x5D,0x3B};
private static byte[] bels_24 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bels_25 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_26 = {0x7D};
private static byte[] bels_27 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_28 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_29 = {0x3B};
private static byte[] bels_30 = {0x7D};
private static byte[] bels_31 = {0x5D,0x3B};
private static byte[] bels_32 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_32, 10));
private static byte[] bels_33 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_34 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_35 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bels_36 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x28,0x29};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_37, 2));
private static byte[] bels_38 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_39 = {0x29,0x3B};
private static byte[] bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_41 = {0x29,0x3B};
private static byte[] bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_43 = {0x2C,0x20};
private static byte[] bels_44 = {0x29,0x3B};
private static byte[] bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_46 = {0x2C,0x20};
private static byte[] bels_47 = {0x29,0x3B};
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bels_51 = {};
private static byte[] bels_52 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_53 = {0x28,0x29,0x3B};
private static byte[] bels_54 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bels_55 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bels_56 = {0x22,0x3B};
private static byte[] bels_57 = {};
private static byte[] bels_58 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_59 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_60 = {0x28,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x37,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x28,0x29,0x29,0x2E,0x62,0x65,0x6D,0x5F,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_60, 62));
private static byte[] bels_61 = {0x76,0x61,0x72,0x20};
private static byte[] bels_62 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bels_63 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_63, 25));
private static byte[] bels_64 = {0x20,0x7B};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_64, 2));
private static byte[] bels_65 = {0x74,0x68,0x69,0x73};
private static byte[] bels_66 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_66, 17));
private static byte[] bels_67 = {0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_67, 3));
private static byte[] bels_68 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_68, 38));
private static byte[] bels_69 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_69, 4));
private static byte[] bels_70 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_70, 21));
private static byte[] bels_71 = {0x29};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_71, 1));
private static byte[] bels_72 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_72, 4));
private static byte[] bels_73 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_73, 23));
private static byte[] bels_74 = {0x29};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_74, 1));
private static byte[] bels_75 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_19 = (new BEC_2_4_6_TextString(bels_75, 4));
private static byte[] bels_76 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bevo_20 = (new BEC_2_4_6_TextString(bels_76, 27));
private static byte[] bels_77 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_77, 22));
private static byte[] bels_78 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bels_78, 2));
private static byte[] bels_79 = {0x29};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bels_79, 1));
private static byte[] bels_80 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_24 = (new BEC_2_4_6_TextString(bels_80, 4));
private static byte[] bels_81 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bevo_25 = (new BEC_2_4_6_TextString(bels_81, 32));
private static byte[] bels_82 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_26 = (new BEC_2_4_6_TextString(bels_82, 22));
private static byte[] bels_83 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_27 = (new BEC_2_4_6_TextString(bels_83, 2));
private static byte[] bels_84 = {0x29};
private static BEC_2_4_6_TextString bevo_28 = (new BEC_2_4_6_TextString(bels_84, 1));
private static byte[] bels_85 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_86 = {0x76,0x61,0x72,0x20};
private static byte[] bels_87 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_88 = {0x7D};
private static byte[] bels_89 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_29 = (new BEC_2_4_6_TextString(bels_89, 5));
private static byte[] bels_90 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_30 = (new BEC_2_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {};
private static byte[] bels_92 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_31 = (new BEC_2_4_6_TextString(bels_92, 11));
private static byte[] bels_93 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_32 = (new BEC_2_4_6_TextString(bels_93, 5));
private static byte[] bels_94 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bevo_33 = (new BEC_2_4_6_TextString(bels_94, 3));
private static byte[] bels_95 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_34 = (new BEC_2_4_6_TextString(bels_95, 11));
private static byte[] bels_96 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_35 = (new BEC_2_4_6_TextString(bels_96, 4));
private static byte[] bels_97 = {0x3B};
private static BEC_2_4_6_TextString bevo_36 = (new BEC_2_4_6_TextString(bels_97, 1));
private static byte[] bels_98 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_99 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_100 = {};
private static byte[] bels_101 = {};
private static byte[] bels_102 = {};
private static byte[] bels_103 = {};
private static byte[] bels_104 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_105 = {};
private static byte[] bels_106 = {};
private static byte[] bels_107 = {};
private static byte[] bels_108 = {};
private static byte[] bels_109 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bevo_37 = (new BEC_2_4_6_TextString(bels_109, 7));
private static byte[] bels_110 = {0x3A,0x20};
private static BEC_2_4_6_TextString bevo_38 = (new BEC_2_4_6_TextString(bels_110, 2));
private static byte[] bels_111 = {};
private static byte[] bels_112 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_113 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_39 = (new BEC_2_4_6_TextString(bels_113, 22));
private static byte[] bels_114 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bevo_40 = (new BEC_2_4_6_TextString(bels_114, 5));
private static byte[] bels_115 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_116 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bels_117 = {0x29,0x20,0x7B};
private static byte[] bels_118 = {};
private static byte[] bels_119 = {0x5F};
private static BEC_2_4_6_TextString bevo_41 = (new BEC_2_4_6_TextString(bels_119, 1));
private static byte[] bels_120 = {0x62,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_42 = (new BEC_2_4_6_TextString(bels_120, 3));
public static BEC_2_5_9_BuildJSEmitter bevs_inst;
public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_6_6_SystemObject bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(44, bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(45, bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bels_6));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(38, bels_7));
bevt_2_tmpvar_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_4_tmpvar_phold = this.bem_formTarg_1(bevt_5_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpvar_phold.bem_add_1(bevt_1_tmpvar_phold);
bevp_methodCatch = bevp_methodCatch.bem_increment_0();
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_10));
bevt_4_tmpvar_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_11));
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_firstGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpvar_phold = bevo_1;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_8_tmpvar_phold, bevt_12_tmpvar_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_2_4_6_TextString beva_belsBase) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = beva_sdec.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_4_6_TextString(22, bels_14));
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_15));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(37, bels_16));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_17));
bevt_6_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_relEmitName_1(bevt_12_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_13_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_18));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_19));
bevt_14_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_14_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_5_ContainerArray bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_4_6_TextString(26, bels_20));
bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevl_first = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = bevl_ptyList.bem_arrayIteratorGet_0();
while (true)
 /* Line: 77 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpvar_loop.bem_nextGet_0();
if (bevl_first.bevi_bool) /* Line: 78 */ {
bevl_first = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 79 */
 else  /* Line: 80 */ {
bevt_6_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_21));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpvar_phold);
} /* Line: 81 */
bevt_9_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_22));
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold.bem_addValue_1(bevp_q);
} /* Line: 83 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
bevt_13_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_23));
bevt_12_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_12_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(50, bels_24));
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_25));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_26));
bevt_9_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_2_4_6_TextString(41, bels_27));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_11_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_28));
bevt_17_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_29));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_30));
bevt_20_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevp_nl);
this.bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_31));
bevt_0_tmpvar_phold = beva_sdec.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevt_2_tmpvar_phold = bevo_3;
bevt_3_tmpvar_phold = beva_v.bem_nameGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /* Line: 128 */
bevt_4_tmpvar_phold = super.bem_nameForVar_1(beva_v);
return bevt_4_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_typeInstances = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_107_tmpvar_phold = null;
bevl_libe = this.bem_getLibOutput_0();
bevl_typeInstances = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 142 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(50, bels_33));
bevt_8_tmpvar_phold = bevl_typeInstances.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_12_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_13_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_34));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_17_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_relEmitName_1(bevt_18_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_19_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_35));
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 148 */ {
bevt_24_tmpvar_phold = bevo_4;
bevt_28_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpvar_phold);
bevt_29_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_relEmitName_1(bevt_29_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_30_tmpvar_phold = bevo_5;
bevl_nc = bevt_23_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_34_tmpvar_phold = (new BEC_2_4_6_TextString(75, bels_38));
bevt_33_tmpvar_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_39));
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 157 */ {
bevt_42_tmpvar_phold = (new BEC_2_4_6_TextString(73, bels_40));
bevt_41_tmpvar_phold = bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_41));
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_addValue_1(bevt_43_tmpvar_phold);
bevt_39_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 158 */
} /* Line: 157 */
} /* Line: 148 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpvar_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpvar_loop = bevt_44_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 166 */ {
bevt_45_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 166 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_53_tmpvar_phold = (new BEC_2_4_6_TextString(52, bels_42));
bevt_52_tmpvar_phold = bevl_smap.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_55_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bem_quoteGet_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_addValue_1(bevt_54_tmpvar_phold);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_quoteGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_58_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_43));
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_60_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_44));
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_46_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpvar_phold = (new BEC_2_4_6_TextString(53, bels_45));
bevt_67_tmpvar_phold = bevl_smap.bem_addValue_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_quoteGet_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_addValue_1(bevt_69_tmpvar_phold);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bem_quoteGet_0();
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_addValue_1(bevt_71_tmpvar_phold);
bevt_73_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_46));
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_addValue_1(bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_addValue_1(bevt_74_tmpvar_phold);
bevt_75_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_47));
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bem_addValue_1(bevt_75_tmpvar_phold);
bevt_61_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 169 */
 else  /* Line: 166 */ {
break;
} /* Line: 166 */
} /* Line: 166 */
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_typeInstances);
bevt_78_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bem_sizeGet_0();
bevt_79_tmpvar_phold = bevo_6;
if (bevt_77_tmpvar_phold.bevi_int == bevt_79_tmpvar_phold.bevi_int) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 178 */ {
bevt_81_tmpvar_phold = (new BEC_2_4_6_TextString(112, bels_48));
bevt_80_tmpvar_phold = bevl_libInit.bem_addValue_1(bevt_81_tmpvar_phold);
bevt_80_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpvar_phold = (new BEC_2_4_6_TextString(114, bels_49));
bevt_82_tmpvar_phold = bevl_libInit.bem_addValue_1(bevt_83_tmpvar_phold);
bevt_82_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpvar_phold = (new BEC_2_4_6_TextString(99, bels_50));
bevt_84_tmpvar_phold = bevl_libInit.bem_addValue_1(bevt_85_tmpvar_phold);
bevt_84_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 181 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpvar_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpvar_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bels_51));
bevt_90_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_52));
bevt_89_tmpvar_phold = bevl_main.bem_addValue_1(bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_addValue_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_53));
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bem_addValue_1(bevt_92_tmpvar_phold);
bevt_87_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpvar_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_95_tmpvar_phold = (new BEC_2_4_6_TextString(56, bels_54));
bevt_94_tmpvar_phold = bevl_main.bem_addValue_1(bevt_95_tmpvar_phold);
bevt_94_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 195 */
bevt_99_tmpvar_phold = (new BEC_2_4_6_TextString(52, bels_55));
bevt_98_tmpvar_phold = bevl_main.bem_addValue_1(bevt_99_tmpvar_phold);
bevt_101_tmpvar_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_addValue_1(bevt_100_tmpvar_phold);
bevt_102_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_56));
bevt_96_tmpvar_phold = bevt_97_tmpvar_phold.bem_addValue_1(bevt_102_tmpvar_phold);
bevt_96_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (new BEC_2_4_6_TextString(0, bels_57));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpvar_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_105_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_58));
bevt_104_tmpvar_phold = bevl_main.bem_addValue_1(bevt_105_tmpvar_phold);
bevt_104_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpvar_phold = (new BEC_2_4_6_TextString(16, bels_59));
bevt_106_tmpvar_phold = bevl_main.bem_addValue_1(bevt_107_tmpvar_phold);
bevt_106_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 205 */
bevl_libe.bem_write_1(bevl_main);
this.bem_finishLibOutput_1(bevl_libe);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_procStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_7;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_decForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 218 */ {
} /* Line: 218 */
 else  /* Line: 220 */ {
bevt_2_tmpvar_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_61));
beva_b.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 222 */
bevt_4_tmpvar_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 224 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_62));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpvar_phold = bevo_9;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_65));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_parent);
bevt_5_tmpvar_phold = bevo_11;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevl_extstr = bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevl_extstr.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_12;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevl_extstr = bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_13;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_14;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_15;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_17;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 256 */ {
bevt_8_tmpvar_phold = bevo_19;
bevt_10_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_20;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_21;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(beva_belsName);
bevt_14_tmpvar_phold = bevo_22;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_lisz);
bevt_15_tmpvar_phold = bevo_23;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /* Line: 257 */
bevt_24_tmpvar_phold = bevo_24;
bevt_26_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_25;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = bevo_26;
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(beva_belsName);
bevt_30_tmpvar_phold = bevo_27;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(beva_lisz);
bevt_31_tmpvar_phold = bevo_28;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
return bevt_16_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classBeginGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevl_extends = this.bem_extend_1((BEC_2_4_6_TextString) bevt_1_tmpvar_phold);
} /* Line: 264 */
 else  /* Line: 265 */ {
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(24, bels_85));
bevl_extends = this.bem_extend_1(bevt_3_tmpvar_phold);
} /* Line: 266 */
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_86));
bevt_6_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_87));
bevl_begin = bevt_4_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_88));
bevt_8_tmpvar_phold = bevl_begin.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameForCall_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1796577138, BEL_4_Base.bevn_superCallGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 282 */ {
bevt_3_tmpvar_phold = bevo_29;
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 283 */
bevt_7_tmpvar_phold = bevo_30;
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
bevl_end = (new BEC_2_4_6_TextString(0, bels_91));
bevt_0_tmpvar_loop = bevp_superCalls.bem_arrayIteratorGet_0();
while (true)
 /* Line: 290 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpvar_phold = bevo_31;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_32;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevo_33;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_34;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_35;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_22_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 291 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 301 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getLibOutput_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpvar_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 317 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpvar_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_fileGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_existsGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 319 */ {
bevt_7_tmpvar_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_fileGet_0();
bevt_6_tmpvar_phold.bem_makeDirs_0();
} /* Line: 320 */
bevt_9_tmpvar_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevt_11_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_98));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_has_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevt_14_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_99));
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_get_1(bevt_15_tmpvar_phold);
bevt_0_tmpvar_loop = bevt_13_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 325 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 325 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_17_tmpvar_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpvar_phold.bem_fileGet_0();
bevt_19_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_20_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_21_tmpvar_phold = this.bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpvar_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 330 */
 else  /* Line: 325 */ {
break;
} /* Line: 325 */
} /* Line: 325 */
} /* Line: 325 */
} /* Line: 324 */
return bevp_shlibe;
} /*method end*/
public BEC_2_6_6_SystemObject bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_100));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_101));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_102));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_103));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_104));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_105));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_106));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_107));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_108));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_37;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_varName);
bevt_4_tmpvar_phold = bevo_38;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_typeName);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_111));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(31, bels_112));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
return (BEC_2_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_39;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_40;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_count);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = bevp_methods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_115));
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_116));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_117));
bevt_6_tmpvar_phold = bevp_methods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_1(BEC_2_5_11_BuildClassConfig beva_cc) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_118));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_41;
bevt_1_tmpvar_phold = beva_nameSpace.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_emitName);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_42;
bevt_2_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_6_6_SystemObject bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {27, 28, 29, 33, 35, 36, 38, 39, 43, 43, 43, 43, 43, 43, 43, 43, 47, 47, 47, 48, 49, 49, 49, 49, 49, 49, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 59, 59, 59, 59, 59, 59, 59, 63, 63, 63, 63, 63, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 66, 66, 66, 71, 71, 72, 74, 74, 74, 74, 76, 77, 0, 77, 77, 79, 81, 81, 83, 83, 83, 83, 83, 83, 87, 87, 87, 92, 92, 92, 93, 95, 95, 95, 95, 95, 98, 98, 98, 98, 100, 100, 100, 102, 102, 102, 102, 102, 105, 105, 105, 105, 105, 105, 107, 107, 107, 109, 114, 115, 116, 122, 122, 122, 127, 128, 128, 128, 128, 130, 130, 136, 138, 139, 140, 141, 142, 142, 144, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 148, 148, 148, 150, 150, 150, 150, 150, 150, 150, 150, 150, 156, 156, 156, 156, 156, 156, 157, 157, 157, 158, 158, 158, 158, 158, 158, 164, 166, 166, 0, 166, 166, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 168, 169, 169, 169, 169, 169, 169, 169, 169, 169, 169, 169, 169, 169, 169, 169, 169, 173, 175, 178, 178, 178, 178, 178, 179, 179, 179, 180, 180, 180, 181, 181, 181, 184, 185, 188, 189, 189, 190, 192, 193, 193, 193, 193, 193, 193, 193, 194, 195, 195, 195, 197, 197, 197, 197, 197, 197, 197, 197, 199, 200, 201, 202, 203, 204, 204, 204, 205, 205, 205, 207, 209, 214, 214, 214, 218, 221, 221, 221, 222, 222, 224, 224, 229, 229, 233, 233, 233, 233, 233, 233, 237, 237, 242, 242, 242, 242, 242, 242, 242, 243, 243, 243, 243, 243, 244, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 263, 263, 264, 264, 264, 266, 266, 268, 268, 268, 268, 268, 276, 276, 276, 277, 278, 282, 282, 283, 283, 283, 283, 283, 285, 285, 285, 285, 285, 289, 290, 0, 290, 290, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 293, 300, 300, 301, 303, 304, 304, 309, 309, 317, 317, 318, 319, 319, 319, 319, 319, 320, 320, 320, 322, 322, 322, 324, 324, 324, 325, 325, 325, 325, 0, 325, 325, 326, 326, 327, 327, 327, 328, 328, 329, 329, 330, 336, 340, 341, 346, 346, 350, 350, 354, 354, 358, 358, 362, 362, 366, 366, 370, 370, 375, 375, 380, 380, 384, 384, 384, 384, 384, 384, 388, 388, 392, 392, 392, 392, 392, 397, 397, 397, 397, 397, 397, 397, 402, 402, 402, 402, 402, 402, 402, 404, 406, 406, 406, 411, 411, 415, 415, 419, 419, 419, 419, 423, 423, 423, 423, 427, 428, 428, 429, 433, 434, 434, 435, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {175, 176, 177, 178, 179, 180, 181, 182, 193, 194, 195, 196, 197, 198, 199, 200, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 253, 254, 255, 256, 257, 258, 259, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 319, 320, 321, 322, 323, 324, 325, 326, 327, 327, 330, 332, 334, 337, 338, 340, 341, 342, 343, 344, 345, 351, 352, 353, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 416, 417, 418, 424, 425, 426, 435, 437, 438, 439, 440, 442, 443, 567, 568, 569, 570, 571, 572, 575, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 620, 621, 622, 623, 624, 625, 633, 634, 635, 635, 638, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 678, 679, 680, 681, 682, 683, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 715, 716, 717, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 733, 734, 735, 736, 737, 738, 740, 741, 747, 748, 749, 757, 761, 762, 767, 768, 769, 771, 772, 778, 779, 787, 788, 789, 790, 791, 792, 796, 797, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 958, 963, 964, 965, 966, 969, 970, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 994, 995, 997, 998, 999, 1000, 1001, 1003, 1004, 1005, 1006, 1007, 1036, 1037, 1037, 1040, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1071, 1076, 1081, 1082, 1084, 1085, 1086, 1090, 1091, 1122, 1127, 1128, 1129, 1130, 1131, 1132, 1137, 1138, 1139, 1140, 1142, 1143, 1144, 1145, 1146, 1147, 1149, 1150, 1151, 1152, 1152, 1155, 1157, 1158, 1159, 1160, 1161, 1162, 1163, 1164, 1165, 1166, 1167, 1175, 1178, 1179, 1184, 1185, 1189, 1190, 1194, 1195, 1199, 1200, 1204, 1205, 1209, 1210, 1214, 1215, 1219, 1220, 1224, 1225, 1233, 1234, 1235, 1236, 1237, 1238, 1242, 1243, 1250, 1251, 1252, 1253, 1254, 1263, 1264, 1265, 1266, 1267, 1268, 1269, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1295, 1296, 1300, 1301, 1307, 1308, 1309, 1310, 1316, 1317, 1318, 1319, 1324, 1325, 1326, 1327, 1332, 1333, 1334, 1335, 1338, 1341, 1345, 1348};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 27 175
new 0 27 175
assign 1 28 176
new 0 28 176
assign 1 29 177
new 0 29 177
new 1 33 178
assign 1 35 179
new 0 35 179
assign 1 36 180
new 0 36 180
assign 1 38 181
new 0 38 181
assign 1 39 182
new 0 39 182
assign 1 43 193
new 0 43 193
assign 1 43 194
addValue 1 43 194
assign 1 43 195
secondGet 0 43 195
assign 1 43 196
formTarg 1 43 196
assign 1 43 197
addValue 1 43 197
assign 1 43 198
new 0 43 198
assign 1 43 199
addValue 1 43 199
addValue 1 43 200
assign 1 47 221
new 0 47 221
assign 1 47 222
toString 0 47 222
assign 1 47 223
add 1 47 223
assign 1 48 224
increment 0 48 224
assign 1 49 225
new 0 49 225
assign 1 49 226
addValue 1 49 226
assign 1 49 227
addValue 1 49 227
assign 1 49 228
new 0 49 228
assign 1 49 229
addValue 1 49 229
addValue 1 49 230
assign 1 51 231
containedGet 0 51 231
assign 1 51 232
firstGet 0 51 232
assign 1 51 233
containedGet 0 51 233
assign 1 51 234
firstGet 0 51 234
assign 1 51 235
new 0 51 235
assign 1 51 236
add 1 51 236
assign 1 51 237
new 0 51 237
assign 1 51 238
add 1 51 238
assign 1 51 239
finalAssign 3 51 239
addValue 1 51 240
assign 1 59 253
emitNameGet 0 59 253
assign 1 59 254
addValue 1 59 254
assign 1 59 255
new 0 59 255
assign 1 59 256
addValue 1 59 256
assign 1 59 257
addValue 1 59 257
assign 1 59 258
new 0 59 258
addValue 1 59 259
assign 1 63 279
emitNameGet 0 63 279
assign 1 63 280
addValue 1 63 280
assign 1 63 281
new 0 63 281
assign 1 63 282
addValue 1 63 282
addValue 1 63 283
assign 1 64 284
new 0 64 284
assign 1 64 285
addValue 1 64 285
assign 1 64 286
heldGet 0 64 286
assign 1 64 287
namepathGet 0 64 287
assign 1 64 288
getClassConfig 1 64 288
assign 1 64 289
libNameGet 0 64 289
assign 1 64 290
relEmitName 1 64 290
assign 1 64 291
addValue 1 64 291
assign 1 64 292
new 0 64 292
assign 1 64 293
addValue 1 64 293
addValue 1 64 294
assign 1 66 295
new 0 66 295
assign 1 66 296
addValue 1 66 296
addValue 1 66 297
assign 1 71 319
heldGet 0 71 319
assign 1 71 320
synGet 0 71 320
assign 1 72 321
ptyListGet 0 72 321
assign 1 74 322
emitNameGet 0 74 322
assign 1 74 323
addValue 1 74 323
assign 1 74 324
new 0 74 324
addValue 1 74 325
assign 1 76 326
new 0 76 326
assign 1 77 327
arrayIteratorGet 0 0 327
assign 1 77 330
hasNextGet 0 77 330
assign 1 77 332
nextGet 0 77 332
assign 1 79 334
new 0 79 334
assign 1 81 337
new 0 81 337
addValue 1 81 338
assign 1 83 340
addValue 1 83 340
assign 1 83 341
new 0 83 341
assign 1 83 342
addValue 1 83 342
assign 1 83 343
nameGet 0 83 343
assign 1 83 344
addValue 1 83 344
addValue 1 83 345
assign 1 87 351
new 0 87 351
assign 1 87 352
addValue 1 87 352
addValue 1 87 353
assign 1 92 381
heldGet 0 92 381
assign 1 92 382
namepathGet 0 92 382
assign 1 92 383
getClassConfig 1 92 383
assign 1 93 384
getInitialInst 1 93 384
assign 1 95 385
emitNameGet 0 95 385
assign 1 95 386
addValue 1 95 386
assign 1 95 387
new 0 95 387
assign 1 95 388
addValue 1 95 388
addValue 1 95 389
assign 1 98 390
addValue 1 98 390
assign 1 98 391
new 0 98 391
assign 1 98 392
addValue 1 98 392
addValue 1 98 393
assign 1 100 394
new 0 100 394
assign 1 100 395
addValue 1 100 395
addValue 1 100 396
assign 1 102 397
emitNameGet 0 102 397
assign 1 102 398
addValue 1 102 398
assign 1 102 399
new 0 102 399
assign 1 102 400
addValue 1 102 400
addValue 1 102 401
assign 1 105 402
new 0 105 402
assign 1 105 403
addValue 1 105 403
assign 1 105 404
addValue 1 105 404
assign 1 105 405
new 0 105 405
assign 1 105 406
addValue 1 105 406
addValue 1 105 407
assign 1 107 408
new 0 107 408
assign 1 107 409
addValue 1 107 409
addValue 1 107 410
buildPropList 0 109 411
getCode 2 114 416
assign 1 115 417
toString 0 115 417
addValue 1 116 418
assign 1 122 424
new 0 122 424
assign 1 122 425
addValue 1 122 425
addValue 1 122 426
assign 1 127 435
isPropertyGet 0 127 435
assign 1 128 437
new 0 128 437
assign 1 128 438
nameGet 0 128 438
assign 1 128 439
add 1 128 439
return 1 128 440
assign 1 130 442
nameForVar 1 130 442
return 1 130 443
assign 1 136 567
getLibOutput 0 136 567
assign 1 138 568
new 0 138 568
assign 1 139 569
new 0 139 569
assign 1 140 570
new 0 140 570
assign 1 141 571
new 0 141 571
assign 1 142 572
iteratorGet 0 142 572
assign 1 142 575
hasNextGet 0 142 575
assign 1 144 577
nextGet 0 144 577
assign 1 146 578
new 0 146 578
assign 1 146 579
addValue 1 146 579
assign 1 146 580
addValue 1 146 580
assign 1 146 581
heldGet 0 146 581
assign 1 146 582
namepathGet 0 146 582
assign 1 146 583
toString 0 146 583
assign 1 146 584
addValue 1 146 584
assign 1 146 585
addValue 1 146 585
assign 1 146 586
new 0 146 586
assign 1 146 587
addValue 1 146 587
assign 1 146 588
heldGet 0 146 588
assign 1 146 589
namepathGet 0 146 589
assign 1 146 590
getClassConfig 1 146 590
assign 1 146 591
libNameGet 0 146 591
assign 1 146 592
relEmitName 1 146 592
assign 1 146 593
addValue 1 146 593
assign 1 146 594
new 0 146 594
assign 1 146 595
addValue 1 146 595
addValue 1 146 596
assign 1 148 597
heldGet 0 148 597
assign 1 148 598
synGet 0 148 598
assign 1 148 599
hasDefaultGet 0 148 599
assign 1 150 601
new 0 150 601
assign 1 150 602
heldGet 0 150 602
assign 1 150 603
namepathGet 0 150 603
assign 1 150 604
getClassConfig 1 150 604
assign 1 150 605
libNameGet 0 150 605
assign 1 150 606
relEmitName 1 150 606
assign 1 150 607
add 1 150 607
assign 1 150 608
new 0 150 608
assign 1 150 609
add 1 150 609
assign 1 156 610
new 0 156 610
assign 1 156 611
addValue 1 156 611
assign 1 156 612
addValue 1 156 612
assign 1 156 613
new 0 156 613
assign 1 156 614
addValue 1 156 614
addValue 1 156 615
assign 1 157 616
heldGet 0 157 616
assign 1 157 617
synGet 0 157 617
assign 1 157 618
hasDefaultGet 0 157 618
assign 1 158 620
new 0 158 620
assign 1 158 621
addValue 1 158 621
assign 1 158 622
addValue 1 158 622
assign 1 158 623
new 0 158 623
assign 1 158 624
addValue 1 158 624
addValue 1 158 625
assign 1 164 633
new 0 164 633
assign 1 166 634
keysGet 0 166 634
assign 1 166 635
iteratorGet 0 0 635
assign 1 166 638
hasNextGet 0 166 638
assign 1 166 640
nextGet 0 166 640
assign 1 168 641
new 0 168 641
assign 1 168 642
addValue 1 168 642
assign 1 168 643
new 0 168 643
assign 1 168 644
quoteGet 0 168 644
assign 1 168 645
addValue 1 168 645
assign 1 168 646
addValue 1 168 646
assign 1 168 647
new 0 168 647
assign 1 168 648
quoteGet 0 168 648
assign 1 168 649
addValue 1 168 649
assign 1 168 650
new 0 168 650
assign 1 168 651
addValue 1 168 651
assign 1 168 652
get 1 168 652
assign 1 168 653
addValue 1 168 653
assign 1 168 654
new 0 168 654
assign 1 168 655
addValue 1 168 655
addValue 1 168 656
assign 1 169 657
new 0 169 657
assign 1 169 658
addValue 1 169 658
assign 1 169 659
new 0 169 659
assign 1 169 660
quoteGet 0 169 660
assign 1 169 661
addValue 1 169 661
assign 1 169 662
addValue 1 169 662
assign 1 169 663
new 0 169 663
assign 1 169 664
quoteGet 0 169 664
assign 1 169 665
addValue 1 169 665
assign 1 169 666
new 0 169 666
assign 1 169 667
addValue 1 169 667
assign 1 169 668
get 1 169 668
assign 1 169 669
addValue 1 169 669
assign 1 169 670
new 0 169 670
assign 1 169 671
addValue 1 169 671
addValue 1 169 672
write 1 173 678
write 1 175 679
assign 1 178 680
usedLibrarysGet 0 178 680
assign 1 178 681
sizeGet 0 178 681
assign 1 178 682
new 0 178 682
assign 1 178 683
equals 1 178 688
assign 1 179 689
new 0 179 689
assign 1 179 690
addValue 1 179 690
addValue 1 179 691
assign 1 180 692
new 0 180 692
assign 1 180 693
addValue 1 180 693
addValue 1 180 694
assign 1 181 695
new 0 181 695
assign 1 181 696
addValue 1 181 696
addValue 1 181 697
write 1 184 699
write 1 185 700
assign 1 188 701
new 0 188 701
assign 1 189 702
mainNameGet 0 189 702
fromString 1 189 703
assign 1 190 704
getClassConfig 1 190 704
assign 1 192 705
new 0 192 705
assign 1 193 706
new 0 193 706
assign 1 193 707
addValue 1 193 707
assign 1 193 708
fullEmitNameGet 0 193 708
assign 1 193 709
addValue 1 193 709
assign 1 193 710
new 0 193 710
assign 1 193 711
addValue 1 193 711
addValue 1 193 712
assign 1 194 713
ownProcessGet 0 194 713
assign 1 195 715
new 0 195 715
assign 1 195 716
addValue 1 195 716
addValue 1 195 717
assign 1 197 719
new 0 197 719
assign 1 197 720
addValue 1 197 720
assign 1 197 721
outputPlatformGet 0 197 721
assign 1 197 722
nameGet 0 197 722
assign 1 197 723
addValue 1 197 723
assign 1 197 724
new 0 197 724
assign 1 197 725
addValue 1 197 725
addValue 1 197 726
write 1 199 727
assign 1 200 728
new 0 200 728
write 1 201 729
write 1 202 730
assign 1 203 731
ownProcessGet 0 203 731
assign 1 204 733
new 0 204 733
assign 1 204 734
addValue 1 204 734
addValue 1 204 735
assign 1 205 736
new 0 205 736
assign 1 205 737
addValue 1 205 737
addValue 1 205 738
write 1 207 740
finishLibOutput 1 209 741
assign 1 214 747
new 0 214 747
assign 1 214 748
add 1 214 748
return 1 214 749
assign 1 218 757
isPropertyGet 0 218 757
assign 1 221 761
isArgGet 0 221 761
assign 1 221 762
not 0 221 767
assign 1 222 768
new 0 222 768
addValue 1 222 769
assign 1 224 771
nameForVar 1 224 771
addValue 1 224 772
assign 1 229 778
new 0 229 778
return 1 229 779
assign 1 233 787
new 0 233 787
assign 1 233 788
add 1 233 788
assign 1 233 789
new 0 233 789
assign 1 233 790
add 1 233 790
assign 1 233 791
add 1 233 791
return 1 233 792
assign 1 237 796
new 0 237 796
return 1 237 797
assign 1 242 811
emitNameGet 0 242 811
assign 1 242 812
new 0 242 812
assign 1 242 813
add 1 242 813
assign 1 242 814
add 1 242 814
assign 1 242 815
new 0 242 815
assign 1 242 816
add 1 242 816
assign 1 242 817
addValue 1 242 817
assign 1 243 818
emitNameGet 0 243 818
assign 1 243 819
add 1 243 819
assign 1 243 820
new 0 243 820
assign 1 243 821
add 1 243 821
assign 1 243 822
addValue 1 243 822
return 1 244 823
assign 1 248 837
new 0 248 837
assign 1 248 838
libNameGet 0 248 838
assign 1 248 839
relEmitName 1 248 839
assign 1 248 840
add 1 248 840
assign 1 248 841
new 0 248 841
assign 1 248 842
add 1 248 842
assign 1 248 843
heldGet 0 248 843
assign 1 248 844
literalValueGet 0 248 844
assign 1 248 845
add 1 248 845
assign 1 248 846
new 0 248 846
assign 1 248 847
add 1 248 847
return 1 248 848
assign 1 252 862
new 0 252 862
assign 1 252 863
libNameGet 0 252 863
assign 1 252 864
relEmitName 1 252 864
assign 1 252 865
add 1 252 865
assign 1 252 866
new 0 252 866
assign 1 252 867
add 1 252 867
assign 1 252 868
heldGet 0 252 868
assign 1 252 869
literalValueGet 0 252 869
assign 1 252 870
add 1 252 870
assign 1 252 871
new 0 252 871
assign 1 252 872
add 1 252 872
return 1 252 873
assign 1 257 909
new 0 257 909
assign 1 257 910
libNameGet 0 257 910
assign 1 257 911
relEmitName 1 257 911
assign 1 257 912
add 1 257 912
assign 1 257 913
new 0 257 913
assign 1 257 914
add 1 257 914
assign 1 257 915
emitNameGet 0 257 915
assign 1 257 916
add 1 257 916
assign 1 257 917
new 0 257 917
assign 1 257 918
add 1 257 918
assign 1 257 919
add 1 257 919
assign 1 257 920
new 0 257 920
assign 1 257 921
add 1 257 921
assign 1 257 922
add 1 257 922
assign 1 257 923
new 0 257 923
assign 1 257 924
add 1 257 924
return 1 257 925
assign 1 259 927
new 0 259 927
assign 1 259 928
libNameGet 0 259 928
assign 1 259 929
relEmitName 1 259 929
assign 1 259 930
add 1 259 930
assign 1 259 931
new 0 259 931
assign 1 259 932
add 1 259 932
assign 1 259 933
emitNameGet 0 259 933
assign 1 259 934
add 1 259 934
assign 1 259 935
new 0 259 935
assign 1 259 936
add 1 259 936
assign 1 259 937
add 1 259 937
assign 1 259 938
new 0 259 938
assign 1 259 939
add 1 259 939
assign 1 259 940
add 1 259 940
assign 1 259 941
new 0 259 941
assign 1 259 942
add 1 259 942
return 1 259 943
assign 1 263 958
def 1 263 963
assign 1 264 964
libNameGet 0 264 964
assign 1 264 965
relEmitName 1 264 965
assign 1 264 966
extend 1 264 966
assign 1 266 969
new 0 266 969
assign 1 266 970
extend 1 266 970
assign 1 268 972
new 0 268 972
assign 1 268 973
emitNameGet 0 268 973
assign 1 268 974
addValue 1 268 974
assign 1 268 975
new 0 268 975
assign 1 268 976
addValue 1 268 976
assign 1 276 977
new 0 276 977
assign 1 276 978
addValue 1 276 978
addValue 1 276 979
addValue 1 277 980
return 1 278 981
assign 1 282 994
heldGet 0 282 994
assign 1 282 995
superCallGet 0 282 995
assign 1 283 997
new 0 283 997
assign 1 283 998
heldGet 0 283 998
assign 1 283 999
nameGet 0 283 999
assign 1 283 1000
add 1 283 1000
return 1 283 1001
assign 1 285 1003
new 0 285 1003
assign 1 285 1004
heldGet 0 285 1004
assign 1 285 1005
nameGet 0 285 1005
assign 1 285 1006
add 1 285 1006
return 1 285 1007
assign 1 289 1036
new 0 289 1036
assign 1 290 1037
arrayIteratorGet 0 0 1037
assign 1 290 1040
hasNextGet 0 290 1040
assign 1 290 1042
nextGet 0 290 1042
assign 1 291 1043
emitNameGet 0 291 1043
assign 1 291 1044
new 0 291 1044
assign 1 291 1045
add 1 291 1045
assign 1 291 1046
new 0 291 1046
assign 1 291 1047
add 1 291 1047
assign 1 291 1048
heldGet 0 291 1048
assign 1 291 1049
nameGet 0 291 1049
assign 1 291 1050
add 1 291 1050
assign 1 291 1051
new 0 291 1051
assign 1 291 1052
add 1 291 1052
assign 1 291 1053
emitNameGet 0 291 1053
assign 1 291 1054
add 1 291 1054
assign 1 291 1055
new 0 291 1055
assign 1 291 1056
add 1 291 1056
assign 1 291 1057
new 0 291 1057
assign 1 291 1058
add 1 291 1058
assign 1 291 1059
heldGet 0 291 1059
assign 1 291 1060
nameGet 0 291 1060
assign 1 291 1061
add 1 291 1061
assign 1 291 1062
new 0 291 1062
assign 1 291 1063
add 1 291 1063
assign 1 291 1064
add 1 291 1064
addValue 1 291 1065
return 1 293 1071
assign 1 300 1076
undef 1 300 1081
assign 1 301 1082
new 0 301 1082
addValue 1 303 1084
assign 1 304 1085
new 0 304 1085
return 1 304 1086
assign 1 309 1090
getLibOutput 0 309 1090
return 1 309 1091
assign 1 317 1122
undef 1 317 1127
assign 1 318 1128
new 0 318 1128
assign 1 319 1129
parentGet 0 319 1129
assign 1 319 1130
fileGet 0 319 1130
assign 1 319 1131
existsGet 0 319 1131
assign 1 319 1132
not 0 319 1137
assign 1 320 1138
parentGet 0 320 1138
assign 1 320 1139
fileGet 0 320 1139
makeDirs 0 320 1140
assign 1 322 1142
fileGet 0 322 1142
assign 1 322 1143
writerGet 0 322 1143
assign 1 322 1144
open 0 322 1144
assign 1 324 1145
paramsGet 0 324 1145
assign 1 324 1146
new 0 324 1146
assign 1 324 1147
has 1 324 1147
assign 1 325 1149
paramsGet 0 325 1149
assign 1 325 1150
new 0 325 1150
assign 1 325 1151
get 1 325 1151
assign 1 325 1152
iteratorGet 0 0 1152
assign 1 325 1155
hasNextGet 0 325 1155
assign 1 325 1157
nextGet 0 325 1157
assign 1 326 1158
apNew 1 326 1158
assign 1 326 1159
fileGet 0 326 1159
assign 1 327 1160
readerGet 0 327 1160
assign 1 327 1161
open 0 327 1161
assign 1 327 1162
readString 0 327 1162
assign 1 328 1163
readerGet 0 328 1163
close 0 328 1164
assign 1 329 1165
countLines 1 329 1165
addValue 1 329 1166
write 1 330 1167
return 1 336 1175
close 0 340 1178
assign 1 341 1179
assign 1 346 1184
new 0 346 1184
return 1 346 1185
assign 1 350 1189
new 0 350 1189
return 1 350 1190
assign 1 354 1194
new 0 354 1194
return 1 354 1195
assign 1 358 1199
new 0 358 1199
return 1 358 1200
assign 1 362 1204
new 0 362 1204
return 1 362 1205
assign 1 366 1209
new 0 366 1209
return 1 366 1210
assign 1 370 1214
new 0 370 1214
return 1 370 1215
assign 1 375 1219
new 0 375 1219
return 1 375 1220
assign 1 380 1224
new 0 380 1224
return 1 380 1225
assign 1 384 1233
new 0 384 1233
assign 1 384 1234
add 1 384 1234
assign 1 384 1235
new 0 384 1235
assign 1 384 1236
add 1 384 1236
assign 1 384 1237
add 1 384 1237
return 1 384 1238
assign 1 388 1242
new 0 388 1242
return 1 388 1243
assign 1 392 1250
libNameGet 0 392 1250
assign 1 392 1251
relEmitName 1 392 1251
assign 1 392 1252
new 0 392 1252
assign 1 392 1253
add 1 392 1253
return 1 392 1254
assign 1 397 1263
emitNameGet 0 397 1263
assign 1 397 1264
new 0 397 1264
assign 1 397 1265
add 1 397 1265
assign 1 397 1266
new 0 397 1266
assign 1 397 1267
add 1 397 1267
assign 1 397 1268
add 1 397 1268
return 1 397 1269
assign 1 402 1280
emitNameGet 0 402 1280
assign 1 402 1281
addValue 1 402 1281
assign 1 402 1282
new 0 402 1282
assign 1 402 1283
addValue 1 402 1283
assign 1 402 1284
addValue 1 402 1284
assign 1 402 1285
new 0 402 1285
addValue 1 402 1286
addValue 1 404 1287
assign 1 406 1288
new 0 406 1288
assign 1 406 1289
addValue 1 406 1289
addValue 1 406 1290
assign 1 411 1295
new 0 411 1295
return 1 411 1296
assign 1 415 1300
new 0 415 1300
return 1 415 1301
assign 1 419 1307
new 0 419 1307
assign 1 419 1308
add 1 419 1308
assign 1 419 1309
add 1 419 1309
return 1 419 1310
assign 1 423 1316
new 0 423 1316
assign 1 423 1317
libEmitName 1 423 1317
assign 1 423 1318
add 1 423 1318
return 1 423 1319
assign 1 427 1324
getClassConfig 1 427 1324
assign 1 428 1325
fullEmitNameGet 0 428 1325
emitNameSet 1 428 1326
return 1 429 1327
assign 1 433 1332
getLocalClassConfig 1 433 1332
assign 1 434 1333
fullEmitNameGet 0 434 1333
emitNameSet 1 434 1334
return 1 435 1335
return 1 0 1338
assign 1 0 1341
return 1 0 1345
assign 1 0 1348
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1109279973: return bem_spropDecGet_0();
case 397629001: return bem_maxSpillArgsLenGet_0();
case 229958684: return bem_constGet_0();
case 944442837: return bem_classConfGet_0();
case 362974009: return bem_parentConfGet_0();
case 1413054881: return bem_smnlcsGet_0();
case 103017121: return bem_runtimeInitGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1859739893: return bem_methodsGet_0();
case 1529527065: return bem_onceCountGet_0();
case 1947619572: return bem_msynGet_0();
case 89706405: return bem_ccCacheGet_0();
case 708434875: return bem_klassDecGet_0();
case 1967844855: return bem_initialDecGet_0();
case 1774940957: return bem_toString_0();
case 1566392515: return bem_covariantReturnsGet_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 4647121: return bem_doEmit_0();
case 2039613615: return bem_instanceNotEqualGet_0();
case 955058175: return bem_lastMethodBodyLinesGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2001798761: return bem_nlGet_0();
case 1711936384: return bem_baseSmtdDecGet_0();
case 1308786538: return bem_echo_0();
case 160277051: return bem_procStartGet_0();
case 1372235405: return bem_superCallsGet_0();
case 1786051763: return bem_methodCatchGet_0();
case 1081275759: return bem_classesInDepthOrderGet_0();
case 774383281: return bem_okNintCallsGet_0();
case 1380285640: return bem_objectCcGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 604504089: return bem_falseValueGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case 378762597: return bem_boolNpGet_0();
case 1727672536: return bem_propDecGet_0();
case 628036310: return bem_lastMethodsSizeGet_0();
case 1487140092: return bem_classEndGet_0();
case 104713553: return bem_new_0();
case 402158238: return bem_inFilePathedGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1177623581: return bem_callNamesGet_0();
case 991179882: return bem_qGet_0();
case 644675716: return bem_ntypesGet_0();
case 1081412016: return bem_many_0();
case 1638160588: return bem_lineCountGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 772789066: return bem_libEmitPathGet_0();
case 2055025483: return bem_serializeContents_0();
case 1312373307: return bem_buildCreate_0();
case 1703922349: return bem_fullLibEmitNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 36542021: return bem_mainEndGet_0();
case 916491491: return bem_emitLib_0();
case 603479476: return bem_allOnceDecsGet_0();
case 1747980150: return bem_smnlecsGet_0();
case 1841706211: return bem_returnTypeGet_0();
case 1073009537: return bem_beginNs_0();
case 2085643372: return bem_stringNpGet_0();
case 1500143225: return bem_useDynMethodsGet_0();
case 1052944126: return bem_csynGet_0();
case 1607412815: return bem_endNs_0();
case 86482693: return bem_overrideSmtdDecGet_0();
case 1923547459: return bem_boolCcGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 498080472: return bem_mnodeGet_0();
case 1820417453: return bem_create_0();
case 962646066: return bem_shlibeGet_0();
case 946095539: return bem_mainInClassGet_0();
case 681402717: return bem_boolTypeGet_0();
case 101343106: return bem_nativeCSlotsGet_0();
case 493012039: return bem_buildGet_0();
case 1354714650: return bem_copy_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 254265568: return bem_buildPropList_0();
case 361542143: return bem_classEmitsGet_0();
case 2019411446: return bem_classBeginGet_0();
case 902412214: return bem_classCallsGet_0();
case 294732055: return bem_floatNpGet_0();
case 729571811: return bem_serializeToString_0();
case 1831751774: return bem_cnodeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 622039562: return bem_intNpGet_0();
case 1240611285: return bem_onceDecsGet_0();
case 786424307: return bem_tagGet_0();
case 991255330: return bem_mainStartGet_0();
case 722876119: return bem_buildClassInfo_0();
case 1910715228: return bem_libEmitNameGet_0();
case 797225458: return bem_dynMethodsGet_0();
case 1181505319: return bem_buildInitial_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1755995201: return bem_transGet_0();
case 1449942744: return bem_instanceEqualGet_0();
case 1012494862: return bem_once_0();
case 1369896794: return bem_objectNpGet_0();
case 1498619679: return bem_getLibOutput_0();
case 287040793: return bem_hashGet_0();
case 1317806639: return bem_baseMtdDecGet_0();
case 483359873: return bem_superNameGet_0();
case 1241388883: return bem_lastMethodBodySizeGet_0();
case 1795655423: return bem_propertyDecsGet_0();
case 1152064310: return bem_instOfGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1102720804: return bem_classNameGet_0();
case 727049506: return bem_exceptDecGet_0();
case 57260628: return bem_getClassOutput_0();
case 388723214: return bem_preClassGet_0();
case 1327064356: return bem_methodBodyGet_0();
case 1064889660: return bem_trueValueGet_0();
case 314718434: return bem_print_0();
case 220901978: return bem_emitLangGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 1053807407: return bem_trueValueSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2144776371: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 763301028: return bem_okNintCallsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case 1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 610957309: return bem_intNpSet_1(bevd_0);
case 386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case 891329961: return bem_classCallsSet_1(bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1820669521: return bem_cnodeSet_1(bevd_0);
case 945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case 1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 90260853: return bem_nativeCSlotsSet_1(bevd_0);
case 1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case 1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case 1912465206: return bem_boolCcSet_1(bevd_0);
case 377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case 943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case 1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case 1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1936537319: return bem_msynSet_1(bevd_0);
case 551679723: return bem_formCast_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1438860491: return bem_instanceEqualSet_1(bevd_0);
case 1899632975: return bem_libEmitNameSet_1(bevd_0);
case 478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 391075985: return bem_inFilePathedSet_1(bevd_0);
case 36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1041861873: return bem_csynSet_1(bevd_0);
case 1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 715967253: return bem_exceptDecSet_1(bevd_0);
case 1830623958: return bem_returnTypeSet_1(bevd_0);
case 1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case 1774969510: return bem_methodCatchSet_1(bevd_0);
case 614561729: return bem_allOnceDecsSet_1(bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case 1358814541: return bem_objectNpSet_1(bevd_0);
case 1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case 2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case 65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_5_8_BuildNamePath) bevd_1);
case 1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 722876117: return bem_buildClassInfo_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bevs_inst = (BEC_2_5_9_BuildJSEmitter)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bevs_inst;
}
}
