package be.BEL_4_Base;
/* IO:File: source/build/Syns.be */
public class BEC_2_5_8_BuildClassSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 9));
private static byte[] bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_4, 78));
private static byte[] bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_5, 12));
private static byte[] bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_6, 38));
private static byte[] bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_7, 68));
private static byte[] bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_8, 75));
private static byte[] bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_10, 65));
private static byte[] bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_11, 11));
private static byte[] bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_12, 33));
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_14, 95));
private static byte[] bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_15, 84));
private static byte[] bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_16, 80));
private static byte[] bels_17 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_17, 9));
private static byte[] bels_18 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_18, 26));
private static BEC_2_9_5_ContainerArray bevo_18;
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_19 = {0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
private static byte[] bels_20 = {0x64,0x65,0x70,0x74,0x68};
private static byte[] bels_21 = {0x66,0x72,0x6F,0x6D,0x46,0x69,0x6C,0x65};
private static byte[] bels_22 = {0x6C,0x69,0x62,0x4E,0x61,0x6D,0x65};
private static byte[] bels_23 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bels_24 = {0x69,0x73,0x4C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_25 = {0x73,0x75,0x70,0x65,0x72,0x4C,0x69,0x73,0x74};
private static byte[] bels_26 = {0x75,0x73,0x65,0x73};
private static byte[] bels_27 = {0x70,0x74,0x79,0x4C,0x69,0x73,0x74};
private static byte[] bels_28 = {0x6D,0x74,0x64,0x4C,0x69,0x73,0x74};
private static byte[] bels_29 = {0x61,0x6C,0x6C,0x41,0x6E,0x63,0x65,0x73,0x74,0x6F,0x72,0x73,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_30 = {0x69,0x73,0x4E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
public static BEC_2_5_8_BuildClassSyn bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_5_ContainerArray bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_5_ContainerArray bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public BEC_2_5_8_BuildClassSyn bem_new_0() throws Throwable {
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevl_maxMtdx = (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 104 */ {
bevt_0_tmpvar_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpvar_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpvar_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 106 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 107 */
} /* Line: 106 */
 else  /* Line: 104 */ {
break;
} /* Line: 104 */
} /* Line: 104 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpvar_phold);
if (bevl_dmtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 117 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
this.bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) throws Throwable {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = beva_psyn.bemd_0(1974592946, BEL_4_Base.bevn_superListGet_0);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_3_tmpvar_phold = beva_psyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_superList.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_psyn.bemd_0(1477961836, BEL_4_Base.bevn_mtdListGet_0);
bevp_mtdList = (BEC_2_9_5_ContainerArray) bevt_4_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_5_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevp_ptyList = (BEC_2_9_5_ContainerArray) bevt_5_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 142 */ {
bevt_8_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_10_tmpvar_phold);
bevt_14_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_1));
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_15_tmpvar_phold);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 145 */ {
if (bevl_pv == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 145 */
 else  /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 145 */ {
bevt_19_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 145 */
 else  /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 145 */ {
bevt_24_tmpvar_phold = bevo_1;
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_2;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 146 */
} /* Line: 145 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevt_31_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevl_iv = bevt_31_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 151 */ {
bevt_32_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 151 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevt_35_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_36_tmpvar_phold);
} /* Line: 154 */
} /* Line: 153 */
 else  /* Line: 151 */ {
break;
} /* Line: 151 */
} /* Line: 151 */
bevt_39_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_38_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 158 */ {
bevt_40_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 158 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpvar_phold = beva_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_41_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_42_tmpvar_phold);
if (bevl_pm == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevt_46_tmpvar_phold = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevt_46_tmpvar_phold == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_49_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_48_tmpvar_phold == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_54_tmpvar_phold = bevo_3;
bevt_56_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_add_1(bevt_55_tmpvar_phold);
bevt_57_tmpvar_phold = bevo_4;
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_add_1(bevt_57_tmpvar_phold);
bevt_59_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_50_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_50_tmpvar_phold);
} /* Line: 164 */
} /* Line: 163 */
} /* Line: 162 */
} /* Line: 161 */
 else  /* Line: 158 */ {
break;
} /* Line: 158 */
} /* Line: 158 */
this.bem_loadClass_1(beva_klass);
bevt_60_tmpvar_phold = beva_psyn.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevt_61_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_61_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpvar_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpvar_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpvar_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 178 */ {
return this;
} /* Line: 178 */
bevp_integrated = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directProperties = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directMethods = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 183 */ {
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpvar_loop = bevp_mtdList.bem_arrayIteratorGet_0();
while (true)
 /* Line: 188 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_methodIndexesGet_0();
bevt_10_tmpvar_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpvar_phold.bem_put_1(bevt_10_tmpvar_phold);
} /* Line: 189 */
 else  /* Line: 188 */ {
break;
} /* Line: 188 */
} /* Line: 188 */
return this;
} /* Line: 191 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (new BEC_2_4_3_MathInt(0));
bevt_11_tmpvar_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpvar_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpvar_phold.bem_subtract_1(bevt_12_tmpvar_phold);
bevt_15_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 198 */
bevt_16_tmpvar_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_19_tmpvar_phold = bevo_5;
bevt_20_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 200 */
bevt_21_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_23_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 202 */
 else  /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 202 */ {
bevt_26_tmpvar_phold = bevo_6;
bevt_27_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_24_tmpvar_phold);
} /* Line: 203 */
bevt_28_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_29_tmpvar_phold = bevp_isLocal.bem_not_0();
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 205 */ {
bevt_30_tmpvar_phold = bevp_isFinal.bem_not_0();
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 205 */ {
bevt_33_tmpvar_phold = bevo_7;
bevt_34_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevt_31_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_31_tmpvar_phold);
} /* Line: 206 */
bevt_1_tmpvar_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 208 */ {
bevt_35_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 208 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_has_1(bevt_39_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_not_0();
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_41_tmpvar_phold = bevl_pn.bem_toString_0();
bevt_42_tmpvar_phold = bevo_8;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_notEquals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 210 */
 else  /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 210 */ {
bevp_directProperties = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_directMethods = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 213 */
bevt_45_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_has_1(bevt_46_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_not_0();
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 215 */ {
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 216 */
} /* Line: 215 */
 else  /* Line: 208 */ {
break;
} /* Line: 208 */
} /* Line: 208 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 220 */ {
bevt_47_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 220 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_48_tmpvar_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpvar_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpvar_phold.bem_get_1(bevt_49_tmpvar_phold);
if (bevl_pm == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_51_tmpvar_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpvar_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 227 */
} /* Line: 224 */
 else  /* Line: 229 */ {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpvar_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_methodIndexesGet_0();
bevt_57_tmpvar_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpvar_phold.bem_put_1(bevt_57_tmpvar_phold);
} /* Line: 233 */
} /* Line: 223 */
 else  /* Line: 220 */ {
break;
} /* Line: 220 */
} /* Line: 220 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 240 */ {
return this;
} /* Line: 240 */
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 242 */ {
return this;
} /* Line: 242 */
bevl_psyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevp_superNp);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_3_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 244 */ {
bevt_5_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 244 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_6_tmpvar_phold = bevl_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_8_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
if (bevl_pv == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_16_tmpvar_phold = bevo_9;
bevt_18_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_10;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_12_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_13_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_12_tmpvar_phold);
} /* Line: 249 */
 else  /* Line: 250 */ {
bevt_23_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_23_tmpvar_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_24_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_27_tmpvar_phold);
} /* Line: 252 */
} /* Line: 248 */
} /* Line: 247 */
 else  /* Line: 244 */ {
break;
} /* Line: 244 */
} /* Line: 244 */
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_29_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 256 */ {
bevt_31_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 256 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_32_tmpvar_phold = bevl_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_34_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_32_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_33_tmpvar_phold);
if (bevl_pm == null) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_36_tmpvar_phold = bevl_pm.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevt_41_tmpvar_phold = bevo_11;
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_12;
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_47_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_37_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_38_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_37_tmpvar_phold);
} /* Line: 261 */
bevt_49_tmpvar_phold = bevl_om.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_oa = bevt_48_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 264 */ {
bevt_52_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_50_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_51_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 264 */ {
bevt_53_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_pmr = bevt_53_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_54_tmpvar_phold = bevl_oa.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevl_omr = bevt_54_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
this.bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 264 */
 else  /* Line: 264 */ {
break;
} /* Line: 264 */
} /* Line: 264 */
bevl_pmr = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
bevt_55_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_omr = bevt_55_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevl_pmr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
if (bevl_omr == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
if (bevl_pmr == null) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bem_not_0();
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
if (bevl_omr == null) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_not_0();
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 273 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 273 */ {
bevt_64_tmpvar_phold = bevo_13;
bevt_67_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_add_1(bevt_65_tmpvar_phold);
bevt_62_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_63_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_62_tmpvar_phold);
} /* Line: 274 */
} /* Line: 273 */
 else  /* Line: 276 */ {
this.bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 278 */
} /* Line: 272 */
} /* Line: 259 */
 else  /* Line: 256 */ {
break;
} /* Line: 256 */
} /* Line: 256 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) throws Throwable {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_3_tmpvar_phold = beva_omr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevt_6_tmpvar_phold = bevo_14;
bevt_9_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
bevt_10_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 287 */ {
bevt_11_tmpvar_phold = beva_pmr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_12_tmpvar_phold = beva_omr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
return this;
} /* Line: 291 */
bevt_13_tmpvar_phold = beva_omr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_osyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_osyn.bemd_0(986531569, BEL_4_Base.bevn_allTypesGet_0);
bevt_17_tmpvar_phold = beva_pmr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_17_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 294 */ {
bevt_20_tmpvar_phold = bevo_15;
bevt_23_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_18_tmpvar_phold);
} /* Line: 295 */
} /* Line: 294 */
} /* Line: 285 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
this.bem_new_0();
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_0_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 302 */ {
bevt_2_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 302 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 304 */ {
bevt_10_tmpvar_phold = bevo_16;
bevt_12_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_17;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 305 */
} /* Line: 304 */
 else  /* Line: 302 */ {
break;
} /* Line: 302 */
} /* Line: 302 */
this.bem_loadClass_1(beva_klass);
bevp_depth = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevt_3_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpvar_phold.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpvar_phold.bemd_0(842582618, BEL_4_Base.bevn_isLocalGet_0);
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpvar_phold.bemd_0(363636983, BEL_4_Base.bevn_isNotNullGet_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(83882038, BEL_4_Base.bevn_usedGet_0);
bevl_iu = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 320 */ {
bevt_8_tmpvar_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_ou = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ou.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_uses.bem_put_1(bevt_9_tmpvar_phold);
} /* Line: 322 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
bevt_11_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_10_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 324 */ {
bevt_12_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 324 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 327 */
 else  /* Line: 324 */ {
break;
} /* Line: 324 */
} /* Line: 324 */
bevt_14_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_13_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 329 */ {
bevt_15_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 329 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 332 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
this.bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_postLoad_0() throws Throwable {
BEC_2_9_5_ContainerArray bevl_nptyList = null;
BEC_2_9_5_ContainerArray bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
bevl_nptyList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_mtdnList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 342 */ {
bevt_1_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 342 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 344 */ {
bevt_5_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_ptyMap.bem_put_2(bevt_5_tmpvar_phold, bevl_ov);
} /* Line: 346 */
} /* Line: 344 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 352 */ {
bevt_6_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 352 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = bevl_unq.bem_has_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_not_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevt_10_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpvar_phold);
bevl_nom.bemd_1(1283009805, BEL_4_Base.bevn_mposSet_1, bevl_mpos);
bevt_11_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
} /* Line: 359 */
} /* Line: 354 */
 else  /* Line: 352 */ {
break;
} /* Line: 352 */
} /* Line: 352 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 366 */ {
bevt_14_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 366 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_15_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_mtdMap.bem_put_2(bevt_15_tmpvar_phold, bevl_om);
bevt_18_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpvar_phold);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_not_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 371 */ {
bevt_19_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdOmap.bem_put_2(bevt_19_tmpvar_phold, bevl_om);
} /* Line: 372 */
} /* Line: 371 */
 else  /* Line: 366 */ {
break;
} /* Line: 366 */
} /* Line: 366 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 378 */ {
bevt_20_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 378 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_22_tmpvar_phold = bevl_unq.bem_has_1(bevt_23_tmpvar_phold);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_not_0();
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevt_24_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpvar_phold == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevt_28_tmpvar_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpvar_phold);
} /* Line: 392 */
bevt_29_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(885379526, BEL_4_Base.bevn_declarationSet_1, bevt_29_tmpvar_phold);
bevl_oma.bemd_1(1365143591, BEL_4_Base.bevn_mtdxSet_1, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
} /* Line: 398 */
} /* Line: 380 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpvar_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 403 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 403 */ {
bevl_s = bevt_0_tmpvar_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 405 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_9_5_ContainerArray bevl_names = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(12));
synchronized (BEC_2_5_8_BuildClassSyn.class) {
if (bevo_18 == null) {
bevo_18 = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
}
}
bevl_names = bevo_18;
bevt_3_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevl_names.bem_get_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 413 */ {
bevt_4_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_19));
bevl_names.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_20));
bevl_names.bem_put_2(bevt_6_tmpvar_phold, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_21));
bevl_names.bem_put_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = (new BEC_2_4_3_MathInt(3));
bevt_11_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_22));
bevl_names.bem_put_2(bevt_10_tmpvar_phold, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = (new BEC_2_4_3_MathInt(4));
bevt_13_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_23));
bevl_names.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_2_4_3_MathInt(5));
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_24));
bevl_names.bem_put_2(bevt_14_tmpvar_phold, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (new BEC_2_4_3_MathInt(6));
bevt_17_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_25));
bevl_names.bem_put_2(bevt_16_tmpvar_phold, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_2_4_3_MathInt(7));
bevt_19_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_26));
bevl_names.bem_put_2(bevt_18_tmpvar_phold, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_2_4_3_MathInt(8));
bevt_21_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_27));
bevl_names.bem_put_2(bevt_20_tmpvar_phold, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_2_4_3_MathInt(9));
bevt_23_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_28));
bevl_names.bem_put_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_2_4_3_MathInt(10));
bevt_25_tmpvar_phold = (new BEC_2_4_6_TextString(17, bels_29));
bevl_names.bem_put_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (new BEC_2_4_3_MathInt(11));
bevt_27_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_30));
bevl_names.bem_put_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
} /* Line: 425 */
bevt_28_tmpvar_phold = (new BEC_2_6_23_SystemNamedPropertiesIterator()).bem_new_2(this, bevl_names);
return bevt_28_tmpvar_phold;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() throws Throwable {
return bevp_superNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
return bevp_depth;
} /*method end*/
public BEC_2_6_6_SystemObject bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() throws Throwable {
return bevp_newMbrs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() throws Throwable {
return bevp_newMtds;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() throws Throwable {
return bevp_defMtds;
} /*method end*/
public BEC_2_6_6_SystemObject bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() throws Throwable {
return bevp_directProperties;
} /*method end*/
public BEC_2_6_6_SystemObject bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() throws Throwable {
return bevp_directMethods;
} /*method end*/
public BEC_2_6_6_SystemObject bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() throws Throwable {
return bevp_allTypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() throws Throwable {
return bevp_superList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() throws Throwable {
return bevp_mtdMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mtdListGet_0() throws Throwable {
return bevp_mtdList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mtdList = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() throws Throwable {
return bevp_ptyMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_ptyListGet_0() throws Throwable {
return bevp_ptyList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ptyList = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_6_6_SystemObject bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() throws Throwable {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() throws Throwable {
return bevp_integrated;
} /*method end*/
public BEC_2_6_6_SystemObject bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() throws Throwable {
return bevp_iChecked;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() throws Throwable {
return bevp_uses;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() throws Throwable {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_6_6_SystemObject bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() throws Throwable {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_6_6_SystemObject bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {80, 82, 84, 86, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 98, 103, 104, 104, 105, 106, 106, 106, 107, 110, 114, 114, 115, 115, 117, 117, 119, 119, 122, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 136, 137, 137, 138, 138, 139, 139, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 145, 145, 145, 145, 145, 0, 0, 0, 145, 145, 145, 0, 0, 0, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 151, 151, 151, 152, 153, 153, 154, 154, 154, 154, 158, 158, 158, 158, 159, 160, 160, 160, 160, 161, 161, 162, 162, 162, 163, 163, 163, 163, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 169, 170, 170, 170, 174, 174, 178, 179, 180, 181, 182, 183, 183, 184, 185, 186, 187, 188, 0, 188, 188, 189, 189, 189, 189, 191, 193, 194, 195, 197, 197, 197, 197, 198, 198, 198, 199, 200, 200, 200, 200, 200, 202, 202, 202, 0, 0, 0, 203, 203, 203, 203, 203, 205, 205, 0, 0, 0, 205, 0, 0, 0, 206, 206, 206, 206, 206, 208, 0, 208, 208, 209, 210, 210, 210, 210, 210, 210, 210, 0, 0, 0, 212, 213, 215, 215, 215, 215, 216, 220, 220, 221, 222, 222, 222, 223, 223, 224, 225, 225, 226, 226, 227, 230, 230, 231, 232, 233, 233, 233, 233, 240, 241, 242, 242, 242, 243, 244, 244, 244, 244, 245, 246, 246, 246, 246, 247, 247, 248, 248, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 251, 251, 251, 251, 252, 252, 252, 252, 256, 256, 256, 256, 257, 258, 258, 258, 258, 259, 259, 260, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 263, 263, 263, 264, 264, 264, 264, 265, 265, 266, 266, 268, 264, 270, 271, 271, 272, 272, 0, 272, 272, 0, 0, 273, 273, 0, 273, 273, 0, 0, 274, 274, 274, 274, 274, 274, 274, 278, 285, 285, 285, 286, 286, 286, 286, 286, 286, 286, 287, 290, 290, 0, 0, 0, 291, 293, 293, 294, 294, 294, 294, 295, 295, 295, 295, 295, 295, 295, 301, 302, 302, 302, 302, 303, 304, 304, 304, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 308, 309, 314, 314, 315, 315, 316, 316, 317, 317, 318, 318, 319, 319, 320, 320, 320, 320, 321, 322, 322, 324, 324, 324, 324, 325, 326, 327, 329, 329, 329, 329, 330, 331, 332, 334, 338, 339, 342, 342, 343, 344, 344, 344, 346, 346, 350, 351, 352, 352, 353, 354, 354, 354, 355, 355, 356, 357, 357, 358, 359, 359, 359, 362, 364, 366, 366, 367, 369, 369, 371, 371, 371, 372, 372, 376, 377, 378, 378, 379, 380, 380, 380, 381, 381, 390, 390, 391, 391, 391, 392, 392, 394, 394, 395, 396, 397, 398, 398, 398, 401, 403, 0, 403, 403, 404, 405, 408, 412, 412, 413, 413, 413, 413, 414, 414, 414, 415, 415, 415, 416, 416, 416, 417, 417, 417, 418, 418, 418, 419, 419, 419, 420, 420, 420, 421, 421, 421, 422, 422, 422, 423, 423, 423, 424, 424, 424, 425, 425, 425, 427, 427, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 111, 112, 115, 117, 118, 119, 124, 125, 132, 140, 141, 142, 147, 148, 149, 151, 152, 155, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 253, 255, 256, 257, 258, 259, 260, 261, 262, 263, 265, 270, 271, 274, 278, 281, 282, 283, 285, 288, 292, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 313, 314, 317, 319, 320, 321, 323, 324, 325, 326, 333, 334, 335, 338, 340, 341, 342, 343, 344, 345, 350, 351, 352, 357, 358, 359, 360, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 385, 386, 387, 388, 393, 394, 462, 464, 465, 466, 467, 468, 473, 474, 475, 476, 477, 478, 478, 481, 483, 484, 485, 486, 487, 493, 495, 496, 497, 498, 499, 500, 501, 502, 503, 505, 507, 509, 510, 511, 512, 513, 515, 517, 518, 520, 523, 527, 530, 531, 532, 533, 534, 536, 538, 540, 543, 547, 550, 552, 555, 559, 562, 563, 564, 565, 566, 568, 568, 571, 573, 574, 575, 576, 577, 578, 580, 581, 582, 584, 587, 591, 594, 595, 597, 598, 599, 600, 602, 609, 612, 614, 615, 616, 617, 618, 623, 624, 626, 627, 628, 629, 630, 634, 635, 636, 637, 638, 639, 640, 641, 731, 733, 734, 739, 740, 742, 743, 744, 745, 748, 750, 751, 752, 753, 754, 755, 760, 761, 762, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 778, 779, 780, 781, 782, 783, 784, 785, 793, 794, 795, 798, 800, 801, 802, 803, 804, 805, 810, 811, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 826, 827, 828, 829, 832, 833, 834, 836, 837, 838, 839, 840, 841, 847, 848, 849, 850, 855, 856, 859, 864, 865, 868, 872, 877, 879, 882, 887, 889, 892, 896, 897, 898, 899, 900, 901, 902, 906, 942, 943, 944, 946, 947, 948, 949, 950, 951, 952, 955, 957, 959, 961, 964, 968, 971, 973, 974, 975, 976, 977, 978, 980, 981, 982, 983, 984, 985, 986, 1012, 1013, 1014, 1015, 1018, 1020, 1021, 1022, 1023, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1043, 1044, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1089, 1091, 1092, 1093, 1099, 1100, 1101, 1104, 1106, 1107, 1108, 1114, 1115, 1116, 1119, 1121, 1122, 1123, 1129, 1180, 1181, 1182, 1185, 1187, 1188, 1189, 1190, 1192, 1193, 1200, 1201, 1202, 1205, 1207, 1208, 1209, 1210, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1227, 1228, 1229, 1232, 1234, 1235, 1236, 1237, 1238, 1239, 1241, 1242, 1249, 1250, 1251, 1254, 1256, 1257, 1258, 1259, 1261, 1262, 1263, 1264, 1265, 1266, 1271, 1272, 1273, 1275, 1276, 1277, 1278, 1279, 1280, 1281, 1282, 1289, 1290, 1290, 1293, 1295, 1296, 1297, 1303, 1337, 1338, 1344, 1345, 1346, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1387, 1389, 1390, 1393, 1396, 1400, 1403, 1407, 1410, 1414, 1417, 1421, 1424, 1428, 1431, 1435, 1438, 1442, 1445, 1449, 1452, 1456, 1459, 1463, 1466, 1470, 1473, 1477, 1480, 1484, 1487, 1491, 1494, 1498, 1501, 1505, 1508, 1512, 1515, 1519, 1522, 1526, 1529, 1533, 1536, 1540, 1543, 1547, 1550, 1554, 1557, 1561, 1564, 1568, 1571, 1575, 1578};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 80 87
new 0 80 87
assign 1 82 88
new 0 82 88
assign 1 84 89
new 0 84 89
assign 1 86 90
new 0 86 90
assign 1 87 91
new 0 87 91
assign 1 88 92
new 0 88 92
assign 1 89 93
new 0 89 93
assign 1 90 94
new 0 90 94
assign 1 91 95
new 0 91 95
assign 1 92 96
new 0 92 96
assign 1 93 97
new 0 93 97
assign 1 95 98
new 0 95 98
assign 1 96 99
new 0 96 99
assign 1 97 100
new 0 97 100
assign 1 98 101
new 0 98 101
assign 1 103 111
new 0 103 111
assign 1 104 112
valueIteratorGet 0 104 112
assign 1 104 115
hasNextGet 0 104 115
assign 1 105 117
nextGet 0 105 117
assign 1 106 118
mtdxGet 0 106 118
assign 1 106 119
greater 1 106 124
assign 1 107 125
mtdxGet 0 107 125
return 1 110 132
assign 1 114 140
new 0 114 140
assign 1 114 141
get 1 114 141
assign 1 115 142
def 1 115 147
assign 1 117 148
new 0 117 148
return 1 117 149
assign 1 119 151
new 0 119 151
return 1 119 152
new 0 122 155
assign 1 125 229
new 0 125 229
assign 1 126 230
new 0 126 230
assign 1 127 231
new 0 127 231
assign 1 128 232
new 0 128 232
assign 1 129 233
new 0 129 233
assign 1 130 234
new 0 130 234
assign 1 131 235
new 0 131 235
assign 1 132 236
new 0 132 236
assign 1 133 237
new 0 133 237
assign 1 134 238
new 0 134 238
assign 1 135 239
new 0 135 239
assign 1 136 240
superListGet 0 136 240
assign 1 136 241
copy 0 136 241
assign 1 137 242
namepathGet 0 137 242
addValue 1 137 243
assign 1 138 244
mtdListGet 0 138 244
assign 1 138 245
copy 0 138 245
assign 1 139 246
ptyListGet 0 139 246
assign 1 139 247
copy 0 139 247
assign 1 142 248
heldGet 0 142 248
assign 1 142 249
orderedVarsGet 0 142 249
assign 1 142 250
iteratorGet 0 142 250
assign 1 142 253
hasNextGet 0 142 253
assign 1 143 255
nextGet 0 143 255
assign 1 144 256
ptyMapGet 0 144 256
assign 1 144 257
heldGet 0 144 257
assign 1 144 258
nameGet 0 144 258
assign 1 144 259
get 1 144 259
assign 1 145 260
heldGet 0 145 260
assign 1 145 261
nameGet 0 145 261
assign 1 145 262
new 0 145 262
assign 1 145 263
notEquals 1 145 263
assign 1 145 265
undef 1 145 270
assign 1 0 271
assign 1 0 274
assign 1 0 278
assign 1 145 281
heldGet 0 145 281
assign 1 145 282
isDeclaredGet 0 145 282
assign 1 145 283
not 0 145 283
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 146 295
new 0 146 295
assign 1 146 296
heldGet 0 146 296
assign 1 146 297
nameGet 0 146 297
assign 1 146 298
add 1 146 298
assign 1 146 299
new 0 146 299
assign 1 146 300
add 1 146 300
assign 1 146 301
heldGet 0 146 301
assign 1 146 302
namepathGet 0 146 302
assign 1 146 303
toString 0 146 303
assign 1 146 304
add 1 146 304
assign 1 146 305
new 2 146 305
throw 1 146 306
assign 1 151 313
ptyListGet 0 151 313
assign 1 151 314
iteratorGet 0 151 314
assign 1 151 317
hasNextGet 0 151 317
assign 1 152 319
nextGet 0 152 319
assign 1 153 320
memSynGet 0 153 320
assign 1 153 321
isTypedGet 0 153 321
assign 1 154 323
heldGet 0 154 323
assign 1 154 324
memSynGet 0 154 324
assign 1 154 325
namepathGet 0 154 325
addUsed 1 154 326
assign 1 158 333
heldGet 0 158 333
assign 1 158 334
orderedMethodsGet 0 158 334
assign 1 158 335
iteratorGet 0 158 335
assign 1 158 338
hasNextGet 0 158 338
assign 1 159 340
nextGet 0 159 340
assign 1 160 341
mtdMapGet 0 160 341
assign 1 160 342
heldGet 0 160 342
assign 1 160 343
nameGet 0 160 343
assign 1 160 344
get 1 160 344
assign 1 161 345
def 1 161 350
assign 1 162 351
rsynGet 0 162 351
assign 1 162 352
def 1 162 357
assign 1 163 358
heldGet 0 163 358
assign 1 163 359
rtypeGet 0 163 359
assign 1 163 360
undef 1 163 365
assign 1 164 366
new 0 164 366
assign 1 164 367
heldGet 0 164 367
assign 1 164 368
nameGet 0 164 368
assign 1 164 369
add 1 164 369
assign 1 164 370
new 0 164 370
assign 1 164 371
add 1 164 371
assign 1 164 372
heldGet 0 164 372
assign 1 164 373
nameGet 0 164 373
assign 1 164 374
add 1 164 374
assign 1 164 375
new 2 164 375
throw 1 164 376
loadClass 1 169 385
assign 1 170 386
depthGet 0 170 386
assign 1 170 387
new 0 170 387
assign 1 170 388
add 1 170 388
assign 1 174 393
has 1 174 393
return 1 174 394
return 1 178 462
assign 1 179 464
new 0 179 464
assign 1 180 465
new 0 180 465
assign 1 181 466
new 0 181 466
assign 1 182 467
new 0 182 467
assign 1 183 468
undef 1 183 473
assign 1 184 474
new 0 184 474
assign 1 185 475
sizeGet 0 185 475
assign 1 186 476
sizeGet 0 186 476
assign 1 187 477
assign 1 188 478
arrayIteratorGet 0 0 478
assign 1 188 481
hasNextGet 0 188 481
assign 1 188 483
nextGet 0 188 483
assign 1 189 484
emitDataGet 0 189 484
assign 1 189 485
methodIndexesGet 0 189 485
assign 1 189 486
new 2 189 486
put 1 189 487
return 1 191 493
assign 1 193 495
getSynNp 1 193 495
assign 1 194 496
new 0 194 496
assign 1 195 497
new 0 195 497
assign 1 197 498
sizeGet 0 197 498
assign 1 197 499
ptyListGet 0 197 499
assign 1 197 500
sizeGet 0 197 500
assign 1 197 501
subtract 1 197 501
assign 1 198 502
libNameGet 0 198 502
assign 1 198 503
equals 1 198 503
integrate 1 198 505
assign 1 199 507
isFinalGet 0 199 507
assign 1 200 509
new 0 200 509
assign 1 200 510
toString 0 200 510
assign 1 200 511
add 1 200 511
assign 1 200 512
new 1 200 512
throw 1 200 513
assign 1 202 515
isLocalGet 0 202 515
assign 1 202 517
libNameGet 0 202 517
assign 1 202 518
notEquals 1 202 518
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 203 530
new 0 203 530
assign 1 203 531
toString 0 203 531
assign 1 203 532
add 1 203 532
assign 1 203 533
new 1 203 533
throw 1 203 534
assign 1 205 536
isLocalGet 0 205 536
assign 1 205 538
not 0 205 538
assign 1 0 540
assign 1 0 543
assign 1 0 547
assign 1 205 550
not 0 205 550
assign 1 0 552
assign 1 0 555
assign 1 0 559
assign 1 206 562
new 0 206 562
assign 1 206 563
toString 0 206 563
assign 1 206 564
add 1 206 564
assign 1 206 565
new 1 206 565
throw 1 206 566
assign 1 208 568
linkedListIteratorGet 0 0 568
assign 1 208 571
hasNextGet 0 208 571
assign 1 208 573
nextGet 0 208 573
assign 1 209 574
getSynNp 1 209 574
assign 1 210 575
closeLibrariesGet 0 210 575
assign 1 210 576
libNameGet 0 210 576
assign 1 210 577
has 1 210 577
assign 1 210 578
not 0 210 578
assign 1 210 580
toString 0 210 580
assign 1 210 581
new 0 210 581
assign 1 210 582
notEquals 1 210 582
assign 1 0 584
assign 1 0 587
assign 1 0 591
assign 1 212 594
new 0 212 594
assign 1 213 595
new 0 213 595
assign 1 215 597
closeLibrariesGet 0 215 597
assign 1 215 598
libNameGet 0 215 598
assign 1 215 599
has 1 215 599
assign 1 215 600
not 0 215 600
assign 1 216 602
new 0 216 602
assign 1 220 609
valueIteratorGet 0 220 609
assign 1 220 612
hasNextGet 0 220 612
assign 1 221 614
nextGet 0 221 614
assign 1 222 615
mtdMapGet 0 222 615
assign 1 222 616
nameGet 0 222 616
assign 1 222 617
get 1 222 617
assign 1 223 618
def 1 223 623
assign 1 224 624
notEquals 1 224 624
assign 1 225 626
new 0 225 626
lastDefSet 1 225 627
assign 1 226 628
new 0 226 628
isOverrideSet 1 226 629
assign 1 227 630
increment 0 227 630
assign 1 230 634
new 0 230 634
isOverrideSet 1 230 635
assign 1 231 636
increment 0 231 636
assign 1 232 637
increment 0 232 637
assign 1 233 638
emitDataGet 0 233 638
assign 1 233 639
methodIndexesGet 0 233 639
assign 1 233 640
new 2 233 640
put 1 233 641
return 1 240 731
assign 1 241 733
new 0 241 733
assign 1 242 734
undef 1 242 739
return 1 242 740
assign 1 243 742
getSynNp 1 243 742
assign 1 244 743
heldGet 0 244 743
assign 1 244 744
orderedVarsGet 0 244 744
assign 1 244 745
iteratorGet 0 244 745
assign 1 244 748
hasNextGet 0 244 748
assign 1 245 750
nextGet 0 245 750
assign 1 246 751
ptyMapGet 0 246 751
assign 1 246 752
heldGet 0 246 752
assign 1 246 753
nameGet 0 246 753
assign 1 246 754
get 1 246 754
assign 1 247 755
def 1 247 760
assign 1 248 761
heldGet 0 248 761
assign 1 248 762
isDeclaredGet 0 248 762
assign 1 249 764
new 0 249 764
assign 1 249 765
heldGet 0 249 765
assign 1 249 766
nameGet 0 249 766
assign 1 249 767
add 1 249 767
assign 1 249 768
new 0 249 768
assign 1 249 769
add 1 249 769
assign 1 249 770
heldGet 0 249 770
assign 1 249 771
namepathGet 0 249 771
assign 1 249 772
toString 0 249 772
assign 1 249 773
add 1 249 773
assign 1 249 774
new 1 249 774
throw 1 249 775
assign 1 251 778
heldGet 0 251 778
assign 1 251 779
memSynGet 0 251 779
assign 1 251 780
isTypedGet 0 251 780
isTypedSet 1 251 781
assign 1 252 782
heldGet 0 252 782
assign 1 252 783
memSynGet 0 252 783
assign 1 252 784
namepathGet 0 252 784
namepathSet 1 252 785
assign 1 256 793
heldGet 0 256 793
assign 1 256 794
orderedMethodsGet 0 256 794
assign 1 256 795
iteratorGet 0 256 795
assign 1 256 798
hasNextGet 0 256 798
assign 1 257 800
nextGet 0 257 800
assign 1 258 801
mtdMapGet 0 258 801
assign 1 258 802
heldGet 0 258 802
assign 1 258 803
nameGet 0 258 803
assign 1 258 804
get 1 258 804
assign 1 259 805
def 1 259 810
assign 1 260 811
isFinalGet 0 260 811
assign 1 261 813
new 0 261 813
assign 1 261 814
heldGet 0 261 814
assign 1 261 815
nameGet 0 261 815
assign 1 261 816
add 1 261 816
assign 1 261 817
new 0 261 817
assign 1 261 818
add 1 261 818
assign 1 261 819
heldGet 0 261 819
assign 1 261 820
namepathGet 0 261 820
assign 1 261 821
toString 0 261 821
assign 1 261 822
add 1 261 822
assign 1 261 823
new 2 261 823
throw 1 261 824
assign 1 263 826
containedGet 0 263 826
assign 1 263 827
firstGet 0 263 827
assign 1 263 828
containedGet 0 263 828
assign 1 264 829
new 0 264 829
assign 1 264 832
argSynsGet 0 264 832
assign 1 264 833
lengthGet 0 264 833
assign 1 264 834
lesser 1 264 834
assign 1 265 836
argSynsGet 0 265 836
assign 1 265 837
get 1 265 837
assign 1 266 838
get 1 266 838
assign 1 266 839
heldGet 0 266 839
checkTypes 5 268 840
assign 1 264 841
increment 0 264 841
assign 1 270 847
rsynGet 0 270 847
assign 1 271 848
heldGet 0 271 848
assign 1 271 849
rtypeGet 0 271 849
assign 1 272 850
undef 1 272 855
assign 1 0 856
assign 1 272 859
undef 1 272 864
assign 1 0 865
assign 1 0 868
assign 1 273 872
undef 1 273 877
assign 1 273 877
not 0 273 877
assign 1 0 879
assign 1 273 882
undef 1 273 887
assign 1 273 887
not 0 273 887
assign 1 0 889
assign 1 0 892
assign 1 274 896
new 0 274 896
assign 1 274 897
heldGet 0 274 897
assign 1 274 898
namepathGet 0 274 898
assign 1 274 899
toString 0 274 899
assign 1 274 900
add 1 274 900
assign 1 274 901
new 2 274 901
throw 1 274 902
checkTypes 5 278 906
assign 1 285 942
isTypedGet 0 285 942
assign 1 285 943
isTypedGet 0 285 943
assign 1 285 944
notEquals 1 285 944
assign 1 286 946
new 0 286 946
assign 1 286 947
heldGet 0 286 947
assign 1 286 948
namepathGet 0 286 948
assign 1 286 949
toString 0 286 949
assign 1 286 950
add 1 286 950
assign 1 286 951
new 2 286 951
throw 1 286 952
assign 1 287 955
isTypedGet 0 287 955
assign 1 290 957
isSelfGet 0 290 957
assign 1 290 959
isSelfGet 0 290 959
assign 1 0 961
assign 1 0 964
assign 1 0 968
return 1 291 971
assign 1 293 973
namepathGet 0 293 973
assign 1 293 974
getSynNp 1 293 974
assign 1 294 975
allTypesGet 0 294 975
assign 1 294 976
namepathGet 0 294 976
assign 1 294 977
has 1 294 977
assign 1 294 978
not 0 294 978
assign 1 295 980
new 0 295 980
assign 1 295 981
heldGet 0 295 981
assign 1 295 982
namepathGet 0 295 982
assign 1 295 983
toString 0 295 983
assign 1 295 984
add 1 295 984
assign 1 295 985
new 2 295 985
throw 1 295 986
new 0 301 1012
assign 1 302 1013
heldGet 0 302 1013
assign 1 302 1014
orderedVarsGet 0 302 1014
assign 1 302 1015
iteratorGet 0 302 1015
assign 1 302 1018
hasNextGet 0 302 1018
assign 1 303 1020
nextGet 0 303 1020
assign 1 304 1021
heldGet 0 304 1021
assign 1 304 1022
isDeclaredGet 0 304 1022
assign 1 304 1023
not 0 304 1023
assign 1 305 1025
new 0 305 1025
assign 1 305 1026
heldGet 0 305 1026
assign 1 305 1027
nameGet 0 305 1027
assign 1 305 1028
add 1 305 1028
assign 1 305 1029
new 0 305 1029
assign 1 305 1030
add 1 305 1030
assign 1 305 1031
heldGet 0 305 1031
assign 1 305 1032
namepathGet 0 305 1032
assign 1 305 1033
toString 0 305 1033
assign 1 305 1034
add 1 305 1034
assign 1 305 1035
new 2 305 1035
throw 1 305 1036
loadClass 1 308 1043
assign 1 309 1044
new 0 309 1044
assign 1 314 1072
heldGet 0 314 1072
assign 1 314 1073
fromFileGet 0 314 1073
assign 1 315 1074
heldGet 0 315 1074
assign 1 315 1075
namepathGet 0 315 1075
assign 1 316 1076
heldGet 0 316 1076
assign 1 316 1077
libNameGet 0 316 1077
assign 1 317 1078
heldGet 0 317 1078
assign 1 317 1079
isFinalGet 0 317 1079
assign 1 318 1080
heldGet 0 318 1080
assign 1 318 1081
isLocalGet 0 318 1081
assign 1 319 1082
heldGet 0 319 1082
assign 1 319 1083
isNotNullGet 0 319 1083
assign 1 320 1084
heldGet 0 320 1084
assign 1 320 1085
usedGet 0 320 1085
assign 1 320 1086
iteratorGet 0 320 1086
assign 1 320 1089
hasNextGet 0 320 1089
assign 1 321 1091
nextGet 0 321 1091
assign 1 322 1092
toString 0 322 1092
put 1 322 1093
assign 1 324 1099
heldGet 0 324 1099
assign 1 324 1100
orderedVarsGet 0 324 1100
assign 1 324 1101
iteratorGet 0 324 1101
assign 1 324 1104
hasNextGet 0 324 1104
assign 1 325 1106
nextGet 0 325 1106
assign 1 326 1107
new 2 326 1107
addValue 1 327 1108
assign 1 329 1114
heldGet 0 329 1114
assign 1 329 1115
orderedMethodsGet 0 329 1115
assign 1 329 1116
iteratorGet 0 329 1116
assign 1 329 1119
hasNextGet 0 329 1119
assign 1 330 1121
nextGet 0 330 1121
assign 1 331 1122
new 2 331 1122
addValue 1 332 1123
postLoad 0 334 1129
assign 1 338 1180
new 0 338 1180
assign 1 339 1181
new 0 339 1181
assign 1 342 1182
iteratorGet 0 342 1182
assign 1 342 1185
hasNextGet 0 342 1185
assign 1 343 1187
nextGet 0 343 1187
assign 1 344 1188
nameGet 0 344 1188
assign 1 344 1189
has 1 344 1189
assign 1 344 1190
not 0 344 1190
assign 1 346 1192
nameGet 0 346 1192
put 2 346 1193
assign 1 350 1200
new 0 350 1200
assign 1 351 1201
new 0 351 1201
assign 1 352 1202
iteratorGet 0 352 1202
assign 1 352 1205
hasNextGet 0 352 1205
assign 1 353 1207
nextGet 0 353 1207
assign 1 354 1208
nameGet 0 354 1208
assign 1 354 1209
has 1 354 1209
assign 1 354 1210
not 0 354 1210
assign 1 355 1212
nameGet 0 355 1212
assign 1 355 1213
get 1 355 1213
mposSet 1 356 1214
assign 1 357 1215
new 0 357 1215
assign 1 357 1216
add 1 357 1216
addValue 1 358 1217
assign 1 359 1218
nameGet 0 359 1218
assign 1 359 1219
nameGet 0 359 1219
put 2 359 1220
assign 1 362 1227
assign 1 364 1228
new 0 364 1228
assign 1 366 1229
iteratorGet 0 366 1229
assign 1 366 1232
hasNextGet 0 366 1232
assign 1 367 1234
nextGet 0 367 1234
assign 1 369 1235
nameGet 0 369 1235
put 2 369 1236
assign 1 371 1237
nameGet 0 371 1237
assign 1 371 1238
has 1 371 1238
assign 1 371 1239
not 0 371 1239
assign 1 372 1241
nameGet 0 372 1241
put 2 372 1242
assign 1 376 1249
new 0 376 1249
assign 1 377 1250
new 0 377 1250
assign 1 378 1251
iteratorGet 0 378 1251
assign 1 378 1254
hasNextGet 0 378 1254
assign 1 379 1256
nextGet 0 379 1256
assign 1 380 1257
nameGet 0 380 1257
assign 1 380 1258
has 1 380 1258
assign 1 380 1259
not 0 380 1259
assign 1 381 1261
nameGet 0 381 1261
assign 1 381 1262
get 1 381 1262
assign 1 390 1263
nameGet 0 390 1263
assign 1 390 1264
get 1 390 1264
assign 1 391 1265
declarationGet 0 391 1265
assign 1 391 1266
undef 1 391 1271
assign 1 392 1272
originGet 0 392 1272
declarationSet 1 392 1273
assign 1 394 1275
declarationGet 0 394 1275
declarationSet 1 394 1276
mtdxSet 1 395 1277
assign 1 396 1278
increment 0 396 1278
addValue 1 397 1279
assign 1 398 1280
nameGet 0 398 1280
assign 1 398 1281
nameGet 0 398 1281
put 2 398 1282
assign 1 401 1289
assign 1 403 1290
linkedListIteratorGet 0 0 1290
assign 1 403 1293
hasNextGet 0 403 1293
assign 1 403 1295
nextGet 0 403 1295
put 2 404 1296
assign 1 405 1297
put 2 408 1303
assign 1 412 1337
new 0 412 1337
assign 1 412 1338
new 1 412 1338
assign 1 413 1344
new 0 413 1344
assign 1 413 1345
get 1 413 1345
assign 1 413 1346
undef 1 413 1351
assign 1 414 1352
new 0 414 1352
assign 1 414 1353
new 0 414 1353
put 2 414 1354
assign 1 415 1355
new 0 415 1355
assign 1 415 1356
new 0 415 1356
put 2 415 1357
assign 1 416 1358
new 0 416 1358
assign 1 416 1359
new 0 416 1359
put 2 416 1360
assign 1 417 1361
new 0 417 1361
assign 1 417 1362
new 0 417 1362
put 2 417 1363
assign 1 418 1364
new 0 418 1364
assign 1 418 1365
new 0 418 1365
put 2 418 1366
assign 1 419 1367
new 0 419 1367
assign 1 419 1368
new 0 419 1368
put 2 419 1369
assign 1 420 1370
new 0 420 1370
assign 1 420 1371
new 0 420 1371
put 2 420 1372
assign 1 421 1373
new 0 421 1373
assign 1 421 1374
new 0 421 1374
put 2 421 1375
assign 1 422 1376
new 0 422 1376
assign 1 422 1377
new 0 422 1377
put 2 422 1378
assign 1 423 1379
new 0 423 1379
assign 1 423 1380
new 0 423 1380
put 2 423 1381
assign 1 424 1382
new 0 424 1382
assign 1 424 1383
new 0 424 1383
put 2 424 1384
assign 1 425 1385
new 0 425 1385
assign 1 425 1386
new 0 425 1386
put 2 425 1387
assign 1 427 1389
new 2 427 1389
return 1 427 1390
return 1 0 1393
assign 1 0 1396
return 1 0 1400
assign 1 0 1403
return 1 0 1407
assign 1 0 1410
return 1 0 1414
assign 1 0 1417
return 1 0 1421
assign 1 0 1424
return 1 0 1428
assign 1 0 1431
return 1 0 1435
assign 1 0 1438
return 1 0 1442
assign 1 0 1445
return 1 0 1449
assign 1 0 1452
return 1 0 1456
assign 1 0 1459
return 1 0 1463
assign 1 0 1466
return 1 0 1470
assign 1 0 1473
return 1 0 1477
assign 1 0 1480
return 1 0 1484
assign 1 0 1487
return 1 0 1491
assign 1 0 1494
return 1 0 1498
assign 1 0 1501
return 1 0 1505
assign 1 0 1508
return 1 0 1512
assign 1 0 1515
return 1 0 1519
assign 1 0 1522
return 1 0 1526
assign 1 0 1529
return 1 0 1533
assign 1 0 1536
return 1 0 1540
assign 1 0 1543
return 1 0 1547
assign 1 0 1550
return 1 0 1554
assign 1 0 1557
return 1 0 1561
assign 1 0 1564
return 1 0 1568
assign 1 0 1571
return 1 0 1575
assign 1 0 1578
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 153365600: return bem_ptyMapGet_0();
case 1314364113: return bem_newMbrsGet_0();
case 2097069068: return bem_integratedGet_0();
case 1803479881: return bem_libNameGet_0();
case 287040793: return bem_hashGet_0();
case 1443447938: return bem_directMethodsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2033393684: return bem_ptyListGet_0();
case 842582618: return bem_isLocalGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 311680096: return bem_allNamesGet_0();
case 2058095605: return bem_signatureChangedGet_0();
case 1774940957: return bem_toString_0();
case 786424307: return bem_tagGet_0();
case 492006165: return bem_directPropertiesGet_0();
case 834964524: return bem_defMtdsGet_0();
case 1820417453: return bem_create_0();
case 1974592946: return bem_superListGet_0();
case 1760712968: return bem_signatureCheckedGet_0();
case 1274615854: return bem_allAncestorsCloseGet_0();
case 363636983: return bem_isNotNullGet_0();
case 1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1012494862: return bem_once_0();
case 1631955979: return bem_foreignClassesGet_0();
case 1214937871: return bem_newMtdsGet_0();
case 795036897: return bem_fromFileGet_0();
case 845792839: return bem_iteratorGet_0();
case 71634217: return bem_iCheckedGet_0();
case 287367803: return bem_isFinalGet_0();
case 354142775: return bem_namepathGet_0();
case 202810500: return bem_depthGet_0();
case 1477961836: return bem_mtdListGet_0();
case 345555227: return bem_usesGet_0();
case 1308786538: return bem_echo_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 244359240: return bem_mtdMapGet_0();
case 2055025483: return bem_serializeContents_0();
case 443668840: return bem_methodNotDefined_0();
case 986531569: return bem_allTypesGet_0();
case 481879936: return bem_hasDefaultGet_0();
case 1413594071: return bem_postLoad_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 68632810: return bem_superNpGet_0();
case 1495449800: return bem_maxMtdxGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 1118052001: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 82716470: return bem_iCheckedSet_1(bevd_0);
case 1432365685: return bem_directMethodsSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 356637480: return bem_usesSet_1(bevd_0);
case 975449316: return bem_allTypesSet_1(bevd_0);
case 142283347: return bem_ptyMapSet_1(bevd_0);
case 79715063: return bem_superNpSet_1(bevd_0);
case 1749630715: return bem_signatureCheckedSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2085986815: return bem_integratedSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 2047013352: return bem_signatureChangedSet_1(bevd_0);
case 255441493: return bem_mtdMapSet_1(bevd_0);
case 300597843: return bem_allNamesSet_1(bevd_0);
case 846046777: return bem_defMtdsSet_1(bevd_0);
case 831500365: return bem_isLocalSet_1(bevd_0);
case 480923912: return bem_directPropertiesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1489044089: return bem_mtdListSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1203855618: return bem_newMtdsSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1963510693: return bem_superListSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1285698107: return bem_allAncestorsCloseSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 340843364: return bem_loadClass_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1156342947: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1325446366: return bem_newMbrsSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 213892753: return bem_depthSet_1(bevd_0);
case 1620873726: return bem_foreignClassesSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2044475937: return bem_ptyListSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1694832085: return bem_checkInheritance_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 913726521: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildClassSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildClassSyn.bevs_inst = (BEC_2_5_8_BuildClassSyn)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildClassSyn.bevs_inst;
}
}
