package be.BEL_4_Base;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_8_JsonParseLog extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_JsonParseLog() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x4C,0x6F,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x47,0x6F,0x74,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7C};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 12));
private static byte[] bels_1 = {0x7C};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_1, 1));
private static byte[] bels_2 = {0x62,0x65,0x67,0x69,0x6E,0x4D,0x61,0x70};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_2, 8));
private static byte[] bels_3 = {0x65,0x6E,0x64,0x4D,0x61,0x70};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_3, 6));
private static byte[] bels_4 = {0x6B,0x76,0x4D,0x69,0x64};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_4, 5));
private static byte[] bels_5 = {0x62,0x65,0x67,0x69,0x6E,0x4C,0x69,0x73,0x74};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_5, 9));
private static byte[] bels_6 = {0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_6, 7));
private static byte[] bels_7 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x72,0x75,0x65};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_7, 10));
private static byte[] bels_8 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x46,0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_8, 11));
private static byte[] bels_9 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x4E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_9, 10));
private static byte[] bels_10 = {0x47,0x6F,0x74,0x20,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x20,0x7C};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_10, 13));
private static byte[] bels_11 = {0x7C};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_11, 1));
public static BEC_2_4_8_JsonParseLog bevs_inst;
public BEC_2_4_8_JsonParseLog bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_str);
bevt_3_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beginMap_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_2;
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_endMap_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_kvMid_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beginList_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_5;
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_endList_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_handleTrue_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_7;
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_handleFalse_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_8;
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_handleNull_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_9;
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_10;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_int);
bevt_3_tmpvar_phold = bevo_11;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {601, 601, 601, 601, 601, 605, 605, 609, 609, 613, 613, 617, 617, 621, 621, 625, 625, 629, 629, 633, 633, 637, 637, 637, 637, 637};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 42, 43, 44, 49, 50, 55, 56, 61, 62, 67, 68, 73, 74, 79, 80, 85, 86, 91, 92, 100, 101, 102, 103, 104};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 601 40
new 0 601 40
assign 1 601 41
add 1 601 41
assign 1 601 42
new 0 601 42
assign 1 601 43
add 1 601 43
print 0 601 44
assign 1 605 49
new 0 605 49
print 0 605 50
assign 1 609 55
new 0 609 55
print 0 609 56
assign 1 613 61
new 0 613 61
print 0 613 62
assign 1 617 67
new 0 617 67
print 0 617 68
assign 1 621 73
new 0 621 73
print 0 621 74
assign 1 625 79
new 0 625 79
print 0 625 80
assign 1 629 85
new 0 629 85
print 0 629 86
assign 1 633 91
new 0 633 91
print 0 633 92
assign 1 637 100
new 0 637 100
assign 1 637 101
add 1 637 101
assign 1 637 102
new 0 637 102
assign 1 637 103
add 1 637 103
print 0 637 104
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1431394368: return bem_handleNull_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 435843368: return bem_beginList_0();
case 1308786538: return bem_echo_0();
case 1398681994: return bem_endList_0();
case 104713553: return bem_new_0();
case 368775858: return bem_kvMid_0();
case 1262128633: return bem_handleTrue_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 1095000804: return bem_beginMap_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 506014516: return bem_handleFalse_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1708368370: return bem_endMap_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1774332469: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1512002600: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_JsonParseLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_JsonParseLog.bevs_inst = (BEC_2_4_8_JsonParseLog)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_JsonParseLog.bevs_inst;
}
}
