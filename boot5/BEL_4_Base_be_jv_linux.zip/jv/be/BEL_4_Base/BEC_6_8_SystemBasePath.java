package be.BEL_4_Base;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_6_8_SystemBasePath extends BEC_6_6_SystemObject {
public BEC_6_8_SystemBasePath() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(1));
public static BEC_6_8_SystemBasePath bevs_inst;
public BEC_4_6_TextString bevp_separator;
public BEC_4_6_TextString bevp_path;
public BEC_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_new_1(BEC_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_4_6_TextString(1, bels_0));
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromString_1(BEC_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_4_6_TextString bem_toString_1(BEC_4_6_TextString beva_newsep) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toStringWithSeparator_1(BEC_4_6_TextString beva_newsep) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_4_6_TextString bevl_npath = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_npath = bevt_0_tmpvar_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_8_SystemBasePath bem_add_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_9_10_ContainerLinkedList bevl_spath = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_l = null;
BEC_4_6_TextString bevl_rstr = null;
BEC_6_8_SystemBasePath bevl_rpath = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_3_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_emptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 383 */ {
bevt_4_tmpvar_phold = this.bem_copy_0();
return (BEC_6_8_SystemBasePath) bevt_4_tmpvar_phold;
} /* Line: 384 */
bevt_5_tmpvar_phold = beva_other.bemd_0(1359432006, BEL_4_Base.bevn_isAbsoluteGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 386 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
return (BEC_6_8_SystemBasePath) bevt_6_tmpvar_phold;
} /* Line: 387 */
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevl_spath = (BEC_9_10_ContainerLinkedList) bevt_7_tmpvar_phold.bemd_1(2001811380, BEL_4_Base.bevn_split_1, bevp_separator);
bevl_i = bevl_spath.bem_iteratorGet_0();
while (true)
 /* Line: 391 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 391 */ {
bevl_l = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 393 */
 else  /* Line: 391 */ {
break;
} /* Line: 391 */
} /* Line: 391 */
bevt_9_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_rstr = bevt_9_tmpvar_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_6_8_SystemBasePath) this.bem_copy_0();
bevl_rpath = (BEC_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return bevl_rpath;
} /*method end*/
public BEC_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_6_8_SystemBasePath bevl_rpath = null;
BEC_4_3_MathInt bevl_rpl = null;
BEC_4_3_MathInt bevl_c = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_6_8_SystemBasePath) this.bem_copy_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpvar_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_iteratorGet_0();
while (true)
 /* Line: 409 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 409 */ {
bevt_2_tmpvar_phold = bevl_c.bem_lesser_1(bevl_rpl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 410 */ {
bevt_3_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_rpath.bem_addStep_1(bevt_3_tmpvar_phold);
} /* Line: 411 */
 else  /* Line: 412 */ {
bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 413 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 415 */
 else  /* Line: 409 */ {
break;
} /* Line: 409 */
} /* Line: 409 */
bevt_4_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 417 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 418 */
return bevl_rpath;
} /*method end*/
public BEC_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (bevp_path == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 424 */ {
bevt_4_tmpvar_phold = bevp_path.bem_toString_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 424 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 424 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 424 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevp_path.bem_getPoint_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 425 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 426 */
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 432 */ {
bevt_1_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
} /* Line: 433 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_isAbsoluteGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 438 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 439 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_trimParents_1(BEC_4_3_MathInt beva_howMany) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = beva_howMany.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 444 */ {
this.bem_makeNonAbsolute_0();
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 449 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(beva_howMany);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 449 */ {
if (bevl_next == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 450 */ {
break;
} /* Line: 450 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 449 */
 else  /* Line: 449 */ {
break;
} /* Line: 449 */
} /* Line: 449 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 455 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_addStep_1(BEC_6_6_SystemObject beva_step) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_4_3_MathInt bevl_fp = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevp_path = bevt_1_tmpvar_phold.bem_emptyGet_0();
} /* Line: 468 */
 else  /* Line: 469 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_2_tmpvar_phold = bevl_fp.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpvar_phold, bevt_4_tmpvar_phold);
} /* Line: 470 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addStepList_1(BEC_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_iteratorGet_0();
while (true)
 /* Line: 476 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fpath.bem_addValue_1(bevt_1_tmpvar_phold);
} /* Line: 477 */
 else  /* Line: 476 */ {
break;
} /* Line: 476 */
} /* Line: 476 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addSteps_1(BEC_6_6_SystemObject beva_step) throws Throwable {
BEC_6_8_SystemBasePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_addStep_1(beva_step);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_addSteps_2(BEC_6_6_SystemObject beva_s1, BEC_6_6_SystemObject beva_s2) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_6_8_SystemBasePath bevl_other = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_other = (BEC_6_8_SystemBasePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpvar_phold);
return bevl_other;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_x == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 516 */ {
bevt_3_tmpvar_phold = beva_x.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 516 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 516 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 516 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 516 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 516 */ {
bevt_5_tmpvar_phold = beva_x.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_4_tmpvar_phold = bevp_path.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 516 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 516 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 516 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 517 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_subPath_1(BEC_4_3_MathInt beva_start) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_subPath_2(beva_start, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_subPath_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_st = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_res = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_st = this.bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 528 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 529 */
 else  /* Line: 530 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 531 */
bevl_res = this.bem_create_0();
bevl_res.bemd_1(410741679, BEL_4_Base.bevn_separatorSet_1, bevp_separator);
bevt_1_tmpvar_phold = BEC_4_7_TextStrings.bevs_inst.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(389107089, BEL_4_Base.bevn_pathSet_1, bevt_1_tmpvar_phold);
return bevl_res;
} /*method end*/
public BEC_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_6_6_SystemObject bem_separatorSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_separator = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_6_6_SystemObject bem_pathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_path = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {344, 344, 348, 349, 353, 357, 361, 361, 365, 366, 366, 367, 371, 371, 375, 375, 375, 379, 379, 379, 383, 383, 383, 383, 384, 384, 386, 387, 387, 389, 390, 390, 391, 391, 392, 393, 395, 395, 396, 397, 399, 403, 404, 405, 405, 406, 407, 408, 409, 409, 410, 411, 411, 413, 415, 417, 418, 420, 424, 424, 0, 424, 424, 424, 424, 0, 0, 424, 424, 425, 425, 425, 426, 426, 428, 428, 432, 433, 433, 433, 438, 438, 439, 444, 444, 445, 446, 448, 449, 449, 450, 450, 451, 452, 453, 449, 455, 460, 461, 462, 466, 467, 467, 468, 468, 470, 470, 470, 470, 475, 476, 476, 477, 477, 479, 483, 483, 487, 488, 489, 490, 494, 495, 496, 496, 497, 501, 501, 505, 505, 509, 509, 509, 516, 516, 0, 516, 0, 0, 0, 516, 516, 0, 0, 517, 517, 519, 519, 523, 523, 527, 528, 528, 529, 531, 533, 534, 535, 535, 536, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 30, 34, 38, 39, 45, 46, 47, 48, 52, 53, 58, 59, 60, 65, 66, 67, 86, 87, 88, 89, 91, 92, 94, 96, 97, 99, 100, 101, 102, 105, 107, 108, 114, 115, 116, 117, 118, 131, 132, 133, 134, 135, 136, 137, 138, 141, 143, 145, 146, 149, 151, 157, 159, 161, 176, 181, 182, 185, 186, 187, 188, 190, 193, 197, 198, 200, 201, 202, 204, 205, 207, 208, 214, 216, 217, 218, 225, 226, 228, 241, 242, 244, 245, 246, 247, 250, 252, 257, 260, 261, 262, 263, 269, 275, 276, 277, 287, 288, 293, 294, 295, 298, 299, 300, 301, 310, 311, 314, 316, 317, 323, 328, 329, 333, 334, 335, 336, 342, 343, 344, 345, 346, 350, 351, 355, 356, 361, 362, 363, 374, 379, 380, 383, 385, 388, 392, 395, 396, 398, 401, 405, 406, 408, 409, 413, 414, 422, 423, 428, 429, 432, 434, 435, 436, 437, 438, 441, 444, 448, 451};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 344 20
new 0 344 20
new 1 344 21
assign 1 348 25
new 0 348 25
fromString 1 349 26
assign 1 353 30
return 1 357 34
assign 1 361 38
toStringWithSeparator 1 361 38
return 1 361 39
assign 1 365 45
split 1 365 45
assign 1 366 46
new 0 366 46
assign 1 366 47
join 2 366 47
return 1 367 48
assign 1 371 52
split 1 371 52
return 1 371 53
assign 1 375 58
split 1 375 58
assign 1 375 59
firstGet 0 375 59
return 1 375 60
assign 1 379 65
split 1 379 65
assign 1 379 66
lastGet 0 379 66
return 1 379 67
assign 1 383 86
pathGet 0 383 86
assign 1 383 87
new 0 383 87
assign 1 383 88
emptyGet 0 383 88
assign 1 383 89
equals 1 383 89
assign 1 384 91
copy 0 384 91
return 1 384 92
assign 1 386 94
isAbsoluteGet 0 386 94
assign 1 387 96
copy 0 387 96
return 1 387 97
assign 1 389 99
split 1 389 99
assign 1 390 100
pathGet 0 390 100
assign 1 390 101
split 1 390 101
assign 1 391 102
iteratorGet 0 391 102
assign 1 391 105
hasNextGet 0 391 105
assign 1 392 107
nextGet 0 392 107
addValue 1 393 108
assign 1 395 114
new 0 395 114
assign 1 395 115
join 2 395 115
assign 1 396 116
copy 0 396 116
assign 1 397 117
fromString 1 397 117
return 1 399 118
assign 1 403 131
split 1 403 131
assign 1 404 132
copy 0 404 132
assign 1 405 133
new 0 405 133
pathSet 1 405 134
assign 1 406 135
lengthGet 0 406 135
assign 1 407 136
decrement 0 407 136
assign 1 408 137
new 0 408 137
assign 1 409 138
iteratorGet 0 409 138
assign 1 409 141
hasNextGet 0 409 141
assign 1 410 143
lesser 1 410 143
assign 1 411 145
nextGet 0 411 145
addStep 1 411 146
nextGet 0 413 149
assign 1 415 151
increment 0 415 151
assign 1 417 157
isAbsoluteGet 0 417 157
makeAbsolute 0 418 159
return 1 420 161
assign 1 424 176
undef 1 424 181
assign 1 0 182
assign 1 424 185
toString 0 424 185
assign 1 424 186
sizeGet 0 424 186
assign 1 424 187
new 0 424 187
assign 1 424 188
lesser 1 424 188
assign 1 0 190
assign 1 0 193
assign 1 424 197
new 0 424 197
return 1 424 198
assign 1 425 200
new 0 425 200
assign 1 425 201
getPoint 1 425 201
assign 1 425 202
equals 1 425 202
assign 1 426 204
new 0 426 204
return 1 426 205
assign 1 428 207
new 0 428 207
return 1 428 208
assign 1 432 214
isAbsoluteGet 0 432 214
assign 1 433 216
new 0 433 216
assign 1 433 217
sizeGet 0 433 217
assign 1 433 218
substring 2 433 218
assign 1 438 225
isAbsoluteGet 0 438 225
assign 1 438 226
not 0 438 226
assign 1 439 228
add 1 439 228
assign 1 444 241
new 0 444 241
assign 1 444 242
greater 1 444 242
makeNonAbsolute 0 445 244
assign 1 446 245
split 1 446 245
assign 1 448 246
firstNodeGet 0 448 246
assign 1 449 247
new 0 449 247
assign 1 449 250
lesser 1 449 250
assign 1 450 252
undef 1 450 257
assign 1 451 260
assign 1 452 261
nextGet 0 452 261
delete 0 453 262
assign 1 449 263
increment 0 449 263
assign 1 455 269
join 2 455 269
assign 1 460 275
split 1 460 275
addValue 1 461 276
assign 1 462 277
join 2 462 277
assign 1 466 287
find 1 466 287
assign 1 467 288
undef 1 467 293
assign 1 468 294
new 0 468 294
assign 1 468 295
emptyGet 0 468 295
assign 1 470 298
new 0 470 298
assign 1 470 299
add 1 470 299
assign 1 470 300
sizeGet 0 470 300
assign 1 470 301
substring 2 470 301
assign 1 475 310
split 1 475 310
assign 1 476 311
iteratorGet 0 476 311
assign 1 476 314
hasNextGet 0 476 314
assign 1 477 316
nextGet 0 477 316
addValue 1 477 317
assign 1 479 323
join 2 479 323
assign 1 483 328
addStep 1 483 328
return 1 483 329
assign 1 487 333
split 1 487 333
addValue 1 488 334
addValue 1 489 335
assign 1 490 336
join 2 490 336
assign 1 494 342
create 0 494 342
copyTo 1 495 343
assign 1 496 344
copy 0 496 344
pathSet 1 496 345
return 1 497 346
assign 1 501 350
split 1 501 350
return 1 501 351
assign 1 505 355
hashGet 0 505 355
return 1 505 356
assign 1 509 361
equals 1 509 361
assign 1 509 362
not 0 509 362
return 1 509 363
assign 1 516 374
undef 1 516 379
assign 1 0 380
assign 1 516 383
otherType 1 516 383
assign 1 0 385
assign 1 0 388
assign 1 0 392
assign 1 516 395
pathGet 0 516 395
assign 1 516 396
notEquals 1 516 396
assign 1 0 398
assign 1 0 401
assign 1 517 405
new 0 517 405
return 1 517 406
assign 1 519 408
new 0 519 408
return 1 519 409
assign 1 523 413
subPath 2 523 413
return 1 523 414
assign 1 527 422
stepsGet 0 527 422
assign 1 528 423
undef 1 528 428
assign 1 529 429
subList 1 529 429
assign 1 531 432
subList 2 531 432
assign 1 533 434
create 0 533 434
separatorSet 1 534 435
assign 1 535 436
join 2 535 436
pathSet 1 535 437
return 1 536 438
return 1 0 441
assign 1 0 444
return 1 0 448
assign 1 0 451
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case 1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 471950299: return bem_lastStepGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case 935459934: return bem_deleteFirstStep_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1719674549: return bem_firstStepGet_0();
case 723109216: return bem_stepsGet_0();
case 1354714650: return bem_copy_0();
case 400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case 1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 630006451: return bem_fromString_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 488966921: return bem_subPath_1((BEC_4_3_MathInt) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 389107089: return bem_pathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1787791811: return bem_addStepList_1((BEC_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case 2006569863: return bem_trimParents_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 488966920: return bem_subPath_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_8_SystemBasePath.bevs_inst = (BEC_6_8_SystemBasePath)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_8_SystemBasePath.bevs_inst;
}
}
