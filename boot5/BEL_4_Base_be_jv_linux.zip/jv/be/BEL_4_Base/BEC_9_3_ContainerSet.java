package be.BEL_4_Base;
/* IO:File: source/base/Map.be */
public class BEC_9_3_ContainerSet extends BEC_6_6_SystemObject {
public BEC_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(1));
public static BEC_9_3_ContainerSet bevs_inst;
public BEC_9_5_ContainerArray bevp_slots;
public BEC_4_3_MathInt bevp_modu;
public BEC_4_3_MathInt bevp_multi;
public BEC_9_3_9_ContainerSetRelations bevp_rel;
public BEC_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_4_3_MathInt bevp_size;
public BEC_5_4_LogicBool bevp_innerPutAdded;
public BEC_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_new_1(BEC_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_9_5_ContainerArray()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_4_3_MathInt(2));
bevp_rel = (BEC_9_3_9_ContainerSetRelations) BEC_9_3_9_ContainerSetRelations.bevs_inst.bem_new_0();
bevp_baseNode = (BEC_9_3_7_ContainerSetSetNode) (new BEC_9_3_7_ContainerSetSetNode()).bem_new_0();
bevp_size = (new BEC_4_3_MathInt(0));
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_size.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 237 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = bevp_size.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 244 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_21_SetSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_21_SetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_insertAll_2(BEC_9_5_ContainerArray beva_ninner, BEC_9_5_ContainerArray beva_ir) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = beva_ir.bem_iteratorGet_0();
while (true)
 /* Line: 262 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 262 */ {
bevl_ni = (BEC_9_3_7_ContainerSetSetNode) bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_ni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_4_tmpvar_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpvar_phold = this.bem_innerPut_4(bevt_4_tmpvar_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 265 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 266 */
} /* Line: 265 */
} /* Line: 264 */
 else  /* Line: 262 */ {
break;
} /* Line: 262 */
} /* Line: 262 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_rehash_1(BEC_9_5_ContainerArray beva_slt) throws Throwable {
BEC_4_3_MathInt bevl_nslots = null;
BEC_9_5_ContainerArray bevl_ninner = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpvar_phold = bevo_2;
bevl_nslots = bevt_0_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
bevl_ninner = (new BEC_9_5_ContainerArray()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 277 */ {
bevt_4_tmpvar_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 277 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_9_5_ContainerArray()).bem_new_1(bevl_nslots);
} /* Line: 279 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
return bevl_ninner;
} /*method end*/
public BEC_5_4_LogicBool bem_contentsEqual_1(BEC_9_3_ContainerSet beva_other) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (beva_other == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 285 */ {
bevt_4_tmpvar_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpvar_phold = this.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 285 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 285 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 286 */
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 288 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 288 */ {
bevl_i = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_other.bem_has_1(bevl_i);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /* Line: 289 */
} /* Line: 289 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_innerPut_4(BEC_6_6_SystemObject beva_k, BEC_6_6_SystemObject beva_v, BEC_6_6_SystemObject beva_inode, BEC_9_5_ContainerArray beva_slt) throws Throwable {
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_3;
bevt_1_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 298 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 299 */
} /* Line: 298 */
 else  /* Line: 301 */ {
bevl_hval = (BEC_4_3_MathInt) beva_inode.bemd_0(449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 302 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 306 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 308 */ {
if (beva_inode == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevt_6_tmpvar_phold = bevp_baseNode.bem_create_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_3(104713556, BEL_4_Base.bevn_new_3, bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpvar_phold);
} /* Line: 310 */
 else  /* Line: 311 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 312 */
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 315 */
 else  /* Line: 308 */ {
bevt_10_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 316 */ {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /* Line: 317 */
 else  /* Line: 308 */ {
bevt_13_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpvar_phold, beva_k);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 318 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_14_tmpvar_phold;
} /* Line: 322 */
 else  /* Line: 323 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_15_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 325 */ {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_16_tmpvar_phold;
} /* Line: 326 */
} /* Line: 325 */
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 308 */
} /*method end*/
public BEC_6_6_SystemObject bem_put_1(BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 333 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 336 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 336 */ {
bevl_slt = (BEC_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
} /* Line: 337 */
 else  /* Line: 336 */ {
break;
} /* Line: 336 */
} /* Line: 336 */
bevp_slots = bevl_slt;
} /* Line: 339 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 341 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 342 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_get_1(BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 351 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 355 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 357 */ {
return null;
} /* Line: 358 */
 else  /* Line: 357 */ {
bevt_5_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 359 */ {
return null;
} /* Line: 360 */
 else  /* Line: 357 */ {
bevt_7_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpvar_phold, beva_k);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 361 */ {
bevt_8_tmpvar_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpvar_phold;
} /* Line: 362 */
 else  /* Line: 363 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_9_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 365 */ {
return null;
} /* Line: 366 */
} /* Line: 365 */
} /* Line: 357 */
} /* Line: 357 */
} /* Line: 357 */
} /*method end*/
public BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_5;
bevt_0_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 377 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 381 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 383 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 384 */
 else  /* Line: 383 */ {
bevt_6_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /* Line: 386 */
 else  /* Line: 383 */ {
bevt_9_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpvar_phold, beva_k);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 387 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 388 */
 else  /* Line: 389 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_11_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /* Line: 392 */
} /* Line: 391 */
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 383 */
} /*method end*/
public BEC_6_6_SystemObject bem_delete_1(BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_6;
bevt_1_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 404 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 408 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 410 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 411 */
 else  /* Line: 410 */ {
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 412 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 413 */
 else  /* Line: 410 */ {
bevt_10_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpvar_phold, beva_k);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 414 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 418 */ {
bevt_11_tmpvar_phold = bevl_sl.bem_lesser_1(bevl_modu);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 420 */ {
bevt_15_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 420 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 420 */ {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_16_tmpvar_phold;
} /* Line: 421 */
 else  /* Line: 422 */ {
bevt_18_tmpvar_phold = bevo_7;
bevt_17_tmpvar_phold = bevl_sl.bem_subtract_1(bevt_18_tmpvar_phold);
bevl_slt.bem_put_2(bevt_17_tmpvar_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 424 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 426 */
 else  /* Line: 418 */ {
break;
} /* Line: 418 */
} /* Line: 418 */
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_19_tmpvar_phold;
} /* Line: 428 */
 else  /* Line: 429 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_20_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 431 */ {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_21_tmpvar_phold;
} /* Line: 432 */
} /* Line: 431 */
} /* Line: 410 */
} /* Line: 410 */
} /* Line: 410 */
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_6_6_SystemObject bevl_other = null;
BEC_4_3_MathInt bevl_i = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpvar_phold);
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 442 */ {
bevt_2_tmpvar_phold = bevp_slots.bem_lengthGet_0();
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 444 */ {
bevt_4_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpvar_phold = bevp_baseNode.bem_create_0();
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_3(104713556, BEL_4_Base.bevn_new_3, bevt_7_tmpvar_phold, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpvar_phold);
} /* Line: 445 */
 else  /* Line: 446 */ {
bevt_10_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 447 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 442 */
 else  /* Line: 442 */ {
break;
} /* Line: 442 */
} /* Line: 442 */
return bevl_other;
} /*method end*/
public BEC_6_6_SystemObject bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_size = (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_12_SetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_11_SetKeyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_11_SetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_12_SetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_11_SetKeyIterator()).bem_new_1(this);
return (BEC_3_11_SetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_11_SetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_11_SetKeyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_12_SetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_12_SetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_12_SetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_12_SetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_12_SetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_3_ContainerSet bem_intersection_1(BEC_9_3_ContainerSet beva_other) throws Throwable {
BEC_9_3_ContainerSet bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_i = (new BEC_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 481 */ {
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 482 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 482 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_3_tmpvar_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 483 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 484 */
} /* Line: 483 */
 else  /* Line: 482 */ {
break;
} /* Line: 482 */
} /* Line: 482 */
} /* Line: 482 */
return bevl_i;
} /*method end*/
public BEC_9_3_ContainerSet bem_union_1(BEC_9_3_ContainerSet beva_other) throws Throwable {
BEC_9_3_ContainerSet bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevl_i = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 493 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 493 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bem_put_1(bevl_x);
} /* Line: 494 */
 else  /* Line: 493 */ {
break;
} /* Line: 493 */
} /* Line: 493 */
if (beva_other == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 496 */ {
bevt_1_tmpvar_loop = beva_other.bem_iteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_4_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 497 */ {
bevl_x = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bem_put_1(bevl_x);
} /* Line: 498 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
} /* Line: 497 */
return bevl_i;
} /*method end*/
public BEC_9_3_ContainerSet bem_add_1(BEC_9_3_ContainerSet beva_other) throws Throwable {
BEC_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_9_3_ContainerSet) this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_9_3_ContainerSet bem_addValue_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 511 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 512 */ {
bevt_0_tmpvar_loop = beva_other.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 513 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 513 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 514 */
 else  /* Line: 513 */ {
break;
} /* Line: 513 */
} /* Line: 513 */
} /* Line: 513 */
 else  /* Line: 512 */ {
bevt_4_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 516 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpvar_phold);
} /* Line: 517 */
 else  /* Line: 518 */ {
this.bem_put_1(beva_other);
} /* Line: 519 */
} /* Line: 512 */
} /* Line: 512 */
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_6_6_SystemObject bem_slotsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_slots = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_6_6_SystemObject bem_moduSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_modu = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_6_6_SystemObject bem_multiSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_multi = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_6_6_SystemObject bem_relSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_rel = (BEC_9_3_9_ContainerSetRelations) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_6_6_SystemObject bem_baseNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_baseNode = (BEC_9_3_7_ContainerSetSetNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_6_6_SystemObject bem_innerPutAddedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_innerPutAdded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {218, 218, 224, 225, 226, 227, 228, 229, 230, 236, 236, 237, 237, 239, 239, 243, 243, 244, 244, 246, 246, 250, 250, 254, 254, 258, 258, 262, 262, 263, 264, 264, 265, 265, 265, 266, 266, 270, 270, 275, 275, 275, 275, 276, 277, 277, 278, 279, 281, 285, 285, 0, 285, 285, 285, 0, 0, 286, 286, 288, 0, 288, 288, 289, 289, 289, 289, 291, 291, 295, 296, 296, 297, 298, 298, 299, 302, 304, 305, 307, 308, 308, 309, 309, 310, 310, 310, 312, 314, 315, 315, 316, 316, 316, 317, 317, 318, 318, 319, 321, 322, 322, 324, 325, 326, 326, 333, 333, 334, 335, 336, 336, 337, 339, 342, 347, 348, 349, 350, 350, 351, 353, 354, 356, 357, 357, 358, 359, 359, 359, 360, 361, 361, 362, 362, 364, 365, 366, 373, 374, 375, 376, 376, 377, 379, 380, 382, 383, 383, 384, 384, 385, 385, 385, 386, 386, 387, 387, 388, 388, 390, 391, 392, 392, 399, 400, 402, 403, 403, 404, 406, 407, 409, 410, 410, 411, 411, 412, 412, 412, 413, 413, 414, 414, 415, 416, 417, 418, 419, 420, 420, 0, 420, 420, 420, 0, 0, 421, 421, 423, 423, 423, 424, 426, 428, 428, 430, 431, 432, 432, 439, 440, 441, 441, 442, 442, 442, 443, 444, 444, 445, 445, 445, 445, 445, 445, 445, 447, 447, 442, 450, 455, 456, 460, 460, 464, 464, 468, 468, 472, 472, 476, 476, 480, 481, 481, 482, 0, 482, 482, 483, 484, 488, 492, 493, 0, 493, 493, 494, 496, 496, 497, 0, 497, 497, 498, 501, 505, 506, 507, 511, 511, 512, 513, 0, 513, 513, 514, 516, 517, 517, 519, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 30, 31, 32, 33, 34, 35, 36, 44, 45, 47, 48, 50, 51, 58, 59, 61, 62, 64, 65, 69, 70, 74, 75, 80, 81, 93, 96, 98, 99, 104, 105, 106, 107, 109, 110, 118, 119, 129, 130, 131, 132, 133, 136, 137, 139, 140, 146, 162, 167, 168, 171, 172, 173, 175, 178, 182, 183, 185, 185, 188, 190, 191, 192, 194, 195, 202, 203, 228, 229, 234, 235, 236, 237, 239, 243, 245, 246, 249, 250, 255, 256, 261, 262, 263, 264, 267, 269, 270, 271, 274, 275, 276, 278, 279, 282, 283, 285, 286, 287, 288, 291, 292, 294, 295, 308, 309, 311, 312, 315, 316, 318, 324, 327, 348, 349, 350, 351, 352, 354, 356, 357, 360, 361, 366, 367, 370, 371, 372, 374, 377, 378, 380, 381, 384, 385, 387, 414, 415, 416, 417, 418, 420, 422, 423, 426, 427, 432, 433, 434, 437, 438, 439, 441, 442, 445, 446, 448, 449, 452, 453, 455, 456, 492, 493, 494, 495, 496, 498, 500, 501, 504, 505, 510, 511, 512, 515, 516, 517, 519, 520, 523, 524, 526, 527, 528, 531, 533, 534, 539, 540, 543, 544, 545, 547, 550, 554, 555, 558, 559, 560, 561, 563, 569, 570, 573, 574, 576, 577, 599, 600, 601, 602, 603, 606, 607, 609, 610, 615, 616, 617, 618, 619, 620, 621, 622, 625, 626, 628, 634, 637, 638, 643, 644, 648, 649, 653, 654, 658, 659, 663, 664, 673, 674, 679, 680, 680, 683, 685, 686, 688, 696, 706, 707, 707, 710, 712, 713, 719, 724, 725, 725, 728, 730, 731, 738, 742, 743, 744, 754, 759, 760, 762, 762, 765, 767, 768, 776, 778, 779, 782, 789, 792, 796, 799, 803, 806, 810, 813, 817, 820, 824, 827, 831, 834};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 218 25
new 0 218 25
new 1 218 26
assign 1 224 30
new 1 224 30
assign 1 225 31
assign 1 226 32
new 0 226 32
assign 1 227 33
new 0 227 33
assign 1 228 34
new 0 228 34
assign 1 229 35
new 0 229 35
assign 1 230 36
new 0 230 36
assign 1 236 44
new 0 236 44
assign 1 236 45
equals 1 236 45
assign 1 237 47
new 0 237 47
return 1 237 48
assign 1 239 50
new 0 239 50
return 1 239 51
assign 1 243 58
new 0 243 58
assign 1 243 59
equals 1 243 59
assign 1 244 61
new 0 244 61
return 1 244 62
assign 1 246 64
new 0 246 64
return 1 246 65
assign 1 250 69
toString 0 250 69
return 1 250 70
assign 1 254 74
new 1 254 74
new 1 254 75
assign 1 258 80
new 1 258 80
return 1 258 81
assign 1 262 93
iteratorGet 0 262 93
assign 1 262 96
hasNextGet 0 262 96
assign 1 263 98
nextGet 0 263 98
assign 1 264 99
def 1 264 104
assign 1 265 105
keyGet 0 265 105
assign 1 265 106
innerPut 4 265 106
assign 1 265 107
not 0 265 107
assign 1 266 109
new 0 266 109
return 1 266 110
assign 1 270 118
new 0 270 118
return 1 270 119
assign 1 275 129
sizeGet 0 275 129
assign 1 275 130
multiply 1 275 130
assign 1 275 131
new 0 275 131
assign 1 275 132
add 1 275 132
assign 1 276 133
new 1 276 133
assign 1 277 136
insertAll 2 277 136
assign 1 277 137
not 0 277 137
assign 1 278 139
increment 0 278 139
assign 1 279 140
new 1 279 140
return 1 281 146
assign 1 285 162
undef 1 285 167
assign 1 0 168
assign 1 285 171
sizeGet 0 285 171
assign 1 285 172
sizeGet 0 285 172
assign 1 285 173
notEquals 1 285 173
assign 1 0 175
assign 1 0 178
assign 1 286 182
new 0 286 182
return 1 286 183
assign 1 288 185
iteratorGet 0 0 185
assign 1 288 188
hasNextGet 0 288 188
assign 1 288 190
nextGet 0 288 190
assign 1 289 191
has 1 289 191
assign 1 289 192
not 0 289 192
assign 1 289 194
new 0 289 194
return 1 289 195
assign 1 291 202
new 0 291 202
return 1 291 203
assign 1 295 228
sizeGet 0 295 228
assign 1 296 229
undef 1 296 234
assign 1 297 235
getHash 1 297 235
assign 1 298 236
new 0 298 236
assign 1 298 237
lesser 1 298 237
assign 1 299 239
abs 0 299 239
assign 1 302 243
hvalGet 0 302 243
assign 1 304 245
modulus 1 304 245
assign 1 305 246
assign 1 307 249
get 1 307 249
assign 1 308 250
undef 1 308 255
assign 1 309 256
undef 1 309 261
assign 1 310 262
create 0 310 262
assign 1 310 263
new 3 310 263
put 2 310 264
put 2 312 267
assign 1 314 269
new 0 314 269
assign 1 315 270
new 0 315 270
return 1 315 271
assign 1 316 274
hvalGet 0 316 274
assign 1 316 275
modulus 1 316 275
assign 1 316 276
notEquals 1 316 276
assign 1 317 278
new 0 317 278
return 1 317 279
assign 1 318 282
keyGet 0 318 282
assign 1 318 283
isEqual 2 318 283
putTo 2 319 285
assign 1 321 286
new 0 321 286
assign 1 322 287
new 0 322 287
return 1 322 288
assign 1 324 291
increment 0 324 291
assign 1 325 292
greaterEquals 1 325 292
assign 1 326 294
new 0 326 294
return 1 326 295
assign 1 333 308
innerPut 4 333 308
assign 1 333 309
not 0 333 309
assign 1 334 311
assign 1 335 312
rehash 1 335 312
assign 1 336 315
innerPut 4 336 315
assign 1 336 316
not 0 336 316
assign 1 337 318
rehash 1 337 318
assign 1 339 324
assign 1 342 327
increment 0 342 327
assign 1 347 348
assign 1 348 349
sizeGet 0 348 349
assign 1 349 350
getHash 1 349 350
assign 1 350 351
new 0 350 351
assign 1 350 352
lesser 1 350 352
assign 1 351 354
abs 0 351 354
assign 1 353 356
modulus 1 353 356
assign 1 354 357
assign 1 356 360
get 1 356 360
assign 1 357 361
undef 1 357 366
return 1 358 367
assign 1 359 370
hvalGet 0 359 370
assign 1 359 371
modulus 1 359 371
assign 1 359 372
notEquals 1 359 372
return 1 360 374
assign 1 361 377
keyGet 0 361 377
assign 1 361 378
isEqual 2 361 378
assign 1 362 380
getFrom 0 362 380
return 1 362 381
assign 1 364 384
increment 0 364 384
assign 1 365 385
greaterEquals 1 365 385
return 1 366 387
assign 1 373 414
assign 1 374 415
sizeGet 0 374 415
assign 1 375 416
getHash 1 375 416
assign 1 376 417
new 0 376 417
assign 1 376 418
lesser 1 376 418
assign 1 377 420
abs 0 377 420
assign 1 379 422
modulus 1 379 422
assign 1 380 423
assign 1 382 426
get 1 382 426
assign 1 383 427
undef 1 383 432
assign 1 384 433
new 0 384 433
return 1 384 434
assign 1 385 437
hvalGet 0 385 437
assign 1 385 438
modulus 1 385 438
assign 1 385 439
notEquals 1 385 439
assign 1 386 441
new 0 386 441
return 1 386 442
assign 1 387 445
keyGet 0 387 445
assign 1 387 446
isEqual 2 387 446
assign 1 388 448
new 0 388 448
return 1 388 449
assign 1 390 452
increment 0 390 452
assign 1 391 453
greaterEquals 1 391 453
assign 1 392 455
new 0 392 455
return 1 392 456
assign 1 399 492
assign 1 400 493
sizeGet 0 400 493
assign 1 402 494
getHash 1 402 494
assign 1 403 495
new 0 403 495
assign 1 403 496
lesser 1 403 496
assign 1 404 498
abs 0 404 498
assign 1 406 500
modulus 1 406 500
assign 1 407 501
assign 1 409 504
get 1 409 504
assign 1 410 505
undef 1 410 510
assign 1 411 511
new 0 411 511
return 1 411 512
assign 1 412 515
hvalGet 0 412 515
assign 1 412 516
modulus 1 412 516
assign 1 412 517
notEquals 1 412 517
assign 1 413 519
new 0 413 519
return 1 413 520
assign 1 414 523
keyGet 0 414 523
assign 1 414 524
isEqual 2 414 524
put 2 415 526
assign 1 416 527
decrement 0 416 527
assign 1 417 528
increment 0 417 528
assign 1 418 531
lesser 1 418 531
assign 1 419 533
get 1 419 533
assign 1 420 534
undef 1 420 539
assign 1 0 540
assign 1 420 543
hvalGet 0 420 543
assign 1 420 544
modulus 1 420 544
assign 1 420 545
notEquals 1 420 545
assign 1 0 547
assign 1 0 550
assign 1 421 554
new 0 421 554
return 1 421 555
assign 1 423 558
new 0 423 558
assign 1 423 559
subtract 1 423 559
put 2 423 560
put 2 424 561
assign 1 426 563
increment 0 426 563
assign 1 428 569
new 0 428 569
return 1 428 570
assign 1 430 573
increment 0 430 573
assign 1 431 574
greaterEquals 1 431 574
assign 1 432 576
new 0 432 576
return 1 432 577
assign 1 439 599
create 0 439 599
copyTo 1 440 600
assign 1 441 601
copy 0 441 601
slotsSet 1 441 602
assign 1 442 603
new 0 442 603
assign 1 442 606
lengthGet 0 442 606
assign 1 442 607
lesser 1 442 607
assign 1 443 609
get 1 443 609
assign 1 444 610
def 1 444 615
assign 1 445 616
slotsGet 0 445 616
assign 1 445 617
create 0 445 617
assign 1 445 618
hvalGet 0 445 618
assign 1 445 619
keyGet 0 445 619
assign 1 445 620
getFrom 0 445 620
assign 1 445 621
new 3 445 621
put 2 445 622
assign 1 447 625
slotsGet 0 447 625
put 2 447 626
assign 1 442 628
increment 0 442 628
return 1 450 634
clear 0 455 637
assign 1 456 638
new 0 456 638
assign 1 460 643
new 1 460 643
return 1 460 644
assign 1 464 648
new 1 464 648
return 1 464 649
assign 1 468 653
keyIteratorGet 0 468 653
return 1 468 654
assign 1 472 658
new 1 472 658
return 1 472 659
assign 1 476 663
nodeIteratorGet 0 476 663
return 1 476 664
assign 1 480 673
new 0 480 673
assign 1 481 674
def 1 481 679
assign 1 482 680
iteratorGet 0 0 680
assign 1 482 683
hasNextGet 0 482 683
assign 1 482 685
nextGet 0 482 685
assign 1 483 686
has 1 483 686
put 1 484 688
return 1 488 696
assign 1 492 706
new 0 492 706
assign 1 493 707
iteratorGet 0 0 707
assign 1 493 710
hasNextGet 0 493 710
assign 1 493 712
nextGet 0 493 712
put 1 494 713
assign 1 496 719
def 1 496 724
assign 1 497 725
iteratorGet 0 0 725
assign 1 497 728
hasNextGet 0 497 728
assign 1 497 730
nextGet 0 497 730
put 1 498 731
return 1 501 738
assign 1 505 742
copy 0 505 742
addValue 1 506 743
return 1 507 744
assign 1 511 754
def 1 511 759
assign 1 512 760
sameType 1 512 760
assign 1 513 762
iteratorGet 0 0 762
assign 1 513 765
hasNextGet 0 513 765
assign 1 513 767
nextGet 0 513 767
put 1 514 768
assign 1 516 776
sameType 1 516 776
assign 1 517 778
keyGet 0 517 778
put 1 517 779
put 1 519 782
return 1 0 789
assign 1 0 792
return 1 0 796
assign 1 0 799
return 1 0 803
assign 1 0 806
return 1 0 810
assign 1 0 813
return 1 0 817
assign 1 0 820
return 1 0 824
assign 1 0 827
return 1 0 831
assign 1 0 834
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 712928736: return bem_innerPutAddedGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1586230380: return bem_moduGet_0();
case 1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 2142483603: return bem_notEmptyGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case 578884498: return bem_relGet_0();
case 786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 567802245: return bem_relSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_9_3_ContainerSet) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 79841285: return bem_intersection_1((BEC_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 286659903: return bem_union_1((BEC_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_9_3_ContainerSet) bevd_0);
case 668984013: return bem_rehash_1((BEC_9_5_ContainerArray) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 131089957: return bem_insertAll_2((BEC_9_5_ContainerArray) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_9_5_ContainerArray) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_3_ContainerSet.bevs_inst = (BEC_9_3_ContainerSet)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_3_ContainerSet.bevs_inst;
}
}
