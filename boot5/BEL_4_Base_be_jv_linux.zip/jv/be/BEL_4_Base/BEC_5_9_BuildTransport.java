package be.BEL_4_Base;
/* IO:File: source/build/Transport.be */
public class BEC_5_9_BuildTransport extends BEC_6_6_SystemObject {
public BEC_5_9_BuildTransport() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65,0x3A};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 38));
private static byte[] bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 10));
private static byte[] bels_3 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_4, 10));
private static byte[] bels_5 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_6 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_7 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_8 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static BEC_5_9_BuildTransport bevs_inst;
public BEC_5_5_BuildBuild bevp_build;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_5_4_BuildNode bevp_outermost;
public BEC_5_4_BuildNode bevp_current;
public BEC_5_9_BuildTransport bem_new_1(BEC_5_5_BuildBuild beva__build) throws Throwable {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(9, bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_9_BuildTransport bem_new_2(BEC_5_5_BuildBuild beva__build, BEC_5_4_BuildNode beva__outermost) throws Throwable {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_traverse_1(BEC_5_5_7_BuildVisitVisitor beva_visitor) throws Throwable {
BEC_5_4_BuildNode bevl_node = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
try  /* Line: 40 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 45 */ {
if (bevl_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 46 */
 else  /* Line: 45 */ {
break;
} /* Line: 45 */
} /* Line: 45 */
beva_visitor.bem_end_1(this);
} /* Line: 49 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold.bem_print_0();
bevl_node.bem_print_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 55 */
 else  /* Line: 56 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold.bem_print_0();
bevt_5_tmpvar_phold = bevo_3;
bevt_5_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 59 */
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 61 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_contain_0() throws Throwable {
BEC_9_3_ContainerMap bevl_conTypes = null;
BEC_5_4_BuildNode bevl_curr = null;
BEC_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_5_4_BuildNode bevl_node = null;
BEC_5_4_BuildNode bevl_wf = null;
BEC_5_4_BuildNode bevl_cnode = null;
BEC_5_4_BuildNode bevl_mnode = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_9_BuildConstants bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
bevt_7_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpvar_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 70 */ {
bevt_8_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 70 */ {
bevl_node = (BEC_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpvar_phold = bevl_node.bem_delayDeleteGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_not_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 74 */ {
bevt_12_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_13_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_15_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 75 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 75 */
 else  /* Line: 75 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 75 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 79 */ {
if (bevl_wf == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_19_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_equals_1(bevt_20_tmpvar_phold);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_22_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_equals_1(bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 79 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 80 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_25_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_equals_1(bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 80 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 79 */
 else  /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 80 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 81 */
 else  /* Line: 79 */ {
break;
} /* Line: 79 */
} /* Line: 79 */
if (bevl_wf == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevt_29_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_equals_1(bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_32_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_equals_1(bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 83 */ {
bevl_cnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (new BEC_4_6_TextString(5, bels_5));
bevl_cnode.bem_heldSet_1(bevt_35_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 90 */
} /* Line: 83 */
bevt_37_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_equals_1(bevt_38_tmpvar_phold);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevt_41_tmpvar_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_equals_1(bevt_42_tmpvar_phold);
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 93 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 93 */
 else  /* Line: 93 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 93 */ {
bevt_44_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 93 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 93 */
 else  /* Line: 93 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 93 */ {
bevl_mnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = (new BEC_4_6_TextString(6, bels_6));
bevl_mnode.bem_heldSet_1(bevt_47_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 99 */
bevt_49_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bem_equals_1(bevt_50_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_52_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_equals_1(bevt_53_tmpvar_phold);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 102 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 102 */
 else  /* Line: 102 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 102 */ {
bevl_mnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(6, bels_7));
bevl_mnode.bem_heldSet_1(bevt_55_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 108 */
bevt_57_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_equals_1(bevt_58_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 112 */
 else  /* Line: 111 */ {
bevt_60_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpvar_phold = bevp_ntypes.bem_RIDXGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bem_equals_1(bevt_61_tmpvar_phold);
if (bevt_59_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 114 */
 else  /* Line: 111 */ {
bevt_63_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_equals_1(bevt_64_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_67_tmpvar_phold = (new BEC_4_6_TextString(32, bels_8));
bevt_66_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_66_tmpvar_phold);
} /* Line: 118 */
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_70_tmpvar_phold = (new BEC_4_6_TextString(32, bels_9));
bevt_69_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_69_tmpvar_phold);
} /* Line: 122 */
} /* Line: 121 */
 else  /* Line: 124 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 125 */
} /* Line: 111 */
} /* Line: 111 */
bevt_72_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevl_conTypes.bem_has_1(bevt_72_tmpvar_phold);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevl_curr = bevl_node;
} /* Line: 128 */
} /* Line: 127 */
} /* Line: 74 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_stepBack_1(BEC_5_4_BuildNode beva_curr) throws Throwable {
BEC_5_4_BuildNode bevl_hop = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(32, bels_10));
bevt_1_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpvar_phold, beva_curr);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 137 */
return bevl_hop;
} /*method end*/
public BEC_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_outermostGet_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public BEC_6_6_SystemObject bem_outermostSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outermost = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_6_6_SystemObject bem_currentSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_current = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {22, 23, 23, 24, 25, 27, 27, 28, 28, 32, 33, 33, 34, 35, 41, 43, 45, 45, 46, 49, 51, 51, 52, 52, 53, 54, 54, 55, 57, 57, 58, 58, 59, 61, 66, 66, 67, 68, 69, 70, 70, 73, 74, 74, 75, 75, 75, 75, 75, 75, 0, 0, 0, 78, 79, 79, 79, 79, 79, 0, 79, 79, 79, 0, 0, 0, 80, 80, 80, 0, 0, 0, 0, 0, 81, 83, 83, 83, 83, 83, 0, 83, 83, 83, 0, 0, 0, 0, 0, 86, 87, 87, 88, 88, 89, 90, 93, 93, 93, 93, 93, 93, 93, 0, 0, 0, 93, 93, 93, 0, 0, 0, 95, 96, 96, 97, 97, 98, 99, 102, 102, 102, 102, 102, 102, 0, 0, 0, 104, 105, 105, 106, 106, 107, 108, 111, 111, 111, 112, 113, 113, 113, 114, 115, 115, 115, 116, 117, 117, 118, 118, 118, 120, 121, 121, 122, 122, 122, 125, 127, 127, 128, 135, 136, 136, 137, 137, 137, 139, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 33, 34, 35, 36, 37, 38, 39, 44, 45, 46, 47, 48, 61, 62, 65, 70, 71, 77, 81, 86, 87, 88, 89, 90, 91, 92, 95, 96, 97, 98, 99, 101, 187, 188, 189, 190, 191, 192, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207, 209, 212, 216, 219, 222, 227, 228, 229, 230, 232, 235, 236, 237, 239, 242, 246, 249, 250, 251, 253, 256, 260, 263, 267, 270, 276, 281, 282, 283, 284, 286, 289, 290, 291, 293, 296, 300, 303, 307, 310, 311, 312, 313, 314, 315, 316, 319, 320, 321, 323, 324, 325, 326, 328, 331, 335, 338, 339, 340, 342, 345, 349, 352, 353, 354, 355, 356, 357, 358, 360, 361, 362, 364, 365, 366, 368, 371, 375, 378, 379, 380, 381, 382, 383, 384, 386, 387, 388, 390, 393, 394, 395, 397, 400, 401, 402, 404, 405, 410, 411, 412, 413, 415, 416, 421, 422, 423, 424, 428, 432, 433, 435, 450, 451, 456, 457, 458, 459, 461, 464, 467, 471, 474, 478, 481, 485, 488};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 22 31
assign 1 23 32
constantsGet 0 23 32
assign 1 23 33
ntypesGet 0 23 33
assign 1 24 34
new 1 24 34
assign 1 25 35
assign 1 27 36
TRANSUNITGet 0 27 36
typenameSet 1 27 37
assign 1 28 38
new 0 28 38
heldSet 1 28 39
assign 1 32 44
assign 1 33 45
constantsGet 0 33 45
assign 1 33 46
ntypesGet 0 33 46
assign 1 34 47
assign 1 35 48
begin 1 41 61
assign 1 43 62
accept 1 43 62
assign 1 45 65
def 1 45 70
assign 1 46 71
accept 1 46 71
end 1 49 77
assign 1 51 81
def 1 51 86
assign 1 52 87
new 0 52 87
print 0 52 88
print 0 53 89
assign 1 54 90
new 0 54 90
print 0 54 91
print 0 55 92
assign 1 57 95
new 0 57 95
print 0 57 96
assign 1 58 97
new 0 58 97
print 0 58 98
print 0 59 99
throw 1 61 101
assign 1 66 187
constantsGet 0 66 187
assign 1 66 188
conTypesGet 0 66 188
assign 1 67 189
assign 1 68 190
containedGet 0 68 190
containedSet 1 69 191
assign 1 70 192
linkedListIteratorGet 0 70 192
assign 1 70 195
hasNextGet 0 70 195
assign 1 73 197
nextGet 0 73 197
assign 1 74 198
delayDeleteGet 0 74 198
assign 1 74 199
not 0 74 199
assign 1 75 201
typenameGet 0 75 201
assign 1 75 202
TRANSUNITGet 0 75 202
assign 1 75 203
equals 1 75 203
assign 1 75 205
typenameGet 0 75 205
assign 1 75 206
IDGet 0 75 206
assign 1 75 207
equals 1 75 207
assign 1 0 209
assign 1 0 212
assign 1 0 216
assign 1 78 219
assign 1 79 222
def 1 79 227
assign 1 79 228
typenameGet 0 79 228
assign 1 79 229
IDGet 0 79 229
assign 1 79 230
equals 1 79 230
assign 1 0 232
assign 1 79 235
typenameGet 0 79 235
assign 1 79 236
COLONGet 0 79 236
assign 1 79 237
equals 1 79 237
assign 1 0 239
assign 1 0 242
assign 1 0 246
assign 1 80 249
typenameGet 0 80 249
assign 1 80 250
SPACEGet 0 80 250
assign 1 80 251
equals 1 80 251
assign 1 0 253
assign 1 0 256
assign 1 0 260
assign 1 0 263
assign 1 0 267
assign 1 81 270
nextPeerGet 0 81 270
assign 1 83 276
def 1 83 281
assign 1 83 282
typenameGet 0 83 282
assign 1 83 283
PARENSGet 0 83 283
assign 1 83 284
equals 1 83 284
assign 1 0 286
assign 1 83 289
typenameGet 0 83 289
assign 1 83 290
BRACESGet 0 83 290
assign 1 83 291
equals 1 83 291
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 86 310
new 1 86 310
assign 1 87 311
CLASSGet 0 87 311
typenameSet 1 87 312
assign 1 88 313
new 0 88 313
heldSet 1 88 314
addValue 1 89 315
assign 1 90 316
assign 1 93 319
typenameGet 0 93 319
assign 1 93 320
BRACESGet 0 93 320
assign 1 93 321
equals 1 93 321
assign 1 93 323
containerGet 0 93 323
assign 1 93 324
typenameGet 0 93 324
assign 1 93 325
CLASSGet 0 93 325
assign 1 93 326
equals 1 93 326
assign 1 0 328
assign 1 0 331
assign 1 0 335
assign 1 93 338
typenameGet 0 93 338
assign 1 93 339
IDGet 0 93 339
assign 1 93 340
equals 1 93 340
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 95 352
new 1 95 352
assign 1 96 353
METHODGet 0 96 353
typenameSet 1 96 354
assign 1 97 355
new 0 97 355
heldSet 1 97 356
addValue 1 98 357
assign 1 99 358
assign 1 102 360
typenameGet 0 102 360
assign 1 102 361
BRACESGet 0 102 361
assign 1 102 362
equals 1 102 362
assign 1 102 364
typenameGet 0 102 364
assign 1 102 365
BRACESGet 0 102 365
assign 1 102 366
equals 1 102 366
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 104 378
new 1 104 378
assign 1 105 379
PROPERTIESGet 0 105 379
typenameSet 1 105 380
assign 1 106 381
new 0 106 381
heldSet 1 106 382
addValue 1 107 383
assign 1 108 384
assign 1 111 386
typenameGet 0 111 386
assign 1 111 387
RPARENSGet 0 111 387
assign 1 111 388
equals 1 111 388
assign 1 112 390
stepBack 1 112 390
assign 1 113 393
typenameGet 0 113 393
assign 1 113 394
RIDXGet 0 113 394
assign 1 113 395
equals 1 113 395
assign 1 114 397
stepBack 1 114 397
assign 1 115 400
typenameGet 0 115 400
assign 1 115 401
RBRACESGet 0 115 401
assign 1 115 402
equals 1 115 402
assign 1 116 404
stepBack 1 116 404
assign 1 117 405
undef 1 117 410
assign 1 118 411
new 0 118 411
assign 1 118 412
new 2 118 412
throw 1 118 413
assign 1 120 415
stepBack 1 120 415
assign 1 121 416
undef 1 121 421
assign 1 122 422
new 0 122 422
assign 1 122 423
new 2 122 423
throw 1 122 424
addValue 1 125 428
assign 1 127 432
typenameGet 0 127 432
assign 1 127 433
has 1 127 433
assign 1 128 435
assign 1 135 450
containerGet 0 135 450
assign 1 136 451
undef 1 136 456
assign 1 137 457
new 0 137 457
assign 1 137 458
new 2 137 458
throw 1 137 459
return 1 139 461
return 1 0 464
assign 1 0 467
return 1 0 471
assign 1 0 474
return 1 0 478
assign 1 0 481
return 1 0 485
assign 1 0 488
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 410956923: return bem_contain_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case 1081412016: return bem_many_0();
case 1380522583: return bem_outermostGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 2101994299: return bem_stepBack_1((BEC_5_4_BuildNode) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1369440330: return bem_outermostSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 688372900: return bem_traverse_1((BEC_5_5_7_BuildVisitVisitor) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_5_5_BuildBuild) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_9_BuildTransport();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_9_BuildTransport.bevs_inst = (BEC_5_9_BuildTransport)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_9_BuildTransport.bevs_inst;
}
}
