package be.BEL_4_Base;
/* IO:File: source/build/Transport.be */
public class BEC_5_9_BuildTransport extends BEC_6_6_SystemObject {
public BEC_5_9_BuildTransport() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65,0x3A};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 38));
private static byte[] bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 10));
private static byte[] bels_3 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_4, 10));
private static byte[] bels_5 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_6 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_7 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_8 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static BEC_5_9_BuildTransport bevs_inst;
public BEC_5_5_BuildBuild bevp_build;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_5_4_BuildNode bevp_outermost;
public BEC_5_4_BuildNode bevp_current;
public BEC_5_9_BuildTransport bem_new_1(BEC_5_5_BuildBuild beva__build) throws Throwable {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(9, bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_9_BuildTransport bem_new_2(BEC_5_5_BuildBuild beva__build, BEC_5_4_BuildNode beva__outermost) throws Throwable {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_traverse_1(BEC_5_5_7_BuildVisitVisitor beva_visitor) throws Throwable {
BEC_5_4_BuildNode bevl_node = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
try  /* Line: 39 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 44 */ {
if (bevl_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 45 */
 else  /* Line: 44 */ {
break;
} /* Line: 44 */
} /* Line: 44 */
beva_visitor.bem_end_1(this);
} /* Line: 48 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold.bem_print_0();
bevl_node.bem_print_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 54 */
 else  /* Line: 55 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold.bem_print_0();
bevt_5_tmpvar_phold = bevo_3;
bevt_5_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 58 */
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 60 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_contain_0() throws Throwable {
BEC_9_3_ContainerMap bevl_conTypes = null;
BEC_5_4_BuildNode bevl_curr = null;
BEC_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_5_4_BuildNode bevl_node = null;
BEC_5_4_BuildNode bevl_wf = null;
BEC_5_4_BuildNode bevl_cnode = null;
BEC_5_4_BuildNode bevl_mnode = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_9_BuildConstants bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
bevt_7_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpvar_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_iteratorGet_0();
while (true)
 /* Line: 69 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 69 */ {
bevl_node = (BEC_5_4_BuildNode) bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_node.bem_delayDeleteGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_not_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_12_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_13_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 74 */ {
bevt_15_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 74 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 78 */ {
if (bevl_wf == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevt_19_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_equals_1(bevt_20_tmpvar_phold);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_22_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_equals_1(bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_25_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_equals_1(bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 79 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
 else  /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 79 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 80 */
 else  /* Line: 78 */ {
break;
} /* Line: 78 */
} /* Line: 78 */
if (bevl_wf == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_29_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_equals_1(bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_32_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_equals_1(bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevl_cnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (new BEC_4_6_TextString(5, bels_5));
bevl_cnode.bem_heldSet_1(bevt_35_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 89 */
} /* Line: 82 */
bevt_37_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_equals_1(bevt_38_tmpvar_phold);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 92 */ {
bevt_41_tmpvar_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_equals_1(bevt_42_tmpvar_phold);
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 92 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 92 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 92 */
 else  /* Line: 92 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 92 */ {
bevt_44_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 92 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 92 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 92 */
 else  /* Line: 92 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 92 */ {
bevl_mnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = (new BEC_4_6_TextString(6, bels_6));
bevl_mnode.bem_heldSet_1(bevt_47_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 98 */
bevt_49_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bem_equals_1(bevt_50_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevt_52_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_equals_1(bevt_53_tmpvar_phold);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 101 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 101 */
 else  /* Line: 101 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 101 */ {
bevl_mnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(6, bels_7));
bevl_mnode.bem_heldSet_1(bevt_55_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 107 */
bevt_57_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_equals_1(bevt_58_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 110 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 111 */
 else  /* Line: 110 */ {
bevt_60_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpvar_phold = bevp_ntypes.bem_RIDXGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bem_equals_1(bevt_61_tmpvar_phold);
if (bevt_59_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 113 */
 else  /* Line: 110 */ {
bevt_63_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_equals_1(bevt_64_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 114 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_67_tmpvar_phold = (new BEC_4_6_TextString(32, bels_8));
bevt_66_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_66_tmpvar_phold);
} /* Line: 117 */
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_70_tmpvar_phold = (new BEC_4_6_TextString(32, bels_9));
bevt_69_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_69_tmpvar_phold);
} /* Line: 121 */
} /* Line: 120 */
 else  /* Line: 123 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 124 */
} /* Line: 110 */
} /* Line: 110 */
bevt_72_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevl_conTypes.bem_has_1(bevt_72_tmpvar_phold);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevl_curr = bevl_node;
} /* Line: 127 */
} /* Line: 126 */
} /* Line: 73 */
 else  /* Line: 69 */ {
break;
} /* Line: 69 */
} /* Line: 69 */
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_stepBack_1(BEC_5_4_BuildNode beva_curr) throws Throwable {
BEC_5_4_BuildNode bevl_hop = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(32, bels_10));
bevt_1_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpvar_phold, beva_curr);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 136 */
return bevl_hop;
} /*method end*/
public BEC_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_outermostGet_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public BEC_6_6_SystemObject bem_outermostSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outermost = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_6_6_SystemObject bem_currentSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_current = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 22, 22, 23, 24, 26, 26, 27, 27, 31, 32, 32, 33, 34, 40, 42, 44, 44, 45, 48, 50, 50, 51, 51, 52, 53, 53, 54, 56, 56, 57, 57, 58, 60, 65, 65, 66, 67, 68, 69, 69, 72, 73, 73, 74, 74, 74, 74, 74, 74, 0, 0, 0, 77, 78, 78, 78, 78, 78, 0, 78, 78, 78, 0, 0, 0, 79, 79, 79, 0, 0, 0, 0, 0, 80, 82, 82, 82, 82, 82, 0, 82, 82, 82, 0, 0, 0, 0, 0, 85, 86, 86, 87, 87, 88, 89, 92, 92, 92, 92, 92, 92, 92, 0, 0, 0, 92, 92, 92, 0, 0, 0, 94, 95, 95, 96, 96, 97, 98, 101, 101, 101, 101, 101, 101, 0, 0, 0, 103, 104, 104, 105, 105, 106, 107, 110, 110, 110, 111, 112, 112, 112, 113, 114, 114, 114, 115, 116, 116, 117, 117, 117, 119, 120, 120, 121, 121, 121, 124, 126, 126, 127, 134, 135, 135, 136, 136, 136, 138, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 33, 34, 35, 36, 37, 38, 39, 44, 45, 46, 47, 48, 61, 62, 65, 70, 71, 77, 81, 86, 87, 88, 89, 90, 91, 92, 95, 96, 97, 98, 99, 101, 187, 188, 189, 190, 191, 192, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207, 209, 212, 216, 219, 222, 227, 228, 229, 230, 232, 235, 236, 237, 239, 242, 246, 249, 250, 251, 253, 256, 260, 263, 267, 270, 276, 281, 282, 283, 284, 286, 289, 290, 291, 293, 296, 300, 303, 307, 310, 311, 312, 313, 314, 315, 316, 319, 320, 321, 323, 324, 325, 326, 328, 331, 335, 338, 339, 340, 342, 345, 349, 352, 353, 354, 355, 356, 357, 358, 360, 361, 362, 364, 365, 366, 368, 371, 375, 378, 379, 380, 381, 382, 383, 384, 386, 387, 388, 390, 393, 394, 395, 397, 400, 401, 402, 404, 405, 410, 411, 412, 413, 415, 416, 421, 422, 423, 424, 428, 432, 433, 435, 450, 451, 456, 457, 458, 459, 461, 464, 467, 471, 474, 478, 481, 485, 488};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 21 31
assign 1 22 32
constantsGet 0 22 32
assign 1 22 33
ntypesGet 0 22 33
assign 1 23 34
new 1 23 34
assign 1 24 35
assign 1 26 36
TRANSUNITGet 0 26 36
typenameSet 1 26 37
assign 1 27 38
new 0 27 38
heldSet 1 27 39
assign 1 31 44
assign 1 32 45
constantsGet 0 32 45
assign 1 32 46
ntypesGet 0 32 46
assign 1 33 47
assign 1 34 48
begin 1 40 61
assign 1 42 62
accept 1 42 62
assign 1 44 65
def 1 44 70
assign 1 45 71
accept 1 45 71
end 1 48 77
assign 1 50 81
def 1 50 86
assign 1 51 87
new 0 51 87
print 0 51 88
print 0 52 89
assign 1 53 90
new 0 53 90
print 0 53 91
print 0 54 92
assign 1 56 95
new 0 56 95
print 0 56 96
assign 1 57 97
new 0 57 97
print 0 57 98
print 0 58 99
throw 1 60 101
assign 1 65 187
constantsGet 0 65 187
assign 1 65 188
conTypesGet 0 65 188
assign 1 66 189
assign 1 67 190
containedGet 0 67 190
containedSet 1 68 191
assign 1 69 192
iteratorGet 0 69 192
assign 1 69 195
hasNextGet 0 69 195
assign 1 72 197
nextGet 0 72 197
assign 1 73 198
delayDeleteGet 0 73 198
assign 1 73 199
not 0 73 199
assign 1 74 201
typenameGet 0 74 201
assign 1 74 202
TRANSUNITGet 0 74 202
assign 1 74 203
equals 1 74 203
assign 1 74 205
typenameGet 0 74 205
assign 1 74 206
IDGet 0 74 206
assign 1 74 207
equals 1 74 207
assign 1 0 209
assign 1 0 212
assign 1 0 216
assign 1 77 219
assign 1 78 222
def 1 78 227
assign 1 78 228
typenameGet 0 78 228
assign 1 78 229
IDGet 0 78 229
assign 1 78 230
equals 1 78 230
assign 1 0 232
assign 1 78 235
typenameGet 0 78 235
assign 1 78 236
COLONGet 0 78 236
assign 1 78 237
equals 1 78 237
assign 1 0 239
assign 1 0 242
assign 1 0 246
assign 1 79 249
typenameGet 0 79 249
assign 1 79 250
SPACEGet 0 79 250
assign 1 79 251
equals 1 79 251
assign 1 0 253
assign 1 0 256
assign 1 0 260
assign 1 0 263
assign 1 0 267
assign 1 80 270
nextPeerGet 0 80 270
assign 1 82 276
def 1 82 281
assign 1 82 282
typenameGet 0 82 282
assign 1 82 283
PARENSGet 0 82 283
assign 1 82 284
equals 1 82 284
assign 1 0 286
assign 1 82 289
typenameGet 0 82 289
assign 1 82 290
BRACESGet 0 82 290
assign 1 82 291
equals 1 82 291
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 85 310
new 1 85 310
assign 1 86 311
CLASSGet 0 86 311
typenameSet 1 86 312
assign 1 87 313
new 0 87 313
heldSet 1 87 314
addValue 1 88 315
assign 1 89 316
assign 1 92 319
typenameGet 0 92 319
assign 1 92 320
BRACESGet 0 92 320
assign 1 92 321
equals 1 92 321
assign 1 92 323
containerGet 0 92 323
assign 1 92 324
typenameGet 0 92 324
assign 1 92 325
CLASSGet 0 92 325
assign 1 92 326
equals 1 92 326
assign 1 0 328
assign 1 0 331
assign 1 0 335
assign 1 92 338
typenameGet 0 92 338
assign 1 92 339
IDGet 0 92 339
assign 1 92 340
equals 1 92 340
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 94 352
new 1 94 352
assign 1 95 353
METHODGet 0 95 353
typenameSet 1 95 354
assign 1 96 355
new 0 96 355
heldSet 1 96 356
addValue 1 97 357
assign 1 98 358
assign 1 101 360
typenameGet 0 101 360
assign 1 101 361
BRACESGet 0 101 361
assign 1 101 362
equals 1 101 362
assign 1 101 364
typenameGet 0 101 364
assign 1 101 365
BRACESGet 0 101 365
assign 1 101 366
equals 1 101 366
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 103 378
new 1 103 378
assign 1 104 379
PROPERTIESGet 0 104 379
typenameSet 1 104 380
assign 1 105 381
new 0 105 381
heldSet 1 105 382
addValue 1 106 383
assign 1 107 384
assign 1 110 386
typenameGet 0 110 386
assign 1 110 387
RPARENSGet 0 110 387
assign 1 110 388
equals 1 110 388
assign 1 111 390
stepBack 1 111 390
assign 1 112 393
typenameGet 0 112 393
assign 1 112 394
RIDXGet 0 112 394
assign 1 112 395
equals 1 112 395
assign 1 113 397
stepBack 1 113 397
assign 1 114 400
typenameGet 0 114 400
assign 1 114 401
RBRACESGet 0 114 401
assign 1 114 402
equals 1 114 402
assign 1 115 404
stepBack 1 115 404
assign 1 116 405
undef 1 116 410
assign 1 117 411
new 0 117 411
assign 1 117 412
new 2 117 412
throw 1 117 413
assign 1 119 415
stepBack 1 119 415
assign 1 120 416
undef 1 120 421
assign 1 121 422
new 0 121 422
assign 1 121 423
new 2 121 423
throw 1 121 424
addValue 1 124 428
assign 1 126 432
typenameGet 0 126 432
assign 1 126 433
has 1 126 433
assign 1 127 435
assign 1 134 450
containerGet 0 134 450
assign 1 135 451
undef 1 135 456
assign 1 136 457
new 0 136 457
assign 1 136 458
new 2 136 458
throw 1 136 459
return 1 138 461
return 1 0 464
assign 1 0 467
return 1 0 471
assign 1 0 474
return 1 0 478
assign 1 0 481
return 1 0 485
assign 1 0 488
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 410956923: return bem_contain_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case 1081412016: return bem_many_0();
case 1380522583: return bem_outermostGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 2101994299: return bem_stepBack_1((BEC_5_4_BuildNode) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1369440330: return bem_outermostSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 688372900: return bem_traverse_1((BEC_5_5_7_BuildVisitVisitor) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_5_5_BuildBuild) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_9_BuildTransport();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_9_BuildTransport.bevs_inst = (BEC_5_9_BuildTransport)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_9_BuildTransport.bevs_inst;
}
}
