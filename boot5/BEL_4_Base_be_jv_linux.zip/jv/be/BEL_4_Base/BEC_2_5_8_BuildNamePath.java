package be.BEL_4_Base;
/* IO:File: source/build/BuildTypes.be */
public class BEC_2_5_8_BuildNamePath extends BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 4));
private static byte[] bels_1 = {0x3A};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_1, 1));
public static BEC_2_5_8_BuildNamePath bevs_inst;
public BEC_2_4_6_TextString bevp_label;
public BEC_2_5_8_BuildNamePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_separator = bevt_0_tmpvar_phold.bem_colonGet_0();
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpvar_phold = null;
if (bevp_label == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 31 */ {
bevt_2_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lastGet_0();
return bevt_1_tmpvar_phold;
} /* Line: 32 */
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
bevl_oldpath = this.bem_pathGet_0();
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevl_oldpath.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 40 */ {
return this;
} /* Line: 40 */
bevl_fstep = this.bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevt_4_tmpvar_phold = bevl_tunode.bem_heldGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_3_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_fstep);
if (bevl_par == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevt_8_tmpvar_phold = this.bem_pathGet_0();
bevt_9_tmpvar_phold = bevo_1;
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_has_1(bevt_9_tmpvar_phold);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_not_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 44 */
 else  /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 44 */ {
bevl_np2 = this.bem_deleteFirstStep_0();
bevl_np = bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 47 */
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(312889617, BEL_4_Base.bevn_classGet_0);
if (bevl_clnode == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_11_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_11_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, this);
} /* Line: 51 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 26, 27, 31, 31, 32, 32, 32, 35, 39, 40, 40, 40, 41, 42, 43, 43, 43, 44, 44, 44, 44, 44, 44, 0, 0, 0, 45, 46, 47, 49, 50, 50, 51, 51, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 24, 29, 30, 31, 32, 34, 56, 57, 58, 60, 62, 63, 64, 65, 66, 67, 72, 73, 74, 75, 76, 78, 81, 85, 88, 89, 90, 92, 93, 98, 99, 100, 105};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 26 15
new 0 26 15
assign 1 26 16
colonGet 0 26 16
fromString 1 27 17
assign 1 31 24
undef 1 31 29
assign 1 32 30
split 1 32 30
assign 1 32 31
lastGet 0 32 31
return 1 32 32
return 1 35 34
assign 1 39 56
pathGet 0 39 56
assign 1 40 57
new 0 40 57
assign 1 40 58
equals 1 40 58
return 1 40 60
assign 1 41 62
firstStepGet 0 41 62
assign 1 42 63
transUnitGet 0 42 63
assign 1 43 64
heldGet 0 43 64
assign 1 43 65
aliasedGet 0 43 65
assign 1 43 66
get 1 43 66
assign 1 44 67
def 1 44 72
assign 1 44 73
pathGet 0 44 73
assign 1 44 74
new 0 44 74
assign 1 44 75
has 1 44 75
assign 1 44 76
not 0 44 76
assign 1 0 78
assign 1 0 81
assign 1 0 85
assign 1 45 88
deleteFirstStep 0 45 88
assign 1 46 89
add 1 46 89
assign 1 47 90
pathGet 0 47 90
assign 1 49 92
classGet 0 49 92
assign 1 50 93
def 1 50 98
assign 1 51 99
heldGet 0 51 99
addUsed 1 51 100
assign 1 0 105
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case 1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 471950299: return bem_lastStepGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 935459934: return bem_deleteFirstStep_0();
case 1672091917: return bem_labelGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1719674549: return bem_firstStepGet_0();
case 723109216: return bem_stepsGet_0();
case 1354714650: return bem_copy_0();
case 400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case 1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1661009664: return bem_labelSet_1(bevd_0);
case 630006451: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1991261538: return bem_resolve_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 488966921: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 389107089: return bem_pathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1787791811: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case 2006569863: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 488966920: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildNamePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildNamePath.bevs_inst = (BEC_2_5_8_BuildNamePath)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildNamePath.bevs_inst;
}
}
