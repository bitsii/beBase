package be.BEL_4_Base;
/* IO:File: source/build/Pass5.be */
public class BEC_3_5_5_5_BuildVisitPass5 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass5() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x35};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x35,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x6F,0x66,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_2 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x61,0x6C,0x69,0x61,0x73,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x20,0x2D,0x61,0x73,0x2D,0x2E};
private static byte[] bels_3 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x6F,0x74,0x20,0x77,0x69,0x74,0x68,0x69,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x75,0x6E,0x69,0x74};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_4 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_5 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_6 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_7 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_9 = {0x4F,0x6E,0x6C,0x79,0x20,0x73,0x69,0x6E,0x67,0x6C,0x65,0x20,0x69,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x61,0x6C,0x6C,0x6F,0x77,0x65,0x64};
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x62,0x72,0x61,0x63,0x65,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_13 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_14 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_15 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_16 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_17 = {0x4C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bels_18 = {0x46,0x69,0x72,0x73,0x74,0x20,0x63,0x68,0x61,0x72,0x61,0x63,0x74,0x65,0x72,0x20,0x6F,0x66,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x61,0x6E,0x64,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x6E,0x61,0x6D,0x65,0x73,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x6E,0x75,0x6D,0x65,0x72,0x69,0x63,0x20,0x64,0x69,0x67,0x69,0x74};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x31};
private static byte[] bels_20 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x32};
private static byte[] bels_21 = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] bels_22 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x63,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6F,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x2E};
private static byte[] bels_23 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x74,0x68,0x65,0x73,0x69,0x73,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x28,0x62,0x75,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x29,0x20,0x61,0x66,0x74,0x65,0x72,0x3A,0x20};
public static BEC_3_5_5_5_BuildVisitPass5 bevs_inst;
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_err = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_namepath = null;
BEC_2_4_6_TextString bevl_alias = null;
BEC_2_6_6_SystemObject bevl_mas = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_6_6_SystemObject bevl_tnode = null;
BEC_2_5_4_LogicBool bevl_isFinal = null;
BEC_2_5_4_LogicBool bevl_isLocal = null;
BEC_2_5_4_LogicBool bevl_isNotNull = null;
BEC_2_5_4_BuildNode bevl_prp = null;
BEC_2_4_3_MathInt bevl_prpi = null;
BEC_2_5_4_BuildNode bevl_prptmp = null;
BEC_2_6_6_SystemObject bevl_m = null;
BEC_2_6_6_SystemObject bevl_mx = null;
BEC_2_6_6_SystemObject bevl_nx = null;
BEC_2_6_6_SystemObject bevl_con = null;
BEC_2_6_6_SystemObject bevl_lpnode = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_5_9_BuildTransUnit bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_86_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_111_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_2_5_5_BuildClass bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_118_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_125_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_132_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_141_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_142_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_158_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_160_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_161_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_162_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_164_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_174_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_176_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_177_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_178_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_179_tmpvar_phold = null;
BEC_2_5_6_BuildMethod bevt_180_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_182_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_183_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_184_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_185_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_186_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_188_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_189_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_191_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_192_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_194_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_197_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_198_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_201_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_203_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_208_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_211_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_214_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_216_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_217_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_219_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_220_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_224_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_227_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_228_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_229_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_230_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_231_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_232_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_233_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_236_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_237_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_238_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_239_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_240_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_241_tmpvar_phold = null;
BEC_2_5_9_BuildConstants bevt_242_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_243_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_244_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_245_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_246_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_247_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_249_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_250_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_251_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_253_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_254_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_255_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_256_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_258_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_259_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_261_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_263_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_264_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_265_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_267_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_269_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_270_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_271_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_272_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_273_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_274_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_275_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_276_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_277_tmpvar_phold = null;
bevt_18_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_18_tmpvar_phold.bevi_int == bevt_19_tmpvar_phold.bevi_int) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_20_tmpvar_phold = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
beva_node.bem_heldSet_1(bevt_20_tmpvar_phold);
} /* Line: 27 */
bevt_22_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_22_tmpvar_phold.bevi_int == bevt_23_tmpvar_phold.bevi_int) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_25_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_25_tmpvar_phold == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_27_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_29_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_emptyGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_28_tmpvar_phold);
if (bevt_26_tmpvar_phold != null && bevt_26_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_26_tmpvar_phold).bevi_bool) /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 30 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 30 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 32 */
} /* Line: 30 */
bevl_ix = beva_node.bem_nextPeerGet_0();
if (bevl_ix == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_32_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_33_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_32_tmpvar_phold.bevi_int == bevt_33_tmpvar_phold.bevi_int) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_35_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_36_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_35_tmpvar_phold.bevi_int == bevt_36_tmpvar_phold.bevi_int) {
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_38_tmpvar_phold = bevl_ix.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_39_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_39_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
 else  /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_41_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_41_tmpvar_phold.bevi_int == bevt_42_tmpvar_phold.bevi_int) {
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 38 */ {
bevl_vinp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_43_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_43_tmpvar_phold);
} /* Line: 40 */
 else  /* Line: 41 */ {
bevl_vinp = beva_node.bem_heldGet_0();
} /* Line: 42 */
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_44_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_45_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_45_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 49 */
bevt_47_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_48_tmpvar_phold = bevp_ntypes.bem_USEGet_0();
if (bevt_47_tmpvar_phold.bevi_int == bevt_48_tmpvar_phold.bevi_int) {
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 54 */ {
if (bevl_nnode == null) {
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_49_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_51_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_52_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_52_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 54 */
 else  /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 54 */ {
bevl_nnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 55 */
 else  /* Line: 54 */ {
break;
} /* Line: 54 */
} /* Line: 54 */
if (bevl_nnode == null) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_55_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_56_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_56_tmpvar_phold);
if (bevt_54_tmpvar_phold != null && bevt_54_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_54_tmpvar_phold).bevi_bool) /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 57 */ {
bevl_clnode = bevl_nnode;
bevt_57_tmpvar_phold = bevl_clnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nnode = bevt_57_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_clnode = null;
} /* Line: 61 */
if (bevl_nnode == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 64 */ {
bevt_60_tmpvar_phold = (new BEC_2_4_6_TextString(59, bels_0));
bevt_59_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_60_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_59_tmpvar_phold);
} /* Line: 65 */
bevt_62_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_63_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_63_tmpvar_phold);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 68 */ {
bevl_namepath = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_64_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_64_tmpvar_phold);
} /* Line: 70 */
 else  /* Line: 68 */ {
bevt_66_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_67_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_67_tmpvar_phold);
if (bevt_65_tmpvar_phold != null && bevt_65_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_65_tmpvar_phold).bevi_bool) /* Line: 71 */ {
bevl_namepath = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 72 */
 else  /* Line: 73 */ {
bevt_69_tmpvar_phold = (new BEC_2_4_6_TextString(55, bels_1));
bevt_68_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_69_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_68_tmpvar_phold);
} /* Line: 74 */
} /* Line: 68 */
bevl_alias = null;
bevl_mas = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_71_tmpvar_phold = bevl_mas.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpvar_phold = bevp_ntypes.bem_ASGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 79 */ {
bevl_nnode = bevl_mas.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_74_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_75_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_75_tmpvar_phold);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 81 */ {
bevt_77_tmpvar_phold = (new BEC_2_4_6_TextString(57, bels_2));
bevt_76_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_77_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_76_tmpvar_phold);
} /* Line: 82 */
bevl_alias = (BEC_2_4_6_TextString) bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 84 */
if (bevl_clnode == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_80_tmpvar_phold = bevl_gnext.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_81_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 91 */ {
bevl_nnode = bevl_gnext;
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 94 */
} /* Line: 91 */
 else  /* Line: 96 */ {
bevl_gnext = bevl_clnode;
} /* Line: 97 */
beva_node.bem_heldSet_1(bevl_namepath);
bevl_tnode = beva_node.bem_transUnitGet_0();
if (bevl_tnode == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_84_tmpvar_phold = (new BEC_2_4_6_TextString(53, bels_3));
bevt_83_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_84_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_83_tmpvar_phold);
} /* Line: 104 */
if (bevl_alias == null) {
bevt_85_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_85_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 107 */ {
bevl_alias = (BEC_2_4_6_TextString) bevl_namepath.bemd_0(1672091917, BEL_4_Base.bevn_labelGet_0);
} /* Line: 108 */
bevt_87_tmpvar_phold = bevl_tnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_86_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_alias, bevl_namepath);
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 112 */
bevt_89_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_90_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_89_tmpvar_phold.bevi_int == bevt_90_tmpvar_phold.bevi_int) {
bevt_88_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_88_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 114 */ {
bevl_isFinal = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isLocal = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isNotNull = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 119 */ {
bevt_92_tmpvar_phold = bevo_0;
if (bevl_prpi.bevi_int < bevt_92_tmpvar_phold.bevi_int) {
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 119 */ {
if (bevl_prp == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_95_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_96_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_95_tmpvar_phold.bevi_int == bevt_96_tmpvar_phold.bevi_int) {
bevt_94_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_94_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_94_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_98_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_99_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_98_tmpvar_phold.bevi_int == bevt_99_tmpvar_phold.bevi_int) {
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 122 */ {
bevt_101_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_102_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_4));
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_102_tmpvar_phold);
if (bevt_100_tmpvar_phold != null && bevt_100_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_100_tmpvar_phold).bevi_bool) /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 122 */
 else  /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 122 */ {
bevl_isFinal = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 123 */
 else  /* Line: 122 */ {
bevt_104_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_105_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_104_tmpvar_phold.bevi_int == bevt_105_tmpvar_phold.bevi_int) {
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_107_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_108_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_5));
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_108_tmpvar_phold);
if (bevt_106_tmpvar_phold != null && bevt_106_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_106_tmpvar_phold).bevi_bool) /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
 else  /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevl_isLocal = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 125 */
 else  /* Line: 122 */ {
bevt_110_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_111_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_110_tmpvar_phold.bevi_int == bevt_111_tmpvar_phold.bevi_int) {
bevt_109_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_109_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_113_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_114_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_6));
bevt_112_tmpvar_phold = bevt_113_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_114_tmpvar_phold);
if (bevt_112_tmpvar_phold != null && bevt_112_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_112_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevl_isNotNull = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 127 */
} /* Line: 122 */
} /* Line: 122 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 131 */
 else  /* Line: 132 */ {
bevl_prp = null;
} /* Line: 133 */
} /* Line: 121 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 119 */
 else  /* Line: 119 */ {
break;
} /* Line: 119 */
} /* Line: 119 */
bevt_115_tmpvar_phold = (new BEC_2_5_5_BuildClass()).bem_new_0();
beva_node.bem_heldSet_1(bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_117_tmpvar_phold = bevp_build.bem_fromFileGet_0();
bevt_116_tmpvar_phold.bemd_1(806119150, BEL_4_Base.bevn_fromFileSet_1, bevt_117_tmpvar_phold);
try  /* Line: 139 */ {
bevt_118_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_118_tmpvar_phold.bem_firstGet_0();
bevt_120_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_121_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpvar_phold);
if (bevt_119_tmpvar_phold != null && bevt_119_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_119_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_namepath = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_122_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_122_tmpvar_phold);
} /* Line: 143 */
 else  /* Line: 141 */ {
bevt_124_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_125_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_125_tmpvar_phold);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 144 */ {
bevl_namepath = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 145 */
 else  /* Line: 146 */ {
bevt_127_tmpvar_phold = (new BEC_2_4_6_TextString(35, bels_7));
bevt_126_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 147 */
} /* Line: 141 */
bevt_128_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_128_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_namepath);
bevt_129_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_129_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevl_isFinal);
bevt_130_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_130_tmpvar_phold.bemd_1(831500365, BEL_4_Base.bevn_isLocalSet_1, bevl_isLocal);
bevt_131_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_131_tmpvar_phold.bemd_1(374719236, BEL_4_Base.bevn_isNotNullSet_1, bevl_isNotNull);
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 153 */
 catch (Throwable beve_0) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_133_tmpvar_phold = (new BEC_2_4_6_TextString(61, bels_8));
bevt_132_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_133_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_132_tmpvar_phold);
} /* Line: 156 */
try  /* Line: 158 */ {
bevt_134_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_nnode = bevt_134_tmpvar_phold.bem_firstGet_0();
bevt_136_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_137_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_135_tmpvar_phold = bevt_136_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_137_tmpvar_phold);
if (bevt_135_tmpvar_phold != null && bevt_135_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_135_tmpvar_phold).bevi_bool) /* Line: 160 */ {
bevt_140_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_139_tmpvar_phold = bevt_140_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_141_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevt_138_tmpvar_phold = bevt_139_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_141_tmpvar_phold);
if (bevt_138_tmpvar_phold != null && bevt_138_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_138_tmpvar_phold).bevi_bool) /* Line: 161 */ {
bevt_143_tmpvar_phold = (new BEC_2_4_6_TextString(34, bels_9));
bevt_142_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_143_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_142_tmpvar_phold);
} /* Line: 162 */
try  /* Line: 164 */ {
bevt_144_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_m = bevt_144_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_146_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_147_tmpvar_phold);
if (bevt_145_tmpvar_phold != null && bevt_145_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_145_tmpvar_phold).bevi_bool) /* Line: 166 */ {
bevt_148_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_149_tmpvar_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_148_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_149_tmpvar_phold);
bevt_151_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_152_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_150_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_152_tmpvar_phold);
} /* Line: 168 */
 else  /* Line: 166 */ {
bevt_154_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_155_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_155_tmpvar_phold);
if (bevt_153_tmpvar_phold != null && bevt_153_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_153_tmpvar_phold).bevi_bool) /* Line: 169 */ {
bevt_156_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_157_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_157_tmpvar_phold);
} /* Line: 170 */
 else  /* Line: 171 */ {
bevt_159_tmpvar_phold = (new BEC_2_4_6_TextString(42, bels_10));
bevt_158_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_159_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_158_tmpvar_phold);
} /* Line: 172 */
} /* Line: 166 */
} /* Line: 166 */
 catch (Throwable beve_1) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_1));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_161_tmpvar_phold = (new BEC_2_4_6_TextString(68, bels_11));
bevt_160_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_161_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_160_tmpvar_phold);
} /* Line: 177 */
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 179 */
} /* Line: 160 */
 catch (Throwable beve_2) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_2));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_163_tmpvar_phold = (new BEC_2_4_6_TextString(60, bels_12));
bevt_162_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_163_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_162_tmpvar_phold);
} /* Line: 183 */
bevt_166_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_165_tmpvar_phold == null) {
bevt_164_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_164_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_164_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevt_170_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_169_tmpvar_phold = bevt_170_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_168_tmpvar_phold = bevt_169_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_171_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_13));
bevt_167_tmpvar_phold = bevt_168_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_171_tmpvar_phold);
if (bevt_167_tmpvar_phold != null && bevt_167_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_167_tmpvar_phold).bevi_bool) /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 186 */
 else  /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 186 */ {
bevt_172_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_174_tmpvar_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_175_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_14));
bevt_173_tmpvar_phold = bevt_174_tmpvar_phold.bem_fromString_1(bevt_175_tmpvar_phold);
bevt_172_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_173_tmpvar_phold);
} /* Line: 187 */
bevt_176_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_176_tmpvar_phold;
} /* Line: 190 */
bevt_178_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_179_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_178_tmpvar_phold.bevi_int == bevt_179_tmpvar_phold.bevi_int) {
bevt_177_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_177_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_177_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevt_180_tmpvar_phold = (new BEC_2_5_6_BuildMethod()).bem_new_0();
beva_node.bem_heldSet_1(bevt_180_tmpvar_phold);
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 195 */ {
bevt_182_tmpvar_phold = bevo_1;
if (bevl_prpi.bevi_int < bevt_182_tmpvar_phold.bevi_int) {
bevt_181_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_181_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_181_tmpvar_phold.bevi_bool) /* Line: 195 */ {
if (bevl_prp == null) {
bevt_183_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_183_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_183_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_185_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_186_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_185_tmpvar_phold.bevi_int == bevt_186_tmpvar_phold.bevi_int) {
bevt_184_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_184_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_184_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevt_188_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_189_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_188_tmpvar_phold.bevi_int == bevt_189_tmpvar_phold.bevi_int) {
bevt_187_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_187_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_187_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevt_191_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_192_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_15));
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_192_tmpvar_phold);
if (bevt_190_tmpvar_phold != null && bevt_190_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_190_tmpvar_phold).bevi_bool) /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 198 */
 else  /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 198 */ {
bevt_193_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_193_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevt_194_tmpvar_phold);
} /* Line: 199 */
 else  /* Line: 198 */ {
bevt_196_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_197_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_196_tmpvar_phold.bevi_int == bevt_197_tmpvar_phold.bevi_int) {
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_195_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevt_199_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_200_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_16));
bevt_198_tmpvar_phold = bevt_199_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_200_tmpvar_phold);
if (bevt_198_tmpvar_phold != null && bevt_198_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_198_tmpvar_phold).bevi_bool) /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 200 */
 else  /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 200 */ {
bevt_202_tmpvar_phold = (new BEC_2_4_6_TextString(27, bels_17));
bevt_201_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_202_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_201_tmpvar_phold);
} /* Line: 202 */
} /* Line: 198 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 206 */
 else  /* Line: 207 */ {
bevl_prp = null;
} /* Line: 208 */
} /* Line: 197 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 195 */
 else  /* Line: 195 */ {
break;
} /* Line: 195 */
} /* Line: 195 */
try  /* Line: 212 */ {
bevt_203_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_203_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_204_tmpvar_phold.bevi_bool) /* Line: 214 */ {
bevl_mx = bevl_m.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_mx == null) {
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_205_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevl_mx = bevl_mx.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_207_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_208_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_206_tmpvar_phold = bevt_207_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_208_tmpvar_phold);
if (bevt_206_tmpvar_phold != null && bevt_206_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_206_tmpvar_phold).bevi_bool) /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_210_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_211_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_209_tmpvar_phold = bevt_210_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_211_tmpvar_phold);
if (bevt_209_tmpvar_phold != null && bevt_209_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_209_tmpvar_phold).bevi_bool) /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 218 */ {
bevt_213_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_214_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_212_tmpvar_phold = bevt_213_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_214_tmpvar_phold);
if (bevt_212_tmpvar_phold != null && bevt_212_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_212_tmpvar_phold).bevi_bool) /* Line: 220 */ {
bevl_vinp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_215_tmpvar_phold = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_215_tmpvar_phold);
} /* Line: 222 */
 else  /* Line: 223 */ {
bevl_vinp = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 224 */
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_216_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_216_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_217_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_mx.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_217_tmpvar_phold);
bevl_mx.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
} /* Line: 230 */
} /* Line: 218 */
bevt_219_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_220_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_218_tmpvar_phold = bevt_219_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_220_tmpvar_phold);
if (bevt_218_tmpvar_phold != null && bevt_218_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_218_tmpvar_phold).bevi_bool) /* Line: 233 */ {
bevt_221_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_222_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_221_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_222_tmpvar_phold);
bevt_226_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_227_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_224_tmpvar_phold = bevt_225_tmpvar_phold.bemd_1(636254476, BEL_4_Base.bevn_getPoint_1, bevt_227_tmpvar_phold);
bevt_223_tmpvar_phold = bevt_224_tmpvar_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_223_tmpvar_phold != null && bevt_223_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_223_tmpvar_phold).bevi_bool) /* Line: 235 */ {
bevt_229_tmpvar_phold = (new BEC_2_4_6_TextString(75, bels_18));
bevt_228_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_229_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_228_tmpvar_phold);
} /* Line: 236 */
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 238 */
 else  /* Line: 239 */ {
bevt_231_tmpvar_phold = (new BEC_2_4_6_TextString(42, bels_19));
bevt_230_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_231_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_230_tmpvar_phold);
} /* Line: 240 */
} /* Line: 233 */
 else  /* Line: 242 */ {
bevt_233_tmpvar_phold = (new BEC_2_4_6_TextString(42, bels_20));
bevt_232_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_233_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_232_tmpvar_phold);
} /* Line: 243 */
} /* Line: 214 */
 catch (Throwable beve_3) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_3));
bevt_235_tmpvar_phold = bevl_err.bemd_0(1102720804, BEL_4_Base.bevn_classNameGet_0);
bevt_236_tmpvar_phold = (new BEC_2_4_6_TextString(16, bels_21));
bevt_234_tmpvar_phold = bevt_235_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_236_tmpvar_phold);
if (bevt_234_tmpvar_phold != null && bevt_234_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_234_tmpvar_phold).bevi_bool) /* Line: 246 */ {
throw new be.BELS_Base.BECS_ThrowBack(bevl_err);
} /* Line: 246 */
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_238_tmpvar_phold = (new BEC_2_4_6_TextString(104, bels_22));
bevt_237_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_238_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_237_tmpvar_phold);
} /* Line: 248 */
bevt_239_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_239_tmpvar_phold;
} /* Line: 250 */
bevt_242_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevt_241_tmpvar_phold = bevt_242_tmpvar_phold.bem_parensReqGet_0();
bevt_243_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_240_tmpvar_phold = bevt_241_tmpvar_phold.bem_has_1(bevt_243_tmpvar_phold);
if (bevt_240_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_244_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_244_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_245_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_245_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_245_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_247_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_248_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_246_tmpvar_phold = bevt_247_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_248_tmpvar_phold);
if (bevt_246_tmpvar_phold != null && bevt_246_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_246_tmpvar_phold).bevi_bool) /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 254 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 254 */ {
bevt_250_tmpvar_phold = (new BEC_2_4_6_TextString(50, bels_23));
bevt_249_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_250_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_249_tmpvar_phold);
} /* Line: 255 */
} /* Line: 254 */
bevt_252_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_253_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_252_tmpvar_phold.bevi_int == bevt_253_tmpvar_phold.bevi_int) {
bevt_251_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_251_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_251_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevl_m = beva_node.bem_containerGet_0();
if (bevl_m == null) {
bevt_254_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_254_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_254_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevt_256_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_257_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_255_tmpvar_phold = bevt_256_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_257_tmpvar_phold);
if (bevt_255_tmpvar_phold != null && bevt_255_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_255_tmpvar_phold).bevi_bool) /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 261 */
 else  /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 261 */ {
bevt_258_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
beva_node.bem_typenameSet_1(bevt_258_tmpvar_phold);
} /* Line: 262 */
} /* Line: 261 */
bevt_260_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_261_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
if (bevt_260_tmpvar_phold.bevi_int == bevt_261_tmpvar_phold.bevi_int) {
bevt_259_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_259_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_259_tmpvar_phold.bevi_bool) /* Line: 265 */ {
bevl_nx = beva_node.bem_priorPeerGet_0();
bevl_gnext = beva_node.bem_nextAscendGet_0();
while (true)
 /* Line: 271 */ {
if (bevl_nx == null) {
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_262_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_264_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_265_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_263_tmpvar_phold = bevt_264_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_265_tmpvar_phold);
if (bevt_263_tmpvar_phold != null && bevt_263_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_263_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
bevt_267_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_268_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_266_tmpvar_phold = bevt_267_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_268_tmpvar_phold);
if (bevt_266_tmpvar_phold != null && bevt_266_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_266_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
bevt_270_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_271_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_271_tmpvar_phold);
if (bevt_269_tmpvar_phold != null && bevt_269_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_269_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
if (bevl_con == null) {
bevt_272_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_272_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_272_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevl_con = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 273 */
bevl_con.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_nx);
bevl_nx = bevl_nx.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
} /* Line: 276 */
 else  /* Line: 271 */ {
break;
} /* Line: 271 */
} /* Line: 271 */
if (bevl_con == null) {
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_273_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_274_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
beva_node.bem_typenameSet_1(bevt_274_tmpvar_phold);
beva_node.bem_heldSet_1(null);
bevl_lpnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_275_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_lpnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_275_tmpvar_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_lpnode);
bevl_lpnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_ii = bevl_con.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 285 */ {
bevt_276_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_276_tmpvar_phold != null && bevt_276_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_276_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lpnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 288 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
} /* Line: 285 */
 else  /* Line: 294 */ {
beva_node.bem_delete_0();
} /* Line: 295 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 297 */
bevt_277_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_277_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 26, 26, 26, 27, 27, 29, 29, 29, 29, 30, 30, 30, 0, 30, 30, 30, 30, 0, 0, 31, 32, 35, 36, 36, 36, 36, 36, 36, 0, 36, 36, 36, 36, 0, 0, 0, 0, 0, 36, 36, 36, 0, 0, 0, 38, 38, 38, 38, 39, 40, 40, 42, 44, 45, 45, 47, 48, 48, 49, 51, 51, 51, 51, 53, 54, 54, 54, 54, 54, 0, 0, 0, 55, 57, 57, 57, 57, 57, 0, 0, 0, 58, 59, 59, 61, 64, 64, 65, 65, 65, 68, 68, 68, 69, 70, 70, 71, 71, 71, 72, 74, 74, 74, 77, 78, 79, 79, 79, 80, 81, 81, 81, 82, 82, 82, 84, 87, 87, 88, 89, 91, 91, 91, 92, 93, 94, 97, 99, 101, 103, 103, 104, 104, 104, 107, 107, 108, 110, 110, 110, 112, 114, 114, 114, 114, 115, 116, 117, 118, 119, 119, 119, 119, 120, 120, 121, 121, 121, 121, 122, 122, 122, 122, 122, 122, 122, 0, 0, 0, 123, 124, 124, 124, 124, 124, 124, 124, 0, 0, 0, 125, 126, 126, 126, 126, 126, 126, 126, 0, 0, 0, 127, 129, 130, 131, 133, 119, 137, 137, 138, 138, 138, 140, 140, 141, 141, 141, 142, 143, 143, 144, 144, 144, 145, 147, 147, 147, 149, 149, 150, 150, 151, 151, 152, 152, 153, 155, 156, 156, 156, 159, 159, 160, 160, 160, 161, 161, 161, 161, 162, 162, 162, 165, 165, 166, 166, 166, 167, 167, 167, 168, 168, 168, 168, 169, 169, 169, 170, 170, 170, 172, 172, 172, 176, 177, 177, 177, 179, 182, 183, 183, 183, 186, 186, 186, 186, 186, 186, 186, 186, 186, 0, 0, 0, 187, 187, 187, 187, 187, 190, 190, 192, 192, 192, 192, 193, 193, 194, 195, 195, 195, 195, 196, 196, 197, 197, 197, 197, 198, 198, 198, 198, 198, 198, 198, 0, 0, 0, 199, 199, 199, 200, 200, 200, 200, 200, 200, 200, 0, 0, 0, 202, 202, 202, 204, 205, 206, 208, 195, 213, 213, 214, 214, 215, 216, 216, 217, 218, 218, 218, 0, 218, 218, 218, 0, 0, 220, 220, 220, 221, 222, 222, 224, 226, 227, 227, 228, 229, 229, 230, 233, 233, 233, 234, 234, 234, 235, 235, 235, 235, 235, 236, 236, 236, 238, 240, 240, 240, 243, 243, 243, 246, 246, 246, 246, 247, 248, 248, 248, 250, 250, 252, 252, 252, 252, 253, 253, 254, 254, 0, 254, 254, 254, 0, 0, 255, 255, 255, 259, 259, 259, 259, 260, 261, 261, 261, 261, 261, 0, 0, 0, 262, 262, 265, 265, 265, 265, 266, 267, 271, 271, 271, 271, 271, 0, 0, 0, 271, 271, 271, 0, 0, 0, 271, 271, 271, 0, 0, 0, 272, 272, 273, 275, 276, 278, 278, 279, 279, 280, 281, 282, 282, 283, 284, 285, 285, 286, 287, 288, 295, 297, 300, 300};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {337, 338, 339, 344, 345, 346, 348, 349, 350, 355, 356, 357, 362, 363, 366, 367, 368, 369, 371, 374, 378, 379, 382, 383, 388, 389, 390, 391, 396, 397, 400, 401, 402, 407, 408, 411, 415, 418, 422, 425, 426, 427, 429, 432, 436, 439, 440, 441, 446, 447, 448, 449, 452, 454, 455, 456, 457, 458, 459, 460, 462, 463, 464, 469, 470, 473, 478, 479, 480, 481, 483, 486, 490, 493, 499, 504, 505, 506, 507, 509, 512, 516, 519, 520, 521, 524, 526, 531, 532, 533, 534, 536, 537, 538, 540, 541, 542, 545, 546, 547, 549, 552, 553, 554, 557, 558, 559, 560, 561, 563, 564, 565, 566, 568, 569, 570, 572, 574, 579, 580, 581, 582, 583, 584, 586, 587, 588, 592, 594, 595, 596, 601, 602, 603, 604, 606, 611, 612, 614, 615, 616, 617, 619, 620, 621, 626, 627, 628, 629, 630, 631, 634, 635, 640, 641, 646, 647, 648, 649, 654, 655, 656, 657, 662, 663, 664, 665, 667, 670, 674, 677, 680, 681, 682, 687, 688, 689, 690, 692, 695, 699, 702, 705, 706, 707, 712, 713, 714, 715, 717, 720, 724, 727, 731, 732, 733, 736, 739, 745, 746, 747, 748, 749, 751, 752, 753, 754, 755, 757, 758, 759, 762, 763, 764, 766, 769, 770, 771, 774, 775, 776, 777, 778, 779, 780, 781, 782, 786, 787, 788, 789, 792, 793, 794, 795, 796, 798, 799, 800, 801, 803, 804, 805, 808, 809, 810, 811, 812, 814, 815, 816, 817, 818, 819, 820, 823, 824, 825, 827, 828, 829, 832, 833, 834, 840, 841, 842, 843, 845, 850, 851, 852, 853, 855, 856, 857, 862, 863, 864, 865, 866, 867, 869, 872, 876, 879, 880, 881, 882, 883, 885, 886, 888, 889, 890, 895, 896, 897, 898, 899, 902, 903, 908, 909, 914, 915, 916, 917, 922, 923, 924, 925, 930, 931, 932, 933, 935, 938, 942, 945, 946, 947, 950, 951, 952, 957, 958, 959, 960, 962, 965, 969, 972, 973, 974, 977, 978, 979, 982, 985, 992, 993, 994, 999, 1000, 1001, 1006, 1007, 1008, 1009, 1010, 1012, 1015, 1016, 1017, 1019, 1022, 1026, 1027, 1028, 1030, 1031, 1032, 1035, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1046, 1047, 1048, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1059, 1060, 1061, 1063, 1066, 1067, 1068, 1072, 1073, 1074, 1079, 1080, 1081, 1083, 1085, 1086, 1087, 1088, 1090, 1091, 1093, 1094, 1095, 1096, 1098, 1099, 1100, 1105, 1106, 1109, 1110, 1111, 1113, 1116, 1120, 1121, 1122, 1125, 1126, 1127, 1132, 1133, 1134, 1139, 1140, 1141, 1142, 1144, 1147, 1151, 1154, 1155, 1158, 1159, 1160, 1165, 1166, 1167, 1170, 1175, 1176, 1177, 1178, 1180, 1183, 1187, 1190, 1191, 1192, 1194, 1197, 1201, 1204, 1205, 1206, 1208, 1211, 1215, 1218, 1223, 1224, 1226, 1227, 1233, 1238, 1239, 1240, 1241, 1242, 1243, 1244, 1245, 1246, 1247, 1250, 1252, 1253, 1254, 1262, 1264, 1266, 1267};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 26 337
typenameGet 0 26 337
assign 1 26 338
TRANSUNITGet 0 26 338
assign 1 26 339
equals 1 26 344
assign 1 27 345
new 0 27 345
heldSet 1 27 346
assign 1 29 348
typenameGet 0 29 348
assign 1 29 349
VARGet 0 29 349
assign 1 29 350
equals 1 29 355
assign 1 30 356
heldGet 0 30 356
assign 1 30 357
undef 1 30 362
assign 1 0 363
assign 1 30 366
heldGet 0 30 366
assign 1 30 367
new 0 30 367
assign 1 30 368
emptyGet 0 30 368
assign 1 30 369
sameType 1 30 369
assign 1 0 371
assign 1 0 374
assign 1 31 378
new 0 31 378
heldSet 1 32 379
assign 1 35 382
nextPeerGet 0 35 382
assign 1 36 383
def 1 36 388
assign 1 36 389
typenameGet 0 36 389
assign 1 36 390
IDGet 0 36 390
assign 1 36 391
equals 1 36 396
assign 1 0 397
assign 1 36 400
typenameGet 0 36 400
assign 1 36 401
NAMEPATHGet 0 36 401
assign 1 36 402
equals 1 36 407
assign 1 0 408
assign 1 0 411
assign 1 0 415
assign 1 0 418
assign 1 0 422
assign 1 36 425
typenameGet 0 36 425
assign 1 36 426
IDGet 0 36 426
assign 1 36 427
equals 1 36 427
assign 1 0 429
assign 1 0 432
assign 1 0 436
assign 1 38 439
typenameGet 0 38 439
assign 1 38 440
IDGet 0 38 440
assign 1 38 441
equals 1 38 446
assign 1 39 447
new 0 39 447
assign 1 40 448
heldGet 0 40 448
addStep 1 40 449
assign 1 42 452
heldGet 0 42 452
assign 1 44 454
new 0 44 454
assign 1 45 455
new 0 45 455
isTypedSet 1 45 456
namepathSet 1 47 457
assign 1 48 458
VARGet 0 48 458
typenameSet 1 48 459
heldSet 1 49 460
assign 1 51 462
typenameGet 0 51 462
assign 1 51 463
USEGet 0 51 463
assign 1 51 464
equals 1 51 469
assign 1 53 470
nextPeerGet 0 53 470
assign 1 54 473
def 1 54 478
assign 1 54 479
typenameGet 0 54 479
assign 1 54 480
DEFMODGet 0 54 480
assign 1 54 481
equals 1 54 481
assign 1 0 483
assign 1 0 486
assign 1 0 490
assign 1 55 493
nextPeerGet 0 55 493
assign 1 57 499
def 1 57 504
assign 1 57 505
typenameGet 0 57 505
assign 1 57 506
CLASSGet 0 57 506
assign 1 57 507
equals 1 57 507
assign 1 0 509
assign 1 0 512
assign 1 0 516
assign 1 58 519
assign 1 59 520
containedGet 0 59 520
assign 1 59 521
firstGet 0 59 521
assign 1 61 524
assign 1 64 526
undef 1 64 531
assign 1 65 532
new 0 65 532
assign 1 65 533
new 2 65 533
throw 1 65 534
assign 1 68 536
typenameGet 0 68 536
assign 1 68 537
IDGet 0 68 537
assign 1 68 538
equals 1 68 538
assign 1 69 540
new 0 69 540
assign 1 70 541
heldGet 0 70 541
addStep 1 70 542
assign 1 71 545
typenameGet 0 71 545
assign 1 71 546
NAMEPATHGet 0 71 546
assign 1 71 547
equals 1 71 547
assign 1 72 549
heldGet 0 72 549
assign 1 74 552
new 0 74 552
assign 1 74 553
new 2 74 553
throw 1 74 554
assign 1 77 557
assign 1 78 558
nextPeerGet 0 78 558
assign 1 79 559
typenameGet 0 79 559
assign 1 79 560
ASGet 0 79 560
assign 1 79 561
equals 1 79 561
assign 1 80 563
nextPeerGet 0 80 563
assign 1 81 564
typenameGet 0 81 564
assign 1 81 565
IDGet 0 81 565
assign 1 81 566
notEquals 1 81 566
assign 1 82 568
new 0 82 568
assign 1 82 569
new 2 82 569
throw 1 82 570
assign 1 84 572
heldGet 0 84 572
assign 1 87 574
undef 1 87 579
assign 1 88 580
nextPeerGet 0 88 580
delete 0 89 581
assign 1 91 582
typenameGet 0 91 582
assign 1 91 583
SEMIGet 0 91 583
assign 1 91 584
equals 1 91 584
assign 1 92 586
assign 1 93 587
nextPeerGet 0 93 587
delete 0 94 588
assign 1 97 592
heldSet 1 99 594
assign 1 101 595
transUnitGet 0 101 595
assign 1 103 596
undef 1 103 601
assign 1 104 602
new 0 104 602
assign 1 104 603
new 2 104 603
throw 1 104 604
assign 1 107 606
undef 1 107 611
assign 1 108 612
labelGet 0 108 612
assign 1 110 614
heldGet 0 110 614
assign 1 110 615
aliasedGet 0 110 615
put 2 110 616
return 1 112 617
assign 1 114 619
typenameGet 0 114 619
assign 1 114 620
CLASSGet 0 114 620
assign 1 114 621
equals 1 114 626
assign 1 115 627
new 0 115 627
assign 1 116 628
new 0 116 628
assign 1 117 629
new 0 117 629
assign 1 118 630
priorPeerGet 0 118 630
assign 1 119 631
new 0 119 631
assign 1 119 634
new 0 119 634
assign 1 119 635
lesser 1 119 640
assign 1 120 641
def 1 120 646
assign 1 121 647
typenameGet 0 121 647
assign 1 121 648
DEFMODGet 0 121 648
assign 1 121 649
equals 1 121 654
assign 1 122 655
typenameGet 0 122 655
assign 1 122 656
DEFMODGet 0 122 656
assign 1 122 657
equals 1 122 662
assign 1 122 663
heldGet 0 122 663
assign 1 122 664
new 0 122 664
assign 1 122 665
equals 1 122 665
assign 1 0 667
assign 1 0 670
assign 1 0 674
assign 1 123 677
new 0 123 677
assign 1 124 680
typenameGet 0 124 680
assign 1 124 681
DEFMODGet 0 124 681
assign 1 124 682
equals 1 124 687
assign 1 124 688
heldGet 0 124 688
assign 1 124 689
new 0 124 689
assign 1 124 690
equals 1 124 690
assign 1 0 692
assign 1 0 695
assign 1 0 699
assign 1 125 702
new 0 125 702
assign 1 126 705
typenameGet 0 126 705
assign 1 126 706
DEFMODGet 0 126 706
assign 1 126 707
equals 1 126 712
assign 1 126 713
heldGet 0 126 713
assign 1 126 714
new 0 126 714
assign 1 126 715
equals 1 126 715
assign 1 0 717
assign 1 0 720
assign 1 0 724
assign 1 127 727
new 0 127 727
assign 1 129 731
priorPeerGet 0 129 731
delete 0 130 732
assign 1 131 733
assign 1 133 736
assign 1 119 739
increment 0 119 739
assign 1 137 745
new 0 137 745
heldSet 1 137 746
assign 1 138 747
heldGet 0 138 747
assign 1 138 748
fromFileGet 0 138 748
fromFileSet 1 138 749
assign 1 140 751
containedGet 0 140 751
assign 1 140 752
firstGet 0 140 752
assign 1 141 753
typenameGet 0 141 753
assign 1 141 754
IDGet 0 141 754
assign 1 141 755
equals 1 141 755
assign 1 142 757
new 0 142 757
assign 1 143 758
heldGet 0 143 758
addStep 1 143 759
assign 1 144 762
typenameGet 0 144 762
assign 1 144 763
NAMEPATHGet 0 144 763
assign 1 144 764
equals 1 144 764
assign 1 145 766
heldGet 0 145 766
assign 1 147 769
new 0 147 769
assign 1 147 770
new 2 147 770
throw 1 147 771
assign 1 149 774
heldGet 0 149 774
namepathSet 1 149 775
assign 1 150 776
heldGet 0 150 776
isFinalSet 1 150 777
assign 1 151 778
heldGet 0 151 778
isLocalSet 1 151 779
assign 1 152 780
heldGet 0 152 780
isNotNullSet 1 152 781
delete 0 153 782
print 0 155 786
assign 1 156 787
new 0 156 787
assign 1 156 788
new 2 156 788
throw 1 156 789
assign 1 159 792
containedGet 0 159 792
assign 1 159 793
firstGet 0 159 793
assign 1 160 794
typenameGet 0 160 794
assign 1 160 795
PARENSGet 0 160 795
assign 1 160 796
equals 1 160 796
assign 1 161 798
containedGet 0 161 798
assign 1 161 799
lengthGet 0 161 799
assign 1 161 800
new 0 161 800
assign 1 161 801
greater 1 161 801
assign 1 162 803
new 0 162 803
assign 1 162 804
new 2 162 804
throw 1 162 805
assign 1 165 808
containedGet 0 165 808
assign 1 165 809
firstGet 0 165 809
assign 1 166 810
typenameGet 0 166 810
assign 1 166 811
IDGet 0 166 811
assign 1 166 812
equals 1 166 812
assign 1 167 814
heldGet 0 167 814
assign 1 167 815
new 0 167 815
extendsSet 1 167 816
assign 1 168 817
heldGet 0 168 817
assign 1 168 818
extendsGet 0 168 818
assign 1 168 819
heldGet 0 168 819
addStep 1 168 820
assign 1 169 823
typenameGet 0 169 823
assign 1 169 824
NAMEPATHGet 0 169 824
assign 1 169 825
equals 1 169 825
assign 1 170 827
heldGet 0 170 827
assign 1 170 828
heldGet 0 170 828
extendsSet 1 170 829
assign 1 172 832
new 0 172 832
assign 1 172 833
new 2 172 833
throw 1 172 834
print 0 176 840
assign 1 177 841
new 0 177 841
assign 1 177 842
new 2 177 842
throw 1 177 843
delete 0 179 845
print 0 182 850
assign 1 183 851
new 0 183 851
assign 1 183 852
new 2 183 852
throw 1 183 853
assign 1 186 855
heldGet 0 186 855
assign 1 186 856
extendsGet 0 186 856
assign 1 186 857
undef 1 186 862
assign 1 186 863
heldGet 0 186 863
assign 1 186 864
namepathGet 0 186 864
assign 1 186 865
toString 0 186 865
assign 1 186 866
new 0 186 866
assign 1 186 867
notEquals 1 186 867
assign 1 0 869
assign 1 0 872
assign 1 0 876
assign 1 187 879
heldGet 0 187 879
assign 1 187 880
new 0 187 880
assign 1 187 881
new 0 187 881
assign 1 187 882
fromString 1 187 882
extendsSet 1 187 883
assign 1 190 885
nextDescendGet 0 190 885
return 1 190 886
assign 1 192 888
typenameGet 0 192 888
assign 1 192 889
METHODGet 0 192 889
assign 1 192 890
equals 1 192 895
assign 1 193 896
new 0 193 896
heldSet 1 193 897
assign 1 194 898
priorPeerGet 0 194 898
assign 1 195 899
new 0 195 899
assign 1 195 902
new 0 195 902
assign 1 195 903
lesser 1 195 908
assign 1 196 909
def 1 196 914
assign 1 197 915
typenameGet 0 197 915
assign 1 197 916
DEFMODGet 0 197 916
assign 1 197 917
equals 1 197 922
assign 1 198 923
typenameGet 0 198 923
assign 1 198 924
DEFMODGet 0 198 924
assign 1 198 925
equals 1 198 930
assign 1 198 931
heldGet 0 198 931
assign 1 198 932
new 0 198 932
assign 1 198 933
equals 1 198 933
assign 1 0 935
assign 1 0 938
assign 1 0 942
assign 1 199 945
heldGet 0 199 945
assign 1 199 946
new 0 199 946
isFinalSet 1 199 947
assign 1 200 950
typenameGet 0 200 950
assign 1 200 951
DEFMODGet 0 200 951
assign 1 200 952
equals 1 200 957
assign 1 200 958
heldGet 0 200 958
assign 1 200 959
new 0 200 959
assign 1 200 960
equals 1 200 960
assign 1 0 962
assign 1 0 965
assign 1 0 969
assign 1 202 972
new 0 202 972
assign 1 202 973
new 2 202 973
throw 1 202 974
assign 1 204 977
priorPeerGet 0 204 977
delete 0 205 978
assign 1 206 979
assign 1 208 982
assign 1 195 985
increment 0 195 985
assign 1 213 992
containedGet 0 213 992
assign 1 213 993
firstGet 0 213 993
assign 1 214 994
def 1 214 999
assign 1 215 1000
nextPeerGet 0 215 1000
assign 1 216 1001
def 1 216 1006
assign 1 217 1007
nextPeerGet 0 217 1007
assign 1 218 1008
typenameGet 0 218 1008
assign 1 218 1009
IDGet 0 218 1009
assign 1 218 1010
equals 1 218 1010
assign 1 0 1012
assign 1 218 1015
typenameGet 0 218 1015
assign 1 218 1016
NAMEPATHGet 0 218 1016
assign 1 218 1017
equals 1 218 1017
assign 1 0 1019
assign 1 0 1022
assign 1 220 1026
typenameGet 0 220 1026
assign 1 220 1027
IDGet 0 220 1027
assign 1 220 1028
equals 1 220 1028
assign 1 221 1030
new 0 221 1030
assign 1 222 1031
heldGet 0 222 1031
addStep 1 222 1032
assign 1 224 1035
heldGet 0 224 1035
assign 1 226 1037
new 0 226 1037
assign 1 227 1038
new 0 227 1038
isTypedSet 1 227 1039
namepathSet 1 228 1040
assign 1 229 1041
VARGet 0 229 1041
typenameSet 1 229 1042
heldSet 1 230 1043
assign 1 233 1046
typenameGet 0 233 1046
assign 1 233 1047
IDGet 0 233 1047
assign 1 233 1048
equals 1 233 1048
assign 1 234 1050
heldGet 0 234 1050
assign 1 234 1051
heldGet 0 234 1051
nameSet 1 234 1052
assign 1 235 1053
heldGet 0 235 1053
assign 1 235 1054
nameGet 0 235 1054
assign 1 235 1055
new 0 235 1055
assign 1 235 1056
getPoint 1 235 1056
assign 1 235 1057
isInteger 0 235 1057
assign 1 236 1059
new 0 236 1059
assign 1 236 1060
new 2 236 1060
throw 1 236 1061
delete 0 238 1063
assign 1 240 1066
new 0 240 1066
assign 1 240 1067
new 2 240 1067
throw 1 240 1068
assign 1 243 1072
new 0 243 1072
assign 1 243 1073
new 2 243 1073
throw 1 243 1074
assign 1 246 1079
classNameGet 0 246 1079
assign 1 246 1080
new 0 246 1080
assign 1 246 1081
equals 1 246 1081
throw 1 246 1083
print 0 247 1085
assign 1 248 1086
new 0 248 1086
assign 1 248 1087
new 2 248 1087
throw 1 248 1088
assign 1 250 1090
nextDescendGet 0 250 1090
return 1 250 1091
assign 1 252 1093
constantsGet 0 252 1093
assign 1 252 1094
parensReqGet 0 252 1094
assign 1 252 1095
typenameGet 0 252 1095
assign 1 252 1096
has 1 252 1096
assign 1 253 1098
containedGet 0 253 1098
assign 1 253 1099
firstGet 0 253 1099
assign 1 254 1100
undef 1 254 1105
assign 1 0 1106
assign 1 254 1109
typenameGet 0 254 1109
assign 1 254 1110
PARENSGet 0 254 1110
assign 1 254 1111
notEquals 1 254 1111
assign 1 0 1113
assign 1 0 1116
assign 1 255 1120
new 0 255 1120
assign 1 255 1121
new 2 255 1121
throw 1 255 1122
assign 1 259 1125
typenameGet 0 259 1125
assign 1 259 1126
BRACESGet 0 259 1126
assign 1 259 1127
equals 1 259 1132
assign 1 260 1133
containerGet 0 260 1133
assign 1 261 1134
def 1 261 1139
assign 1 261 1140
typenameGet 0 261 1140
assign 1 261 1141
EXPRGet 0 261 1141
assign 1 261 1142
equals 1 261 1142
assign 1 0 1144
assign 1 0 1147
assign 1 0 1151
assign 1 262 1154
PARENSGet 0 262 1154
typenameSet 1 262 1155
assign 1 265 1158
typenameGet 0 265 1158
assign 1 265 1159
SEMIGet 0 265 1159
assign 1 265 1160
equals 1 265 1165
assign 1 266 1166
priorPeerGet 0 266 1166
assign 1 267 1167
nextAscendGet 0 267 1167
assign 1 271 1170
def 1 271 1175
assign 1 271 1176
typenameGet 0 271 1176
assign 1 271 1177
SEMIGet 0 271 1177
assign 1 271 1178
notEquals 1 271 1178
assign 1 0 1180
assign 1 0 1183
assign 1 0 1187
assign 1 271 1190
typenameGet 0 271 1190
assign 1 271 1191
BRACESGet 0 271 1191
assign 1 271 1192
notEquals 1 271 1192
assign 1 0 1194
assign 1 0 1197
assign 1 0 1201
assign 1 271 1204
typenameGet 0 271 1204
assign 1 271 1205
EXPRGet 0 271 1205
assign 1 271 1206
notEquals 1 271 1206
assign 1 0 1208
assign 1 0 1211
assign 1 0 1215
assign 1 272 1218
undef 1 272 1223
assign 1 273 1224
new 0 273 1224
prepend 1 275 1226
assign 1 276 1227
priorPeerGet 0 276 1227
assign 1 278 1233
def 1 278 1238
assign 1 279 1239
EXPRGet 0 279 1239
typenameSet 1 279 1240
heldSet 1 280 1241
assign 1 281 1242
new 1 281 1242
assign 1 282 1243
PARENSGet 0 282 1243
typenameSet 1 282 1244
addValue 1 283 1245
copyLoc 1 284 1246
assign 1 285 1247
iteratorGet 0 285 1247
assign 1 285 1250
hasNextGet 0 285 1250
assign 1 286 1252
nextGet 0 286 1252
delete 0 287 1253
addValue 1 288 1254
delete 0 295 1262
return 1 297 1264
assign 1 300 1266
nextDescendGet 0 300 1266
return 1 300 1267
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass5();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass5.bevs_inst = (BEC_3_5_5_5_BuildVisitPass5)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass5.bevs_inst;
}
}
