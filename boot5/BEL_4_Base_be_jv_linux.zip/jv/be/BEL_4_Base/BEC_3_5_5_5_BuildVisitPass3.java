package be.BEL_4_Base;
/* IO:File: source/build/Pass3.be */
public class BEC_3_5_5_5_BuildVisitPass3 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass3() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x33};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x33,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_0 = {0x2D};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_0, 1));
public static BEC_3_5_5_5_BuildVisitPass3 bevs_inst;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_4_3_MathInt bevp_nestComment;
public BEC_2_4_3_MathInt bevp_strqCnt;
public BEC_2_5_4_BuildNode bevp_goingStr;
public BEC_2_4_3_MathInt bevp_quoteType;
public BEC_2_5_4_LogicBool bevp_inLc;
public BEC_2_5_4_LogicBool bevp_inSpace;
public BEC_2_5_4_LogicBool bevp_inNl;
public BEC_2_5_4_LogicBool bevp_inStr;
public BEC_2_6_6_SystemObject bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bevp_nestComment = (new BEC_2_4_3_MathInt(0));
bevp_strqCnt = (new BEC_2_4_3_MathInt(0));
bevp_inLc = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inSpace = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inNl = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inStr = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_toRet = null;
BEC_2_5_4_BuildNode bevl_xn = null;
BEC_2_4_3_MathInt bevl_typename = null;
BEC_2_5_4_BuildNode bevl_nextPeer = null;
BEC_2_4_3_MathInt bevl_nextPeerTypename = null;
BEC_2_4_3_MathInt bevl_fsc = null;
BEC_2_6_6_SystemObject bevl_csc = null;
BEC_2_6_6_SystemObject bevl_ia = null;
BEC_2_5_4_BuildNode bevl_vback = null;
BEC_2_5_4_BuildNode bevl_pre = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_41_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_45_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_49_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_50_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_55_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_64_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_72_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_111_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_113_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_131_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_133_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_134_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_135_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_136_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_137_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_138_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_139_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_141_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_143_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_144_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_147_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_148_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_149_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_150_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_153_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_160_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_161_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_162_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_163_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_167_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_168_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_169_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_170_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_171_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_172_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_173_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_177_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_178_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_179_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_180_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_181_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_182_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_183_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_186_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_190_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_191_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_192_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_196_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_197_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_198_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_200_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_202_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_203_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_204_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_206_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_207_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_208_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_209_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_210_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_211_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_212_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_216_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_217_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_218_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_219_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_220_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_221_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_222_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_223_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_224_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_225_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_226_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_227_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_228_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_231_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_232_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_233_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_234_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_235_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_236_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_237_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_239_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_240_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_241_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_242_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_243_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_244_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_245_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_246_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_247_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_249_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_250_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_251_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_253_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_254_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_255_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_256_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_257_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_258_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_259_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_261_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_263_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_265_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_266_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_267_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_269_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_270_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_271_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_272_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_273_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_274_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_275_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_276_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_277_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_278_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_279_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_280_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_281_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_282_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_283_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_284_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_285_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_286_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_287_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_288_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_289_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_290_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_291_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_292_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_293_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_294_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_295_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_296_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_297_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_298_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_299_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_300_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_301_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_302_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_303_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_304_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_305_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_306_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_307_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_308_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_309_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_310_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_311_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_312_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_313_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_314_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_315_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_316_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_317_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_318_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_319_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_320_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_321_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_322_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_323_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_324_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_325_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_326_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_327_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_328_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_329_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_330_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_331_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_332_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_333_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_334_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_335_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_336_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_337_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_338_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_339_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_340_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_341_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_342_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_343_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_344_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_345_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_346_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_347_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_348_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_349_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_350_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_351_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_352_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_353_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_354_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_355_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_356_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_357_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_358_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_359_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_360_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_361_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_362_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_363_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_364_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_365_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_366_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_367_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_368_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_369_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_370_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_371_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_372_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_373_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_374_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_375_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_376_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_377_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_378_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_379_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_380_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_381_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_382_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_383_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_384_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_385_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_386_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_387_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_388_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_389_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_390_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_391_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_392_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_393_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_394_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_395_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_396_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_397_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_398_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_399_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_400_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_401_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_402_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_403_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_404_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_405_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_406_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_407_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_408_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_409_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_410_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_411_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_412_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_413_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_414_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_415_tmpvar_phold = null;
bevl_typename = beva_node.bem_typenameGet_0();
bevl_nextPeer = beva_node.bem_nextPeerGet_0();
if (bevl_nextPeer == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevl_nextPeerTypename = bevl_nextPeer.bem_typenameGet_0();
} /* Line: 56 */
bevt_59_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_typename.bevi_int == bevt_59_tmpvar_phold.bevi_int) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 60 */ {
if (bevl_nextPeer == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_62_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_62_tmpvar_phold.bevi_int) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_61_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_63_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevp_nestComment = bevp_nestComment.bem_increment_0();
bevt_64_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_64_tmpvar_phold.bem_nextDescendGet_0();
bevt_65_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_65_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 66 */
bevt_67_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
if (bevl_typename.bevi_int == bevt_67_tmpvar_phold.bevi_int) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 68 */ {
if (bevl_nextPeer == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 68 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 68 */
 else  /* Line: 68 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 68 */ {
bevt_70_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_70_tmpvar_phold.bevi_int) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 68 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 68 */
 else  /* Line: 68 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 68 */ {
bevt_71_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 68 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 68 */
 else  /* Line: 68 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 68 */ {
bevp_nestComment = bevp_nestComment.bem_decrement_0();
bevt_72_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_72_tmpvar_phold.bem_nextDescendGet_0();
bevt_73_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_73_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 74 */
bevt_75_tmpvar_phold = bevo_0;
if (bevp_nestComment.bevi_int > bevt_75_tmpvar_phold.bevi_int) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 79 */
bevt_76_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_77_tmpvar_phold = bevp_inLc.bem_not_0();
if (bevt_77_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevt_79_tmpvar_phold = bevp_ntypes.bem_STRQGet_0();
if (bevl_typename.bevi_int == bevt_79_tmpvar_phold.bevi_int) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_81_tmpvar_phold = bevp_ntypes.bem_WSTRQGet_0();
if (bevl_typename.bevi_int == bevt_81_tmpvar_phold.bevi_int) {
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevl_xn = beva_node.bem_nextPeerGet_0();
bevp_strqCnt = (new BEC_2_4_3_MathInt(1));
bevp_quoteType = beva_node.bem_typenameGet_0();
while (true)
 /* Line: 85 */ {
if (bevl_xn == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevt_84_tmpvar_phold = bevl_xn.bem_typenameGet_0();
if (bevt_84_tmpvar_phold.bevi_int == bevp_quoteType.bevi_int) {
bevt_83_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_83_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
 else  /* Line: 85 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 85 */ {
bevp_strqCnt = bevp_strqCnt.bem_increment_0();
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 88 */
 else  /* Line: 85 */ {
break;
} /* Line: 85 */
} /* Line: 85 */
bevt_86_tmpvar_phold = bevo_1;
if (bevp_strqCnt.bevi_int == bevt_86_tmpvar_phold.bevi_int) {
bevt_85_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_85_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 90 */ {
bevp_strqCnt = (new BEC_2_4_3_MathInt(0));
bevt_87_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_0();
beva_node.bem_heldSet_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
beva_node.bem_typenameSet_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
beva_node.bem_typeDetailSet_1(bevt_89_tmpvar_phold);
} /* Line: 94 */
 else  /* Line: 95 */ {
bevp_inStr = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_goingStr = beva_node;
bevt_90_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_0();
beva_node.bem_heldSet_1(bevt_90_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_ntypes.bem_WSTRQGet_0();
if (bevl_typename.bevi_int == bevt_92_tmpvar_phold.bevi_int) {
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_93_tmpvar_phold = bevp_ntypes.bem_WSTRINGLGet_0();
bevp_goingStr.bem_typenameSet_1(bevt_93_tmpvar_phold);
} /* Line: 101 */
 else  /* Line: 102 */ {
bevt_94_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevp_goingStr.bem_typenameSet_1(bevt_94_tmpvar_phold);
} /* Line: 103 */
} /* Line: 99 */
return bevl_xn;
} /* Line: 106 */
if (bevp_inStr.bevi_bool) /* Line: 108 */ {
bevt_95_tmpvar_phold = bevp_inLc.bem_not_0();
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 108 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
 else  /* Line: 108 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 108 */ {
bevt_97_tmpvar_phold = bevp_goingStr.bem_typenameGet_0();
bevt_98_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_97_tmpvar_phold.bevi_int == bevt_98_tmpvar_phold.bevi_int) {
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_100_tmpvar_phold = bevp_ntypes.bem_FSLASHGet_0();
if (bevl_typename.bevi_int == bevt_100_tmpvar_phold.bevi_int) {
bevt_99_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_99_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_99_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 109 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 109 */
 else  /* Line: 109 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 109 */ {
beva_node.bem_delayDelete_0();
bevl_xn = beva_node.bem_nextPeerGet_0();
bevl_fsc = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 113 */ {
if (bevl_xn == null) {
bevt_101_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_101_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_101_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_103_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_104_tmpvar_phold = bevp_ntypes.bem_FSLASHGet_0();
if (bevt_103_tmpvar_phold.bevi_int == bevt_104_tmpvar_phold.bevi_int) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 113 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 113 */
 else  /* Line: 113 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 113 */ {
bevl_fsc = bevl_fsc.bem_increment_0();
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 116 */
 else  /* Line: 113 */ {
break;
} /* Line: 113 */
} /* Line: 113 */
bevl_ia = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 118 */ {
bevt_105_tmpvar_phold = bevl_ia.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fsc);
if (bevt_105_tmpvar_phold != null && bevt_105_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_105_tmpvar_phold).bevi_bool) /* Line: 118 */ {
bevt_107_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_108_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_108_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_106_tmpvar_phold);
bevl_ia = bevl_ia.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 118 */
 else  /* Line: 118 */ {
break;
} /* Line: 118 */
} /* Line: 118 */
if (bevl_xn == null) {
bevt_109_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_109_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_112_tmpvar_phold = bevo_2;
bevt_111_tmpvar_phold = bevl_fsc.bem_modulus_1(bevt_112_tmpvar_phold);
bevt_113_tmpvar_phold = bevo_3;
if (bevt_111_tmpvar_phold.bevi_int == bevt_113_tmpvar_phold.bevi_int) {
bevt_110_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_110_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_110_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 121 */ {
bevt_115_tmpvar_phold = bevl_xn.bem_typenameGet_0();
if (bevt_115_tmpvar_phold.bevi_int == bevp_quoteType.bevi_int) {
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 121 */ {
bevl_xn.bem_delayDelete_0();
bevt_117_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_118_tmpvar_phold = bevl_xn.bem_heldGet_0();
bevt_116_tmpvar_phold = bevt_117_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_118_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_116_tmpvar_phold);
bevl_xn = bevl_xn.bem_nextDescendGet_0();
} /* Line: 124 */
return bevl_xn;
} /* Line: 126 */
 else  /* Line: 109 */ {
if (bevl_typename.bevi_int == bevp_quoteType.bevi_int) {
bevt_119_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_119_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_119_tmpvar_phold.bevi_bool) /* Line: 127 */ {
beva_node.bem_delayDelete_0();
bevl_xn = beva_node.bem_nextPeerGet_0();
bevl_csc = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 131 */ {
if (bevl_xn == null) {
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevt_122_tmpvar_phold = bevl_xn.bem_typenameGet_0();
if (bevt_122_tmpvar_phold.bevi_int == bevp_quoteType.bevi_int) {
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
 else  /* Line: 131 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 131 */ {
bevl_csc = bevl_csc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 134 */
 else  /* Line: 131 */ {
break;
} /* Line: 131 */
} /* Line: 131 */
bevt_123_tmpvar_phold = bevl_csc.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_strqCnt);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevp_goingStr.bem_typeDetailSet_1(bevp_strqCnt);
bevp_strqCnt = (new BEC_2_4_3_MathInt(0));
bevp_goingStr = null;
bevp_inStr = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 140 */
 else  /* Line: 141 */ {
bevl_ia = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 142 */ {
bevt_124_tmpvar_phold = bevl_ia.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_csc);
if (bevt_124_tmpvar_phold != null && bevt_124_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_124_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevt_126_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_127_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_125_tmpvar_phold = bevt_126_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_127_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_125_tmpvar_phold);
bevl_ia = bevl_ia.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 142 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
} /* Line: 142 */
return bevl_xn;
} /* Line: 146 */
 else  /* Line: 147 */ {
bevt_129_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_130_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_130_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_128_tmpvar_phold);
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 151 */
} /* Line: 109 */
} /* Line: 109 */
bevt_132_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_typename.bevi_int == bevt_132_tmpvar_phold.bevi_int) {
bevt_131_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_131_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_131_tmpvar_phold.bevi_bool) /* Line: 154 */ {
if (bevl_nextPeer == null) {
bevt_133_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_133_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_133_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 154 */ {
bevt_135_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_135_tmpvar_phold.bevi_int) {
bevt_134_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_134_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_134_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 154 */ {
bevt_136_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_136_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 154 */ {
bevt_137_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_137_tmpvar_phold.bem_nextDescendGet_0();
bevp_inLc = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_138_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_138_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 159 */
if (bevp_inLc.bevi_bool) /* Line: 161 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
bevt_140_tmpvar_phold = bevl_toRet.bem_typenameGet_0();
bevt_141_tmpvar_phold = bevp_ntypes.bem_NEWLINEGet_0();
if (bevt_140_tmpvar_phold.bevi_int == bevt_141_tmpvar_phold.bevi_int) {
bevt_139_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_139_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_139_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevp_inLc = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_toRet.bem_delayDelete_0();
bevl_toRet = bevl_toRet.bem_nextDescendGet_0();
} /* Line: 167 */
return bevl_toRet;
} /* Line: 169 */
bevt_143_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
if (bevl_typename.bevi_int == bevt_143_tmpvar_phold.bevi_int) {
bevt_142_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpvar_phold.bevi_bool) /* Line: 171 */ {
if (bevl_nextPeer == null) {
bevt_144_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_144_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_144_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
 else  /* Line: 171 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_19_tmpvar_anchor.bevi_bool) /* Line: 171 */ {
bevt_146_tmpvar_phold = bevp_ntypes.bem_INTLGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_146_tmpvar_phold.bevi_int) {
bevt_145_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_145_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_145_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
 else  /* Line: 171 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 171 */ {
bevt_148_tmpvar_phold = beva_node.bem_priorPeerGet_0();
if (bevt_148_tmpvar_phold == null) {
bevt_147_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_147_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_147_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevl_vback = beva_node.bem_priorPeerGet_0();
while (true)
 /* Line: 174 */ {
if (bevl_vback == null) {
bevt_149_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_149_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_149_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_151_tmpvar_phold = bevl_vback.bem_typenameGet_0();
bevt_152_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_151_tmpvar_phold.bevi_int == bevt_152_tmpvar_phold.bevi_int) {
bevt_150_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_150_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_150_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 174 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 174 */
 else  /* Line: 174 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_20_tmpvar_anchor.bevi_bool) /* Line: 174 */ {
bevl_vback = bevl_vback.bem_priorPeerGet_0();
} /* Line: 175 */
 else  /* Line: 174 */ {
break;
} /* Line: 174 */
} /* Line: 174 */
bevl_pre = bevl_vback;
} /* Line: 177 */
if (bevl_pre == null) {
bevt_153_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_153_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_153_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_155_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_156_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
if (bevt_155_tmpvar_phold.bevi_int == bevt_156_tmpvar_phold.bevi_int) {
bevt_154_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
if (bevt_23_tmpvar_anchor.bevi_bool) /* Line: 180 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_158_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_159_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_158_tmpvar_phold.bevi_int == bevt_159_tmpvar_phold.bevi_int) {
bevt_157_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
if (bevt_22_tmpvar_anchor.bevi_bool) /* Line: 180 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_161_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_162_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_160_tmpvar_phold = bevt_161_tmpvar_phold.bem_has_1(bevt_162_tmpvar_phold);
if (bevt_160_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
if (bevt_21_tmpvar_anchor.bevi_bool) /* Line: 180 */ {
bevt_163_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_165_tmpvar_phold = bevo_4;
bevt_167_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_166_tmpvar_phold = bevt_167_tmpvar_phold.bem_heldGet_0();
bevt_164_tmpvar_phold = bevt_165_tmpvar_phold.bem_add_1(bevt_166_tmpvar_phold);
bevt_163_tmpvar_phold.bem_heldSet_1(bevt_164_tmpvar_phold);
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 186 */
} /* Line: 180 */
bevt_169_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_typename.bevi_int == bevt_169_tmpvar_phold.bevi_int) {
bevt_168_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_168_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_168_tmpvar_phold.bevi_bool) /* Line: 189 */ {
if (bevl_nextPeer == null) {
bevt_170_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_170_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_170_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
 else  /* Line: 189 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_25_tmpvar_anchor.bevi_bool) /* Line: 189 */ {
bevt_172_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_172_tmpvar_phold.bevi_int) {
bevt_171_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_171_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_171_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
 else  /* Line: 189 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_24_tmpvar_anchor.bevi_bool) /* Line: 189 */ {
bevt_173_tmpvar_phold = bevp_ntypes.bem_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_173_tmpvar_phold);
bevt_175_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_177_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_176_tmpvar_phold = bevt_177_tmpvar_phold.bem_heldGet_0();
bevt_174_tmpvar_phold = bevt_175_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_176_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_174_tmpvar_phold);
bevt_178_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_178_tmpvar_phold.bem_nextDescendGet_0();
bevt_179_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_179_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 194 */
bevt_181_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_typename.bevi_int == bevt_181_tmpvar_phold.bevi_int) {
bevt_180_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_180_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_180_tmpvar_phold.bevi_bool) /* Line: 196 */ {
if (bevl_nextPeer == null) {
bevt_182_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_182_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_182_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_27_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_184_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_184_tmpvar_phold.bevi_int) {
bevt_183_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_183_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_183_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_186_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_186_tmpvar_phold.bevi_int) {
bevt_185_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_185_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_185_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
if (bevt_26_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_26_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_188_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_190_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_189_tmpvar_phold = bevt_190_tmpvar_phold.bem_heldGet_0();
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_189_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_187_tmpvar_phold);
bevt_191_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_191_tmpvar_phold.bem_nextDescendGet_0();
bevt_192_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_192_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 201 */
bevt_194_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
if (bevl_typename.bevi_int == bevt_194_tmpvar_phold.bevi_int) {
bevt_193_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_193_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_193_tmpvar_phold.bevi_bool) /* Line: 203 */ {
if (bevl_nextPeer == null) {
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_195_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 203 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 203 */
 else  /* Line: 203 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_29_tmpvar_anchor.bevi_bool) /* Line: 203 */ {
bevt_197_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_197_tmpvar_phold.bevi_int) {
bevt_196_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_196_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_196_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 203 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 203 */
 else  /* Line: 203 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_28_tmpvar_anchor.bevi_bool) /* Line: 203 */ {
bevt_198_tmpvar_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_198_tmpvar_phold);
bevt_200_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_202_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_201_tmpvar_phold = bevt_202_tmpvar_phold.bem_heldGet_0();
bevt_199_tmpvar_phold = bevt_200_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_201_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_199_tmpvar_phold);
bevt_203_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_203_tmpvar_phold.bem_nextDescendGet_0();
bevt_204_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_204_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 208 */
bevt_206_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
if (bevl_typename.bevi_int == bevt_206_tmpvar_phold.bevi_int) {
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_205_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_208_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_208_tmpvar_phold == null) {
bevt_207_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_207_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_207_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_211_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bem_typenameGet_0();
bevt_212_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
if (bevt_210_tmpvar_phold.bevi_int == bevt_212_tmpvar_phold.bevi_int) {
bevt_209_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_209_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_209_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 211 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 211 */
 else  /* Line: 211 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_30_tmpvar_anchor.bevi_bool) /* Line: 211 */ {
bevt_214_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_216_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bem_heldGet_0();
bevt_213_tmpvar_phold = bevt_214_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_215_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_213_tmpvar_phold);
bevt_217_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
beva_node.bem_typenameSet_1(bevt_217_tmpvar_phold);
bevt_218_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_218_tmpvar_phold.bem_nextDescendGet_0();
bevt_219_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_219_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 216 */
} /* Line: 211 */
bevt_221_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
if (bevl_typename.bevi_int == bevt_221_tmpvar_phold.bevi_int) {
bevt_220_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_220_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_220_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevt_223_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_223_tmpvar_phold == null) {
bevt_222_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_222_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_222_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_226_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bem_typenameGet_0();
bevt_227_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
if (bevt_225_tmpvar_phold.bevi_int == bevt_227_tmpvar_phold.bevi_int) {
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_224_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_31_tmpvar_anchor.bevi_bool) /* Line: 220 */ {
bevt_229_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_231_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_230_tmpvar_phold = bevt_231_tmpvar_phold.bem_heldGet_0();
bevt_228_tmpvar_phold = bevt_229_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_230_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_228_tmpvar_phold);
bevt_232_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
beva_node.bem_typenameSet_1(bevt_232_tmpvar_phold);
bevt_233_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_233_tmpvar_phold.bem_nextDescendGet_0();
bevt_234_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_234_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 225 */
} /* Line: 220 */
bevt_236_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
if (bevl_typename.bevi_int == bevt_236_tmpvar_phold.bevi_int) {
bevt_235_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_235_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_235_tmpvar_phold.bevi_bool) /* Line: 228 */ {
if (bevl_nextPeer == null) {
bevt_237_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_237_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_237_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_33_tmpvar_anchor.bevi_bool) /* Line: 228 */ {
bevt_239_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_239_tmpvar_phold.bevi_int) {
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_32_tmpvar_anchor.bevi_bool) /* Line: 228 */ {
bevt_240_tmpvar_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_240_tmpvar_phold);
bevt_242_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_244_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_243_tmpvar_phold = bevt_244_tmpvar_phold.bem_heldGet_0();
bevt_241_tmpvar_phold = bevt_242_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_243_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_241_tmpvar_phold);
bevt_245_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_245_tmpvar_phold.bem_nextDescendGet_0();
bevt_246_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_246_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 233 */
bevt_248_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
if (bevl_typename.bevi_int == bevt_248_tmpvar_phold.bevi_int) {
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_247_tmpvar_phold.bevi_bool) /* Line: 235 */ {
if (bevl_nextPeer == null) {
bevt_249_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_249_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_249_tmpvar_phold.bevi_bool) /* Line: 235 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_35_tmpvar_anchor.bevi_bool) /* Line: 235 */ {
bevt_251_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_251_tmpvar_phold.bevi_int) {
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_250_tmpvar_phold.bevi_bool) /* Line: 235 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_34_tmpvar_anchor.bevi_bool) /* Line: 235 */ {
bevt_252_tmpvar_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_252_tmpvar_phold);
bevt_254_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_256_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_255_tmpvar_phold = bevt_256_tmpvar_phold.bem_heldGet_0();
bevt_253_tmpvar_phold = bevt_254_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_255_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_253_tmpvar_phold);
bevt_257_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_257_tmpvar_phold.bem_nextDescendGet_0();
bevt_258_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_258_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 240 */
bevt_260_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
if (bevl_typename.bevi_int == bevt_260_tmpvar_phold.bevi_int) {
bevt_259_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_259_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_259_tmpvar_phold.bevi_bool) /* Line: 242 */ {
if (bevl_nextPeer == null) {
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_261_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_37_tmpvar_anchor.bevi_bool) /* Line: 242 */ {
bevt_263_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_263_tmpvar_phold.bevi_int) {
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_262_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_36_tmpvar_anchor.bevi_bool) /* Line: 242 */ {
bevt_266_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_265_tmpvar_phold = bevt_266_tmpvar_phold.bem_nextPeerGet_0();
if (bevt_265_tmpvar_phold == null) {
bevt_264_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_264_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_264_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_270_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bem_nextPeerGet_0();
bevt_268_tmpvar_phold = bevt_269_tmpvar_phold.bem_typenameGet_0();
bevt_271_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevt_268_tmpvar_phold.bevi_int == bevt_271_tmpvar_phold.bevi_int) {
bevt_267_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_267_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_267_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_38_tmpvar_anchor.bevi_bool) /* Line: 243 */ {
bevt_272_tmpvar_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_272_tmpvar_phold);
bevt_275_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_277_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_276_tmpvar_phold = bevt_277_tmpvar_phold.bem_heldGet_0();
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_276_tmpvar_phold);
bevt_280_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_279_tmpvar_phold = bevt_280_tmpvar_phold.bem_nextPeerGet_0();
bevt_278_tmpvar_phold = bevt_279_tmpvar_phold.bem_heldGet_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_278_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_273_tmpvar_phold);
bevt_282_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_281_tmpvar_phold = bevt_282_tmpvar_phold.bem_nextPeerGet_0();
bevl_toRet = bevt_281_tmpvar_phold.bem_nextDescendGet_0();
bevt_283_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_283_tmpvar_phold.bem_delayDelete_0();
bevt_285_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_284_tmpvar_phold = bevt_285_tmpvar_phold.bem_nextPeerGet_0();
bevt_284_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 249 */
bevt_286_tmpvar_phold = bevp_ntypes.bem_INCREMENTGet_0();
beva_node.bem_typenameSet_1(bevt_286_tmpvar_phold);
bevt_288_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_290_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_289_tmpvar_phold = bevt_290_tmpvar_phold.bem_heldGet_0();
bevt_287_tmpvar_phold = bevt_288_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_289_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_287_tmpvar_phold);
bevt_291_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_291_tmpvar_phold.bem_nextDescendGet_0();
bevt_292_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_292_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 255 */
bevt_294_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
if (bevl_typename.bevi_int == bevt_294_tmpvar_phold.bevi_int) {
bevt_293_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_293_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_293_tmpvar_phold.bevi_bool) /* Line: 257 */ {
if (bevl_nextPeer == null) {
bevt_295_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_295_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_295_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 257 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 257 */
 else  /* Line: 257 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_40_tmpvar_anchor.bevi_bool) /* Line: 257 */ {
bevt_297_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_297_tmpvar_phold.bevi_int) {
bevt_296_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_296_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_296_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 257 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 257 */
 else  /* Line: 257 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_39_tmpvar_anchor.bevi_bool) /* Line: 257 */ {
bevt_300_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_299_tmpvar_phold = bevt_300_tmpvar_phold.bem_nextPeerGet_0();
if (bevt_299_tmpvar_phold == null) {
bevt_298_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_298_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_298_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_304_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_303_tmpvar_phold = bevt_304_tmpvar_phold.bem_nextPeerGet_0();
bevt_302_tmpvar_phold = bevt_303_tmpvar_phold.bem_typenameGet_0();
bevt_305_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevt_302_tmpvar_phold.bevi_int == bevt_305_tmpvar_phold.bevi_int) {
bevt_301_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_301_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_301_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 258 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 258 */
 else  /* Line: 258 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_41_tmpvar_anchor.bevi_bool) /* Line: 258 */ {
bevt_306_tmpvar_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_306_tmpvar_phold);
bevt_309_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_311_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_310_tmpvar_phold = bevt_311_tmpvar_phold.bem_heldGet_0();
bevt_308_tmpvar_phold = bevt_309_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_310_tmpvar_phold);
bevt_314_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_313_tmpvar_phold = bevt_314_tmpvar_phold.bem_nextPeerGet_0();
bevt_312_tmpvar_phold = bevt_313_tmpvar_phold.bem_heldGet_0();
bevt_307_tmpvar_phold = bevt_308_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_312_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_307_tmpvar_phold);
bevt_316_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_315_tmpvar_phold = bevt_316_tmpvar_phold.bem_nextPeerGet_0();
bevl_toRet = bevt_315_tmpvar_phold.bem_nextDescendGet_0();
bevt_317_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_317_tmpvar_phold.bem_delayDelete_0();
bevt_319_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_318_tmpvar_phold = bevt_319_tmpvar_phold.bem_nextPeerGet_0();
bevt_318_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 264 */
bevt_320_tmpvar_phold = bevp_ntypes.bem_DECREMENTGet_0();
beva_node.bem_typenameSet_1(bevt_320_tmpvar_phold);
bevt_322_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_324_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_323_tmpvar_phold = bevt_324_tmpvar_phold.bem_heldGet_0();
bevt_321_tmpvar_phold = bevt_322_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_323_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_321_tmpvar_phold);
bevt_325_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_325_tmpvar_phold.bem_nextDescendGet_0();
bevt_326_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_326_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 270 */
bevt_328_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
if (bevl_typename.bevi_int == bevt_328_tmpvar_phold.bevi_int) {
bevt_327_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_327_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_327_tmpvar_phold.bevi_bool) /* Line: 272 */ {
if (bevl_nextPeer == null) {
bevt_329_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_329_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_329_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_43_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
bevt_331_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_331_tmpvar_phold.bevi_int) {
bevt_330_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_330_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_330_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_42_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
bevt_332_tmpvar_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_332_tmpvar_phold);
bevt_334_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_336_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_335_tmpvar_phold = bevt_336_tmpvar_phold.bem_heldGet_0();
bevt_333_tmpvar_phold = bevt_334_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_335_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_333_tmpvar_phold);
bevt_337_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_337_tmpvar_phold.bem_nextDescendGet_0();
bevt_338_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_338_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 277 */
bevt_340_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
if (bevl_typename.bevi_int == bevt_340_tmpvar_phold.bevi_int) {
bevt_339_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_339_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_339_tmpvar_phold.bevi_bool) /* Line: 279 */ {
if (bevl_nextPeer == null) {
bevt_341_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_341_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_341_tmpvar_phold.bevi_bool) /* Line: 279 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 279 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 279 */
 else  /* Line: 279 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_45_tmpvar_anchor.bevi_bool) /* Line: 279 */ {
bevt_343_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_343_tmpvar_phold.bevi_int) {
bevt_342_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_342_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_342_tmpvar_phold.bevi_bool) /* Line: 279 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 279 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 279 */
 else  /* Line: 279 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_44_tmpvar_anchor.bevi_bool) /* Line: 279 */ {
bevt_344_tmpvar_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_344_tmpvar_phold);
bevt_346_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_348_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_347_tmpvar_phold = bevt_348_tmpvar_phold.bem_heldGet_0();
bevt_345_tmpvar_phold = bevt_346_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_347_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_345_tmpvar_phold);
bevt_349_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_349_tmpvar_phold.bem_nextDescendGet_0();
bevt_350_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_350_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 284 */
bevt_352_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
if (bevl_typename.bevi_int == bevt_352_tmpvar_phold.bevi_int) {
bevt_351_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_351_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_351_tmpvar_phold.bevi_bool) /* Line: 286 */ {
if (bevl_nextPeer == null) {
bevt_353_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_353_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_353_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_47_tmpvar_anchor.bevi_bool) /* Line: 286 */ {
bevt_355_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_355_tmpvar_phold.bevi_int) {
bevt_354_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_354_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_354_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_46_tmpvar_anchor.bevi_bool) /* Line: 286 */ {
bevt_356_tmpvar_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_356_tmpvar_phold);
bevt_358_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_360_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_359_tmpvar_phold = bevt_360_tmpvar_phold.bem_heldGet_0();
bevt_357_tmpvar_phold = bevt_358_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_359_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_357_tmpvar_phold);
bevt_361_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_361_tmpvar_phold.bem_nextDescendGet_0();
bevt_362_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_362_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 291 */
bevt_364_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_typename.bevi_int == bevt_364_tmpvar_phold.bevi_int) {
bevt_363_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_363_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_363_tmpvar_phold.bevi_bool) /* Line: 293 */ {
if (bevl_nextPeer == null) {
bevt_365_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_365_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_365_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 293 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 293 */
 else  /* Line: 293 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_49_tmpvar_anchor.bevi_bool) /* Line: 293 */ {
bevt_367_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_367_tmpvar_phold.bevi_int) {
bevt_366_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_366_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_366_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 293 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 293 */
 else  /* Line: 293 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_48_tmpvar_anchor.bevi_bool) /* Line: 293 */ {
bevt_368_tmpvar_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_368_tmpvar_phold);
bevt_370_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_372_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_371_tmpvar_phold = bevt_372_tmpvar_phold.bem_heldGet_0();
bevt_369_tmpvar_phold = bevt_370_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_371_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_369_tmpvar_phold);
bevt_373_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_373_tmpvar_phold.bem_nextDescendGet_0();
bevt_374_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_374_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 298 */
bevt_376_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
if (bevl_typename.bevi_int == bevt_376_tmpvar_phold.bevi_int) {
bevt_375_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_375_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_375_tmpvar_phold.bevi_bool) /* Line: 300 */ {
if (bevl_nextPeer == null) {
bevt_377_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_377_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_377_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_51_tmpvar_anchor.bevi_bool) /* Line: 300 */ {
bevt_379_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_379_tmpvar_phold.bevi_int) {
bevt_378_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_378_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_378_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_50_tmpvar_anchor.bevi_bool) /* Line: 300 */ {
bevt_380_tmpvar_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_380_tmpvar_phold);
bevt_382_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_384_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_383_tmpvar_phold = bevt_384_tmpvar_phold.bem_heldGet_0();
bevt_381_tmpvar_phold = bevt_382_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_383_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_381_tmpvar_phold);
bevt_385_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_385_tmpvar_phold.bem_nextDescendGet_0();
bevt_386_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_386_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 305 */
bevt_388_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
if (bevl_typename.bevi_int == bevt_388_tmpvar_phold.bevi_int) {
bevt_387_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_387_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_387_tmpvar_phold.bevi_bool) /* Line: 307 */ {
if (bevl_nextPeer == null) {
bevt_389_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_389_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_389_tmpvar_phold.bevi_bool) /* Line: 307 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 307 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 307 */
 else  /* Line: 307 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_53_tmpvar_anchor.bevi_bool) /* Line: 307 */ {
bevt_391_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_391_tmpvar_phold.bevi_int) {
bevt_390_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_390_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_390_tmpvar_phold.bevi_bool) /* Line: 307 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 307 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 307 */
 else  /* Line: 307 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_52_tmpvar_anchor.bevi_bool) /* Line: 307 */ {
bevt_392_tmpvar_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_392_tmpvar_phold);
bevt_394_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_396_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_395_tmpvar_phold = bevt_396_tmpvar_phold.bem_heldGet_0();
bevt_393_tmpvar_phold = bevt_394_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_395_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_393_tmpvar_phold);
bevt_397_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_397_tmpvar_phold.bem_nextDescendGet_0();
bevt_398_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_398_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 312 */
bevt_400_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
if (bevl_typename.bevi_int == bevt_400_tmpvar_phold.bevi_int) {
bevt_399_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_399_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_399_tmpvar_phold.bevi_bool) /* Line: 314 */ {
if (bevl_nextPeer == null) {
bevt_401_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_401_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_401_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
 else  /* Line: 314 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_55_tmpvar_anchor.bevi_bool) /* Line: 314 */ {
bevt_403_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_403_tmpvar_phold.bevi_int) {
bevt_402_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_402_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_402_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
 else  /* Line: 314 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_54_tmpvar_anchor.bevi_bool) /* Line: 314 */ {
bevt_404_tmpvar_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_404_tmpvar_phold);
bevt_406_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_408_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_407_tmpvar_phold = bevt_408_tmpvar_phold.bem_heldGet_0();
bevt_405_tmpvar_phold = bevt_406_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_407_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_405_tmpvar_phold);
bevt_409_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_409_tmpvar_phold.bem_nextDescendGet_0();
bevt_410_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_410_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 319 */
bevt_412_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevl_typename.bevi_int == bevt_412_tmpvar_phold.bevi_int) {
bevt_411_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_411_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_411_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_414_tmpvar_phold = bevp_ntypes.bem_NEWLINEGet_0();
if (bevl_typename.bevi_int == bevt_414_tmpvar_phold.bevi_int) {
bevt_413_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_413_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_413_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 321 */
if (bevt_56_tmpvar_anchor.bevi_bool) /* Line: 321 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 324 */
bevt_415_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_415_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nestCommentGet_0() throws Throwable {
return bevp_nestComment;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nestCommentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nestComment = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_strqCntGet_0() throws Throwable {
return bevp_strqCnt;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strqCntSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_strqCnt = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_goingStrGet_0() throws Throwable {
return bevp_goingStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_goingStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_goingStr = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_quoteTypeGet_0() throws Throwable {
return bevp_quoteType;
} /*method end*/
public BEC_2_6_6_SystemObject bem_quoteTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_quoteType = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inLcGet_0() throws Throwable {
return bevp_inLc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inLcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inLc = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inSpaceGet_0() throws Throwable {
return bevp_inSpace;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inSpace = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inNlGet_0() throws Throwable {
return bevp_inNl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inNlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inNl = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inStrGet_0() throws Throwable {
return bevp_inStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inStr = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 30, 32, 41, 42, 43, 44, 53, 54, 55, 55, 56, 60, 60, 60, 60, 60, 0, 0, 0, 60, 60, 60, 0, 0, 0, 60, 0, 0, 0, 62, 63, 63, 64, 64, 65, 66, 68, 68, 68, 68, 68, 0, 0, 0, 68, 68, 68, 0, 0, 0, 68, 0, 0, 0, 70, 71, 71, 72, 72, 73, 74, 76, 76, 76, 77, 78, 79, 81, 81, 0, 0, 0, 81, 81, 81, 0, 81, 81, 81, 0, 0, 0, 0, 0, 82, 83, 84, 85, 85, 85, 85, 85, 0, 0, 0, 86, 87, 88, 90, 90, 90, 91, 92, 92, 93, 93, 94, 94, 96, 97, 98, 98, 99, 99, 99, 101, 101, 103, 103, 106, 108, 0, 0, 0, 109, 109, 109, 109, 109, 109, 109, 0, 0, 0, 110, 111, 112, 113, 113, 113, 113, 113, 113, 0, 0, 0, 114, 115, 116, 118, 118, 119, 119, 119, 119, 118, 121, 121, 121, 121, 121, 121, 121, 0, 0, 0, 121, 121, 121, 0, 0, 0, 122, 123, 123, 123, 123, 124, 126, 127, 127, 128, 129, 130, 131, 131, 131, 131, 131, 0, 0, 0, 132, 133, 134, 136, 137, 138, 139, 140, 142, 142, 143, 143, 143, 143, 142, 146, 148, 148, 148, 148, 149, 150, 151, 154, 154, 154, 154, 154, 0, 0, 0, 154, 154, 154, 0, 0, 0, 154, 0, 0, 0, 155, 155, 156, 157, 157, 158, 159, 162, 163, 164, 164, 164, 164, 165, 166, 167, 169, 171, 171, 171, 171, 171, 0, 0, 0, 171, 171, 171, 0, 0, 0, 172, 172, 172, 173, 174, 174, 174, 174, 174, 174, 0, 0, 0, 175, 177, 180, 180, 0, 180, 180, 180, 180, 0, 0, 0, 180, 180, 180, 180, 0, 0, 0, 180, 180, 180, 0, 0, 183, 183, 183, 183, 183, 183, 184, 185, 186, 189, 189, 189, 189, 189, 0, 0, 0, 189, 189, 189, 0, 0, 0, 190, 190, 191, 191, 191, 191, 191, 192, 192, 193, 193, 194, 196, 196, 196, 196, 196, 0, 0, 0, 196, 196, 196, 0, 196, 196, 196, 0, 0, 0, 0, 0, 198, 198, 198, 198, 198, 199, 199, 200, 200, 201, 203, 203, 203, 203, 203, 0, 0, 0, 203, 203, 203, 0, 0, 0, 204, 204, 205, 205, 205, 205, 205, 206, 206, 207, 207, 208, 210, 210, 210, 211, 211, 211, 211, 211, 211, 211, 211, 0, 0, 0, 212, 212, 212, 212, 212, 213, 213, 214, 214, 215, 215, 216, 219, 219, 219, 220, 220, 220, 220, 220, 220, 220, 220, 0, 0, 0, 221, 221, 221, 221, 221, 222, 222, 223, 223, 224, 224, 225, 228, 228, 228, 228, 228, 0, 0, 0, 228, 228, 228, 0, 0, 0, 229, 229, 230, 230, 230, 230, 230, 231, 231, 232, 232, 233, 235, 235, 235, 235, 235, 0, 0, 0, 235, 235, 235, 0, 0, 0, 236, 236, 237, 237, 237, 237, 237, 238, 238, 239, 239, 240, 242, 242, 242, 242, 242, 0, 0, 0, 242, 242, 242, 0, 0, 0, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 0, 0, 0, 244, 244, 245, 245, 245, 245, 245, 245, 245, 245, 245, 246, 246, 246, 247, 247, 248, 248, 248, 249, 251, 251, 252, 252, 252, 252, 252, 253, 253, 254, 254, 255, 257, 257, 257, 257, 257, 0, 0, 0, 257, 257, 257, 0, 0, 0, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 0, 0, 0, 259, 259, 260, 260, 260, 260, 260, 260, 260, 260, 260, 261, 261, 261, 262, 262, 263, 263, 263, 264, 266, 266, 267, 267, 267, 267, 267, 268, 268, 269, 269, 270, 272, 272, 272, 272, 272, 0, 0, 0, 272, 272, 272, 0, 0, 0, 273, 273, 274, 274, 274, 274, 274, 275, 275, 276, 276, 277, 279, 279, 279, 279, 279, 0, 0, 0, 279, 279, 279, 0, 0, 0, 280, 280, 281, 281, 281, 281, 281, 282, 282, 283, 283, 284, 286, 286, 286, 286, 286, 0, 0, 0, 286, 286, 286, 0, 0, 0, 287, 287, 288, 288, 288, 288, 288, 289, 289, 290, 290, 291, 293, 293, 293, 293, 293, 0, 0, 0, 293, 293, 293, 0, 0, 0, 294, 294, 295, 295, 295, 295, 295, 296, 296, 297, 297, 298, 300, 300, 300, 300, 300, 0, 0, 0, 300, 300, 300, 0, 0, 0, 301, 301, 302, 302, 302, 302, 302, 303, 303, 304, 304, 305, 307, 307, 307, 307, 307, 0, 0, 0, 307, 307, 307, 0, 0, 0, 308, 308, 309, 309, 309, 309, 309, 310, 310, 311, 311, 312, 314, 314, 314, 314, 314, 0, 0, 0, 314, 314, 314, 0, 0, 0, 315, 315, 316, 316, 316, 316, 316, 317, 317, 318, 318, 319, 321, 321, 321, 0, 321, 321, 321, 0, 0, 322, 323, 324, 326, 326, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 25, 26, 27, 28, 29, 30, 460, 461, 462, 467, 468, 470, 471, 476, 477, 482, 483, 486, 490, 493, 494, 499, 500, 503, 507, 510, 512, 515, 519, 522, 523, 524, 525, 526, 527, 528, 530, 531, 536, 537, 542, 543, 546, 550, 553, 554, 559, 560, 563, 567, 570, 572, 575, 579, 582, 583, 584, 585, 586, 587, 588, 590, 591, 596, 597, 598, 599, 601, 603, 605, 608, 612, 615, 616, 621, 622, 625, 626, 631, 632, 635, 639, 642, 646, 649, 650, 651, 654, 659, 660, 661, 666, 667, 670, 674, 677, 678, 679, 685, 686, 691, 692, 693, 694, 695, 696, 697, 698, 701, 702, 703, 704, 705, 706, 711, 712, 713, 716, 717, 720, 723, 725, 728, 732, 735, 736, 737, 742, 743, 744, 749, 750, 753, 757, 760, 761, 762, 765, 770, 771, 772, 773, 778, 779, 782, 786, 789, 790, 791, 797, 800, 802, 803, 804, 805, 806, 812, 817, 818, 819, 820, 821, 826, 827, 830, 834, 837, 838, 843, 844, 847, 851, 854, 855, 856, 857, 858, 859, 861, 864, 869, 870, 871, 872, 875, 880, 881, 882, 887, 888, 891, 895, 898, 899, 900, 906, 908, 909, 910, 911, 914, 917, 919, 920, 921, 922, 923, 930, 933, 934, 935, 936, 937, 938, 939, 943, 944, 949, 950, 955, 956, 959, 963, 966, 967, 972, 973, 976, 980, 983, 985, 988, 992, 995, 996, 997, 998, 999, 1000, 1001, 1004, 1005, 1006, 1007, 1008, 1013, 1014, 1015, 1016, 1018, 1020, 1021, 1026, 1027, 1032, 1033, 1036, 1040, 1043, 1044, 1049, 1050, 1053, 1057, 1060, 1061, 1066, 1067, 1070, 1075, 1076, 1077, 1078, 1083, 1084, 1087, 1091, 1094, 1100, 1102, 1107, 1108, 1111, 1112, 1113, 1118, 1119, 1122, 1126, 1129, 1130, 1131, 1136, 1137, 1140, 1144, 1147, 1148, 1149, 1151, 1154, 1158, 1159, 1160, 1161, 1162, 1163, 1164, 1165, 1166, 1169, 1170, 1175, 1176, 1181, 1182, 1185, 1189, 1192, 1193, 1198, 1199, 1202, 1206, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1222, 1223, 1228, 1229, 1234, 1235, 1238, 1242, 1245, 1246, 1251, 1252, 1255, 1256, 1261, 1262, 1265, 1269, 1272, 1276, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1290, 1291, 1296, 1297, 1302, 1303, 1306, 1310, 1313, 1314, 1319, 1320, 1323, 1327, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1343, 1344, 1349, 1350, 1351, 1356, 1357, 1358, 1359, 1360, 1365, 1366, 1369, 1373, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1387, 1390, 1391, 1396, 1397, 1398, 1403, 1404, 1405, 1406, 1407, 1412, 1413, 1416, 1420, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1437, 1438, 1443, 1444, 1449, 1450, 1453, 1457, 1460, 1461, 1466, 1467, 1470, 1474, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1490, 1491, 1496, 1497, 1502, 1503, 1506, 1510, 1513, 1514, 1519, 1520, 1523, 1527, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1543, 1544, 1549, 1550, 1555, 1556, 1559, 1563, 1566, 1567, 1572, 1573, 1576, 1580, 1583, 1584, 1585, 1590, 1591, 1592, 1593, 1594, 1595, 1600, 1601, 1604, 1608, 1611, 1612, 1613, 1614, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1645, 1646, 1651, 1652, 1657, 1658, 1661, 1665, 1668, 1669, 1674, 1675, 1678, 1682, 1685, 1686, 1687, 1692, 1693, 1694, 1695, 1696, 1697, 1702, 1703, 1706, 1710, 1713, 1714, 1715, 1716, 1717, 1718, 1719, 1720, 1721, 1722, 1723, 1724, 1725, 1726, 1727, 1728, 1729, 1730, 1731, 1732, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1747, 1748, 1753, 1754, 1759, 1760, 1763, 1767, 1770, 1771, 1776, 1777, 1780, 1784, 1787, 1788, 1789, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1797, 1798, 1800, 1801, 1806, 1807, 1812, 1813, 1816, 1820, 1823, 1824, 1829, 1830, 1833, 1837, 1840, 1841, 1842, 1843, 1844, 1845, 1846, 1847, 1848, 1849, 1850, 1851, 1853, 1854, 1859, 1860, 1865, 1866, 1869, 1873, 1876, 1877, 1882, 1883, 1886, 1890, 1893, 1894, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1902, 1903, 1904, 1906, 1907, 1912, 1913, 1918, 1919, 1922, 1926, 1929, 1930, 1935, 1936, 1939, 1943, 1946, 1947, 1948, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1956, 1957, 1959, 1960, 1965, 1966, 1971, 1972, 1975, 1979, 1982, 1983, 1988, 1989, 1992, 1996, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2012, 2013, 2018, 2019, 2024, 2025, 2028, 2032, 2035, 2036, 2041, 2042, 2045, 2049, 2052, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2060, 2061, 2062, 2063, 2065, 2066, 2071, 2072, 2077, 2078, 2081, 2085, 2088, 2089, 2094, 2095, 2098, 2102, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2112, 2113, 2114, 2115, 2116, 2118, 2119, 2124, 2125, 2128, 2129, 2134, 2135, 2138, 2142, 2143, 2144, 2146, 2147, 2150, 2153, 2157, 2160, 2164, 2167, 2171, 2174, 2178, 2181, 2185, 2188, 2192, 2195, 2199, 2202, 2206, 2209};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 24 24
assign 1 30 25
new 0 30 25
assign 1 32 26
new 0 32 26
assign 1 41 27
new 0 41 27
assign 1 42 28
new 0 42 28
assign 1 43 29
new 0 43 29
assign 1 44 30
new 0 44 30
assign 1 53 460
typenameGet 0 53 460
assign 1 54 461
nextPeerGet 0 54 461
assign 1 55 462
def 1 55 467
assign 1 56 468
typenameGet 0 56 468
assign 1 60 470
DIVIDEGet 0 60 470
assign 1 60 471
equals 1 60 476
assign 1 60 477
def 1 60 482
assign 1 0 483
assign 1 0 486
assign 1 0 490
assign 1 60 493
MULTIPLYGet 0 60 493
assign 1 60 494
equals 1 60 499
assign 1 0 500
assign 1 0 503
assign 1 0 507
assign 1 60 510
not 0 60 510
assign 1 0 512
assign 1 0 515
assign 1 0 519
assign 1 62 522
increment 0 62 522
assign 1 63 523
nextPeerGet 0 63 523
assign 1 63 524
nextDescendGet 0 63 524
assign 1 64 525
nextPeerGet 0 64 525
delayDelete 0 64 526
delayDelete 0 65 527
return 1 66 528
assign 1 68 530
MULTIPLYGet 0 68 530
assign 1 68 531
equals 1 68 536
assign 1 68 537
def 1 68 542
assign 1 0 543
assign 1 0 546
assign 1 0 550
assign 1 68 553
DIVIDEGet 0 68 553
assign 1 68 554
equals 1 68 559
assign 1 0 560
assign 1 0 563
assign 1 0 567
assign 1 68 570
not 0 68 570
assign 1 0 572
assign 1 0 575
assign 1 0 579
assign 1 70 582
decrement 0 70 582
assign 1 71 583
nextPeerGet 0 71 583
assign 1 71 584
nextDescendGet 0 71 584
assign 1 72 585
nextPeerGet 0 72 585
delayDelete 0 72 586
delayDelete 0 73 587
return 1 74 588
assign 1 76 590
new 0 76 590
assign 1 76 591
greater 1 76 596
assign 1 77 597
nextDescendGet 0 77 597
delayDelete 0 78 598
return 1 79 599
assign 1 81 601
not 0 81 601
assign 1 81 603
not 0 81 603
assign 1 0 605
assign 1 0 608
assign 1 0 612
assign 1 81 615
STRQGet 0 81 615
assign 1 81 616
equals 1 81 621
assign 1 0 622
assign 1 81 625
WSTRQGet 0 81 625
assign 1 81 626
equals 1 81 631
assign 1 0 632
assign 1 0 635
assign 1 0 639
assign 1 0 642
assign 1 0 646
assign 1 82 649
nextPeerGet 0 82 649
assign 1 83 650
new 0 83 650
assign 1 84 651
typenameGet 0 84 651
assign 1 85 654
def 1 85 659
assign 1 85 660
typenameGet 0 85 660
assign 1 85 661
equals 1 85 666
assign 1 0 667
assign 1 0 670
assign 1 0 674
assign 1 86 677
increment 0 86 677
delayDelete 0 87 678
assign 1 88 679
nextPeerGet 0 88 679
assign 1 90 685
new 0 90 685
assign 1 90 686
equals 1 90 691
assign 1 91 692
new 0 91 692
assign 1 92 693
new 0 92 693
heldSet 1 92 694
assign 1 93 695
STRINGLGet 0 93 695
typenameSet 1 93 696
assign 1 94 697
new 0 94 697
typeDetailSet 1 94 698
assign 1 96 701
new 0 96 701
assign 1 97 702
assign 1 98 703
new 0 98 703
heldSet 1 98 704
assign 1 99 705
WSTRQGet 0 99 705
assign 1 99 706
equals 1 99 711
assign 1 101 712
WSTRINGLGet 0 101 712
typenameSet 1 101 713
assign 1 103 716
STRINGLGet 0 103 716
typenameSet 1 103 717
return 1 106 720
assign 1 108 723
not 0 108 723
assign 1 0 725
assign 1 0 728
assign 1 0 732
assign 1 109 735
typenameGet 0 109 735
assign 1 109 736
STRINGLGet 0 109 736
assign 1 109 737
equals 1 109 742
assign 1 109 743
FSLASHGet 0 109 743
assign 1 109 744
equals 1 109 749
assign 1 0 750
assign 1 0 753
assign 1 0 757
delayDelete 0 110 760
assign 1 111 761
nextPeerGet 0 111 761
assign 1 112 762
new 0 112 762
assign 1 113 765
def 1 113 770
assign 1 113 771
typenameGet 0 113 771
assign 1 113 772
FSLASHGet 0 113 772
assign 1 113 773
equals 1 113 778
assign 1 0 779
assign 1 0 782
assign 1 0 786
assign 1 114 789
increment 0 114 789
delayDelete 0 115 790
assign 1 116 791
nextPeerGet 0 116 791
assign 1 118 797
new 0 118 797
assign 1 118 800
lesser 1 118 800
assign 1 119 802
heldGet 0 119 802
assign 1 119 803
heldGet 0 119 803
assign 1 119 804
add 1 119 804
heldSet 1 119 805
assign 1 118 806
increment 0 118 806
assign 1 121 812
def 1 121 817
assign 1 121 818
new 0 121 818
assign 1 121 819
modulus 1 121 819
assign 1 121 820
new 0 121 820
assign 1 121 821
equals 1 121 826
assign 1 0 827
assign 1 0 830
assign 1 0 834
assign 1 121 837
typenameGet 0 121 837
assign 1 121 838
equals 1 121 843
assign 1 0 844
assign 1 0 847
assign 1 0 851
delayDelete 0 122 854
assign 1 123 855
heldGet 0 123 855
assign 1 123 856
heldGet 0 123 856
assign 1 123 857
add 1 123 857
heldSet 1 123 858
assign 1 124 859
nextDescendGet 0 124 859
return 1 126 861
assign 1 127 864
equals 1 127 869
delayDelete 0 128 870
assign 1 129 871
nextPeerGet 0 129 871
assign 1 130 872
new 0 130 872
assign 1 131 875
def 1 131 880
assign 1 131 881
typenameGet 0 131 881
assign 1 131 882
equals 1 131 887
assign 1 0 888
assign 1 0 891
assign 1 0 895
assign 1 132 898
increment 0 132 898
delayDelete 0 133 899
assign 1 134 900
nextPeerGet 0 134 900
assign 1 136 906
equals 1 136 906
typeDetailSet 1 137 908
assign 1 138 909
new 0 138 909
assign 1 139 910
assign 1 140 911
new 0 140 911
assign 1 142 914
new 0 142 914
assign 1 142 917
lesser 1 142 917
assign 1 143 919
heldGet 0 143 919
assign 1 143 920
heldGet 0 143 920
assign 1 143 921
add 1 143 921
heldSet 1 143 922
assign 1 142 923
increment 0 142 923
return 1 146 930
assign 1 148 933
heldGet 0 148 933
assign 1 148 934
heldGet 0 148 934
assign 1 148 935
add 1 148 935
heldSet 1 148 936
assign 1 149 937
nextDescendGet 0 149 937
delayDelete 0 150 938
return 1 151 939
assign 1 154 943
DIVIDEGet 0 154 943
assign 1 154 944
equals 1 154 949
assign 1 154 950
def 1 154 955
assign 1 0 956
assign 1 0 959
assign 1 0 963
assign 1 154 966
DIVIDEGet 0 154 966
assign 1 154 967
equals 1 154 972
assign 1 0 973
assign 1 0 976
assign 1 0 980
assign 1 154 983
not 0 154 983
assign 1 0 985
assign 1 0 988
assign 1 0 992
assign 1 155 995
nextPeerGet 0 155 995
assign 1 155 996
nextDescendGet 0 155 996
assign 1 156 997
new 0 156 997
assign 1 157 998
nextPeerGet 0 157 998
delayDelete 0 157 999
delayDelete 0 158 1000
return 1 159 1001
assign 1 162 1004
nextDescendGet 0 162 1004
delayDelete 0 163 1005
assign 1 164 1006
typenameGet 0 164 1006
assign 1 164 1007
NEWLINEGet 0 164 1007
assign 1 164 1008
equals 1 164 1013
assign 1 165 1014
new 0 165 1014
delayDelete 0 166 1015
assign 1 167 1016
nextDescendGet 0 167 1016
return 1 169 1018
assign 1 171 1020
SUBTRACTGet 0 171 1020
assign 1 171 1021
equals 1 171 1026
assign 1 171 1027
def 1 171 1032
assign 1 0 1033
assign 1 0 1036
assign 1 0 1040
assign 1 171 1043
INTLGet 0 171 1043
assign 1 171 1044
equals 1 171 1049
assign 1 0 1050
assign 1 0 1053
assign 1 0 1057
assign 1 172 1060
priorPeerGet 0 172 1060
assign 1 172 1061
def 1 172 1066
assign 1 173 1067
priorPeerGet 0 173 1067
assign 1 174 1070
def 1 174 1075
assign 1 174 1076
typenameGet 0 174 1076
assign 1 174 1077
SPACEGet 0 174 1077
assign 1 174 1078
equals 1 174 1083
assign 1 0 1084
assign 1 0 1087
assign 1 0 1091
assign 1 175 1094
priorPeerGet 0 175 1094
assign 1 177 1100
assign 1 180 1102
undef 1 180 1107
assign 1 0 1108
assign 1 180 1111
typenameGet 0 180 1111
assign 1 180 1112
COMMAGet 0 180 1112
assign 1 180 1113
equals 1 180 1118
assign 1 0 1119
assign 1 0 1122
assign 1 0 1126
assign 1 180 1129
typenameGet 0 180 1129
assign 1 180 1130
PARENSGet 0 180 1130
assign 1 180 1131
equals 1 180 1136
assign 1 0 1137
assign 1 0 1140
assign 1 0 1144
assign 1 180 1147
operGet 0 180 1147
assign 1 180 1148
typenameGet 0 180 1148
assign 1 180 1149
has 1 180 1149
assign 1 0 1151
assign 1 0 1154
assign 1 183 1158
nextPeerGet 0 183 1158
assign 1 183 1159
new 0 183 1159
assign 1 183 1160
nextPeerGet 0 183 1160
assign 1 183 1161
heldGet 0 183 1161
assign 1 183 1162
add 1 183 1162
heldSet 1 183 1163
assign 1 184 1164
nextDescendGet 0 184 1164
delayDelete 0 185 1165
return 1 186 1166
assign 1 189 1169
ASSIGNGet 0 189 1169
assign 1 189 1170
equals 1 189 1175
assign 1 189 1176
def 1 189 1181
assign 1 0 1182
assign 1 0 1185
assign 1 0 1189
assign 1 189 1192
ASSIGNGet 0 189 1192
assign 1 189 1193
equals 1 189 1198
assign 1 0 1199
assign 1 0 1202
assign 1 0 1206
assign 1 190 1209
EQUALSGet 0 190 1209
typenameSet 1 190 1210
assign 1 191 1211
heldGet 0 191 1211
assign 1 191 1212
nextPeerGet 0 191 1212
assign 1 191 1213
heldGet 0 191 1213
assign 1 191 1214
add 1 191 1214
heldSet 1 191 1215
assign 1 192 1216
nextPeerGet 0 192 1216
assign 1 192 1217
nextDescendGet 0 192 1217
assign 1 193 1218
nextPeerGet 0 193 1218
delayDelete 0 193 1219
return 1 194 1220
assign 1 196 1222
ASSIGNGet 0 196 1222
assign 1 196 1223
equals 1 196 1228
assign 1 196 1229
def 1 196 1234
assign 1 0 1235
assign 1 0 1238
assign 1 0 1242
assign 1 196 1245
ONCEGet 0 196 1245
assign 1 196 1246
equals 1 196 1251
assign 1 0 1252
assign 1 196 1255
MANYGet 0 196 1255
assign 1 196 1256
equals 1 196 1261
assign 1 0 1262
assign 1 0 1265
assign 1 0 1269
assign 1 0 1272
assign 1 0 1276
assign 1 198 1279
heldGet 0 198 1279
assign 1 198 1280
nextPeerGet 0 198 1280
assign 1 198 1281
heldGet 0 198 1281
assign 1 198 1282
add 1 198 1282
heldSet 1 198 1283
assign 1 199 1284
nextPeerGet 0 199 1284
assign 1 199 1285
nextDescendGet 0 199 1285
assign 1 200 1286
nextPeerGet 0 200 1286
delayDelete 0 200 1287
return 1 201 1288
assign 1 203 1290
NOTGet 0 203 1290
assign 1 203 1291
equals 1 203 1296
assign 1 203 1297
def 1 203 1302
assign 1 0 1303
assign 1 0 1306
assign 1 0 1310
assign 1 203 1313
ASSIGNGet 0 203 1313
assign 1 203 1314
equals 1 203 1319
assign 1 0 1320
assign 1 0 1323
assign 1 0 1327
assign 1 204 1330
NOT_EQUALSGet 0 204 1330
typenameSet 1 204 1331
assign 1 205 1332
heldGet 0 205 1332
assign 1 205 1333
nextPeerGet 0 205 1333
assign 1 205 1334
heldGet 0 205 1334
assign 1 205 1335
add 1 205 1335
heldSet 1 205 1336
assign 1 206 1337
nextPeerGet 0 206 1337
assign 1 206 1338
nextDescendGet 0 206 1338
assign 1 207 1339
nextPeerGet 0 207 1339
delayDelete 0 207 1340
return 1 208 1341
assign 1 210 1343
ORGet 0 210 1343
assign 1 210 1344
equals 1 210 1349
assign 1 211 1350
nextPeerGet 0 211 1350
assign 1 211 1351
def 1 211 1356
assign 1 211 1357
nextPeerGet 0 211 1357
assign 1 211 1358
typenameGet 0 211 1358
assign 1 211 1359
ORGet 0 211 1359
assign 1 211 1360
equals 1 211 1365
assign 1 0 1366
assign 1 0 1369
assign 1 0 1373
assign 1 212 1376
heldGet 0 212 1376
assign 1 212 1377
nextPeerGet 0 212 1377
assign 1 212 1378
heldGet 0 212 1378
assign 1 212 1379
add 1 212 1379
heldSet 1 212 1380
assign 1 213 1381
LOGICAL_ORGet 0 213 1381
typenameSet 1 213 1382
assign 1 214 1383
nextPeerGet 0 214 1383
assign 1 214 1384
nextDescendGet 0 214 1384
assign 1 215 1385
nextPeerGet 0 215 1385
delayDelete 0 215 1386
return 1 216 1387
assign 1 219 1390
ANDGet 0 219 1390
assign 1 219 1391
equals 1 219 1396
assign 1 220 1397
nextPeerGet 0 220 1397
assign 1 220 1398
def 1 220 1403
assign 1 220 1404
nextPeerGet 0 220 1404
assign 1 220 1405
typenameGet 0 220 1405
assign 1 220 1406
ANDGet 0 220 1406
assign 1 220 1407
equals 1 220 1412
assign 1 0 1413
assign 1 0 1416
assign 1 0 1420
assign 1 221 1423
heldGet 0 221 1423
assign 1 221 1424
nextPeerGet 0 221 1424
assign 1 221 1425
heldGet 0 221 1425
assign 1 221 1426
add 1 221 1426
heldSet 1 221 1427
assign 1 222 1428
LOGICAL_ANDGet 0 222 1428
typenameSet 1 222 1429
assign 1 223 1430
nextPeerGet 0 223 1430
assign 1 223 1431
nextDescendGet 0 223 1431
assign 1 224 1432
nextPeerGet 0 224 1432
delayDelete 0 224 1433
return 1 225 1434
assign 1 228 1437
GREATERGet 0 228 1437
assign 1 228 1438
equals 1 228 1443
assign 1 228 1444
def 1 228 1449
assign 1 0 1450
assign 1 0 1453
assign 1 0 1457
assign 1 228 1460
ASSIGNGet 0 228 1460
assign 1 228 1461
equals 1 228 1466
assign 1 0 1467
assign 1 0 1470
assign 1 0 1474
assign 1 229 1477
GREATER_EQUALSGet 0 229 1477
typenameSet 1 229 1478
assign 1 230 1479
heldGet 0 230 1479
assign 1 230 1480
nextPeerGet 0 230 1480
assign 1 230 1481
heldGet 0 230 1481
assign 1 230 1482
add 1 230 1482
heldSet 1 230 1483
assign 1 231 1484
nextPeerGet 0 231 1484
assign 1 231 1485
nextDescendGet 0 231 1485
assign 1 232 1486
nextPeerGet 0 232 1486
delayDelete 0 232 1487
return 1 233 1488
assign 1 235 1490
LESSERGet 0 235 1490
assign 1 235 1491
equals 1 235 1496
assign 1 235 1497
def 1 235 1502
assign 1 0 1503
assign 1 0 1506
assign 1 0 1510
assign 1 235 1513
ASSIGNGet 0 235 1513
assign 1 235 1514
equals 1 235 1519
assign 1 0 1520
assign 1 0 1523
assign 1 0 1527
assign 1 236 1530
LESSER_EQUALSGet 0 236 1530
typenameSet 1 236 1531
assign 1 237 1532
heldGet 0 237 1532
assign 1 237 1533
nextPeerGet 0 237 1533
assign 1 237 1534
heldGet 0 237 1534
assign 1 237 1535
add 1 237 1535
heldSet 1 237 1536
assign 1 238 1537
nextPeerGet 0 238 1537
assign 1 238 1538
nextDescendGet 0 238 1538
assign 1 239 1539
nextPeerGet 0 239 1539
delayDelete 0 239 1540
return 1 240 1541
assign 1 242 1543
ADDGet 0 242 1543
assign 1 242 1544
equals 1 242 1549
assign 1 242 1550
def 1 242 1555
assign 1 0 1556
assign 1 0 1559
assign 1 0 1563
assign 1 242 1566
ADDGet 0 242 1566
assign 1 242 1567
equals 1 242 1572
assign 1 0 1573
assign 1 0 1576
assign 1 0 1580
assign 1 243 1583
nextPeerGet 0 243 1583
assign 1 243 1584
nextPeerGet 0 243 1584
assign 1 243 1585
def 1 243 1590
assign 1 243 1591
nextPeerGet 0 243 1591
assign 1 243 1592
nextPeerGet 0 243 1592
assign 1 243 1593
typenameGet 0 243 1593
assign 1 243 1594
ASSIGNGet 0 243 1594
assign 1 243 1595
equals 1 243 1600
assign 1 0 1601
assign 1 0 1604
assign 1 0 1608
assign 1 244 1611
INCREMENT_ASSIGNGet 0 244 1611
typenameSet 1 244 1612
assign 1 245 1613
heldGet 0 245 1613
assign 1 245 1614
nextPeerGet 0 245 1614
assign 1 245 1615
heldGet 0 245 1615
assign 1 245 1616
add 1 245 1616
assign 1 245 1617
nextPeerGet 0 245 1617
assign 1 245 1618
nextPeerGet 0 245 1618
assign 1 245 1619
heldGet 0 245 1619
assign 1 245 1620
add 1 245 1620
heldSet 1 245 1621
assign 1 246 1622
nextPeerGet 0 246 1622
assign 1 246 1623
nextPeerGet 0 246 1623
assign 1 246 1624
nextDescendGet 0 246 1624
assign 1 247 1625
nextPeerGet 0 247 1625
delayDelete 0 247 1626
assign 1 248 1627
nextPeerGet 0 248 1627
assign 1 248 1628
nextPeerGet 0 248 1628
delayDelete 0 248 1629
return 1 249 1630
assign 1 251 1632
INCREMENTGet 0 251 1632
typenameSet 1 251 1633
assign 1 252 1634
heldGet 0 252 1634
assign 1 252 1635
nextPeerGet 0 252 1635
assign 1 252 1636
heldGet 0 252 1636
assign 1 252 1637
add 1 252 1637
heldSet 1 252 1638
assign 1 253 1639
nextPeerGet 0 253 1639
assign 1 253 1640
nextDescendGet 0 253 1640
assign 1 254 1641
nextPeerGet 0 254 1641
delayDelete 0 254 1642
return 1 255 1643
assign 1 257 1645
SUBTRACTGet 0 257 1645
assign 1 257 1646
equals 1 257 1651
assign 1 257 1652
def 1 257 1657
assign 1 0 1658
assign 1 0 1661
assign 1 0 1665
assign 1 257 1668
SUBTRACTGet 0 257 1668
assign 1 257 1669
equals 1 257 1674
assign 1 0 1675
assign 1 0 1678
assign 1 0 1682
assign 1 258 1685
nextPeerGet 0 258 1685
assign 1 258 1686
nextPeerGet 0 258 1686
assign 1 258 1687
def 1 258 1692
assign 1 258 1693
nextPeerGet 0 258 1693
assign 1 258 1694
nextPeerGet 0 258 1694
assign 1 258 1695
typenameGet 0 258 1695
assign 1 258 1696
ASSIGNGet 0 258 1696
assign 1 258 1697
equals 1 258 1702
assign 1 0 1703
assign 1 0 1706
assign 1 0 1710
assign 1 259 1713
DECREMENT_ASSIGNGet 0 259 1713
typenameSet 1 259 1714
assign 1 260 1715
heldGet 0 260 1715
assign 1 260 1716
nextPeerGet 0 260 1716
assign 1 260 1717
heldGet 0 260 1717
assign 1 260 1718
add 1 260 1718
assign 1 260 1719
nextPeerGet 0 260 1719
assign 1 260 1720
nextPeerGet 0 260 1720
assign 1 260 1721
heldGet 0 260 1721
assign 1 260 1722
add 1 260 1722
heldSet 1 260 1723
assign 1 261 1724
nextPeerGet 0 261 1724
assign 1 261 1725
nextPeerGet 0 261 1725
assign 1 261 1726
nextDescendGet 0 261 1726
assign 1 262 1727
nextPeerGet 0 262 1727
delayDelete 0 262 1728
assign 1 263 1729
nextPeerGet 0 263 1729
assign 1 263 1730
nextPeerGet 0 263 1730
delayDelete 0 263 1731
return 1 264 1732
assign 1 266 1734
DECREMENTGet 0 266 1734
typenameSet 1 266 1735
assign 1 267 1736
heldGet 0 267 1736
assign 1 267 1737
nextPeerGet 0 267 1737
assign 1 267 1738
heldGet 0 267 1738
assign 1 267 1739
add 1 267 1739
heldSet 1 267 1740
assign 1 268 1741
nextPeerGet 0 268 1741
assign 1 268 1742
nextDescendGet 0 268 1742
assign 1 269 1743
nextPeerGet 0 269 1743
delayDelete 0 269 1744
return 1 270 1745
assign 1 272 1747
ADDGet 0 272 1747
assign 1 272 1748
equals 1 272 1753
assign 1 272 1754
def 1 272 1759
assign 1 0 1760
assign 1 0 1763
assign 1 0 1767
assign 1 272 1770
ASSIGNGet 0 272 1770
assign 1 272 1771
equals 1 272 1776
assign 1 0 1777
assign 1 0 1780
assign 1 0 1784
assign 1 273 1787
ADD_ASSIGNGet 0 273 1787
typenameSet 1 273 1788
assign 1 274 1789
heldGet 0 274 1789
assign 1 274 1790
nextPeerGet 0 274 1790
assign 1 274 1791
heldGet 0 274 1791
assign 1 274 1792
add 1 274 1792
heldSet 1 274 1793
assign 1 275 1794
nextPeerGet 0 275 1794
assign 1 275 1795
nextDescendGet 0 275 1795
assign 1 276 1796
nextPeerGet 0 276 1796
delayDelete 0 276 1797
return 1 277 1798
assign 1 279 1800
SUBTRACTGet 0 279 1800
assign 1 279 1801
equals 1 279 1806
assign 1 279 1807
def 1 279 1812
assign 1 0 1813
assign 1 0 1816
assign 1 0 1820
assign 1 279 1823
ASSIGNGet 0 279 1823
assign 1 279 1824
equals 1 279 1829
assign 1 0 1830
assign 1 0 1833
assign 1 0 1837
assign 1 280 1840
SUBTRACT_ASSIGNGet 0 280 1840
typenameSet 1 280 1841
assign 1 281 1842
heldGet 0 281 1842
assign 1 281 1843
nextPeerGet 0 281 1843
assign 1 281 1844
heldGet 0 281 1844
assign 1 281 1845
add 1 281 1845
heldSet 1 281 1846
assign 1 282 1847
nextPeerGet 0 282 1847
assign 1 282 1848
nextDescendGet 0 282 1848
assign 1 283 1849
nextPeerGet 0 283 1849
delayDelete 0 283 1850
return 1 284 1851
assign 1 286 1853
MULTIPLYGet 0 286 1853
assign 1 286 1854
equals 1 286 1859
assign 1 286 1860
def 1 286 1865
assign 1 0 1866
assign 1 0 1869
assign 1 0 1873
assign 1 286 1876
ASSIGNGet 0 286 1876
assign 1 286 1877
equals 1 286 1882
assign 1 0 1883
assign 1 0 1886
assign 1 0 1890
assign 1 287 1893
MULTIPLY_ASSIGNGet 0 287 1893
typenameSet 1 287 1894
assign 1 288 1895
heldGet 0 288 1895
assign 1 288 1896
nextPeerGet 0 288 1896
assign 1 288 1897
heldGet 0 288 1897
assign 1 288 1898
add 1 288 1898
heldSet 1 288 1899
assign 1 289 1900
nextPeerGet 0 289 1900
assign 1 289 1901
nextDescendGet 0 289 1901
assign 1 290 1902
nextPeerGet 0 290 1902
delayDelete 0 290 1903
return 1 291 1904
assign 1 293 1906
DIVIDEGet 0 293 1906
assign 1 293 1907
equals 1 293 1912
assign 1 293 1913
def 1 293 1918
assign 1 0 1919
assign 1 0 1922
assign 1 0 1926
assign 1 293 1929
ASSIGNGet 0 293 1929
assign 1 293 1930
equals 1 293 1935
assign 1 0 1936
assign 1 0 1939
assign 1 0 1943
assign 1 294 1946
DIVIDE_ASSIGNGet 0 294 1946
typenameSet 1 294 1947
assign 1 295 1948
heldGet 0 295 1948
assign 1 295 1949
nextPeerGet 0 295 1949
assign 1 295 1950
heldGet 0 295 1950
assign 1 295 1951
add 1 295 1951
heldSet 1 295 1952
assign 1 296 1953
nextPeerGet 0 296 1953
assign 1 296 1954
nextDescendGet 0 296 1954
assign 1 297 1955
nextPeerGet 0 297 1955
delayDelete 0 297 1956
return 1 298 1957
assign 1 300 1959
MODULUSGet 0 300 1959
assign 1 300 1960
equals 1 300 1965
assign 1 300 1966
def 1 300 1971
assign 1 0 1972
assign 1 0 1975
assign 1 0 1979
assign 1 300 1982
ASSIGNGet 0 300 1982
assign 1 300 1983
equals 1 300 1988
assign 1 0 1989
assign 1 0 1992
assign 1 0 1996
assign 1 301 1999
MODULUS_ASSIGNGet 0 301 1999
typenameSet 1 301 2000
assign 1 302 2001
heldGet 0 302 2001
assign 1 302 2002
nextPeerGet 0 302 2002
assign 1 302 2003
heldGet 0 302 2003
assign 1 302 2004
add 1 302 2004
heldSet 1 302 2005
assign 1 303 2006
nextPeerGet 0 303 2006
assign 1 303 2007
nextDescendGet 0 303 2007
assign 1 304 2008
nextPeerGet 0 304 2008
delayDelete 0 304 2009
return 1 305 2010
assign 1 307 2012
ANDGet 0 307 2012
assign 1 307 2013
equals 1 307 2018
assign 1 307 2019
def 1 307 2024
assign 1 0 2025
assign 1 0 2028
assign 1 0 2032
assign 1 307 2035
ASSIGNGet 0 307 2035
assign 1 307 2036
equals 1 307 2041
assign 1 0 2042
assign 1 0 2045
assign 1 0 2049
assign 1 308 2052
AND_ASSIGNGet 0 308 2052
typenameSet 1 308 2053
assign 1 309 2054
heldGet 0 309 2054
assign 1 309 2055
nextPeerGet 0 309 2055
assign 1 309 2056
heldGet 0 309 2056
assign 1 309 2057
add 1 309 2057
heldSet 1 309 2058
assign 1 310 2059
nextPeerGet 0 310 2059
assign 1 310 2060
nextDescendGet 0 310 2060
assign 1 311 2061
nextPeerGet 0 311 2061
delayDelete 0 311 2062
return 1 312 2063
assign 1 314 2065
ORGet 0 314 2065
assign 1 314 2066
equals 1 314 2071
assign 1 314 2072
def 1 314 2077
assign 1 0 2078
assign 1 0 2081
assign 1 0 2085
assign 1 314 2088
ASSIGNGet 0 314 2088
assign 1 314 2089
equals 1 314 2094
assign 1 0 2095
assign 1 0 2098
assign 1 0 2102
assign 1 315 2105
OR_ASSIGNGet 0 315 2105
typenameSet 1 315 2106
assign 1 316 2107
heldGet 0 316 2107
assign 1 316 2108
nextPeerGet 0 316 2108
assign 1 316 2109
heldGet 0 316 2109
assign 1 316 2110
add 1 316 2110
heldSet 1 316 2111
assign 1 317 2112
nextPeerGet 0 317 2112
assign 1 317 2113
nextDescendGet 0 317 2113
assign 1 318 2114
nextPeerGet 0 318 2114
delayDelete 0 318 2115
return 1 319 2116
assign 1 321 2118
SPACEGet 0 321 2118
assign 1 321 2119
equals 1 321 2124
assign 1 0 2125
assign 1 321 2128
NEWLINEGet 0 321 2128
assign 1 321 2129
equals 1 321 2134
assign 1 0 2135
assign 1 0 2138
assign 1 322 2142
nextDescendGet 0 322 2142
delayDelete 0 323 2143
return 1 324 2144
assign 1 326 2146
nextDescendGet 0 326 2146
return 1 326 2147
return 1 0 2150
assign 1 0 2153
return 1 0 2157
assign 1 0 2160
return 1 0 2164
assign 1 0 2167
return 1 0 2171
assign 1 0 2174
return 1 0 2178
assign 1 0 2181
return 1 0 2185
assign 1 0 2188
return 1 0 2192
assign 1 0 2195
return 1 0 2199
assign 1 0 2202
return 1 0 2206
assign 1 0 2209
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 572357856: return bem_nestCommentGet_0();
case 599903714: return bem_strqCntGet_0();
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 734766741: return bem_inLcGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1788342768: return bem_goingStrGet_0();
case 1081412016: return bem_many_0();
case 1246859482: return bem_inSpaceGet_0();
case 1417421339: return bem_inStrGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1297902980: return bem_inNlGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case 2021097297: return bem_quoteTypeGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1235777229: return bem_inSpaceSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 588821461: return bem_strqCntSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1428503592: return bem_inStrSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 723684488: return bem_inLcSet_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 583440109: return bem_nestCommentSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 2032179550: return bem_quoteTypeSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1799425021: return bem_goingStrSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1308985233: return bem_inNlSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass3();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass3.bevs_inst = (BEC_3_5_5_5_BuildVisitPass3)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass3.bevs_inst;
}
}
