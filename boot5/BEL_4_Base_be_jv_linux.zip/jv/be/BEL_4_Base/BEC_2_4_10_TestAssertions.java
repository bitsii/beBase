package be.BEL_4_Base;
/* IO:File: source/base/Test.be */
public class BEC_2_4_10_TestAssertions extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_TestAssertions() { }
private static byte[] becc_clname = {0x54,0x65,0x73,0x74,0x3A,0x41,0x73,0x73,0x65,0x72,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_1 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73};
private static byte[] bels_4 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bels_6 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E};
private static byte[] bels_7 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bels_8 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bels_9 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_9, 36));
private static byte[] bels_10 = {0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_10, 1));
private static byte[] bels_11 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x55,0x4E,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74};
private static byte[] bels_12 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_13 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_14 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x4F,0x54,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_15 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x54,0x52,0x55,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_16 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x46,0x41,0x4C,0x53,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
public static BEC_2_4_10_TestAssertions bevs_inst;
public BEC_2_4_10_TestAssertions bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_10_TestAssertions bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_10_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_v1.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_v2);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 30 */ {
bevl_msg = (new BEC_2_4_6_TextString(46, bels_0));
if (beva_v1 == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 32 */ {
if (beva_v2 == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 32 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 32 */
 else  /* Line: 32 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 32 */ {
bevt_8_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_1));
bevt_7_tmpvar_phold = bevl_msg.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(beva_v1);
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_2));
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(beva_v2);
} /* Line: 33 */
bevt_10_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BELS_Base.BECS_ThrowBack(bevt_10_tmpvar_phold);
} /* Line: 35 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertNotHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_v1.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_v2);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 39 */ {
bevl_msg = (new BEC_2_4_6_TextString(46, bels_3));
if (beva_v1 == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 41 */ {
if (beva_v2 == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 41 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 41 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 41 */
 else  /* Line: 41 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 41 */ {
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_4));
bevt_6_tmpvar_phold = bevl_msg.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(beva_v1);
bevt_8_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_5));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(beva_v2);
} /* Line: 42 */
bevt_9_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BELS_Base.BECS_ThrowBack(bevt_9_tmpvar_phold);
} /* Line: 44 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_assertEqual_2(beva_v1, beva_v2);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertNotEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_assertNotEqual_2(beva_v1, beva_v2);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_4_6_TextString bevl_v1v = null;
BEC_2_4_6_TextString bevl_v2v = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
if (beva_v1 == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(56, bels_6));
bevt_1_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 55 */
bevt_3_tmpvar_phold = beva_v1.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, beva_v2);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 57 */ {
if (beva_v1 == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 58 */ {
bevl_v1v = (BEC_2_4_6_TextString) beva_v1.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_v1v = (new BEC_2_4_6_TextString(6, bels_7));
} /* Line: 61 */
if (beva_v2 == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 63 */ {
bevl_v2v = (BEC_2_4_6_TextString) beva_v2.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 64 */
 else  /* Line: 65 */ {
bevl_v2v = (new BEC_2_4_6_TextString(6, bels_8));
} /* Line: 66 */
bevt_10_tmpvar_phold = bevo_0;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevl_v1v);
bevt_11_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevl_v2v);
bevt_6_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_7_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 68 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertNotEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v1.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_v2);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 72 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(36, bels_11));
bevt_1_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 73 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
if (beva_v == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(31, bels_12));
bevt_1_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 78 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertIsNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
if (beva_v == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(31, bels_13));
bevt_1_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 83 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertNotNull_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
if (beva_v == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(35, bels_14));
bevt_1_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 88 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertTrue_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 92 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(31, bels_15));
bevt_1_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 93 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_assertFalse_1(BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_4_7_TestFailure bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
if (beva_v != null && beva_v instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)beva_v).bevi_bool) /* Line: 97 */ {
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(32, bels_16));
bevt_0_tmpvar_phold = (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_1_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_0_tmpvar_phold);
} /* Line: 98 */
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {30, 30, 31, 32, 32, 32, 32, 0, 0, 0, 33, 33, 33, 33, 33, 33, 35, 35, 39, 40, 41, 41, 41, 41, 0, 0, 0, 42, 42, 42, 42, 42, 42, 44, 44, 48, 48, 51, 51, 54, 54, 55, 55, 55, 57, 58, 58, 59, 61, 63, 63, 64, 66, 68, 68, 68, 68, 68, 68, 68, 72, 73, 73, 73, 77, 77, 78, 78, 78, 82, 82, 83, 83, 83, 87, 87, 88, 88, 88, 92, 93, 93, 93, 98, 98, 98};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {46, 47, 49, 50, 55, 56, 61, 62, 65, 69, 72, 73, 74, 75, 76, 77, 79, 80, 96, 98, 99, 104, 105, 110, 111, 114, 118, 121, 122, 123, 124, 125, 126, 128, 129, 135, 136, 140, 141, 158, 163, 164, 165, 166, 168, 170, 175, 176, 179, 181, 186, 187, 190, 192, 193, 194, 195, 196, 197, 198, 206, 208, 209, 210, 218, 223, 224, 225, 226, 234, 239, 240, 241, 242, 250, 255, 256, 257, 258, 266, 268, 269, 270, 278, 279, 280};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 30 46
has 1 30 46
assign 1 30 47
not 0 30 47
assign 1 31 49
new 0 31 49
assign 1 32 50
def 1 32 55
assign 1 32 56
def 1 32 61
assign 1 0 62
assign 1 0 65
assign 1 0 69
assign 1 33 72
new 0 33 72
assign 1 33 73
addValue 1 33 73
assign 1 33 74
addValue 1 33 74
assign 1 33 75
new 0 33 75
assign 1 33 76
addValue 1 33 76
addValue 1 33 77
assign 1 35 79
new 1 35 79
throw 1 35 80
assign 1 39 96
has 1 39 96
assign 1 40 98
new 0 40 98
assign 1 41 99
def 1 41 104
assign 1 41 105
def 1 41 110
assign 1 0 111
assign 1 0 114
assign 1 0 118
assign 1 42 121
new 0 42 121
assign 1 42 122
addValue 1 42 122
assign 1 42 123
addValue 1 42 123
assign 1 42 124
new 0 42 124
assign 1 42 125
addValue 1 42 125
addValue 1 42 126
assign 1 44 128
new 1 44 128
throw 1 44 129
assign 1 48 135
assertEqual 2 48 135
return 1 48 136
assign 1 51 140
assertNotEqual 2 51 140
return 1 51 141
assign 1 54 158
undef 1 54 163
assign 1 55 164
new 0 55 164
assign 1 55 165
new 1 55 165
throw 1 55 166
assign 1 57 168
notEquals 1 57 168
assign 1 58 170
def 1 58 175
assign 1 59 176
toString 0 59 176
assign 1 61 179
new 0 61 179
assign 1 63 181
def 1 63 186
assign 1 64 187
toString 0 64 187
assign 1 66 190
new 0 66 190
assign 1 68 192
new 0 68 192
assign 1 68 193
add 1 68 193
assign 1 68 194
new 0 68 194
assign 1 68 195
add 1 68 195
assign 1 68 196
add 1 68 196
assign 1 68 197
new 1 68 197
throw 1 68 198
assign 1 72 206
equals 1 72 206
assign 1 73 208
new 0 73 208
assign 1 73 209
new 1 73 209
throw 1 73 210
assign 1 77 218
def 1 77 223
assign 1 78 224
new 0 78 224
assign 1 78 225
new 1 78 225
throw 1 78 226
assign 1 82 234
def 1 82 239
assign 1 83 240
new 0 83 240
assign 1 83 241
new 1 83 241
throw 1 83 242
assign 1 87 250
undef 1 87 255
assign 1 88 256
new 0 88 256
assign 1 88 257
new 1 88 257
throw 1 88 258
assign 1 92 266
not 0 92 266
assign 1 93 268
new 0 93 268
assign 1 93 269
new 1 93 269
throw 1 93 270
assign 1 98 278
new 0 98 278
assign 1 98 279
new 1 98 279
throw 1 98 280
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1397518831: return bem_assertFalse_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1801614214: return bem_assertNotNull_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 754733399: return bem_assertIsNull_1(bevd_0);
case 815800737: return bem_assertNull_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 646535002: return bem_assertTrue_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 187025688: return bem_assertEquals_2(bevd_0, bevd_1);
case 1160364576: return bem_assertNotHas_2(bevd_0, bevd_1);
case 1328041857: return bem_assertNotEquals_2(bevd_0, bevd_1);
case 975863745: return bem_assertEqual_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 383195175: return bem_assertHas_2(bevd_0, bevd_1);
case 511348602: return bem_assertNotEqual_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_TestAssertions();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_TestAssertions.bevs_inst = (BEC_2_4_10_TestAssertions)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_TestAssertions.bevs_inst;
}
}
