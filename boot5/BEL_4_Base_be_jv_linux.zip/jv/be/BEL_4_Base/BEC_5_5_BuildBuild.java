package be.BEL_4_Base;
/* IO:File: source/build/Build.be */
public class BEC_5_5_BuildBuild extends BEC_6_6_SystemObject {
public BEC_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_6 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_7, 28));
private static byte[] bels_8 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_9 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_9, 12));
private static byte[] bels_10 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_10, 21));
private static byte[] bels_11 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_11, 6));
private static byte[] bels_12 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_12, 13));
private static byte[] bels_13 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_13, 21));
private static byte[] bels_14 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_14, 6));
private static byte[] bels_15 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_16 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_4_6_TextString bevo_9 = (new BEC_4_6_TextString(bels_16, 5));
private static byte[] bels_17 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_18 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_21 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_22 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_23 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_24 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_25 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_26 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_27 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_30 = {0x74,0x72,0x75,0x65};
private static byte[] bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_51 = {0x72,0x75,0x6E};
private static byte[] bels_52 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_53 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_54 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_55 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_56 = {0x67,0x63,0x63};
private static byte[] bels_57 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_59 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_59, 9));
private static byte[] bels_60 = {};
private static byte[] bels_61 = {0x63};
private static byte[] bels_62 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_62, 8));
private static byte[] bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_4_6_TextString bevo_12 = (new BEC_4_6_TextString(bels_63, 7));
private static byte[] bels_64 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_65 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_66 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_13 = (new BEC_4_6_TextString(bels_66, 2));
private static byte[] bels_67 = {0x63,0x73};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_67, 2));
private static byte[] bels_68 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_68, 2));
private static byte[] bels_69 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_70 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_70, 19));
private static byte[] bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_17 = (new BEC_4_6_TextString(bels_71, 31));
private static byte[] bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_18 = (new BEC_4_6_TextString(bels_72, 31));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_19 = (new BEC_4_6_TextString(bels_73, 41));
private static byte[] bels_74 = {0x2F};
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_20 = (new BEC_4_6_TextString(bels_75, 31));
private static byte[] bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_21 = (new BEC_4_6_TextString(bels_76, 41));
private static byte[] bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_77, 51));
private static byte[] bels_78 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_23 = (new BEC_4_6_TextString(bels_78, 14));
private static byte[] bels_79 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_4_6_TextString bevo_24 = (new BEC_4_6_TextString(bels_79, 19));
private static byte[] bels_80 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_25 = (new BEC_4_6_TextString(bels_80, 9));
private static byte[] bels_81 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_26 = (new BEC_4_6_TextString(bels_81, 13));
private static byte[] bels_82 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_27 = (new BEC_4_6_TextString(bels_82, 2));
private static byte[] bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_4_6_TextString bevo_28 = (new BEC_4_6_TextString(bels_83, 22));
private static byte[] bels_84 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_29 = (new BEC_4_6_TextString(bels_84, 3));
private static byte[] bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_4_6_TextString bevo_30 = (new BEC_4_6_TextString(bels_85, 15));
private static byte[] bels_86 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_31 = (new BEC_4_6_TextString(bels_86, 4));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_4_6_TextString bevo_32 = (new BEC_4_6_TextString(bels_87, 15));
private static byte[] bels_88 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_33 = (new BEC_4_6_TextString(bels_88, 5));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_4_6_TextString bevo_34 = (new BEC_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_35 = (new BEC_4_6_TextString(bels_90, 6));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_4_6_TextString bevo_36 = (new BEC_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_37 = (new BEC_4_6_TextString(bels_92, 7));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_4_6_TextString bevo_38 = (new BEC_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_39 = (new BEC_4_6_TextString(bels_94, 8));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_4_6_TextString bevo_40 = (new BEC_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_41 = (new BEC_4_6_TextString(bels_96, 9));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_4_6_TextString bevo_42 = (new BEC_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_43 = (new BEC_4_6_TextString(bels_98, 10));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_4_6_TextString bevo_44 = (new BEC_4_6_TextString(bels_99, 15));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_45 = (new BEC_4_6_TextString(bels_100, 11));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_4_6_TextString bevo_46 = (new BEC_4_6_TextString(bels_101, 16));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_47 = (new BEC_4_6_TextString(bels_102, 12));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_4_6_TextString bevo_48 = (new BEC_4_6_TextString(bels_103, 16));
private static byte[] bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_49 = (new BEC_4_6_TextString(bels_104, 13));
private static byte[] bels_105 = {0x20};
private static BEC_4_6_TextString bevo_50 = (new BEC_4_6_TextString(bels_105, 1));
private static byte[] bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_4_6_TextString bevo_51 = (new BEC_4_6_TextString(bels_106, 16));
public static BEC_5_5_BuildBuild bevs_inst;
public BEC_4_6_TextString bevp_mainName;
public BEC_4_6_TextString bevp_libName;
public BEC_4_6_TextString bevp_exeName;
public BEC_6_6_SystemObject bevp_emitFileHeader;
public BEC_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_9_10_ContainerLinkedList bevp_extLibs;
public BEC_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_platform;
public BEC_6_6_SystemObject bevp_outputPlatform;
public BEC_6_6_SystemObject bevp_emitLibrary;
public BEC_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_newline;
public BEC_6_6_SystemObject bevp_runArgs;
public BEC_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_9_5_ContainerArray bevp_args;
public BEC_6_10_SystemParameters bevp_params;
public BEC_5_4_LogicBool bevp_buildSucceeded;
public BEC_4_6_TextString bevp_buildMessage;
public BEC_4_8_TimeInterval bevp_startTime;
public BEC_4_8_TimeInterval bevp_parseTime;
public BEC_4_8_TimeInterval bevp_parseEmitTime;
public BEC_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_2_4_4_IOFilePath bevp_buildPath;
public BEC_6_6_SystemObject bevp_includePath;
public BEC_9_3_ContainerMap bevp_built;
public BEC_9_10_ContainerLinkedList bevp_toBuild;
public BEC_5_4_LogicBool bevp_printSteps;
public BEC_5_4_LogicBool bevp_printPlaces;
public BEC_5_4_LogicBool bevp_printAst;
public BEC_5_4_LogicBool bevp_printAllAst;
public BEC_9_3_ContainerSet bevp_printAstElements;
public BEC_5_4_LogicBool bevp_doEmit;
public BEC_5_4_LogicBool bevp_emitDebug;
public BEC_5_4_LogicBool bevp_parse;
public BEC_5_4_LogicBool bevp_prepMake;
public BEC_5_4_LogicBool bevp_make;
public BEC_5_4_LogicBool bevp_genOnly;
public BEC_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_5_8_BuildEmitData bevp_emitData;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public BEC_6_6_SystemObject bevp_code;
public BEC_4_6_TextString bevp_estr;
public BEC_6_6_SystemObject bevp_sharedEmitter;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_9_TextTokenizer bevp_twtok;
public BEC_4_9_TextTokenizer bevp_lctok;
public BEC_5_7_BuildLibrary bevp_deployLibrary;
public BEC_4_6_TextString bevp_deployPath;
public BEC_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_9_3_ContainerSet bevp_closeLibraries;
public BEC_5_4_LogicBool bevp_run;
public BEC_4_6_TextString bevp_compiler;
public BEC_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_4_6_TextString bevp_makeName;
public BEC_4_6_TextString bevp_makeArgs;
public BEC_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_5_4_LogicBool bevp_ownProcess;
public BEC_4_6_TextString bevp_readBuffer;
public BEC_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(3, bels_0));
bevp_lctok = (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isNewish_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 104 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 105 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_process_1(BEC_4_6_TextString beva_arg) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_main_0() throws Throwable {
BEC_9_5_ContainerArray bevl__args = null;
BEC_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst.bem_new_0();
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = this.bem_main_1(bevl__args);
BEC_6_7_SystemProcess.bevs_inst.bem_exit_1((BEC_4_3_MathInt) bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_main_1(BEC_9_5_ContainerArray beva__args) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_0_tmpvar_phold = this.bem_go_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_go_0() throws Throwable {
BEC_4_3_MathInt bevl_whatResult = null;
BEC_5_4_LogicBool bevl_buildFailed = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (new BEC_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 129 */ {
bevp_buildMessage = (new BEC_4_6_TextString(16, bels_5));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (new BEC_4_6_TextString(14, bels_6));
} /* Line: 132 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_4_3_MathInt(1));
} /* Line: 137 */
if (bevp_printSteps.bevi_bool) /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 139 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 139 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 140 */
return bevl_whatResult;
} /*method end*/
public BEC_4_6_TextString bem_dllhead_1(BEC_4_6_TextString beva_addTo) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(5, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 146 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 152 */
return beva_addTo;
} /*method end*/
public BEC_6_6_SystemObject bem_config_0() throws Throwable {
BEC_4_6_TextString bevl_istr = null;
BEC_9_3_ContainerSet bevl_bfiles = null;
BEC_4_6_TextString bevl_bkey = null;
BEC_9_10_ContainerLinkedList bevl_pacm = null;
BEC_4_6_TextString bevl_pa = null;
BEC_4_6_TextString bevl_outLang = null;
BEC_6_6_SystemObject bevl_platformSources = null;
BEC_6_6_SystemObject bevl_langSources = null;
BEC_6_6_SystemObject bevl_emr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_113_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_114_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_116_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_2_4_IOFile bevt_120_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_4_IOFile bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
bevl_bfiles = (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_4_6_TextString(9, bels_15));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 163 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 163 */ {
bevl_istr = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 166 */
} /* Line: 164 */
 else  /* Line: 163 */ {
break;
} /* Line: 163 */
} /* Line: 163 */
} /* Line: 163 */
bevt_13_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 172 */
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(7, bels_18));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(7, bels_19));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 176 */
 else  /* Line: 177 */ {
bevp_exeName = bevp_libName;
} /* Line: 178 */
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(9, bels_20));
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(6, bels_21));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(6, bels_22));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(11, bels_23));
bevt_31_tmpvar_phold = (new BEC_4_6_TextString(7, bels_24));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(8, bels_25));
bevt_36_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_4_6_TextString(14, bels_26));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_4_6_TextString(16, bels_27));
bevt_44_tmpvar_phold = (new BEC_4_6_TextString(5, bels_28));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (new BEC_4_6_TextString(10, bels_29));
bevt_48_tmpvar_phold = (new BEC_4_6_TextString(4, bels_30));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (new BEC_4_6_TextString(9, bels_31));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (new BEC_4_6_TextString(10, bels_32));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (new BEC_4_6_TextString(10, bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevp_usedLibrarysStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(15, bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_closeLibrariesStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(14, bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesFrom = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_59_tmpvar_phold = (new BEC_4_6_TextString(12, bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevp_deployFilesTo = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(10, bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevp_extIncludes = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_63_tmpvar_phold = (new BEC_4_6_TextString(9, bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_ccObjArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_65_tmpvar_phold = (new BEC_4_6_TextString(6, bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevp_extLibs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_67_tmpvar_phold = (new BEC_4_6_TextString(11, bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevp_linkLibArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(13, bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevp_extLinkObjects = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 225 */
bevt_71_tmpvar_phold = (new BEC_4_6_TextString(14, bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 229 */
bevt_73_tmpvar_phold = (new BEC_4_6_TextString(7, bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 233 */
 else  /* Line: 234 */ {
bevp_runArgs = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 235 */
bevt_75_tmpvar_phold = (new BEC_4_6_TextString(10, bels_44));
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (new BEC_4_6_TextString(11, bels_45));
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (new BEC_4_6_TextString(8, bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (new BEC_4_6_TextString(11, bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (new BEC_4_6_TextString(15, bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_not_0();
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 243 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_iteratorGet_0();
while (true)
 /* Line: 244 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 244 */ {
bevl_pa = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 245 */
 else  /* Line: 244 */ {
break;
} /* Line: 244 */
} /* Line: 244 */
} /* Line: 244 */
bevt_86_tmpvar_phold = (new BEC_4_6_TextString(7, bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (new BEC_4_6_TextString(19, bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (new BEC_4_6_TextString(3, bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (new BEC_4_6_TextString(21, bels_52));
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (new BEC_4_6_TextString(8, bels_53));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (new BEC_4_6_TextString(8, bels_54));
bevp_emitFlags = bevp_params.bem_get_1(bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = (new BEC_4_6_TextString(8, bels_55));
bevt_95_tmpvar_phold = (new BEC_4_6_TextString(3, bels_56));
bevt_93_tmpvar_phold = bevp_params.bem_get_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevp_compiler = (BEC_4_6_TextString) bevt_93_tmpvar_phold.bem_firstGet_0();
bevt_97_tmpvar_phold = (new BEC_4_6_TextString(4, bels_57));
bevt_98_tmpvar_phold = (new BEC_4_6_TextString(4, bels_58));
bevt_96_tmpvar_phold = bevp_params.bem_get_2(bevt_97_tmpvar_phold, bevt_98_tmpvar_phold);
bevp_makeName = (BEC_4_6_TextString) bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = bevo_10;
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_102_tmpvar_phold = (new BEC_4_6_TextString(0, bels_60));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_102_tmpvar_phold);
bevp_makeArgs = (BEC_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevp_parse = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevl_outLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 265 */
 else  /* Line: 266 */ {
bevl_outLang = (new BEC_4_6_TextString(1, bels_61));
} /* Line: 267 */
bevt_106_tmpvar_phold = bevo_11;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevt_107_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_104_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 275 */ {
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_109_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 276 */
bevt_111_tmpvar_phold = bevo_12;
bevt_110_tmpvar_phold = bevl_outLang.bem_add_1(bevt_111_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_langSources == null) {
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_113_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 281 */
bevp_toBuild = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_114_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_114_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 285 */ {
bevt_115_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevl_istr = (BEC_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_116_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_116_tmpvar_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
bevp_newline = (BEC_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_existsGet_0();
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bem_not_0();
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_120_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpvar_phold.bem_makeDirs_0();
} /* Line: 294 */
if (bevp_emitFileHeader == null) {
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevt_122_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_122_tmpvar_phold.bem_readerGet_0();
bevt_123_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_123_tmpvar_phold.bemd_1(347960121, BEL_4_Base.bevn_readString_1, bevp_readBuffer);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 299 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(13, bels_64));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(12, bels_65));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_6_6_SystemObject bem_setClassesToWrite_0() throws Throwable {
BEC_9_3_ContainerSet bevl_toEmit = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_9_3_ContainerSet bevl_usedBy = null;
BEC_4_6_TextString bevl_ub = null;
BEC_9_3_ContainerSet bevl_subClasses = null;
BEC_4_6_TextString bevl_sc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 313 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 313 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_iteratorGet_0();
while (true)
 /* Line: 319 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 319 */ {
bevl_ub = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 320 */
 else  /* Line: 319 */ {
break;
} /* Line: 319 */
} /* Line: 319 */
} /* Line: 319 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_iteratorGet_0();
while (true)
 /* Line: 325 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 325 */ {
bevl_sc = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 326 */
 else  /* Line: 325 */ {
break;
} /* Line: 325 */
} /* Line: 325 */
} /* Line: 325 */
} /* Line: 324 */
} /* Line: 315 */
 else  /* Line: 313 */ {
break;
} /* Line: 313 */
} /* Line: 313 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 331 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 331 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 333 */
 else  /* Line: 331 */ {
break;
} /* Line: 331 */
} /* Line: 331 */
return this;
} /*method end*/
public BEC_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_4_6_TextString bevl_emitLang = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 344 */ {
return bevp_emitCommon;
} /* Line: 345 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevl_emitLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 352 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 355 */
 else  /* Line: 352 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 357 */
 else  /* Line: 358 */ {
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(49, bels_69));
bevt_8_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 359 */
} /* Line: 352 */
} /* Line: 352 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 362 */
return null;
} /*method end*/
public BEC_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_6_6_SystemObject bevl_em = null;
BEC_9_3_ContainerSet bevl_ulibs = null;
BEC_6_6_SystemObject bevl_ups = null;
BEC_6_6_SystemObject bevl_pack = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_tb = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_bp = null;
BEC_6_6_SystemObject bevl_cpFrom = null;
BEC_6_6_SystemObject bevl_cpTo = null;
BEC_6_6_SystemObject bevl_fIter = null;
BEC_6_6_SystemObject bevl_tIter = null;
BEC_4_3_MathInt bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_19_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
bevp_startTime = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_emitData = (new BEC_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 372 */ {
bevp_deployLibrary = (new BEC_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 375 */ {
bevt_6_tmpvar_phold = bevo_16;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_libName);
bevt_5_tmpvar_phold.bem_print_0();
} /* Line: 376 */
} /* Line: 375 */
bevl_ulibs = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 381 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 381 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 382 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 385 */
} /* Line: 382 */
 else  /* Line: 381 */ {
break;
} /* Line: 381 */
} /* Line: 381 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 388 */ {
bevt_10_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 388 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_13_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_13_tmpvar_phold);
} /* Line: 393 */
} /* Line: 389 */
 else  /* Line: 388 */ {
break;
} /* Line: 388 */
} /* Line: 388 */
if (bevp_parse.bevi_bool) /* Line: 396 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 398 */ {
bevt_14_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 398 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 401 */
 else  /* Line: 398 */ {
break;
} /* Line: 398 */
} /* Line: 398 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 403 */
bevt_15_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseTime = bevt_15_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_printSteps.bevi_bool) /* Line: 407 */ {
bevt_17_tmpvar_phold = bevo_17;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_16_tmpvar_phold.bem_print_0();
} /* Line: 408 */
bevt_19_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_19_tmpvar_phold == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 410 */ {
bevt_20_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_20_tmpvar_phold.bem_doEmit_0();
bevt_21_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_21_tmpvar_phold;
} /* Line: 413 */
if (bevp_doEmit.bevi_bool) /* Line: 415 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_22_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_22_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 419 */ {
bevt_23_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 419 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 421 */
 else  /* Line: 419 */ {
break;
} /* Line: 419 */
} /* Line: 419 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 425 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 425 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 427 */
 else  /* Line: 425 */ {
break;
} /* Line: 425 */
} /* Line: 425 */
} /* Line: 425 */
bevt_26_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitTime = bevt_26_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 432 */ {
bevt_29_tmpvar_phold = bevo_18;
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_28_tmpvar_phold.bem_print_0();
} /* Line: 433 */
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_30_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 436 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 438 */
if (bevp_make.bevi_bool) /* Line: 441 */ {
bevt_32_tmpvar_phold = bevp_genOnly.bem_not_0();
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 445 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_iteratorGet_0();
while (true)
 /* Line: 446 */ {
bevt_33_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 446 */ {
bevl_bp = bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_34_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_35_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_35_tmpvar_phold.bem_copy_0();
bevt_37_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_38_tmpvar_phold != null && bevt_38_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_38_tmpvar_phold).bevi_bool) /* Line: 450 */ {
bevt_40_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_40_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 451 */
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 453 */ {
bevt_44_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_44_tmpvar_phold, bevt_45_tmpvar_phold);
} /* Line: 454 */
} /* Line: 453 */
 else  /* Line: 446 */ {
break;
} /* Line: 446 */
} /* Line: 446 */
} /* Line: 446 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 461 */ {
bevt_46_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 461 */ {
bevt_47_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 461 */
 else  /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 461 */ {
bevt_48_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_48_tmpvar_phold);
bevt_53_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_copy_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_54_tmpvar_phold = (new BEC_4_6_TextString(1, bels_74));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_55_tmpvar_phold);
bevl_cpTo = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_49_tmpvar_phold);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_56_tmpvar_phold != null && bevt_56_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_56_tmpvar_phold).bevi_bool) /* Line: 465 */ {
bevt_58_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_58_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 466 */
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 468 */ {
bevt_62_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
} /* Line: 469 */
} /* Line: 468 */
 else  /* Line: 461 */ {
break;
} /* Line: 461 */
} /* Line: 461 */
} /* Line: 461 */
} /* Line: 442 */
bevt_64_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitCompileTime = bevt_64_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 476 */ {
bevt_67_tmpvar_phold = bevo_20;
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_66_tmpvar_phold.bem_print_0();
} /* Line: 477 */
if (bevp_parseEmitTime == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_70_tmpvar_phold = bevo_21;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_69_tmpvar_phold.bem_print_0();
} /* Line: 480 */
if (bevp_parseEmitCompileTime == null) {
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 482 */ {
bevt_73_tmpvar_phold = bevo_22;
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_72_tmpvar_phold.bem_print_0();
} /* Line: 483 */
if (bevp_run.bevi_bool) /* Line: 486 */ {
bevt_74_tmpvar_phold = bevo_23;
bevt_74_tmpvar_phold.bem_print_0();
bevl_result = (BEC_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_77_tmpvar_phold = bevo_24;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevl_result);
bevt_78_tmpvar_phold = bevo_25;
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bem_add_1(bevt_78_tmpvar_phold);
bevt_75_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 490 */
bevt_79_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_79_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSyns_1(BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_kls = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 496 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 496 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 500 */
 else  /* Line: 496 */ {
break;
} /* Line: 496 */
} /* Line: 496 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 502 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 502 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 506 */
 else  /* Line: 502 */ {
break;
} /* Line: 502 */
} /* Line: 502 */
bevt_6_tmpvar_phold = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_getSyn_2(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_syn = null;
BEC_6_6_SystemObject bevl_pklass = null;
BEC_6_6_SystemObject bevl_psyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 512 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 513 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 517 */
 else  /* Line: 518 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 521 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 523 */
 else  /* Line: 524 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 526 */
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 528 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevt_18_tmpvar_phold, (BEC_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_5_8_BuildClassSyn bem_getSynNp_1(BEC_6_6_SystemObject beva_np) throws Throwable {
BEC_6_6_SystemObject bevl_nps = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 538 */ {
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /* Line: 539 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevl_nps, (BEC_5_8_BuildClassSyn) bevl_syn);
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 554 */ {
bevp_sharedEmitter = (new BEC_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 555 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_doParse_1(BEC_6_6_SystemObject beva_toParse) throws Throwable {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_blank = null;
BEC_6_6_SystemObject bevl_emitter = null;
BEC_5_4_LogicBool bevl_parseThis = null;
BEC_6_6_SystemObject bevl_src = null;
BEC_9_10_ContainerLinkedList bevl_toks = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_ntunode = null;
BEC_6_6_SystemObject bevl_ntt = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 568 */ {
if (bevp_printSteps.bevi_bool) /* Line: 569 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 569 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 569 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 569 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 569 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 569 */ {
bevt_4_tmpvar_phold = bevo_26;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 570 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 583 */ {
bevt_11_tmpvar_phold = bevo_27;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 584 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 587 */ {
bevt_13_tmpvar_phold = bevo_28;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 589 */
if (bevp_printSteps.bevi_bool) /* Line: 592 */ {
bevt_15_tmpvar_phold = bevo_29;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 593 */
bevt_16_tmpvar_phold = (BEC_5_5_5_BuildVisitPass2) (new BEC_5_5_5_BuildVisitPass2()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 596 */ {
bevt_17_tmpvar_phold = bevo_30;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 598 */
if (bevp_printSteps.bevi_bool) /* Line: 600 */ {
bevt_19_tmpvar_phold = bevo_31;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 601 */
bevt_20_tmpvar_phold = (BEC_5_5_5_BuildVisitPass3) (new BEC_5_5_5_BuildVisitPass3()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 606 */ {
bevt_21_tmpvar_phold = bevo_32;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 608 */
if (bevp_printSteps.bevi_bool) /* Line: 611 */ {
bevt_23_tmpvar_phold = bevo_33;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 612 */
bevt_24_tmpvar_phold = (BEC_5_5_5_BuildVisitPass4) (new BEC_5_5_5_BuildVisitPass4()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 615 */ {
bevt_25_tmpvar_phold = bevo_34;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 617 */
if (bevp_printSteps.bevi_bool) /* Line: 620 */ {
bevt_27_tmpvar_phold = bevo_35;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 621 */
bevt_28_tmpvar_phold = (BEC_5_5_5_BuildVisitPass5) (new BEC_5_5_5_BuildVisitPass5()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 624 */ {
bevt_29_tmpvar_phold = bevo_36;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 626 */
if (bevp_printSteps.bevi_bool) /* Line: 629 */ {
bevt_31_tmpvar_phold = bevo_37;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 630 */
bevt_32_tmpvar_phold = (BEC_5_5_5_BuildVisitPass6) (new BEC_5_5_5_BuildVisitPass6()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_33_tmpvar_phold = bevo_38;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_35_tmpvar_phold = bevo_39;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 639 */
bevt_36_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_37_tmpvar_phold = bevo_40;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_39_tmpvar_phold = bevo_41;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 648 */
bevt_40_tmpvar_phold = (BEC_5_5_5_BuildVisitPass8) (new BEC_5_5_5_BuildVisitPass8()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_41_tmpvar_phold = bevo_42;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_43_tmpvar_phold = bevo_43;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 657 */
bevt_44_tmpvar_phold = (BEC_5_5_5_BuildVisitPass9) (new BEC_5_5_5_BuildVisitPass9()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_45_tmpvar_phold = bevo_44;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 665 */ {
bevt_47_tmpvar_phold = bevo_45;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 666 */
bevt_48_tmpvar_phold = (BEC_5_5_6_BuildVisitPass10) (new BEC_5_5_6_BuildVisitPass10()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 669 */ {
bevt_49_tmpvar_phold = bevo_46;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 671 */
if (bevp_printSteps.bevi_bool) /* Line: 673 */ {
bevt_51_tmpvar_phold = bevo_47;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 674 */
bevt_52_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 677 */ {
bevt_53_tmpvar_phold = bevo_48;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 679 */
if (bevp_printSteps.bevi_bool) /* Line: 682 */ {
bevt_55_tmpvar_phold = bevo_49;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_50;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 684 */
bevt_57_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 687 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 687 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 687 */ {
bevt_58_tmpvar_phold = bevo_51;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 689 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 691 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 691 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 702 */
 else  /* Line: 691 */ {
break;
} /* Line: 691 */
} /* Line: 691 */
} /* Line: 691 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_nodify_2(BEC_6_6_SystemObject beva_parnode, BEC_6_6_SystemObject beva_toks) throws Throwable {
BEC_9_8_ContainerNodeList bevl_con = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_4_6_TextString bevl_cr = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_node = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 712 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 712 */ {
bevl_node = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 716 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 717 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 719 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 721 */
} /* Line: 719 */
 else  /* Line: 712 */ {
break;
} /* Line: 712 */
} /* Line: 712 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_6_6_SystemObject bem_mainNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mainName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_6_6_SystemObject bem_exeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_6_6_SystemObject bem_extIncludesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_ccObjArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_6_6_SystemObject bem_extLibsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_linkLibArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_6_6_SystemObject bem_platformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesFromSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerProfileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSucceededSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildSucceeded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_6_6_SystemObject bem_buildMessageSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildMessage = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_6_6_SystemObject bem_startTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_startTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_6_6_SystemObject bem_buildPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_6_6_SystemObject bem_builtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_built = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_6_6_SystemObject bem_toBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_toBuild = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_6_6_SystemObject bem_printStepsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printSteps = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_6_6_SystemObject bem_printPlacesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printPlaces = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAllAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAllAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstElementsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAstElements = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_6_6_SystemObject bem_doEmitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_doEmit = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDebugSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitDebug = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_6_6_SystemObject bem_parseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parse = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_6_6_SystemObject bem_prepMakeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_prepMake = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_6_6_SystemObject bem_makeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_make = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_6_6_SystemObject bem_genOnlySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_genOnly = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDataSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitData = (BEC_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_6_6_SystemObject bem_codeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_6_6_SystemObject bem_estrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_estr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_6_6_SystemObject bem_twtokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_twtok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_6_6_SystemObject bem_lctokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lctok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_deployLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_6_6_SystemObject bem_deployPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployPath = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibraries = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_6_6_SystemObject bem_runSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_run = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compiler = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLangsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLangs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFlagsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFlags = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_6_6_SystemObject bem_makeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_makeArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeArgs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_dynConditionsAllGet_0() throws Throwable {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_6_6_SystemObject bem_ownProcessSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ownProcess = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_6_6_SystemObject bem_readBufferSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_readBuffer = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitCommonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {61, 63, 64, 65, 66, 68, 69, 70, 71, 72, 73, 74, 78, 80, 81, 82, 83, 83, 86, 89, 90, 96, 97, 98, 99, 99, 104, 104, 104, 104, 0, 104, 104, 0, 0, 0, 0, 0, 105, 105, 107, 107, 111, 111, 111, 111, 115, 115, 116, 116, 120, 121, 122, 122, 126, 127, 128, 130, 131, 132, 134, 135, 136, 136, 137, 0, 0, 0, 140, 142, 146, 146, 146, 147, 147, 147, 147, 148, 148, 148, 149, 149, 149, 150, 150, 150, 150, 151, 151, 151, 152, 152, 152, 154, 159, 161, 162, 162, 162, 163, 163, 0, 163, 163, 164, 164, 165, 166, 166, 171, 171, 171, 171, 172, 174, 174, 174, 175, 175, 176, 176, 176, 178, 180, 180, 180, 180, 180, 180, 181, 182, 182, 183, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 184, 185, 185, 185, 185, 185, 186, 186, 186, 186, 186, 187, 187, 187, 187, 187, 189, 189, 189, 190, 190, 190, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 231, 232, 232, 233, 235, 237, 237, 237, 238, 238, 238, 239, 239, 240, 240, 241, 242, 242, 243, 243, 243, 243, 0, 0, 0, 244, 0, 244, 244, 245, 248, 248, 249, 249, 250, 250, 251, 251, 251, 252, 252, 253, 253, 254, 254, 254, 254, 255, 255, 255, 255, 256, 256, 256, 256, 256, 257, 258, 259, 260, 261, 264, 264, 265, 267, 274, 274, 274, 274, 274, 275, 275, 276, 276, 279, 279, 279, 280, 280, 281, 281, 284, 285, 285, 0, 285, 285, 286, 286, 288, 289, 290, 292, 293, 293, 293, 294, 294, 296, 296, 297, 297, 298, 298, 299, 305, 306, 306, 306, 306, 306, 307, 307, 307, 307, 307, 308, 312, 313, 313, 313, 314, 315, 315, 315, 315, 316, 316, 316, 316, 317, 317, 317, 317, 317, 318, 318, 319, 0, 319, 319, 320, 323, 323, 323, 323, 323, 324, 324, 325, 0, 325, 325, 326, 331, 331, 331, 332, 333, 333, 333, 333, 333, 333, 340, 340, 344, 344, 345, 350, 350, 351, 352, 352, 353, 354, 354, 355, 356, 356, 357, 359, 359, 359, 361, 362, 364, 369, 370, 371, 372, 372, 373, 374, 376, 376, 376, 379, 381, 0, 381, 381, 382, 382, 383, 384, 385, 388, 0, 388, 388, 389, 389, 390, 391, 392, 393, 393, 398, 398, 399, 401, 403, 406, 406, 408, 408, 408, 410, 410, 410, 412, 412, 413, 413, 416, 417, 419, 419, 419, 420, 421, 423, 424, 425, 425, 425, 426, 427, 431, 431, 432, 432, 433, 433, 433, 435, 435, 435, 438, 442, 443, 444, 446, 0, 446, 446, 447, 447, 448, 448, 449, 449, 449, 450, 450, 451, 451, 453, 453, 453, 454, 454, 454, 458, 459, 461, 461, 0, 0, 0, 462, 462, 463, 463, 463, 463, 463, 463, 463, 463, 465, 465, 466, 466, 468, 468, 468, 469, 469, 469, 474, 474, 476, 476, 477, 477, 477, 479, 479, 480, 480, 480, 482, 482, 483, 483, 483, 487, 487, 488, 489, 489, 489, 489, 489, 490, 492, 492, 496, 496, 496, 497, 498, 498, 499, 500, 502, 502, 502, 503, 504, 504, 505, 506, 508, 508, 512, 512, 512, 512, 513, 513, 513, 515, 515, 516, 516, 516, 516, 517, 519, 519, 519, 519, 519, 521, 521, 522, 522, 523, 526, 526, 526, 528, 530, 530, 531, 531, 531, 531, 532, 536, 537, 537, 538, 538, 539, 545, 545, 546, 547, 554, 554, 555, 557, 562, 563, 564, 565, 566, 567, 567, 0, 0, 0, 570, 570, 570, 570, 572, 574, 574, 574, 574, 575, 575, 575, 576, 584, 584, 586, 586, 588, 588, 589, 589, 593, 593, 595, 595, 597, 597, 598, 598, 601, 601, 604, 604, 605, 607, 607, 608, 608, 612, 612, 614, 614, 616, 616, 617, 617, 621, 621, 623, 623, 625, 625, 626, 626, 630, 630, 632, 632, 634, 634, 635, 635, 639, 639, 641, 641, 643, 643, 644, 644, 648, 648, 650, 650, 652, 652, 653, 653, 657, 657, 659, 659, 661, 661, 662, 662, 666, 666, 668, 668, 670, 670, 671, 671, 674, 674, 676, 676, 678, 678, 679, 679, 683, 683, 684, 684, 686, 686, 0, 0, 0, 688, 688, 689, 689, 691, 691, 691, 692, 694, 695, 696, 696, 697, 698, 698, 698, 699, 700, 701, 702, 708, 709, 710, 711, 711, 712, 712, 713, 714, 714, 715, 716, 716, 717, 719, 719, 720, 721, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 276, 281, 282, 283, 285, 288, 289, 291, 294, 298, 301, 305, 308, 309, 311, 312, 318, 319, 320, 321, 327, 328, 329, 330, 335, 336, 337, 338, 346, 347, 348, 350, 351, 352, 356, 357, 358, 359, 360, 363, 367, 370, 374, 376, 396, 397, 398, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 421, 557, 558, 559, 560, 565, 566, 567, 567, 570, 572, 573, 574, 576, 577, 578, 586, 587, 588, 589, 591, 593, 594, 595, 596, 597, 599, 600, 601, 604, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 655, 656, 658, 659, 660, 665, 666, 668, 669, 670, 675, 676, 678, 679, 680, 685, 686, 688, 689, 690, 695, 696, 698, 699, 700, 705, 706, 708, 709, 710, 715, 716, 718, 719, 720, 725, 726, 728, 729, 730, 735, 736, 738, 739, 740, 745, 746, 748, 749, 750, 755, 756, 759, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 779, 780, 781, 783, 786, 790, 793, 793, 796, 798, 799, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 842, 843, 846, 848, 849, 850, 851, 852, 853, 858, 859, 860, 862, 863, 864, 865, 870, 871, 872, 874, 875, 876, 876, 879, 881, 882, 883, 889, 890, 891, 892, 893, 894, 895, 897, 898, 900, 905, 906, 907, 908, 909, 910, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 975, 976, 977, 980, 982, 983, 984, 985, 986, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 1002, 1003, 1003, 1006, 1008, 1009, 1016, 1017, 1018, 1019, 1020, 1021, 1026, 1027, 1027, 1030, 1032, 1033, 1046, 1047, 1050, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1068, 1069, 1083, 1088, 1089, 1091, 1096, 1097, 1098, 1099, 1101, 1104, 1105, 1107, 1110, 1111, 1113, 1116, 1117, 1118, 1122, 1123, 1125, 1222, 1223, 1224, 1225, 1230, 1231, 1232, 1234, 1235, 1236, 1239, 1240, 1240, 1243, 1245, 1246, 1247, 1249, 1250, 1251, 1258, 1258, 1261, 1263, 1264, 1265, 1267, 1268, 1269, 1270, 1271, 1279, 1282, 1284, 1285, 1291, 1293, 1294, 1296, 1297, 1298, 1300, 1301, 1306, 1307, 1308, 1309, 1310, 1313, 1314, 1315, 1316, 1319, 1321, 1322, 1328, 1329, 1330, 1331, 1334, 1336, 1337, 1344, 1345, 1346, 1351, 1352, 1353, 1354, 1356, 1357, 1358, 1360, 1363, 1365, 1366, 1368, 1368, 1371, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1384, 1385, 1387, 1388, 1389, 1391, 1392, 1393, 1401, 1402, 1405, 1407, 1409, 1412, 1416, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1432, 1433, 1435, 1436, 1437, 1439, 1440, 1441, 1450, 1451, 1452, 1457, 1458, 1459, 1460, 1462, 1467, 1468, 1469, 1470, 1472, 1477, 1478, 1479, 1480, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1493, 1494, 1507, 1508, 1511, 1513, 1514, 1515, 1516, 1517, 1523, 1524, 1527, 1529, 1530, 1531, 1532, 1533, 1539, 1540, 1568, 1569, 1570, 1575, 1576, 1577, 1578, 1580, 1581, 1582, 1583, 1584, 1589, 1590, 1593, 1594, 1595, 1596, 1597, 1598, 1603, 1604, 1605, 1606, 1609, 1610, 1611, 1613, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1629, 1630, 1631, 1632, 1637, 1638, 1640, 1641, 1642, 1643, 1647, 1652, 1653, 1655, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1743, 1747, 1750, 1754, 1755, 1756, 1757, 1759, 1760, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1769, 1770, 1772, 1773, 1775, 1776, 1777, 1778, 1781, 1782, 1784, 1785, 1787, 1788, 1789, 1790, 1793, 1794, 1796, 1797, 1798, 1800, 1801, 1802, 1803, 1806, 1807, 1809, 1810, 1812, 1813, 1814, 1815, 1818, 1819, 1821, 1822, 1824, 1825, 1826, 1827, 1830, 1831, 1833, 1834, 1836, 1837, 1838, 1839, 1842, 1843, 1845, 1846, 1848, 1849, 1850, 1851, 1854, 1855, 1857, 1858, 1860, 1861, 1862, 1863, 1866, 1867, 1869, 1870, 1872, 1873, 1874, 1875, 1878, 1879, 1881, 1882, 1884, 1885, 1886, 1887, 1890, 1891, 1893, 1894, 1896, 1897, 1898, 1899, 1902, 1903, 1904, 1905, 1907, 1908, 1910, 1914, 1917, 1921, 1922, 1923, 1924, 1926, 1927, 1930, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943, 1944, 1966, 1967, 1968, 1969, 1970, 1971, 1974, 1976, 1977, 1978, 1979, 1980, 1981, 1983, 1985, 1986, 1988, 1989, 1999, 2002, 2006, 2009, 2013, 2016, 2020, 2023, 2027, 2030, 2034, 2037, 2041, 2044, 2048, 2051, 2055, 2058, 2062, 2065, 2069, 2072, 2076, 2079, 2083, 2086, 2090, 2093, 2097, 2100, 2104, 2107, 2111, 2114, 2118, 2121, 2125, 2128, 2132, 2135, 2139, 2142, 2146, 2149, 2153, 2156, 2160, 2163, 2167, 2170, 2174, 2177, 2181, 2184, 2188, 2191, 2195, 2198, 2202, 2205, 2209, 2212, 2216, 2219, 2223, 2226, 2230, 2233, 2237, 2240, 2244, 2247, 2251, 2254, 2258, 2261, 2265, 2268, 2272, 2275, 2279, 2282, 2286, 2289, 2293, 2296, 2300, 2303, 2307, 2310, 2314, 2317, 2321, 2324, 2328, 2331, 2335, 2338, 2342, 2345, 2349, 2352, 2356, 2359, 2363, 2366, 2370, 2373, 2377, 2380, 2384, 2387, 2391, 2394, 2398, 2401, 2405, 2408, 2412, 2415, 2419, 2422, 2426, 2429, 2433, 2436, 2440, 2443, 2447, 2450, 2454, 2457, 2461, 2464, 2468, 2471, 2475};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 61 239
new 0 61 239
assign 1 63 240
new 0 63 240
assign 1 64 241
new 0 64 241
assign 1 65 242
new 0 65 242
assign 1 66 243
new 0 66 243
assign 1 68 244
new 0 68 244
assign 1 69 245
new 0 69 245
assign 1 70 246
new 0 70 246
assign 1 71 247
new 0 71 247
assign 1 72 248
new 0 72 248
assign 1 73 249
new 0 73 249
assign 1 74 250
new 0 74 250
assign 1 78 251
new 0 78 251
assign 1 80 252
new 1 80 252
assign 1 81 253
ntypesGet 0 81 253
assign 1 82 254
twtokGet 0 82 254
assign 1 83 255
new 0 83 255
assign 1 83 256
new 1 83 256
assign 1 86 257
new 0 86 257
assign 1 89 258
new 0 89 258
assign 1 90 259
new 0 90 259
assign 1 96 260
new 0 96 260
assign 1 97 261
new 0 97 261
assign 1 98 262
new 0 98 262
assign 1 99 263
new 0 99 263
assign 1 99 264
new 1 99 264
assign 1 104 276
def 1 104 281
assign 1 104 282
new 0 104 282
assign 1 104 283
equals 1 104 283
assign 1 0 285
assign 1 104 288
new 0 104 288
assign 1 104 289
ends 1 104 289
assign 1 0 291
assign 1 0 294
assign 1 0 298
assign 1 0 301
assign 1 0 305
assign 1 105 308
new 0 105 308
return 1 105 309
assign 1 107 311
new 0 107 311
return 1 107 312
assign 1 111 318
new 0 111 318
assign 1 111 319
new 0 111 319
assign 1 111 320
swap 2 111 320
return 1 111 321
assign 1 115 327
new 0 115 327
assign 1 115 328
argsGet 0 115 328
assign 1 116 329
main 1 116 329
exit 1 116 330
assign 1 120 335
assign 1 121 336
new 1 121 336
assign 1 122 337
go 0 122 337
return 1 122 338
assign 1 126 346
new 0 126 346
config 0 127 347
assign 1 128 348
new 0 128 348
assign 1 130 350
new 0 130 350
assign 1 131 351
doWhat 0 131 351
assign 1 132 352
new 0 132 352
assign 1 134 356
toString 0 134 356
assign 1 135 357
new 0 135 357
assign 1 136 358
new 0 136 358
assign 1 136 359
add 1 136 359
assign 1 137 360
new 0 137 360
assign 1 0 363
assign 1 0 367
assign 1 0 370
print 0 140 374
return 1 142 376
assign 1 146 396
nameGet 0 146 396
assign 1 146 397
new 0 146 397
assign 1 146 398
equals 1 146 398
assign 1 147 400
new 0 147 400
assign 1 147 401
add 1 147 401
assign 1 147 402
add 1 147 402
assign 1 147 403
add 1 147 403
assign 1 148 404
new 0 148 404
assign 1 148 405
add 1 148 405
assign 1 148 406
add 1 148 406
assign 1 149 407
new 0 149 407
assign 1 149 408
add 1 149 408
assign 1 149 409
add 1 149 409
assign 1 150 410
new 0 150 410
assign 1 150 411
add 1 150 411
assign 1 150 412
add 1 150 412
assign 1 150 413
add 1 150 413
assign 1 151 414
new 0 151 414
assign 1 151 415
add 1 151 415
assign 1 151 416
add 1 151 416
assign 1 152 417
new 0 152 417
assign 1 152 418
add 1 152 418
assign 1 152 419
add 1 152 419
return 1 154 421
assign 1 159 557
new 0 159 557
assign 1 161 558
new 0 161 558
assign 1 162 559
get 1 162 559
assign 1 162 560
def 1 162 565
assign 1 163 566
get 1 163 566
assign 1 163 567
iteratorGet 0 0 567
assign 1 163 570
hasNextGet 0 163 570
assign 1 163 572
nextGet 0 163 572
assign 1 164 573
has 1 164 573
assign 1 164 574
not 0 164 574
put 1 165 576
assign 1 166 577
new 1 166 577
addFile 1 166 578
assign 1 171 586
new 0 171 586
assign 1 171 587
nameGet 0 171 587
assign 1 171 588
new 0 171 588
assign 1 171 589
equals 1 171 589
preProcessorSet 1 172 591
assign 1 174 593
new 0 174 593
assign 1 174 594
get 1 174 594
assign 1 174 595
firstGet 0 174 595
assign 1 175 596
new 0 175 596
assign 1 175 597
has 1 175 597
assign 1 176 599
new 0 176 599
assign 1 176 600
get 1 176 600
assign 1 176 601
firstGet 0 176 601
assign 1 178 604
assign 1 180 606
new 0 180 606
assign 1 180 607
new 0 180 607
assign 1 180 608
get 2 180 608
assign 1 180 609
firstGet 0 180 609
assign 1 180 610
new 1 180 610
assign 1 180 611
pathGet 0 180 611
addStep 1 181 612
assign 1 182 613
new 0 182 613
addStep 1 182 614
assign 1 183 615
new 0 183 615
assign 1 183 616
new 0 183 616
assign 1 183 617
get 2 183 617
assign 1 183 618
firstGet 0 183 618
assign 1 183 619
new 1 183 619
assign 1 183 620
pathGet 0 183 620
assign 1 184 621
new 0 184 621
assign 1 184 622
new 0 184 622
assign 1 184 623
nameGet 0 184 623
assign 1 184 624
get 2 184 624
assign 1 184 625
firstGet 0 184 625
assign 1 184 626
new 1 184 626
assign 1 185 627
new 0 185 627
assign 1 185 628
nameGet 0 185 628
assign 1 185 629
get 2 185 629
assign 1 185 630
firstGet 0 185 630
assign 1 185 631
new 1 185 631
assign 1 186 632
new 0 186 632
assign 1 186 633
new 0 186 633
assign 1 186 634
get 2 186 634
assign 1 186 635
firstGet 0 186 635
assign 1 186 636
new 1 186 636
assign 1 187 637
new 0 187 637
assign 1 187 638
new 0 187 638
assign 1 187 639
get 2 187 639
assign 1 187 640
firstGet 0 187 640
assign 1 187 641
new 1 187 641
assign 1 189 642
new 0 189 642
assign 1 189 643
get 1 189 643
assign 1 189 644
firstGet 0 189 644
assign 1 190 645
new 0 190 645
assign 1 190 646
get 1 190 646
assign 1 190 647
firstGet 0 190 647
assign 1 191 648
new 0 191 648
assign 1 191 649
get 1 191 649
assign 1 192 650
undef 1 192 655
assign 1 193 656
new 0 193 656
assign 1 195 658
new 0 195 658
assign 1 195 659
get 1 195 659
assign 1 196 660
undef 1 196 665
assign 1 197 666
new 0 197 666
assign 1 199 668
new 0 199 668
assign 1 199 669
get 1 199 669
assign 1 200 670
undef 1 200 675
assign 1 201 676
new 0 201 676
assign 1 203 678
new 0 203 678
assign 1 203 679
get 1 203 679
assign 1 204 680
undef 1 204 685
assign 1 205 686
new 0 205 686
assign 1 207 688
new 0 207 688
assign 1 207 689
get 1 207 689
assign 1 208 690
undef 1 208 695
assign 1 209 696
new 0 209 696
assign 1 211 698
new 0 211 698
assign 1 211 699
get 1 211 699
assign 1 212 700
undef 1 212 705
assign 1 213 706
new 0 213 706
assign 1 215 708
new 0 215 708
assign 1 215 709
get 1 215 709
assign 1 216 710
undef 1 216 715
assign 1 217 716
new 0 217 716
assign 1 219 718
new 0 219 718
assign 1 219 719
get 1 219 719
assign 1 220 720
undef 1 220 725
assign 1 221 726
new 0 221 726
assign 1 223 728
new 0 223 728
assign 1 223 729
get 1 223 729
assign 1 224 730
undef 1 224 735
assign 1 225 736
new 0 225 736
assign 1 227 738
new 0 227 738
assign 1 227 739
get 1 227 739
assign 1 228 740
def 1 228 745
assign 1 229 746
firstGet 0 229 746
assign 1 231 748
new 0 231 748
assign 1 231 749
get 1 231 749
assign 1 232 750
def 1 232 755
assign 1 233 756
firstGet 0 233 756
assign 1 235 759
new 0 235 759
assign 1 237 761
new 0 237 761
assign 1 237 762
new 0 237 762
assign 1 237 763
isTrue 2 237 763
assign 1 238 764
new 0 238 764
assign 1 238 765
new 0 238 765
assign 1 238 766
isTrue 2 238 766
assign 1 239 767
new 0 239 767
assign 1 239 768
isTrue 1 239 768
assign 1 240 769
new 0 240 769
assign 1 240 770
isTrue 1 240 770
assign 1 241 771
new 0 241 771
assign 1 242 772
new 0 242 772
assign 1 242 773
get 1 242 773
assign 1 243 774
def 1 243 779
assign 1 243 780
isEmptyGet 0 243 780
assign 1 243 781
not 0 243 781
assign 1 0 783
assign 1 0 786
assign 1 0 790
assign 1 244 793
iteratorGet 0 0 793
assign 1 244 796
hasNextGet 0 244 796
assign 1 244 798
nextGet 0 244 798
put 1 245 799
assign 1 248 806
new 0 248 806
assign 1 248 807
isTrue 1 248 807
assign 1 249 808
new 0 249 808
assign 1 249 809
isTrue 1 249 809
assign 1 250 810
new 0 250 810
assign 1 250 811
isTrue 1 250 811
assign 1 251 812
new 0 251 812
assign 1 251 813
new 0 251 813
assign 1 251 814
isTrue 2 251 814
assign 1 252 815
new 0 252 815
assign 1 252 816
get 1 252 816
assign 1 253 817
new 0 253 817
assign 1 253 818
get 1 253 818
assign 1 254 819
new 0 254 819
assign 1 254 820
new 0 254 820
assign 1 254 821
get 2 254 821
assign 1 254 822
firstGet 0 254 822
assign 1 255 823
new 0 255 823
assign 1 255 824
new 0 255 824
assign 1 255 825
get 2 255 825
assign 1 255 826
firstGet 0 255 826
assign 1 256 827
new 0 256 827
assign 1 256 828
add 1 256 828
assign 1 256 829
new 0 256 829
assign 1 256 830
get 2 256 830
assign 1 256 831
firstGet 0 256 831
assign 1 257 832
new 0 257 832
assign 1 258 833
new 0 258 833
assign 1 259 834
new 0 259 834
assign 1 260 835
new 0 260 835
assign 1 261 836
new 0 261 836
assign 1 264 837
def 1 264 842
assign 1 265 843
firstGet 0 265 843
assign 1 267 846
new 0 267 846
assign 1 274 848
new 0 274 848
assign 1 274 849
add 1 274 849
assign 1 274 850
nameGet 0 274 850
assign 1 274 851
add 1 274 851
assign 1 274 852
get 1 274 852
assign 1 275 853
def 1 275 858
assign 1 276 859
orderedGet 0 276 859
addAll 1 276 860
assign 1 279 862
new 0 279 862
assign 1 279 863
add 1 279 863
assign 1 279 864
get 1 279 864
assign 1 280 865
def 1 280 870
assign 1 281 871
orderedGet 0 281 871
addAll 1 281 872
assign 1 284 874
new 0 284 874
assign 1 285 875
orderedGet 0 285 875
assign 1 285 876
iteratorGet 0 0 876
assign 1 285 879
hasNextGet 0 285 879
assign 1 285 881
nextGet 0 285 881
assign 1 286 882
new 1 286 882
addValue 1 286 883
assign 1 288 889
newlineGet 0 288 889
assign 1 289 890
assign 1 290 891
new 1 290 891
assign 1 292 892
copy 0 292 892
assign 1 293 893
fileGet 0 293 893
assign 1 293 894
existsGet 0 293 894
assign 1 293 895
not 0 293 895
assign 1 294 897
fileGet 0 294 897
makeDirs 0 294 898
assign 1 296 900
def 1 296 905
assign 1 297 906
new 1 297 906
assign 1 297 907
readerGet 0 297 907
assign 1 298 908
open 0 298 908
assign 1 298 909
readString 1 298 909
close 0 299 910
assign 1 305 924
classNameGet 0 305 924
assign 1 306 925
add 1 306 925
assign 1 306 926
new 0 306 926
assign 1 306 927
add 1 306 927
assign 1 306 928
toString 0 306 928
assign 1 306 929
add 1 306 929
assign 1 307 930
add 1 307 930
assign 1 307 931
new 0 307 931
assign 1 307 932
add 1 307 932
assign 1 307 933
toString 0 307 933
assign 1 307 934
add 1 307 934
return 1 308 935
assign 1 312 975
new 0 312 975
assign 1 313 976
classesGet 0 313 976
assign 1 313 977
valueIteratorGet 0 313 977
assign 1 313 980
hasNextGet 0 313 980
assign 1 314 982
nextGet 0 314 982
assign 1 315 983
shouldEmitGet 0 315 983
assign 1 315 984
heldGet 0 315 984
assign 1 315 985
fromFileGet 0 315 985
assign 1 315 986
has 1 315 986
assign 1 316 988
heldGet 0 316 988
assign 1 316 989
namepathGet 0 316 989
assign 1 316 990
toString 0 316 990
put 1 316 991
assign 1 317 992
usedByGet 0 317 992
assign 1 317 993
heldGet 0 317 993
assign 1 317 994
namepathGet 0 317 994
assign 1 317 995
toString 0 317 995
assign 1 317 996
get 1 317 996
assign 1 318 997
def 1 318 1002
assign 1 319 1003
iteratorGet 0 0 1003
assign 1 319 1006
hasNextGet 0 319 1006
assign 1 319 1008
nextGet 0 319 1008
put 1 320 1009
assign 1 323 1016
subClassesGet 0 323 1016
assign 1 323 1017
heldGet 0 323 1017
assign 1 323 1018
namepathGet 0 323 1018
assign 1 323 1019
toString 0 323 1019
assign 1 323 1020
get 1 323 1020
assign 1 324 1021
def 1 324 1026
assign 1 325 1027
iteratorGet 0 0 1027
assign 1 325 1030
hasNextGet 0 325 1030
assign 1 325 1032
nextGet 0 325 1032
put 1 326 1033
assign 1 331 1046
classesGet 0 331 1046
assign 1 331 1047
valueIteratorGet 0 331 1047
assign 1 331 1050
hasNextGet 0 331 1050
assign 1 332 1052
nextGet 0 332 1052
assign 1 333 1053
heldGet 0 333 1053
assign 1 333 1054
heldGet 0 333 1054
assign 1 333 1055
namepathGet 0 333 1055
assign 1 333 1056
toString 0 333 1056
assign 1 333 1057
has 1 333 1057
shouldWriteSet 1 333 1058
assign 1 340 1068
new 0 340 1068
return 1 340 1069
assign 1 344 1083
def 1 344 1088
return 1 345 1089
assign 1 350 1091
def 1 350 1096
assign 1 351 1097
firstGet 0 351 1097
assign 1 352 1098
new 0 352 1098
assign 1 352 1099
equals 1 352 1099
assign 1 353 1101
new 1 353 1101
assign 1 354 1104
new 0 354 1104
assign 1 354 1105
equals 1 354 1105
assign 1 355 1107
new 1 355 1107
assign 1 356 1110
new 0 356 1110
assign 1 356 1111
equals 1 356 1111
assign 1 357 1113
new 1 357 1113
assign 1 359 1116
new 0 359 1116
assign 1 359 1117
new 1 359 1117
throw 1 359 1118
dynConditionsAllSet 1 361 1122
return 1 362 1123
return 1 364 1125
assign 1 369 1222
now 0 369 1222
assign 1 370 1223
new 0 370 1223
assign 1 371 1224
emitterGet 0 371 1224
assign 1 372 1225
def 1 372 1230
assign 1 373 1231
new 4 373 1231
put 1 374 1232
assign 1 376 1234
new 0 376 1234
assign 1 376 1235
add 1 376 1235
print 0 376 1236
assign 1 379 1239
new 0 379 1239
assign 1 381 1240
iteratorGet 0 0 1240
assign 1 381 1243
hasNextGet 0 381 1243
assign 1 381 1245
nextGet 0 381 1245
assign 1 382 1246
has 1 382 1246
assign 1 382 1247
not 0 382 1247
put 1 383 1249
assign 1 384 1250
new 2 384 1250
addValue 1 385 1251
assign 1 388 1258
iteratorGet 0 0 1258
assign 1 388 1261
hasNextGet 0 388 1261
assign 1 388 1263
nextGet 0 388 1263
assign 1 389 1264
has 1 389 1264
assign 1 389 1265
not 0 389 1265
put 1 390 1267
assign 1 391 1268
new 2 391 1268
addValue 1 392 1269
assign 1 393 1270
libNameGet 0 393 1270
put 1 393 1271
assign 1 398 1279
iteratorGet 0 398 1279
assign 1 398 1282
hasNextGet 0 398 1282
assign 1 399 1284
nextGet 0 399 1284
doParse 1 401 1285
buildSyns 1 403 1291
assign 1 406 1293
now 0 406 1293
assign 1 406 1294
subtract 1 406 1294
assign 1 408 1296
new 0 408 1296
assign 1 408 1297
add 1 408 1297
print 0 408 1298
assign 1 410 1300
emitCommonGet 0 410 1300
assign 1 410 1301
def 1 410 1306
assign 1 412 1307
emitCommonGet 0 412 1307
doEmit 0 412 1308
assign 1 413 1309
new 0 413 1309
return 1 413 1310
setClassesToWrite 0 416 1313
libnameInfoGet 0 417 1314
assign 1 419 1315
classesGet 0 419 1315
assign 1 419 1316
valueIteratorGet 0 419 1316
assign 1 419 1319
hasNextGet 0 419 1319
assign 1 420 1321
nextGet 0 420 1321
doEmit 1 421 1322
emitMain 0 423 1328
emitCUInit 0 424 1329
assign 1 425 1330
classesGet 0 425 1330
assign 1 425 1331
valueIteratorGet 0 425 1331
assign 1 425 1334
hasNextGet 0 425 1334
assign 1 426 1336
nextGet 0 426 1336
emitSyn 1 427 1337
assign 1 431 1344
now 0 431 1344
assign 1 431 1345
subtract 1 431 1345
assign 1 432 1346
def 1 432 1351
assign 1 433 1352
new 0 433 1352
assign 1 433 1353
add 1 433 1353
print 0 433 1354
assign 1 435 1356
new 0 435 1356
assign 1 435 1357
add 1 435 1357
print 0 435 1358
prepMake 1 438 1360
assign 1 442 1363
not 0 442 1363
make 1 443 1365
deployLibrary 1 444 1366
assign 1 446 1368
iteratorGet 0 0 1368
assign 1 446 1371
hasNextGet 0 446 1371
assign 1 446 1373
nextGet 0 446 1373
assign 1 447 1374
libnameInfoGet 0 447 1374
assign 1 447 1375
unitShlibGet 0 447 1375
assign 1 448 1376
emitPathGet 0 448 1376
assign 1 448 1377
copy 0 448 1377
assign 1 449 1378
stepsGet 0 449 1378
assign 1 449 1379
lastGet 0 449 1379
addStep 1 449 1380
assign 1 450 1381
fileGet 0 450 1381
assign 1 450 1382
existsGet 0 450 1382
assign 1 451 1384
fileGet 0 451 1384
delete 0 451 1385
assign 1 453 1387
fileGet 0 453 1387
assign 1 453 1388
existsGet 0 453 1388
assign 1 453 1389
not 0 453 1389
assign 1 454 1391
fileGet 0 454 1391
assign 1 454 1392
fileGet 0 454 1392
deployFile 2 454 1393
assign 1 458 1401
iteratorGet 0 458 1401
assign 1 459 1402
iteratorGet 0 459 1402
assign 1 461 1405
hasNextGet 0 461 1405
assign 1 461 1407
hasNextGet 0 461 1407
assign 1 0 1409
assign 1 0 1412
assign 1 0 1416
assign 1 462 1419
nextGet 0 462 1419
assign 1 462 1420
apNew 1 462 1420
assign 1 463 1421
emitPathGet 0 463 1421
assign 1 463 1422
copy 0 463 1422
assign 1 463 1423
toString 0 463 1423
assign 1 463 1424
new 0 463 1424
assign 1 463 1425
add 1 463 1425
assign 1 463 1426
nextGet 0 463 1426
assign 1 463 1427
add 1 463 1427
assign 1 463 1428
apNew 1 463 1428
assign 1 465 1429
fileGet 0 465 1429
assign 1 465 1430
existsGet 0 465 1430
assign 1 466 1432
fileGet 0 466 1432
delete 0 466 1433
assign 1 468 1435
fileGet 0 468 1435
assign 1 468 1436
existsGet 0 468 1436
assign 1 468 1437
not 0 468 1437
assign 1 469 1439
fileGet 0 469 1439
assign 1 469 1440
fileGet 0 469 1440
deployFile 2 469 1441
assign 1 474 1450
now 0 474 1450
assign 1 474 1451
subtract 1 474 1451
assign 1 476 1452
def 1 476 1457
assign 1 477 1458
new 0 477 1458
assign 1 477 1459
add 1 477 1459
print 0 477 1460
assign 1 479 1462
def 1 479 1467
assign 1 480 1468
new 0 480 1468
assign 1 480 1469
add 1 480 1469
print 0 480 1470
assign 1 482 1472
def 1 482 1477
assign 1 483 1478
new 0 483 1478
assign 1 483 1479
add 1 483 1479
print 0 483 1480
assign 1 487 1483
new 0 487 1483
print 0 487 1484
assign 1 488 1485
run 2 488 1485
assign 1 489 1486
new 0 489 1486
assign 1 489 1487
add 1 489 1487
assign 1 489 1488
new 0 489 1488
assign 1 489 1489
add 1 489 1489
print 0 489 1490
return 1 490 1491
assign 1 492 1493
new 0 492 1493
return 1 492 1494
assign 1 496 1507
justParsedGet 0 496 1507
assign 1 496 1508
valueIteratorGet 0 496 1508
assign 1 496 1511
hasNextGet 0 496 1511
assign 1 497 1513
nextGet 0 497 1513
assign 1 498 1514
heldGet 0 498 1514
libNameSet 1 498 1515
assign 1 499 1516
getSyn 2 499 1516
libNameSet 1 500 1517
assign 1 502 1523
justParsedGet 0 502 1523
assign 1 502 1524
valueIteratorGet 0 502 1524
assign 1 502 1527
hasNextGet 0 502 1527
assign 1 503 1529
nextGet 0 503 1529
assign 1 504 1530
heldGet 0 504 1530
assign 1 504 1531
synGet 0 504 1531
checkInheritance 2 505 1532
integrate 1 506 1533
assign 1 508 1539
new 0 508 1539
justParsedSet 1 508 1540
assign 1 512 1568
heldGet 0 512 1568
assign 1 512 1569
synGet 0 512 1569
assign 1 512 1570
def 1 512 1575
assign 1 513 1576
heldGet 0 513 1576
assign 1 513 1577
synGet 0 513 1577
return 1 513 1578
assign 1 515 1580
heldGet 0 515 1580
libNameSet 1 515 1581
assign 1 516 1582
heldGet 0 516 1582
assign 1 516 1583
extendsGet 0 516 1583
assign 1 516 1584
undef 1 516 1589
assign 1 517 1590
new 1 517 1590
assign 1 519 1593
classesGet 0 519 1593
assign 1 519 1594
heldGet 0 519 1594
assign 1 519 1595
extendsGet 0 519 1595
assign 1 519 1596
toString 0 519 1596
assign 1 519 1597
get 1 519 1597
assign 1 521 1598
def 1 521 1603
assign 1 522 1604
heldGet 0 522 1604
libNameSet 1 522 1605
assign 1 523 1606
getSyn 2 523 1606
assign 1 526 1609
heldGet 0 526 1609
assign 1 526 1610
extendsGet 0 526 1610
assign 1 526 1611
loadSyn 1 526 1611
assign 1 528 1613
new 2 528 1613
assign 1 530 1615
heldGet 0 530 1615
synSet 1 530 1616
assign 1 531 1617
heldGet 0 531 1617
assign 1 531 1618
namepathGet 0 531 1618
assign 1 531 1619
toString 0 531 1619
addSynClass 2 531 1620
return 1 532 1621
assign 1 536 1629
toString 0 536 1629
assign 1 537 1630
synClassesGet 0 537 1630
assign 1 537 1631
get 1 537 1631
assign 1 538 1632
def 1 538 1637
return 1 539 1638
assign 1 545 1640
emitterGet 0 545 1640
assign 1 545 1641
loadSyn 1 545 1641
addSynClass 2 546 1642
return 1 547 1643
assign 1 554 1647
undef 1 554 1652
assign 1 555 1653
new 1 555 1653
return 1 557 1655
assign 1 562 1734
new 1 562 1734
assign 1 563 1735
new 0 563 1735
assign 1 564 1736
emitterGet 0 564 1736
assign 1 565 1737
assign 1 566 1738
new 0 566 1738
assign 1 567 1739
shouldEmitGet 0 567 1739
put 1 567 1740
assign 1 0 1743
assign 1 0 1747
assign 1 0 1750
assign 1 570 1754
new 0 570 1754
assign 1 570 1755
toString 0 570 1755
assign 1 570 1756
add 1 570 1756
print 0 570 1757
assign 1 572 1759
assign 1 574 1760
fileGet 0 574 1760
assign 1 574 1761
readerGet 0 574 1761
assign 1 574 1762
open 0 574 1762
assign 1 574 1763
readBuffer 1 574 1763
assign 1 575 1764
fileGet 0 575 1764
assign 1 575 1765
readerGet 0 575 1765
close 0 575 1766
assign 1 576 1767
tokenize 1 576 1767
assign 1 584 1769
new 0 584 1769
echo 0 584 1770
assign 1 586 1772
outermostGet 0 586 1772
nodify 2 586 1773
assign 1 588 1775
new 0 588 1775
print 0 588 1776
assign 1 589 1777
new 2 589 1777
traverse 1 589 1778
assign 1 593 1781
new 0 593 1781
echo 0 593 1782
assign 1 595 1784
new 0 595 1784
traverse 1 595 1785
assign 1 597 1787
new 0 597 1787
print 0 597 1788
assign 1 598 1789
new 2 598 1789
traverse 1 598 1790
assign 1 601 1793
new 0 601 1793
echo 0 601 1794
assign 1 604 1796
new 0 604 1796
traverse 1 604 1797
contain 0 605 1798
assign 1 607 1800
new 0 607 1800
print 0 607 1801
assign 1 608 1802
new 2 608 1802
traverse 1 608 1803
assign 1 612 1806
new 0 612 1806
echo 0 612 1807
assign 1 614 1809
new 0 614 1809
traverse 1 614 1810
assign 1 616 1812
new 0 616 1812
print 0 616 1813
assign 1 617 1814
new 2 617 1814
traverse 1 617 1815
assign 1 621 1818
new 0 621 1818
echo 0 621 1819
assign 1 623 1821
new 0 623 1821
traverse 1 623 1822
assign 1 625 1824
new 0 625 1824
print 0 625 1825
assign 1 626 1826
new 2 626 1826
traverse 1 626 1827
assign 1 630 1830
new 0 630 1830
echo 0 630 1831
assign 1 632 1833
new 0 632 1833
traverse 1 632 1834
assign 1 634 1836
new 0 634 1836
print 0 634 1837
assign 1 635 1838
new 2 635 1838
traverse 1 635 1839
assign 1 639 1842
new 0 639 1842
echo 0 639 1843
assign 1 641 1845
new 0 641 1845
traverse 1 641 1846
assign 1 643 1848
new 0 643 1848
print 0 643 1849
assign 1 644 1850
new 2 644 1850
traverse 1 644 1851
assign 1 648 1854
new 0 648 1854
echo 0 648 1855
assign 1 650 1857
new 0 650 1857
traverse 1 650 1858
assign 1 652 1860
new 0 652 1860
print 0 652 1861
assign 1 653 1862
new 2 653 1862
traverse 1 653 1863
assign 1 657 1866
new 0 657 1866
echo 0 657 1867
assign 1 659 1869
new 0 659 1869
traverse 1 659 1870
assign 1 661 1872
new 0 661 1872
print 0 661 1873
assign 1 662 1874
new 2 662 1874
traverse 1 662 1875
assign 1 666 1878
new 0 666 1878
echo 0 666 1879
assign 1 668 1881
new 0 668 1881
traverse 1 668 1882
assign 1 670 1884
new 0 670 1884
print 0 670 1885
assign 1 671 1886
new 2 671 1886
traverse 1 671 1887
assign 1 674 1890
new 0 674 1890
echo 0 674 1891
assign 1 676 1893
new 0 676 1893
traverse 1 676 1894
assign 1 678 1896
new 0 678 1896
print 0 678 1897
assign 1 679 1898
new 2 679 1898
traverse 1 679 1899
assign 1 683 1902
new 0 683 1902
echo 0 683 1903
assign 1 684 1904
new 0 684 1904
print 0 684 1905
assign 1 686 1907
new 0 686 1907
traverse 1 686 1908
assign 1 0 1910
assign 1 0 1914
assign 1 0 1917
assign 1 688 1921
new 0 688 1921
print 0 688 1922
assign 1 689 1923
new 2 689 1923
traverse 1 689 1924
assign 1 691 1926
classesGet 0 691 1926
assign 1 691 1927
valueIteratorGet 0 691 1927
assign 1 691 1930
hasNextGet 0 691 1930
assign 1 692 1932
nextGet 0 692 1932
assign 1 694 1933
transUnitGet 0 694 1933
assign 1 695 1934
new 1 695 1934
assign 1 696 1935
TRANSUNITGet 0 696 1935
typenameSet 1 696 1936
assign 1 697 1937
new 0 697 1937
assign 1 698 1938
heldGet 0 698 1938
assign 1 698 1939
emitsGet 0 698 1939
emitsSet 1 698 1940
heldSet 1 699 1941
delete 0 700 1942
addValue 1 701 1943
copyLoc 1 702 1944
reInitContained 0 708 1966
assign 1 709 1967
containedGet 0 709 1967
assign 1 710 1968
new 0 710 1968
assign 1 711 1969
new 0 711 1969
assign 1 711 1970
crGet 0 711 1970
assign 1 712 1971
iteratorGet 0 712 1971
assign 1 712 1974
hasNextGet 0 712 1974
assign 1 713 1976
new 1 713 1976
assign 1 714 1977
nextGet 0 714 1977
heldSet 1 714 1978
nlcSet 1 715 1979
assign 1 716 1980
heldGet 0 716 1980
assign 1 716 1981
equals 1 716 1981
assign 1 717 1983
increment 0 717 1983
assign 1 719 1985
heldGet 0 719 1985
assign 1 719 1986
notEquals 1 719 1986
addValue 1 720 1988
containerSet 1 721 1989
return 1 0 1999
assign 1 0 2002
return 1 0 2006
assign 1 0 2009
return 1 0 2013
assign 1 0 2016
return 1 0 2020
assign 1 0 2023
return 1 0 2027
assign 1 0 2030
return 1 0 2034
assign 1 0 2037
return 1 0 2041
assign 1 0 2044
return 1 0 2048
assign 1 0 2051
return 1 0 2055
assign 1 0 2058
return 1 0 2062
assign 1 0 2065
return 1 0 2069
assign 1 0 2072
return 1 0 2076
assign 1 0 2079
return 1 0 2083
assign 1 0 2086
return 1 0 2090
assign 1 0 2093
return 1 0 2097
assign 1 0 2100
return 1 0 2104
assign 1 0 2107
return 1 0 2111
assign 1 0 2114
return 1 0 2118
assign 1 0 2121
return 1 0 2125
assign 1 0 2128
return 1 0 2132
assign 1 0 2135
return 1 0 2139
assign 1 0 2142
return 1 0 2146
assign 1 0 2149
return 1 0 2153
assign 1 0 2156
return 1 0 2160
assign 1 0 2163
return 1 0 2167
assign 1 0 2170
return 1 0 2174
assign 1 0 2177
return 1 0 2181
assign 1 0 2184
return 1 0 2188
assign 1 0 2191
return 1 0 2195
assign 1 0 2198
return 1 0 2202
assign 1 0 2205
return 1 0 2209
assign 1 0 2212
return 1 0 2216
assign 1 0 2219
return 1 0 2223
assign 1 0 2226
return 1 0 2230
assign 1 0 2233
return 1 0 2237
assign 1 0 2240
return 1 0 2244
assign 1 0 2247
return 1 0 2251
assign 1 0 2254
return 1 0 2258
assign 1 0 2261
return 1 0 2265
assign 1 0 2268
return 1 0 2272
assign 1 0 2275
return 1 0 2279
assign 1 0 2282
return 1 0 2286
assign 1 0 2289
return 1 0 2293
assign 1 0 2296
return 1 0 2300
assign 1 0 2303
return 1 0 2307
assign 1 0 2310
return 1 0 2314
assign 1 0 2317
return 1 0 2321
assign 1 0 2324
return 1 0 2328
assign 1 0 2331
return 1 0 2335
assign 1 0 2338
return 1 0 2342
assign 1 0 2345
return 1 0 2349
assign 1 0 2352
return 1 0 2356
assign 1 0 2359
return 1 0 2363
assign 1 0 2366
return 1 0 2370
assign 1 0 2373
return 1 0 2377
assign 1 0 2380
return 1 0 2384
assign 1 0 2387
return 1 0 2391
assign 1 0 2394
return 1 0 2398
assign 1 0 2401
return 1 0 2405
assign 1 0 2408
return 1 0 2412
assign 1 0 2415
return 1 0 2419
assign 1 0 2422
return 1 0 2426
assign 1 0 2429
return 1 0 2433
assign 1 0 2436
return 1 0 2440
assign 1 0 2443
return 1 0 2447
assign 1 0 2450
return 1 0 2454
assign 1 0 2457
return 1 0 2461
assign 1 0 2464
return 1 0 2468
assign 1 0 2471
assign 1 0 2475
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 404051026: return bem_printPlacesGet_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 902949587: return bem_printStepsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 392968773: return bem_printPlacesSet_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 891867334: return bem_printStepsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_9_5_ContainerArray) bevd_0);
case 593264218: return bem_isNewish_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_BuildBuild.bevs_inst = (BEC_5_5_BuildBuild)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_BuildBuild.bevs_inst;
}
}
