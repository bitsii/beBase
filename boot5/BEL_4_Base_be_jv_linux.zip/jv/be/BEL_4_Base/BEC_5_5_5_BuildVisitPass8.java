package be.BEL_4_Base;
/* IO:File: source/build/Pass8.be */
public class BEC_5_5_5_BuildVisitPass8 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass8() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bels_24 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_25 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_26 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_27 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_28 = {0x3D,0x40};
private static byte[] bels_29 = {0x3D,0x23};
public static BEC_5_5_5_BuildVisitPass8 bevs_inst;
public BEC_6_6_SystemObject bem_acceptClass_1(BEC_6_6_SystemObject beva_node) throws Throwable {
BEC_5_8_BuildEmitData bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_0_tmpvar_phold.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_prepOps_0() throws Throwable {
BEC_6_6_SystemObject bevl_ops = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(10));
bevl_ops = (new BEC_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 25 */ {
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(10));
bevt_1_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 25 */ {
bevt_3_tmpvar_phold = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 25 */
 else  /* Line: 25 */ {
break;
} /* Line: 25 */
} /* Line: 25 */
return bevl_ops;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_it = null;
BEC_6_6_SystemObject bevl_prec = null;
BEC_6_6_SystemObject bevl_cont = null;
BEC_6_6_SystemObject bevl_ops = null;
BEC_6_6_SystemObject bevl_onode = null;
BEC_6_6_SystemObject bevl_mo = null;
BEC_6_6_SystemObject bevl_inode = null;
BEC_6_6_SystemObject bevl_mt = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_30_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 35 */ {
this.bem_acceptClass_1(beva_node);
bevt_5_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpvar_phold;
} /* Line: 37 */
bevt_6_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_7_tmpvar_phold = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_tmpvar_phold.bem_get_1(bevt_7_tmpvar_phold);
if (bevl_prec == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 40 */ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = this.bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
 /* Line: 50 */ {
if (bevl_onode == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 50 */ {
if (bevl_prec == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 50 */ {
bevt_12_tmpvar_phold = bevl_onode.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_cont);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 50 */ {
bevt_13_tmpvar_phold = bevl_ops.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_prec);
bevt_13_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_onode);
bevl_inode = bevl_onode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevt_17_tmpvar_phold = bevl_inode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_18_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 56 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 58 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 59 */
} /* Line: 58 */
} /* Line: 56 */
} /* Line: 55 */
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_21_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_22_tmpvar_phold = bevl_onode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevl_prec = bevt_21_tmpvar_phold.bem_get_1(bevt_22_tmpvar_phold);
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_prec = null;
} /* Line: 68 */
} /* Line: 65 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
bevl_prec = (new BEC_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 72 */ {
bevt_23_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 72 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_i.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 74 */ {
bevl_mt = bevl_i.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 75 */ {
bevt_27_tmpvar_phold = bevl_mt.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 75 */ {
bevl_mo = bevl_mt.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_28_tmpvar_phold = bevl_mo.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
bevt_29_tmpvar_phold = bevl_mo.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_mo = this.bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_tmpvar_phold, bevt_29_tmpvar_phold);
beva_node = (BEC_5_4_BuildNode) bevl_mo;
} /* Line: 78 */
 else  /* Line: 75 */ {
break;
} /* Line: 75 */
} /* Line: 75 */
} /* Line: 75 */
bevl_prec = bevl_prec.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 81 */
 else  /* Line: 72 */ {
break;
} /* Line: 72 */
} /* Line: 72 */
} /* Line: 72 */
bevt_30_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_callFromOper_4(BEC_6_6_SystemObject beva_op, BEC_6_6_SystemObject beva_prec, BEC_6_6_SystemObject beva_pr, BEC_6_6_SystemObject beva_nx) throws Throwable {
BEC_6_6_SystemObject bevl_gc = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
bevl_gc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1795527427, BEL_4_Base.bevn_wasOperSet_1, bevt_2_tmpvar_phold);
bevt_5_tmpvar_phold = bevp_const.bem_operNamesGet_0();
bevt_6_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_get_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(357005938, BEL_4_Base.bevn_lower_0);
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_3_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(10, bels_0));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 93 */ {
bevt_10_tmpvar_phold = (new BEC_4_6_TextString(9, bels_1));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_10_tmpvar_phold);
} /* Line: 94 */
bevt_12_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = (new BEC_4_6_TextString(13, bels_2));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_13_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 96 */ {
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(12, bels_3));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_14_tmpvar_phold);
} /* Line: 97 */
bevt_16_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(14, bels_4));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 99 */ {
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(13, bels_5));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_18_tmpvar_phold);
} /* Line: 100 */
bevt_20_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(9, bels_6));
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold != null && bevt_19_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_19_tmpvar_phold).bevi_bool) /* Line: 102 */ {
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(8, bels_7));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_22_tmpvar_phold);
} /* Line: 103 */
bevt_24_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_25_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 105 */ {
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(13, bels_9));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_26_tmpvar_phold);
} /* Line: 106 */
bevt_28_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_29_tmpvar_phold = (new BEC_4_6_TextString(15, bels_10));
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 108 */ {
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(14, bels_11));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_30_tmpvar_phold);
} /* Line: 109 */
bevt_32_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpvar_phold = (new BEC_4_6_TextString(15, bels_12));
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 111 */ {
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(14, bels_13));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_34_tmpvar_phold);
} /* Line: 112 */
bevt_36_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_37_tmpvar_phold = (new BEC_4_6_TextString(14, bels_14));
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_37_tmpvar_phold);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 114 */ {
bevt_38_tmpvar_phold = (new BEC_4_6_TextString(13, bels_15));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_38_tmpvar_phold);
} /* Line: 115 */
bevt_40_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(12, bels_16));
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpvar_phold);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 117 */ {
bevt_42_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_42_tmpvar_phold);
} /* Line: 118 */
bevt_44_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_45_tmpvar_phold = (new BEC_4_6_TextString(13, bels_18));
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold != null && bevt_43_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_43_tmpvar_phold).bevi_bool) /* Line: 120 */ {
bevt_46_tmpvar_phold = (new BEC_4_6_TextString(12, bels_19));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_46_tmpvar_phold);
} /* Line: 121 */
bevt_48_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_49_tmpvar_phold = (new BEC_4_6_TextString(11, bels_20));
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_49_tmpvar_phold);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 123 */ {
bevt_50_tmpvar_phold = (new BEC_4_6_TextString(10, bels_21));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpvar_phold);
} /* Line: 124 */
bevt_52_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = (new BEC_4_6_TextString(10, bels_22));
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_53_tmpvar_phold);
if (bevt_51_tmpvar_phold != null && bevt_51_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_51_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_54_tmpvar_phold = (new BEC_4_6_TextString(9, bels_23));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_54_tmpvar_phold);
} /* Line: 127 */
bevt_56_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(9, bels_24));
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_57_tmpvar_phold);
if (bevt_55_tmpvar_phold != null && bevt_55_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_55_tmpvar_phold).bevi_bool) /* Line: 129 */ {
bevt_58_tmpvar_phold = (new BEC_4_6_TextString(8, bels_25));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_58_tmpvar_phold);
} /* Line: 130 */
bevt_60_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(8, bels_26));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 132 */ {
bevt_62_tmpvar_phold = (new BEC_4_6_TextString(7, bels_27));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_62_tmpvar_phold);
} /* Line: 133 */
bevt_63_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_63_tmpvar_phold);
bevt_65_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_66_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_66_tmpvar_phold);
if (bevt_64_tmpvar_phold != null && bevt_64_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_64_tmpvar_phold).bevi_bool) /* Line: 137 */ {
bevt_68_tmpvar_phold = beva_op.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(2, bels_28));
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
 else  /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 137 */ {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1489916809, BEL_4_Base.bevn_isOnceSet_1, bevt_70_tmpvar_phold);
} /* Line: 139 */
bevt_72_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_73_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_73_tmpvar_phold);
if (bevt_71_tmpvar_phold != null && bevt_71_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_71_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevt_75_tmpvar_phold = beva_op.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpvar_phold = (new BEC_4_6_TextString(2, bels_29));
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
 else  /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_77_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1373349483, BEL_4_Base.bevn_isManySet_1, bevt_77_tmpvar_phold);
} /* Line: 143 */
bevt_78_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpvar_phold);
beva_op.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_pr.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_op.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_pr);
bevt_80_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_79_tmpvar_phold = beva_prec.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_80_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 149 */ {
beva_nx.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_op.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_nx);
} /* Line: 151 */
return beva_op;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 20, 24, 24, 25, 25, 25, 26, 26, 25, 28, 35, 35, 35, 36, 37, 37, 39, 39, 39, 40, 40, 45, 46, 47, 49, 50, 50, 50, 50, 0, 0, 0, 50, 50, 0, 0, 0, 51, 51, 52, 53, 53, 54, 55, 55, 56, 56, 56, 57, 58, 58, 59, 64, 65, 65, 66, 66, 66, 68, 71, 72, 72, 73, 74, 74, 74, 75, 75, 76, 77, 77, 77, 78, 81, 86, 86, 90, 91, 91, 92, 92, 92, 92, 92, 93, 93, 93, 94, 94, 96, 96, 96, 97, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 109, 109, 111, 111, 111, 112, 112, 114, 114, 114, 115, 115, 117, 117, 117, 118, 118, 120, 120, 120, 121, 121, 123, 123, 123, 124, 124, 126, 126, 126, 127, 127, 129, 129, 129, 130, 130, 132, 132, 132, 133, 133, 136, 136, 137, 137, 137, 137, 137, 137, 0, 0, 0, 139, 139, 141, 141, 141, 141, 141, 141, 0, 0, 0, 143, 143, 145, 145, 146, 147, 148, 149, 149, 150, 151, 153};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 51, 52, 53, 56, 57, 59, 60, 61, 67, 110, 111, 112, 114, 115, 116, 118, 119, 120, 121, 126, 127, 128, 129, 130, 133, 138, 139, 144, 145, 148, 152, 155, 156, 158, 161, 165, 168, 169, 170, 171, 176, 177, 178, 183, 184, 185, 186, 188, 189, 194, 195, 200, 201, 206, 207, 208, 209, 212, 219, 220, 223, 225, 226, 227, 228, 230, 233, 235, 236, 237, 238, 239, 246, 253, 254, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 351, 352, 354, 355, 356, 358, 359, 361, 362, 363, 365, 366, 368, 369, 370, 372, 373, 375, 376, 377, 379, 380, 382, 383, 384, 386, 387, 389, 390, 391, 393, 394, 396, 397, 398, 400, 401, 403, 404, 405, 407, 408, 410, 411, 412, 414, 415, 417, 418, 419, 421, 422, 424, 425, 426, 428, 429, 431, 432, 433, 435, 436, 438, 439, 440, 442, 443, 445, 446, 447, 448, 449, 451, 452, 453, 455, 458, 462, 465, 466, 468, 469, 470, 472, 473, 474, 476, 479, 483, 486, 487, 489, 490, 491, 492, 493, 494, 495, 497, 498, 500};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 40
emitDataGet 0 20 40
addParsedClass 1 20 41
assign 1 24 51
new 0 24 51
assign 1 24 52
new 1 24 52
assign 1 25 53
new 0 25 53
assign 1 25 56
new 0 25 56
assign 1 25 57
lesser 1 25 57
assign 1 26 59
new 0 26 59
put 2 26 60
assign 1 25 61
increment 0 25 61
return 1 28 67
assign 1 35 110
typenameGet 0 35 110
assign 1 35 111
CLASSGet 0 35 111
assign 1 35 112
equals 1 35 112
acceptClass 1 36 114
assign 1 37 115
nextDescendGet 0 37 115
return 1 37 116
assign 1 39 118
operGet 0 39 118
assign 1 39 119
typenameGet 0 39 119
assign 1 39 120
get 1 39 120
assign 1 40 121
def 1 40 126
assign 1 45 127
containerGet 0 45 127
assign 1 46 128
prepOps 0 46 128
assign 1 47 129
assign 1 49 130
assign 1 50 133
def 1 50 138
assign 1 50 139
def 1 50 144
assign 1 0 145
assign 1 0 148
assign 1 0 152
assign 1 50 155
containerGet 0 50 155
assign 1 50 156
equals 1 50 156
assign 1 0 158
assign 1 0 161
assign 1 0 165
assign 1 51 168
get 1 51 168
addValue 1 51 169
assign 1 52 170
nextPeerGet 0 52 170
assign 1 53 171
def 1 53 176
assign 1 54 177
nextPeerGet 0 54 177
assign 1 55 178
def 1 55 183
assign 1 56 184
typenameGet 0 56 184
assign 1 56 185
COMMAGet 0 56 185
assign 1 56 186
equals 1 56 186
assign 1 57 188
nextPeerGet 0 57 188
assign 1 58 189
def 1 58 194
assign 1 59 195
nextPeerGet 0 59 195
assign 1 64 200
assign 1 65 201
def 1 65 206
assign 1 66 207
operGet 0 66 207
assign 1 66 208
typenameGet 0 66 208
assign 1 66 209
get 1 66 209
assign 1 68 212
assign 1 71 219
new 0 71 219
assign 1 72 220
iteratorGet 0 72 220
assign 1 72 223
hasNextGet 0 72 223
assign 1 73 225
nextGet 0 73 225
assign 1 74 226
lengthGet 0 74 226
assign 1 74 227
new 0 74 227
assign 1 74 228
greater 1 74 228
assign 1 75 230
iteratorGet 0 75 230
assign 1 75 233
hasNextGet 0 75 233
assign 1 76 235
nextGet 0 76 235
assign 1 77 236
priorPeerGet 0 77 236
assign 1 77 237
nextPeerGet 0 77 237
assign 1 77 238
callFromOper 4 77 238
assign 1 78 239
assign 1 81 246
increment 0 81 246
assign 1 86 253
nextDescendGet 0 86 253
return 1 86 254
assign 1 90 339
new 0 90 339
assign 1 91 340
new 0 91 340
wasOperSet 1 91 341
assign 1 92 342
operNamesGet 0 92 342
assign 1 92 343
typenameGet 0 92 343
assign 1 92 344
get 1 92 344
assign 1 92 345
lower 0 92 345
nameSet 1 92 346
assign 1 93 347
nameGet 0 93 347
assign 1 93 348
new 0 93 348
assign 1 93 349
equals 1 93 349
assign 1 94 351
new 0 94 351
nameSet 1 94 352
assign 1 96 354
nameGet 0 96 354
assign 1 96 355
new 0 96 355
assign 1 96 356
equals 1 96 356
assign 1 97 358
new 0 97 358
nameSet 1 97 359
assign 1 99 361
nameGet 0 99 361
assign 1 99 362
new 0 99 362
assign 1 99 363
equals 1 99 363
assign 1 100 365
new 0 100 365
nameSet 1 100 366
assign 1 102 368
nameGet 0 102 368
assign 1 102 369
new 0 102 369
assign 1 102 370
equals 1 102 370
assign 1 103 372
new 0 103 372
nameSet 1 103 373
assign 1 105 375
nameGet 0 105 375
assign 1 105 376
new 0 105 376
assign 1 105 377
equals 1 105 377
assign 1 106 379
new 0 106 379
nameSet 1 106 380
assign 1 108 382
nameGet 0 108 382
assign 1 108 383
new 0 108 383
assign 1 108 384
equals 1 108 384
assign 1 109 386
new 0 109 386
nameSet 1 109 387
assign 1 111 389
nameGet 0 111 389
assign 1 111 390
new 0 111 390
assign 1 111 391
equals 1 111 391
assign 1 112 393
new 0 112 393
nameSet 1 112 394
assign 1 114 396
nameGet 0 114 396
assign 1 114 397
new 0 114 397
assign 1 114 398
equals 1 114 398
assign 1 115 400
new 0 115 400
nameSet 1 115 401
assign 1 117 403
nameGet 0 117 403
assign 1 117 404
new 0 117 404
assign 1 117 405
equals 1 117 405
assign 1 118 407
new 0 118 407
nameSet 1 118 408
assign 1 120 410
nameGet 0 120 410
assign 1 120 411
new 0 120 411
assign 1 120 412
equals 1 120 412
assign 1 121 414
new 0 121 414
nameSet 1 121 415
assign 1 123 417
nameGet 0 123 417
assign 1 123 418
new 0 123 418
assign 1 123 419
equals 1 123 419
assign 1 124 421
new 0 124 421
nameSet 1 124 422
assign 1 126 424
nameGet 0 126 424
assign 1 126 425
new 0 126 425
assign 1 126 426
equals 1 126 426
assign 1 127 428
new 0 127 428
nameSet 1 127 429
assign 1 129 431
nameGet 0 129 431
assign 1 129 432
new 0 129 432
assign 1 129 433
equals 1 129 433
assign 1 130 435
new 0 130 435
nameSet 1 130 436
assign 1 132 438
nameGet 0 132 438
assign 1 132 439
new 0 132 439
assign 1 132 440
equals 1 132 440
assign 1 133 442
new 0 133 442
nameSet 1 133 443
assign 1 136 445
new 0 136 445
wasBoundSet 1 136 446
assign 1 137 447
typenameGet 0 137 447
assign 1 137 448
ASSIGNGet 0 137 448
assign 1 137 449
equals 1 137 449
assign 1 137 451
heldGet 0 137 451
assign 1 137 452
new 0 137 452
assign 1 137 453
equals 1 137 453
assign 1 0 455
assign 1 0 458
assign 1 0 462
assign 1 139 465
new 0 139 465
isOnceSet 1 139 466
assign 1 141 468
typenameGet 0 141 468
assign 1 141 469
ASSIGNGet 0 141 469
assign 1 141 470
equals 1 141 470
assign 1 141 472
heldGet 0 141 472
assign 1 141 473
new 0 141 473
assign 1 141 474
equals 1 141 474
assign 1 0 476
assign 1 0 479
assign 1 0 483
assign 1 143 486
new 0 143 486
isManySet 1 143 487
assign 1 145 489
CALLGet 0 145 489
typenameSet 1 145 490
heldSet 1 146 491
delete 0 147 492
addValue 1 148 493
assign 1 149 494
new 0 149 494
assign 1 149 495
greater 1 149 495
delete 0 150 497
addValue 1 151 498
return 1 153 500
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 1028089930: return bem_prepOps_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 724180734: return bem_acceptClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1204261941: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass8();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass8.bevs_inst = (BEC_5_5_5_BuildVisitPass8)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass8.bevs_inst;
}
}
