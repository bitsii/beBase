package be.BEL_4_Base;
/* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_12_TextByteIterator bevs_inst;
public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public BEC_2_4_12_TextByteIterator bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_emptyGet_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_containerGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
this.bem_new_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_str = beva__str;
bevp_pos = (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpvar_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1220 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 1221 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_next_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpvar_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1231 */ {
bevt_3_tmpvar_phold = beva_buf.bem_capacityGet_0();
bevt_4_tmpvar_phold = bevo_0;
if (bevt_3_tmpvar_phold.bevi_int < bevt_4_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1232 */ {
bevt_5_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_tmpvar_phold);
} /* Line: 1233 */
bevt_7_tmpvar_phold = beva_buf.bem_sizeGet_0();
bevt_8_tmpvar_phold = bevo_1;
if (bevt_7_tmpvar_phold.bevi_int != bevt_8_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1235 */ {
bevt_9_tmpvar_phold = beva_buf.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevo_2;
bevt_10_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_11_tmpvar_phold.bem_once_0();
bevt_9_tmpvar_phold.bevi_int = bevt_10_tmpvar_phold.bevi_int;
} /* Line: 1236 */
bevt_12_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_13_tmpvar_phold = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevp_pos.bevi_int++;
} /* Line: 1242 */
return beva_buf;
} /*method end*/
public BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpvar_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1248 */ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1250 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_3;
if (bevp_pos.bevi_int > bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1256 */ {
bevt_4_tmpvar_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpvar_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1256 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1256 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1256 */
 else  /* Line: 1256 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1256 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1259 */
return beva_into;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_4;
if (bevp_pos.bevi_int > bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1265 */ {
bevt_4_tmpvar_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpvar_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1265 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1265 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1265 */
 else  /* Line: 1265 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1265 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1268 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_6_6_SystemObject bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGet_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1196, 1196, 1196, 1200, 1204, 1208, 1213, 1214, 1215, 1220, 1220, 1220, 1221, 1221, 1223, 1223, 1227, 1227, 1227, 1227, 1231, 1231, 1231, 1232, 1232, 1232, 1232, 1233, 1233, 1235, 1235, 1235, 1235, 1236, 1236, 1236, 1236, 1238, 1238, 1238, 1242, 1244, 1248, 1248, 1248, 1249, 1250, 1252, 1256, 1256, 1256, 1256, 1256, 1256, 0, 0, 0, 1257, 1258, 1259, 1261, 1265, 1265, 1265, 1265, 1265, 1265, 0, 0, 0, 1266, 1267, 1268, 1274, 1278, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 25, 28, 31, 35, 36, 37, 45, 46, 51, 52, 53, 55, 56, 62, 63, 64, 65, 84, 85, 90, 91, 92, 93, 98, 99, 100, 102, 103, 104, 109, 110, 111, 112, 113, 115, 116, 117, 118, 120, 125, 126, 131, 132, 133, 135, 143, 144, 149, 150, 151, 156, 157, 160, 164, 167, 168, 169, 171, 179, 180, 185, 186, 187, 192, 193, 196, 200, 203, 204, 205, 210, 213, 216, 219, 223, 226, 230, 233};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1196 19
new 0 1196 19
assign 1 1196 20
emptyGet 0 1196 20
new 1 1196 21
return 1 1200 25
return 1 1204 28
new 1 1208 31
assign 1 1213 35
assign 1 1214 36
new 0 1214 36
assign 1 1215 37
new 0 1215 37
assign 1 1220 45
sizeGet 0 1220 45
assign 1 1220 46
greater 1 1220 51
assign 1 1221 52
new 0 1221 52
return 1 1221 53
assign 1 1223 55
new 0 1223 55
return 1 1223 56
assign 1 1227 62
new 0 1227 62
assign 1 1227 63
new 1 1227 63
assign 1 1227 64
next 1 1227 64
return 1 1227 65
assign 1 1231 84
sizeGet 0 1231 84
assign 1 1231 85
greater 1 1231 90
assign 1 1232 91
capacityGet 0 1232 91
assign 1 1232 92
new 0 1232 92
assign 1 1232 93
lesser 1 1232 98
assign 1 1233 99
new 0 1233 99
capacitySet 1 1233 100
assign 1 1235 102
sizeGet 0 1235 102
assign 1 1235 103
new 0 1235 103
assign 1 1235 104
notEquals 1 1235 109
assign 1 1236 110
sizeGet 0 1236 110
assign 1 1236 111
new 0 1236 111
assign 1 1236 112
once 0 1236 112
setValue 1 1236 113
assign 1 1238 115
new 0 1238 115
assign 1 1238 116
getInt 2 1238 116
setIntUnchecked 2 1238 117
incrementValue 0 1242 118
return 1 1244 120
assign 1 1248 125
sizeGet 0 1248 125
assign 1 1248 126
greater 1 1248 131
getInt 2 1249 132
incrementValue 0 1250 133
return 1 1252 135
assign 1 1256 143
new 0 1256 143
assign 1 1256 144
greater 1 1256 149
assign 1 1256 150
sizeGet 0 1256 150
assign 1 1256 151
greaterEquals 1 1256 156
assign 1 0 157
assign 1 0 160
assign 1 0 164
decrementValue 0 1257 167
getInt 2 1258 168
incrementValue 0 1259 169
return 1 1261 171
assign 1 1265 179
new 0 1265 179
assign 1 1265 180
greater 1 1265 185
assign 1 1265 186
sizeGet 0 1265 186
assign 1 1265 187
greaterEquals 1 1265 192
assign 1 0 193
assign 1 0 196
assign 1 0 200
decrementValue 0 1266 203
setIntUnchecked 2 1267 204
incrementValue 0 1268 205
return 1 1274 210
return 1 1278 213
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 833063302: return bem_containerGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 715968403: return bem_posGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case -248879165: return bem_byteIteratorIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 108485850: return bem_hasNextGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1763354070: return bem_strGet_0();
case 1102720804: return bem_classNameGet_0();
case -230685860: return bem_vcopyGet_0();
case 1194623572: return bem_nextGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1774436323: return bem_strSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -219603607: return bem_vcopySet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1488067202: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1048795675: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1196738734: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1448425960: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_TextByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_TextByteIterator.bevs_inst = (BEC_2_4_12_TextByteIterator)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_TextByteIterator.bevs_inst;
}
}
