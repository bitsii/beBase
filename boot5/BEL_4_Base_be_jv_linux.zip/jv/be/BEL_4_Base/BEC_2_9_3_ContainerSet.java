package be.BEL_4_Base;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_3_ContainerSet bevs_inst;
public BEC_2_9_5_ContainerArray bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_5_ContainerArray()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 241 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 248 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_5_ContainerArray beva_ninner, BEC_2_9_5_ContainerArray beva_ir) throws Throwable {
BEC_3_9_5_8_ContainerArrayIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 266 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_4_tmpvar_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpvar_phold = this.bem_innerPut_4(bevt_4_tmpvar_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 269 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 270 */
} /* Line: 269 */
} /* Line: 268 */
 else  /* Line: 266 */ {
break;
} /* Line: 266 */
} /* Line: 266 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_5_ContainerArray beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_5_ContainerArray bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpvar_phold = bevo_2;
bevl_nslots = bevt_0_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
bevl_ninner = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 281 */ {
bevt_4_tmpvar_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevl_nslots);
} /* Line: 283 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (beva_other == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 289 */ {
bevt_4_tmpvar_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpvar_phold = this.bem_sizeGet_0();
if (bevt_4_tmpvar_phold.bevi_int != bevt_5_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 289 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 289 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 290 */
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 292 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevl_i = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_other.bem_has_1(bevl_i);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /* Line: 293 */
} /* Line: 293 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_5_ContainerArray beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 302 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 303 */
} /* Line: 302 */
 else  /* Line: 305 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 306 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 310 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 312 */ {
if (beva_inode == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpvar_phold);
} /* Line: 314 */
 else  /* Line: 315 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 316 */
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 319 */
 else  /* Line: 312 */ {
bevt_10_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /* Line: 321 */
 else  /* Line: 312 */ {
bevt_13_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpvar_phold, beva_k);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 322 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_14_tmpvar_phold;
} /* Line: 326 */
 else  /* Line: 327 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 329 */ {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_16_tmpvar_phold;
} /* Line: 330 */
} /* Line: 329 */
} /* Line: 312 */
} /* Line: 312 */
} /* Line: 312 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 337 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 340 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 340 */ {
bevl_slt = (BEC_2_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
} /* Line: 341 */
 else  /* Line: 340 */ {
break;
} /* Line: 340 */
} /* Line: 340 */
bevp_slots = bevl_slt;
} /* Line: 343 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 345 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 346 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 355 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 359 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 361 */ {
return null;
} /* Line: 362 */
 else  /* Line: 361 */ {
bevt_5_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 363 */ {
return null;
} /* Line: 364 */
 else  /* Line: 361 */ {
bevt_7_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpvar_phold, beva_k);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 365 */ {
bevt_8_tmpvar_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpvar_phold;
} /* Line: 366 */
 else  /* Line: 367 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 369 */ {
return null;
} /* Line: 370 */
} /* Line: 369 */
} /* Line: 361 */
} /* Line: 361 */
} /* Line: 361 */
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 381 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 385 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 388 */
 else  /* Line: 387 */ {
bevt_6_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /* Line: 390 */
 else  /* Line: 387 */ {
bevt_9_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpvar_phold, beva_k);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 391 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 392 */
 else  /* Line: 393 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 395 */ {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /* Line: 396 */
} /* Line: 395 */
} /* Line: 387 */
} /* Line: 387 */
} /* Line: 387 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 408 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 412 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 414 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 415 */
 else  /* Line: 414 */ {
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 416 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 417 */
 else  /* Line: 414 */ {
bevt_10_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpvar_phold, beva_k);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 418 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 422 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 424 */ {
bevt_15_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 424 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 424 */ {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_16_tmpvar_phold;
} /* Line: 425 */
 else  /* Line: 426 */ {
bevt_18_tmpvar_phold = bevo_7;
bevt_17_tmpvar_phold = bevl_sl.bem_subtract_1(bevt_18_tmpvar_phold);
bevl_slt.bem_put_2(bevt_17_tmpvar_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 428 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 430 */
 else  /* Line: 422 */ {
break;
} /* Line: 422 */
} /* Line: 422 */
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_19_tmpvar_phold;
} /* Line: 432 */
 else  /* Line: 433 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 435 */ {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_21_tmpvar_phold;
} /* Line: 436 */
} /* Line: 435 */
} /* Line: 414 */
} /* Line: 414 */
} /* Line: 414 */
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpvar_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 446 */ {
bevt_2_tmpvar_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 446 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 448 */ {
bevt_4_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_new_3(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpvar_phold);
} /* Line: 449 */
 else  /* Line: 450 */ {
bevt_10_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 451 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 446 */
 else  /* Line: 446 */ {
break;
} /* Line: 446 */
} /* Line: 446 */
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_6_6_SystemObject bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 489 */ {
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 490 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 490 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_3_tmpvar_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 491 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 492 */
} /* Line: 491 */
 else  /* Line: 490 */ {
break;
} /* Line: 490 */
} /* Line: 490 */
} /* Line: 490 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 501 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 501 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 502 */
 else  /* Line: 501 */ {
break;
} /* Line: 501 */
} /* Line: 501 */
if (beva_other == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 504 */ {
bevt_1_tmpvar_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 505 */ {
bevt_4_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 505 */ {
bevl_x = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 506 */
 else  /* Line: 505 */ {
break;
} /* Line: 505 */
} /* Line: 505 */
} /* Line: 505 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 519 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 520 */ {
bevt_0_tmpvar_loop = beva_other.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 521 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 521 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 522 */
 else  /* Line: 521 */ {
break;
} /* Line: 521 */
} /* Line: 521 */
} /* Line: 521 */
 else  /* Line: 520 */ {
bevt_4_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 524 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpvar_phold);
} /* Line: 525 */
 else  /* Line: 526 */ {
this.bem_put_1(beva_other);
} /* Line: 527 */
} /* Line: 520 */
} /* Line: 520 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_2_6_6_SystemObject bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_slots = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_2_6_6_SystemObject bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_2_6_6_SystemObject bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_2_6_6_SystemObject bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {222, 222, 228, 229, 230, 231, 232, 233, 234, 240, 240, 240, 241, 241, 243, 243, 247, 247, 247, 248, 248, 250, 250, 254, 254, 258, 258, 262, 262, 266, 266, 267, 268, 268, 269, 269, 269, 270, 270, 274, 274, 279, 279, 279, 279, 280, 281, 281, 282, 283, 285, 289, 289, 0, 289, 289, 289, 289, 0, 0, 290, 290, 292, 0, 292, 292, 293, 293, 293, 293, 295, 295, 299, 300, 300, 301, 302, 302, 302, 303, 306, 308, 309, 311, 312, 312, 313, 313, 314, 314, 314, 316, 318, 319, 319, 320, 320, 320, 320, 321, 321, 322, 322, 323, 325, 326, 326, 328, 329, 329, 330, 330, 337, 337, 338, 339, 340, 340, 341, 343, 346, 351, 352, 353, 354, 354, 354, 355, 357, 358, 360, 361, 361, 362, 363, 363, 363, 363, 364, 365, 365, 366, 366, 368, 369, 369, 370, 377, 378, 379, 380, 380, 380, 381, 383, 384, 386, 387, 387, 388, 388, 389, 389, 389, 389, 390, 390, 391, 391, 392, 392, 394, 395, 395, 396, 396, 403, 404, 406, 407, 407, 407, 408, 410, 411, 413, 414, 414, 415, 415, 416, 416, 416, 416, 417, 417, 418, 418, 419, 420, 421, 422, 422, 423, 424, 424, 0, 424, 424, 424, 424, 0, 0, 425, 425, 427, 427, 427, 428, 430, 432, 432, 434, 435, 435, 436, 436, 443, 444, 445, 445, 446, 446, 446, 446, 447, 448, 448, 449, 449, 449, 449, 449, 449, 449, 451, 451, 446, 454, 459, 460, 464, 464, 468, 468, 472, 472, 476, 476, 480, 480, 484, 484, 488, 489, 489, 490, 0, 490, 490, 491, 492, 496, 500, 501, 0, 501, 501, 502, 504, 504, 505, 0, 505, 505, 506, 509, 513, 514, 515, 519, 519, 520, 521, 0, 521, 521, 522, 524, 525, 525, 527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 30, 31, 32, 33, 34, 35, 36, 44, 45, 50, 51, 52, 54, 55, 62, 63, 68, 69, 70, 72, 73, 77, 78, 82, 83, 88, 89, 101, 104, 106, 107, 112, 113, 114, 115, 117, 118, 126, 127, 137, 138, 139, 140, 141, 144, 145, 147, 148, 154, 170, 175, 176, 179, 180, 181, 186, 187, 190, 194, 195, 197, 197, 200, 202, 203, 204, 206, 207, 214, 215, 240, 241, 246, 247, 248, 249, 254, 255, 259, 261, 262, 265, 266, 271, 272, 277, 278, 279, 280, 283, 285, 286, 287, 290, 291, 292, 297, 298, 299, 302, 303, 305, 306, 307, 308, 311, 312, 317, 318, 319, 332, 333, 335, 336, 339, 340, 342, 348, 351, 372, 373, 374, 375, 376, 381, 382, 384, 385, 388, 389, 394, 395, 398, 399, 400, 405, 406, 409, 410, 412, 413, 416, 417, 422, 423, 450, 451, 452, 453, 454, 459, 460, 462, 463, 466, 467, 472, 473, 474, 477, 478, 479, 484, 485, 486, 489, 490, 492, 493, 496, 497, 502, 503, 504, 540, 541, 542, 543, 544, 549, 550, 552, 553, 556, 557, 562, 563, 564, 567, 568, 569, 574, 575, 576, 579, 580, 582, 583, 584, 587, 592, 593, 594, 599, 600, 603, 604, 605, 610, 611, 614, 618, 619, 622, 623, 624, 625, 627, 633, 634, 637, 638, 643, 644, 645, 667, 668, 669, 670, 671, 674, 675, 680, 681, 682, 687, 688, 689, 690, 691, 692, 693, 694, 697, 698, 700, 706, 709, 710, 715, 716, 720, 721, 725, 726, 730, 731, 735, 736, 740, 741, 750, 751, 756, 757, 757, 760, 762, 763, 765, 773, 783, 784, 784, 787, 789, 790, 796, 801, 802, 802, 805, 807, 808, 815, 819, 820, 821, 831, 836, 837, 839, 839, 842, 844, 845, 853, 855, 856, 859, 866, 869, 873, 876, 880, 883, 887, 890, 894, 897, 901, 904, 908, 911};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 222 25
new 0 222 25
new 1 222 26
assign 1 228 30
new 1 228 30
assign 1 229 31
assign 1 230 32
new 0 230 32
assign 1 231 33
new 0 231 33
assign 1 232 34
new 0 232 34
assign 1 233 35
new 0 233 35
assign 1 234 36
new 0 234 36
assign 1 240 44
new 0 240 44
assign 1 240 45
equals 1 240 50
assign 1 241 51
new 0 241 51
return 1 241 52
assign 1 243 54
new 0 243 54
return 1 243 55
assign 1 247 62
new 0 247 62
assign 1 247 63
equals 1 247 68
assign 1 248 69
new 0 248 69
return 1 248 70
assign 1 250 72
new 0 250 72
return 1 250 73
assign 1 254 77
toString 0 254 77
return 1 254 78
assign 1 258 82
new 1 258 82
new 1 258 83
assign 1 262 88
new 1 262 88
return 1 262 89
assign 1 266 101
arrayIteratorGet 0 266 101
assign 1 266 104
hasNextGet 0 266 104
assign 1 267 106
nextGet 0 267 106
assign 1 268 107
def 1 268 112
assign 1 269 113
keyGet 0 269 113
assign 1 269 114
innerPut 4 269 114
assign 1 269 115
not 0 269 115
assign 1 270 117
new 0 270 117
return 1 270 118
assign 1 274 126
new 0 274 126
return 1 274 127
assign 1 279 137
sizeGet 0 279 137
assign 1 279 138
multiply 1 279 138
assign 1 279 139
new 0 279 139
assign 1 279 140
add 1 279 140
assign 1 280 141
new 1 280 141
assign 1 281 144
insertAll 2 281 144
assign 1 281 145
not 0 281 145
assign 1 282 147
increment 0 282 147
assign 1 283 148
new 1 283 148
return 1 285 154
assign 1 289 170
undef 1 289 175
assign 1 0 176
assign 1 289 179
sizeGet 0 289 179
assign 1 289 180
sizeGet 0 289 180
assign 1 289 181
notEquals 1 289 186
assign 1 0 187
assign 1 0 190
assign 1 290 194
new 0 290 194
return 1 290 195
assign 1 292 197
setIteratorGet 0 0 197
assign 1 292 200
hasNextGet 0 292 200
assign 1 292 202
nextGet 0 292 202
assign 1 293 203
has 1 293 203
assign 1 293 204
not 0 293 204
assign 1 293 206
new 0 293 206
return 1 293 207
assign 1 295 214
new 0 295 214
return 1 295 215
assign 1 299 240
sizeGet 0 299 240
assign 1 300 241
undef 1 300 246
assign 1 301 247
getHash 1 301 247
assign 1 302 248
new 0 302 248
assign 1 302 249
lesser 1 302 254
assign 1 303 255
abs 0 303 255
assign 1 306 259
hvalGet 0 306 259
assign 1 308 261
modulus 1 308 261
assign 1 309 262
assign 1 311 265
get 1 311 265
assign 1 312 266
undef 1 312 271
assign 1 313 272
undef 1 313 277
assign 1 314 278
create 0 314 278
assign 1 314 279
new 3 314 279
put 2 314 280
put 2 316 283
assign 1 318 285
new 0 318 285
assign 1 319 286
new 0 319 286
return 1 319 287
assign 1 320 290
hvalGet 0 320 290
assign 1 320 291
modulus 1 320 291
assign 1 320 292
notEquals 1 320 297
assign 1 321 298
new 0 321 298
return 1 321 299
assign 1 322 302
keyGet 0 322 302
assign 1 322 303
isEqual 2 322 303
putTo 2 323 305
assign 1 325 306
new 0 325 306
assign 1 326 307
new 0 326 307
return 1 326 308
assign 1 328 311
increment 0 328 311
assign 1 329 312
greaterEquals 1 329 317
assign 1 330 318
new 0 330 318
return 1 330 319
assign 1 337 332
innerPut 4 337 332
assign 1 337 333
not 0 337 333
assign 1 338 335
assign 1 339 336
rehash 1 339 336
assign 1 340 339
innerPut 4 340 339
assign 1 340 340
not 0 340 340
assign 1 341 342
rehash 1 341 342
assign 1 343 348
assign 1 346 351
increment 0 346 351
assign 1 351 372
assign 1 352 373
sizeGet 0 352 373
assign 1 353 374
getHash 1 353 374
assign 1 354 375
new 0 354 375
assign 1 354 376
lesser 1 354 381
assign 1 355 382
abs 0 355 382
assign 1 357 384
modulus 1 357 384
assign 1 358 385
assign 1 360 388
get 1 360 388
assign 1 361 389
undef 1 361 394
return 1 362 395
assign 1 363 398
hvalGet 0 363 398
assign 1 363 399
modulus 1 363 399
assign 1 363 400
notEquals 1 363 405
return 1 364 406
assign 1 365 409
keyGet 0 365 409
assign 1 365 410
isEqual 2 365 410
assign 1 366 412
getFrom 0 366 412
return 1 366 413
assign 1 368 416
increment 0 368 416
assign 1 369 417
greaterEquals 1 369 422
return 1 370 423
assign 1 377 450
assign 1 378 451
sizeGet 0 378 451
assign 1 379 452
getHash 1 379 452
assign 1 380 453
new 0 380 453
assign 1 380 454
lesser 1 380 459
assign 1 381 460
abs 0 381 460
assign 1 383 462
modulus 1 383 462
assign 1 384 463
assign 1 386 466
get 1 386 466
assign 1 387 467
undef 1 387 472
assign 1 388 473
new 0 388 473
return 1 388 474
assign 1 389 477
hvalGet 0 389 477
assign 1 389 478
modulus 1 389 478
assign 1 389 479
notEquals 1 389 484
assign 1 390 485
new 0 390 485
return 1 390 486
assign 1 391 489
keyGet 0 391 489
assign 1 391 490
isEqual 2 391 490
assign 1 392 492
new 0 392 492
return 1 392 493
assign 1 394 496
increment 0 394 496
assign 1 395 497
greaterEquals 1 395 502
assign 1 396 503
new 0 396 503
return 1 396 504
assign 1 403 540
assign 1 404 541
sizeGet 0 404 541
assign 1 406 542
getHash 1 406 542
assign 1 407 543
new 0 407 543
assign 1 407 544
lesser 1 407 549
assign 1 408 550
abs 0 408 550
assign 1 410 552
modulus 1 410 552
assign 1 411 553
assign 1 413 556
get 1 413 556
assign 1 414 557
undef 1 414 562
assign 1 415 563
new 0 415 563
return 1 415 564
assign 1 416 567
hvalGet 0 416 567
assign 1 416 568
modulus 1 416 568
assign 1 416 569
notEquals 1 416 574
assign 1 417 575
new 0 417 575
return 1 417 576
assign 1 418 579
keyGet 0 418 579
assign 1 418 580
isEqual 2 418 580
put 2 419 582
assign 1 420 583
decrement 0 420 583
assign 1 421 584
increment 0 421 584
assign 1 422 587
lesser 1 422 592
assign 1 423 593
get 1 423 593
assign 1 424 594
undef 1 424 599
assign 1 0 600
assign 1 424 603
hvalGet 0 424 603
assign 1 424 604
modulus 1 424 604
assign 1 424 605
notEquals 1 424 610
assign 1 0 611
assign 1 0 614
assign 1 425 618
new 0 425 618
return 1 425 619
assign 1 427 622
new 0 427 622
assign 1 427 623
subtract 1 427 623
put 2 427 624
put 2 428 625
assign 1 430 627
increment 0 430 627
assign 1 432 633
new 0 432 633
return 1 432 634
assign 1 434 637
increment 0 434 637
assign 1 435 638
greaterEquals 1 435 643
assign 1 436 644
new 0 436 644
return 1 436 645
assign 1 443 667
create 0 443 667
copyTo 1 444 668
assign 1 445 669
copy 0 445 669
slotsSet 1 445 670
assign 1 446 671
new 0 446 671
assign 1 446 674
lengthGet 0 446 674
assign 1 446 675
lesser 1 446 680
assign 1 447 681
get 1 447 681
assign 1 448 682
def 1 448 687
assign 1 449 688
slotsGet 0 449 688
assign 1 449 689
create 0 449 689
assign 1 449 690
hvalGet 0 449 690
assign 1 449 691
keyGet 0 449 691
assign 1 449 692
getFrom 0 449 692
assign 1 449 693
new 3 449 693
put 2 449 694
assign 1 451 697
slotsGet 0 451 697
put 2 451 698
assign 1 446 700
increment 0 446 700
return 1 454 706
clear 0 459 709
assign 1 460 710
new 0 460 710
assign 1 464 715
new 1 464 715
return 1 464 716
assign 1 468 720
new 1 468 720
return 1 468 721
assign 1 472 725
new 1 472 725
return 1 472 726
assign 1 476 730
keyIteratorGet 0 476 730
return 1 476 731
assign 1 480 735
new 1 480 735
return 1 480 736
assign 1 484 740
nodeIteratorGet 0 484 740
return 1 484 741
assign 1 488 750
new 0 488 750
assign 1 489 751
def 1 489 756
assign 1 490 757
setIteratorGet 0 0 757
assign 1 490 760
hasNextGet 0 490 760
assign 1 490 762
nextGet 0 490 762
assign 1 491 763
has 1 491 763
put 1 492 765
return 1 496 773
assign 1 500 783
new 0 500 783
assign 1 501 784
setIteratorGet 0 0 784
assign 1 501 787
hasNextGet 0 501 787
assign 1 501 789
nextGet 0 501 789
put 1 502 790
assign 1 504 796
def 1 504 801
assign 1 505 802
setIteratorGet 0 0 802
assign 1 505 805
hasNextGet 0 505 805
assign 1 505 807
nextGet 0 505 807
put 1 506 808
return 1 509 815
assign 1 513 819
copy 0 513 819
addValue 1 514 820
return 1 515 821
assign 1 519 831
def 1 519 836
assign 1 520 837
sameType 1 520 837
assign 1 521 839
iteratorGet 0 0 839
assign 1 521 842
hasNextGet 0 521 842
assign 1 521 844
nextGet 0 521 844
put 1 522 845
assign 1 524 853
sameType 1 524 853
assign 1 525 855
keyGet 0 525 855
put 1 525 856
put 1 527 859
return 1 0 866
assign 1 0 869
return 1 0 873
assign 1 0 876
return 1 0 880
assign 1 0 883
return 1 0 887
assign 1 0 890
return 1 0 894
assign 1 0 897
return 1 0 901
assign 1 0 904
return 1 0 908
assign 1 0 911
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 712928736: return bem_innerPutAddedGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1586230380: return bem_moduGet_0();
case 1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 2142483603: return bem_notEmptyGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case 578884498: return bem_relGet_0();
case 786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 567802245: return bem_relSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 668984013: return bem_rehash_1((BEC_2_9_5_ContainerArray) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 131089957: return bem_insertAll_2((BEC_2_9_5_ContainerArray) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_5_ContainerArray) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bevs_inst = (BEC_2_9_3_ContainerSet)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bevs_inst;
}
}
