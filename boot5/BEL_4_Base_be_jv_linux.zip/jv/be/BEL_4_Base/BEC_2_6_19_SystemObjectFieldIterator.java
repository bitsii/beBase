package be.BEL_4_Base;
/* IO:File: source/base/OpiFc.be */
public final class BEC_2_6_19_SystemObjectFieldIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
public static BEC_2_6_19_SystemObjectFieldIterator bevs_inst;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_4_3_MathInt bevp_minField;
public BEC_2_4_3_MathInt bevp_maxField;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_19_SystemObjectFieldIterator bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_new_2(beva__instance, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) throws Throwable {
BEC_2_4_3_MathInt bevl__minField = null;
BEC_2_4_3_MathInt bevl__maxField = null;
bevl__minField = (new BEC_2_4_3_MathInt());
bevl__maxField = (new BEC_2_4_3_MathInt());
if (beva_forceFirstSlot.bevi_bool) /* Line: 50 */ {
} /* Line: 51 */

      String prefix = "bevp_";
      java.lang.reflect.Field[] fields = beva__instance.getClass().getFields();
      int numfields = 0;
      for (int i = 0;i < fields.length;i++) {
        if (fields[i].getName().startsWith(prefix)) {
            //System.out.println("got field named " + fields[i].getName());
            numfields++;
        }
      }
      bevl__minField.bevi_int = 0;
      bevl__maxField.bevi_int = numfields;
      bevp_instance = beva__instance;
bevp_minField = bevl__minField;
bevp_maxField = bevl__maxField;
bevp_pos = bevl__minField;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_pos.bevi_int < bevp_maxField.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 107 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_1_tmpvar_phold;
} /* Line: 108 */
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl__instance = null;
BEC_2_4_3_MathInt bevl__pos = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl__instance = bevp_instance;
bevl__pos = bevp_pos;
if (bevp_pos.bevi_int < bevp_maxField.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 126 */ {

          String prefix = "bevp_";
          java.lang.reflect.Field[] fields = bevl__instance.getClass().getFields();
          int numfields = 0;
          for (int i = 0;i < fields.length;i++) {
            if (fields[i].getName().startsWith(prefix)) {
                if (numfields == bevl__pos.bevi_int) {
                    bevl_inst = (BEC_2_6_6_SystemObject) (fields[i].get(bevl__instance));
                    break;
                }
                numfields++;
            }
          }
         bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 173 */
return bevl_inst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl__instance = null;
BEC_2_4_3_MathInt bevl__pos = null;
BEC_2_6_6_SystemObject bevl__value = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl__instance = bevp_instance;
bevl__pos = bevp_pos;
bevl__value = beva_value;
if (bevp_pos.bevi_int < bevp_maxField.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 192 */ {

          String prefix = "bevp_";
          java.lang.reflect.Field[] fields = bevl__instance.getClass().getFields();
          int numfields = 0;
          for (int i = 0;i < fields.length;i++) {
            if (fields[i].getName().startsWith(prefix)) {
                if (numfields == bevl__pos.bevi_int) {
                    fields[i].set(bevl__instance, bevl__value);
                    break;
                }
                numfields++;
            }
          }
         bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 237 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevp_pos = bevp_pos.bem_add_1(beva_multiNullCount);
if (bevp_pos.bevi_int > bevp_maxField.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevp_pos = bevp_maxField;
} /* Line: 244 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() throws Throwable {
return bevp_instance;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_instance = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minFieldGet_0() throws Throwable {
return bevp_minField;
} /*method end*/
public BEC_2_6_6_SystemObject bem_minFieldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_minField = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxFieldGet_0() throws Throwable {
return bevp_maxField;
} /*method end*/
public BEC_2_6_6_SystemObject bem_maxFieldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_maxField = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_6_6_SystemObject bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 26, 26, 39, 40, 99, 100, 101, 102, 107, 107, 108, 108, 110, 110, 124, 125, 126, 126, 173, 175, 189, 190, 191, 192, 192, 237, 242, 243, 243, 244, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 25, 26, 41, 42, 43, 44, 51, 56, 57, 58, 60, 61, 68, 69, 70, 75, 89, 91, 98, 99, 100, 101, 106, 120, 126, 127, 132, 133, 138, 141, 145, 148, 152, 155, 159, 162};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 26 18
new 0 26 18
assign 1 26 19
new 2 26 19
return 1 26 20
assign 1 39 25
new 0 39 25
assign 1 40 26
new 0 40 26
assign 1 99 41
assign 1 100 42
assign 1 101 43
assign 1 102 44
assign 1 107 51
lesser 1 107 56
assign 1 108 57
new 0 108 57
return 1 108 58
assign 1 110 60
new 0 110 60
return 1 110 61
assign 1 124 68
assign 1 125 69
assign 1 126 70
lesser 1 126 75
assign 1 173 89
increment 0 173 89
return 1 175 91
assign 1 189 98
assign 1 190 99
assign 1 191 100
assign 1 192 101
lesser 1 192 106
assign 1 237 120
increment 0 237 120
assign 1 242 126
add 1 242 126
assign 1 243 127
greater 1 243 132
assign 1 244 133
return 1 0 138
assign 1 0 141
return 1 0 145
assign 1 0 148
return 1 0 152
assign 1 0 155
return 1 0 159
assign 1 0 162
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case -618123983: return bem_maxFieldGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 715968403: return bem_posGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 1204182175: return bem_minFieldGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 108485850: return bem_hasNextGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1194623572: return bem_nextGet_0();
case -1405080078: return bem_instanceGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1215264428: return bem_minFieldSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -607041730: return bem_maxFieldSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1393997825: return bem_instanceSet_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator.bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bevs_inst;
}
}
