package be.BEL_4_Base;
/* IO:File: source/build/Pass11.be */
public class BEC_5_5_6_BuildVisitPass11 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_6_BuildVisitPass11() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x31};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x31,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_2 = {0x74,0x68,0x72,0x6F,0x77};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(2));
private static byte[] bels_3 = {0x54,0x68,0x69,0x73,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x75,0x73,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x65,0x78,0x61,0x63,0x74,0x6C,0x79,0x20,0x6F,0x6E,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x2C,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_3, 46));
private static byte[] bels_4 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_6 = {0x43,0x61,0x6C,0x6C,0x20,0x6E,0x6F,0x74,0x20,0x69,0x6E,0x20,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x70,0x6F,0x73,0x69,0x74,0x69,0x6F,0x6E};
private static byte[] bels_7 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_8 = {0x70,0x68,0x6F,0x6C,0x64};
private static byte[] bels_9 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_5_5_6_BuildVisitPass11 bevs_inst;
public BEC_5_4_BuildNode bevp_inMtd;
public BEC_5_5_6_BuildVisitPass11 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_4_BuildNode bevl_fnode = null;
BEC_6_6_SystemObject bevl_it = null;
BEC_5_4_BuildNode bevl_inode = null;
BEC_5_3_BuildVar bevl_ts = null;
BEC_6_6_SystemObject bevl_nd = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_unwind = null;
BEC_6_6_SystemObject bevl_c0 = null;
BEC_6_6_SystemObject bevl_cnode = null;
BEC_6_6_SystemObject bevl_lastStep = null;
BEC_6_6_SystemObject bevl_pholdv = null;
BEC_6_6_SystemObject bevl_phold = null;
BEC_6_6_SystemObject bevl_prc = null;
BEC_6_6_SystemObject bevl_prcc = null;
BEC_6_6_SystemObject bevl_phold2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_86_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_87_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 28 */ {
bevl_fnode = null;
bevt_11_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_firstGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_8_tmpvar_phold == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 30 */ {
bevl_fnode = beva_node.bem_nextDescendGet_0();
} /* Line: 31 */
bevt_14_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_firstGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_it = bevt_12_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 33 */ {
bevt_15_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 33 */ {
bevl_inode = (BEC_5_4_BuildNode) bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_fnode == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 35 */ {
bevl_fnode = bevl_inode;
} /* Line: 36 */
beva_node.bem_beforeInsert_1(bevl_inode);
} /* Line: 38 */
 else  /* Line: 33 */ {
break;
} /* Line: 33 */
} /* Line: 33 */
beva_node.bem_delete_0();
return bevl_fnode;
} /* Line: 41 */
bevt_18_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_equals_1(bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 43 */ {
bevp_inMtd = beva_node;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_23_tmpvar_phold = (new BEC_4_6_TextString(4, bels_0));
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_23_tmpvar_phold);
bevl_ts = (BEC_5_3_BuildVar) bevt_20_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_ts.bem_isTypedSet_1(bevt_24_tmpvar_phold);
bevt_27_tmpvar_phold = beva_node.bem_classGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_ts.bem_namepathSet_1(bevt_25_tmpvar_phold);
} /* Line: 47 */
bevt_29_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_30_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_equals_1(bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_33_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(6, bels_1));
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_34_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 54 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_37_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = (new BEC_4_6_TextString(5, bels_2));
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_38_tmpvar_phold);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 54 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 54 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 54 */ {
bevt_41_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_lengthGet_0();
bevt_42_tmpvar_phold = bevo_0;
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_greater_1(bevt_42_tmpvar_phold);
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 54 */
 else  /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 54 */ {
bevt_45_tmpvar_phold = bevo_1;
bevt_48_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_lengthGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_toString_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_add_1(bevt_46_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_44_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_43_tmpvar_phold);
} /* Line: 55 */
bevt_51_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(1319292247, BEL_4_Base.bevn_boundGet_0);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_49_tmpvar_phold != null && bevt_49_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_49_tmpvar_phold).bevi_bool) /* Line: 57 */ {
bevl_nd = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_53_tmpvar_phold = bevp_inMtd.bem_heldGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_54_tmpvar_phold = (new BEC_4_6_TextString(4, bels_4));
bevl_v = bevt_52_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_nd.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_55_tmpvar_phold);
bevt_56_tmpvar_phold = bevl_v.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_56_tmpvar_phold);
bevt_57_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_57_tmpvar_phold.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_58_tmpvar_phold);
beva_node.bem_prepend_1((BEC_5_4_BuildNode) bevl_nd);
} /* Line: 64 */
bevt_61_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = (new BEC_4_6_TextString(6, bels_5));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_62_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 67 */ {
bevt_63_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_63_tmpvar_phold;
} /* Line: 68 */
bevl_unwind = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_c0 = beva_node.bem_containerGet_0();
if (bevl_c0 == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 72 */ {
bevt_66_tmpvar_phold = (new BEC_4_6_TextString(28, bels_6));
bevt_65_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_66_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_65_tmpvar_phold);
} /* Line: 73 */
bevt_68_tmpvar_phold = bevl_c0.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 77 */ {
bevt_72_tmpvar_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_73_tmpvar_phold = (new BEC_4_6_TextString(6, bels_7));
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_73_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 77 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
 else  /* Line: 77 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 77 */ {
bevt_74_tmpvar_phold = beva_node.bem_isSecondGet_0();
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
 else  /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 77 */ {
bevl_unwind = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 78 */
 else  /* Line: 77 */ {
bevt_76_tmpvar_phold = bevl_c0.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_77_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_77_tmpvar_phold);
if (bevt_75_tmpvar_phold != null && bevt_75_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_75_tmpvar_phold).bevi_bool) /* Line: 79 */ {
bevl_unwind = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 80 */
} /* Line: 77 */
if (bevl_unwind != null && bevl_unwind instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_unwind).bevi_bool) /* Line: 82 */ {
bevl_cnode = bevl_c0;
bevl_lastStep = null;
while (true)
 /* Line: 87 */ {
bevt_79_tmpvar_phold = bevl_cnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_80_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_80_tmpvar_phold);
if (bevt_78_tmpvar_phold != null && bevt_78_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_78_tmpvar_phold).bevi_bool) /* Line: 87 */ {
bevl_lastStep = bevl_cnode;
bevl_cnode = bevl_cnode.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 90 */
 else  /* Line: 87 */ {
break;
} /* Line: 87 */
} /* Line: 87 */
bevt_81_tmpvar_phold = (new BEC_4_6_TextString(5, bels_8));
bevl_pholdv = bevl_lastStep.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_81_tmpvar_phold, bevp_build);
bevl_phold = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_82_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_82_tmpvar_phold);
bevl_phold.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_pholdv);
beva_node.bem_replaceWith_1((BEC_5_4_BuildNode) bevl_phold);
bevl_phold.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_prc = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_prc.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_83_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_prc.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_83_tmpvar_phold);
bevl_prcc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_84_tmpvar_phold = (new BEC_4_6_TextString(6, bels_9));
bevl_prcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_84_tmpvar_phold);
bevl_prc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_prcc);
bevl_phold2 = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold2.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_85_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold2.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_85_tmpvar_phold);
bevl_phold2.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_pholdv);
bevl_prc.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_phold2);
bevl_prc.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
bevl_lastStep.bemd_1(1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_prc);
bevt_86_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpvar_phold;
} /* Line: 115 */
} /* Line: 82 */
bevt_87_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_87_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_inMtdGet_0() throws Throwable {
return bevp_inMtd;
} /*method end*/
public BEC_6_6_SystemObject bem_inMtdSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inMtd = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {28, 28, 28, 29, 30, 30, 30, 30, 30, 30, 31, 33, 33, 33, 33, 33, 34, 35, 35, 36, 38, 40, 41, 43, 43, 43, 44, 45, 45, 45, 45, 45, 46, 46, 47, 47, 47, 47, 52, 52, 52, 54, 54, 54, 54, 0, 54, 54, 54, 54, 0, 0, 54, 54, 54, 54, 0, 0, 0, 55, 55, 55, 55, 55, 55, 55, 57, 57, 57, 58, 59, 60, 60, 60, 60, 61, 61, 62, 62, 63, 63, 63, 64, 67, 67, 67, 67, 68, 68, 70, 71, 72, 72, 73, 73, 73, 77, 77, 77, 77, 77, 77, 77, 0, 0, 0, 77, 0, 0, 0, 78, 79, 79, 79, 80, 83, 84, 87, 87, 87, 89, 90, 95, 95, 96, 97, 98, 98, 99, 100, 101, 102, 103, 104, 104, 105, 106, 106, 107, 108, 109, 110, 110, 111, 112, 113, 114, 115, 115, 118, 118, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {128, 129, 130, 132, 133, 134, 135, 136, 137, 142, 143, 145, 146, 147, 148, 151, 153, 154, 159, 160, 162, 168, 169, 171, 172, 173, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 188, 189, 190, 192, 193, 194, 195, 197, 200, 201, 202, 203, 205, 208, 212, 213, 214, 215, 217, 220, 224, 227, 228, 229, 230, 231, 232, 233, 235, 236, 237, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 254, 255, 256, 257, 259, 260, 262, 263, 264, 269, 270, 271, 272, 274, 275, 276, 278, 279, 280, 281, 283, 286, 290, 293, 295, 298, 302, 305, 308, 309, 310, 312, 316, 317, 320, 321, 322, 324, 325, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 360, 361, 364, 367};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 28 128
typenameGet 0 28 128
assign 1 28 129
EXPRGet 0 28 129
assign 1 28 130
equals 1 28 130
assign 1 29 132
assign 1 30 133
containedGet 0 30 133
assign 1 30 134
firstGet 0 30 134
assign 1 30 135
containedGet 0 30 135
assign 1 30 136
firstNodeGet 0 30 136
assign 1 30 137
undef 1 30 142
assign 1 31 143
nextDescendGet 0 31 143
assign 1 33 145
containedGet 0 33 145
assign 1 33 146
firstGet 0 33 146
assign 1 33 147
containedGet 0 33 147
assign 1 33 148
iteratorGet 0 33 148
assign 1 33 151
hasNextGet 0 33 151
assign 1 34 153
nextGet 0 34 153
assign 1 35 154
undef 1 35 159
assign 1 36 160
beforeInsert 1 38 162
delete 0 40 168
return 1 41 169
assign 1 43 171
typenameGet 0 43 171
assign 1 43 172
METHODGet 0 43 172
assign 1 43 173
equals 1 43 173
assign 1 44 175
assign 1 45 176
heldGet 0 45 176
assign 1 45 177
varMapGet 0 45 177
assign 1 45 178
new 0 45 178
assign 1 45 179
get 1 45 179
assign 1 45 180
heldGet 0 45 180
assign 1 46 181
new 0 46 181
isTypedSet 1 46 182
assign 1 47 183
classGet 0 47 183
assign 1 47 184
heldGet 0 47 184
assign 1 47 185
namepathGet 0 47 185
namepathSet 1 47 186
assign 1 52 188
typenameGet 0 52 188
assign 1 52 189
CALLGet 0 52 189
assign 1 52 190
equals 1 52 190
assign 1 54 192
heldGet 0 54 192
assign 1 54 193
nameGet 0 54 193
assign 1 54 194
new 0 54 194
assign 1 54 195
equals 1 54 195
assign 1 0 197
assign 1 54 200
heldGet 0 54 200
assign 1 54 201
nameGet 0 54 201
assign 1 54 202
new 0 54 202
assign 1 54 203
equals 1 54 203
assign 1 0 205
assign 1 0 208
assign 1 54 212
containedGet 0 54 212
assign 1 54 213
lengthGet 0 54 213
assign 1 54 214
new 0 54 214
assign 1 54 215
greater 1 54 215
assign 1 0 217
assign 1 0 220
assign 1 0 224
assign 1 55 227
new 0 55 227
assign 1 55 228
containedGet 0 55 228
assign 1 55 229
lengthGet 0 55 229
assign 1 55 230
toString 0 55 230
assign 1 55 231
add 1 55 231
assign 1 55 232
new 2 55 232
throw 1 55 233
assign 1 57 235
heldGet 0 57 235
assign 1 57 236
boundGet 0 57 236
assign 1 57 237
not 0 57 237
assign 1 58 239
new 1 58 239
copyLoc 1 59 240
assign 1 60 241
heldGet 0 60 241
assign 1 60 242
varMapGet 0 60 242
assign 1 60 243
new 0 60 243
assign 1 60 244
get 1 60 244
assign 1 61 245
VARGet 0 61 245
typenameSet 1 61 246
assign 1 62 247
heldGet 0 62 247
heldSet 1 62 248
assign 1 63 249
heldGet 0 63 249
assign 1 63 250
new 0 63 250
boundSet 1 63 251
prepend 1 64 252
assign 1 67 254
heldGet 0 67 254
assign 1 67 255
nameGet 0 67 255
assign 1 67 256
new 0 67 256
assign 1 67 257
equals 1 67 257
assign 1 68 259
nextDescendGet 0 68 259
return 1 68 260
assign 1 70 262
new 0 70 262
assign 1 71 263
containerGet 0 71 263
assign 1 72 264
undef 1 72 269
assign 1 73 270
new 0 73 270
assign 1 73 271
new 2 73 271
throw 1 73 272
assign 1 77 274
typenameGet 0 77 274
assign 1 77 275
CALLGet 0 77 275
assign 1 77 276
equals 1 77 276
assign 1 77 278
heldGet 0 77 278
assign 1 77 279
nameGet 0 77 279
assign 1 77 280
new 0 77 280
assign 1 77 281
equals 1 77 281
assign 1 0 283
assign 1 0 286
assign 1 0 290
assign 1 77 293
isSecondGet 0 77 293
assign 1 0 295
assign 1 0 298
assign 1 0 302
assign 1 78 305
new 0 78 305
assign 1 79 308
typenameGet 0 79 308
assign 1 79 309
BRACESGet 0 79 309
assign 1 79 310
equals 1 79 310
assign 1 80 312
new 0 80 312
assign 1 83 316
assign 1 84 317
assign 1 87 320
typenameGet 0 87 320
assign 1 87 321
BRACESGet 0 87 321
assign 1 87 322
notEquals 1 87 322
assign 1 89 324
assign 1 90 325
containerGet 0 90 325
assign 1 95 331
new 0 95 331
assign 1 95 332
tmpVar 2 95 332
assign 1 96 333
new 1 96 333
copyLoc 1 97 334
assign 1 98 335
VARGet 0 98 335
typenameSet 1 98 336
heldSet 1 99 337
replaceWith 1 100 338
addVariable 0 101 339
assign 1 102 340
new 1 102 340
copyLoc 1 103 341
assign 1 104 342
CALLGet 0 104 342
typenameSet 1 104 343
assign 1 105 344
new 0 105 344
assign 1 106 345
new 0 106 345
nameSet 1 106 346
heldSet 1 107 347
assign 1 108 348
new 1 108 348
copyLoc 1 109 349
assign 1 110 350
VARGet 0 110 350
typenameSet 1 110 351
heldSet 1 111 352
addValue 1 112 353
addValue 1 113 354
beforeInsert 1 114 355
assign 1 115 356
nextDescendGet 0 115 356
return 1 115 357
assign 1 118 360
nextDescendGet 0 118 360
return 1 118 361
return 1 0 364
assign 1 0 367
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 850314193: return bem_inMtdGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 839231940: return bem_inMtdSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_6_BuildVisitPass11();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_6_BuildVisitPass11.bevs_inst = (BEC_5_5_6_BuildVisitPass11)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_6_BuildVisitPass11.bevs_inst;
}
}
