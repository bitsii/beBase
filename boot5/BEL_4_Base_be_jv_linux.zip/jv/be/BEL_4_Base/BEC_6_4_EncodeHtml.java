package be.BEL_4_Base;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_6_4_EncodeHtml extends BEC_6_6_SystemObject {
public BEC_6_4_EncodeHtml() { }
private static byte[] becc_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x74,0x6D,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(127));
private static byte[] bels_0 = {0x22};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_0, 1));
private static byte[] bels_1 = {0x3C};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_1, 1));
private static byte[] bels_2 = {0x3E};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x26};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x26,0x23};
private static byte[] bels_5 = {0x3B};
public static BEC_6_4_EncodeHtml bevs_inst;
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_4_EncodeHtml bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_encode_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_6_TextString bevl_r = null;
BEC_4_12_TextByteIterator bevl_tb = null;
BEC_4_6_TextString bevl_pt = null;
BEC_4_3_MathInt bevl_ac = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_6_tmpvar_phold = bevo_0;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_multiply_1(bevt_6_tmpvar_phold);
bevl_r = (new BEC_4_6_TextString()).bem_new_1(bevt_4_tmpvar_phold);
bevl_tb = (new BEC_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_7_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevl_pt = (new BEC_4_6_TextString()).bem_new_1(bevt_7_tmpvar_phold);
while (true)
 /* Line: 138 */ {
bevt_8_tmpvar_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_9_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_9_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = bevl_ac.bem_greater_1(bevt_11_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_13_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevl_pt.bem_equals_1(bevt_13_tmpvar_phold);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_15_tmpvar_phold = bevo_3;
bevt_14_tmpvar_phold = bevl_pt.bem_equals_1(bevt_15_tmpvar_phold);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_17_tmpvar_phold = bevo_4;
bevt_16_tmpvar_phold = bevl_pt.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_19_tmpvar_phold = bevo_5;
bevt_18_tmpvar_phold = bevl_pt.bem_equals_1(bevt_19_tmpvar_phold);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(2, bels_4));
bevl_r.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = bevl_ac.bem_toString_0();
bevl_r.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(1, bels_5));
bevl_r.bem_addValue_1(bevt_22_tmpvar_phold);
} /* Line: 144 */
 else  /* Line: 145 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 146 */
} /* Line: 141 */
 else  /* Line: 138 */ {
break;
} /* Line: 138 */
} /* Line: 138 */
return bevl_r;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {135, 135, 135, 135, 136, 137, 137, 138, 139, 140, 140, 141, 141, 0, 141, 141, 0, 0, 0, 141, 141, 0, 0, 0, 141, 141, 0, 0, 0, 141, 141, 0, 0, 142, 142, 143, 143, 144, 144, 146, 149};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {56, 57, 58, 59, 60, 61, 62, 65, 67, 68, 69, 70, 71, 73, 76, 77, 79, 82, 86, 89, 90, 92, 95, 99, 102, 103, 105, 108, 112, 115, 116, 118, 121, 125, 126, 127, 128, 129, 130, 133, 140};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 135 56
sizeGet 0 135 56
assign 1 135 57
new 0 135 57
assign 1 135 58
multiply 1 135 58
assign 1 135 59
new 1 135 59
assign 1 136 60
new 1 136 60
assign 1 137 61
new 0 137 61
assign 1 137 62
new 1 137 62
assign 1 138 65
hasNextGet 0 138 65
next 1 139 67
assign 1 140 68
new 0 140 68
assign 1 140 69
getCode 1 140 69
assign 1 141 70
new 0 141 70
assign 1 141 71
greater 1 141 71
assign 1 0 73
assign 1 141 76
new 0 141 76
assign 1 141 77
equals 1 141 77
assign 1 0 79
assign 1 0 82
assign 1 0 86
assign 1 141 89
new 0 141 89
assign 1 141 90
equals 1 141 90
assign 1 0 92
assign 1 0 95
assign 1 0 99
assign 1 141 102
new 0 141 102
assign 1 141 103
equals 1 141 103
assign 1 0 105
assign 1 0 108
assign 1 0 112
assign 1 141 115
new 0 141 115
assign 1 141 116
equals 1 141 116
assign 1 0 118
assign 1 0 121
assign 1 142 125
new 0 142 125
addValue 1 142 126
assign 1 143 127
toString 0 143 127
addValue 1 143 128
assign 1 144 129
new 0 144 129
addValue 1 144 130
addValue 1 146 133
return 1 149 140
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1711217736: return bem_encode_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_4_EncodeHtml();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_4_EncodeHtml.bevs_inst = (BEC_6_4_EncodeHtml)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_4_EncodeHtml.bevs_inst;
}
}
