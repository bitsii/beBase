package be.BEL_4_Base;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_6_6_15_SystemThreadContainerLocker extends BEC_6_6_SystemObject {
public BEC_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_6_6_15_SystemThreadContainerLocker bevs_inst;
public BEC_6_6_4_SystemThreadLock bevp_lock;
public BEC_6_6_SystemObject bevp_container;
public BEC_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_6_6_SystemObject beva__container) throws Throwable {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_6_6_4_SystemThreadLock) (new BEC_6_6_4_SystemThreadLock()).bem_new_0();
bevp_lock.bem_lock_0();
try  /* Line: 822 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 824 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 827 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_key) throws Throwable {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 833 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 835 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 838 */
return bevl_r;
} /*method end*/
public BEC_5_4_LogicBool bem_has_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_key2) throws Throwable {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 845 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_2(99049421, BEL_4_Base.bevn_has_2, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 847 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 850 */
return bevl_r;
} /*method end*/
public BEC_6_6_SystemObject bem_get_0() throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 857 */ {
bevl_r = bevp_container.bemd_0(98246023, BEL_4_Base.bevn_get_0);
bevp_lock.bem_unlock_0();
} /* Line: 859 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 862 */
return bevl_r;
} /*method end*/
public BEC_6_6_SystemObject bem_get_1(BEC_6_6_SystemObject beva_key) throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 869 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 871 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 874 */
return bevl_r;
} /*method end*/
public BEC_6_6_SystemObject bem_getAndClear_1(BEC_6_6_SystemObject beva_key) throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 881 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 884 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 887 */
return bevl_r;
} /*method end*/
public BEC_6_6_SystemObject bem_get_2(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 894 */ {
bevl_r = bevp_container.bemd_2(98246025, BEL_4_Base.bevn_get_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 896 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 899 */
return bevl_r;
} /*method end*/
public BEC_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_6_6_SystemObject beva_key) throws Throwable {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 906 */ {
bevp_container.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 908 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 911 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_putReturn_1(BEC_6_6_SystemObject beva_key) throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 917 */ {
bevl_r = bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 919 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 922 */
return bevl_r;
} /*method end*/
public BEC_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_6_6_SystemObject beva_key) throws Throwable {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 929 */ {
bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 931 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 934 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_putReturn_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 940 */ {
bevl_r = bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 942 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 945 */
return bevl_r;
} /*method end*/
public BEC_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 952 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 954 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 957 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_testAndPut_3(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_oldValue, BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_6_6_SystemObject bevl_rc = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 963 */ {
bevl_rc = bevp_container.bemd_3(250195426, BEL_4_Base.bevn_testAndPut_3, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 965 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 968 */
return bevl_rc;
} /*method end*/
public BEC_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_9_3_ContainerMap bevl_rc = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 975 */ {
bevl_rc = (BEC_9_3_ContainerMap) bevp_container.bemd_0(1959489623, BEL_4_Base.bevn_getMap_0);
bevp_lock.bem_unlock_0();
} /* Line: 977 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 980 */
return bevl_rc;
} /*method end*/
public BEC_6_6_SystemObject bem_getMap_1(BEC_4_6_TextString beva_prefix) throws Throwable {
BEC_9_3_ContainerMap bevl_rc = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 987 */ {
bevl_rc = (BEC_9_3_ContainerMap) bevp_container.bemd_1(1959489624, BEL_4_Base.bevn_getMap_1, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 989 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 992 */
return bevl_rc;
} /*method end*/
public BEC_5_4_LogicBool bem_putIfAbsent_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_5_4_LogicBool bevl_didPut = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 999 */ {
bevt_0_tmpvar_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1000 */ {
bevl_didPut = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1001 */
 else  /* Line: 1002 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_didPut = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1004 */
bevp_lock.bem_unlock_0();
} /* Line: 1006 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1009 */
return bevl_didPut;
} /*method end*/
public BEC_6_6_SystemObject bem_getOrPut_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_6_6_SystemObject bevl_result = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1016 */ {
bevt_0_tmpvar_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1017 */ {
bevl_result = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
} /* Line: 1018 */
 else  /* Line: 1019 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1021 */
bevp_lock.bem_unlock_0();
} /* Line: 1023 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1026 */
return bevl_result;
} /*method end*/
public BEC_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k, BEC_6_6_SystemObject beva_v) throws Throwable {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1033 */ {
bevp_container.bemd_3(107034371, BEL_4_Base.bevn_put_3, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1035 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1038 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_delete_1(BEC_6_6_SystemObject beva_key) throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1044 */ {
bevl_r = bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1046 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1049 */
return bevl_r;
} /*method end*/
public BEC_6_6_SystemObject bem_delete_2(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1056 */ {
bevl_r = bevp_container.bemd_2(819712670, BEL_4_Base.bevn_delete_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1058 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1061 */
return bevl_r;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_4_3_MathInt bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1068 */ {
bevl_r = (BEC_4_3_MathInt) bevp_container.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1070 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1073 */
return bevl_r;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1080 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_0(1089531140, BEL_4_Base.bevn_isEmptyGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1082 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1085 */
return bevl_r;
} /*method end*/
public BEC_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1092 */ {
bevl_r = bevp_container.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevp_lock.bem_unlock_0();
} /* Line: 1094 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1097 */
return bevl_r;
} /*method end*/
public BEC_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1104 */ {
bevp_container.bemd_0(856777406, BEL_4_Base.bevn_clear_0);
bevp_lock.bem_unlock_0();
} /* Line: 1106 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1109 */
return this;
} /*method end*/
public BEC_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1115 */ {
bevp_container.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_lock.bem_unlock_0();
} /* Line: 1117 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1120 */
return this;
} /*method end*/
public BEC_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_6_6_SystemObject bem_lockSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lock = (BEC_6_6_4_SystemThreadLock) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_container = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {818, 821, 823, 824, 826, 827, 832, 834, 835, 837, 838, 840, 844, 846, 847, 849, 850, 852, 856, 858, 859, 861, 862, 864, 868, 870, 871, 873, 874, 876, 880, 882, 883, 884, 886, 887, 889, 893, 895, 896, 898, 899, 901, 905, 907, 908, 910, 911, 916, 918, 919, 921, 922, 924, 928, 930, 931, 933, 934, 939, 941, 942, 944, 945, 947, 951, 953, 954, 956, 957, 962, 964, 965, 967, 968, 970, 974, 976, 977, 979, 980, 982, 986, 988, 989, 991, 992, 994, 998, 1000, 1001, 1003, 1004, 1006, 1008, 1009, 1011, 1015, 1017, 1018, 1020, 1021, 1023, 1025, 1026, 1028, 1032, 1034, 1035, 1037, 1038, 1043, 1045, 1046, 1048, 1049, 1051, 1055, 1057, 1058, 1060, 1061, 1063, 1067, 1069, 1070, 1072, 1073, 1075, 1079, 1081, 1082, 1084, 1085, 1087, 1091, 1093, 1094, 1096, 1097, 1099, 1103, 1105, 1106, 1108, 1109, 1114, 1116, 1117, 1119, 1120, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 17, 18, 22, 23, 30, 32, 33, 37, 38, 40, 45, 47, 48, 52, 53, 55, 60, 62, 63, 67, 68, 70, 75, 77, 78, 82, 83, 85, 90, 92, 93, 94, 98, 99, 101, 106, 108, 109, 113, 114, 116, 120, 122, 123, 127, 128, 135, 137, 138, 142, 143, 145, 149, 151, 152, 156, 157, 164, 166, 167, 171, 172, 174, 178, 180, 181, 185, 186, 193, 195, 196, 200, 201, 203, 208, 210, 211, 215, 216, 218, 223, 225, 226, 230, 231, 233, 239, 241, 243, 246, 247, 249, 253, 254, 256, 262, 264, 266, 269, 270, 272, 276, 277, 279, 283, 285, 286, 290, 291, 298, 300, 301, 305, 306, 308, 313, 315, 316, 320, 321, 323, 328, 330, 331, 335, 336, 338, 343, 345, 346, 350, 351, 353, 358, 360, 361, 365, 366, 368, 372, 374, 375, 379, 380, 386, 388, 389, 393, 394, 399, 402, 406, 409};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 818 14
new 0 818 14
lock 0 821 15
assign 1 823 17
unlock 0 824 18
unlock 0 826 22
throw 1 827 23
lock 0 832 30
assign 1 834 32
has 1 834 32
unlock 0 835 33
unlock 0 837 37
throw 1 838 38
return 1 840 40
lock 0 844 45
assign 1 846 47
has 2 846 47
unlock 0 847 48
unlock 0 849 52
throw 1 850 53
return 1 852 55
lock 0 856 60
assign 1 858 62
get 0 858 62
unlock 0 859 63
unlock 0 861 67
throw 1 862 68
return 1 864 70
lock 0 868 75
assign 1 870 77
get 1 870 77
unlock 0 871 78
unlock 0 873 82
throw 1 874 83
return 1 876 85
lock 0 880 90
assign 1 882 92
get 1 882 92
delete 1 883 93
unlock 0 884 94
unlock 0 886 98
throw 1 887 99
return 1 889 101
lock 0 893 106
assign 1 895 108
get 2 895 108
unlock 0 896 109
unlock 0 898 113
throw 1 899 114
return 1 901 116
lock 0 905 120
addValue 1 907 122
unlock 0 908 123
unlock 0 910 127
throw 1 911 128
lock 0 916 135
assign 1 918 137
put 1 918 137
unlock 0 919 138
unlock 0 921 142
throw 1 922 143
return 1 924 145
lock 0 928 149
put 1 930 151
unlock 0 931 152
unlock 0 933 156
throw 1 934 157
lock 0 939 164
assign 1 941 166
put 2 941 166
unlock 0 942 167
unlock 0 944 171
throw 1 945 172
return 1 947 174
lock 0 951 178
put 2 953 180
unlock 0 954 181
unlock 0 956 185
throw 1 957 186
lock 0 962 193
assign 1 964 195
testAndPut 3 964 195
unlock 0 965 196
unlock 0 967 200
throw 1 968 201
return 1 970 203
lock 0 974 208
assign 1 976 210
getMap 0 976 210
unlock 0 977 211
unlock 0 979 215
throw 1 980 216
return 1 982 218
lock 0 986 223
assign 1 988 225
getMap 1 988 225
unlock 0 989 226
unlock 0 991 230
throw 1 992 231
return 1 994 233
lock 0 998 239
assign 1 1000 241
has 1 1000 241
assign 1 1001 243
new 0 1001 243
put 2 1003 246
assign 1 1004 247
new 0 1004 247
unlock 0 1006 249
unlock 0 1008 253
throw 1 1009 254
return 1 1011 256
lock 0 1015 262
assign 1 1017 264
has 1 1017 264
assign 1 1018 266
get 1 1018 266
put 2 1020 269
assign 1 1021 270
unlock 0 1023 272
unlock 0 1025 276
throw 1 1026 277
return 1 1028 279
lock 0 1032 283
put 3 1034 285
unlock 0 1035 286
unlock 0 1037 290
throw 1 1038 291
lock 0 1043 298
assign 1 1045 300
delete 1 1045 300
unlock 0 1046 301
unlock 0 1048 305
throw 1 1049 306
return 1 1051 308
lock 0 1055 313
assign 1 1057 315
delete 2 1057 315
unlock 0 1058 316
unlock 0 1060 320
throw 1 1061 321
return 1 1063 323
lock 0 1067 328
assign 1 1069 330
sizeGet 0 1069 330
unlock 0 1070 331
unlock 0 1072 335
throw 1 1073 336
return 1 1075 338
lock 0 1079 343
assign 1 1081 345
isEmptyGet 0 1081 345
unlock 0 1082 346
unlock 0 1084 350
throw 1 1085 351
return 1 1087 353
lock 0 1091 358
assign 1 1093 360
copy 0 1093 360
unlock 0 1094 361
unlock 0 1096 365
throw 1 1097 366
return 1 1099 368
lock 0 1103 372
clear 0 1105 374
unlock 0 1106 375
unlock 0 1108 379
throw 1 1109 380
lock 0 1114 386
close 0 1116 388
unlock 0 1117 389
unlock 0 1119 393
throw 1 1120 394
return 1 0 399
assign 1 0 402
return 1 0 406
assign 1 0 409
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 833063302: return bem_containerGet_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 952571108: return bem_lockGet_0();
case 866536361: return bem_close_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 98246023: return bem_get_0();
case 1820417453: return bem_create_0();
case 454584637: return bem_copyContainer_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 1959489623: return bem_getMap_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 941488855: return bem_lockSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 365996783: return bem_putReturn_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1572587742: return bem_getAndClear_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1959489624: return bem_getMap_1((BEC_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2(bevd_0, bevd_1);
case 98246025: return bem_get_2(bevd_0, bevd_1);
case 819712670: return bem_delete_2(bevd_0, bevd_1);
case 99049421: return bem_has_2(bevd_0, bevd_1);
case 365996782: return bem_putReturn_2(bevd_0, bevd_1);
case 188241239: return bem_getOrPut_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 2074693976: return bem_putIfAbsent_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 107034371: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 250195426: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_6_15_SystemThreadContainerLocker.bevs_inst = (BEC_6_6_15_SystemThreadContainerLocker)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_6_15_SystemThreadContainerLocker.bevs_inst;
}
}
