package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_8_BuildClassSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 9));
private static byte[] bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_4, 78));
private static byte[] bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_5, 12));
private static byte[] bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_6, 38));
private static byte[] bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_7, 68));
private static byte[] bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_8, 75));
private static byte[] bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_10, 65));
private static byte[] bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_11, 11));
private static byte[] bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_12, 33));
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_14, 95));
private static byte[] bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x62,0x75,0x74,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_15, 90));
private static byte[] bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_16, 84));
private static byte[] bels_17 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_17, 80));
private static byte[] bels_18 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_18, 9));
private static byte[] bels_19 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_19, 26));
public static BEC_2_5_8_BuildClassSyn bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_4_ContainerList bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_4_ContainerList bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public BEC_2_5_8_BuildClassSyn bem_new_0() throws Throwable {
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
bevp_integrated = be.BECS_Runtime.boolFalse;
bevp_iChecked = be.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_maxMtdx = (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 99 */ {
bevt_0_tmpany_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 101 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 102 */
} /* Line: 101 */
 else  /* Line: 99 */ {
break;
} /* Line: 99 */
} /* Line: 99 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpany_phold);
if (bevl_dmtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 112 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) throws Throwable {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
bevp_integrated = be.BECS_Runtime.boolFalse;
bevp_iChecked = be.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = beva_psyn.bemd_0(-1974592946, BEL_4_Base.bevn_superListGet_0);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_3_tmpany_phold = beva_psyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_superList.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = beva_psyn.bemd_0(1477961836, BEL_4_Base.bevn_mtdListGet_0);
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_4_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_5_tmpany_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_5_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_7_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_6_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 135 */ {
bevt_8_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = beva_psyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_11_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_9_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_10_tmpany_phold);
bevt_14_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_1));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_15_tmpany_phold);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 138 */ {
if (bevl_pv == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
 else  /* Line: 138 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 138 */ {
bevt_19_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpany_phold).bevi_bool) /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
 else  /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 138 */ {
bevt_24_tmpany_phold = bevo_1;
bevt_26_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevo_2;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 139 */
} /* Line: 138 */
 else  /* Line: 135 */ {
break;
} /* Line: 135 */
} /* Line: 135 */
bevt_31_tmpany_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevl_iv = bevt_31_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 144 */ {
bevt_32_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 144 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpany_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_33_tmpany_phold != null && bevt_33_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpany_phold).bevi_bool) /* Line: 146 */ {
bevt_35_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpany_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpany_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_36_tmpany_phold);
} /* Line: 147 */
} /* Line: 146 */
 else  /* Line: 144 */ {
break;
} /* Line: 144 */
} /* Line: 144 */
bevt_39_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_38_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 151 */ {
bevt_40_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpany_phold).bevi_bool) /* Line: 151 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpany_phold = beva_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_43_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_41_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_42_tmpany_phold);
if (bevl_pm == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_46_tmpany_phold = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevt_46_tmpany_phold == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevt_49_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_48_tmpany_phold == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_54_tmpany_phold = bevo_3;
bevt_56_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_add_1(bevt_55_tmpany_phold);
bevt_57_tmpany_phold = bevo_4;
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bem_add_1(bevt_57_tmpany_phold);
bevt_59_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_50_tmpany_phold);
} /* Line: 157 */
} /* Line: 156 */
} /* Line: 155 */
} /* Line: 154 */
 else  /* Line: 151 */ {
break;
} /* Line: 151 */
} /* Line: 151 */
this.bem_loadClass_1(beva_klass);
bevt_60_tmpany_phold = beva_psyn.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevt_61_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_61_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpany_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 171 */ {
return this;
} /* Line: 171 */
bevp_integrated = be.BECS_Runtime.boolTrue;
bevp_directProperties = be.BECS_Runtime.boolTrue;
bevp_directMethods = be.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 176 */ {
bevp_allAncestorsClose = be.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpany_loop = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 181 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 181 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_methodIndexesGet_0();
bevt_10_tmpany_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpany_phold.bem_put_1(bevt_10_tmpany_phold);
} /* Line: 182 */
 else  /* Line: 181 */ {
break;
} /* Line: 181 */
} /* Line: 181 */
return this;
} /* Line: 184 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (new BEC_2_4_3_MathInt(0));
bevt_11_tmpany_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpany_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpany_phold.bem_subtract_1(bevt_12_tmpany_phold);
bevt_15_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 191 */
bevt_16_tmpany_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_19_tmpany_phold = bevo_5;
bevt_20_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_17_tmpany_phold);
} /* Line: 193 */
bevt_21_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_23_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_26_tmpany_phold = bevo_6;
bevt_27_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 196 */
bevt_28_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 198 */ {
if (bevp_isLocal.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 198 */
 else  /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 198 */ {
if (bevp_isFinal.bevi_bool) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 198 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 198 */
 else  /* Line: 198 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 198 */ {
bevt_33_tmpany_phold = bevo_7;
bevt_34_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_31_tmpany_phold);
} /* Line: 199 */
bevt_1_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 201 */ {
bevt_35_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_35_tmpany_phold != null && bevt_35_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpany_phold).bevi_bool) /* Line: 201 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_has_1(bevt_39_tmpany_phold);
if (bevt_37_tmpany_phold.bevi_bool) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevt_41_tmpany_phold = bevl_pn.bem_toString_0();
bevt_42_tmpany_phold = bevo_8;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_notEquals_1(bevt_42_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 203 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 203 */
 else  /* Line: 203 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 203 */ {
bevp_directProperties = be.BECS_Runtime.boolFalse;
bevp_directMethods = be.BECS_Runtime.boolFalse;
} /* Line: 206 */
bevt_45_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
} /* Line: 209 */
} /* Line: 208 */
 else  /* Line: 201 */ {
break;
} /* Line: 201 */
} /* Line: 201 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 213 */ {
bevt_47_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpany_phold != null && bevt_47_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpany_phold).bevi_bool) /* Line: 213 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_48_tmpany_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpany_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
if (bevl_pm == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevt_51_tmpany_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpany_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 220 */
} /* Line: 217 */
 else  /* Line: 222 */ {
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpany_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_methodIndexesGet_0();
bevt_57_tmpany_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpany_phold.bem_put_1(bevt_57_tmpany_phold);
} /* Line: 226 */
} /* Line: 216 */
 else  /* Line: 213 */ {
break;
} /* Line: 213 */
} /* Line: 213 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 233 */ {
return this;
} /* Line: 233 */
bevp_iChecked = be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 235 */ {
return this;
} /* Line: 235 */
bevl_psyn = beva_build.bemd_1(-706249818, BEL_4_Base.bevn_getSynNp_1, bevp_superNp);
bevt_5_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_4_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 237 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 237 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpany_phold = bevl_psyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_9_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_7_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_8_tmpany_phold);
if (bevl_pv == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_12_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 241 */ {
bevt_17_tmpany_phold = bevo_9;
bevt_19_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_20_tmpany_phold = bevo_10;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_14_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_13_tmpany_phold);
} /* Line: 242 */
 else  /* Line: 243 */ {
bevt_24_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpany_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_24_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpany_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_28_tmpany_phold);
} /* Line: 245 */
} /* Line: 241 */
} /* Line: 240 */
 else  /* Line: 237 */ {
break;
} /* Line: 237 */
} /* Line: 237 */
bevt_31_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_30_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 249 */ {
bevt_32_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 249 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_33_tmpany_phold = bevl_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_35_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_33_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_34_tmpany_phold);
if (bevl_pm == null) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevt_37_tmpany_phold = bevl_pm.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
if (bevt_37_tmpany_phold != null && bevt_37_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpany_phold).bevi_bool) /* Line: 253 */ {
bevt_42_tmpany_phold = bevo_11;
bevt_44_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_45_tmpany_phold = bevo_12;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_39_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_38_tmpany_phold);
} /* Line: 254 */
bevt_50_tmpany_phold = bevl_om.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_oa = bevt_49_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 257 */ {
bevt_53_tmpany_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_51_tmpany_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_52_tmpany_phold);
if (bevt_51_tmpany_phold != null && bevt_51_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_51_tmpany_phold).bevi_bool) /* Line: 257 */ {
bevt_54_tmpany_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_pmr = bevt_54_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_55_tmpany_phold = bevl_oa.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevl_omr = bevt_55_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
this.bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 257 */
 else  /* Line: 257 */ {
break;
} /* Line: 257 */
} /* Line: 257 */
bevl_pmr = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
bevt_56_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_omr = bevt_56_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevl_pmr == null) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 265 */ {
if (bevl_omr == null) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 265 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 265 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 265 */ {
if (bevl_pmr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 266 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
if (bevl_omr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpany_phold.bevi_bool) /* Line: 266 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 266 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 266 */ {
bevt_65_tmpany_phold = bevo_13;
bevt_68_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_add_1(bevt_66_tmpany_phold);
bevt_63_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_63_tmpany_phold);
} /* Line: 271 */
} /* Line: 266 */
 else  /* Line: 273 */ {
bevt_69_tmpany_phold = bevl_pmr.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_69_tmpany_phold != null && bevt_69_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_69_tmpany_phold).bevi_bool) /* Line: 275 */ {
bevt_71_tmpany_phold = bevl_pmr.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
bevt_72_tmpany_phold = bevl_omr.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_72_tmpany_phold);
if (bevt_70_tmpany_phold != null && bevt_70_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpany_phold).bevi_bool) /* Line: 275 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 275 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 275 */
 else  /* Line: 275 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 275 */ {
bevt_75_tmpany_phold = bevo_14;
bevt_78_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_76_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 276 */
this.bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 278 */
} /* Line: 265 */
} /* Line: 252 */
 else  /* Line: 249 */ {
break;
} /* Line: 249 */
} /* Line: 249 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) throws Throwable {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
bevt_2_tmpany_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_3_tmpany_phold = beva_omr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevt_6_tmpany_phold = bevo_15;
bevt_9_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
bevt_10_tmpany_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_11_tmpany_phold = beva_pmr.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 290 */ {
bevt_12_tmpany_phold = beva_omr.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 290 */ {
return this;
} /* Line: 291 */
bevt_13_tmpany_phold = beva_omr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_osyn = beva_build.bemd_1(-706249818, BEL_4_Base.bevn_getSynNp_1, bevt_13_tmpany_phold);
bevt_16_tmpany_phold = bevl_osyn.bemd_0(-986531569, BEL_4_Base.bevn_allTypesGet_0);
bevt_17_tmpany_phold = beva_pmr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_17_tmpany_phold);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 294 */ {
bevt_20_tmpany_phold = bevo_16;
bevt_23_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_18_tmpany_phold);
} /* Line: 295 */
} /* Line: 294 */
} /* Line: 285 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
this.bem_new_0();
bevt_1_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_0_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 302 */ {
bevt_2_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 302 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 304 */ {
bevt_10_tmpany_phold = bevo_17;
bevt_12_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevo_18;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_16_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 305 */
} /* Line: 304 */
 else  /* Line: 302 */ {
break;
} /* Line: 302 */
} /* Line: 302 */
this.bem_loadClass_1(beva_klass);
bevp_depth = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_1_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_2_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(-1803479881, BEL_4_Base.bevn_libNameGet_0);
bevt_3_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpany_phold.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_4_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpany_phold.bemd_0(-842582618, BEL_4_Base.bevn_isLocalGet_0);
bevt_5_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpany_phold.bemd_0(363636983, BEL_4_Base.bevn_isNotNullGet_0);
bevt_7_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-83882038, BEL_4_Base.bevn_usedGet_0);
bevl_iu = bevt_6_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 320 */ {
bevt_8_tmpany_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 320 */ {
bevl_ou = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = bevl_ou.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_uses.bem_put_1(bevt_9_tmpany_phold);
} /* Line: 322 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
bevt_11_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_10_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 324 */ {
bevt_12_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 324 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 327 */
 else  /* Line: 324 */ {
break;
} /* Line: 324 */
} /* Line: 324 */
bevt_14_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_13_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 329 */ {
bevt_15_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 329 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 332 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
this.bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_postLoad_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_nptyList = null;
BEC_2_9_4_ContainerList bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
bevl_nptyList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_mtdnList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 342 */ {
bevt_1_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 342 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpany_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_5_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_ptyMap.bem_put_2(bevt_5_tmpany_phold, bevl_ov);
} /* Line: 346 */
} /* Line: 344 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 352 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 352 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpany_phold = bevl_unq.bem_has_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 354 */ {
bevt_10_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpany_phold);
bevl_nom.bemd_1(1283009805, BEL_4_Base.bevn_mposSet_1, bevl_mpos);
bevt_11_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpany_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
} /* Line: 359 */
} /* Line: 354 */
 else  /* Line: 352 */ {
break;
} /* Line: 352 */
} /* Line: 352 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 366 */ {
bevt_14_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 366 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_15_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_mtdMap.bem_put_2(bevt_15_tmpany_phold, bevl_om);
bevt_18_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpany_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 371 */ {
bevt_19_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdOmap.bem_put_2(bevt_19_tmpany_phold, bevl_om);
} /* Line: 372 */
} /* Line: 371 */
 else  /* Line: 366 */ {
break;
} /* Line: 366 */
} /* Line: 366 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 378 */ {
bevt_20_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpany_phold != null && bevt_20_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpany_phold).bevi_bool) /* Line: 378 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_22_tmpany_phold = bevl_unq.bem_has_1(bevt_23_tmpany_phold);
if (bevt_22_tmpany_phold.bevi_bool) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 380 */ {
bevt_24_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevt_28_tmpany_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpany_phold);
} /* Line: 392 */
bevt_29_tmpany_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(-885379526, BEL_4_Base.bevn_declarationSet_1, bevt_29_tmpany_phold);
bevl_oma.bemd_1(-1365143591, BEL_4_Base.bevn_mtdxSet_1, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
} /* Line: 398 */
} /* Line: 380 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 403 */ {
bevt_32_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 403 */ {
bevl_s = bevt_0_tmpany_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 405 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() throws Throwable {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
return bevp_depth;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() throws Throwable {
return bevp_newMbrs;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() throws Throwable {
return bevp_newMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() throws Throwable {
return bevp_defMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() throws Throwable {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() throws Throwable {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() throws Throwable {
return bevp_allTypes;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() throws Throwable {
return bevp_superList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() throws Throwable {
return bevp_mtdMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGet_0() throws Throwable {
return bevp_mtdList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() throws Throwable {
return bevp_ptyMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGet_0() throws Throwable {
return bevp_ptyList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() throws Throwable {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() throws Throwable {
return bevp_integrated;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() throws Throwable {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() throws Throwable {
return bevp_uses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() throws Throwable {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() throws Throwable {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {75, 77, 79, 81, 82, 83, 84, 85, 86, 87, 88, 90, 91, 92, 93, 98, 99, 99, 100, 101, 101, 101, 102, 105, 109, 109, 110, 110, 112, 112, 114, 114, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 129, 130, 130, 131, 131, 132, 132, 135, 135, 135, 135, 136, 137, 137, 137, 137, 138, 138, 138, 138, 138, 138, 0, 0, 0, 138, 138, 138, 0, 0, 0, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 144, 144, 144, 145, 146, 146, 147, 147, 147, 147, 151, 151, 151, 151, 152, 153, 153, 153, 153, 154, 154, 155, 155, 155, 156, 156, 156, 156, 157, 157, 157, 157, 157, 157, 157, 157, 157, 157, 157, 162, 163, 163, 163, 167, 167, 171, 172, 173, 174, 175, 176, 176, 177, 178, 179, 180, 181, 0, 181, 181, 182, 182, 182, 182, 184, 186, 187, 188, 190, 190, 190, 190, 191, 191, 191, 192, 193, 193, 193, 193, 193, 195, 195, 195, 0, 0, 0, 196, 196, 196, 196, 196, 198, 198, 198, 0, 0, 0, 198, 198, 0, 0, 0, 199, 199, 199, 199, 199, 201, 0, 201, 201, 202, 203, 203, 203, 203, 203, 203, 203, 203, 0, 0, 0, 205, 206, 208, 208, 208, 208, 208, 209, 213, 213, 214, 215, 215, 215, 216, 216, 217, 218, 218, 219, 219, 220, 223, 223, 224, 225, 226, 226, 226, 226, 233, 234, 235, 235, 235, 236, 237, 237, 237, 237, 238, 239, 239, 239, 239, 240, 240, 241, 241, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 244, 244, 244, 244, 245, 245, 245, 245, 249, 249, 249, 249, 250, 251, 251, 251, 251, 252, 252, 253, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 256, 256, 256, 257, 257, 257, 257, 258, 258, 259, 259, 261, 257, 263, 264, 264, 265, 265, 0, 265, 265, 0, 0, 266, 266, 266, 0, 266, 266, 266, 0, 0, 271, 271, 271, 271, 271, 271, 271, 275, 275, 275, 275, 0, 0, 0, 276, 276, 276, 276, 276, 276, 276, 278, 285, 285, 285, 286, 286, 286, 286, 286, 286, 286, 287, 290, 290, 0, 0, 0, 291, 293, 293, 294, 294, 294, 294, 295, 295, 295, 295, 295, 295, 295, 301, 302, 302, 302, 302, 303, 304, 304, 304, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 308, 309, 314, 314, 315, 315, 316, 316, 317, 317, 318, 318, 319, 319, 320, 320, 320, 320, 321, 322, 322, 324, 324, 324, 324, 325, 326, 327, 329, 329, 329, 329, 330, 331, 332, 334, 338, 339, 342, 342, 343, 344, 344, 344, 344, 346, 346, 350, 351, 352, 352, 353, 354, 354, 354, 354, 355, 355, 356, 357, 357, 358, 359, 359, 359, 362, 364, 366, 366, 367, 369, 369, 371, 371, 371, 371, 372, 372, 376, 377, 378, 378, 379, 380, 380, 380, 380, 381, 381, 390, 390, 391, 391, 391, 392, 392, 394, 394, 395, 396, 397, 398, 398, 398, 401, 403, 0, 403, 403, 404, 405, 408, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 99, 100, 103, 105, 106, 107, 112, 113, 120, 128, 129, 130, 135, 136, 137, 139, 140, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 237, 239, 240, 241, 242, 243, 244, 245, 246, 247, 249, 254, 255, 258, 262, 265, 266, 267, 269, 272, 276, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 297, 298, 301, 303, 304, 305, 307, 308, 309, 310, 317, 318, 319, 322, 324, 325, 326, 327, 328, 329, 334, 335, 336, 341, 342, 343, 344, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 369, 370, 371, 372, 377, 378, 446, 448, 449, 450, 451, 452, 457, 458, 459, 460, 461, 462, 462, 465, 467, 468, 469, 470, 471, 477, 479, 480, 481, 482, 483, 484, 485, 486, 487, 489, 491, 493, 494, 495, 496, 497, 499, 501, 502, 504, 507, 511, 514, 515, 516, 517, 518, 520, 522, 527, 528, 531, 535, 538, 543, 544, 547, 551, 554, 555, 556, 557, 558, 560, 560, 563, 565, 566, 567, 568, 569, 570, 575, 576, 577, 578, 580, 583, 587, 590, 591, 593, 594, 595, 596, 601, 602, 609, 612, 614, 615, 616, 617, 618, 623, 624, 626, 627, 628, 629, 630, 634, 635, 636, 637, 638, 639, 640, 641, 742, 744, 745, 750, 751, 753, 754, 755, 756, 759, 761, 762, 763, 764, 765, 766, 771, 772, 773, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 789, 790, 791, 792, 793, 794, 795, 796, 804, 805, 806, 809, 811, 812, 813, 814, 815, 816, 821, 822, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 837, 838, 839, 840, 843, 844, 845, 847, 848, 849, 850, 851, 852, 858, 859, 860, 861, 866, 867, 870, 875, 876, 879, 883, 888, 893, 894, 897, 902, 907, 908, 911, 915, 916, 917, 918, 919, 920, 921, 925, 927, 928, 929, 931, 934, 938, 941, 942, 943, 944, 945, 946, 947, 949, 985, 986, 987, 989, 990, 991, 992, 993, 994, 995, 998, 1000, 1002, 1004, 1007, 1011, 1014, 1016, 1017, 1018, 1019, 1020, 1021, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1055, 1056, 1057, 1058, 1061, 1063, 1064, 1065, 1066, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1086, 1087, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1132, 1134, 1135, 1136, 1142, 1143, 1144, 1147, 1149, 1150, 1151, 1157, 1158, 1159, 1162, 1164, 1165, 1166, 1172, 1223, 1224, 1225, 1228, 1230, 1231, 1232, 1233, 1238, 1239, 1240, 1247, 1248, 1249, 1252, 1254, 1255, 1256, 1257, 1262, 1263, 1264, 1265, 1266, 1267, 1268, 1269, 1270, 1271, 1278, 1279, 1280, 1283, 1285, 1286, 1287, 1288, 1289, 1290, 1295, 1296, 1297, 1304, 1305, 1306, 1309, 1311, 1312, 1313, 1314, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1330, 1331, 1332, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1348, 1349, 1349, 1352, 1354, 1355, 1356, 1362, 1366, 1369, 1373, 1376, 1380, 1383, 1387, 1390, 1394, 1397, 1401, 1404, 1408, 1411, 1415, 1418, 1422, 1425, 1429, 1432, 1436, 1439, 1443, 1446, 1450, 1453, 1457, 1460, 1464, 1467, 1471, 1474, 1478, 1481, 1485, 1488, 1492, 1495, 1499, 1502, 1506, 1509, 1513, 1516, 1520, 1523, 1527, 1530, 1534, 1537, 1541, 1544, 1548, 1551};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 75 75
new 0 75 75
assign 1 77 76
new 0 77 76
assign 1 79 77
new 0 79 77
assign 1 81 78
new 0 81 78
assign 1 82 79
new 0 82 79
assign 1 83 80
new 0 83 80
assign 1 84 81
new 0 84 81
assign 1 85 82
new 0 85 82
assign 1 86 83
new 0 86 83
assign 1 87 84
new 0 87 84
assign 1 88 85
new 0 88 85
assign 1 90 86
new 0 90 86
assign 1 91 87
new 0 91 87
assign 1 92 88
new 0 92 88
assign 1 93 89
new 0 93 89
assign 1 98 99
new 0 98 99
assign 1 99 100
valueIteratorGet 0 99 100
assign 1 99 103
hasNextGet 0 99 103
assign 1 100 105
nextGet 0 100 105
assign 1 101 106
mtdxGet 0 101 106
assign 1 101 107
greater 1 101 112
assign 1 102 113
mtdxGet 0 102 113
return 1 105 120
assign 1 109 128
new 0 109 128
assign 1 109 129
get 1 109 129
assign 1 110 130
def 1 110 135
assign 1 112 136
new 0 112 136
return 1 112 137
assign 1 114 139
new 0 114 139
return 1 114 140
assign 1 118 213
new 0 118 213
assign 1 119 214
new 0 119 214
assign 1 120 215
new 0 120 215
assign 1 121 216
new 0 121 216
assign 1 122 217
new 0 122 217
assign 1 123 218
new 0 123 218
assign 1 124 219
new 0 124 219
assign 1 125 220
new 0 125 220
assign 1 126 221
new 0 126 221
assign 1 127 222
new 0 127 222
assign 1 128 223
new 0 128 223
assign 1 129 224
superListGet 0 129 224
assign 1 129 225
copy 0 129 225
assign 1 130 226
namepathGet 0 130 226
addValue 1 130 227
assign 1 131 228
mtdListGet 0 131 228
assign 1 131 229
copy 0 131 229
assign 1 132 230
ptyListGet 0 132 230
assign 1 132 231
copy 0 132 231
assign 1 135 232
heldGet 0 135 232
assign 1 135 233
orderedVarsGet 0 135 233
assign 1 135 234
iteratorGet 0 135 234
assign 1 135 237
hasNextGet 0 135 237
assign 1 136 239
nextGet 0 136 239
assign 1 137 240
ptyMapGet 0 137 240
assign 1 137 241
heldGet 0 137 241
assign 1 137 242
nameGet 0 137 242
assign 1 137 243
get 1 137 243
assign 1 138 244
heldGet 0 138 244
assign 1 138 245
nameGet 0 138 245
assign 1 138 246
new 0 138 246
assign 1 138 247
notEquals 1 138 247
assign 1 138 249
undef 1 138 254
assign 1 0 255
assign 1 0 258
assign 1 0 262
assign 1 138 265
heldGet 0 138 265
assign 1 138 266
isDeclaredGet 0 138 266
assign 1 138 267
not 0 138 267
assign 1 0 269
assign 1 0 272
assign 1 0 276
assign 1 139 279
new 0 139 279
assign 1 139 280
heldGet 0 139 280
assign 1 139 281
nameGet 0 139 281
assign 1 139 282
add 1 139 282
assign 1 139 283
new 0 139 283
assign 1 139 284
add 1 139 284
assign 1 139 285
heldGet 0 139 285
assign 1 139 286
namepathGet 0 139 286
assign 1 139 287
toString 0 139 287
assign 1 139 288
add 1 139 288
assign 1 139 289
new 2 139 289
throw 1 139 290
assign 1 144 297
ptyListGet 0 144 297
assign 1 144 298
iteratorGet 0 144 298
assign 1 144 301
hasNextGet 0 144 301
assign 1 145 303
nextGet 0 145 303
assign 1 146 304
memSynGet 0 146 304
assign 1 146 305
isTypedGet 0 146 305
assign 1 147 307
heldGet 0 147 307
assign 1 147 308
memSynGet 0 147 308
assign 1 147 309
namepathGet 0 147 309
addUsed 1 147 310
assign 1 151 317
heldGet 0 151 317
assign 1 151 318
orderedMethodsGet 0 151 318
assign 1 151 319
iteratorGet 0 151 319
assign 1 151 322
hasNextGet 0 151 322
assign 1 152 324
nextGet 0 152 324
assign 1 153 325
mtdMapGet 0 153 325
assign 1 153 326
heldGet 0 153 326
assign 1 153 327
nameGet 0 153 327
assign 1 153 328
get 1 153 328
assign 1 154 329
def 1 154 334
assign 1 155 335
rsynGet 0 155 335
assign 1 155 336
def 1 155 341
assign 1 156 342
heldGet 0 156 342
assign 1 156 343
rtypeGet 0 156 343
assign 1 156 344
undef 1 156 349
assign 1 157 350
new 0 157 350
assign 1 157 351
heldGet 0 157 351
assign 1 157 352
nameGet 0 157 352
assign 1 157 353
add 1 157 353
assign 1 157 354
new 0 157 354
assign 1 157 355
add 1 157 355
assign 1 157 356
heldGet 0 157 356
assign 1 157 357
nameGet 0 157 357
assign 1 157 358
add 1 157 358
assign 1 157 359
new 2 157 359
throw 1 157 360
loadClass 1 162 369
assign 1 163 370
depthGet 0 163 370
assign 1 163 371
new 0 163 371
assign 1 163 372
add 1 163 372
assign 1 167 377
has 1 167 377
return 1 167 378
return 1 171 446
assign 1 172 448
new 0 172 448
assign 1 173 449
new 0 173 449
assign 1 174 450
new 0 174 450
assign 1 175 451
new 0 175 451
assign 1 176 452
undef 1 176 457
assign 1 177 458
new 0 177 458
assign 1 178 459
sizeGet 0 178 459
assign 1 179 460
sizeGet 0 179 460
assign 1 180 461
assign 1 181 462
iteratorGet 0 0 462
assign 1 181 465
hasNextGet 0 181 465
assign 1 181 467
nextGet 0 181 467
assign 1 182 468
emitDataGet 0 182 468
assign 1 182 469
methodIndexesGet 0 182 469
assign 1 182 470
new 2 182 470
put 1 182 471
return 1 184 477
assign 1 186 479
getSynNp 1 186 479
assign 1 187 480
new 0 187 480
assign 1 188 481
new 0 188 481
assign 1 190 482
sizeGet 0 190 482
assign 1 190 483
ptyListGet 0 190 483
assign 1 190 484
sizeGet 0 190 484
assign 1 190 485
subtract 1 190 485
assign 1 191 486
libNameGet 0 191 486
assign 1 191 487
equals 1 191 487
integrate 1 191 489
assign 1 192 491
isFinalGet 0 192 491
assign 1 193 493
new 0 193 493
assign 1 193 494
toString 0 193 494
assign 1 193 495
add 1 193 495
assign 1 193 496
new 1 193 496
throw 1 193 497
assign 1 195 499
isLocalGet 0 195 499
assign 1 195 501
libNameGet 0 195 501
assign 1 195 502
notEquals 1 195 502
assign 1 0 504
assign 1 0 507
assign 1 0 511
assign 1 196 514
new 0 196 514
assign 1 196 515
toString 0 196 515
assign 1 196 516
add 1 196 516
assign 1 196 517
new 1 196 517
throw 1 196 518
assign 1 198 520
isLocalGet 0 198 520
assign 1 198 522
not 0 198 527
assign 1 0 528
assign 1 0 531
assign 1 0 535
assign 1 198 538
not 0 198 543
assign 1 0 544
assign 1 0 547
assign 1 0 551
assign 1 199 554
new 0 199 554
assign 1 199 555
toString 0 199 555
assign 1 199 556
add 1 199 556
assign 1 199 557
new 1 199 557
throw 1 199 558
assign 1 201 560
linkedListIteratorGet 0 0 560
assign 1 201 563
hasNextGet 0 201 563
assign 1 201 565
nextGet 0 201 565
assign 1 202 566
getSynNp 1 202 566
assign 1 203 567
closeLibrariesGet 0 203 567
assign 1 203 568
libNameGet 0 203 568
assign 1 203 569
has 1 203 569
assign 1 203 570
not 0 203 575
assign 1 203 576
toString 0 203 576
assign 1 203 577
new 0 203 577
assign 1 203 578
notEquals 1 203 578
assign 1 0 580
assign 1 0 583
assign 1 0 587
assign 1 205 590
new 0 205 590
assign 1 206 591
new 0 206 591
assign 1 208 593
closeLibrariesGet 0 208 593
assign 1 208 594
libNameGet 0 208 594
assign 1 208 595
has 1 208 595
assign 1 208 596
not 0 208 601
assign 1 209 602
new 0 209 602
assign 1 213 609
valueIteratorGet 0 213 609
assign 1 213 612
hasNextGet 0 213 612
assign 1 214 614
nextGet 0 214 614
assign 1 215 615
mtdMapGet 0 215 615
assign 1 215 616
nameGet 0 215 616
assign 1 215 617
get 1 215 617
assign 1 216 618
def 1 216 623
assign 1 217 624
notEquals 1 217 624
assign 1 218 626
new 0 218 626
lastDefSet 1 218 627
assign 1 219 628
new 0 219 628
isOverrideSet 1 219 629
assign 1 220 630
increment 0 220 630
assign 1 223 634
new 0 223 634
isOverrideSet 1 223 635
assign 1 224 636
increment 0 224 636
assign 1 225 637
increment 0 225 637
assign 1 226 638
emitDataGet 0 226 638
assign 1 226 639
methodIndexesGet 0 226 639
assign 1 226 640
new 2 226 640
put 1 226 641
return 1 233 742
assign 1 234 744
new 0 234 744
assign 1 235 745
undef 1 235 750
return 1 235 751
assign 1 236 753
getSynNp 1 236 753
assign 1 237 754
heldGet 0 237 754
assign 1 237 755
orderedVarsGet 0 237 755
assign 1 237 756
iteratorGet 0 237 756
assign 1 237 759
hasNextGet 0 237 759
assign 1 238 761
nextGet 0 238 761
assign 1 239 762
ptyMapGet 0 239 762
assign 1 239 763
heldGet 0 239 763
assign 1 239 764
nameGet 0 239 764
assign 1 239 765
get 1 239 765
assign 1 240 766
def 1 240 771
assign 1 241 772
heldGet 0 241 772
assign 1 241 773
isDeclaredGet 0 241 773
assign 1 242 775
new 0 242 775
assign 1 242 776
heldGet 0 242 776
assign 1 242 777
nameGet 0 242 777
assign 1 242 778
add 1 242 778
assign 1 242 779
new 0 242 779
assign 1 242 780
add 1 242 780
assign 1 242 781
heldGet 0 242 781
assign 1 242 782
namepathGet 0 242 782
assign 1 242 783
toString 0 242 783
assign 1 242 784
add 1 242 784
assign 1 242 785
new 1 242 785
throw 1 242 786
assign 1 244 789
heldGet 0 244 789
assign 1 244 790
memSynGet 0 244 790
assign 1 244 791
isTypedGet 0 244 791
isTypedSet 1 244 792
assign 1 245 793
heldGet 0 245 793
assign 1 245 794
memSynGet 0 245 794
assign 1 245 795
namepathGet 0 245 795
namepathSet 1 245 796
assign 1 249 804
heldGet 0 249 804
assign 1 249 805
orderedMethodsGet 0 249 805
assign 1 249 806
iteratorGet 0 249 806
assign 1 249 809
hasNextGet 0 249 809
assign 1 250 811
nextGet 0 250 811
assign 1 251 812
mtdMapGet 0 251 812
assign 1 251 813
heldGet 0 251 813
assign 1 251 814
nameGet 0 251 814
assign 1 251 815
get 1 251 815
assign 1 252 816
def 1 252 821
assign 1 253 822
isFinalGet 0 253 822
assign 1 254 824
new 0 254 824
assign 1 254 825
heldGet 0 254 825
assign 1 254 826
nameGet 0 254 826
assign 1 254 827
add 1 254 827
assign 1 254 828
new 0 254 828
assign 1 254 829
add 1 254 829
assign 1 254 830
heldGet 0 254 830
assign 1 254 831
namepathGet 0 254 831
assign 1 254 832
toString 0 254 832
assign 1 254 833
add 1 254 833
assign 1 254 834
new 2 254 834
throw 1 254 835
assign 1 256 837
containedGet 0 256 837
assign 1 256 838
firstGet 0 256 838
assign 1 256 839
containedGet 0 256 839
assign 1 257 840
new 0 257 840
assign 1 257 843
argSynsGet 0 257 843
assign 1 257 844
lengthGet 0 257 844
assign 1 257 845
lesser 1 257 845
assign 1 258 847
argSynsGet 0 258 847
assign 1 258 848
get 1 258 848
assign 1 259 849
get 1 259 849
assign 1 259 850
heldGet 0 259 850
checkTypes 5 261 851
assign 1 257 852
increment 0 257 852
assign 1 263 858
rsynGet 0 263 858
assign 1 264 859
heldGet 0 264 859
assign 1 264 860
rtypeGet 0 264 860
assign 1 265 861
undef 1 265 866
assign 1 0 867
assign 1 265 870
undef 1 265 875
assign 1 0 876
assign 1 0 879
assign 1 266 883
undef 1 266 888
assign 1 266 888
not 0 266 893
assign 1 0 894
assign 1 266 897
undef 1 266 902
assign 1 266 902
not 0 266 907
assign 1 0 908
assign 1 0 911
assign 1 271 915
new 0 271 915
assign 1 271 916
heldGet 0 271 916
assign 1 271 917
namepathGet 0 271 917
assign 1 271 918
toString 0 271 918
assign 1 271 919
add 1 271 919
assign 1 271 920
new 2 271 920
throw 1 271 921
assign 1 275 925
isThisGet 0 275 925
assign 1 275 927
isThisGet 0 275 927
assign 1 275 928
isThisGet 0 275 928
assign 1 275 929
notEquals 1 275 929
assign 1 0 931
assign 1 0 934
assign 1 0 938
assign 1 276 941
new 0 276 941
assign 1 276 942
heldGet 0 276 942
assign 1 276 943
namepathGet 0 276 943
assign 1 276 944
toString 0 276 944
assign 1 276 945
add 1 276 945
assign 1 276 946
new 2 276 946
throw 1 276 947
checkTypes 5 278 949
assign 1 285 985
isTypedGet 0 285 985
assign 1 285 986
isTypedGet 0 285 986
assign 1 285 987
notEquals 1 285 987
assign 1 286 989
new 0 286 989
assign 1 286 990
heldGet 0 286 990
assign 1 286 991
namepathGet 0 286 991
assign 1 286 992
toString 0 286 992
assign 1 286 993
add 1 286 993
assign 1 286 994
new 2 286 994
throw 1 286 995
assign 1 287 998
isTypedGet 0 287 998
assign 1 290 1000
isSelfGet 0 290 1000
assign 1 290 1002
isSelfGet 0 290 1002
assign 1 0 1004
assign 1 0 1007
assign 1 0 1011
return 1 291 1014
assign 1 293 1016
namepathGet 0 293 1016
assign 1 293 1017
getSynNp 1 293 1017
assign 1 294 1018
allTypesGet 0 294 1018
assign 1 294 1019
namepathGet 0 294 1019
assign 1 294 1020
has 1 294 1020
assign 1 294 1021
not 0 294 1021
assign 1 295 1023
new 0 295 1023
assign 1 295 1024
heldGet 0 295 1024
assign 1 295 1025
namepathGet 0 295 1025
assign 1 295 1026
toString 0 295 1026
assign 1 295 1027
add 1 295 1027
assign 1 295 1028
new 2 295 1028
throw 1 295 1029
new 0 301 1055
assign 1 302 1056
heldGet 0 302 1056
assign 1 302 1057
orderedVarsGet 0 302 1057
assign 1 302 1058
iteratorGet 0 302 1058
assign 1 302 1061
hasNextGet 0 302 1061
assign 1 303 1063
nextGet 0 303 1063
assign 1 304 1064
heldGet 0 304 1064
assign 1 304 1065
isDeclaredGet 0 304 1065
assign 1 304 1066
not 0 304 1066
assign 1 305 1068
new 0 305 1068
assign 1 305 1069
heldGet 0 305 1069
assign 1 305 1070
nameGet 0 305 1070
assign 1 305 1071
add 1 305 1071
assign 1 305 1072
new 0 305 1072
assign 1 305 1073
add 1 305 1073
assign 1 305 1074
heldGet 0 305 1074
assign 1 305 1075
namepathGet 0 305 1075
assign 1 305 1076
toString 0 305 1076
assign 1 305 1077
add 1 305 1077
assign 1 305 1078
new 2 305 1078
throw 1 305 1079
loadClass 1 308 1086
assign 1 309 1087
new 0 309 1087
assign 1 314 1115
heldGet 0 314 1115
assign 1 314 1116
fromFileGet 0 314 1116
assign 1 315 1117
heldGet 0 315 1117
assign 1 315 1118
namepathGet 0 315 1118
assign 1 316 1119
heldGet 0 316 1119
assign 1 316 1120
libNameGet 0 316 1120
assign 1 317 1121
heldGet 0 317 1121
assign 1 317 1122
isFinalGet 0 317 1122
assign 1 318 1123
heldGet 0 318 1123
assign 1 318 1124
isLocalGet 0 318 1124
assign 1 319 1125
heldGet 0 319 1125
assign 1 319 1126
isNotNullGet 0 319 1126
assign 1 320 1127
heldGet 0 320 1127
assign 1 320 1128
usedGet 0 320 1128
assign 1 320 1129
iteratorGet 0 320 1129
assign 1 320 1132
hasNextGet 0 320 1132
assign 1 321 1134
nextGet 0 321 1134
assign 1 322 1135
toString 0 322 1135
put 1 322 1136
assign 1 324 1142
heldGet 0 324 1142
assign 1 324 1143
orderedVarsGet 0 324 1143
assign 1 324 1144
iteratorGet 0 324 1144
assign 1 324 1147
hasNextGet 0 324 1147
assign 1 325 1149
nextGet 0 325 1149
assign 1 326 1150
new 2 326 1150
addValue 1 327 1151
assign 1 329 1157
heldGet 0 329 1157
assign 1 329 1158
orderedMethodsGet 0 329 1158
assign 1 329 1159
iteratorGet 0 329 1159
assign 1 329 1162
hasNextGet 0 329 1162
assign 1 330 1164
nextGet 0 330 1164
assign 1 331 1165
new 2 331 1165
addValue 1 332 1166
postLoad 0 334 1172
assign 1 338 1223
new 0 338 1223
assign 1 339 1224
new 0 339 1224
assign 1 342 1225
iteratorGet 0 342 1225
assign 1 342 1228
hasNextGet 0 342 1228
assign 1 343 1230
nextGet 0 343 1230
assign 1 344 1231
nameGet 0 344 1231
assign 1 344 1232
has 1 344 1232
assign 1 344 1233
not 0 344 1238
assign 1 346 1239
nameGet 0 346 1239
put 2 346 1240
assign 1 350 1247
new 0 350 1247
assign 1 351 1248
new 0 351 1248
assign 1 352 1249
iteratorGet 0 352 1249
assign 1 352 1252
hasNextGet 0 352 1252
assign 1 353 1254
nextGet 0 353 1254
assign 1 354 1255
nameGet 0 354 1255
assign 1 354 1256
has 1 354 1256
assign 1 354 1257
not 0 354 1262
assign 1 355 1263
nameGet 0 355 1263
assign 1 355 1264
get 1 355 1264
mposSet 1 356 1265
assign 1 357 1266
new 0 357 1266
assign 1 357 1267
add 1 357 1267
addValue 1 358 1268
assign 1 359 1269
nameGet 0 359 1269
assign 1 359 1270
nameGet 0 359 1270
put 2 359 1271
assign 1 362 1278
assign 1 364 1279
new 0 364 1279
assign 1 366 1280
iteratorGet 0 366 1280
assign 1 366 1283
hasNextGet 0 366 1283
assign 1 367 1285
nextGet 0 367 1285
assign 1 369 1286
nameGet 0 369 1286
put 2 369 1287
assign 1 371 1288
nameGet 0 371 1288
assign 1 371 1289
has 1 371 1289
assign 1 371 1290
not 0 371 1295
assign 1 372 1296
nameGet 0 372 1296
put 2 372 1297
assign 1 376 1304
new 0 376 1304
assign 1 377 1305
new 0 377 1305
assign 1 378 1306
iteratorGet 0 378 1306
assign 1 378 1309
hasNextGet 0 378 1309
assign 1 379 1311
nextGet 0 379 1311
assign 1 380 1312
nameGet 0 380 1312
assign 1 380 1313
has 1 380 1313
assign 1 380 1314
not 0 380 1319
assign 1 381 1320
nameGet 0 381 1320
assign 1 381 1321
get 1 381 1321
assign 1 390 1322
nameGet 0 390 1322
assign 1 390 1323
get 1 390 1323
assign 1 391 1324
declarationGet 0 391 1324
assign 1 391 1325
undef 1 391 1330
assign 1 392 1331
originGet 0 392 1331
declarationSet 1 392 1332
assign 1 394 1334
declarationGet 0 394 1334
declarationSet 1 394 1335
mtdxSet 1 395 1336
assign 1 396 1337
increment 0 396 1337
addValue 1 397 1338
assign 1 398 1339
nameGet 0 398 1339
assign 1 398 1340
nameGet 0 398 1340
put 2 398 1341
assign 1 401 1348
assign 1 403 1349
linkedListIteratorGet 0 0 1349
assign 1 403 1352
hasNextGet 0 403 1352
assign 1 403 1354
nextGet 0 403 1354
put 2 404 1355
assign 1 405 1356
put 2 408 1362
return 1 0 1366
assign 1 0 1369
return 1 0 1373
assign 1 0 1376
return 1 0 1380
assign 1 0 1383
return 1 0 1387
assign 1 0 1390
return 1 0 1394
assign 1 0 1397
return 1 0 1401
assign 1 0 1404
return 1 0 1408
assign 1 0 1411
return 1 0 1415
assign 1 0 1418
return 1 0 1422
assign 1 0 1425
return 1 0 1429
assign 1 0 1432
return 1 0 1436
assign 1 0 1439
return 1 0 1443
assign 1 0 1446
return 1 0 1450
assign 1 0 1453
return 1 0 1457
assign 1 0 1460
return 1 0 1464
assign 1 0 1467
return 1 0 1471
assign 1 0 1474
return 1 0 1478
assign 1 0 1481
return 1 0 1485
assign 1 0 1488
return 1 0 1492
assign 1 0 1495
return 1 0 1499
assign 1 0 1502
return 1 0 1506
assign 1 0 1509
return 1 0 1513
assign 1 0 1516
return 1 0 1520
assign 1 0 1523
return 1 0 1527
assign 1 0 1530
return 1 0 1534
assign 1 0 1537
return 1 0 1541
assign 1 0 1544
return 1 0 1548
assign 1 0 1551
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -153365600: return bem_ptyMapGet_0();
case 1314364113: return bem_newMbrsGet_0();
case -2097069068: return bem_integratedGet_0();
case -1803479881: return bem_libNameGet_0();
case 287040793: return bem_hashGet_0();
case -1443447938: return bem_directMethodsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2033393684: return bem_ptyListGet_0();
case -842582618: return bem_isLocalGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -311680096: return bem_allNamesGet_0();
case -2058095605: return bem_signatureChangedGet_0();
case 1774940957: return bem_toString_0();
case -786424307: return bem_tagGet_0();
case -492006165: return bem_directPropertiesGet_0();
case 834964524: return bem_defMtdsGet_0();
case 1820417453: return bem_create_0();
case -1974592946: return bem_superListGet_0();
case -1760712968: return bem_signatureCheckedGet_0();
case 1274615854: return bem_allAncestorsCloseGet_0();
case 363636983: return bem_isNotNullGet_0();
case -1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case -1012494862: return bem_once_0();
case -1631955979: return bem_foreignClassesGet_0();
case -1214937871: return bem_newMtdsGet_0();
case -1182494494: return bem_toAny_0();
case 795036897: return bem_fromFileGet_0();
case -845792839: return bem_iteratorGet_0();
case 71634217: return bem_iCheckedGet_0();
case 287367803: return bem_isFinalGet_0();
case 354142775: return bem_namepathGet_0();
case 202810500: return bem_depthGet_0();
case 1477961836: return bem_mtdListGet_0();
case 345555227: return bem_usesGet_0();
case -1308786538: return bem_echo_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 244359240: return bem_mtdMapGet_0();
case 2055025483: return bem_serializeContents_0();
case 443668840: return bem_methodNotDefined_0();
case -986531569: return bem_allTypesGet_0();
case 481879936: return bem_hasDefaultGet_0();
case 1413594071: return bem_postLoad_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -1354714650: return bem_copy_0();
case 68632810: return bem_superNpGet_0();
case 1495449800: return bem_maxMtdxGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 1118052001: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 82716470: return bem_iCheckedSet_1(bevd_0);
case -1432365685: return bem_directMethodsSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 356637480: return bem_usesSet_1(bevd_0);
case -975449316: return bem_allTypesSet_1(bevd_0);
case -142283347: return bem_ptyMapSet_1(bevd_0);
case 79715063: return bem_superNpSet_1(bevd_0);
case -1749630715: return bem_signatureCheckedSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -2085986815: return bem_integratedSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -2047013352: return bem_signatureChangedSet_1(bevd_0);
case 255441493: return bem_mtdMapSet_1(bevd_0);
case -300597843: return bem_allNamesSet_1(bevd_0);
case 846046777: return bem_defMtdsSet_1(bevd_0);
case -831500365: return bem_isLocalSet_1(bevd_0);
case -480923912: return bem_directPropertiesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1489044089: return bem_mtdListSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1203855618: return bem_newMtdsSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1963510693: return bem_superListSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1285698107: return bem_allAncestorsCloseSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 340843364: return bem_loadClass_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1156342947: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1325446366: return bem_newMbrsSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 213892753: return bem_depthSet_1(bevd_0);
case -1620873726: return bem_foreignClassesSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 2044475937: return bem_ptyListSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1694832085: return bem_checkInheritance_2(bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case -913726521: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildClassSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildClassSyn.bevs_inst = (BEC_2_5_8_BuildClassSyn)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildClassSyn.bevs_inst;
}
}
