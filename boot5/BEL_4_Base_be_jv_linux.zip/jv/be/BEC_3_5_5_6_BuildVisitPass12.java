package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_6_BuildVisitPass12 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass12() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x32};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_1 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_2 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_5 = {0x47,0x45,0x54};
private static byte[] bels_6 = {0x5F,0x30};
private static byte[] bels_7 = {0x53,0x45,0x54};
private static byte[] bels_8 = {0x5F,0x31};
private static byte[] bels_9 = {0x53,0x45,0x54};
private static byte[] bels_10 = {0x43,0x61,0x6C,0x6C,0x20,0x68,0x65,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_11 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_12, 64));
private static byte[] bels_13 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x70,0x72,0x6F,0x62,0x61,0x62,0x6C,0x79,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x65,0x78,0x69,0x73,0x74,0x2C,0x20,0x76,0x65,0x72,0x69,0x66,0x79,0x20,0x6E,0x61,0x6D,0x65,0x20,0x61,0x6E,0x64,0x20,0x75,0x73,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] bels_14 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_14, 52));
private static byte[] bels_15 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74};
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_16 = {0x5F};
private static byte[] bels_17 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_18 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_19 = {0x6D,0x61,0x6E,0x79,0x5F,0x30};
public static BEC_3_5_5_6_BuildVisitPass12 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_classnp;
public BEC_3_5_5_6_BuildVisitPass12 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAccessor_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_myselfn = null;
BEC_2_6_6_SystemObject bevl_myself = null;
BEC_2_6_6_SystemObject bevl_mtdmyn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_6_6_SystemObject bevl_myparn = null;
BEC_2_6_6_SystemObject bevl_mybr = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_3_BuildVar bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevl_myselfn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_myselfn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpany_phold);
bevl_myself = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_0));
bevl_myself.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_2_tmpany_phold);
bevl_myself.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevp_classnp);
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_3_tmpany_phold);
bevl_myselfn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_myself);
bevl_mtdmyn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_4_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mtdmyn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_4_tmpany_phold);
bevl_mtdmy = (new BEC_2_5_6_BuildMethod()).bem_new_0();
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_mtdmy.bemd_1(1725653351, BEL_4_Base.bevn_isGenAccessorSet_1, bevt_5_tmpany_phold);
bevl_mtdmyn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_mtdmy);
bevl_myparn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_6_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_myparn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_6_tmpany_phold);
bevl_myparn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_myselfn);
bevl_mtdmyn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_myparn);
bevl_myselfn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_mybr = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_7_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_mybr.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_7_tmpany_phold);
bevl_mtdmyn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_mybr);
bevt_8_tmpany_phold = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_mtdmy.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevl_mtdmy.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_9_tmpany_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_mtdmy.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_11_tmpany_phold.bemd_1(606514572, BEL_4_Base.bevn_isThisSet_1, bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bevl_mtdmy.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_13_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevl_mtdmy.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_1));
bevt_16_tmpany_phold = (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_17_tmpany_phold);
bevt_15_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_16_tmpany_phold);
return bevl_mtdmyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getRetNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_retnoden = null;
BEC_2_6_6_SystemObject bevl_retnode = null;
BEC_2_6_6_SystemObject bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_retnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_retnoden.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpany_phold);
bevl_retnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_2));
bevl_retnode.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpany_phold);
bevl_retnoden.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_retnode);
bevl_sn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_sn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_3));
bevl_sn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_3_tmpany_phold);
bevl_retnoden.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_sn);
return bevl_retnoden;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAsNode_1(BEC_2_6_6_SystemObject beva_selfnode) throws Throwable {
BEC_2_6_6_SystemObject bevl_asnoden = null;
BEC_2_6_6_SystemObject bevl_asnode = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_asnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asnoden.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpany_phold);
bevl_asnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_4));
bevl_asnode.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpany_phold);
bevl_asnoden.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asnode);
return bevl_asnoden;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_ia = null;
BEC_2_6_6_SystemObject bevl_tst = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ename = null;
BEC_2_6_6_SystemObject bevl_anode = null;
BEC_2_6_6_SystemObject bevl_rettnode = null;
BEC_2_6_6_SystemObject bevl_rin = null;
BEC_2_6_6_SystemObject bevl_sv = null;
BEC_2_6_6_SystemObject bevl_svn = null;
BEC_2_6_6_SystemObject bevl_svn2 = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_newNp = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_c1 = null;
BEC_2_6_6_SystemObject bevl_bn = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpany_phold = null;
BEC_2_4_6_TextString bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpany_phold = null;
BEC_2_4_6_TextString bevt_156_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_157_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_166_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_4_6_TextString bevt_174_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_176_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpany_phold = null;
BEC_2_4_6_TextString bevt_180_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_181_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_182_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_183_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_185_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_186_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_187_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_188_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_190_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_191_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_193_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_197_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_199_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_200_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_202_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_204_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_205_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_206_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_207_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_13_tmpany_phold = beva_node.bem_containedGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_firstGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ia = bevt_11_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bevl_ia.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_14_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevl_ia.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevp_classnp);
} /* Line: 83 */
 else  /* Line: 80 */ {
bevt_18_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_18_tmpany_phold.bevi_int == bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_20_tmpany_phold = beva_node.bem_heldGet_0();
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_20_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_tst = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_22_tmpany_phold = beva_node.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_ii = bevt_21_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 90 */ {
bevt_23_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpany_phold).bevi_bool) /* Line: 90 */ {
bevt_24_tmpany_phold = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i = bevt_24_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpany_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_25_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_5));
bevl_tst.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_27_tmpany_phold);
bevl_tst.bemd_0(-173192194, BEL_4_Base.bevn_toAccessorName_0);
bevl_ename = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_29_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_6));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_30_tmpany_phold);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_28_tmpany_phold);
bevt_31_tmpany_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpany_phold).bevi_bool) /* Line: 97 */ {
bevt_35_tmpany_phold = beva_node.bem_heldGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_36_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_36_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevl_anode = this.bem_getAccessor_1(beva_node);
bevt_37_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpany_phold.bemd_1(-1030895937, BEL_4_Base.bevn_propertySet_1, bevl_i);
bevt_38_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpany_phold.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_ename);
bevt_39_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_40_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_39_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_40_tmpany_phold);
bevt_41_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_41_tmpany_phold.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_42_tmpany_phold);
bevt_44_tmpany_phold = beva_node.bem_heldGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_46_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_43_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_45_tmpany_phold, bevl_anode);
bevt_48_tmpany_phold = beva_node.bem_heldGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_47_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_50_tmpany_phold = beva_node.bem_containedGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_lastGet_0();
bevt_49_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevl_rettnode = this.bem_getRetNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_51_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_51_tmpany_phold);
bevt_53_tmpany_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevl_rin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_52_tmpany_phold);
bevl_rettnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rin);
bevt_55_tmpany_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevt_54_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rettnode);
bevt_57_tmpany_phold = bevl_rettnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_56_tmpany_phold.bemd_1(-205397975, BEL_4_Base.bevn_syncVariable_1, this);
bevl_rin.bemd_1(-205397975, BEL_4_Base.bevn_syncVariable_1, this);
bevt_58_tmpany_phold = bevl_i.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_58_tmpany_phold != null && bevt_58_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_58_tmpany_phold).bevi_bool) /* Line: 116 */ {
bevt_59_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_59_tmpany_phold.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevl_i);
} /* Line: 117 */
 else  /* Line: 118 */ {
bevt_60_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpany_phold.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, null);
} /* Line: 119 */
} /* Line: 116 */
bevt_62_tmpany_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpany_phold);
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_7));
bevl_tst.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_63_tmpany_phold);
bevl_tst.bemd_0(-173192194, BEL_4_Base.bevn_toAccessorName_0);
bevl_ename = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_66_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_8));
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_66_tmpany_phold);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_64_tmpany_phold);
bevt_67_tmpany_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_67_tmpany_phold != null && bevt_67_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpany_phold).bevi_bool) /* Line: 129 */ {
bevt_71_tmpany_phold = beva_node.bem_heldGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_72_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_72_tmpany_phold);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_68_tmpany_phold != null && bevt_68_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_68_tmpany_phold).bevi_bool) /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 129 */
 else  /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 129 */ {
bevl_anode = this.bem_getAccessor_1(beva_node);
bevt_73_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_73_tmpany_phold.bemd_1(-1030895937, BEL_4_Base.bevn_propertySet_1, bevl_i);
bevt_74_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_74_tmpany_phold.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_ename);
bevt_75_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_75_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_78_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_77_tmpany_phold.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_78_tmpany_phold);
bevt_80_tmpany_phold = beva_node.bem_heldGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_82_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_79_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_81_tmpany_phold, bevl_anode);
bevt_84_tmpany_phold = beva_node.bem_heldGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_83_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_86_tmpany_phold = beva_node.bem_containedGet_0();
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_lastGet_0();
bevt_85_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_87_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_9));
bevl_sv = bevl_anode.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_87_tmpany_phold, bevp_build);
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_sv.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_88_tmpany_phold);
bevl_svn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_svn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_89_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_89_tmpany_phold);
bevl_svn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_sv);
bevt_91_tmpany_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_90_tmpany_phold = bevt_91_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_90_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_svn);
bevl_svn2 = (new BEC_2_5_4_BuildNode());
bevl_svn2.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_92_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn2.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_92_tmpany_phold);
bevl_svn2.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_sv);
bevl_asn = this.bem_getAsNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_93_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_93_tmpany_phold);
bevt_95_tmpany_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevl_rin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_94_tmpany_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rin);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_svn2);
bevt_97_tmpany_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevt_96_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_asn);
bevl_svn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_rin.bemd_1(-205397975, BEL_4_Base.bevn_syncVariable_1, this);
} /* Line: 163 */
} /* Line: 129 */
 else  /* Line: 90 */ {
break;
} /* Line: 90 */
} /* Line: 90 */
} /* Line: 90 */
 else  /* Line: 80 */ {
bevt_99_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_100_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_99_tmpany_phold.bevi_int == bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_102_tmpany_phold = beva_node.bem_heldGet_0();
if (bevt_102_tmpany_phold == null) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_104_tmpany_phold = (new BEC_2_4_6_TextString(17, bels_10));
bevt_103_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_104_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_103_tmpany_phold);
} /* Line: 171 */
bevt_106_tmpany_phold = beva_node.bem_heldGet_0();
bevt_105_tmpany_phold = bevt_106_tmpany_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_105_tmpany_phold != null && bevt_105_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_105_tmpany_phold).bevi_bool) /* Line: 173 */ {
bevt_109_tmpany_phold = beva_node.bem_heldGet_0();
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_108_tmpany_phold == null) {
bevt_107_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_107_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_107_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 173 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 173 */
 else  /* Line: 173 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 173 */ {
bevt_110_tmpany_phold = beva_node.bem_containedGet_0();
bevl_newNp = bevt_110_tmpany_phold.bem_firstGet_0();
bevt_112_tmpany_phold = bevl_newNp.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_113_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_113_tmpany_phold);
if (bevt_111_tmpany_phold != null && bevt_111_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_111_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevt_115_tmpany_phold = bevl_newNp.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_116_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpany_phold);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpany_phold).bevi_bool) /* Line: 176 */ {
bevt_119_tmpany_phold = bevl_newNp.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_118_tmpany_phold = bevt_119_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_120_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_11));
bevt_117_tmpany_phold = bevt_118_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_120_tmpany_phold);
if (bevt_117_tmpany_phold != null && bevt_117_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_117_tmpany_phold).bevi_bool) /* Line: 176 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 176 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 176 */
 else  /* Line: 176 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 176 */ {
bevl_newNp = beva_node.bem_secondGet_0();
bevt_122_tmpany_phold = bevl_newNp.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_123_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_121_tmpany_phold = bevt_122_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_123_tmpany_phold);
if (bevt_121_tmpany_phold != null && bevt_121_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_121_tmpany_phold).bevi_bool) /* Line: 178 */ {
bevt_125_tmpany_phold = bevo_0;
bevt_126_tmpany_phold = bevl_newNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_124_tmpany_phold = bevt_125_tmpany_phold.bem_add_1(bevt_126_tmpany_phold);
bevt_124_tmpany_phold.bem_print_0();
bevt_128_tmpany_phold = (new BEC_2_4_6_TextString(131, bels_13));
bevt_127_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_128_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_127_tmpany_phold);
} /* Line: 180 */
} /* Line: 178 */
 else  /* Line: 182 */ {
bevt_130_tmpany_phold = bevo_1;
bevt_131_tmpany_phold = bevl_newNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_129_tmpany_phold = bevt_130_tmpany_phold.bem_add_1(bevt_131_tmpany_phold);
bevt_129_tmpany_phold.bem_print_0();
bevt_133_tmpany_phold = (new BEC_2_4_6_TextString(51, bels_15));
bevt_132_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_133_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_132_tmpany_phold);
} /* Line: 184 */
} /* Line: 176 */
bevt_134_tmpany_phold = beva_node.bem_heldGet_0();
bevt_135_tmpany_phold = bevl_newNp.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_134_tmpany_phold.bemd_1(-1572840142, BEL_4_Base.bevn_newNpSet_1, bevt_135_tmpany_phold);
bevl_newNp.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 188 */
bevt_136_tmpany_phold = beva_node.bem_heldGet_0();
bevt_139_tmpany_phold = beva_node.bem_containedGet_0();
bevt_138_tmpany_phold = bevt_139_tmpany_phold.bem_lengthGet_0();
bevt_140_tmpany_phold = bevo_2;
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bem_subtract_1(bevt_140_tmpany_phold);
bevt_136_tmpany_phold.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_137_tmpany_phold);
bevt_141_tmpany_phold = beva_node.bem_heldGet_0();
bevt_143_tmpany_phold = beva_node.bem_heldGet_0();
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_141_tmpany_phold.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_142_tmpany_phold);
bevt_144_tmpany_phold = beva_node.bem_heldGet_0();
bevt_148_tmpany_phold = beva_node.bem_heldGet_0();
bevt_147_tmpany_phold = bevt_148_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_149_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_16));
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_149_tmpany_phold);
bevt_152_tmpany_phold = beva_node.bem_heldGet_0();
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_0(-548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_150_tmpany_phold);
bevt_144_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_145_tmpany_phold);
bevt_155_tmpany_phold = beva_node.bem_heldGet_0();
bevt_154_tmpany_phold = bevt_155_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_156_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_17));
bevt_153_tmpany_phold = bevt_154_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_156_tmpany_phold);
if (bevt_153_tmpany_phold != null && bevt_153_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_153_tmpany_phold).bevi_bool) /* Line: 193 */ {
bevt_157_tmpany_phold = beva_node.bem_containedGet_0();
bevl_c0 = bevt_157_tmpany_phold.bem_firstGet_0();
if (bevl_c0 == null) {
bevt_158_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_158_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_158_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_160_tmpany_phold = bevl_c0.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_161_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_159_tmpany_phold = bevt_160_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_161_tmpany_phold);
if (bevt_159_tmpany_phold != null && bevt_159_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_159_tmpany_phold).bevi_bool) /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_162_tmpany_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_165_tmpany_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_164_tmpany_phold = bevt_165_tmpany_phold.bemd_0(389100841, BEL_4_Base.bevn_numAssignsGet_0);
bevt_163_tmpany_phold = bevt_164_tmpany_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_162_tmpany_phold.bemd_1(400183094, BEL_4_Base.bevn_numAssignsSet_1, bevt_163_tmpany_phold);
} /* Line: 196 */
bevt_166_tmpany_phold = beva_node.bem_containedGet_0();
bevl_c1 = bevt_166_tmpany_phold.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_167_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_167_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_167_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_169_tmpany_phold = bevl_c1.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_170_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_168_tmpany_phold = bevt_169_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_170_tmpany_phold);
if (bevt_168_tmpany_phold != null && bevt_168_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_168_tmpany_phold).bevi_bool) /* Line: 199 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 199 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 199 */
 else  /* Line: 199 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 199 */ {
bevt_173_tmpany_phold = bevl_c1.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_172_tmpany_phold = bevt_173_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_174_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_18));
bevt_171_tmpany_phold = bevt_172_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_174_tmpany_phold);
if (bevt_171_tmpany_phold != null && bevt_171_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_171_tmpany_phold).bevi_bool) /* Line: 204 */ {
bevt_175_tmpany_phold = beva_node.bem_heldGet_0();
bevt_176_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_175_tmpany_phold.bemd_1(1489916809, BEL_4_Base.bevn_isOnceSet_1, bevt_176_tmpany_phold);
} /* Line: 205 */
bevt_179_tmpany_phold = bevl_c1.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_178_tmpany_phold = bevt_179_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_180_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_19));
bevt_177_tmpany_phold = bevt_178_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_180_tmpany_phold);
if (bevt_177_tmpany_phold != null && bevt_177_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_177_tmpany_phold).bevi_bool) /* Line: 207 */ {
bevt_181_tmpany_phold = beva_node.bem_heldGet_0();
bevt_182_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_181_tmpany_phold.bemd_1(1373349483, BEL_4_Base.bevn_isManySet_1, bevt_182_tmpany_phold);
} /* Line: 208 */
} /* Line: 207 */
} /* Line: 199 */
} /* Line: 193 */
 else  /* Line: 80 */ {
bevt_184_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_185_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_184_tmpany_phold.bevi_int == bevt_185_tmpany_phold.bevi_int) {
bevt_183_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_183_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_183_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevl_bn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_187_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_187_tmpany_phold == null) {
bevt_186_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_186_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_186_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevt_190_tmpany_phold = beva_node.bem_containedGet_0();
bevt_189_tmpany_phold = bevt_190_tmpany_phold.bem_lastGet_0();
if (bevt_189_tmpany_phold == null) {
bevt_188_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_188_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_188_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 214 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 214 */
 else  /* Line: 214 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 214 */ {
bevt_193_tmpany_phold = beva_node.bem_containedGet_0();
bevt_192_tmpany_phold = bevt_193_tmpany_phold.bem_lastGet_0();
bevt_191_tmpany_phold = bevt_192_tmpany_phold.bemd_0(-1595262430, BEL_4_Base.bevn_nlcGet_0);
bevl_bn.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevt_191_tmpany_phold);
} /* Line: 215 */
 else  /* Line: 216 */ {
bevl_bn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
} /* Line: 217 */
bevt_194_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
bevl_bn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_194_tmpany_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_bn);
} /* Line: 220 */
 else  /* Line: 80 */ {
bevt_196_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_197_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_196_tmpany_phold.bevi_int == bevt_197_tmpany_phold.bevi_int) {
bevt_195_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_195_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_195_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevl_pn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_199_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_199_tmpany_phold == null) {
bevt_198_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_198_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_198_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevt_202_tmpany_phold = beva_node.bem_containedGet_0();
bevt_201_tmpany_phold = bevt_202_tmpany_phold.bem_lastGet_0();
if (bevt_201_tmpany_phold == null) {
bevt_200_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_200_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_200_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
 else  /* Line: 223 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 223 */ {
bevt_205_tmpany_phold = beva_node.bem_containedGet_0();
bevt_204_tmpany_phold = bevt_205_tmpany_phold.bem_lastGet_0();
bevt_203_tmpany_phold = bevt_204_tmpany_phold.bemd_0(-1595262430, BEL_4_Base.bevn_nlcGet_0);
bevl_pn.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevt_203_tmpany_phold);
} /* Line: 224 */
 else  /* Line: 225 */ {
bevl_pn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
} /* Line: 226 */
bevt_206_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
bevl_pn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_206_tmpany_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_pn);
} /* Line: 229 */
} /* Line: 80 */
} /* Line: 80 */
} /* Line: 80 */
} /* Line: 80 */
bevt_207_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_207_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_classnpGet_0() throws Throwable {
return bevp_classnp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass12 bem_classnpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 25, 25, 26, 27, 27, 28, 28, 29, 30, 30, 31, 32, 33, 33, 34, 35, 35, 36, 37, 38, 38, 39, 40, 41, 42, 43, 43, 44, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 49, 50, 54, 55, 55, 56, 57, 57, 58, 59, 60, 60, 61, 61, 62, 63, 67, 68, 68, 69, 70, 70, 71, 72, 80, 80, 80, 80, 81, 81, 81, 81, 82, 82, 82, 83, 83, 87, 87, 87, 87, 88, 88, 89, 90, 90, 90, 90, 91, 91, 92, 92, 92, 93, 93, 94, 95, 96, 96, 96, 96, 97, 97, 97, 97, 97, 97, 0, 0, 0, 99, 100, 100, 101, 101, 102, 102, 102, 103, 103, 103, 104, 104, 104, 104, 104, 105, 105, 105, 106, 106, 106, 107, 108, 109, 110, 110, 111, 111, 111, 112, 113, 113, 113, 114, 114, 114, 115, 116, 117, 117, 119, 119, 124, 124, 124, 125, 125, 126, 127, 128, 128, 128, 128, 129, 129, 129, 129, 129, 129, 0, 0, 0, 131, 132, 132, 133, 133, 134, 134, 134, 135, 135, 135, 136, 136, 136, 136, 136, 137, 137, 137, 138, 138, 138, 140, 140, 141, 141, 142, 143, 144, 144, 145, 147, 147, 147, 148, 149, 150, 150, 151, 153, 154, 155, 156, 156, 157, 157, 157, 158, 159, 160, 160, 160, 162, 163, 169, 169, 169, 169, 170, 170, 170, 171, 171, 171, 173, 173, 173, 173, 173, 173, 0, 0, 0, 174, 174, 175, 175, 175, 176, 176, 176, 176, 176, 176, 176, 0, 0, 0, 177, 178, 178, 178, 179, 179, 179, 179, 180, 180, 180, 183, 183, 183, 183, 184, 184, 184, 187, 187, 187, 188, 190, 190, 190, 190, 190, 190, 191, 191, 191, 191, 192, 192, 192, 192, 192, 192, 192, 192, 192, 192, 193, 193, 193, 193, 194, 194, 195, 195, 195, 195, 195, 0, 0, 0, 196, 196, 196, 196, 196, 198, 198, 199, 199, 199, 199, 199, 0, 0, 0, 204, 204, 204, 204, 205, 205, 205, 207, 207, 207, 207, 208, 208, 208, 212, 212, 212, 212, 213, 214, 214, 214, 214, 214, 214, 214, 0, 0, 0, 215, 215, 215, 215, 217, 219, 219, 220, 221, 221, 221, 221, 222, 223, 223, 223, 223, 223, 223, 223, 0, 0, 0, 224, 224, 224, 224, 226, 228, 228, 229, 231, 231, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 134, 135, 136, 137, 138, 139, 140, 141, 369, 370, 371, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 388, 389, 390, 395, 396, 397, 398, 399, 400, 401, 404, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 421, 422, 423, 424, 425, 427, 430, 434, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 477, 478, 481, 482, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 498, 499, 500, 501, 502, 504, 507, 511, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 576, 577, 578, 583, 584, 585, 590, 591, 592, 593, 595, 596, 598, 599, 600, 605, 606, 609, 613, 616, 617, 618, 619, 620, 622, 623, 624, 626, 627, 628, 629, 631, 634, 638, 641, 642, 643, 644, 646, 647, 648, 649, 650, 651, 652, 656, 657, 658, 659, 660, 661, 662, 665, 666, 667, 668, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 695, 696, 697, 702, 703, 704, 705, 707, 710, 714, 717, 718, 719, 720, 721, 723, 724, 725, 730, 731, 732, 733, 735, 738, 742, 745, 746, 747, 748, 750, 751, 752, 754, 755, 756, 757, 759, 760, 761, 767, 768, 769, 774, 775, 776, 777, 782, 783, 784, 785, 790, 791, 794, 798, 801, 802, 803, 804, 807, 809, 810, 811, 814, 815, 816, 821, 822, 823, 824, 829, 830, 831, 832, 837, 838, 841, 845, 848, 849, 850, 851, 854, 856, 857, 858, 864, 865, 868, 871};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 60
new 1 24 60
assign 1 25 61
VARGet 0 25 61
typenameSet 1 25 62
assign 1 26 63
new 0 26 63
assign 1 27 64
new 0 27 64
nameSet 1 27 65
assign 1 28 66
new 0 28 66
isTypedSet 1 28 67
namepathSet 1 29 68
assign 1 30 69
new 0 30 69
isArgSet 1 30 70
heldSet 1 31 71
assign 1 32 72
new 1 32 72
assign 1 33 73
METHODGet 0 33 73
typenameSet 1 33 74
assign 1 34 75
new 0 34 75
assign 1 35 76
new 0 35 76
isGenAccessorSet 1 35 77
heldSet 1 36 78
assign 1 37 79
new 1 37 79
assign 1 38 80
PARENSGet 0 38 80
typenameSet 1 38 81
addValue 1 39 82
addValue 1 40 83
addVariable 0 41 84
assign 1 42 85
new 1 42 85
assign 1 43 86
BRACESGet 0 43 86
typenameSet 1 43 87
addValue 1 44 88
assign 1 45 89
new 0 45 89
rtypeSet 1 45 90
assign 1 46 91
rtypeGet 0 46 91
assign 1 46 92
new 0 46 92
isSelfSet 1 46 93
assign 1 47 94
rtypeGet 0 47 94
assign 1 47 95
new 0 47 95
isThisSet 1 47 96
assign 1 48 97
rtypeGet 0 48 97
assign 1 48 98
new 0 48 98
isTypedSet 1 48 99
assign 1 49 100
rtypeGet 0 49 100
assign 1 49 101
new 0 49 101
assign 1 49 102
new 1 49 102
namepathSet 1 49 103
return 1 50 104
assign 1 54 114
new 1 54 114
assign 1 55 115
CALLGet 0 55 115
typenameSet 1 55 116
assign 1 56 117
new 0 56 117
assign 1 57 118
new 0 57 118
nameSet 1 57 119
heldSet 1 58 120
assign 1 59 121
new 1 59 121
assign 1 60 122
VARGet 0 60 122
typenameSet 1 60 123
assign 1 61 124
new 0 61 124
heldSet 1 61 125
addValue 1 62 126
return 1 63 127
assign 1 67 134
new 1 67 134
assign 1 68 135
CALLGet 0 68 135
typenameSet 1 68 136
assign 1 69 137
new 0 69 137
assign 1 70 138
new 0 70 138
nameSet 1 70 139
heldSet 1 71 140
return 1 72 141
assign 1 80 369
typenameGet 0 80 369
assign 1 80 370
METHODGet 0 80 370
assign 1 80 371
equals 1 80 376
assign 1 81 377
containedGet 0 81 377
assign 1 81 378
firstGet 0 81 378
assign 1 81 379
containedGet 0 81 379
assign 1 81 380
firstGet 0 81 380
assign 1 82 381
heldGet 0 82 381
assign 1 82 382
new 0 82 382
isTypedSet 1 82 383
assign 1 83 384
heldGet 0 83 384
namepathSet 1 83 385
assign 1 87 388
typenameGet 0 87 388
assign 1 87 389
CLASSGet 0 87 389
assign 1 87 390
equals 1 87 395
assign 1 88 396
heldGet 0 88 396
assign 1 88 397
namepathGet 0 88 397
assign 1 89 398
new 0 89 398
assign 1 90 399
heldGet 0 90 399
assign 1 90 400
orderedVarsGet 0 90 400
assign 1 90 401
iteratorGet 0 90 401
assign 1 90 404
hasNextGet 0 90 404
assign 1 91 406
nextGet 0 91 406
assign 1 91 407
heldGet 0 91 407
assign 1 92 408
nameGet 0 92 408
assign 1 92 409
copy 0 92 409
nameSet 1 92 410
assign 1 93 411
new 0 93 411
accessorTypeSet 1 93 412
toAccessorName 0 94 413
assign 1 95 414
nameGet 0 95 414
assign 1 96 415
nameGet 0 96 415
assign 1 96 416
new 0 96 416
assign 1 96 417
add 1 96 417
nameSet 1 96 418
assign 1 97 419
isDeclaredGet 0 97 419
assign 1 97 421
heldGet 0 97 421
assign 1 97 422
methodsGet 0 97 422
assign 1 97 423
nameGet 0 97 423
assign 1 97 424
has 1 97 424
assign 1 97 425
not 0 97 425
assign 1 0 427
assign 1 0 430
assign 1 0 434
assign 1 99 437
getAccessor 1 99 437
assign 1 100 438
heldGet 0 100 438
propertySet 1 100 439
assign 1 101 440
heldGet 0 101 440
orgNameSet 1 101 441
assign 1 102 442
heldGet 0 102 442
assign 1 102 443
nameGet 0 102 443
nameSet 1 102 444
assign 1 103 445
heldGet 0 103 445
assign 1 103 446
new 0 103 446
numargsSet 1 103 447
assign 1 104 448
heldGet 0 104 448
assign 1 104 449
methodsGet 0 104 449
assign 1 104 450
heldGet 0 104 450
assign 1 104 451
nameGet 0 104 451
put 2 104 452
assign 1 105 453
heldGet 0 105 453
assign 1 105 454
orderedMethodsGet 0 105 454
addValue 1 105 455
assign 1 106 456
containedGet 0 106 456
assign 1 106 457
lastGet 0 106 457
addValue 1 106 458
assign 1 107 459
getRetNode 1 107 459
assign 1 108 460
new 1 108 460
copyLoc 1 109 461
assign 1 110 462
VARGet 0 110 462
typenameSet 1 110 463
assign 1 111 464
nameGet 0 111 464
assign 1 111 465
copy 0 111 465
heldSet 1 111 466
addValue 1 112 467
assign 1 113 468
containedGet 0 113 468
assign 1 113 469
lastGet 0 113 469
addValue 1 113 470
assign 1 114 471
containedGet 0 114 471
assign 1 114 472
firstGet 0 114 472
syncVariable 1 114 473
syncVariable 1 115 474
assign 1 116 475
isTypedGet 0 116 475
assign 1 117 477
heldGet 0 117 477
rtypeSet 1 117 478
assign 1 119 481
heldGet 0 119 481
rtypeSet 1 119 482
assign 1 124 485
nameGet 0 124 485
assign 1 124 486
copy 0 124 486
nameSet 1 124 487
assign 1 125 488
new 0 125 488
accessorTypeSet 1 125 489
toAccessorName 0 126 490
assign 1 127 491
nameGet 0 127 491
assign 1 128 492
nameGet 0 128 492
assign 1 128 493
new 0 128 493
assign 1 128 494
add 1 128 494
nameSet 1 128 495
assign 1 129 496
isDeclaredGet 0 129 496
assign 1 129 498
heldGet 0 129 498
assign 1 129 499
methodsGet 0 129 499
assign 1 129 500
nameGet 0 129 500
assign 1 129 501
has 1 129 501
assign 1 129 502
not 0 129 502
assign 1 0 504
assign 1 0 507
assign 1 0 511
assign 1 131 514
getAccessor 1 131 514
assign 1 132 515
heldGet 0 132 515
propertySet 1 132 516
assign 1 133 517
heldGet 0 133 517
orgNameSet 1 133 518
assign 1 134 519
heldGet 0 134 519
assign 1 134 520
nameGet 0 134 520
nameSet 1 134 521
assign 1 135 522
heldGet 0 135 522
assign 1 135 523
new 0 135 523
numargsSet 1 135 524
assign 1 136 525
heldGet 0 136 525
assign 1 136 526
methodsGet 0 136 526
assign 1 136 527
heldGet 0 136 527
assign 1 136 528
nameGet 0 136 528
put 2 136 529
assign 1 137 530
heldGet 0 137 530
assign 1 137 531
orderedMethodsGet 0 137 531
addValue 1 137 532
assign 1 138 533
containedGet 0 138 533
assign 1 138 534
lastGet 0 138 534
addValue 1 138 535
assign 1 140 536
new 0 140 536
assign 1 140 537
tmpVar 2 140 537
assign 1 141 538
new 0 141 538
isArgSet 1 141 539
assign 1 142 540
new 1 142 540
copyLoc 1 143 541
assign 1 144 542
VARGet 0 144 542
typenameSet 1 144 543
heldSet 1 145 544
assign 1 147 545
containedGet 0 147 545
assign 1 147 546
firstGet 0 147 546
addValue 1 147 547
assign 1 148 548
new 0 148 548
copyLoc 1 149 549
assign 1 150 550
VARGet 0 150 550
typenameSet 1 150 551
heldSet 1 151 552
assign 1 153 553
getAsNode 1 153 553
assign 1 154 554
new 1 154 554
copyLoc 1 155 555
assign 1 156 556
VARGet 0 156 556
typenameSet 1 156 557
assign 1 157 558
nameGet 0 157 558
assign 1 157 559
copy 0 157 559
heldSet 1 157 560
addValue 1 158 561
addValue 1 159 562
assign 1 160 563
containedGet 0 160 563
assign 1 160 564
lastGet 0 160 564
addValue 1 160 565
addVariable 0 162 566
syncVariable 1 163 567
assign 1 169 576
typenameGet 0 169 576
assign 1 169 577
CALLGet 0 169 577
assign 1 169 578
equals 1 169 583
assign 1 170 584
heldGet 0 170 584
assign 1 170 585
undef 1 170 590
assign 1 171 591
new 0 171 591
assign 1 171 592
new 2 171 592
throw 1 171 593
assign 1 173 595
heldGet 0 173 595
assign 1 173 596
isConstructGet 0 173 596
assign 1 173 598
heldGet 0 173 598
assign 1 173 599
newNpGet 0 173 599
assign 1 173 600
undef 1 173 605
assign 1 0 606
assign 1 0 609
assign 1 0 613
assign 1 174 616
containedGet 0 174 616
assign 1 174 617
firstGet 0 174 617
assign 1 175 618
typenameGet 0 175 618
assign 1 175 619
NAMEPATHGet 0 175 619
assign 1 175 620
notEquals 1 175 620
assign 1 176 622
typenameGet 0 176 622
assign 1 176 623
VARGet 0 176 623
assign 1 176 624
equals 1 176 624
assign 1 176 626
heldGet 0 176 626
assign 1 176 627
nameGet 0 176 627
assign 1 176 628
new 0 176 628
assign 1 176 629
equals 1 176 629
assign 1 0 631
assign 1 0 634
assign 1 0 638
assign 1 177 641
secondGet 0 177 641
assign 1 178 642
typenameGet 0 178 642
assign 1 178 643
NAMEPATHGet 0 178 643
assign 1 178 644
notEquals 1 178 644
assign 1 179 646
new 0 179 646
assign 1 179 647
toString 0 179 647
assign 1 179 648
add 1 179 648
print 0 179 649
assign 1 180 650
new 0 180 650
assign 1 180 651
new 2 180 651
throw 1 180 652
assign 1 183 656
new 0 183 656
assign 1 183 657
toString 0 183 657
assign 1 183 658
add 1 183 658
print 0 183 659
assign 1 184 660
new 0 184 660
assign 1 184 661
new 2 184 661
throw 1 184 662
assign 1 187 665
heldGet 0 187 665
assign 1 187 666
heldGet 0 187 666
newNpSet 1 187 667
delete 0 188 668
assign 1 190 670
heldGet 0 190 670
assign 1 190 671
containedGet 0 190 671
assign 1 190 672
lengthGet 0 190 672
assign 1 190 673
new 0 190 673
assign 1 190 674
subtract 1 190 674
numargsSet 1 190 675
assign 1 191 676
heldGet 0 191 676
assign 1 191 677
heldGet 0 191 677
assign 1 191 678
nameGet 0 191 678
orgNameSet 1 191 679
assign 1 192 680
heldGet 0 192 680
assign 1 192 681
heldGet 0 192 681
assign 1 192 682
nameGet 0 192 682
assign 1 192 683
new 0 192 683
assign 1 192 684
add 1 192 684
assign 1 192 685
heldGet 0 192 685
assign 1 192 686
numargsGet 0 192 686
assign 1 192 687
toString 0 192 687
assign 1 192 688
add 1 192 688
nameSet 1 192 689
assign 1 193 690
heldGet 0 193 690
assign 1 193 691
orgNameGet 0 193 691
assign 1 193 692
new 0 193 692
assign 1 193 693
equals 1 193 693
assign 1 194 695
containedGet 0 194 695
assign 1 194 696
firstGet 0 194 696
assign 1 195 697
def 1 195 702
assign 1 195 703
typenameGet 0 195 703
assign 1 195 704
VARGet 0 195 704
assign 1 195 705
equals 1 195 705
assign 1 0 707
assign 1 0 710
assign 1 0 714
assign 1 196 717
heldGet 0 196 717
assign 1 196 718
heldGet 0 196 718
assign 1 196 719
numAssignsGet 0 196 719
assign 1 196 720
increment 0 196 720
numAssignsSet 1 196 721
assign 1 198 723
containedGet 0 198 723
assign 1 198 724
secondGet 0 198 724
assign 1 199 725
def 1 199 730
assign 1 199 731
typenameGet 0 199 731
assign 1 199 732
CALLGet 0 199 732
assign 1 199 733
equals 1 199 733
assign 1 0 735
assign 1 0 738
assign 1 0 742
assign 1 204 745
heldGet 0 204 745
assign 1 204 746
nameGet 0 204 746
assign 1 204 747
new 0 204 747
assign 1 204 748
equals 1 204 748
assign 1 205 750
heldGet 0 205 750
assign 1 205 751
new 0 205 751
isOnceSet 1 205 752
assign 1 207 754
heldGet 0 207 754
assign 1 207 755
nameGet 0 207 755
assign 1 207 756
new 0 207 756
assign 1 207 757
equals 1 207 757
assign 1 208 759
heldGet 0 208 759
assign 1 208 760
new 0 208 760
isManySet 1 208 761
assign 1 212 767
typenameGet 0 212 767
assign 1 212 768
BRACESGet 0 212 768
assign 1 212 769
equals 1 212 774
assign 1 213 775
new 1 213 775
assign 1 214 776
containedGet 0 214 776
assign 1 214 777
def 1 214 782
assign 1 214 783
containedGet 0 214 783
assign 1 214 784
lastGet 0 214 784
assign 1 214 785
def 1 214 790
assign 1 0 791
assign 1 0 794
assign 1 0 798
assign 1 215 801
containedGet 0 215 801
assign 1 215 802
lastGet 0 215 802
assign 1 215 803
nlcGet 0 215 803
nlcSet 1 215 804
copyLoc 1 217 807
assign 1 219 809
RBRACESGet 0 219 809
typenameSet 1 219 810
addValue 1 220 811
assign 1 221 814
typenameGet 0 221 814
assign 1 221 815
PARENSGet 0 221 815
assign 1 221 816
equals 1 221 821
assign 1 222 822
new 1 222 822
assign 1 223 823
containedGet 0 223 823
assign 1 223 824
def 1 223 829
assign 1 223 830
containedGet 0 223 830
assign 1 223 831
lastGet 0 223 831
assign 1 223 832
def 1 223 837
assign 1 0 838
assign 1 0 841
assign 1 0 845
assign 1 224 848
containedGet 0 224 848
assign 1 224 849
lastGet 0 224 849
assign 1 224 850
nlcGet 0 224 850
nlcSet 1 224 851
copyLoc 1 226 854
assign 1 228 856
RPARENSGet 0 228 856
typenameSet 1 228 857
addValue 1 229 858
assign 1 231 864
nextDescendGet 0 231 864
return 1 231 865
return 1 0 868
assign 1 0 871
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 487303277: return bem_classnpGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2055890305: return bem_getRetNode_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 498385530: return bem_classnpSet_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 654182780: return bem_getAsNode_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1438955473: return bem_getAccessor_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass12();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass12.bevs_inst = (BEC_3_5_5_6_BuildVisitPass12)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass12.bevs_inst;
}
}
