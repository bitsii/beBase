package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_9_BuildVisitTypeCheck extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x61,0x6E,0x79,0x29};
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_3 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x61,0x6E,0x79,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_4 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_4, 30));
private static byte[] bels_5 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_5, 19));
private static byte[] bels_6 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_7 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] bels_8 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_9 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] bels_10 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_10, 67));
private static byte[] bels_11 = {0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_11, 1));
private static byte[] bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bels_13 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_14 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_15 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_16 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bels_17 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x61,0x6E,0x79,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_17, 19));
private static byte[] bels_18 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_18, 52));
private static byte[] bels_19 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_19, 5));
public static BEC_3_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_3_5_5_9_BuildVisitTypeCheck bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cany = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_4_ContainerList bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_103_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_106_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_4_6_TextString bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_125_tmpany_phold = null;
BEC_2_4_6_TextString bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_163_tmpany_phold = null;
BEC_2_4_6_TextString bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_4_6_TextString bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_174_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_178_tmpany_phold = null;
BEC_2_4_6_TextString bevt_179_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_181_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_182_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_183_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_185_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_186_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_187_tmpany_phold = null;
BEC_2_4_6_TextString bevt_188_tmpany_phold = null;
BEC_2_4_6_TextString bevt_189_tmpany_phold = null;
BEC_2_4_6_TextString bevt_190_tmpany_phold = null;
BEC_2_4_6_TextString bevt_191_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpany_phold = null;
BEC_2_4_6_TextString bevt_193_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_194_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_196_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_197_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_198_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_200_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_201_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_204_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_205_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_206_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_207_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_208_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_209_tmpany_phold = null;
BEC_2_4_6_TextString bevt_210_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_211_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_212_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_214_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_215_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_216_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_217_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_219_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_224_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpany_phold = null;
BEC_2_4_6_TextString bevt_227_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_228_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_229_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_231_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_234_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_237_tmpany_phold = null;
BEC_2_4_6_TextString bevt_238_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_239_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_240_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_241_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_242_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_243_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_244_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_245_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_246_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_247_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_248_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_249_tmpany_phold = null;
BEC_2_4_6_TextString bevt_250_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_251_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_252_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_253_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_254_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_255_tmpany_phold = null;
BEC_2_4_6_TextString bevt_256_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_257_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_258_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_259_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_260_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_261_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_262_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_263_tmpany_phold = null;
BEC_2_4_6_TextString bevt_264_tmpany_phold = null;
BEC_2_4_6_TextString bevt_265_tmpany_phold = null;
BEC_2_4_6_TextString bevt_266_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_267_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_268_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_269_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_270_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_271_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_272_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_273_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_274_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_275_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_276_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_277_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_278_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_279_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_280_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_281_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_282_tmpany_phold = null;
BEC_2_4_6_TextString bevt_283_tmpany_phold = null;
BEC_2_4_6_TextString bevt_284_tmpany_phold = null;
BEC_2_4_6_TextString bevt_285_tmpany_phold = null;
BEC_2_4_6_TextString bevt_286_tmpany_phold = null;
BEC_2_4_6_TextString bevt_287_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_288_tmpany_phold = null;
BEC_2_4_6_TextString bevt_289_tmpany_phold = null;
BEC_2_4_6_TextString bevt_290_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_291_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_292_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevt_16_tmpany_phold = beva_node.bem_containedGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_firstGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 392 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(46, bels_0));
bevt_17_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_17_tmpany_phold);
} /* Line: 393 */
} /* Line: 392 */
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevp_inClass = beva_node;
bevt_22_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_22_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_23_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_23_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 399 */
bevt_25_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_25_tmpany_phold.bevi_int == bevt_26_tmpany_phold.bevi_int) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevp_cpos = (new BEC_2_4_3_MathInt(0));
} /* Line: 402 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_30_tmpany_phold = beva_node.bem_heldGet_0();
bevt_30_tmpany_phold.bemd_1(-2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_31_tmpany_phold = beva_node.bem_containedGet_0();
bevt_0_tmpany_loop = bevt_31_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 407 */ {
bevt_32_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 407 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpany_phold = bevl_cci.bem_typenameGet_0();
bevt_35_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_34_tmpany_phold.bevi_int == bevt_35_tmpany_phold.bevi_int) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 408 */ {
bevt_36_tmpany_phold = bevl_cci.bem_heldGet_0();
bevt_36_tmpany_phold.bemd_1(-474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 409 */
} /* Line: 408 */
 else  /* Line: 407 */ {
break;
} /* Line: 407 */
} /* Line: 407 */
bevt_39_tmpany_phold = beva_node.bem_heldGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_1));
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_40_tmpany_phold);
if (bevt_37_tmpany_phold != null && bevt_37_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpany_phold).bevi_bool) /* Line: 420 */ {
bevt_41_tmpany_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_41_tmpany_phold.bem_firstGet_0();
bevt_43_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_42_tmpany_phold != null && bevt_42_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_42_tmpany_phold).bevi_bool) /* Line: 423 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 424 */
 else  /* Line: 425 */ {
bevt_45_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_47_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_46_tmpany_phold);
bevl_tany = bevt_44_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 426 */
bevt_49_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_48_tmpany_phold != null && bevt_48_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpany_phold).bevi_bool) /* Line: 429 */ {
bevt_50_tmpany_phold = beva_node.bem_heldGet_0();
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_50_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_51_tmpany_phold);
} /* Line: 430 */
 else  /* Line: 431 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_53_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_54_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_53_tmpany_phold.bevi_int == bevt_54_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 433 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 433 */ {
bevt_56_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_57_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_56_tmpany_phold.bevi_int == bevt_57_tmpany_phold.bevi_int) {
bevt_55_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_55_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 433 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 433 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 433 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 433 */ {
bevt_58_tmpany_phold = beva_node.bem_heldGet_0();
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_58_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_59_tmpany_phold);
} /* Line: 435 */
 else  /* Line: 436 */ {
bevt_61_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_62_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpany_phold.bevi_int == bevt_62_tmpany_phold.bevi_int) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 437 */ {
bevt_64_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_63_tmpany_phold != null && bevt_63_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpany_phold).bevi_bool) /* Line: 438 */ {
bevl_oany = bevl_org.bem_heldGet_0();
} /* Line: 439 */
 else  /* Line: 440 */ {
bevt_66_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_68_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_67_tmpany_phold);
bevl_oany = bevt_65_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 442 */
} /* Line: 438 */
 else  /* Line: 437 */ {
bevt_70_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_71_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_70_tmpany_phold.bevi_int == bevt_71_tmpany_phold.bevi_int) {
bevt_69_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_69_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_69_tmpany_phold.bevi_bool) /* Line: 445 */ {
bevt_72_tmpany_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_72_tmpany_phold.bem_firstGet_0();
bevt_74_tmpany_phold = bevl_ctarg.bem_heldGet_0();
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_73_tmpany_phold != null && bevt_73_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpany_phold).bevi_bool) /* Line: 448 */ {
bevl_cany = bevl_ctarg.bem_heldGet_0();
} /* Line: 450 */
 else  /* Line: 451 */ {
bevt_76_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_78_tmpany_phold = bevl_ctarg.bem_heldGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_77_tmpany_phold);
bevl_cany = bevt_75_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 453 */
bevl_syn = null;
bevt_81_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_80_tmpany_phold = bevt_81_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_80_tmpany_phold == null) {
bevt_79_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_79_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_79_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_83_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_82_tmpany_phold);
} /* Line: 458 */
 else  /* Line: 457 */ {
bevt_84_tmpany_phold = bevl_cany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_84_tmpany_phold != null && bevt_84_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_84_tmpany_phold).bevi_bool) /* Line: 459 */ {
bevt_85_tmpany_phold = bevl_cany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_85_tmpany_phold);
} /* Line: 461 */
} /* Line: 457 */
if (bevl_syn == null) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 463 */ {
bevt_87_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_89_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_87_tmpany_phold.bem_get_1(bevt_88_tmpany_phold);
if (bevl_mtdc == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 465 */ {
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(12, bels_2));
bevt_91_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_92_tmpany_phold, bevl_org);
throw new be.BECS_ThrowBack(bevt_91_tmpany_phold);
} /* Line: 466 */
 else  /* Line: 467 */ {
bevl_oany = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 468 */
} /* Line: 465 */
} /* Line: 463 */
} /* Line: 437 */
if (bevl_oany == null) {
bevt_93_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 472 */ {
bevt_94_tmpany_phold = bevl_oany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_94_tmpany_phold != null && bevt_94_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_94_tmpany_phold).bevi_bool) /* Line: 472 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 472 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 472 */
 else  /* Line: 472 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 472 */ {
bevl_castForSelf = be.BECS_Runtime.boolFalse;
bevt_95_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_95_tmpany_phold != null && bevt_95_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_95_tmpany_phold).bevi_bool) /* Line: 475 */ {
if (bevl_syn == null) {
bevt_96_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_96_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 477 */ {
bevt_98_tmpany_phold = (new BEC_2_4_6_TextString(28, bels_3));
bevt_97_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_98_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_97_tmpany_phold);
} /* Line: 478 */
bevt_100_tmpany_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_101_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_99_tmpany_phold = bevt_100_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_101_tmpany_phold);
if (bevt_99_tmpany_phold != null && bevt_99_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_99_tmpany_phold).bevi_bool) /* Line: 483 */ {
bevl_castForSelf = be.BECS_Runtime.boolTrue;
} /* Line: 485 */
 else  /* Line: 483 */ {
bevt_103_tmpany_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_103_tmpany_phold == null) {
bevt_102_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpany_phold.bevi_bool) /* Line: 486 */ {
bevt_106_tmpany_phold = bevp_build.bem_emitCommonGet_0();
bevt_105_tmpany_phold = bevt_106_tmpany_phold.bem_coanyiantReturnsGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_104_tmpany_phold != null && bevt_104_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 486 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 486 */
 else  /* Line: 486 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 486 */ {
bevl_castForSelf = be.BECS_Runtime.boolTrue;
} /* Line: 487 */
} /* Line: 483 */
} /* Line: 483 */
 else  /* Line: 475 */ {
if (bevl_mtdc == null) {
bevt_107_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpany_phold.bevi_bool) /* Line: 489 */ {
bevt_108_tmpany_phold = bevl_mtdc.bemd_2(-583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_108_tmpany_phold);
} /* Line: 490 */
 else  /* Line: 491 */ {
bevt_109_tmpany_phold = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_109_tmpany_phold);
} /* Line: 492 */
} /* Line: 475 */
bevt_111_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_110_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_111_tmpany_phold);
if (bevt_110_tmpany_phold != null && bevt_110_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevt_112_tmpany_phold = beva_node.bem_heldGet_0();
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_112_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_113_tmpany_phold);
} /* Line: 498 */
 else  /* Line: 499 */ {
bevt_114_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpany_phold).bevi_bool) /* Line: 500 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 501 */
 else  /* Line: 502 */ {
bevl_ovnp = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 503 */
bevt_115_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_115_tmpany_phold);
bevt_116_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp);
if (bevt_116_tmpany_phold != null && bevt_116_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_116_tmpany_phold).bevi_bool) /* Line: 506 */ {
bevt_117_tmpany_phold = beva_node.bem_heldGet_0();
bevt_118_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_117_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_118_tmpany_phold);
} /* Line: 508 */
 else  /* Line: 509 */ {
bevt_123_tmpany_phold = bevo_0;
bevt_125_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_124_tmpany_phold = bevt_125_tmpany_phold.bem_toString_0();
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bem_add_1(bevt_124_tmpany_phold);
bevt_126_tmpany_phold = bevo_1;
bevt_121_tmpany_phold = bevt_122_tmpany_phold.bem_add_1(bevt_126_tmpany_phold);
bevt_127_tmpany_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_120_tmpany_phold = bevt_121_tmpany_phold.bem_add_1(bevt_127_tmpany_phold);
bevt_119_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_120_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_119_tmpany_phold);
} /* Line: 510 */
} /* Line: 506 */
if (bevl_castForSelf.bevi_bool) /* Line: 514 */ {
bevt_128_tmpany_phold = beva_node.bem_heldGet_0();
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_128_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_129_tmpany_phold);
} /* Line: 516 */
} /* Line: 514 */
bevt_132_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_131_tmpany_phold = bevt_132_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_131_tmpany_phold == null) {
bevt_130_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_130_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 519 */ {
} /* Line: 519 */
} /* Line: 519 */
} /* Line: 433 */
} /* Line: 429 */
 else  /* Line: 420 */ {
bevt_135_tmpany_phold = beva_node.bem_heldGet_0();
bevt_134_tmpany_phold = bevt_135_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_136_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_6));
bevt_133_tmpany_phold = bevt_134_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpany_phold);
if (bevt_133_tmpany_phold != null && bevt_133_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_133_tmpany_phold).bevi_bool) /* Line: 524 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_138_tmpany_phold = bevl_targ.bem_typenameGet_0();
bevt_139_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_138_tmpany_phold.bevi_int == bevt_139_tmpany_phold.bevi_int) {
bevt_137_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_137_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_137_tmpany_phold.bevi_bool) /* Line: 526 */ {
bevt_141_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_140_tmpany_phold = bevt_141_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_140_tmpany_phold != null && bevt_140_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_140_tmpany_phold).bevi_bool) /* Line: 527 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 528 */
 else  /* Line: 529 */ {
bevt_143_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_145_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_144_tmpany_phold = bevt_145_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_144_tmpany_phold);
bevl_tany = bevt_142_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 530 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_147_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_146_tmpany_phold != null && bevt_146_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_146_tmpany_phold).bevi_bool) /* Line: 534 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 535 */
 else  /* Line: 536 */ {
bevt_149_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_151_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_148_tmpany_phold = bevt_149_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_150_tmpany_phold);
bevl_tany = bevt_148_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 537 */
bevt_154_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_153_tmpany_phold = bevt_154_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_153_tmpany_phold == null) {
bevt_152_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_152_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_152_tmpany_phold.bevi_bool) /* Line: 540 */ {
bevt_157_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpany_phold = bevt_157_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_155_tmpany_phold = bevt_156_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_155_tmpany_phold != null && bevt_155_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_155_tmpany_phold).bevi_bool) /* Line: 540 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 540 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 540 */
 else  /* Line: 540 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 540 */ {
bevt_159_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_158_tmpany_phold = bevt_159_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_158_tmpany_phold != null && bevt_158_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpany_phold).bevi_bool) /* Line: 541 */ {
bevt_162_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_160_tmpany_phold != null && bevt_160_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_160_tmpany_phold).bevi_bool) /* Line: 542 */ {
bevt_164_tmpany_phold = (new BEC_2_4_6_TextString(104, bels_7));
bevt_163_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_164_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_163_tmpany_phold);
} /* Line: 543 */
bevt_165_tmpany_phold = beva_node.bem_heldGet_0();
bevt_166_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_165_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_166_tmpany_phold);
} /* Line: 546 */
 else  /* Line: 547 */ {
bevt_169_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_168_tmpany_phold = bevt_169_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_167_tmpany_phold = bevt_168_tmpany_phold.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_167_tmpany_phold != null && bevt_167_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_167_tmpany_phold).bevi_bool) /* Line: 550 */ {
bevt_171_tmpany_phold = bevl_tany.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_172_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_8));
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_172_tmpany_phold);
if (bevt_170_tmpany_phold != null && bevt_170_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_170_tmpany_phold).bevi_bool) /* Line: 551 */ {
bevt_173_tmpany_phold = beva_node.bem_heldGet_0();
bevt_174_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_173_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_174_tmpany_phold);
} /* Line: 553 */
 else  /* Line: 554 */ {
bevt_177_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_176_tmpany_phold = bevt_177_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_175_tmpany_phold = bevt_176_tmpany_phold.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_175_tmpany_phold != null && bevt_175_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_175_tmpany_phold).bevi_bool) /* Line: 555 */ {
bevt_179_tmpany_phold = (new BEC_2_4_6_TextString(104, bels_9));
bevt_178_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_179_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_178_tmpany_phold);
} /* Line: 556 */
bevt_180_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_180_tmpany_phold);
bevt_182_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_181_tmpany_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_182_tmpany_phold);
if (bevt_181_tmpany_phold != null && bevt_181_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_181_tmpany_phold).bevi_bool) /* Line: 559 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 559 */ {
bevt_184_tmpany_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_183_tmpany_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_184_tmpany_phold);
if (bevt_183_tmpany_phold != null && bevt_183_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_183_tmpany_phold).bevi_bool) /* Line: 559 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 559 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 559 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 559 */ {
bevt_185_tmpany_phold = beva_node.bem_heldGet_0();
bevt_186_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_185_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_186_tmpany_phold);
} /* Line: 561 */
 else  /* Line: 562 */ {
bevt_191_tmpany_phold = bevo_2;
bevt_192_tmpany_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_190_tmpany_phold = bevt_191_tmpany_phold.bem_add_1(bevt_192_tmpany_phold);
bevt_193_tmpany_phold = bevo_3;
bevt_189_tmpany_phold = bevt_190_tmpany_phold.bem_add_1(bevt_193_tmpany_phold);
bevt_194_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_188_tmpany_phold = bevt_189_tmpany_phold.bem_add_1(bevt_194_tmpany_phold);
bevt_187_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_188_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_187_tmpany_phold);
} /* Line: 563 */
} /* Line: 559 */
} /* Line: 551 */
 else  /* Line: 566 */ {
bevt_195_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_195_tmpany_phold);
bevt_199_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_198_tmpany_phold = bevt_199_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_197_tmpany_phold = bevt_198_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_196_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_197_tmpany_phold);
if (bevt_196_tmpany_phold != null && bevt_196_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_196_tmpany_phold).bevi_bool) /* Line: 568 */ {
bevt_200_tmpany_phold = beva_node.bem_heldGet_0();
bevt_201_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_200_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_201_tmpany_phold);
} /* Line: 570 */
 else  /* Line: 571 */ {
bevt_204_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_203_tmpany_phold = bevt_204_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_202_tmpany_phold = bevt_203_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_202_tmpany_phold);
bevt_206_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_205_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_206_tmpany_phold);
if (bevt_205_tmpany_phold != null && bevt_205_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_205_tmpany_phold).bevi_bool) /* Line: 573 */ {
bevt_207_tmpany_phold = beva_node.bem_heldGet_0();
bevt_208_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_207_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_208_tmpany_phold);
} /* Line: 575 */
 else  /* Line: 576 */ {
bevt_210_tmpany_phold = (new BEC_2_4_6_TextString(25, bels_12));
bevt_209_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_210_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_209_tmpany_phold);
} /* Line: 577 */
} /* Line: 573 */
} /* Line: 568 */
} /* Line: 550 */
} /* Line: 541 */
 else  /* Line: 582 */ {
bevt_211_tmpany_phold = beva_node.bem_heldGet_0();
bevt_212_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_211_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_212_tmpany_phold);
} /* Line: 584 */
} /* Line: 540 */
 else  /* Line: 586 */ {
bevt_213_tmpany_phold = beva_node.bem_heldGet_0();
bevt_214_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_213_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_214_tmpany_phold);
} /* Line: 587 */
} /* Line: 526 */
 else  /* Line: 589 */ {
bevt_215_tmpany_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_215_tmpany_phold.bem_firstGet_0();
bevt_217_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_216_tmpany_phold = bevt_217_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_216_tmpany_phold != null && bevt_216_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_216_tmpany_phold).bevi_bool) /* Line: 592 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 593 */
 else  /* Line: 594 */ {
bevt_219_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_221_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_220_tmpany_phold = bevt_221_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_218_tmpany_phold = bevt_219_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_220_tmpany_phold);
bevl_tany = bevt_218_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 595 */
bevt_223_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_222_tmpany_phold = bevt_223_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_222_tmpany_phold != null && bevt_222_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_222_tmpany_phold).bevi_bool) /* Line: 598 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 598 */ {
bevt_226_tmpany_phold = beva_node.bem_heldGet_0();
bevt_225_tmpany_phold = bevt_226_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_227_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_13));
bevt_224_tmpany_phold = bevt_225_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_227_tmpany_phold);
if (bevt_224_tmpany_phold != null && bevt_224_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_224_tmpany_phold).bevi_bool) /* Line: 598 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 598 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 598 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 598 */ {
bevt_228_tmpany_phold = beva_node.bem_heldGet_0();
bevt_229_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_228_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_229_tmpany_phold);
} /* Line: 599 */
 else  /* Line: 600 */ {
bevt_230_tmpany_phold = beva_node.bem_heldGet_0();
bevt_231_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_230_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_231_tmpany_phold);
bevt_233_tmpany_phold = beva_node.bem_heldGet_0();
bevt_232_tmpany_phold = bevt_233_tmpany_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_232_tmpany_phold != null && bevt_232_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_232_tmpany_phold).bevi_bool) /* Line: 602 */ {
bevt_236_tmpany_phold = beva_node.bem_heldGet_0();
bevt_235_tmpany_phold = bevt_236_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_235_tmpany_phold == null) {
bevt_234_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_234_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_234_tmpany_phold.bevi_bool) /* Line: 603 */ {
bevt_238_tmpany_phold = (new BEC_2_4_6_TextString(49, bels_14));
bevt_237_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_238_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_237_tmpany_phold);
} /* Line: 604 */
bevt_240_tmpany_phold = beva_node.bem_heldGet_0();
bevt_239_tmpany_phold = bevt_240_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_239_tmpany_phold);
bevt_241_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_243_tmpany_phold = beva_node.bem_heldGet_0();
bevt_242_tmpany_phold = bevt_243_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_241_tmpany_phold.bem_get_1(bevt_242_tmpany_phold);
} /* Line: 607 */
 else  /* Line: 608 */ {
bevt_244_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_244_tmpany_phold);
bevt_245_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_247_tmpany_phold = beva_node.bem_heldGet_0();
bevt_246_tmpany_phold = bevt_247_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_245_tmpany_phold.bem_get_1(bevt_246_tmpany_phold);
} /* Line: 610 */
if (bevl_mtdc == null) {
bevt_248_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_248_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_248_tmpany_phold.bevi_bool) /* Line: 612 */ {
bevt_250_tmpany_phold = (new BEC_2_4_6_TextString(12, bels_15));
bevt_249_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_250_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_249_tmpany_phold);
} /* Line: 613 */
bevl_argSyns = (BEC_2_9_4_ContainerList) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 617 */ {
bevt_252_tmpany_phold = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_252_tmpany_phold.bevi_int) {
bevt_251_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_251_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_251_tmpany_phold.bevi_bool) /* Line: 617 */ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_253_tmpany_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_253_tmpany_phold.bevi_bool) /* Line: 619 */ {
if (bevl_nnode == null) {
bevt_254_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_254_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_254_tmpany_phold.bevi_bool) /* Line: 620 */ {
bevt_256_tmpany_phold = (new BEC_2_4_6_TextString(16, bels_16));
bevt_255_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_256_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_255_tmpany_phold);
} /* Line: 621 */
 else  /* Line: 620 */ {
bevt_258_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_259_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_258_tmpany_phold.bevi_int != bevt_259_tmpany_phold.bevi_int) {
bevt_257_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_257_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_257_tmpany_phold.bevi_bool) /* Line: 622 */ {
bevt_261_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_262_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_261_tmpany_phold.bevi_int != bevt_262_tmpany_phold.bevi_int) {
bevt_260_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_260_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_260_tmpany_phold.bevi_bool) /* Line: 622 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 622 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 622 */
 else  /* Line: 622 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 622 */ {
bevt_265_tmpany_phold = bevo_4;
bevt_267_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_266_tmpany_phold = bevt_267_tmpany_phold.bem_toString_0();
bevt_264_tmpany_phold = bevt_265_tmpany_phold.bem_add_1(bevt_266_tmpany_phold);
bevt_263_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_264_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_263_tmpany_phold);
} /* Line: 623 */
} /* Line: 620 */
bevt_269_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_270_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_269_tmpany_phold.bevi_int == bevt_270_tmpany_phold.bevi_int) {
bevt_268_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_268_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_268_tmpany_phold.bevi_bool) /* Line: 625 */ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_272_tmpany_phold = bevl_carg.bem_isTypedGet_0();
if (bevt_272_tmpany_phold.bevi_bool) {
bevt_271_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_271_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_271_tmpany_phold.bevi_bool) /* Line: 627 */ {
bevt_273_tmpany_phold = beva_node.bem_heldGet_0();
bevt_274_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_273_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_274_tmpany_phold);
bevt_276_tmpany_phold = beva_node.bem_heldGet_0();
bevt_275_tmpany_phold = bevt_276_tmpany_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_277_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_275_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_277_tmpany_phold);
} /* Line: 629 */
 else  /* Line: 631 */ {
bevt_278_tmpany_phold = bevl_carg.bem_namepathGet_0();
bevl_syn = bevp_build.bem_getSynNp_1(bevt_278_tmpany_phold);
bevt_281_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_280_tmpany_phold = bevl_syn.bem_castsTo_1(bevt_281_tmpany_phold);
bevt_279_tmpany_phold = bevt_280_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_279_tmpany_phold != null && bevt_279_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_279_tmpany_phold).bevi_bool) /* Line: 633 */ {
bevt_286_tmpany_phold = bevo_5;
bevt_288_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_287_tmpany_phold = bevt_288_tmpany_phold.bem_toString_0();
bevt_285_tmpany_phold = bevt_286_tmpany_phold.bem_add_1(bevt_287_tmpany_phold);
bevt_289_tmpany_phold = bevo_6;
bevt_284_tmpany_phold = bevt_285_tmpany_phold.bem_add_1(bevt_289_tmpany_phold);
bevt_291_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_290_tmpany_phold = bevt_291_tmpany_phold.bem_toString_0();
bevt_283_tmpany_phold = bevt_284_tmpany_phold.bem_add_1(bevt_290_tmpany_phold);
bevt_282_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_283_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_282_tmpany_phold);
} /* Line: 634 */
} /* Line: 633 */
} /* Line: 627 */
} /* Line: 625 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 617 */
 else  /* Line: 617 */ {
break;
} /* Line: 617 */
} /* Line: 617 */
} /* Line: 617 */
} /* Line: 598 */
} /* Line: 420 */
} /* Line: 420 */
bevt_292_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_292_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {391, 391, 391, 391, 392, 392, 392, 392, 392, 392, 393, 393, 393, 396, 396, 396, 396, 397, 398, 398, 399, 399, 401, 401, 401, 401, 402, 404, 404, 404, 404, 405, 405, 406, 407, 407, 0, 407, 407, 408, 408, 408, 408, 409, 409, 420, 420, 420, 420, 421, 421, 423, 423, 424, 426, 426, 426, 426, 426, 429, 429, 430, 430, 430, 432, 433, 433, 433, 433, 0, 433, 433, 433, 433, 0, 0, 435, 435, 435, 437, 437, 437, 437, 438, 438, 439, 442, 442, 442, 442, 442, 445, 445, 445, 445, 446, 446, 448, 448, 450, 453, 453, 453, 453, 453, 456, 457, 457, 457, 457, 458, 458, 458, 459, 461, 461, 463, 463, 464, 464, 464, 464, 465, 465, 466, 466, 466, 468, 472, 472, 472, 0, 0, 0, 474, 475, 477, 477, 478, 478, 478, 483, 483, 483, 485, 486, 486, 486, 486, 486, 486, 0, 0, 0, 487, 489, 489, 490, 490, 492, 492, 496, 496, 498, 498, 498, 500, 501, 503, 505, 505, 506, 508, 508, 508, 510, 510, 510, 510, 510, 510, 510, 510, 510, 510, 516, 516, 516, 519, 519, 519, 519, 524, 524, 524, 524, 525, 526, 526, 526, 526, 527, 527, 528, 530, 530, 530, 530, 530, 533, 534, 534, 535, 537, 537, 537, 537, 537, 540, 540, 540, 540, 540, 540, 540, 0, 0, 0, 541, 541, 542, 542, 542, 543, 543, 543, 546, 546, 546, 550, 550, 550, 551, 551, 551, 553, 553, 553, 555, 555, 555, 556, 556, 556, 558, 558, 559, 559, 0, 559, 559, 0, 0, 561, 561, 561, 563, 563, 563, 563, 563, 563, 563, 563, 563, 567, 567, 568, 568, 568, 568, 570, 570, 570, 572, 572, 572, 572, 573, 573, 575, 575, 575, 577, 577, 577, 584, 584, 584, 587, 587, 587, 590, 590, 592, 592, 593, 595, 595, 595, 595, 595, 598, 598, 0, 598, 598, 598, 598, 0, 0, 599, 599, 599, 601, 601, 601, 602, 602, 603, 603, 603, 603, 604, 604, 604, 606, 606, 606, 607, 607, 607, 607, 609, 609, 610, 610, 610, 610, 612, 612, 613, 613, 613, 615, 616, 617, 617, 617, 617, 618, 619, 620, 620, 621, 621, 621, 622, 622, 622, 622, 622, 622, 622, 622, 0, 0, 0, 623, 623, 623, 623, 623, 623, 625, 625, 625, 625, 626, 627, 627, 627, 628, 628, 628, 629, 629, 629, 629, 632, 632, 633, 633, 633, 634, 634, 634, 634, 634, 634, 634, 634, 634, 634, 634, 643, 617, 648, 648, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {355, 356, 357, 362, 363, 364, 365, 366, 367, 368, 370, 371, 372, 375, 376, 377, 382, 383, 384, 385, 386, 387, 389, 390, 391, 396, 397, 399, 400, 401, 406, 407, 408, 409, 410, 411, 411, 414, 416, 417, 418, 419, 424, 425, 426, 433, 434, 435, 436, 438, 439, 440, 441, 443, 446, 447, 448, 449, 450, 452, 453, 455, 456, 457, 460, 461, 462, 463, 468, 469, 472, 473, 474, 479, 480, 483, 487, 488, 489, 492, 493, 494, 499, 500, 501, 503, 506, 507, 508, 509, 510, 514, 515, 516, 521, 522, 523, 524, 525, 527, 530, 531, 532, 533, 534, 536, 537, 538, 539, 544, 545, 546, 547, 550, 552, 553, 556, 561, 562, 563, 564, 565, 566, 571, 572, 573, 574, 577, 582, 587, 588, 590, 593, 597, 600, 601, 603, 608, 609, 610, 611, 613, 614, 615, 617, 620, 621, 626, 627, 628, 629, 631, 634, 638, 641, 646, 651, 652, 653, 656, 657, 660, 661, 663, 664, 665, 668, 670, 673, 675, 676, 677, 679, 680, 681, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 697, 698, 699, 702, 703, 704, 709, 715, 716, 717, 718, 720, 721, 722, 723, 728, 729, 730, 732, 735, 736, 737, 738, 739, 741, 742, 743, 745, 748, 749, 750, 751, 752, 754, 755, 756, 761, 762, 763, 764, 766, 769, 773, 776, 777, 779, 780, 781, 783, 784, 785, 787, 788, 789, 792, 793, 794, 796, 797, 798, 800, 801, 802, 805, 806, 807, 809, 810, 811, 813, 814, 815, 816, 818, 821, 822, 824, 827, 831, 832, 833, 836, 837, 838, 839, 840, 841, 842, 843, 844, 849, 850, 851, 852, 853, 854, 856, 857, 858, 861, 862, 863, 864, 865, 866, 868, 869, 870, 873, 874, 875, 882, 883, 884, 888, 889, 890, 894, 895, 896, 897, 899, 902, 903, 904, 905, 906, 908, 909, 911, 914, 915, 916, 917, 919, 922, 926, 927, 928, 931, 932, 933, 934, 935, 937, 938, 939, 944, 945, 946, 947, 949, 950, 951, 952, 953, 954, 955, 958, 959, 960, 961, 962, 963, 965, 970, 971, 972, 973, 975, 976, 977, 980, 981, 986, 987, 988, 990, 995, 996, 997, 998, 1001, 1002, 1003, 1008, 1009, 1010, 1011, 1016, 1017, 1020, 1024, 1027, 1028, 1029, 1030, 1031, 1032, 1035, 1036, 1037, 1042, 1043, 1044, 1045, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1060, 1061, 1062, 1063, 1064, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1081, 1082, 1092, 1093, 1096, 1099, 1103, 1106, 1110, 1113, 1117, 1120, 1124, 1127};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 391 355
typenameGet 0 391 355
assign 1 391 356
CATCHGet 0 391 356
assign 1 391 357
equals 1 391 362
assign 1 392 363
containedGet 0 392 363
assign 1 392 364
firstGet 0 392 364
assign 1 392 365
containedGet 0 392 365
assign 1 392 366
firstGet 0 392 366
assign 1 392 367
heldGet 0 392 367
assign 1 392 368
isTypedGet 0 392 368
assign 1 393 370
new 0 393 370
assign 1 393 371
new 1 393 371
throw 1 393 372
assign 1 396 375
typenameGet 0 396 375
assign 1 396 376
CLASSGet 0 396 376
assign 1 396 377
equals 1 396 382
assign 1 397 383
assign 1 398 384
heldGet 0 398 384
assign 1 398 385
namepathGet 0 398 385
assign 1 399 386
heldGet 0 399 386
assign 1 399 387
synGet 0 399 387
assign 1 401 389
typenameGet 0 401 389
assign 1 401 390
METHODGet 0 401 390
assign 1 401 391
equals 1 401 396
assign 1 402 397
new 0 402 397
assign 1 404 399
typenameGet 0 404 399
assign 1 404 400
CALLGet 0 404 400
assign 1 404 401
equals 1 404 406
assign 1 405 407
heldGet 0 405 407
cposSet 1 405 408
assign 1 406 409
increment 0 406 409
assign 1 407 410
containedGet 0 407 410
assign 1 407 411
iteratorGet 0 0 411
assign 1 407 414
hasNextGet 0 407 414
assign 1 407 416
nextGet 0 407 416
assign 1 408 417
typenameGet 0 408 417
assign 1 408 418
VARGet 0 408 418
assign 1 408 419
equals 1 408 424
assign 1 409 425
heldGet 0 409 425
addCall 1 409 426
assign 1 420 433
heldGet 0 420 433
assign 1 420 434
orgNameGet 0 420 434
assign 1 420 435
new 0 420 435
assign 1 420 436
equals 1 420 436
assign 1 421 438
containedGet 0 421 438
assign 1 421 439
firstGet 0 421 439
assign 1 423 440
heldGet 0 423 440
assign 1 423 441
isDeclaredGet 0 423 441
assign 1 424 443
heldGet 0 424 443
assign 1 426 446
ptyMapGet 0 426 446
assign 1 426 447
heldGet 0 426 447
assign 1 426 448
nameGet 0 426 448
assign 1 426 449
get 1 426 449
assign 1 426 450
memSynGet 0 426 450
assign 1 429 452
isTypedGet 0 429 452
assign 1 429 453
not 0 429 453
assign 1 430 455
heldGet 0 430 455
assign 1 430 456
new 0 430 456
checkTypesSet 1 430 457
assign 1 432 460
secondGet 0 432 460
assign 1 433 461
typenameGet 0 433 461
assign 1 433 462
TRUEGet 0 433 462
assign 1 433 463
equals 1 433 468
assign 1 0 469
assign 1 433 472
typenameGet 0 433 472
assign 1 433 473
FALSEGet 0 433 473
assign 1 433 474
equals 1 433 479
assign 1 0 480
assign 1 0 483
assign 1 435 487
heldGet 0 435 487
assign 1 435 488
new 0 435 488
checkTypesSet 1 435 489
assign 1 437 492
typenameGet 0 437 492
assign 1 437 493
VARGet 0 437 493
assign 1 437 494
equals 1 437 499
assign 1 438 500
heldGet 0 438 500
assign 1 438 501
isDeclaredGet 0 438 501
assign 1 439 503
heldGet 0 439 503
assign 1 442 506
ptyMapGet 0 442 506
assign 1 442 507
heldGet 0 442 507
assign 1 442 508
nameGet 0 442 508
assign 1 442 509
get 1 442 509
assign 1 442 510
memSynGet 0 442 510
assign 1 445 514
typenameGet 0 445 514
assign 1 445 515
CALLGet 0 445 515
assign 1 445 516
equals 1 445 521
assign 1 446 522
containedGet 0 446 522
assign 1 446 523
firstGet 0 446 523
assign 1 448 524
heldGet 0 448 524
assign 1 448 525
isDeclaredGet 0 448 525
assign 1 450 527
heldGet 0 450 527
assign 1 453 530
ptyMapGet 0 453 530
assign 1 453 531
heldGet 0 453 531
assign 1 453 532
nameGet 0 453 532
assign 1 453 533
get 1 453 533
assign 1 453 534
memSynGet 0 453 534
assign 1 456 536
assign 1 457 537
heldGet 0 457 537
assign 1 457 538
newNpGet 0 457 538
assign 1 457 539
def 1 457 544
assign 1 458 545
heldGet 0 458 545
assign 1 458 546
newNpGet 0 458 546
assign 1 458 547
getSynNp 1 458 547
assign 1 459 550
isTypedGet 0 459 550
assign 1 461 552
namepathGet 0 461 552
assign 1 461 553
getSynNp 1 461 553
assign 1 463 556
def 1 463 561
assign 1 464 562
mtdMapGet 0 464 562
assign 1 464 563
heldGet 0 464 563
assign 1 464 564
nameGet 0 464 564
assign 1 464 565
get 1 464 565
assign 1 465 566
undef 1 465 571
assign 1 466 572
new 0 466 572
assign 1 466 573
new 2 466 573
throw 1 466 574
assign 1 468 577
rsynGet 0 468 577
assign 1 472 582
def 1 472 587
assign 1 472 588
isTypedGet 0 472 588
assign 1 0 590
assign 1 0 593
assign 1 0 597
assign 1 474 600
new 0 474 600
assign 1 475 601
isSelfGet 0 475 601
assign 1 477 603
undef 1 477 608
assign 1 478 609
new 0 478 609
assign 1 478 610
new 1 478 610
throw 1 478 611
assign 1 483 613
originGet 0 483 613
assign 1 483 614
namepathGet 0 483 614
assign 1 483 615
notEquals 1 483 615
assign 1 485 617
new 0 485 617
assign 1 486 620
emitCommonGet 0 486 620
assign 1 486 621
def 1 486 626
assign 1 486 627
emitCommonGet 0 486 627
assign 1 486 628
coanyiantReturnsGet 0 486 628
assign 1 486 629
not 0 486 629
assign 1 0 631
assign 1 0 634
assign 1 0 638
assign 1 487 641
new 0 487 641
assign 1 489 646
def 1 489 651
assign 1 490 652
getEmitReturnType 2 490 652
assign 1 490 653
getSynNp 1 490 653
assign 1 492 656
namepathGet 0 492 656
assign 1 492 657
getSynNp 1 492 657
assign 1 496 660
namepathGet 0 496 660
assign 1 496 661
castsTo 1 496 661
assign 1 498 663
heldGet 0 498 663
assign 1 498 664
new 0 498 664
checkTypesSet 1 498 665
assign 1 500 668
isSelfGet 0 500 668
assign 1 501 670
namepathGet 0 501 670
assign 1 503 673
namepathGet 0 503 673
assign 1 505 675
namepathGet 0 505 675
assign 1 505 676
getSynNp 1 505 676
assign 1 506 677
castsTo 1 506 677
assign 1 508 679
heldGet 0 508 679
assign 1 508 680
new 0 508 680
checkTypesSet 1 508 681
assign 1 510 684
new 0 510 684
assign 1 510 685
namepathGet 0 510 685
assign 1 510 686
toString 0 510 686
assign 1 510 687
add 1 510 687
assign 1 510 688
new 0 510 688
assign 1 510 689
add 1 510 689
assign 1 510 690
toString 0 510 690
assign 1 510 691
add 1 510 691
assign 1 510 692
new 2 510 692
throw 1 510 693
assign 1 516 697
heldGet 0 516 697
assign 1 516 698
new 0 516 698
checkTypesSet 1 516 699
assign 1 519 702
heldGet 0 519 702
assign 1 519 703
namepathGet 0 519 703
assign 1 519 704
def 1 519 709
assign 1 524 715
heldGet 0 524 715
assign 1 524 716
orgNameGet 0 524 716
assign 1 524 717
new 0 524 717
assign 1 524 718
equals 1 524 718
assign 1 525 720
secondGet 0 525 720
assign 1 526 721
typenameGet 0 526 721
assign 1 526 722
VARGet 0 526 722
assign 1 526 723
equals 1 526 728
assign 1 527 729
heldGet 0 527 729
assign 1 527 730
isDeclaredGet 0 527 730
assign 1 528 732
heldGet 0 528 732
assign 1 530 735
ptyMapGet 0 530 735
assign 1 530 736
heldGet 0 530 736
assign 1 530 737
nameGet 0 530 737
assign 1 530 738
get 1 530 738
assign 1 530 739
memSynGet 0 530 739
assign 1 533 741
scopeGet 0 533 741
assign 1 534 742
heldGet 0 534 742
assign 1 534 743
isDeclaredGet 0 534 743
assign 1 535 745
heldGet 0 535 745
assign 1 537 748
ptyMapGet 0 537 748
assign 1 537 749
heldGet 0 537 749
assign 1 537 750
nameGet 0 537 750
assign 1 537 751
get 1 537 751
assign 1 537 752
memSynGet 0 537 752
assign 1 540 754
heldGet 0 540 754
assign 1 540 755
rtypeGet 0 540 755
assign 1 540 756
def 1 540 761
assign 1 540 762
heldGet 0 540 762
assign 1 540 763
rtypeGet 0 540 763
assign 1 540 764
isTypedGet 0 540 764
assign 1 0 766
assign 1 0 769
assign 1 0 773
assign 1 541 776
isTypedGet 0 541 776
assign 1 541 777
not 0 541 777
assign 1 542 779
heldGet 0 542 779
assign 1 542 780
rtypeGet 0 542 780
assign 1 542 781
isThisGet 0 542 781
assign 1 543 783
new 0 543 783
assign 1 543 784
new 2 543 784
throw 1 543 785
assign 1 546 787
heldGet 0 546 787
assign 1 546 788
new 0 546 788
checkTypesSet 1 546 789
assign 1 550 792
heldGet 0 550 792
assign 1 550 793
rtypeGet 0 550 793
assign 1 550 794
isSelfGet 0 550 794
assign 1 551 796
nameGet 0 551 796
assign 1 551 797
new 0 551 797
assign 1 551 798
equals 1 551 798
assign 1 553 800
heldGet 0 553 800
assign 1 553 801
new 0 553 801
checkTypesSet 1 553 802
assign 1 555 805
heldGet 0 555 805
assign 1 555 806
rtypeGet 0 555 806
assign 1 555 807
isThisGet 0 555 807
assign 1 556 809
new 0 556 809
assign 1 556 810
new 2 556 810
throw 1 556 811
assign 1 558 813
namepathGet 0 558 813
assign 1 558 814
getSynNp 1 558 814
assign 1 559 815
namepathGet 0 559 815
assign 1 559 816
castsTo 1 559 816
assign 1 0 818
assign 1 559 821
namepathGet 0 559 821
assign 1 559 822
castsTo 1 559 822
assign 1 0 824
assign 1 0 827
assign 1 561 831
heldGet 0 561 831
assign 1 561 832
new 0 561 832
checkTypesSet 1 561 833
assign 1 563 836
new 0 563 836
assign 1 563 837
namepathGet 0 563 837
assign 1 563 838
add 1 563 838
assign 1 563 839
new 0 563 839
assign 1 563 840
add 1 563 840
assign 1 563 841
namepathGet 0 563 841
assign 1 563 842
add 1 563 842
assign 1 563 843
new 2 563 843
throw 1 563 844
assign 1 567 849
namepathGet 0 567 849
assign 1 567 850
getSynNp 1 567 850
assign 1 568 851
heldGet 0 568 851
assign 1 568 852
rtypeGet 0 568 852
assign 1 568 853
namepathGet 0 568 853
assign 1 568 854
castsTo 1 568 854
assign 1 570 856
heldGet 0 570 856
assign 1 570 857
new 0 570 857
checkTypesSet 1 570 858
assign 1 572 861
heldGet 0 572 861
assign 1 572 862
rtypeGet 0 572 862
assign 1 572 863
namepathGet 0 572 863
assign 1 572 864
getSynNp 1 572 864
assign 1 573 865
namepathGet 0 573 865
assign 1 573 866
castsTo 1 573 866
assign 1 575 868
heldGet 0 575 868
assign 1 575 869
new 0 575 869
checkTypesSet 1 575 870
assign 1 577 873
new 0 577 873
assign 1 577 874
new 2 577 874
throw 1 577 875
assign 1 584 882
heldGet 0 584 882
assign 1 584 883
new 0 584 883
checkTypesSet 1 584 884
assign 1 587 888
heldGet 0 587 888
assign 1 587 889
new 0 587 889
checkTypesSet 1 587 890
assign 1 590 894
containedGet 0 590 894
assign 1 590 895
firstGet 0 590 895
assign 1 592 896
heldGet 0 592 896
assign 1 592 897
isDeclaredGet 0 592 897
assign 1 593 899
heldGet 0 593 899
assign 1 595 902
ptyMapGet 0 595 902
assign 1 595 903
heldGet 0 595 903
assign 1 595 904
nameGet 0 595 904
assign 1 595 905
get 1 595 905
assign 1 595 906
memSynGet 0 595 906
assign 1 598 908
isTypedGet 0 598 908
assign 1 598 909
not 0 598 909
assign 1 0 911
assign 1 598 914
heldGet 0 598 914
assign 1 598 915
orgNameGet 0 598 915
assign 1 598 916
new 0 598 916
assign 1 598 917
equals 1 598 917
assign 1 0 919
assign 1 0 922
assign 1 599 926
heldGet 0 599 926
assign 1 599 927
new 0 599 927
checkTypesSet 1 599 928
assign 1 601 931
heldGet 0 601 931
assign 1 601 932
new 0 601 932
checkTypesSet 1 601 933
assign 1 602 934
heldGet 0 602 934
assign 1 602 935
isConstructGet 0 602 935
assign 1 603 937
heldGet 0 603 937
assign 1 603 938
newNpGet 0 603 938
assign 1 603 939
undef 1 603 944
assign 1 604 945
new 0 604 945
assign 1 604 946
new 1 604 946
throw 1 604 947
assign 1 606 949
heldGet 0 606 949
assign 1 606 950
newNpGet 0 606 950
assign 1 606 951
getSynNp 1 606 951
assign 1 607 952
mtdMapGet 0 607 952
assign 1 607 953
heldGet 0 607 953
assign 1 607 954
nameGet 0 607 954
assign 1 607 955
get 1 607 955
assign 1 609 958
namepathGet 0 609 958
assign 1 609 959
getSynNp 1 609 959
assign 1 610 960
mtdMapGet 0 610 960
assign 1 610 961
heldGet 0 610 961
assign 1 610 962
nameGet 0 610 962
assign 1 610 963
get 1 610 963
assign 1 612 965
undef 1 612 970
assign 1 613 971
new 0 613 971
assign 1 613 972
new 2 613 972
throw 1 613 973
assign 1 615 975
argSynsGet 0 615 975
assign 1 616 976
nextPeerGet 0 616 976
assign 1 617 977
new 0 617 977
assign 1 617 980
lengthGet 0 617 980
assign 1 617 981
lesser 1 617 986
assign 1 618 987
get 1 618 987
assign 1 619 988
isTypedGet 0 619 988
assign 1 620 990
undef 1 620 995
assign 1 621 996
new 0 621 996
assign 1 621 997
new 2 621 997
throw 1 621 998
assign 1 622 1001
typenameGet 0 622 1001
assign 1 622 1002
VARGet 0 622 1002
assign 1 622 1003
notEquals 1 622 1008
assign 1 622 1009
typenameGet 0 622 1009
assign 1 622 1010
NULLGet 0 622 1010
assign 1 622 1011
notEquals 1 622 1016
assign 1 0 1017
assign 1 0 1020
assign 1 0 1024
assign 1 623 1027
new 0 623 1027
assign 1 623 1028
typenameGet 0 623 1028
assign 1 623 1029
toString 0 623 1029
assign 1 623 1030
add 1 623 1030
assign 1 623 1031
new 2 623 1031
throw 1 623 1032
assign 1 625 1035
typenameGet 0 625 1035
assign 1 625 1036
VARGet 0 625 1036
assign 1 625 1037
equals 1 625 1042
assign 1 626 1043
heldGet 0 626 1043
assign 1 627 1044
isTypedGet 0 627 1044
assign 1 627 1045
not 0 627 1050
assign 1 628 1051
heldGet 0 628 1051
assign 1 628 1052
new 0 628 1052
checkTypesSet 1 628 1053
assign 1 629 1054
heldGet 0 629 1054
assign 1 629 1055
argCastsGet 0 629 1055
assign 1 629 1056
namepathGet 0 629 1056
put 2 629 1057
assign 1 632 1060
namepathGet 0 632 1060
assign 1 632 1061
getSynNp 1 632 1061
assign 1 633 1062
namepathGet 0 633 1062
assign 1 633 1063
castsTo 1 633 1063
assign 1 633 1064
not 0 633 1064
assign 1 634 1066
new 0 634 1066
assign 1 634 1067
namepathGet 0 634 1067
assign 1 634 1068
toString 0 634 1068
assign 1 634 1069
add 1 634 1069
assign 1 634 1070
new 0 634 1070
assign 1 634 1071
add 1 634 1071
assign 1 634 1072
namepathGet 0 634 1072
assign 1 634 1073
toString 0 634 1073
assign 1 634 1074
add 1 634 1074
assign 1 634 1075
new 2 634 1075
throw 1 634 1076
assign 1 643 1081
nextPeerGet 0 643 1081
assign 1 617 1082
increment 0 617 1082
assign 1 648 1092
nextDescendGet 0 648 1092
return 1 648 1093
return 1 0 1096
assign 1 0 1099
return 1 0 1103
assign 1 0 1106
return 1 0 1110
assign 1 0 1113
return 1 0 1117
assign 1 0 1120
return 1 0 1124
assign 1 0 1127
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -2028575047: return bem_emitterGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case -2041762316: return bem_inClassGet_0();
case -1012494862: return bem_once_0();
case -997464046: return bem_inClassSynGet_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -2030680063: return bem_inClassSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2117282045: return bem_cposSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
