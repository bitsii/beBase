package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildPtySyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildPtySyn() { }
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x74,0x79,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_0 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildPtySyn_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildPtySyn_bels_0, 8));
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildPtySyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildPtySyn_bels_1, 4));
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_2 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_3 = {0x6D,0x65,0x6D,0x54,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_4 = {0x61,0x6E,0x79};
public static BEC_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_inst;
public BEC_2_4_3_MathInt bevp_mpos;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_6_BuildVarSyn bevp_memSyn;
public BEC_2_5_6_BuildPtySyn bem_new_2(BEC_2_6_6_SystemObject beva_vnode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_5_3_BuildVar bevl_v = null;
bevl_v = (BEC_2_5_3_BuildVar) beva_vnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_name = bevl_v.bem_nameGet_0();
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_memSyn = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1(bevl_v);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_5_tmpany_phold = bece_BEC_2_5_6_BuildPtySyn_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_nl);
bevt_6_tmpany_phold = bece_BEC_2_5_6_BuildPtySyn_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevl_nl);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevl_toRet = bevt_1_tmpany_phold.bem_add_1(bevl_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildPtySyn_bels_2));
bevt_9_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_10_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_11_tmpany_phold = bevp_origin.bem_toString_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpany_phold);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildPtySyn_bels_3));
bevt_12_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_13_tmpany_phold);
bevl_toRet = bevt_12_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_14_tmpany_phold = bevp_memSyn.bem_isTypedGet_0();
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevt_17_tmpany_phold = bevp_memSyn.bem_namepathGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_toString_0();
bevt_15_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_16_tmpany_phold);
bevl_toRet = bevt_15_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 523 */
 else  /* Line: 524 */ {
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildPtySyn_bels_4));
bevt_18_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_19_tmpany_phold);
bevl_toRet = bevt_18_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 525 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_mposGet_0() throws Throwable {
return bevp_mpos;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_mposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_memSynGet_0() throws Throwable {
return bevp_memSyn;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_memSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {507, 511, 512, 513, 518, 518, 519, 519, 519, 519, 519, 519, 519, 520, 520, 520, 520, 520, 520, 521, 521, 521, 522, 523, 523, 523, 523, 525, 525, 525, 527, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 24, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 70, 71, 72, 73, 76, 77, 78, 80, 83, 86, 90, 93, 97, 100, 104, 107};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 507 21
heldGet 0 507 21
assign 1 511 22
nameGet 0 511 22
assign 1 512 23
assign 1 513 24
anyNew 1 513 24
assign 1 518 50
new 0 518 50
assign 1 518 51
newlineGet 0 518 51
assign 1 519 52
new 0 519 52
assign 1 519 53
add 1 519 53
assign 1 519 54
new 0 519 54
assign 1 519 55
add 1 519 55
assign 1 519 56
add 1 519 56
assign 1 519 57
add 1 519 57
assign 1 519 58
add 1 519 58
assign 1 520 59
new 0 520 59
assign 1 520 60
add 1 520 60
assign 1 520 61
add 1 520 61
assign 1 520 62
toString 0 520 62
assign 1 520 63
add 1 520 63
assign 1 520 64
add 1 520 64
assign 1 521 65
new 0 521 65
assign 1 521 66
add 1 521 66
assign 1 521 67
add 1 521 67
assign 1 522 68
isTypedGet 0 522 68
assign 1 523 70
namepathGet 0 523 70
assign 1 523 71
toString 0 523 71
assign 1 523 72
add 1 523 72
assign 1 523 73
add 1 523 73
assign 1 525 76
new 0 525 76
assign 1 525 77
add 1 525 77
assign 1 525 78
add 1 525 78
return 1 527 80
return 1 0 83
assign 1 0 86
return 1 0 90
assign 1 0 93
return 1 0 97
assign 1 0 100
return 1 0 104
assign 1 0 107
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1707345409: return bem_originGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1271927552: return bem_mposGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case 1444794516: return bem_memSynGet_0();
case -1354714650: return bem_copy_0();
case 1211273660: return bem_nameGet_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1455876769: return bem_memSynSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1718427662: return bem_originSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1283009805: return bem_mposSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 104713555: return bem_new_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildPtySyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildPtySyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildPtySyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst = (BEC_2_5_6_BuildPtySyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst;
}
}
