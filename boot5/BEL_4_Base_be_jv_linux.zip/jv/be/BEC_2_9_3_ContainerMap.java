package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap extends BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerMap bevs_inst;
public BEC_2_9_3_ContainerMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
bevt_6_tmpany_phold = bevl_other.bem_sizeGet_0();
bevt_7_tmpany_phold = this.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 129 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 129 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 130 */
bevt_0_tmpany_loop = this.bem_mapIteratorGet_0();
while (true)
 /* Line: 132 */ {
bevt_9_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevl_v = bevl_other.bem_get_1(bevt_10_tmpany_phold);
if (bevl_v == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_13_tmpany_phold = bevl_i.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
if (bevt_13_tmpany_phold == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 134 */ {
if (bevl_v == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 134 */
 else  /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 134 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 134 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_v);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 134 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 134 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 134 */ {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_17_tmpany_phold;
} /* Line: 134 */
} /* Line: 134 */
 else  /* Line: 132 */ {
break;
} /* Line: 132 */
} /* Line: 132 */
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 143 */ {
bevt_3_tmpany_phold = this.bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
} /* Line: 144 */
 else  /* Line: 143 */ {
break;
} /* Line: 143 */
} /* Line: 143 */
bevp_slots = bevl_slt;
} /* Line: 146 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 148 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 149 */
return this;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_valueIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_tmpany_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
 /* Line: 177 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 177 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_4_tmpany_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_5_tmpany_phold = bevl_x.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 178 */
 else  /* Line: 177 */ {
break;
} /* Line: 177 */
} /* Line: 177 */
} /* Line: 177 */
 else  /* Line: 175 */ {
bevt_6_tmpany_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 180 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_8_tmpany_phold = beva_other.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
} /* Line: 181 */
 else  /* Line: 182 */ {
this.bem_put_2(beva_other, beva_other);
} /* Line: 183 */
} /* Line: 175 */
} /* Line: 175 */
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_toRet = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = this.bem_mapIteratorGet_0();
while (true)
 /* Line: 190 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, beva_prefix);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 191 */ {
bevt_4_tmpany_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_5_tmpany_phold = bevl_x.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevl_toRet.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 192 */
} /* Line: 191 */
 else  /* Line: 190 */ {
break;
} /* Line: 190 */
} /* Line: 190 */
return bevl_toRet;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 111, 115, 116, 117, 118, 119, 120, 124, 124, 128, 129, 129, 0, 129, 129, 129, 129, 0, 0, 130, 130, 132, 0, 132, 132, 133, 133, 134, 134, 0, 134, 134, 134, 134, 134, 0, 0, 0, 0, 0, 0, 134, 134, 0, 0, 134, 134, 136, 136, 140, 140, 141, 142, 143, 143, 144, 146, 149, 154, 154, 158, 158, 162, 162, 166, 166, 170, 170, 174, 174, 175, 176, 177, 0, 177, 177, 178, 178, 178, 180, 181, 181, 181, 183, 189, 190, 0, 190, 190, 191, 191, 192, 192, 192, 195};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 11, 15, 16, 17, 18, 19, 20, 25, 26, 51, 52, 57, 58, 61, 62, 63, 68, 69, 72, 76, 77, 79, 79, 82, 84, 85, 86, 87, 92, 93, 96, 97, 102, 103, 108, 109, 112, 116, 119, 122, 126, 129, 130, 132, 135, 139, 140, 147, 148, 156, 157, 159, 160, 163, 164, 166, 172, 175, 181, 182, 186, 187, 191, 192, 196, 197, 201, 202, 216, 221, 222, 224, 225, 225, 228, 230, 231, 232, 233, 241, 243, 244, 245, 248, 263, 264, 264, 267, 269, 270, 271, 273, 274, 275, 282};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 10
new 0 111 10
new 1 111 11
assign 1 115 15
new 1 115 15
assign 1 116 16
assign 1 117 17
new 0 117 17
assign 1 118 18
new 0 118 18
assign 1 119 19
new 0 119 19
assign 1 120 20
new 0 120 20
assign 1 124 25
new 1 124 25
return 1 124 26
assign 1 128 51
assign 1 129 52
undef 1 129 57
assign 1 0 58
assign 1 129 61
sizeGet 0 129 61
assign 1 129 62
sizeGet 0 129 62
assign 1 129 63
notEquals 1 129 68
assign 1 0 69
assign 1 0 72
assign 1 130 76
new 0 130 76
return 1 130 77
assign 1 132 79
mapIteratorGet 0 0 79
assign 1 132 82
hasNextGet 0 132 82
assign 1 132 84
nextGet 0 132 84
assign 1 133 85
keyGet 0 133 85
assign 1 133 86
get 1 133 86
assign 1 134 87
undef 1 134 92
assign 1 0 93
assign 1 134 96
valueGet 0 134 96
assign 1 134 97
undef 1 134 102
assign 1 134 103
def 1 134 108
assign 1 0 109
assign 1 0 112
assign 1 0 116
assign 1 0 119
assign 1 0 122
assign 1 0 126
assign 1 134 129
valueGet 0 134 129
assign 1 134 130
notEquals 1 134 130
assign 1 0 132
assign 1 0 135
assign 1 134 139
new 0 134 139
return 1 134 140
assign 1 136 147
new 0 136 147
return 1 136 148
assign 1 140 156
innerPut 4 140 156
assign 1 140 157
not 0 140 157
assign 1 141 159
assign 1 142 160
rehash 1 142 160
assign 1 143 163
innerPut 4 143 163
assign 1 143 164
not 0 143 164
assign 1 144 166
rehash 1 144 166
assign 1 146 172
assign 1 149 175
increment 0 149 175
assign 1 154 181
new 1 154 181
return 1 154 182
assign 1 158 186
valueIteratorGet 0 158 186
return 1 158 187
assign 1 162 191
new 1 162 191
return 1 162 192
assign 1 166 196
new 1 166 196
return 1 166 197
assign 1 170 201
new 1 170 201
return 1 170 202
assign 1 174 216
def 1 174 221
assign 1 175 222
sameType 1 175 222
assign 1 176 224
assign 1 177 225
mapIteratorGet 0 0 225
assign 1 177 228
hasNextGet 0 177 228
assign 1 177 230
nextGet 0 177 230
assign 1 178 231
keyGet 0 178 231
assign 1 178 232
valueGet 0 178 232
put 2 178 233
assign 1 180 241
sameType 1 180 241
assign 1 181 243
keyGet 0 181 243
assign 1 181 244
valueGet 0 181 244
put 2 181 245
put 2 183 248
assign 1 189 263
new 0 189 263
assign 1 190 264
mapIteratorGet 0 0 264
assign 1 190 267
hasNextGet 0 190 267
assign 1 190 269
nextGet 0 190 269
assign 1 191 270
keyGet 0 191 270
assign 1 191 271
begins 1 191 271
assign 1 192 273
keyGet 0 192 273
assign 1 192 274
valueGet 0 192 274
put 2 192 275
return 1 195 282
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1227011022: return bem_multiGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -1431826729: return bem_nodeIteratorGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case -1586230380: return bem_moduGet_0();
case -550406779: return bem_valuesGet_0();
case -1308786538: return bem_echo_0();
case 354906194: return bem_slotsGet_0();
case 856777406: return bem_clear_0();
case -712928736: return bem_innerPutAddedGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2086347094: return bem_nodesGet_0();
case -902391673: return bem_keyValueIteratorGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case -2145224760: return bem_valueIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1012494862: return bem_once_0();
case -578884498: return bem_relGet_0();
case 287040793: return bem_hashGet_0();
case -1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 2056412570: return bem_keyIteratorGet_0();
case -1114073101: return bem_keysGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1089531140: return bem_isEmptyGet_0();
case -845792839: return bem_iteratorGet_0();
case -2142483603: return bem_notEmptyGet_0();
case -444835395: return bem_mapIteratorGet_0();
case -314718434: return bem_print_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1575148127: return bem_moduSet_1(bevd_0);
case 1959489624: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case -567802245: return bem_relSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case -286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -668984013: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 107034370: return bem_put_2(bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -131089957: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerMap.bevs_inst = (BEC_2_9_3_ContainerMap)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerMap.bevs_inst;
}
}
