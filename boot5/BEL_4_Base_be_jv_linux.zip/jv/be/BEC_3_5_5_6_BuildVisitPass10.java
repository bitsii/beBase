package be;
/* IO:File: source/build/Pass10.be */
public final class BEC_3_5_5_6_BuildVisitPass10 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass10() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x30};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x30,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_1 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_2 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_3 = {0x61,0x6E,0x63,0x68,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_5 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_6 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
public static BEC_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;
public BEC_2_6_6_SystemObject bem_condCall_2(BEC_2_6_6_SystemObject beva_condany, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_acc = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_5_4_BuildCall bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_cnode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_cnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_1_tmpany_phold);
bevl_acc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_acc.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_2_tmpany_phold);
bevl_acc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_condany);
bevl_cnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_acc);
bevt_3_tmpany_phold = bevl_cnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_0));
bevt_3_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_4_tmpany_phold);
bevl_nnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, beva_value);
bevl_cnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nnode);
return bevl_cnode;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_anchor = null;
BEC_2_6_6_SystemObject bevl_condany = null;
BEC_2_6_6_SystemObject bevl_cvnp = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_rinode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpany_phold = null;
bevt_4_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_5_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_4_tmpany_phold.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 32 */ {
bevt_8_tmpany_phold = beva_node.bem_containedGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_lengthGet_0();
bevt_9_tmpany_phold = bevo_0;
if (bevt_7_tmpany_phold.bevi_int == bevt_9_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 32 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 32 */
 else  /* Line: 32 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 32 */ {
bevt_13_tmpany_phold = beva_node.bem_containedGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_firstGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_14_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpany_phold);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 32 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 32 */
 else  /* Line: 32 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 32 */ {
bevt_16_tmpany_phold = beva_node.bem_containedGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_firstGet_0();
beva_node.bem_takeContents_1((BEC_2_5_4_BuildNode) bevt_15_tmpany_phold );
return beva_node;
} /* Line: 34 */
bevt_18_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_18_tmpany_phold.bevi_int == bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_20_tmpany_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_20_tmpany_phold);
beva_node.bem_syncVariable_1(this);
} /* Line: 39 */
bevt_22_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevt_26_tmpany_phold = beva_node.bem_heldGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpany_phold);
if (bevt_24_tmpany_phold != null && bevt_24_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 42 */ {
bevt_30_tmpany_phold = beva_node.bem_heldGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_2));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_31_tmpany_phold);
if (bevt_28_tmpany_phold != null && bevt_28_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 42 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 42 */
 else  /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 42 */ {
bevl_anchor = beva_node.bem_anchorGet_0();
bevl_condany = bevl_anchor.bemd_0(1425568797, BEL_4_Base.bevn_condanyGet_0);
if (bevl_condany == null) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_3));
bevl_condany = bevl_anchor.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_33_tmpany_phold, bevp_build);
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_condany.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_34_tmpany_phold);
bevl_cvnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_4));
bevl_cvnp.bemd_1(-630006451, BEL_4_Base.bevn_fromString_1, bevt_35_tmpany_phold);
bevl_condany.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_cvnp);
bevl_anchor.bemd_1(1436651050, BEL_4_Base.bevn_condanySet_1, bevl_condany);
} /* Line: 53 */
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_36_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_36_tmpany_phold);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_rinode = bevl_inode;
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_37_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_37_tmpany_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_pnode);
bevt_39_tmpany_phold = beva_node.bem_containedGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_firstGet_0();
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_38_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_40_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_40_tmpany_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_43_tmpany_phold = beva_node.bem_heldGet_0();
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_5));
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_44_tmpany_phold);
if (bevt_41_tmpany_phold != null && bevt_41_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_41_tmpany_phold).bevi_bool) /* Line: 74 */ {
bevt_46_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_45_tmpany_phold = this.bem_condCall_2(bevl_condany, bevt_46_tmpany_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_45_tmpany_phold);
} /* Line: 75 */
 else  /* Line: 77 */ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_47_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_47_tmpany_phold);
bevl_inode.bemd_1(1436651050, BEL_4_Base.bevn_condanySet_1, bevl_condany);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_48_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_48_tmpany_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_pnode);
bevt_49_tmpany_phold = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_49_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_50_tmpany_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_52_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_51_tmpany_phold = this.bem_condCall_2(bevl_condany, bevt_52_tmpany_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_51_tmpany_phold);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_53_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_53_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_54_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_54_tmpany_phold);
bevt_56_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_55_tmpany_phold = this.bem_condCall_2(bevl_condany, bevt_56_tmpany_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_55_tmpany_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
} /* Line: 104 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_57_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_57_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_58_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_58_tmpany_phold);
bevl_rinode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_61_tmpany_phold = beva_node.bem_heldGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_6));
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_62_tmpany_phold);
if (bevt_59_tmpany_phold != null && bevt_59_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 116 */ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_63_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_63_tmpany_phold);
bevl_inode.bemd_1(1436651050, BEL_4_Base.bevn_condanySet_1, bevl_condany);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_64_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_64_tmpany_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_pnode);
bevt_65_tmpany_phold = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_65_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_66_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_66_tmpany_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_68_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_67_tmpany_phold = this.bem_condCall_2(bevl_condany, bevt_68_tmpany_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_67_tmpany_phold);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_69_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_69_tmpany_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_70_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_70_tmpany_phold);
bevt_72_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_71_tmpany_phold = this.bem_condCall_2(bevl_condany, bevt_72_tmpany_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_71_tmpany_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
} /* Line: 142 */
 else  /* Line: 143 */ {
bevt_74_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_73_tmpany_phold = this.bem_condCall_2(bevl_condany, bevt_74_tmpany_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_73_tmpany_phold);
} /* Line: 144 */
bevl_anchor.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_rinode);
beva_node.bem_containedSet_1(null);
bevt_75_tmpany_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_75_tmpany_phold);
beva_node.bem_heldSet_1(bevl_condany);
beva_node.bem_syncAddVariable_0();
bevt_76_tmpany_phold = bevl_rinode.bemd_0(-1779180144, BEL_4_Base.bevn_nextDescendGet_0);
return (BEC_2_5_4_BuildNode) bevt_76_tmpany_phold;
} /* Line: 153 */
bevt_77_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_77_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 18, 19, 19, 20, 21, 21, 22, 23, 24, 24, 24, 25, 26, 27, 28, 32, 32, 32, 32, 32, 32, 32, 32, 32, 0, 0, 0, 32, 32, 32, 32, 32, 0, 0, 0, 33, 33, 33, 34, 37, 37, 37, 37, 38, 38, 39, 42, 42, 42, 42, 42, 42, 42, 42, 0, 42, 42, 42, 42, 0, 0, 0, 0, 0, 44, 45, 47, 47, 48, 48, 49, 49, 50, 51, 51, 52, 53, 56, 57, 57, 58, 60, 62, 63, 64, 64, 65, 67, 67, 67, 69, 70, 71, 71, 72, 74, 74, 74, 74, 75, 75, 75, 79, 80, 81, 81, 82, 83, 85, 86, 87, 87, 88, 89, 89, 90, 91, 92, 92, 93, 94, 94, 94, 96, 97, 98, 98, 99, 100, 101, 101, 102, 102, 102, 103, 104, 107, 108, 109, 109, 110, 111, 112, 112, 113, 114, 116, 116, 116, 116, 117, 118, 119, 119, 120, 121, 123, 124, 125, 125, 126, 127, 127, 128, 129, 130, 130, 131, 132, 132, 132, 134, 135, 136, 136, 137, 138, 139, 140, 140, 141, 141, 141, 142, 144, 144, 144, 148, 149, 150, 150, 151, 152, 153, 153, 156, 156};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 130, 131, 132, 137, 138, 139, 140, 141, 146, 147, 150, 154, 157, 158, 159, 160, 161, 163, 166, 170, 173, 174, 175, 176, 178, 179, 180, 185, 186, 187, 188, 190, 191, 192, 197, 198, 199, 200, 201, 203, 206, 207, 208, 209, 211, 214, 218, 221, 225, 228, 229, 230, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 269, 270, 271, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 360, 361, 362, 364, 365, 366, 367, 368, 369, 370, 371, 373, 374};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 25
new 1 17 25
assign 1 18 26
new 0 18 26
heldSet 1 18 27
assign 1 19 28
CALLGet 0 19 28
typenameSet 1 19 29
assign 1 20 30
new 1 20 30
assign 1 21 31
VARGet 0 21 31
typenameSet 1 21 32
heldSet 1 22 33
addValue 1 23 34
assign 1 24 35
heldGet 0 24 35
assign 1 24 36
new 0 24 36
nameSet 1 24 37
assign 1 25 38
new 1 25 38
typenameSet 1 26 39
addValue 1 27 40
return 1 28 41
assign 1 32 130
typenameGet 0 32 130
assign 1 32 131
PARENSGet 0 32 131
assign 1 32 132
equals 1 32 137
assign 1 32 138
containedGet 0 32 138
assign 1 32 139
lengthGet 0 32 139
assign 1 32 140
new 0 32 140
assign 1 32 141
equals 1 32 146
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 32 157
containedGet 0 32 157
assign 1 32 158
firstGet 0 32 158
assign 1 32 159
typenameGet 0 32 159
assign 1 32 160
PARENSGet 0 32 160
assign 1 32 161
equals 1 32 161
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 33 173
containedGet 0 33 173
assign 1 33 174
firstGet 0 33 174
takeContents 1 33 175
return 1 34 176
assign 1 37 178
typenameGet 0 37 178
assign 1 37 179
IDGet 0 37 179
assign 1 37 180
equals 1 37 185
assign 1 38 186
VARGet 0 38 186
typenameSet 1 38 187
syncVariable 1 39 188
assign 1 42 190
typenameGet 0 42 190
assign 1 42 191
CALLGet 0 42 191
assign 1 42 192
equals 1 42 197
assign 1 42 198
heldGet 0 42 198
assign 1 42 199
nameGet 0 42 199
assign 1 42 200
new 0 42 200
assign 1 42 201
equals 1 42 201
assign 1 0 203
assign 1 42 206
heldGet 0 42 206
assign 1 42 207
nameGet 0 42 207
assign 1 42 208
new 0 42 208
assign 1 42 209
equals 1 42 209
assign 1 0 211
assign 1 0 214
assign 1 0 218
assign 1 0 221
assign 1 0 225
assign 1 44 228
anchorGet 0 44 228
assign 1 45 229
condanyGet 0 45 229
assign 1 47 230
undef 1 47 235
assign 1 48 236
new 0 48 236
assign 1 48 237
tmpVar 2 48 237
assign 1 49 238
new 0 49 238
isTypedSet 1 49 239
assign 1 50 240
new 0 50 240
assign 1 51 241
new 0 51 241
fromString 1 51 242
namepathSet 1 52 243
condanySet 1 53 244
assign 1 56 246
new 1 56 246
assign 1 57 247
IFGet 0 57 247
typenameSet 1 57 248
copyLoc 1 58 249
assign 1 60 250
assign 1 62 251
new 1 62 251
copyLoc 1 63 252
assign 1 64 253
PARENSGet 0 64 253
typenameSet 1 64 254
addValue 1 65 255
assign 1 67 256
containedGet 0 67 256
assign 1 67 257
firstGet 0 67 257
addValue 1 67 258
assign 1 69 259
new 1 69 259
copyLoc 1 70 260
assign 1 71 261
BRACESGet 0 71 261
typenameSet 1 71 262
addValue 1 72 263
assign 1 74 264
heldGet 0 74 264
assign 1 74 265
nameGet 0 74 265
assign 1 74 266
new 0 74 266
assign 1 74 267
equals 1 74 267
assign 1 75 269
TRUEGet 0 75 269
assign 1 75 270
condCall 2 75 270
addValue 1 75 271
assign 1 79 274
new 1 79 274
copyLoc 1 80 275
assign 1 81 276
IFGet 0 81 276
typenameSet 1 81 277
condanySet 1 82 278
addValue 1 83 279
assign 1 85 280
new 1 85 280
copyLoc 1 86 281
assign 1 87 282
PARENSGet 0 87 282
typenameSet 1 87 283
addValue 1 88 284
assign 1 89 285
secondGet 0 89 285
addValue 1 89 286
assign 1 90 287
new 1 90 287
copyLoc 1 91 288
assign 1 92 289
BRACESGet 0 92 289
typenameSet 1 92 290
addValue 1 93 291
assign 1 94 292
TRUEGet 0 94 292
assign 1 94 293
condCall 2 94 293
addValue 1 94 294
assign 1 96 295
new 1 96 295
copyLoc 1 97 296
assign 1 98 297
ELSEGet 0 98 297
typenameSet 1 98 298
assign 1 99 299
new 1 99 299
copyLoc 1 100 300
assign 1 101 301
BRACESGet 0 101 301
typenameSet 1 101 302
assign 1 102 303
FALSEGet 0 102 303
assign 1 102 304
condCall 2 102 304
addValue 1 102 305
addValue 1 103 306
addValue 1 104 307
assign 1 107 309
new 1 107 309
copyLoc 1 108 310
assign 1 109 311
ELSEGet 0 109 311
typenameSet 1 109 312
assign 1 110 313
new 1 110 313
copyLoc 1 111 314
assign 1 112 315
BRACESGet 0 112 315
typenameSet 1 112 316
addValue 1 113 317
addValue 1 114 318
assign 1 116 319
heldGet 0 116 319
assign 1 116 320
nameGet 0 116 320
assign 1 116 321
new 0 116 321
assign 1 116 322
equals 1 116 322
assign 1 117 324
new 1 117 324
copyLoc 1 118 325
assign 1 119 326
IFGet 0 119 326
typenameSet 1 119 327
condanySet 1 120 328
addValue 1 121 329
assign 1 123 330
new 1 123 330
copyLoc 1 124 331
assign 1 125 332
PARENSGet 0 125 332
typenameSet 1 125 333
addValue 1 126 334
assign 1 127 335
secondGet 0 127 335
addValue 1 127 336
assign 1 128 337
new 1 128 337
copyLoc 1 129 338
assign 1 130 339
BRACESGet 0 130 339
typenameSet 1 130 340
addValue 1 131 341
assign 1 132 342
TRUEGet 0 132 342
assign 1 132 343
condCall 2 132 343
addValue 1 132 344
assign 1 134 345
new 1 134 345
copyLoc 1 135 346
assign 1 136 347
ELSEGet 0 136 347
typenameSet 1 136 348
addValue 1 137 349
assign 1 138 350
new 1 138 350
copyLoc 1 139 351
assign 1 140 352
BRACESGet 0 140 352
typenameSet 1 140 353
assign 1 141 354
FALSEGet 0 141 354
assign 1 141 355
condCall 2 141 355
addValue 1 141 356
addValue 1 142 357
assign 1 144 360
FALSEGet 0 144 360
assign 1 144 361
condCall 2 144 361
addValue 1 144 362
beforeInsert 1 148 364
containedSet 1 149 365
assign 1 150 366
VARGet 0 150 366
typenameSet 1 150 367
heldSet 1 151 368
syncAddVariable 0 152 369
assign 1 153 370
nextDescendGet 0 153 370
return 1 153 371
assign 1 156 373
nextDescendGet 0 156 373
return 1 156 374
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2036228013: return bem_condCall_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass10_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass10_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass10();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst = (BEC_3_5_5_6_BuildVisitPass10) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;
}
}
