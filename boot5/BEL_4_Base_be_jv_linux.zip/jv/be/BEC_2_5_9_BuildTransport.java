package be;
/* IO:File: source/build/Transport.be */
public final class BEC_2_5_9_BuildTransport extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65,0x3A};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_1, 38));
private static byte[] bels_2 = {0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x62,0x79};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 12));
private static byte[] bels_3 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_3, 10));
private static byte[] bels_4 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_4, 44));
private static byte[] bels_5 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_5, 10));
private static byte[] bels_6 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_7 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_8 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_11 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static BEC_2_5_9_BuildTransport bevs_inst;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(9, bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) throws Throwable {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
try  /* Line: 38 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 43 */ {
if (bevl_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 44 */
 else  /* Line: 43 */ {
break;
} /* Line: 43 */
} /* Line: 43 */
beva_visitor.bem_end_1(this);
} /* Line: 47 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_2_tmpany_phold = bevo_0;
bevt_2_tmpany_phold.bem_print_0();
bevl_node.bem_print_0();
bevl_nc = bevl_node.bem_containerGet_0();
while (true)
 /* Line: 53 */ {
if (bevl_nc == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_4_tmpany_phold = bevo_1;
bevt_4_tmpany_phold.bem_print_0();
bevl_nc.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
bevl_nc = bevl_nc.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 56 */
 else  /* Line: 53 */ {
break;
} /* Line: 53 */
} /* Line: 53 */
bevt_5_tmpany_phold = bevo_2;
bevt_5_tmpany_phold.bem_print_0();
bevl_e.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevt_6_tmpany_phold = bevo_3;
bevt_6_tmpany_phold.bem_print_0();
bevt_7_tmpany_phold = bevo_4;
bevt_7_tmpany_phold.bem_print_0();
bevl_e.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
} /* Line: 63 */
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 65 */
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_contain_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
bevt_7_tmpany_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpany_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 74 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 74 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_tmpany_phold.bevi_bool) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 78 */ {
bevt_12_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_tmpany_phold.bevi_int == bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevt_15_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_15_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 79 */
 else  /* Line: 79 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 79 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 83 */ {
if (bevl_wf == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_19_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_19_tmpany_phold.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_22_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 84 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_25_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_tmpany_phold.bevi_int == bevt_26_tmpany_phold.bevi_int) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 84 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 85 */
 else  /* Line: 83 */ {
break;
} /* Line: 83 */
} /* Line: 83 */
if (bevl_wf == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_29_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_tmpany_phold.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_32_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_6));
bevl_cnode.bem_heldSet_1(bevt_35_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 94 */
} /* Line: 87 */
bevt_37_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_tmpany_phold.bevi_int == bevt_38_tmpany_phold.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_41_tmpany_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_typenameGet_0();
bevt_42_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_tmpany_phold.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
 else  /* Line: 97 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevt_44_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_44_tmpany_phold.bevi_int == bevt_45_tmpany_phold.bevi_int) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
 else  /* Line: 97 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevl_mnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_7));
bevl_mnode.bem_heldSet_1(bevt_47_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 103 */
bevt_49_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_tmpany_phold.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_52_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_tmpany_phold.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
 else  /* Line: 106 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 106 */ {
bevl_mnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_8));
bevl_mnode.bem_heldSet_1(bevt_55_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 112 */
bevt_57_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_tmpany_phold.bevi_int == bevt_58_tmpany_phold.bevi_int) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 116 */
 else  /* Line: 115 */ {
bevt_60_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_tmpany_phold.bevi_int == bevt_61_tmpany_phold.bevi_int) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 118 */
 else  /* Line: 115 */ {
bevt_63_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_tmpany_phold.bevi_int == bevt_64_tmpany_phold.bevi_int) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(32, bels_9));
bevt_66_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_66_tmpany_phold);
} /* Line: 122 */
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_70_tmpany_phold = (new BEC_2_4_6_TextString(32, bels_10));
bevt_69_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_69_tmpany_phold);
} /* Line: 126 */
} /* Line: 125 */
 else  /* Line: 128 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 129 */
} /* Line: 115 */
} /* Line: 115 */
bevt_72_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpany_phold = bevl_conTypes.bem_has_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevl_curr = bevl_node;
} /* Line: 132 */
} /* Line: 131 */
} /* Line: 78 */
 else  /* Line: 74 */ {
break;
} /* Line: 74 */
} /* Line: 74 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) throws Throwable {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 140 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(32, bels_11));
bevt_1_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpany_phold, beva_curr);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 141 */
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 21, 21, 22, 23, 25, 25, 26, 26, 30, 31, 31, 32, 33, 39, 41, 43, 43, 44, 47, 49, 49, 50, 50, 51, 52, 53, 53, 54, 54, 55, 56, 58, 58, 59, 61, 61, 62, 62, 63, 65, 70, 70, 71, 72, 73, 74, 74, 77, 78, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 0, 0, 0, 82, 83, 83, 83, 83, 83, 83, 0, 83, 83, 83, 83, 0, 0, 0, 84, 84, 84, 84, 0, 0, 0, 0, 0, 85, 87, 87, 87, 87, 87, 87, 0, 87, 87, 87, 87, 0, 0, 0, 0, 0, 90, 91, 91, 92, 92, 93, 94, 97, 97, 97, 97, 97, 97, 97, 97, 97, 0, 0, 0, 97, 97, 97, 97, 0, 0, 0, 99, 100, 100, 101, 101, 102, 103, 106, 106, 106, 106, 106, 106, 106, 106, 0, 0, 0, 108, 109, 109, 110, 110, 111, 112, 115, 115, 115, 115, 116, 117, 117, 117, 117, 118, 119, 119, 119, 119, 120, 121, 121, 122, 122, 122, 124, 125, 125, 126, 126, 126, 129, 131, 131, 132, 139, 140, 140, 141, 141, 141, 143, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {33, 34, 35, 36, 37, 38, 39, 40, 41, 46, 47, 48, 49, 50, 66, 67, 70, 75, 76, 82, 86, 91, 92, 93, 94, 95, 98, 103, 104, 105, 106, 107, 113, 114, 115, 118, 119, 120, 121, 122, 124, 210, 211, 212, 213, 214, 215, 218, 220, 221, 222, 227, 228, 229, 230, 235, 236, 237, 238, 243, 244, 247, 251, 254, 257, 262, 263, 264, 265, 270, 271, 274, 275, 276, 281, 282, 285, 289, 292, 293, 294, 299, 300, 303, 307, 310, 314, 317, 323, 328, 329, 330, 331, 336, 337, 340, 341, 342, 347, 348, 351, 355, 358, 362, 365, 366, 367, 368, 369, 370, 371, 374, 375, 376, 381, 382, 383, 384, 385, 390, 391, 394, 398, 401, 402, 403, 408, 409, 412, 416, 419, 420, 421, 422, 423, 424, 425, 427, 428, 429, 434, 435, 436, 437, 442, 443, 446, 450, 453, 454, 455, 456, 457, 458, 459, 461, 462, 463, 468, 469, 472, 473, 474, 479, 480, 483, 484, 485, 490, 491, 492, 497, 498, 499, 500, 502, 503, 508, 509, 510, 511, 515, 519, 520, 522, 537, 538, 543, 544, 545, 546, 548, 551, 554, 558, 561, 565, 568, 572, 575};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 33
assign 1 21 34
constantsGet 0 21 34
assign 1 21 35
ntypesGet 0 21 35
assign 1 22 36
new 1 22 36
assign 1 23 37
assign 1 25 38
TRANSUNITGet 0 25 38
typenameSet 1 25 39
assign 1 26 40
new 0 26 40
heldSet 1 26 41
assign 1 30 46
assign 1 31 47
constantsGet 0 31 47
assign 1 31 48
ntypesGet 0 31 48
assign 1 32 49
assign 1 33 50
begin 1 39 66
assign 1 41 67
accept 1 41 67
assign 1 43 70
def 1 43 75
assign 1 44 76
accept 1 44 76
end 1 47 82
assign 1 49 86
def 1 49 91
assign 1 50 92
new 0 50 92
print 0 50 93
print 0 51 94
assign 1 52 95
containerGet 0 52 95
assign 1 53 98
def 1 53 103
assign 1 54 104
new 0 54 104
print 0 54 105
print 0 55 106
assign 1 56 107
containerGet 0 56 107
assign 1 58 113
new 0 58 113
print 0 58 114
print 0 59 115
assign 1 61 118
new 0 61 118
print 0 61 119
assign 1 62 120
new 0 62 120
print 0 62 121
print 0 63 122
throw 1 65 124
assign 1 70 210
constantsGet 0 70 210
assign 1 70 211
conTypesGet 0 70 211
assign 1 71 212
assign 1 72 213
containedGet 0 72 213
containedSet 1 73 214
assign 1 74 215
linkedListIteratorGet 0 74 215
assign 1 74 218
hasNextGet 0 74 218
assign 1 77 220
nextGet 0 77 220
assign 1 78 221
delayDeleteGet 0 78 221
assign 1 78 222
not 0 78 227
assign 1 79 228
typenameGet 0 79 228
assign 1 79 229
TRANSUNITGet 0 79 229
assign 1 79 230
equals 1 79 235
assign 1 79 236
typenameGet 0 79 236
assign 1 79 237
IDGet 0 79 237
assign 1 79 238
equals 1 79 243
assign 1 0 244
assign 1 0 247
assign 1 0 251
assign 1 82 254
assign 1 83 257
def 1 83 262
assign 1 83 263
typenameGet 0 83 263
assign 1 83 264
IDGet 0 83 264
assign 1 83 265
equals 1 83 270
assign 1 0 271
assign 1 83 274
typenameGet 0 83 274
assign 1 83 275
COLONGet 0 83 275
assign 1 83 276
equals 1 83 281
assign 1 0 282
assign 1 0 285
assign 1 0 289
assign 1 84 292
typenameGet 0 84 292
assign 1 84 293
SPACEGet 0 84 293
assign 1 84 294
equals 1 84 299
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 85 317
nextPeerGet 0 85 317
assign 1 87 323
def 1 87 328
assign 1 87 329
typenameGet 0 87 329
assign 1 87 330
PARENSGet 0 87 330
assign 1 87 331
equals 1 87 336
assign 1 0 337
assign 1 87 340
typenameGet 0 87 340
assign 1 87 341
BRACESGet 0 87 341
assign 1 87 342
equals 1 87 347
assign 1 0 348
assign 1 0 351
assign 1 0 355
assign 1 0 358
assign 1 0 362
assign 1 90 365
new 1 90 365
assign 1 91 366
CLASSGet 0 91 366
typenameSet 1 91 367
assign 1 92 368
new 0 92 368
heldSet 1 92 369
addValue 1 93 370
assign 1 94 371
assign 1 97 374
typenameGet 0 97 374
assign 1 97 375
BRACESGet 0 97 375
assign 1 97 376
equals 1 97 381
assign 1 97 382
containerGet 0 97 382
assign 1 97 383
typenameGet 0 97 383
assign 1 97 384
CLASSGet 0 97 384
assign 1 97 385
equals 1 97 390
assign 1 0 391
assign 1 0 394
assign 1 0 398
assign 1 97 401
typenameGet 0 97 401
assign 1 97 402
IDGet 0 97 402
assign 1 97 403
equals 1 97 408
assign 1 0 409
assign 1 0 412
assign 1 0 416
assign 1 99 419
new 1 99 419
assign 1 100 420
METHODGet 0 100 420
typenameSet 1 100 421
assign 1 101 422
new 0 101 422
heldSet 1 101 423
addValue 1 102 424
assign 1 103 425
assign 1 106 427
typenameGet 0 106 427
assign 1 106 428
BRACESGet 0 106 428
assign 1 106 429
equals 1 106 434
assign 1 106 435
typenameGet 0 106 435
assign 1 106 436
BRACESGet 0 106 436
assign 1 106 437
equals 1 106 442
assign 1 0 443
assign 1 0 446
assign 1 0 450
assign 1 108 453
new 1 108 453
assign 1 109 454
PROPERTIESGet 0 109 454
typenameSet 1 109 455
assign 1 110 456
new 0 110 456
heldSet 1 110 457
addValue 1 111 458
assign 1 112 459
assign 1 115 461
typenameGet 0 115 461
assign 1 115 462
RPARENSGet 0 115 462
assign 1 115 463
equals 1 115 468
assign 1 116 469
stepBack 1 116 469
assign 1 117 472
typenameGet 0 117 472
assign 1 117 473
RIDXGet 0 117 473
assign 1 117 474
equals 1 117 479
assign 1 118 480
stepBack 1 118 480
assign 1 119 483
typenameGet 0 119 483
assign 1 119 484
RBRACESGet 0 119 484
assign 1 119 485
equals 1 119 490
assign 1 120 491
stepBack 1 120 491
assign 1 121 492
undef 1 121 497
assign 1 122 498
new 0 122 498
assign 1 122 499
new 2 122 499
throw 1 122 500
assign 1 124 502
stepBack 1 124 502
assign 1 125 503
undef 1 125 508
assign 1 126 509
new 0 126 509
assign 1 126 510
new 2 126 510
throw 1 126 511
addValue 1 129 515
assign 1 131 519
typenameGet 0 131 519
assign 1 131 520
has 1 131 520
assign 1 132 522
assign 1 139 537
containerGet 0 139 537
assign 1 140 538
undef 1 140 543
assign 1 141 544
new 0 141 544
assign 1 141 545
new 2 141 545
throw 1 141 546
return 1 143 548
return 1 0 551
assign 1 0 554
return 1 0 558
assign 1 0 561
return 1 0 565
assign 1 0 568
return 1 0 572
assign 1 0 575
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case -410956923: return bem_contain_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case -1380522583: return bem_outermostGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -2101994299: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1369440330: return bem_outermostSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 688372900: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildTransport();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildTransport.bevs_inst = (BEC_2_5_9_BuildTransport)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildTransport.bevs_inst;
}
}
