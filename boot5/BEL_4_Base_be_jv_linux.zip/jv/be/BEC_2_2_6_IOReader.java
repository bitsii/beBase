package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOReader extends BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOReader() { }

    public java.io.InputStream bevi_is;
   private static byte[] becc_clname = {0x49,0x4F,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_2_6_IOReader bevs_inst;
public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_3_MathInt bevp_blockSize;
public BEC_2_2_6_IOReader bem_new_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
bevp_blockSize = (new BEC_2_4_3_MathInt(256));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extOpen_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_close_0() throws Throwable {

      if (this.bevi_is != null) {
        this.bevi_is.close();
        this.bevi_is = null;
      }
      bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vfileGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) throws Throwable {
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_byteReaderGet_0() throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_2_10_IOByteReader()).bem_readerNew_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_byteReader_1(BEC_2_4_3_MathInt beva_blockSize) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_2_10_IOByteReader()).bem_readerBlockNew_2(this, beva_blockSize);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_1(BEC_2_4_6_TextString beva_readBuf) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_2_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_readIntoBuffer_2(beva_readBuf, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_2(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpvar_phold = this.bem_readIntoBuffer_3(beva_readBuf, beva_at, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_3(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at, BEC_2_4_3_MathInt beva_readsz) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;

      int bevls_read = this.bevi_is.read(beva_readBuf.bevi_bytes, beva_at.bevi_int, beva_readBuf.bevi_bytes.length - beva_at.bevi_int);
      if (bevls_read < 0) {
        bevls_read = 0;
      }
      beva_readsz.bevi_int = bevls_read + beva_at.bevi_int;
      bevt_0_tmpvar_phold = beva_readBuf.bem_sizeGet_0();
bevt_0_tmpvar_phold.bevi_int = beva_readsz.bevi_int;
return beva_readsz;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyData_3(BEC_2_2_6_IOWriter beva_outw, BEC_2_4_6_TextString beva_rwbufE, BEC_2_4_3_MathInt beva_rsz) throws Throwable {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevl_at = bevo_1;
while (true)
 /* Line: 269 */ {
bevt_1_tmpvar_phold = this.bem_readIntoBuffer_3(beva_rwbufE, bevl_at, beva_rsz);
bevt_2_tmpvar_phold = bevo_2;
if (bevt_1_tmpvar_phold.bevi_int > bevt_2_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 269 */ {
beva_outw.bem_write_1(beva_rwbufE);
} /* Line: 270 */
 else  /* Line: 269 */ {
break;
} /* Line: 269 */
} /* Line: 269 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyData_1(BEC_2_2_6_IOWriter beva_outw) throws Throwable {
BEC_2_4_6_TextString bevl_rwbufE = null;
BEC_2_4_3_MathInt bevl_rsz = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(4096));
bevl_rwbufE = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_rsz = (new BEC_2_4_3_MathInt());
this.bem_copyData_3(beva_outw, bevl_rwbufE, bevl_rsz);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevp_blockSize);
bevt_0_tmpvar_phold = this.bem_readBuffer_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_4_3_MathInt bevl_nowAt = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
bevl_at = (new BEC_2_4_3_MathInt(0));
bevl_nowAt = (new BEC_2_4_3_MathInt());
this.bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
while (true)
 /* Line: 288 */ {
if (bevl_nowAt.bevi_int > bevl_at.bevi_int) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 288 */ {
bevl_at.bevi_int = bevl_nowAt.bevi_int;
bevt_3_tmpvar_phold = beva_builder.bem_capacityGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_subtract_1(bevl_at);
bevt_4_tmpvar_phold = bevo_3;
if (bevt_2_tmpvar_phold.bevi_int < bevt_4_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_7_tmpvar_phold = bevl_at.bem_add_1(bevp_blockSize);
bevt_8_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_5;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_multiply_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_6;
bevl_nsize = bevt_5_tmpvar_phold.bem_divide_1(bevt_10_tmpvar_phold);
beva_builder.bem_capacitySet_1(bevl_nsize);
} /* Line: 292 */
this.bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
} /* Line: 294 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
return beva_builder;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferLine_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_readBufferLine_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferLine_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_6_TextString bevl_crb = null;
BEC_2_4_6_TextString bevl_rbuf = null;
BEC_2_4_3_MathInt bevl_got = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_newlineGet_0();
bevl_crb = bevt_0_tmpvar_phold.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevl_rbuf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_3_tmpvar_phold);
bevl_got = this.bem_readIntoBuffer_1(bevl_rbuf);
bevt_5_tmpvar_phold = bevo_7;
if (bevl_got.bevi_int == bevt_5_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 310 */ {
beva_builder = null;
return beva_builder;
} /* Line: 312 */
beva_builder.bem_addValue_1(bevl_rbuf);
while (true)
 /* Line: 315 */ {
bevt_7_tmpvar_phold = bevo_8;
if (bevl_got.bevi_int != bevt_7_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevt_8_tmpvar_phold = bevl_rbuf.bem_equals_1(bevl_crb);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 316 */ {
return beva_builder;
} /* Line: 317 */
bevl_got = this.bem_readIntoBuffer_1(bevl_rbuf);
beva_builder.bem_addValue_1(bevl_rbuf);
} /* Line: 320 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
return beva_builder;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_readBuffer_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_readBuffer_1(beva_builder);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readStringClose_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = this.bem_readString_0();
this.bem_close_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_blockSizeGet_0() throws Throwable {
return bevp_blockSize;
} /*method end*/
public BEC_2_6_6_SystemObject bem_blockSizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_blockSize = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {164, 165, 171, 207, 215, 215, 219, 219, 223, 223, 223, 223, 227, 227, 227, 263, 263, 264, 268, 269, 269, 269, 269, 270, 275, 275, 276, 277, 281, 281, 281, 285, 286, 287, 288, 288, 289, 290, 290, 290, 290, 290, 291, 291, 291, 291, 291, 291, 291, 292, 294, 296, 300, 300, 300, 307, 307, 307, 307, 308, 308, 309, 310, 310, 310, 311, 312, 314, 315, 315, 315, 316, 317, 319, 320, 322, 326, 326, 330, 330, 334, 335, 336, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 28, 37, 48, 49, 53, 54, 60, 61, 62, 63, 68, 69, 70, 80, 81, 82, 89, 92, 93, 94, 99, 100, 112, 113, 114, 115, 121, 122, 123, 140, 141, 142, 145, 150, 151, 152, 153, 154, 155, 160, 161, 162, 163, 164, 165, 166, 167, 168, 170, 176, 181, 182, 183, 198, 199, 200, 201, 202, 203, 204, 205, 206, 211, 212, 213, 215, 218, 219, 224, 225, 227, 229, 230, 236, 240, 241, 245, 246, 250, 251, 252, 255, 258, 262, 265};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 164 23
new 0 164 23
assign 1 165 24
new 0 165 24
assign 1 171 28
new 0 171 28
assign 1 207 37
new 0 207 37
assign 1 215 48
readerNew 1 215 48
return 1 215 49
assign 1 219 53
readerBlockNew 2 219 53
return 1 219 54
assign 1 223 60
new 0 223 60
assign 1 223 61
once 0 223 61
assign 1 223 62
readIntoBuffer 2 223 62
return 1 223 63
assign 1 227 68
new 0 227 68
assign 1 227 69
readIntoBuffer 3 227 69
return 1 227 70
assign 1 263 80
sizeGet 0 263 80
setValue 1 263 81
return 1 264 82
assign 1 268 89
new 0 268 89
assign 1 269 92
readIntoBuffer 3 269 92
assign 1 269 93
new 0 269 93
assign 1 269 94
greater 1 269 99
write 1 270 100
assign 1 275 112
new 0 275 112
assign 1 275 113
new 1 275 113
assign 1 276 114
new 0 276 114
copyData 3 277 115
assign 1 281 121
new 1 281 121
assign 1 281 122
readBuffer 1 281 122
return 1 281 123
assign 1 285 140
new 0 285 140
assign 1 286 141
new 0 286 141
readIntoBuffer 3 287 142
assign 1 288 145
greater 1 288 150
setValue 1 289 151
assign 1 290 152
capacityGet 0 290 152
assign 1 290 153
subtract 1 290 153
assign 1 290 154
new 0 290 154
assign 1 290 155
lesser 1 290 160
assign 1 291 161
add 1 291 161
assign 1 291 162
new 0 291 162
assign 1 291 163
add 1 291 163
assign 1 291 164
new 0 291 164
assign 1 291 165
multiply 1 291 165
assign 1 291 166
new 0 291 166
assign 1 291 167
divide 1 291 167
capacitySet 1 292 168
readIntoBuffer 3 294 170
return 1 296 176
assign 1 300 181
new 0 300 181
assign 1 300 182
readBufferLine 1 300 182
return 1 300 183
assign 1 307 198
new 0 307 198
assign 1 307 199
new 0 307 199
assign 1 307 200
newlineGet 0 307 200
assign 1 307 201
addValue 1 307 201
assign 1 308 202
new 0 308 202
assign 1 308 203
new 1 308 203
assign 1 309 204
readIntoBuffer 1 309 204
assign 1 310 205
new 0 310 205
assign 1 310 206
equals 1 310 211
assign 1 311 212
return 1 312 213
addValue 1 314 215
assign 1 315 218
new 0 315 218
assign 1 315 219
notEquals 1 315 224
assign 1 316 225
equals 1 316 225
return 1 317 227
assign 1 319 229
readIntoBuffer 1 319 229
addValue 1 320 230
return 1 322 236
assign 1 326 240
readBuffer 0 326 240
return 1 326 241
assign 1 330 245
readBuffer 1 330 245
return 1 330 246
assign 1 334 250
readString 0 334 250
close 0 335 251
return 1 336 252
return 1 0 255
assign 1 0 258
return 1 0 262
assign 1 0 265
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case -1109612452: return bem_byteReaderGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 1325881255: return bem_readBuffer_0();
case -1358082055: return bem_blockSizeGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 1242327477: return bem_vfileGet_0();
case 287040793: return bem_hashGet_0();
case 698342331: return bem_readBufferLine_0();
case 1774940957: return bem_toString_0();
case -1714939806: return bem_readStringClose_0();
case -729571811: return bem_serializeToString_0();
case -1240964868: return bem_extOpen_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 866536361: return bem_close_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 347960120: return bem_readString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -792269839: return bem_isClosedGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1253409730: return bem_vfileSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1359009615: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1346999802: return bem_blockSizeSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1992292136: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -781187586: return bem_isClosedSet_1(bevd_0);
case 1325881256: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 698342332: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1385004253: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 347960121: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1992292137: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 1992292138: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1359009613: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_6_IOReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_6_IOReader.bevs_inst = (BEC_2_2_6_IOReader)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_6_IOReader.bevs_inst;
}
}
