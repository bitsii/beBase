package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_4_BuildCall extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildCall() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 7));
private static byte[] bels_1 = {0x20,0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_1, 10));
private static byte[] bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_2, 10));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x42,0x6F,0x75,0x6E,0x64};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_3, 9));
private static byte[] bels_4 = {0x20,0x77,0x61,0x73,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_4, 12));
private static byte[] bels_5 = {0x47,0x45,0x54};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_5, 3));
private static byte[] bels_6 = {0x47,0x65,0x74};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_6, 3));
private static byte[] bels_7 = {0x53,0x65,0x74};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_7, 3));
public static BEC_2_5_4_BuildCall bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_6_TextString bevp_accessorType;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_literalValue;
public BEC_2_5_8_BuildNamePath bevp_newNp;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_2_5_4_LogicBool bevp_isConstruct;
public BEC_2_5_4_LogicBool bevp_bound;
public BEC_2_5_4_LogicBool bevp_wasBound;
public BEC_2_5_4_LogicBool bevp_wasAccessor;
public BEC_2_5_4_LogicBool bevp_wasOper;
public BEC_2_5_4_LogicBool bevp_isLiteral;
public BEC_2_5_4_LogicBool bevp_isOnce;
public BEC_2_5_4_LogicBool bevp_isMany;
public BEC_2_5_4_LogicBool bevp_checkTypes;
public BEC_2_5_4_LogicBool bevp_superCall;
public BEC_2_5_4_LogicBool bevp_wasImpliedConstruct;
public BEC_2_5_4_LogicBool bevp_wasForeachGenned;
public BEC_2_5_4_LogicBool bevp_untyped;
public BEC_2_9_4_ContainerList bevp_argCasts;
public BEC_2_5_4_BuildCall bem_new_0() throws Throwable {
bevp_isConstruct = be.BECS_Runtime.boolFalse;
bevp_bound = be.BECS_Runtime.boolTrue;
bevp_wasBound = be.BECS_Runtime.boolTrue;
bevp_wasAccessor = be.BECS_Runtime.boolFalse;
bevp_wasOper = be.BECS_Runtime.boolFalse;
bevp_isLiteral = be.BECS_Runtime.boolFalse;
bevp_isOnce = be.BECS_Runtime.boolFalse;
bevp_isMany = be.BECS_Runtime.boolFalse;
bevp_checkTypes = be.BECS_Runtime.boolTrue;
bevp_superCall = be.BECS_Runtime.boolFalse;
bevp_wasImpliedConstruct = be.BECS_Runtime.boolFalse;
bevp_wasForeachGenned = be.BECS_Runtime.boolFalse;
bevp_untyped = be.BECS_Runtime.boolFalse;
bevp_argCasts = (new BEC_2_9_4_ContainerList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevl_ret = this.bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_2_tmpany_phold = bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 323 */
if (bevp_orgName == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_6_tmpany_phold = bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_orgName.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 326 */
if (bevp_numargs == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_10_tmpany_phold = bevo_2;
bevt_9_tmpany_phold = bevl_ret.bem_add_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
} /* Line: 329 */
if (bevp_bound.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_13_tmpany_phold = bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_13_tmpany_phold);
} /* Line: 332 */
if (bevp_wasAccessor.bevi_bool) /* Line: 334 */ {
bevt_14_tmpany_phold = bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_14_tmpany_phold);
} /* Line: 335 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildCall bem_toAccessorName_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_5;
bevt_0_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_2_tmpany_phold = bevo_6;
bevp_name = bevp_name.bem_add_1(bevt_2_tmpany_phold);
} /* Line: 342 */
 else  /* Line: 343 */ {
bevt_3_tmpany_phold = bevo_7;
bevp_name = bevp_name.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 344 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGet_0() throws Throwable {
return bevp_accessorType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGet_0() throws Throwable {
return bevp_literalValue;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGet_0() throws Throwable {
return bevp_newNp;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGet_0() throws Throwable {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGet_0() throws Throwable {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGet_0() throws Throwable {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGet_0() throws Throwable {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGet_0() throws Throwable {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGet_0() throws Throwable {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOnceGet_0() throws Throwable {
return bevp_isOnce;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isOnceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isManyGet_0() throws Throwable {
return bevp_isMany;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isManySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGet_0() throws Throwable {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGet_0() throws Throwable {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGet_0() throws Throwable {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGet_0() throws Throwable {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGet_0() throws Throwable {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGet_0() throws Throwable {
return bevp_argCasts;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 314, 321, 322, 322, 323, 323, 323, 323, 325, 325, 326, 326, 326, 326, 328, 328, 329, 329, 329, 329, 331, 331, 332, 332, 335, 335, 337, 341, 341, 342, 342, 344, 344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 79, 80, 85, 86, 87, 88, 89, 91, 96, 97, 98, 99, 100, 102, 107, 108, 109, 110, 111, 113, 118, 119, 120, 123, 124, 126, 133, 134, 136, 137, 140, 141, 146, 149, 153, 156, 160, 163, 167, 170, 174, 177, 181, 184, 188, 191, 195, 198, 202, 205, 209, 212, 216, 219, 223, 226, 230, 233, 237, 240, 244, 247, 251, 254, 258, 261, 265, 268, 272, 275, 279, 282, 286, 289};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 300 46
new 0 300 46
assign 1 301 47
new 0 301 47
assign 1 302 48
new 0 302 48
assign 1 303 49
new 0 303 49
assign 1 304 50
new 0 304 50
assign 1 305 51
new 0 305 51
assign 1 306 52
new 0 306 52
assign 1 307 53
new 0 307 53
assign 1 308 54
new 0 308 54
assign 1 309 55
new 0 309 55
assign 1 310 56
new 0 310 56
assign 1 311 57
new 0 311 57
assign 1 312 58
new 0 312 58
assign 1 314 59
new 0 314 59
assign 1 321 79
classNameGet 0 321 79
assign 1 322 80
def 1 322 85
assign 1 323 86
new 0 323 86
assign 1 323 87
add 1 323 87
assign 1 323 88
toString 0 323 88
assign 1 323 89
add 1 323 89
assign 1 325 91
def 1 325 96
assign 1 326 97
new 0 326 97
assign 1 326 98
add 1 326 98
assign 1 326 99
toString 0 326 99
assign 1 326 100
add 1 326 100
assign 1 328 102
def 1 328 107
assign 1 329 108
new 0 329 108
assign 1 329 109
add 1 329 109
assign 1 329 110
toString 0 329 110
assign 1 329 111
add 1 329 111
assign 1 331 113
not 0 331 118
assign 1 332 119
new 0 332 119
assign 1 332 120
add 1 332 120
assign 1 335 123
new 0 335 123
assign 1 335 124
add 1 335 124
return 1 337 126
assign 1 341 133
new 0 341 133
assign 1 341 134
equals 1 341 134
assign 1 342 136
new 0 342 136
assign 1 342 137
add 1 342 137
assign 1 344 140
new 0 344 140
assign 1 344 141
add 1 344 141
return 1 0 146
assign 1 0 149
return 1 0 153
assign 1 0 156
return 1 0 160
assign 1 0 163
return 1 0 167
assign 1 0 170
return 1 0 174
assign 1 0 177
return 1 0 181
assign 1 0 184
return 1 0 188
assign 1 0 191
return 1 0 195
assign 1 0 198
return 1 0 202
assign 1 0 205
return 1 0 209
assign 1 0 212
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
return 1 0 237
assign 1 0 240
return 1 0 244
assign 1 0 247
return 1 0 251
assign 1 0 254
return 1 0 258
assign 1 0 261
return 1 0 265
assign 1 0 268
return 1 0 272
assign 1 0 275
return 1 0 279
assign 1 0 282
return 1 0 286
assign 1 0 289
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1796577138: return bem_superCallGet_0();
case -548714012: return bem_numargsGet_0();
case 783669222: return bem_accessorTypeGet_0();
case -682709225: return bem_wasAccessorGet_0();
case 202317754: return bem_isConstructGet_0();
case 1362267230: return bem_isManyGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 287040793: return bem_hashGet_0();
case 1018900425: return bem_argCastsGet_0();
case 104713553: return bem_new_0();
case -1806609680: return bem_wasOperGet_0();
case -314718434: return bem_print_0();
case 1087506597: return bem_literalValueGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case 1774940957: return bem_toString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 650919759: return bem_wasImpliedConstructGet_0();
case -2128364298: return bem_cposGet_0();
case 1143663254: return bem_untypedGet_0();
case 1102720804: return bem_classNameGet_0();
case 655314870: return bem_checkTypesGet_0();
case -1319292247: return bem_boundGet_0();
case -845792839: return bem_iteratorGet_0();
case 1478834556: return bem_isOnceGet_0();
case 1820417453: return bem_create_0();
case 1211273660: return bem_nameGet_0();
case -735901070: return bem_wasBoundGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 2055025483: return bem_serializeContents_0();
case -173192194: return bem_toAccessorName_0();
case -1308786538: return bem_echo_0();
case -1583922395: return bem_newNpGet_0();
case 1569395810: return bem_isLiteralGet_0();
case -1354714650: return bem_copy_0();
case 443668840: return bem_methodNotDefined_0();
case -1391492296: return bem_orgNameGet_0();
case 654935401: return bem_wasForeachGennedGet_0();
case -729571811: return bem_serializeToString_0();
case -1012494862: return bem_once_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 662002012: return bem_wasImpliedConstructSet_1(bevd_0);
case -1795527427: return bem_wasOperSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 213400007: return bem_isConstructSet_1(bevd_0);
case 1373349483: return bem_isManySet_1(bevd_0);
case 1489916809: return bem_isOnceSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1029982678: return bem_argCastsSet_1(bevd_0);
case 794751475: return bem_accessorTypeSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1098588850: return bem_literalValueSet_1(bevd_0);
case 1580478063: return bem_isLiteralSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case -1380410043: return bem_orgNameSet_1(bevd_0);
case 666017654: return bem_wasForeachGennedSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -671626972: return bem_wasAccessorSet_1(bevd_0);
case 666397123: return bem_checkTypesSet_1(bevd_0);
case -537631759: return bem_numargsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1785494885: return bem_superCallSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1572840142: return bem_newNpSet_1(bevd_0);
case 1154745507: return bem_untypedSet_1(bevd_0);
case -724818817: return bem_wasBoundSet_1(bevd_0);
case -2117282045: return bem_cposSet_1(bevd_0);
case -1308209994: return bem_boundSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildCall();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildCall.bevs_inst = (BEC_2_5_4_BuildCall)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildCall.bevs_inst;
}
}
