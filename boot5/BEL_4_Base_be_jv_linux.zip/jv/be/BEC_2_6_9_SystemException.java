package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_11, 2));
private static byte[] bels_12 = {0x0D,0x0A};
private static byte[] bels_13 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x46,0x72,0x61,0x6D,0x65,0x20,0x6C,0x69,0x6E,0x65,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_14, 14));
private static byte[] bels_15 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_15, 3));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_16 = {0x73,0x74,0x61,0x72,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_16, 9));
private static byte[] bels_17 = {0x20};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_17, 1));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_18 = {0x65,0x6E,0x64,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_18, 7));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_19 = {0x69,0x6E};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_19, 2));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_20 = {0x20};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_20, 1));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_21 = {0x3A};
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_22 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_22, 5));
private static byte[] bels_23 = {0x28};
private static BEC_2_4_6_TextString bevo_19 = (new BEC_2_4_6_TextString(bels_23, 1));
private static byte[] bels_24 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bevo_20 = (new BEC_2_4_6_TextString(bels_24, 15));
private static byte[] bels_25 = {0x29};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_25, 1));
private static BEC_2_4_3_MathInt bevo_22 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_26 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x65,0x6E,0x64,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bels_26, 13));
private static BEC_2_4_3_MathInt bevo_24 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_27 = {0x3A};
private static BEC_2_4_3_MathInt bevo_25 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_28 = {0x3A};
private static BEC_2_4_3_MathInt bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_27 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_29 = {0x28};
private static BEC_2_4_6_TextString bevo_28 = (new BEC_2_4_6_TextString(bels_29, 1));
private static BEC_2_4_3_MathInt bevo_29 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_30 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_31 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_30 = {0x2E};
private static byte[] bels_31 = {0x63,0x61,0x6C,0x6C,0x50,0x61,0x72,0x74,0x20,0x7C};
private static BEC_2_4_6_TextString bevo_32 = (new BEC_2_4_6_TextString(bels_31, 10));
private static byte[] bels_32 = {0x7C};
private static BEC_2_4_6_TextString bevo_33 = (new BEC_2_4_6_TextString(bels_32, 1));
private static byte[] bels_33 = {0x2E};
private static BEC_2_4_3_MathInt bevo_34 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_35 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_34 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6D,0x74,0x64,0x20,0x7C};
private static BEC_2_4_6_TextString bevo_36 = (new BEC_2_4_6_TextString(bels_34, 15));
private static byte[] bels_35 = {0x7C};
private static BEC_2_4_6_TextString bevo_37 = (new BEC_2_4_6_TextString(bels_35, 1));
private static byte[] bels_36 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_38 = (new BEC_2_4_6_TextString(bels_36, 4));
private static BEC_2_4_3_MathInt bevo_39 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_37 = {0x5F};
private static BEC_2_4_6_TextString bevo_40 = (new BEC_2_4_6_TextString(bels_37, 1));
private static BEC_2_4_3_MathInt bevo_41 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_42 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_38 = {0x70,0x72,0x65,0x20,0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bevo_43 = (new BEC_2_4_6_TextString(bels_38, 21));
private static byte[] bels_39 = {0x7C};
private static BEC_2_4_6_TextString bevo_44 = (new BEC_2_4_6_TextString(bels_39, 1));
private static byte[] bels_40 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bevo_45 = (new BEC_2_4_6_TextString(bels_40, 17));
private static byte[] bels_41 = {0x7C};
private static BEC_2_4_6_TextString bevo_46 = (new BEC_2_4_6_TextString(bels_41, 1));
private static byte[] bels_42 = {0x61,0x64,0x64,0x69,0x6E,0x67,0x20,0x66,0x72,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bevo_47 = (new BEC_2_4_6_TextString(bels_42, 12));
private static byte[] bels_43 = {0x6E,0x6F,0x20,0x65,0x6E,0x64};
private static BEC_2_4_6_TextString bevo_48 = (new BEC_2_4_6_TextString(bels_43, 6));
private static byte[] bels_44 = {0x62,0x65};
private static byte[] bels_45 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_49 = (new BEC_2_4_6_TextString(bels_45, 2));
private static byte[] bels_46 = {0x62,0x65};
private static byte[] bels_47 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bevo_50 = (new BEC_2_4_6_TextString(bels_47, 16));
private static byte[] bels_48 = {0x2E};
private static byte[] bels_49 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_51 = (new BEC_2_4_6_TextString(bels_49, 4));
private static byte[] bels_50 = {0x5F};
private static BEC_2_4_3_MathInt bevo_52 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_53 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_51 = {0x3A};
private static byte[] bels_52 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_54 = (new BEC_2_4_6_TextString(bels_52, 4));
private static byte[] bels_53 = {0x5F};
private static BEC_2_4_3_MathInt bevo_55 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_56 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_54 = {0x5F};
private static byte[] bels_55 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bevo_57 = (new BEC_2_4_6_TextString(bels_55, 16));
private static byte[] bels_56 = {0x0A};
private static BEC_2_4_6_TextString bevo_58 = (new BEC_2_4_6_TextString(bels_56, 1));
public static BEC_2_6_9_SystemException bevs_inst;
public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_vv = be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bels_0));
if (bevp_lang == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(7, bels_1));
bevt_1_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpany_phold);
bevl_toRet = bevt_1_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_lang);
} /* Line: 38 */
if (bevp_emitLang == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_2));
bevt_4_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpany_phold);
bevl_toRet = bevt_4_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_emitLang);
} /* Line: 41 */
if (bevp_methodName == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bels_3));
bevt_7_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpany_phold);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_methodName);
} /* Line: 44 */
if (bevp_klassName == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(8, bels_4));
bevt_10_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpany_phold);
bevl_toRet = bevt_10_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_klassName);
} /* Line: 47 */
if (bevp_description == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(14, bels_5));
bevt_13_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpany_phold);
bevl_toRet = bevt_13_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_description);
} /* Line: 50 */
if (bevp_fileName == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_6));
bevt_16_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_17_tmpany_phold);
bevl_toRet = bevt_16_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_fileName);
} /* Line: 53 */
if (bevp_lineNumber == null) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bels_7));
bevt_19_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_20_tmpany_phold);
bevt_21_tmpany_phold = bevp_lineNumber.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_19_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpany_phold);
} /* Line: 56 */
if (bevp_framesText == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(14, bels_8));
bevt_23_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpany_phold);
bevl_toRet = bevt_23_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_framesText);
} /* Line: 59 */
if (bevp_frames == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_26_tmpany_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpany_phold);
} /* Line: 62 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_9_SystemException bem_translateEmittedException_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 68 */ {
this.bem_translateEmittedExceptionInner_0();
} /* Line: 69 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpany_phold = bevo_0;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 71 */
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_translateEmittedExceptionInner_0() throws Throwable {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpany_phold = null;
BEC_2_4_6_TextString bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_6_TextString bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_6_TextString bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_134_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_4_6_TextString bevt_142_tmpany_phold = null;
BEC_2_4_6_TextString bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_4_6_TextString bevt_145_tmpany_phold = null;
if (bevp_translated == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 79 */ {
if (bevp_translated.bevi_bool) /* Line: 79 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 79 */
 else  /* Line: 79 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 79 */ {
return this;
} /* Line: 80 */
if (bevp_vv == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevp_vv = be.BECS_Runtime.boolFalse;
} /* Line: 83 */
bevp_translated = be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 86 */ {
if (bevp_lang == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 86 */ {
bevt_17_tmpany_phold = bevo_1;
bevt_16_tmpany_phold = bevp_lang.bem_equals_1(bevt_17_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_19_tmpany_phold = bevo_2;
bevt_18_tmpany_phold = bevp_lang.bem_equals_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 86 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 86 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_12));
bevl_ltok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_20_tmpany_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_22_tmpany_phold = bevo_3;
bevt_21_tmpany_phold = bevp_lang.bem_equals_1(bevt_22_tmpany_phold);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 89 */ {
bevl_isCs = be.BECS_Runtime.boolTrue;
} /* Line: 90 */
 else  /* Line: 91 */ {
bevl_isCs = be.BECS_Runtime.boolFalse;
} /* Line: 92 */
bevt_0_tmpany_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 94 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
if (bevp_vv.bevi_bool) /* Line: 95 */ {
bevt_25_tmpany_phold = bevo_4;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevl_line);
bevt_24_tmpany_phold.bem_print_0();
} /* Line: 96 */
bevt_26_tmpany_phold = bevo_5;
bevl_start = bevl_line.bem_find_1(bevt_26_tmpany_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 101 */ {
bevt_29_tmpany_phold = bevo_6;
if (bevl_start.bevi_int >= bevt_29_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 101 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 101 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 101 */
 else  /* Line: 101 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 101 */ {
if (bevp_vv.bevi_bool) /* Line: 102 */ {
bevt_31_tmpany_phold = bevo_7;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevl_start);
bevt_30_tmpany_phold.bem_print_0();
} /* Line: 103 */
bevt_32_tmpany_phold = bevo_8;
bevt_34_tmpany_phold = bevo_9;
bevt_33_tmpany_phold = bevl_start.bem_add_1(bevt_34_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
if (bevl_end == null) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 106 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
 else  /* Line: 106 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 106 */ {
if (bevp_vv.bevi_bool) /* Line: 107 */ {
bevt_38_tmpany_phold = bevo_10;
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevl_end);
bevt_37_tmpany_phold.bem_print_0();
} /* Line: 108 */
bevt_40_tmpany_phold = bevo_11;
bevt_39_tmpany_phold = bevl_start.bem_add_1(bevt_40_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_39_tmpany_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 112 */ {
bevt_41_tmpany_phold = bevo_12;
bevl_start = bevl_line.bem_find_2(bevt_41_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_44_tmpany_phold = bevo_13;
bevt_43_tmpany_phold = bevl_start.bem_add_1(bevt_44_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_43_tmpany_phold);
bevt_46_tmpany_phold = bevo_14;
bevt_45_tmpany_phold = bevl_inPart.bem_ends_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevt_48_tmpany_phold = bevl_inPart.bem_sizeGet_0();
bevt_49_tmpany_phold = bevo_15;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_subtract_1(bevt_49_tmpany_phold);
bevl_inPart.bem_sizeSet_1(bevt_47_tmpany_phold);
} /* Line: 118 */
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_21));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_50_tmpany_phold);
if (bevl_pdelim == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 122 */ {
bevt_52_tmpany_phold = bevo_16;
bevl_efile = bevl_inPart.bem_substring_2(bevt_52_tmpany_phold, bevl_pdelim);
bevt_54_tmpany_phold = bevo_17;
bevt_53_tmpany_phold = bevl_pdelim.bem_add_1(bevt_54_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_53_tmpany_phold);
bevt_56_tmpany_phold = bevo_18;
bevt_55_tmpany_phold = bevl_iv.bem_begins_1(bevt_56_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_57_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_57_tmpany_phold);
} /* Line: 127 */
bevt_58_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 131 */
} /* Line: 130 */
} /* Line: 122 */
} /* Line: 114 */
 else  /* Line: 135 */ {
bevt_59_tmpany_phold = bevo_19;
bevl_start = bevl_line.bem_find_2(bevt_59_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 137 */ {
if (bevp_vv.bevi_bool) /* Line: 138 */ {
bevt_61_tmpany_phold = bevo_20;
bevt_61_tmpany_phold.bem_print_0();
} /* Line: 139 */
bevt_62_tmpany_phold = bevo_21;
bevt_64_tmpany_phold = bevo_22;
bevt_63_tmpany_phold = bevl_start.bem_add_1(bevt_64_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
if (bevl_end == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 143 */ {
if (bevp_vv.bevi_bool) /* Line: 144 */ {
bevt_66_tmpany_phold = bevo_23;
bevt_66_tmpany_phold.bem_print_0();
} /* Line: 145 */
bevt_68_tmpany_phold = bevo_24;
bevt_67_tmpany_phold = bevl_start.bem_add_1(bevt_68_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_67_tmpany_phold, bevl_end);
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_27));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_69_tmpany_phold);
if (bevl_pdelim == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_71_tmpany_phold = bevo_25;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_71_tmpany_phold, bevl_pdelim);
bevt_72_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_28));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_72_tmpany_phold);
if (bevl_pdelim == null) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_74_tmpany_phold = bevo_26;
bevl_efile = bevl_inPart.bem_substring_2(bevt_74_tmpany_phold, bevl_pdelim);
} /* Line: 155 */
bevt_76_tmpany_phold = bevo_27;
bevt_75_tmpany_phold = bevl_pdelim.bem_add_1(bevt_76_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_77_tmpany_phold.bevi_bool) /* Line: 159 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 160 */
} /* Line: 159 */
} /* Line: 150 */
} /* Line: 143 */
} /* Line: 137 */
} /* Line: 112 */
 else  /* Line: 166 */ {
bevt_78_tmpany_phold = bevo_28;
bevt_80_tmpany_phold = bevo_29;
bevt_79_tmpany_phold = bevl_start.bem_add_1(bevt_80_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
if (bevl_end == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 168 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 168 */ {
bevt_84_tmpany_phold = bevo_30;
bevt_83_tmpany_phold = bevl_start.bem_add_1(bevt_84_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_83_tmpany_phold, bevl_end);
} /* Line: 169 */
 else  /* Line: 170 */ {
bevt_86_tmpany_phold = bevo_31;
bevt_85_tmpany_phold = bevl_start.bem_add_1(bevt_86_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_85_tmpany_phold);
} /* Line: 171 */
} /* Line: 168 */
if (bevl_callPart == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 174 */ {
if (bevl_isCs.bevi_bool) /* Line: 175 */ {
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_30));
bevl_parts = bevl_callPart.bem_split_1(bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_90_tmpany_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_92_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_91_tmpany_phold = this.bem_getSourceFileName_1(bevt_92_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_91_tmpany_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 188 */
 else  /* Line: 189 */ {
if (bevp_vv.bevi_bool) /* Line: 191 */ {
bevt_95_tmpany_phold = bevo_32;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevl_callPart);
bevt_96_tmpany_phold = bevo_33;
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bem_add_1(bevt_96_tmpany_phold);
bevt_93_tmpany_phold.bem_print_0();
} /* Line: 192 */
bevt_97_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_33));
bevl_parts = bevl_callPart.bem_split_1(bevt_97_tmpany_phold);
bevt_99_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_100_tmpany_phold = bevo_34;
if (bevt_99_tmpany_phold.bevi_int > bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_102_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_103_tmpany_phold = bevo_35;
if (bevt_102_tmpany_phold.bevi_int > bevt_103_tmpany_phold.bevi_int) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevt_104_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_105_tmpany_phold);
} /* Line: 198 */
 else  /* Line: 199 */ {
bevt_106_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_107_tmpany_phold);
} /* Line: 201 */
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
if (bevp_vv.bevi_bool) /* Line: 204 */ {
bevt_110_tmpany_phold = bevo_36;
bevt_109_tmpany_phold = bevt_110_tmpany_phold.bem_add_1(bevl_mtd);
bevt_111_tmpany_phold = bevo_37;
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bem_add_1(bevt_111_tmpany_phold);
bevt_108_tmpany_phold.bem_print_0();
} /* Line: 205 */
bevt_112_tmpany_phold = bevo_38;
bevl_start = bevl_klass.bem_find_1(bevt_112_tmpany_phold);
if (bevl_start == null) {
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_113_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevt_115_tmpany_phold = bevo_39;
if (bevl_start.bevi_int > bevt_115_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 208 */
 else  /* Line: 208 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 208 */ {
bevt_116_tmpany_phold = bevo_40;
bevt_118_tmpany_phold = bevo_41;
bevt_117_tmpany_phold = bevl_start.bem_add_1(bevt_118_tmpany_phold);
bevl_end = bevl_klass.bem_find_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
if (bevl_end == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 210 */ {
bevt_121_tmpany_phold = bevo_42;
if (bevl_end.bevi_int > bevt_121_tmpany_phold.bevi_int) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 210 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 210 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 210 */
 else  /* Line: 210 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 210 */ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
if (bevp_vv.bevi_bool) /* Line: 215 */ {
bevt_124_tmpany_phold = bevo_43;
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bem_add_1(bevl_klass);
bevt_125_tmpany_phold = bevo_44;
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bem_add_1(bevt_125_tmpany_phold);
bevt_122_tmpany_phold.bem_print_0();
} /* Line: 216 */
bevl_klass = this.bem_extractKlass_1(bevl_klass);
if (bevp_vv.bevi_bool) /* Line: 219 */ {
bevt_128_tmpany_phold = bevo_45;
bevt_127_tmpany_phold = bevt_128_tmpany_phold.bem_add_1(bevl_klass);
bevt_129_tmpany_phold = bevo_46;
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bem_add_1(bevt_129_tmpany_phold);
bevt_126_tmpany_phold.bem_print_0();
} /* Line: 220 */
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_131_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_130_tmpany_phold = this.bem_getSourceFileName_1(bevt_131_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_130_tmpany_phold);
if (bevp_vv.bevi_bool) /* Line: 224 */ {
bevt_132_tmpany_phold = bevo_47;
bevt_132_tmpany_phold.bem_print_0();
} /* Line: 225 */
this.bem_addFrame_1(bevl_fr);
} /* Line: 227 */
 else  /* Line: 228 */ {
if (bevp_vv.bevi_bool) /* Line: 229 */ {
bevt_133_tmpany_phold = bevo_48;
bevt_133_tmpany_phold.bem_print_0();
} /* Line: 230 */
} /* Line: 229 */
} /* Line: 210 */
} /* Line: 208 */
} /* Line: 195 */
} /* Line: 175 */
} /* Line: 174 */
} /* Line: 101 */
 else  /* Line: 94 */ {
break;
} /* Line: 94 */
} /* Line: 94 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bels_44));
bevp_framesText = null;
} /* Line: 241 */
 else  /* Line: 86 */ {
if (bevp_frames == null) {
bevt_134_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_134_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_134_tmpany_phold.bevi_bool) /* Line: 242 */ {
if (bevp_lang == null) {
bevt_135_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_137_tmpany_phold = bevo_49;
bevt_136_tmpany_phold = bevp_lang.bem_equals_1(bevt_137_tmpany_phold);
if (bevt_136_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_1_tmpany_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 243 */ {
bevt_138_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_138_tmpany_phold != null && bevt_138_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_138_tmpany_phold).bevi_bool) /* Line: 243 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpany_loop.bem_nextGet_0();
bevt_140_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_139_tmpany_phold = this.bem_extractKlassLib_1(bevt_140_tmpany_phold);
bevl_fr.bem_klassNameSet_1(bevt_139_tmpany_phold);
bevt_142_tmpany_phold = bevl_fr.bem_methodNameGet_0();
bevt_141_tmpany_phold = this.bem_extractMethod_1(bevt_142_tmpany_phold);
bevl_fr.bem_methodNameSet_1(bevt_141_tmpany_phold);
bevt_144_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_143_tmpany_phold = this.bem_getSourceFileName_1(bevt_144_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_143_tmpany_phold);
 /* Line: 247 */ {
bevl_fr.bem_extractLine_0();
} /* Line: 248 */
} /* Line: 247 */
 else  /* Line: 243 */ {
break;
} /* Line: 243 */
} /* Line: 243 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bels_46));
} /* Line: 252 */
 else  /* Line: 253 */ {
} /* Line: 253 */
} /* Line: 86 */
if (bevp_vv.bevi_bool) /* Line: 256 */ {
bevt_145_tmpany_phold = bevo_50;
bevt_145_tmpany_phold.bem_print_0();
} /* Line: 257 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_i = this.bem_createInstance_2(beva_klassName, bevt_0_tmpany_phold);
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(478622533, BEL_4_Base.bevn_sourceFileNameGet_0);
return (BEC_2_4_6_TextString) bevt_2_tmpany_phold;
} /* Line: 266 */
return null;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_48));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_2_tmpany_phold = bevl_parts.bem_get_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = this.bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpany_phold);
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 280 */ {
bevt_0_tmpany_phold = this.bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpany_phold;
} /* Line: 281 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 282 */
return beva_klass;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 289 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 289 */ {
bevt_4_tmpany_phold = bevo_51;
bevt_3_tmpany_phold = beva_klass.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 289 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 289 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 289 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 289 */ {
return beva_klass;
} /* Line: 290 */
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(6));
bevt_5_tmpany_phold = beva_klass.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_50));
bevl_kparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bevo_52;
bevl_kps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 297 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_11_tmpany_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpany_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpany_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_16_tmpany_phold = bevo_53;
bevt_15_tmpany_phold = bevl_i.bem_add_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_51));
bevl_bec.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 301 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 297 */
 else  /* Line: 297 */ {
break;
} /* Line: 297 */
} /* Line: 297 */
return bevl_bec;
} /*method end*/
public BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
if (beva_mtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_4_tmpany_phold = bevo_54;
bevt_3_tmpany_phold = beva_mtd.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 309 */ {
return beva_mtd;
} /* Line: 310 */
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(4));
bevt_5_tmpany_phold = beva_mtd.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_53));
bevl_mparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bevo_55;
bevl_mps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_bem = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 315 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevt_11_tmpany_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = bevo_56;
bevt_13_tmpany_phold = bevl_i.bem_add_1(bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 317 */ {
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_54));
bevl_bem.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 317 */
bevl_i.bevi_int++;
} /* Line: 315 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
return bevl_bem;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
this.bem_translateEmittedException_0();
if (bevp_vv.bevi_bool) /* Line: 327 */ {
bevt_0_tmpany_phold = bevo_57;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 328 */
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = this.bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 338 */ {
bevt_2_tmpany_phold = bevo_58;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 340 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 340 */ {
bevl_ft = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 341 */
 else  /* Line: 340 */ {
break;
} /* Line: 340 */
} /* Line: 340 */
} /* Line: 340 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_frames == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 352 */ {
bevp_frames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 353 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
this.bem_addFrame_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGet_0() throws Throwable {
return bevp_vv;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 29, 33, 36, 37, 37, 38, 38, 38, 40, 40, 41, 41, 41, 43, 43, 44, 44, 44, 46, 46, 47, 47, 47, 49, 49, 50, 50, 50, 52, 52, 53, 53, 53, 55, 55, 56, 56, 56, 56, 58, 58, 59, 59, 59, 61, 61, 62, 62, 64, 69, 71, 71, 79, 79, 0, 0, 0, 80, 82, 82, 83, 85, 86, 86, 86, 86, 0, 0, 0, 86, 86, 0, 86, 86, 0, 0, 0, 0, 0, 87, 87, 88, 89, 89, 90, 92, 94, 0, 94, 94, 96, 96, 96, 98, 98, 99, 100, 101, 101, 101, 101, 101, 0, 0, 0, 103, 103, 103, 105, 105, 105, 105, 106, 106, 106, 106, 0, 0, 0, 108, 108, 108, 110, 110, 110, 113, 113, 114, 114, 116, 116, 116, 117, 117, 118, 118, 118, 118, 121, 121, 122, 122, 123, 123, 125, 125, 125, 126, 126, 127, 127, 130, 131, 136, 136, 137, 137, 139, 139, 142, 142, 142, 142, 143, 143, 145, 145, 147, 147, 147, 149, 149, 150, 150, 151, 151, 153, 153, 154, 154, 155, 155, 157, 157, 157, 159, 160, 167, 167, 167, 167, 168, 168, 168, 168, 0, 0, 0, 169, 169, 169, 171, 171, 171, 174, 174, 177, 177, 179, 179, 180, 180, 182, 184, 186, 187, 187, 187, 188, 192, 192, 192, 192, 192, 194, 194, 195, 195, 195, 195, 196, 196, 196, 196, 197, 197, 198, 198, 200, 200, 201, 201, 203, 205, 205, 205, 205, 205, 207, 207, 208, 208, 208, 208, 208, 0, 0, 0, 209, 209, 209, 209, 210, 210, 210, 210, 210, 0, 0, 0, 214, 216, 216, 216, 216, 216, 218, 220, 220, 220, 220, 220, 222, 223, 223, 223, 225, 225, 227, 230, 230, 239, 240, 241, 242, 242, 242, 242, 0, 0, 0, 242, 242, 0, 0, 0, 243, 0, 243, 243, 244, 244, 244, 245, 245, 245, 246, 246, 246, 248, 251, 252, 257, 257, 263, 263, 264, 264, 266, 266, 269, 274, 274, 276, 276, 276, 276, 281, 281, 285, 289, 289, 0, 289, 289, 289, 289, 0, 0, 290, 292, 292, 292, 292, 293, 293, 293, 294, 295, 296, 297, 297, 297, 298, 298, 300, 300, 300, 301, 301, 301, 301, 301, 301, 302, 297, 305, 309, 309, 0, 309, 309, 309, 309, 0, 0, 310, 312, 312, 312, 312, 313, 313, 313, 314, 315, 315, 315, 316, 316, 317, 317, 317, 317, 317, 317, 315, 320, 326, 328, 328, 331, 335, 336, 337, 338, 338, 339, 339, 340, 0, 340, 340, 341, 344, 348, 352, 352, 353, 355, 359, 359, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {136, 137, 169, 170, 171, 176, 177, 178, 179, 181, 186, 187, 188, 189, 191, 196, 197, 198, 199, 201, 206, 207, 208, 209, 211, 216, 217, 218, 219, 221, 226, 227, 228, 229, 231, 236, 237, 238, 239, 240, 242, 247, 248, 249, 250, 252, 257, 258, 259, 261, 267, 271, 272, 439, 444, 446, 449, 453, 456, 458, 463, 464, 466, 467, 472, 473, 478, 479, 482, 486, 489, 490, 492, 495, 496, 498, 501, 505, 508, 512, 515, 516, 517, 518, 519, 521, 524, 526, 526, 529, 531, 533, 534, 535, 537, 538, 539, 540, 541, 546, 547, 548, 553, 554, 557, 561, 565, 566, 567, 569, 570, 571, 572, 573, 578, 579, 584, 585, 588, 592, 596, 597, 598, 600, 601, 602, 604, 605, 606, 611, 612, 613, 614, 615, 616, 618, 619, 620, 621, 623, 624, 625, 630, 631, 632, 633, 634, 635, 636, 637, 639, 640, 642, 644, 650, 651, 652, 657, 659, 660, 662, 663, 664, 665, 666, 671, 673, 674, 676, 677, 678, 679, 680, 681, 686, 687, 688, 689, 690, 691, 696, 697, 698, 700, 701, 702, 703, 705, 713, 714, 715, 716, 717, 722, 723, 728, 729, 732, 736, 739, 740, 741, 744, 745, 746, 749, 754, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 772, 773, 774, 775, 776, 778, 779, 780, 781, 782, 787, 788, 789, 790, 795, 796, 797, 798, 799, 802, 803, 804, 805, 807, 809, 810, 811, 812, 813, 815, 816, 817, 822, 823, 824, 829, 830, 833, 837, 840, 841, 842, 843, 844, 849, 850, 851, 856, 857, 860, 864, 867, 869, 870, 871, 872, 873, 875, 877, 878, 879, 880, 881, 883, 884, 885, 886, 888, 889, 891, 895, 896, 909, 910, 911, 914, 919, 920, 925, 926, 929, 933, 936, 937, 939, 942, 946, 949, 949, 952, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 965, 972, 973, 979, 980, 989, 990, 991, 996, 997, 998, 1000, 1008, 1009, 1010, 1011, 1012, 1013, 1019, 1020, 1025, 1053, 1058, 1059, 1062, 1063, 1064, 1069, 1070, 1073, 1077, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1092, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1110, 1111, 1112, 1114, 1115, 1121, 1144, 1149, 1150, 1153, 1154, 1155, 1160, 1161, 1164, 1168, 1170, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1178, 1181, 1186, 1187, 1188, 1189, 1190, 1191, 1196, 1197, 1198, 1200, 1206, 1210, 1212, 1213, 1215, 1225, 1226, 1227, 1228, 1233, 1234, 1235, 1236, 1236, 1239, 1241, 1242, 1249, 1252, 1256, 1261, 1262, 1264, 1269, 1270, 1274, 1277, 1281, 1285, 1288, 1292, 1295, 1299, 1302, 1306, 1309, 1313, 1316, 1320, 1324, 1327, 1331, 1334, 1338, 1341};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 26 136
new 0 26 136
assign 1 29 137
translateEmittedException 0 33 169
assign 1 36 170
new 0 36 170
assign 1 37 171
def 1 37 176
assign 1 38 177
new 0 38 177
assign 1 38 178
add 1 38 178
assign 1 38 179
add 1 38 179
assign 1 40 181
def 1 40 186
assign 1 41 187
new 0 41 187
assign 1 41 188
add 1 41 188
assign 1 41 189
add 1 41 189
assign 1 43 191
def 1 43 196
assign 1 44 197
new 0 44 197
assign 1 44 198
add 1 44 198
assign 1 44 199
add 1 44 199
assign 1 46 201
def 1 46 206
assign 1 47 207
new 0 47 207
assign 1 47 208
add 1 47 208
assign 1 47 209
add 1 47 209
assign 1 49 211
def 1 49 216
assign 1 50 217
new 0 50 217
assign 1 50 218
add 1 50 218
assign 1 50 219
add 1 50 219
assign 1 52 221
def 1 52 226
assign 1 53 227
new 0 53 227
assign 1 53 228
add 1 53 228
assign 1 53 229
add 1 53 229
assign 1 55 231
def 1 55 236
assign 1 56 237
new 0 56 237
assign 1 56 238
add 1 56 238
assign 1 56 239
toString 0 56 239
assign 1 56 240
add 1 56 240
assign 1 58 242
def 1 58 247
assign 1 59 248
new 0 59 248
assign 1 59 249
add 1 59 249
assign 1 59 250
add 1 59 250
assign 1 61 252
def 1 61 257
assign 1 62 258
getFrameText 0 62 258
assign 1 62 259
add 1 62 259
return 1 64 261
translateEmittedExceptionInner 0 69 267
assign 1 71 271
new 0 71 271
print 0 71 272
assign 1 79 439
def 1 79 444
assign 1 0 446
assign 1 0 449
assign 1 0 453
return 1 80 456
assign 1 82 458
undef 1 82 463
assign 1 83 464
new 0 83 464
assign 1 85 466
new 0 85 466
assign 1 86 467
def 1 86 472
assign 1 86 473
def 1 86 478
assign 1 0 479
assign 1 0 482
assign 1 0 486
assign 1 86 489
new 0 86 489
assign 1 86 490
equals 1 86 490
assign 1 0 492
assign 1 86 495
new 0 86 495
assign 1 86 496
equals 1 86 496
assign 1 0 498
assign 1 0 501
assign 1 0 505
assign 1 0 508
assign 1 0 512
assign 1 87 515
new 0 87 515
assign 1 87 516
new 1 87 516
assign 1 88 517
tokenize 1 88 517
assign 1 89 518
new 0 89 518
assign 1 89 519
equals 1 89 519
assign 1 90 521
new 0 90 521
assign 1 92 524
new 0 92 524
assign 1 94 526
linkedListIteratorGet 0 0 526
assign 1 94 529
hasNextGet 0 94 529
assign 1 94 531
nextGet 0 94 531
assign 1 96 533
new 0 96 533
assign 1 96 534
add 1 96 534
print 0 96 535
assign 1 98 537
new 0 98 537
assign 1 98 538
find 1 98 538
assign 1 99 539
assign 1 100 540
assign 1 101 541
def 1 101 546
assign 1 101 547
new 0 101 547
assign 1 101 548
greaterEquals 1 101 553
assign 1 0 554
assign 1 0 557
assign 1 0 561
assign 1 103 565
new 0 103 565
assign 1 103 566
add 1 103 566
print 0 103 567
assign 1 105 569
new 0 105 569
assign 1 105 570
new 0 105 570
assign 1 105 571
add 1 105 571
assign 1 105 572
find 2 105 572
assign 1 106 573
def 1 106 578
assign 1 106 579
greater 1 106 584
assign 1 0 585
assign 1 0 588
assign 1 0 592
assign 1 108 596
new 0 108 596
assign 1 108 597
add 1 108 597
print 0 108 598
assign 1 110 600
new 0 110 600
assign 1 110 601
add 1 110 601
assign 1 110 602
substring 2 110 602
assign 1 113 604
new 0 113 604
assign 1 113 605
find 2 113 605
assign 1 114 606
def 1 114 611
assign 1 116 612
new 0 116 612
assign 1 116 613
add 1 116 613
assign 1 116 614
substring 1 116 614
assign 1 117 615
new 0 117 615
assign 1 117 616
ends 1 117 616
assign 1 118 618
sizeGet 0 118 618
assign 1 118 619
new 0 118 619
assign 1 118 620
subtract 1 118 620
sizeSet 1 118 621
assign 1 121 623
new 0 121 623
assign 1 121 624
rfind 1 121 624
assign 1 122 625
def 1 122 630
assign 1 123 631
new 0 123 631
assign 1 123 632
substring 2 123 632
assign 1 125 633
new 0 125 633
assign 1 125 634
add 1 125 634
assign 1 125 635
substring 1 125 635
assign 1 126 636
new 0 126 636
assign 1 126 637
begins 1 126 637
assign 1 127 639
new 0 127 639
assign 1 127 640
substring 1 127 640
assign 1 130 642
isInteger 0 130 642
assign 1 131 644
new 1 131 644
assign 1 136 650
new 0 136 650
assign 1 136 651
find 2 136 651
assign 1 137 652
def 1 137 657
assign 1 139 659
new 0 139 659
print 0 139 660
assign 1 142 662
new 0 142 662
assign 1 142 663
new 0 142 663
assign 1 142 664
add 1 142 664
assign 1 142 665
find 2 142 665
assign 1 143 666
def 1 143 671
assign 1 145 673
new 0 145 673
print 0 145 674
assign 1 147 676
new 0 147 676
assign 1 147 677
add 1 147 677
assign 1 147 678
substring 2 147 678
assign 1 149 679
new 0 149 679
assign 1 149 680
rfind 1 149 680
assign 1 150 681
def 1 150 686
assign 1 151 687
new 0 151 687
assign 1 151 688
substring 2 151 688
assign 1 153 689
new 0 153 689
assign 1 153 690
rfind 1 153 690
assign 1 154 691
def 1 154 696
assign 1 155 697
new 0 155 697
assign 1 155 698
substring 2 155 698
assign 1 157 700
new 0 157 700
assign 1 157 701
add 1 157 701
assign 1 157 702
substring 1 157 702
assign 1 159 703
isInteger 0 159 703
assign 1 160 705
new 1 160 705
assign 1 167 713
new 0 167 713
assign 1 167 714
new 0 167 714
assign 1 167 715
add 1 167 715
assign 1 167 716
find 2 167 716
assign 1 168 717
def 1 168 722
assign 1 168 723
greater 1 168 728
assign 1 0 729
assign 1 0 732
assign 1 0 736
assign 1 169 739
new 0 169 739
assign 1 169 740
add 1 169 740
assign 1 169 741
substring 2 169 741
assign 1 171 744
new 0 171 744
assign 1 171 745
add 1 171 745
assign 1 171 746
substring 1 171 746
assign 1 174 749
def 1 174 754
assign 1 177 756
new 0 177 756
assign 1 177 757
split 1 177 757
assign 1 179 758
new 0 179 758
assign 1 179 759
get 1 179 759
assign 1 180 760
new 0 180 760
assign 1 180 761
get 1 180 761
assign 1 182 762
extractKlass 1 182 762
assign 1 184 763
extractMethod 1 184 763
assign 1 186 764
new 4 186 764
assign 1 187 765
klassNameGet 0 187 765
assign 1 187 766
getSourceFileName 1 187 766
fileNameSet 1 187 767
addFrame 1 188 768
assign 1 192 772
new 0 192 772
assign 1 192 773
add 1 192 773
assign 1 192 774
new 0 192 774
assign 1 192 775
add 1 192 775
print 0 192 776
assign 1 194 778
new 0 194 778
assign 1 194 779
split 1 194 779
assign 1 195 780
sizeGet 0 195 780
assign 1 195 781
new 0 195 781
assign 1 195 782
greater 1 195 787
assign 1 196 788
sizeGet 0 196 788
assign 1 196 789
new 0 196 789
assign 1 196 790
greater 1 196 795
assign 1 197 796
new 0 197 796
assign 1 197 797
get 1 197 797
assign 1 198 798
new 0 198 798
assign 1 198 799
get 1 198 799
assign 1 200 802
new 0 200 802
assign 1 200 803
get 1 200 803
assign 1 201 804
new 0 201 804
assign 1 201 805
get 1 201 805
assign 1 203 807
extractMethod 1 203 807
assign 1 205 809
new 0 205 809
assign 1 205 810
add 1 205 810
assign 1 205 811
new 0 205 811
assign 1 205 812
add 1 205 812
print 0 205 813
assign 1 207 815
new 0 207 815
assign 1 207 816
find 1 207 816
assign 1 208 817
def 1 208 822
assign 1 208 823
new 0 208 823
assign 1 208 824
greater 1 208 829
assign 1 0 830
assign 1 0 833
assign 1 0 837
assign 1 209 840
new 0 209 840
assign 1 209 841
new 0 209 841
assign 1 209 842
add 1 209 842
assign 1 209 843
find 2 209 843
assign 1 210 844
def 1 210 849
assign 1 210 850
new 0 210 850
assign 1 210 851
greater 1 210 856
assign 1 0 857
assign 1 0 860
assign 1 0 864
assign 1 214 867
substring 1 214 867
assign 1 216 869
new 0 216 869
assign 1 216 870
add 1 216 870
assign 1 216 871
new 0 216 871
assign 1 216 872
add 1 216 872
print 0 216 873
assign 1 218 875
extractKlass 1 218 875
assign 1 220 877
new 0 220 877
assign 1 220 878
add 1 220 878
assign 1 220 879
new 0 220 879
assign 1 220 880
add 1 220 880
print 0 220 881
assign 1 222 883
new 4 222 883
assign 1 223 884
klassNameGet 0 223 884
assign 1 223 885
getSourceFileName 1 223 885
fileNameSet 1 223 886
assign 1 225 888
new 0 225 888
print 0 225 889
addFrame 1 227 891
assign 1 230 895
new 0 230 895
print 0 230 896
assign 1 239 909
assign 1 240 910
new 0 240 910
assign 1 241 911
assign 1 242 914
def 1 242 919
assign 1 242 920
def 1 242 925
assign 1 0 926
assign 1 0 929
assign 1 0 933
assign 1 242 936
new 0 242 936
assign 1 242 937
equals 1 242 937
assign 1 0 939
assign 1 0 942
assign 1 0 946
assign 1 243 949
linkedListIteratorGet 0 0 949
assign 1 243 952
hasNextGet 0 243 952
assign 1 243 954
nextGet 0 243 954
assign 1 244 955
klassNameGet 0 244 955
assign 1 244 956
extractKlassLib 1 244 956
klassNameSet 1 244 957
assign 1 245 958
methodNameGet 0 245 958
assign 1 245 959
extractMethod 1 245 959
methodNameSet 1 245 960
assign 1 246 961
klassNameGet 0 246 961
assign 1 246 962
getSourceFileName 1 246 962
fileNameSet 1 246 963
extractLine 0 248 965
assign 1 251 972
assign 1 252 973
new 0 252 973
assign 1 257 979
new 0 257 979
print 0 257 980
assign 1 263 989
new 0 263 989
assign 1 263 990
createInstance 2 263 990
assign 1 264 991
def 1 264 996
assign 1 266 997
sourceFileNameGet 0 266 997
return 1 266 998
return 1 269 1000
assign 1 274 1008
new 0 274 1008
assign 1 274 1009
split 1 274 1009
assign 1 276 1010
new 0 276 1010
assign 1 276 1011
get 1 276 1011
assign 1 276 1012
extractKlass 1 276 1012
return 1 276 1013
assign 1 281 1019
extractKlassInner 1 281 1019
return 1 281 1020
return 1 285 1025
assign 1 289 1053
undef 1 289 1058
assign 1 0 1059
assign 1 289 1062
new 0 289 1062
assign 1 289 1063
begins 1 289 1063
assign 1 289 1064
not 0 289 1069
assign 1 0 1070
assign 1 0 1073
return 1 290 1077
assign 1 292 1079
new 0 292 1079
assign 1 292 1080
substring 1 292 1080
assign 1 292 1081
new 0 292 1081
assign 1 292 1082
split 1 292 1082
assign 1 293 1083
sizeGet 0 293 1083
assign 1 293 1084
new 0 293 1084
assign 1 293 1085
subtract 1 293 1085
assign 1 294 1086
get 1 294 1086
assign 1 295 1087
new 0 295 1087
assign 1 296 1088
new 0 296 1088
assign 1 297 1089
new 0 297 1089
assign 1 297 1092
lesser 1 297 1097
assign 1 298 1098
get 1 298 1098
assign 1 298 1099
new 1 298 1099
assign 1 300 1100
add 1 300 1100
assign 1 300 1101
substring 2 300 1101
addValue 1 300 1102
assign 1 301 1103
new 0 301 1103
assign 1 301 1104
add 1 301 1104
assign 1 301 1105
lesser 1 301 1110
assign 1 301 1111
new 0 301 1111
addValue 1 301 1112
addValue 1 302 1114
incrementValue 0 297 1115
return 1 305 1121
assign 1 309 1144
undef 1 309 1149
assign 1 0 1150
assign 1 309 1153
new 0 309 1153
assign 1 309 1154
begins 1 309 1154
assign 1 309 1155
not 0 309 1160
assign 1 0 1161
assign 1 0 1164
return 1 310 1168
assign 1 312 1170
new 0 312 1170
assign 1 312 1171
substring 1 312 1171
assign 1 312 1172
new 0 312 1172
assign 1 312 1173
split 1 312 1173
assign 1 313 1174
sizeGet 0 313 1174
assign 1 313 1175
new 0 313 1175
assign 1 313 1176
subtract 1 313 1176
assign 1 314 1177
new 0 314 1177
assign 1 315 1178
new 0 315 1178
assign 1 315 1181
lesser 1 315 1186
assign 1 316 1187
get 1 316 1187
addValue 1 316 1188
assign 1 317 1189
new 0 317 1189
assign 1 317 1190
add 1 317 1190
assign 1 317 1191
lesser 1 317 1196
assign 1 317 1197
new 0 317 1197
addValue 1 317 1198
incrementValue 0 315 1200
return 1 320 1206
translateEmittedException 0 326 1210
assign 1 328 1212
new 0 328 1212
print 0 328 1213
return 1 331 1215
translateEmittedException 0 335 1225
assign 1 336 1226
new 0 336 1226
assign 1 337 1227
framesGet 0 337 1227
assign 1 338 1228
def 1 338 1233
assign 1 339 1234
new 0 339 1234
assign 1 339 1235
add 1 339 1235
assign 1 340 1236
linkedListIteratorGet 0 0 1236
assign 1 340 1239
hasNextGet 0 340 1239
assign 1 340 1241
nextGet 0 340 1241
assign 1 341 1242
add 1 341 1242
return 1 344 1249
return 1 348 1252
assign 1 352 1256
undef 1 352 1261
assign 1 353 1262
new 0 353 1262
addValue 1 355 1264
assign 1 359 1269
new 4 359 1269
addFrame 1 359 1270
return 1 0 1274
assign 1 0 1277
assign 1 0 1281
return 1 0 1285
assign 1 0 1288
return 1 0 1292
assign 1 0 1295
return 1 0 1299
assign 1 0 1302
return 1 0 1306
assign 1 0 1309
return 1 0 1313
assign 1 0 1316
assign 1 0 1320
return 1 0 1324
assign 1 0 1327
return 1 0 1331
assign 1 0 1334
return 1 0 1338
assign 1 0 1341
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case 734830721: return bem_framesGet_0();
case 1475977273: return bem_langGet_0();
case 798185127: return bem_vvGet_0();
case -1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case -1184167343: return bem_translatedGet_0();
case -764669899: return bem_getFrameText_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 484558571: return bem_descriptionGet_0();
case -1611190486: return bem_lineNumberGet_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 154290862: return bem_translateEmittedException_0();
case -1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 970476426: return bem_translateEmittedExceptionInner_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case -845792839: return bem_iteratorGet_0();
case -1141730732: return bem_framesTextGet_0();
case -314718434: return bem_print_0();
case -220901978: return bem_emitLangGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1286797640: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2124977673: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case -813541388: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 809267380: return bem_vvSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1173085090: return bem_translatedSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -205231606: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -371136143: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1130648479: return bem_framesTextSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bevs_inst = (BEC_2_6_9_SystemException)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bevs_inst;
}
}
