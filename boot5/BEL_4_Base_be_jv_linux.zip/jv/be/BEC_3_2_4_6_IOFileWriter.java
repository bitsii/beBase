package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileWriter extends BEC_2_2_6_IOWriter {
public BEC_3_2_4_6_IOFileWriter() { }
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_0 = {0x77,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_1 = {0x61,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_2 = {0x77,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_3 = {0x61,0x62};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileWriter_bels_3, 2));
public static BEC_3_2_4_6_IOFileWriter bevs_inst;
public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_3_2_4_6_IOFileWriter bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevp_isClosed = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath);
this.bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_openTruncate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
this.bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_openAppend_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
this.bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_2));
this.bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_open_1(BEC_2_4_6_TextString beva_mode) throws Throwable {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevl_append = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_fhpatha = bevp_path.bem_toString_0();
 /* Line: 389 */ {
if (beva_mode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 390 */ {
bevt_3_tmpany_phold = bevo_0;
bevt_2_tmpany_phold = beva_mode.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 390 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 390 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 390 */
 else  /* Line: 390 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 390 */ {
bevl_append = be.BECS_Runtime.boolTrue;
} /* Line: 391 */
 else  /* Line: 392 */ {
bevl_append = be.BECS_Runtime.boolFalse;
} /* Line: 393 */
} /* Line: 390 */

      if (this.bevi_os == null) {
        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        this.bevi_os = new java.io.FileOutputStream(bevls_f, bevl_append.bevi_bool);
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {344, 345, 345, 354, 354, 358, 358, 362, 362, 373, 390, 390, 390, 390, 0, 0, 0, 391, 393, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 23, 24, 29, 30, 35, 36, 52, 54, 59, 60, 61, 63, 66, 70, 73, 76, 88, 91};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 344 16
new 0 344 16
assign 1 345 17
new 1 345 17
pathSet 1 345 18
assign 1 354 23
new 0 354 23
open 1 354 24
assign 1 358 29
new 0 358 29
open 1 358 30
assign 1 362 35
new 0 362 35
open 1 362 36
assign 1 373 52
toString 0 373 52
assign 1 390 54
def 1 390 59
assign 1 390 60
new 0 390 60
assign 1 390 61
equals 1 390 61
assign 1 0 63
assign 1 0 66
assign 1 0 70
assign 1 391 73
new 0 391 73
assign 1 393 76
new 0 393 76
return 1 0 88
assign 1 0 91
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 1242327477: return bem_vfileGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 1572783489: return bem_openTruncate_0();
case -729571811: return bem_serializeToString_0();
case -1240964868: return bem_extOpen_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 866536361: return bem_close_0();
case 2055025483: return bem_serializeContents_0();
case -633463627: return bem_openAppend_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1010579589: return bem_open_0();
case 1820417453: return bem_create_0();
case -792269839: return bem_isClosedGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
case -400189342: return bem_pathGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1253409730: return bem_vfileSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1010579588: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -781187586: return bem_isClosedSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1603004369: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileWriter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileWriter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_6_IOFileWriter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_6_IOFileWriter.bevs_inst = (BEC_3_2_4_6_IOFileWriter)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_6_IOFileWriter.bevs_inst;
}
}
