package be;
/* IO:File: source/build/Pass11.be */
public final class BEC_3_5_5_6_BuildVisitPass11 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass11() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x31};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x31,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_2 = {0x74,0x68,0x72,0x6F,0x77};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_3 = {0x54,0x68,0x69,0x73,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x75,0x73,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x65,0x78,0x61,0x63,0x74,0x6C,0x79,0x20,0x6F,0x6E,0x65,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x2C,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_3, 46));
private static byte[] bels_4 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_6 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_7 = {0x43,0x61,0x6C,0x6C,0x20,0x6E,0x6F,0x74,0x20,0x69,0x6E,0x20,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x70,0x6F,0x73,0x69,0x74,0x69,0x6F,0x6E};
private static byte[] bels_8 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_9 = {0x70,0x68,0x6F,0x6C,0x64};
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_3_5_5_6_BuildVisitPass11 bevs_inst;
public BEC_2_5_4_BuildNode bevp_inMtd;
public BEC_3_5_5_6_BuildVisitPass11 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_fnode = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_5_4_BuildNode bevl_inode = null;
BEC_2_5_3_BuildVar bevl_ts = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_unwind = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_lastStep = null;
BEC_2_6_6_SystemObject bevl_pholdv = null;
BEC_2_6_6_SystemObject bevl_phold = null;
BEC_2_6_6_SystemObject bevl_prc = null;
BEC_2_6_6_SystemObject bevl_prcc = null;
BEC_2_6_6_SystemObject bevl_phold2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_98_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_99_tmpany_phold = null;
bevt_6_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_7_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
if (bevt_6_tmpany_phold.bevi_int == bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevl_fnode = null;
bevt_12_tmpany_phold = beva_node.bem_containedGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_firstGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_9_tmpany_phold == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevl_fnode = beva_node.bem_nextDescendGet_0();
} /* Line: 29 */
bevt_15_tmpany_phold = beva_node.bem_containedGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_firstGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_it = bevt_13_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 31 */ {
bevt_16_tmpany_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpany_phold != null && bevt_16_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_16_tmpany_phold).bevi_bool) /* Line: 31 */ {
bevl_inode = (BEC_2_5_4_BuildNode) bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_fnode == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 33 */ {
bevl_fnode = bevl_inode;
} /* Line: 34 */
beva_node.bem_beforeInsert_1(bevl_inode);
} /* Line: 36 */
 else  /* Line: 31 */ {
break;
} /* Line: 31 */
} /* Line: 31 */
beva_node.bem_delete_0();
return bevl_fnode;
} /* Line: 39 */
bevt_19_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_20_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_19_tmpany_phold.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 41 */ {
bevp_inMtd = beva_node;
bevt_23_tmpany_phold = beva_node.bem_heldGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_0));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_24_tmpany_phold);
bevl_ts = (BEC_2_5_3_BuildVar) bevt_21_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_ts.bem_isTypedSet_1(bevt_25_tmpany_phold);
bevt_28_tmpany_phold = beva_node.bem_classGet_0();
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_ts.bem_namepathSet_1(bevt_26_tmpany_phold);
} /* Line: 45 */
bevt_30_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_31_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_tmpany_phold.bevi_int == bevt_31_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_34_tmpany_phold = beva_node.bem_heldGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_1));
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_35_tmpany_phold);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_38_tmpany_phold = beva_node.bem_heldGet_0();
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_2));
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_39_tmpany_phold);
if (bevt_36_tmpany_phold != null && bevt_36_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpany_phold).bevi_bool) /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 52 */ {
bevt_42_tmpany_phold = beva_node.bem_containedGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_lengthGet_0();
bevt_43_tmpany_phold = bevo_0;
if (bevt_41_tmpany_phold.bevi_int > bevt_43_tmpany_phold.bevi_int) {
bevt_40_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_40_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 52 */ {
bevt_46_tmpany_phold = bevo_1;
bevt_49_tmpany_phold = beva_node.bem_containedGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_lengthGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_toString_0();
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_add_1(bevt_47_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_45_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_44_tmpany_phold);
} /* Line: 53 */
bevt_52_tmpany_phold = beva_node.bem_heldGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_4));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_53_tmpany_phold);
if (bevt_50_tmpany_phold != null && bevt_50_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpany_phold).bevi_bool) /* Line: 55 */ {
bevt_56_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_55_tmpany_phold == null) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_59_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(590009791, BEL_4_Base.bevn_impliedGet_0);
if (bevt_57_tmpany_phold != null && bevt_57_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_57_tmpany_phold).bevi_bool) /* Line: 56 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
 else  /* Line: 56 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 56 */ {
bevt_60_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_60_tmpany_phold.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, null);
} /* Line: 57 */
} /* Line: 56 */
bevt_63_tmpany_phold = beva_node.bem_heldGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(-1319292247, BEL_4_Base.bevn_boundGet_0);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_61_tmpany_phold != null && bevt_61_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpany_phold).bevi_bool) /* Line: 60 */ {
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_65_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_66_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_5));
bevl_v = bevt_64_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_66_tmpany_phold);
bevt_67_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_nd.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = bevl_v.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_68_tmpany_phold);
bevt_69_tmpany_phold = beva_node.bem_heldGet_0();
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_69_tmpany_phold.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_70_tmpany_phold);
beva_node.bem_prepend_1((BEC_2_5_4_BuildNode) bevl_nd);
} /* Line: 67 */
bevt_73_tmpany_phold = beva_node.bem_heldGet_0();
bevt_72_tmpany_phold = bevt_73_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_74_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_6));
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_74_tmpany_phold);
if (bevt_71_tmpany_phold != null && bevt_71_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_71_tmpany_phold).bevi_bool) /* Line: 70 */ {
bevt_75_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_75_tmpany_phold;
} /* Line: 71 */
bevl_unwind = be.BECS_Runtime.boolTrue;
bevl_c0 = beva_node.bem_containerGet_0();
if (bevl_c0 == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 75 */ {
bevt_78_tmpany_phold = (new BEC_2_4_6_TextString(28, bels_7));
bevt_77_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_78_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_77_tmpany_phold);
} /* Line: 76 */
bevt_80_tmpany_phold = bevl_c0.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_81_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpany_phold);
if (bevt_79_tmpany_phold != null && bevt_79_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpany_phold).bevi_bool) /* Line: 80 */ {
bevt_84_tmpany_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_8));
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_85_tmpany_phold);
if (bevt_82_tmpany_phold != null && bevt_82_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_82_tmpany_phold).bevi_bool) /* Line: 80 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
 else  /* Line: 80 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 80 */ {
bevt_86_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
 else  /* Line: 80 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 80 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 81 */
 else  /* Line: 80 */ {
bevt_88_tmpany_phold = bevl_c0.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_89_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_89_tmpany_phold);
if (bevt_87_tmpany_phold != null && bevt_87_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_87_tmpany_phold).bevi_bool) /* Line: 82 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 83 */
} /* Line: 80 */
if (bevl_unwind != null && bevl_unwind instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_unwind).bevi_bool) /* Line: 85 */ {
bevl_cnode = bevl_c0;
bevl_lastStep = null;
while (true)
 /* Line: 90 */ {
bevt_91_tmpany_phold = bevl_cnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_92_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_90_tmpany_phold = bevt_91_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_92_tmpany_phold);
if (bevt_90_tmpany_phold != null && bevt_90_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_90_tmpany_phold).bevi_bool) /* Line: 90 */ {
bevl_lastStep = bevl_cnode;
bevl_cnode = bevl_cnode.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 93 */
 else  /* Line: 90 */ {
break;
} /* Line: 90 */
} /* Line: 90 */
bevt_93_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_9));
bevl_pholdv = bevl_lastStep.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_93_tmpany_phold, bevp_build);
bevl_phold = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_94_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_94_tmpany_phold);
bevl_phold.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_pholdv);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_phold);
bevl_phold.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_prc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_prc.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_95_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_prc.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_95_tmpany_phold);
bevl_prcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_96_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_10));
bevl_prcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_96_tmpany_phold);
bevl_prc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_prcc);
bevl_phold2 = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold2.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_97_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold2.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_97_tmpany_phold);
bevl_phold2.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_pholdv);
bevl_prc.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_phold2);
bevl_prc.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
bevl_lastStep.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_prc);
bevt_98_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_98_tmpany_phold;
} /* Line: 118 */
} /* Line: 85 */
bevt_99_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_99_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inMtdGet_0() throws Throwable {
return bevp_inMtd;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 26, 26, 26, 27, 28, 28, 28, 28, 28, 28, 29, 31, 31, 31, 31, 31, 32, 33, 33, 34, 36, 38, 39, 41, 41, 41, 41, 42, 43, 43, 43, 43, 43, 44, 44, 45, 45, 45, 45, 50, 50, 50, 50, 52, 52, 52, 52, 0, 52, 52, 52, 52, 0, 0, 52, 52, 52, 52, 52, 0, 0, 0, 53, 53, 53, 53, 53, 53, 53, 55, 55, 55, 55, 56, 56, 56, 56, 56, 56, 56, 0, 0, 0, 57, 57, 60, 60, 60, 61, 62, 63, 63, 63, 63, 64, 64, 65, 65, 66, 66, 66, 67, 70, 70, 70, 70, 71, 71, 73, 74, 75, 75, 76, 76, 76, 80, 80, 80, 80, 80, 80, 80, 0, 0, 0, 80, 0, 0, 0, 81, 82, 82, 82, 83, 86, 87, 90, 90, 90, 92, 93, 98, 98, 99, 100, 101, 101, 102, 103, 104, 105, 106, 107, 107, 108, 109, 109, 110, 111, 112, 113, 113, 114, 115, 116, 117, 118, 118, 121, 121, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {141, 142, 143, 148, 149, 150, 151, 152, 153, 154, 159, 160, 162, 163, 164, 165, 168, 170, 171, 176, 177, 179, 185, 186, 188, 189, 190, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 209, 210, 211, 216, 217, 218, 219, 220, 222, 225, 226, 227, 228, 230, 233, 237, 238, 239, 240, 245, 246, 249, 253, 256, 257, 258, 259, 260, 261, 262, 264, 265, 266, 267, 269, 270, 271, 276, 277, 278, 279, 281, 284, 288, 291, 292, 295, 296, 297, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 314, 315, 316, 317, 319, 320, 322, 323, 324, 329, 330, 331, 332, 334, 335, 336, 338, 339, 340, 341, 343, 346, 350, 353, 355, 358, 362, 365, 368, 369, 370, 372, 376, 377, 380, 381, 382, 384, 385, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 420, 421, 424, 427};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 26 141
typenameGet 0 26 141
assign 1 26 142
EXPRGet 0 26 142
assign 1 26 143
equals 1 26 148
assign 1 27 149
assign 1 28 150
containedGet 0 28 150
assign 1 28 151
firstGet 0 28 151
assign 1 28 152
containedGet 0 28 152
assign 1 28 153
firstNodeGet 0 28 153
assign 1 28 154
undef 1 28 159
assign 1 29 160
nextDescendGet 0 29 160
assign 1 31 162
containedGet 0 31 162
assign 1 31 163
firstGet 0 31 163
assign 1 31 164
containedGet 0 31 164
assign 1 31 165
iteratorGet 0 31 165
assign 1 31 168
hasNextGet 0 31 168
assign 1 32 170
nextGet 0 32 170
assign 1 33 171
undef 1 33 176
assign 1 34 177
beforeInsert 1 36 179
delete 0 38 185
return 1 39 186
assign 1 41 188
typenameGet 0 41 188
assign 1 41 189
METHODGet 0 41 189
assign 1 41 190
equals 1 41 195
assign 1 42 196
assign 1 43 197
heldGet 0 43 197
assign 1 43 198
anyMapGet 0 43 198
assign 1 43 199
new 0 43 199
assign 1 43 200
get 1 43 200
assign 1 43 201
heldGet 0 43 201
assign 1 44 202
new 0 44 202
isTypedSet 1 44 203
assign 1 45 204
classGet 0 45 204
assign 1 45 205
heldGet 0 45 205
assign 1 45 206
namepathGet 0 45 206
namepathSet 1 45 207
assign 1 50 209
typenameGet 0 50 209
assign 1 50 210
CALLGet 0 50 210
assign 1 50 211
equals 1 50 216
assign 1 52 217
heldGet 0 52 217
assign 1 52 218
nameGet 0 52 218
assign 1 52 219
new 0 52 219
assign 1 52 220
equals 1 52 220
assign 1 0 222
assign 1 52 225
heldGet 0 52 225
assign 1 52 226
nameGet 0 52 226
assign 1 52 227
new 0 52 227
assign 1 52 228
equals 1 52 228
assign 1 0 230
assign 1 0 233
assign 1 52 237
containedGet 0 52 237
assign 1 52 238
lengthGet 0 52 238
assign 1 52 239
new 0 52 239
assign 1 52 240
greater 1 52 245
assign 1 0 246
assign 1 0 249
assign 1 0 253
assign 1 53 256
new 0 53 256
assign 1 53 257
containedGet 0 53 257
assign 1 53 258
lengthGet 0 53 258
assign 1 53 259
toString 0 53 259
assign 1 53 260
add 1 53 260
assign 1 53 261
new 2 53 261
throw 1 53 262
assign 1 55 264
heldGet 0 55 264
assign 1 55 265
nameGet 0 55 265
assign 1 55 266
new 0 55 266
assign 1 55 267
equals 1 55 267
assign 1 56 269
heldGet 0 56 269
assign 1 56 270
rtypeGet 0 56 270
assign 1 56 271
def 1 56 276
assign 1 56 277
heldGet 0 56 277
assign 1 56 278
rtypeGet 0 56 278
assign 1 56 279
impliedGet 0 56 279
assign 1 0 281
assign 1 0 284
assign 1 0 288
assign 1 57 291
heldGet 0 57 291
rtypeSet 1 57 292
assign 1 60 295
heldGet 0 60 295
assign 1 60 296
boundGet 0 60 296
assign 1 60 297
not 0 60 297
assign 1 61 299
new 1 61 299
copyLoc 1 62 300
assign 1 63 301
heldGet 0 63 301
assign 1 63 302
anyMapGet 0 63 302
assign 1 63 303
new 0 63 303
assign 1 63 304
get 1 63 304
assign 1 64 305
VARGet 0 64 305
typenameSet 1 64 306
assign 1 65 307
heldGet 0 65 307
heldSet 1 65 308
assign 1 66 309
heldGet 0 66 309
assign 1 66 310
new 0 66 310
boundSet 1 66 311
prepend 1 67 312
assign 1 70 314
heldGet 0 70 314
assign 1 70 315
nameGet 0 70 315
assign 1 70 316
new 0 70 316
assign 1 70 317
equals 1 70 317
assign 1 71 319
nextDescendGet 0 71 319
return 1 71 320
assign 1 73 322
new 0 73 322
assign 1 74 323
containerGet 0 74 323
assign 1 75 324
undef 1 75 329
assign 1 76 330
new 0 76 330
assign 1 76 331
new 2 76 331
throw 1 76 332
assign 1 80 334
typenameGet 0 80 334
assign 1 80 335
CALLGet 0 80 335
assign 1 80 336
equals 1 80 336
assign 1 80 338
heldGet 0 80 338
assign 1 80 339
nameGet 0 80 339
assign 1 80 340
new 0 80 340
assign 1 80 341
equals 1 80 341
assign 1 0 343
assign 1 0 346
assign 1 0 350
assign 1 80 353
isSecondGet 0 80 353
assign 1 0 355
assign 1 0 358
assign 1 0 362
assign 1 81 365
new 0 81 365
assign 1 82 368
typenameGet 0 82 368
assign 1 82 369
BRACESGet 0 82 369
assign 1 82 370
equals 1 82 370
assign 1 83 372
new 0 83 372
assign 1 86 376
assign 1 87 377
assign 1 90 380
typenameGet 0 90 380
assign 1 90 381
BRACESGet 0 90 381
assign 1 90 382
notEquals 1 90 382
assign 1 92 384
assign 1 93 385
containerGet 0 93 385
assign 1 98 391
new 0 98 391
assign 1 98 392
tmpVar 2 98 392
assign 1 99 393
new 1 99 393
copyLoc 1 100 394
assign 1 101 395
VARGet 0 101 395
typenameSet 1 101 396
heldSet 1 102 397
replaceWith 1 103 398
addVariable 0 104 399
assign 1 105 400
new 1 105 400
copyLoc 1 106 401
assign 1 107 402
CALLGet 0 107 402
typenameSet 1 107 403
assign 1 108 404
new 0 108 404
assign 1 109 405
new 0 109 405
nameSet 1 109 406
heldSet 1 110 407
assign 1 111 408
new 1 111 408
copyLoc 1 112 409
assign 1 113 410
VARGet 0 113 410
typenameSet 1 113 411
heldSet 1 114 412
addValue 1 115 413
addValue 1 116 414
beforeInsert 1 117 415
assign 1 118 416
nextDescendGet 0 118 416
return 1 118 417
assign 1 121 420
nextDescendGet 0 121 420
return 1 121 421
return 1 0 424
assign 1 0 427
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case -850314193: return bem_inMtdGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -839231940: return bem_inMtdSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass11();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass11.bevs_inst = (BEC_3_5_5_6_BuildVisitPass11)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass11.bevs_inst;
}
}
