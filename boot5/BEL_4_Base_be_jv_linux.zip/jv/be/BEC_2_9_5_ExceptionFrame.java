package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_9_5_ExceptionFrame extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ExceptionFrame() { }
private static byte[] becc_clname = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x46,0x72,0x61,0x6D,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x46,0x72,0x61,0x6D,0x65,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x0A};
public static BEC_2_9_5_ExceptionFrame bevs_inst;
public BEC_2_4_6_TextString bevp_klassName;
public BEC_2_4_6_TextString bevp_methodName;
public BEC_2_4_6_TextString bevp_emitFileName;
public BEC_2_4_3_MathInt bevp_emitLine;
public BEC_2_4_6_TextString bevp_fileName;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_9_5_ExceptionFrame bem_new_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__emitFileName, BEC_2_4_3_MathInt beva__emitLine) throws Throwable {
bevp_klassName = beva__klassName;
bevp_methodName = beva__methodName;
bevp_emitFileName = beva__emitFileName;
bevp_emitLine = beva__emitLine;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_extractLine_0() throws Throwable {
BEC_2_6_16_SystemExceptionBuilder bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_16_SystemExceptionBuilder) BEC_2_6_16_SystemExceptionBuilder.bevs_inst;
bevp_line = bevt_0_tmpany_phold.bem_getLineForEmitLine_2(bevp_klassName, bevp_emitLine);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevl_res = (new BEC_2_4_6_TextString(17, bels_0));
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(8, bels_1));
bevl_res.bem_addValue_1(bevt_0_tmpany_phold);
if (bevp_klassName == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 493 */ {
bevl_res.bem_addValue_1(bevp_klassName);
} /* Line: 493 */
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(9, bels_2));
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
if (bevp_methodName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 495 */ {
bevl_res.bem_addValue_1(bevp_methodName);
} /* Line: 495 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_3));
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
if (bevp_fileName == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevl_res.bem_addValue_1(bevp_fileName);
} /* Line: 497 */
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(7, bels_4));
bevl_res.bem_addValue_1(bevt_6_tmpany_phold);
if (bevp_line == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 499 */ {
bevt_8_tmpany_phold = bevp_line.bem_toString_0();
bevl_res.bem_addValue_1(bevt_8_tmpany_phold);
} /* Line: 499 */
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_5));
bevl_res.bem_addValue_1(bevt_9_tmpany_phold);
if (bevp_emitFileName == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevl_res.bem_addValue_1(bevp_emitFileName);
} /* Line: 501 */
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_6));
bevl_res.bem_addValue_1(bevt_11_tmpany_phold);
if (bevp_emitLine == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_13_tmpany_phold = bevp_emitLine.bem_toString_0();
bevl_res.bem_addValue_1(bevt_13_tmpany_phold);
} /* Line: 503 */
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_7));
bevl_res.bem_addValue_1(bevt_14_tmpany_phold);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return bevp_klassName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitFileNameGet_0() throws Throwable {
return bevp_emitFileName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitLineGet_0() throws Throwable {
return bevp_emitLine;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitLineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {471, 472, 473, 474, 487, 487, 491, 492, 492, 493, 493, 493, 494, 494, 495, 495, 495, 496, 496, 497, 497, 497, 498, 498, 499, 499, 499, 499, 500, 500, 501, 501, 501, 502, 502, 503, 503, 503, 503, 504, 504, 505, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 31, 32, 52, 53, 54, 55, 60, 61, 63, 64, 65, 70, 71, 73, 74, 75, 80, 81, 83, 84, 85, 90, 91, 92, 94, 95, 96, 101, 102, 104, 105, 106, 111, 112, 113, 115, 116, 117, 120, 123, 127, 130, 134, 137, 141, 144, 148, 151, 155, 158};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 471 23
assign 1 472 24
assign 1 473 25
assign 1 474 26
assign 1 487 31
new 0 487 31
assign 1 487 32
getLineForEmitLine 2 487 32
assign 1 491 52
new 0 491 52
assign 1 492 53
new 0 492 53
addValue 1 492 54
assign 1 493 55
def 1 493 60
addValue 1 493 61
assign 1 494 63
new 0 494 63
addValue 1 494 64
assign 1 495 65
def 1 495 70
addValue 1 495 71
assign 1 496 73
new 0 496 73
addValue 1 496 74
assign 1 497 75
def 1 497 80
addValue 1 497 81
assign 1 498 83
new 0 498 83
addValue 1 498 84
assign 1 499 85
def 1 499 90
assign 1 499 91
toString 0 499 91
addValue 1 499 92
assign 1 500 94
new 0 500 94
addValue 1 500 95
assign 1 501 96
def 1 501 101
addValue 1 501 102
assign 1 502 104
new 0 502 104
addValue 1 502 105
assign 1 503 106
def 1 503 111
assign 1 503 112
toString 0 503 112
addValue 1 503 113
assign 1 504 115
new 0 504 115
addValue 1 504 116
return 1 505 117
return 1 0 120
assign 1 0 123
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case -1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case 1651005069: return bem_emitFileNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 779420512: return bem_emitLineGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case -1081412016: return bem_many_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case -817024378: return bem_extractLine_0();
case -845792839: return bem_iteratorGet_0();
case -1818667533: return bem_lineGet_0();
case -314718434: return bem_print_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1807585280: return bem_lineSet_1(bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 790502765: return bem_emitLineSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1662087322: return bem_emitFileNameSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 104713557: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ExceptionFrame();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ExceptionFrame.bevs_inst = (BEC_2_9_5_ExceptionFrame)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ExceptionFrame.bevs_inst;
}
}
