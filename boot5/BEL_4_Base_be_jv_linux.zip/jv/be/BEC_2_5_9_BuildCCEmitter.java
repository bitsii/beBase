package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_15, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_16, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x3E,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_27, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_30, 31));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_31, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_49, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_52, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_53, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_63, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_64, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_65, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_66, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_67, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_68, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_69, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_70, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_71, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_77, 18));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x3E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_78, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_81, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_82, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_84, 19));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_85, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_93, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_94, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_95, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_96, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_97, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x3C,0x69,0x6F,0x73,0x74,0x72,0x65,0x61,0x6D,0x3E,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x3C,0x6D,0x65,0x6D,0x6F,0x72,0x79,0x3E,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x5B,0x5D,0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_120, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_121, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_125, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_126, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x7D};
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 31 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = this.bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 32 */
 else  /* Line: 33 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevl_extends = this.bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 34 */
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevp_heow.bem_write_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevp_heow.bem_write_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevp_heow.bem_write_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(76, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevp_heow.bem_write_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(62, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevp_heow.bem_write_1(bevt_15_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_19_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevp_deow.bem_write_1(bevt_16_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
return bevt_21_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_8_tmpany_phold = this.bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_19_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_20_tmpany_phold);
bevt_24_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_22_tmpany_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_23_tmpany_phold );
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_17_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_27_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = this.bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_6_tmpany_phold = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_0_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_16_tmpany_phold = bevp_methods.bem_addValue_1(bevt_17_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_22_tmpany_phold = bevp_classHeadBody.bem_addValue_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_24_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_19_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevp_classHeadBody.bem_addValue_1(bevt_28_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_12_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_3_tmpany_phold = beva_b.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevt_2_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 114 */
 else  /* Line: 115 */ {
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevt_9_tmpany_phold = beva_b.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_12_tmpany_phold = this.bem_getClassConfig_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_relEmitName_1(bevt_14_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_8_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 116 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevl_ccall = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
} /* Line: 122 */
 else  /* Line: 123 */ {
bevl_ccall = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
} /* Line: 124 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = this.bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_18_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_22_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 150 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 151 */
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_20_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(beva_lisz);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_belsName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
return bevt_12_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 164 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 166 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_19_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_36_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_47_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
if (bevp_deow == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_7_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_3_tmpany_phold.bem_add_1(bevp_headExt);
bevt_12_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevt_13_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_9_tmpany_phold.bem_add_1(bevp_headExt);
bevt_15_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_15_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_16_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_20_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_fileGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_existsGet_0();
if (bevt_18_tmpany_phold.bevi_bool) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_22_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold.bem_makeDirs_0();
} /* Line: 222 */
bevt_24_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_23_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_26_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_25_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevp_heow.bem_write_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevp_heow.bem_write_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevp_heow.bem_write_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevp_heow.bem_write_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevp_deow.bem_write_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevp_heow.bem_write_1(bevt_32_tmpany_phold);
bevt_34_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_has_1(bevt_35_tmpany_phold);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_37_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_get_1(bevt_38_tmpany_phold);
bevt_0_tmpany_loop = bevt_36_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 241 */ {
bevt_39_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_39_tmpany_phold != null && bevt_39_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_39_tmpany_phold).bevi_bool) /* Line: 241 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_40_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_40_tmpany_phold.bem_fileGet_0();
bevt_42_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_43_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_43_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 247 */
 else  /* Line: 241 */ {
break;
} /* Line: 241 */
} /* Line: 241 */
} /* Line: 241 */
bevt_45_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 250 */ {
bevt_48_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
bevt_1_tmpany_loop = bevt_47_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 252 */ {
bevt_50_tmpany_phold = bevt_1_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_50_tmpany_phold != null && bevt_50_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 252 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_51_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_51_tmpany_phold.bem_fileGet_0();
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_54_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_54_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 258 */
 else  /* Line: 252 */ {
break;
} /* Line: 252 */
} /* Line: 252 */
} /* Line: 252 */
} /* Line: 250 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
this.bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_14_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevt_7_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 274 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevp_shlibe.bem_write_1(bevt_10_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_12_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 280 */ {
bevt_15_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_get_1(bevt_16_tmpany_phold);
bevt_0_tmpany_loop = bevt_14_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_17_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 281 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_18_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_18_tmpany_phold.bem_fileGet_0();
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_21_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_22_tmpany_phold = this.bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_22_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 286 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
} /* Line: 281 */
} /* Line: 280 */
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
beva_libe.bem_write_1(bevt_0_tmpany_phold);
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevp_deow.bem_write_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevp_heow.bem_write_1(bevt_2_tmpany_phold);
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_1_tmpany_phold = beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 325 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 325 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 326 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 327 */
 else  /* Line: 328 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 329 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 331 */
 else  /* Line: 325 */ {
break;
} /* Line: 325 */
} /* Line: 325 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_7_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_4_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_0_tmpany_phold.bem_relEmitName_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_2_tmpany_phold );
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_12_tmpany_phold = this.bem_overrideMtdDecGet_0();
bevt_11_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_19_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 362 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevl_asnr = this.bem_formCast_3(bevp_classConf, bevt_20_tmpany_phold, bevl_asnr);
} /* Line: 363 */
bevt_24_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_27_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = this.bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_addValue_1(bevt_42_tmpany_phold);
bevt_29_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_45_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_46_tmpany_phold);
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_addValue_1(bevt_47_tmpany_phold);
bevt_43_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_48_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_49_tmpany_phold);
bevt_48_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 19, 20, 21, 23, 24, 27, 31, 31, 32, 32, 32, 34, 34, 36, 36, 36, 36, 36, 36, 38, 38, 40, 40, 42, 44, 46, 48, 50, 50, 51, 51, 52, 52, 53, 53, 54, 54, 56, 56, 56, 56, 56, 56, 58, 58, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 65, 65, 65, 69, 71, 71, 72, 76, 76, 76, 77, 78, 78, 78, 78, 78, 78, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 85, 85, 89, 89, 93, 93, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 100, 102, 102, 102, 102, 102, 102, 104, 104, 104, 104, 104, 104, 104, 104, 104, 104, 106, 108, 108, 113, 113, 113, 114, 114, 114, 114, 114, 114, 114, 116, 116, 116, 116, 116, 116, 116, 116, 116, 121, 121, 122, 124, 126, 126, 126, 126, 126, 126, 126, 126, 131, 131, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 136, 136, 136, 136, 136, 136, 136, 136, 136, 138, 138, 138, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 157, 157, 157, 157, 157, 162, 163, 164, 164, 165, 165, 166, 166, 168, 168, 168, 169, 175, 175, 175, 175, 179, 179, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 184, 185, 185, 185, 186, 186, 186, 186, 186, 186, 186, 186, 188, 188, 192, 192, 196, 196, 196, 196, 200, 200, 215, 215, 216, 217, 217, 217, 217, 217, 217, 217, 218, 218, 218, 218, 218, 218, 218, 219, 219, 220, 220, 221, 221, 221, 221, 221, 222, 222, 222, 224, 224, 224, 225, 225, 225, 227, 227, 228, 228, 229, 229, 230, 230, 232, 232, 233, 233, 239, 239, 239, 241, 241, 241, 241, 0, 241, 241, 243, 243, 244, 244, 244, 245, 245, 247, 250, 250, 250, 252, 252, 252, 252, 0, 252, 252, 254, 254, 255, 255, 255, 256, 256, 258, 265, 266, 271, 271, 272, 273, 273, 273, 273, 273, 274, 274, 274, 276, 276, 276, 278, 278, 279, 280, 280, 280, 281, 281, 281, 281, 0, 281, 281, 282, 282, 283, 283, 283, 284, 284, 285, 285, 286, 292, 297, 297, 298, 299, 301, 301, 303, 303, 304, 305, 310, 310, 314, 314, 314, 314, 314, 319, 319, 320, 322, 322, 322, 322, 324, 325, 0, 325, 325, 327, 329, 329, 331, 331, 331, 331, 331, 331, 335, 335, 335, 340, 342, 342, 342, 342, 342, 344, 344, 344, 344, 344, 344, 344, 344, 344, 346, 350, 350, 351, 351, 351, 351, 352, 356, 356, 356, 357, 357, 357, 358, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 361, 362, 362, 363, 363, 366, 366, 366, 366, 366, 366, 366, 368, 368, 368, 371, 371, 371, 371, 371, 371, 371, 371, 371, 371, 371, 371, 371, 371, 371, 373, 373, 373, 373, 373, 373, 375, 375, 375, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {199, 200, 201, 202, 203, 204, 205, 233, 238, 239, 240, 241, 244, 245, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 347, 348, 349, 350, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 394, 395, 399, 400, 404, 405, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 491, 492, 497, 498, 499, 500, 501, 502, 503, 504, 507, 508, 509, 510, 511, 512, 513, 514, 515, 530, 531, 533, 536, 538, 539, 540, 541, 542, 543, 544, 545, 549, 550, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 715, 716, 717, 718, 719, 729, 730, 731, 732, 734, 735, 736, 737, 739, 740, 741, 742, 749, 750, 751, 752, 756, 757, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 807, 808, 814, 815, 816, 817, 821, 822, 887, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 920, 921, 922, 923, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 947, 948, 949, 950, 950, 953, 955, 956, 957, 958, 959, 960, 961, 962, 963, 970, 971, 972, 974, 975, 976, 977, 977, 980, 982, 983, 984, 985, 986, 987, 988, 989, 990, 1001, 1002, 1032, 1037, 1038, 1039, 1040, 1041, 1042, 1047, 1048, 1049, 1050, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1062, 1063, 1064, 1065, 1065, 1068, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1088, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1108, 1109, 1116, 1117, 1118, 1119, 1120, 1142, 1143, 1144, 1145, 1146, 1147, 1148, 1149, 1150, 1150, 1153, 1155, 1157, 1160, 1161, 1163, 1164, 1165, 1166, 1167, 1168, 1174, 1175, 1176, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293, 1294, 1295, 1296, 1297, 1298, 1299, 1300, 1301, 1302, 1303, 1304, 1305, 1307, 1308, 1310, 1311, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1347, 1350, 1354, 1357, 1361, 1364, 1368, 1371, 1375, 1378, 1382, 1385, 1389, 1392, 1396, 1399, 1403, 1406};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 199
new 0 18 199
assign 1 19 200
new 0 19 200
assign 1 20 201
new 0 20 201
assign 1 21 202
new 0 21 202
assign 1 23 203
new 0 23 203
assign 1 24 204
new 0 24 204
new 1 27 205
assign 1 31 233
def 1 31 238
assign 1 32 239
libNameGet 0 32 239
assign 1 32 240
relEmitName 1 32 240
assign 1 32 241
extend 1 32 241
assign 1 34 244
new 0 34 244
assign 1 34 245
extend 1 34 245
assign 1 36 247
new 0 36 247
assign 1 36 248
emitNameGet 0 36 248
assign 1 36 249
addValue 1 36 249
assign 1 36 250
addValue 1 36 250
assign 1 36 251
new 0 36 251
assign 1 36 252
addValue 1 36 252
assign 1 38 253
new 0 38 253
addValue 1 38 254
assign 1 40 255
new 0 40 255
addValue 1 40 256
write 1 42 257
write 1 44 258
write 1 46 259
clear 0 48 260
assign 1 50 261
new 0 50 261
write 1 50 262
assign 1 51 263
new 0 51 263
write 1 51 264
assign 1 52 265
new 0 52 265
write 1 52 266
assign 1 53 267
new 0 53 267
write 1 53 268
assign 1 54 269
new 0 54 269
write 1 54 270
assign 1 56 271
new 0 56 271
assign 1 56 272
emitNameGet 0 56 272
assign 1 56 273
add 1 56 273
assign 1 56 274
new 0 56 274
assign 1 56 275
add 1 56 275
write 1 56 276
assign 1 58 277
new 0 58 277
return 1 58 278
assign 1 62 310
overrideMtdDecGet 0 62 310
assign 1 62 311
addValue 1 62 311
assign 1 62 312
new 0 62 312
assign 1 62 313
addValue 1 62 313
assign 1 62 314
getClassConfig 1 62 314
assign 1 62 315
libNameGet 0 62 315
assign 1 62 316
relEmitName 1 62 316
assign 1 62 317
addValue 1 62 317
assign 1 62 318
new 0 62 318
assign 1 62 319
addValue 1 62 319
assign 1 62 320
emitNameGet 0 62 320
assign 1 62 321
addValue 1 62 321
assign 1 62 322
new 0 62 322
assign 1 62 323
addValue 1 62 323
assign 1 62 324
addValue 1 62 324
assign 1 62 325
new 0 62 325
assign 1 62 326
addValue 1 62 326
addValue 1 62 327
assign 1 63 328
new 0 63 328
assign 1 63 329
addValue 1 63 329
assign 1 63 330
heldGet 0 63 330
assign 1 63 331
namepathGet 0 63 331
assign 1 63 332
getClassConfig 1 63 332
assign 1 63 333
libNameGet 0 63 333
assign 1 63 334
relEmitName 1 63 334
assign 1 63 335
addValue 1 63 335
assign 1 63 336
new 0 63 336
assign 1 63 337
addValue 1 63 337
addValue 1 63 338
assign 1 65 339
new 0 65 339
assign 1 65 340
addValue 1 65 340
addValue 1 65 341
assign 1 69 347
new 0 69 347
assign 1 71 348
new 0 71 348
write 1 71 349
return 1 72 350
assign 1 76 370
new 0 76 370
assign 1 76 371
toString 0 76 371
assign 1 76 372
add 1 76 372
incrementValue 0 77 373
assign 1 78 374
new 0 78 374
assign 1 78 375
addValue 1 78 375
assign 1 78 376
addValue 1 78 376
assign 1 78 377
new 0 78 377
assign 1 78 378
addValue 1 78 378
addValue 1 78 379
assign 1 80 380
containedGet 0 80 380
assign 1 80 381
firstGet 0 80 381
assign 1 80 382
containedGet 0 80 382
assign 1 80 383
firstGet 0 80 383
assign 1 80 384
new 0 80 384
assign 1 80 385
add 1 80 385
assign 1 80 386
new 0 80 386
assign 1 80 387
add 1 80 387
assign 1 80 388
finalAssign 4 80 388
addValue 1 80 389
assign 1 85 394
new 0 85 394
return 1 85 395
assign 1 89 399
new 0 89 399
return 1 89 400
assign 1 93 404
new 0 93 404
return 1 93 405
assign 1 98 437
addValue 1 98 437
assign 1 98 438
new 0 98 438
assign 1 98 439
addValue 1 98 439
assign 1 98 440
libNameGet 0 98 440
assign 1 98 441
relEmitName 1 98 441
assign 1 98 442
addValue 1 98 442
assign 1 98 443
new 0 98 443
assign 1 98 444
addValue 1 98 444
assign 1 98 445
emitNameGet 0 98 445
assign 1 98 446
addValue 1 98 446
assign 1 98 447
new 0 98 447
assign 1 98 448
addValue 1 98 448
assign 1 98 449
addValue 1 98 449
assign 1 98 450
new 0 98 450
addValue 1 98 451
addValue 1 100 452
assign 1 102 453
new 0 102 453
assign 1 102 454
addValue 1 102 454
assign 1 102 455
addValue 1 102 455
assign 1 102 456
new 0 102 456
assign 1 102 457
addValue 1 102 457
addValue 1 102 458
assign 1 104 459
new 0 104 459
assign 1 104 460
addValue 1 104 460
assign 1 104 461
libNameGet 0 104 461
assign 1 104 462
relEmitName 1 104 462
assign 1 104 463
addValue 1 104 463
assign 1 104 464
new 0 104 464
assign 1 104 465
addValue 1 104 465
assign 1 104 466
addValue 1 104 466
assign 1 104 467
new 0 104 467
addValue 1 104 468
addValue 1 106 469
assign 1 108 470
new 0 108 470
addValue 1 108 471
assign 1 113 491
isTypedGet 0 113 491
assign 1 113 492
not 0 113 497
assign 1 114 498
new 0 114 498
assign 1 114 499
addValue 1 114 499
assign 1 114 500
libNameGet 0 114 500
assign 1 114 501
relEmitName 1 114 501
assign 1 114 502
addValue 1 114 502
assign 1 114 503
new 0 114 503
addValue 1 114 504
assign 1 116 507
new 0 116 507
assign 1 116 508
addValue 1 116 508
assign 1 116 509
namepathGet 0 116 509
assign 1 116 510
getClassConfig 1 116 510
assign 1 116 511
libNameGet 0 116 511
assign 1 116 512
relEmitName 1 116 512
assign 1 116 513
addValue 1 116 513
assign 1 116 514
new 0 116 514
addValue 1 116 515
assign 1 121 530
new 0 121 530
assign 1 121 531
equals 1 121 531
assign 1 122 533
new 0 122 533
assign 1 124 536
new 0 124 536
assign 1 126 538
new 0 126 538
assign 1 126 539
add 1 126 539
assign 1 126 540
libNameGet 0 126 540
assign 1 126 541
relEmitName 1 126 541
assign 1 126 542
add 1 126 542
assign 1 126 543
new 0 126 543
assign 1 126 544
add 1 126 544
return 1 126 545
assign 1 131 549
new 0 131 549
return 1 131 550
assign 1 135 577
overrideMtdDecGet 0 135 577
assign 1 135 578
addValue 1 135 578
assign 1 135 579
new 0 135 579
assign 1 135 580
addValue 1 135 580
assign 1 135 581
emitNameGet 0 135 581
assign 1 135 582
addValue 1 135 582
assign 1 135 583
new 0 135 583
assign 1 135 584
addValue 1 135 584
assign 1 135 585
addValue 1 135 585
assign 1 135 586
new 0 135 586
assign 1 135 587
addValue 1 135 587
assign 1 135 588
addValue 1 135 588
assign 1 135 589
new 0 135 589
assign 1 135 590
addValue 1 135 590
addValue 1 135 591
assign 1 136 592
new 0 136 592
assign 1 136 593
addValue 1 136 593
assign 1 136 594
addValue 1 136 594
assign 1 136 595
new 0 136 595
assign 1 136 596
addValue 1 136 596
assign 1 136 597
addValue 1 136 597
assign 1 136 598
new 0 136 598
assign 1 136 599
addValue 1 136 599
addValue 1 136 600
assign 1 138 601
new 0 138 601
assign 1 138 602
addValue 1 138 602
addValue 1 138 603
assign 1 142 618
new 0 142 618
assign 1 142 619
libNameGet 0 142 619
assign 1 142 620
relEmitName 1 142 620
assign 1 142 621
add 1 142 621
assign 1 142 622
new 0 142 622
assign 1 142 623
add 1 142 623
assign 1 142 624
heldGet 0 142 624
assign 1 142 625
literalValueGet 0 142 625
assign 1 142 626
add 1 142 626
assign 1 142 627
new 0 142 627
assign 1 142 628
add 1 142 628
return 1 142 629
assign 1 146 643
new 0 146 643
assign 1 146 644
libNameGet 0 146 644
assign 1 146 645
relEmitName 1 146 645
assign 1 146 646
add 1 146 646
assign 1 146 647
new 0 146 647
assign 1 146 648
add 1 146 648
assign 1 146 649
heldGet 0 146 649
assign 1 146 650
literalValueGet 0 146 650
assign 1 146 651
add 1 146 651
assign 1 146 652
new 0 146 652
assign 1 146 653
add 1 146 653
return 1 146 654
assign 1 151 682
new 0 151 682
assign 1 151 683
libNameGet 0 151 683
assign 1 151 684
relEmitName 1 151 684
assign 1 151 685
add 1 151 685
assign 1 151 686
new 0 151 686
assign 1 151 687
add 1 151 687
assign 1 151 688
add 1 151 688
assign 1 151 689
new 0 151 689
assign 1 151 690
add 1 151 690
assign 1 151 691
add 1 151 691
assign 1 151 692
new 0 151 692
assign 1 151 693
add 1 151 693
return 1 151 694
assign 1 153 696
new 0 153 696
assign 1 153 697
libNameGet 0 153 697
assign 1 153 698
relEmitName 1 153 698
assign 1 153 699
add 1 153 699
assign 1 153 700
new 0 153 700
assign 1 153 701
add 1 153 701
assign 1 153 702
add 1 153 702
assign 1 153 703
new 0 153 703
assign 1 153 704
add 1 153 704
assign 1 153 705
add 1 153 705
assign 1 153 706
new 0 153 706
assign 1 153 707
add 1 153 707
return 1 153 708
assign 1 157 715
new 0 157 715
assign 1 157 716
add 1 157 716
assign 1 157 717
new 0 157 717
assign 1 157 718
add 1 157 718
return 1 157 719
getInt 2 162 729
assign 1 163 730
toHexString 1 163 730
assign 1 164 731
new 0 164 731
assign 1 164 732
begins 1 164 732
assign 1 165 734
new 0 165 734
assign 1 165 735
substring 1 165 735
assign 1 166 736
new 0 166 736
addValue 1 166 737
assign 1 168 739
new 0 168 739
assign 1 168 740
once 0 168 740
addValue 1 168 741
addValue 1 169 742
assign 1 175 749
new 0 175 749
assign 1 175 750
add 1 175 750
assign 1 175 751
add 1 175 751
return 1 175 752
assign 1 179 756
new 0 179 756
return 1 179 757
assign 1 183 780
new 0 183 780
assign 1 183 781
add 1 183 781
assign 1 183 782
new 0 183 782
assign 1 183 783
add 1 183 783
assign 1 183 784
add 1 183 784
assign 1 184 785
new 0 184 785
assign 1 184 786
addValue 1 184 786
assign 1 184 787
addValue 1 184 787
assign 1 184 788
new 0 184 788
assign 1 184 789
addValue 1 184 789
addValue 1 184 790
assign 1 185 791
new 0 185 791
assign 1 185 792
addValue 1 185 792
addValue 1 185 793
assign 1 186 794
new 0 186 794
assign 1 186 795
addValue 1 186 795
assign 1 186 796
outputPlatformGet 0 186 796
assign 1 186 797
nameGet 0 186 797
assign 1 186 798
addValue 1 186 798
assign 1 186 799
new 0 186 799
assign 1 186 800
addValue 1 186 800
addValue 1 186 801
assign 1 188 802
new 0 188 802
return 1 188 803
assign 1 192 807
new 0 192 807
return 1 192 808
assign 1 196 814
new 0 196 814
assign 1 196 815
once 0 196 815
assign 1 196 816
add 1 196 816
return 1 196 817
assign 1 200 821
getLibOutput 0 200 821
return 1 200 822
assign 1 215 887
undef 1 215 892
assign 1 216 893
libNameGet 0 216 893
assign 1 217 894
new 0 217 894
assign 1 217 895
sizeGet 0 217 895
assign 1 217 896
add 1 217 896
assign 1 217 897
new 0 217 897
assign 1 217 898
add 1 217 898
assign 1 217 899
add 1 217 899
assign 1 217 900
add 1 217 900
assign 1 218 901
new 0 218 901
assign 1 218 902
sizeGet 0 218 902
assign 1 218 903
add 1 218 903
assign 1 218 904
new 0 218 904
assign 1 218 905
add 1 218 905
assign 1 218 906
add 1 218 906
assign 1 218 907
add 1 218 907
assign 1 219 908
parentGet 0 219 908
assign 1 219 909
addStep 1 219 909
assign 1 220 910
parentGet 0 220 910
assign 1 220 911
addStep 1 220 911
assign 1 221 912
parentGet 0 221 912
assign 1 221 913
fileGet 0 221 913
assign 1 221 914
existsGet 0 221 914
assign 1 221 915
not 0 221 920
assign 1 222 921
parentGet 0 222 921
assign 1 222 922
fileGet 0 222 922
makeDirs 0 222 923
assign 1 224 925
fileGet 0 224 925
assign 1 224 926
writerGet 0 224 926
assign 1 224 927
open 0 224 927
assign 1 225 928
fileGet 0 225 928
assign 1 225 929
writerGet 0 225 929
assign 1 225 930
open 0 225 930
assign 1 227 931
new 0 227 931
write 1 227 932
assign 1 228 933
new 0 228 933
write 1 228 934
assign 1 229 935
new 0 229 935
write 1 229 936
assign 1 230 937
new 0 230 937
write 1 230 938
assign 1 232 939
new 0 232 939
write 1 232 940
assign 1 233 941
new 0 233 941
write 1 233 942
assign 1 239 943
paramsGet 0 239 943
assign 1 239 944
new 0 239 944
assign 1 239 945
has 1 239 945
assign 1 241 947
paramsGet 0 241 947
assign 1 241 948
new 0 241 948
assign 1 241 949
get 1 241 949
assign 1 241 950
iteratorGet 0 0 950
assign 1 241 953
hasNextGet 0 241 953
assign 1 241 955
nextGet 0 241 955
assign 1 243 956
apNew 1 243 956
assign 1 243 957
fileGet 0 243 957
assign 1 244 958
readerGet 0 244 958
assign 1 244 959
open 0 244 959
assign 1 244 960
readString 0 244 960
assign 1 245 961
readerGet 0 245 961
close 0 245 962
write 1 247 963
assign 1 250 970
paramsGet 0 250 970
assign 1 250 971
new 0 250 971
assign 1 250 972
has 1 250 972
assign 1 252 974
paramsGet 0 252 974
assign 1 252 975
new 0 252 975
assign 1 252 976
get 1 252 976
assign 1 252 977
iteratorGet 0 0 977
assign 1 252 980
hasNextGet 0 252 980
assign 1 252 982
nextGet 0 252 982
assign 1 254 983
apNew 1 254 983
assign 1 254 984
fileGet 0 254 984
assign 1 255 985
readerGet 0 255 985
assign 1 255 986
open 0 255 986
assign 1 255 987
readString 0 255 987
assign 1 256 988
readerGet 0 256 988
close 0 256 989
write 1 258 990
begin 1 265 1001
prepHeaderOutput 0 266 1002
assign 1 271 1032
undef 1 271 1037
assign 1 272 1038
new 0 272 1038
assign 1 273 1039
parentGet 0 273 1039
assign 1 273 1040
fileGet 0 273 1040
assign 1 273 1041
existsGet 0 273 1041
assign 1 273 1042
not 0 273 1047
assign 1 274 1048
parentGet 0 274 1048
assign 1 274 1049
fileGet 0 274 1049
makeDirs 0 274 1050
assign 1 276 1052
fileGet 0 276 1052
assign 1 276 1053
writerGet 0 276 1053
assign 1 276 1054
open 0 276 1054
assign 1 278 1055
new 0 278 1055
write 1 278 1056
increment 0 279 1057
assign 1 280 1058
paramsGet 0 280 1058
assign 1 280 1059
new 0 280 1059
assign 1 280 1060
has 1 280 1060
assign 1 281 1062
paramsGet 0 281 1062
assign 1 281 1063
new 0 281 1063
assign 1 281 1064
get 1 281 1064
assign 1 281 1065
iteratorGet 0 0 1065
assign 1 281 1068
hasNextGet 0 281 1068
assign 1 281 1070
nextGet 0 281 1070
assign 1 282 1071
apNew 1 282 1071
assign 1 282 1072
fileGet 0 282 1072
assign 1 283 1073
readerGet 0 283 1073
assign 1 283 1074
open 0 283 1074
assign 1 283 1075
readString 0 283 1075
assign 1 284 1076
readerGet 0 284 1076
close 0 284 1077
assign 1 285 1078
countLines 1 285 1078
addValue 1 285 1079
write 1 286 1080
return 1 292 1088
assign 1 297 1094
new 0 297 1094
write 1 297 1095
close 0 298 1096
assign 1 299 1097
assign 1 301 1098
new 0 301 1098
write 1 301 1099
assign 1 303 1100
new 0 303 1100
write 1 303 1101
close 0 304 1102
close 0 305 1103
assign 1 310 1108
new 0 310 1108
return 1 310 1109
assign 1 314 1116
new 0 314 1116
assign 1 314 1117
addValue 1 314 1117
assign 1 314 1118
addValue 1 314 1118
assign 1 314 1119
new 0 314 1119
addValue 1 314 1120
assign 1 319 1142
heldGet 0 319 1142
assign 1 319 1143
synGet 0 319 1143
assign 1 320 1144
ptyListGet 0 320 1144
assign 1 322 1145
emitNameGet 0 322 1145
assign 1 322 1146
addValue 1 322 1146
assign 1 322 1147
new 0 322 1147
addValue 1 322 1148
assign 1 324 1149
new 0 324 1149
assign 1 325 1150
iteratorGet 0 0 1150
assign 1 325 1153
hasNextGet 0 325 1153
assign 1 325 1155
nextGet 0 325 1155
assign 1 327 1157
new 0 327 1157
assign 1 329 1160
new 0 329 1160
addValue 1 329 1161
assign 1 331 1163
addValue 1 331 1163
assign 1 331 1164
new 0 331 1164
assign 1 331 1165
addValue 1 331 1165
assign 1 331 1166
nameGet 0 331 1166
assign 1 331 1167
addValue 1 331 1167
addValue 1 331 1168
assign 1 335 1174
new 0 335 1174
assign 1 335 1175
addValue 1 335 1175
addValue 1 335 1176
assign 1 340 1194
new 0 340 1194
assign 1 342 1195
new 0 342 1195
assign 1 342 1196
emitNameGet 0 342 1196
assign 1 342 1197
add 1 342 1197
assign 1 342 1198
new 0 342 1198
assign 1 342 1199
add 1 342 1199
assign 1 344 1200
new 0 344 1200
assign 1 344 1201
addValue 1 344 1201
assign 1 344 1202
emitNameGet 0 344 1202
assign 1 344 1203
addValue 1 344 1203
assign 1 344 1204
new 0 344 1204
assign 1 344 1205
addValue 1 344 1205
assign 1 344 1206
addValue 1 344 1206
assign 1 344 1207
new 0 344 1207
addValue 1 344 1208
return 1 346 1209
assign 1 350 1218
libNameGet 0 350 1218
assign 1 350 1219
relEmitName 1 350 1219
assign 1 351 1220
new 0 351 1220
assign 1 351 1221
add 1 351 1221
assign 1 351 1222
new 0 351 1222
assign 1 351 1223
add 1 351 1223
return 1 352 1224
assign 1 356 1281
getClassConfig 1 356 1281
assign 1 356 1282
libNameGet 0 356 1282
assign 1 356 1283
relEmitName 1 356 1283
assign 1 357 1284
heldGet 0 357 1284
assign 1 357 1285
namepathGet 0 357 1285
assign 1 357 1286
getClassConfig 1 357 1286
assign 1 358 1287
getInitialInst 1 358 1287
assign 1 360 1288
overrideMtdDecGet 0 360 1288
assign 1 360 1289
addValue 1 360 1289
assign 1 360 1290
new 0 360 1290
assign 1 360 1291
addValue 1 360 1291
assign 1 360 1292
emitNameGet 0 360 1292
assign 1 360 1293
addValue 1 360 1293
assign 1 360 1294
new 0 360 1294
assign 1 360 1295
addValue 1 360 1295
assign 1 360 1296
addValue 1 360 1296
assign 1 360 1297
new 0 360 1297
assign 1 360 1298
addValue 1 360 1298
assign 1 360 1299
addValue 1 360 1299
assign 1 360 1300
new 0 360 1300
assign 1 360 1301
addValue 1 360 1301
addValue 1 360 1302
assign 1 361 1303
new 0 361 1303
assign 1 362 1304
emitNameGet 0 362 1304
assign 1 362 1305
notEquals 1 362 1305
assign 1 363 1307
new 0 363 1307
assign 1 363 1308
formCast 3 363 1308
assign 1 366 1310
addValue 1 366 1310
assign 1 366 1311
new 0 366 1311
assign 1 366 1312
addValue 1 366 1312
assign 1 366 1313
addValue 1 366 1313
assign 1 366 1314
new 0 366 1314
assign 1 366 1315
addValue 1 366 1315
addValue 1 366 1316
assign 1 368 1317
new 0 368 1317
assign 1 368 1318
addValue 1 368 1318
addValue 1 368 1319
assign 1 371 1320
overrideMtdDecGet 0 371 1320
assign 1 371 1321
addValue 1 371 1321
assign 1 371 1322
new 0 371 1322
assign 1 371 1323
addValue 1 371 1323
assign 1 371 1324
addValue 1 371 1324
assign 1 371 1325
new 0 371 1325
assign 1 371 1326
addValue 1 371 1326
assign 1 371 1327
emitNameGet 0 371 1327
assign 1 371 1328
addValue 1 371 1328
assign 1 371 1329
new 0 371 1329
assign 1 371 1330
addValue 1 371 1330
assign 1 371 1331
addValue 1 371 1331
assign 1 371 1332
new 0 371 1332
assign 1 371 1333
addValue 1 371 1333
addValue 1 371 1334
assign 1 373 1335
new 0 373 1335
assign 1 373 1336
addValue 1 373 1336
assign 1 373 1337
addValue 1 373 1337
assign 1 373 1338
new 0 373 1338
assign 1 373 1339
addValue 1 373 1339
addValue 1 373 1340
assign 1 375 1341
new 0 375 1341
assign 1 375 1342
addValue 1 375 1342
addValue 1 375 1343
return 1 0 1347
assign 1 0 1350
return 1 0 1354
assign 1 0 1357
return 1 0 1361
assign 1 0 1364
return 1 0 1368
assign 1 0 1371
return 1 0 1375
assign 1 0 1378
return 1 0 1382
assign 1 0 1385
return 1 0 1389
assign 1 0 1392
return 1 0 1396
assign 1 0 1399
return 1 0 1403
assign 1 0 1406
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1073009537: return bem_beginNs_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 245121133: return bem_classHeadBodyGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1926693913: return bem_synEmitPathGet_0();
case -1052944126: return bem_csynGet_0();
case -1910715228: return bem_libEmitNameGet_0();
case 1774940957: return bem_toString_0();
case -157262622: return bem_heowGet_0();
case -1413054881: return bem_smnlcsGet_0();
case -797225458: return bem_dynMethodsGet_0();
case -622039562: return bem_intNpGet_0();
case -1923547459: return bem_boolCcGet_0();
case -729571811: return bem_serializeToString_0();
case 498080472: return bem_mnodeGet_0();
case 2001798761: return bem_nlGet_0();
case -1841706211: return bem_returnTypeGet_0();
case -2039613615: return bem_instanceNotEqualGet_0();
case 1240611285: return bem_onceDecsGet_0();
case -206157822: return bem_coanyiantReturnsGet_0();
case -1727672536: return bem_propDecGet_0();
case 916491491: return bem_emitLib_0();
case -722876119: return bem_buildClassInfo_0();
case -402158238: return bem_inFilePathedGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case 1327064356: return bem_methodBodyGet_0();
case -786424307: return bem_tagGet_0();
case 1529527065: return bem_onceCountGet_0();
case -1081275759: return bem_classesInDepthOrderGet_0();
case -1369896794: return bem_objectNpGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case -1064889660: return bem_trueValueGet_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 104713553: return bem_new_0();
case -1795655423: return bem_propertyDecsGet_0();
case 89706405: return bem_ccCacheGet_0();
case 962646066: return bem_shlibeGet_0();
case -1317806639: return bem_baseMtdDecGet_0();
case 362974009: return bem_parentConfGet_0();
case -1717783419: return bem_deopGet_0();
case -902412214: return bem_classCallsGet_0();
case -220901978: return bem_emitLangGet_0();
case -1498619679: return bem_getLibOutput_0();
case -946095539: return bem_mainInClassGet_0();
case -357666679: return bem_heopGet_0();
case -1241388883: return bem_lastMethodBodySizeGet_0();
case -101343106: return bem_nativeCSlotsGet_0();
case -1775041721: return bem_deonGet_0();
case 2055025483: return bem_serializeContents_0();
case 5583797: return bem_maxDynArgsGet_0();
case -248786900: return bem_afterCast_0();
case -314718434: return bem_print_0();
case -681402717: return bem_boolTypeGet_0();
case -414924981: return bem_heonGet_0();
case 1820417453: return bem_create_0();
case -388723214: return bem_preClassGet_0();
case -991179882: return bem_qGet_0();
case -1109279973: return bem_spropDecGet_0();
case -1487140092: return bem_classEndGet_0();
case -727049506: return bem_exceptDecGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 361542143: return bem_classEmitsGet_0();
case 1563880876: return bem_prepHeaderOutput_0();
case -1449942744: return bem_instanceEqualGet_0();
case 1859739893: return bem_methodsGet_0();
case 236269941: return bem_ccMethodsGet_0();
case -1786051763: return bem_methodCatchGet_0();
case -1354714650: return bem_copy_0();
case -2085643372: return bem_stringNpGet_0();
case -1500143225: return bem_useDynMethodsGet_0();
case -1831751774: return bem_cnodeGet_0();
case 287040793: return bem_hashGet_0();
case 57260628: return bem_getClassOutput_0();
case -1755995201: return bem_transGet_0();
case -991255330: return bem_mainStartGet_0();
case -493012039: return bem_buildGet_0();
case 604504089: return bem_falseValueGet_0();
case -644675716: return bem_ntypesGet_0();
case -4647121: return bem_doEmit_0();
case 1102720804: return bem_classNameGet_0();
case -944442837: return bem_classConfGet_0();
case 1372235405: return bem_superCallsGet_0();
case -103017121: return bem_runtimeInitGet_0();
case -291757594: return bem_headExtGet_0();
case -254265568: return bem_buildPropList_0();
case -1703922349: return bem_fullLibEmitNameGet_0();
case -1747980150: return bem_smnlecsGet_0();
case 772789066: return bem_libEmitPathGet_0();
case 1177623581: return bem_callNamesGet_0();
case 36542021: return bem_mainEndGet_0();
case -397629001: return bem_maxSpillArgsLenGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case -1152064310: return bem_instOfGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case -294732055: return bem_floatNpGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case 1178070402: return bem_fileExtGet_0();
case 1312373307: return bem_buildCreate_0();
case -1711936384: return bem_baseSmtdDecGet_0();
case 1181505319: return bem_buildInitial_0();
case -229958684: return bem_constGet_0();
case -955058175: return bem_lastMethodBodyLinesGet_0();
case -1607412815: return bem_endNs_0();
case -845792839: return bem_iteratorGet_0();
case -378762597: return bem_boolNpGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1074463609: return bem_saveSyns_0();
case 483359873: return bem_superNameGet_0();
case -1308786538: return bem_echo_0();
case -628036310: return bem_lastMethodsSizeGet_0();
case -1742138840: return bem_invpGet_0();
case 1380285640: return bem_objectCcGet_0();
case -1947619572: return bem_msynGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1638160588: return bem_lineCountGet_0();
case -1517379362: return bem_deowGet_0();
case -1967844855: return bem_initialDecGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 256203386: return bem_classHeadBodySet_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -1053807407: return bem_trueValueSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2144776371: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case -1915611660: return bem_synEmitPathSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case -1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -280675341: return bem_headExtSet_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case -610957309: return bem_intNpSet_1(bevd_0);
case -1763959468: return bem_deonSet_1(bevd_0);
case -386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1731056587: return bem_invpSet_1(bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case -891329961: return bem_classCallsSet_1(bevd_0);
case -1887784556: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -980097629: return bem_qSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1820669521: return bem_cnodeSet_1(bevd_0);
case -146180369: return bem_heowSet_1(bevd_0);
case -945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case -1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -90260853: return bem_nativeCSlotsSet_1(bevd_0);
case -1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case -1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case -1706701166: return bem_deopSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case -596365949: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1912465206: return bem_boolCcSet_1(bevd_0);
case -377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case -943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -933360584: return bem_classConfSet_1(bevd_0);
case 1550716690: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case -1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case -16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case -1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1936537319: return bem_msynSet_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1438860491: return bem_instanceEqualSet_1(bevd_0);
case -1899632975: return bem_libEmitNameSet_1(bevd_0);
case -478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1506297109: return bem_deowSet_1(bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -193407613: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -391075985: return bem_inFilePathedSet_1(bevd_0);
case -36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1041861873: return bem_csynSet_1(bevd_0);
case -1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -403842728: return bem_heonSet_1(bevd_0);
case -715967253: return bem_exceptDecSet_1(bevd_0);
case -1830623958: return bem_returnTypeSet_1(bevd_0);
case -1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case -1774969510: return bem_methodCatchSet_1(bevd_0);
case 2118534024: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case -1358814541: return bem_objectNpSet_1(bevd_0);
case -1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case -2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case -65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
case -346584426: return bem_heopSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -551679722: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 1900236781: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -722876116: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -551679721: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 886529146: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case -316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
}
