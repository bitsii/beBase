package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerStack bevs_inst;
public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_5_ContainerStack bem_new_0() throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_push_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
if (bevp_holder == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 41 */
 else  /* Line: 42 */ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 44 */
} /* Line: 40 */
 else  /* Line: 39 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_4_tmpany_phold = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 49 */
 else  /* Line: 50 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 51 */
} /* Line: 39 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_pop_0() throws Throwable {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
return bevp_top;
} /* Line: 59 */
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 63 */ {
bevp_holder = bevl_last;
} /* Line: 64 */
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
return null;
} /* Line: 67 */
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_2_6_6_SystemObject bem_peek_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 76 */ {
return bevp_top;
} /* Line: 77 */
bevt_1_tmpany_phold = bevp_top.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
this.bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_pop_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_pop.bevi_bool) /* Line: 95 */ {
bevt_0_tmpany_phold = this.bem_pop_0();
return bevt_0_tmpany_phold;
} /* Line: 96 */
bevt_1_tmpany_phold = this.bem_peek_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
this.bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() throws Throwable {
return bevp_holder;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {33, 39, 39, 40, 40, 41, 43, 44, 46, 46, 46, 47, 47, 48, 48, 49, 51, 53, 54, 58, 58, 59, 61, 62, 63, 63, 64, 66, 66, 67, 69, 70, 71, 72, 76, 76, 77, 79, 79, 83, 83, 87, 91, 91, 96, 96, 98, 98, 102, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 22, 27, 28, 33, 34, 37, 38, 42, 43, 48, 49, 50, 51, 52, 53, 56, 59, 60, 69, 74, 75, 77, 78, 79, 84, 85, 87, 92, 93, 95, 96, 97, 98, 103, 108, 109, 111, 112, 116, 121, 124, 129, 130, 136, 137, 139, 140, 143, 147, 150, 154, 157, 161, 164};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 33 12
new 0 33 12
assign 1 39 22
undef 1 39 27
assign 1 40 28
undef 1 40 33
assign 1 41 34
new 0 41 34
assign 1 43 37
assign 1 44 38
assign 1 46 42
nextGet 0 46 42
assign 1 46 43
undef 1 46 48
assign 1 47 49
new 0 47 49
nextSet 1 47 50
assign 1 48 51
nextGet 0 48 51
priorSet 1 48 52
assign 1 49 53
nextGet 0 49 53
assign 1 51 56
nextGet 0 51 56
heldSet 1 53 59
assign 1 54 60
increment 0 54 60
assign 1 58 69
undef 1 58 74
return 1 59 75
assign 1 61 77
assign 1 62 78
priorGet 0 62 78
assign 1 63 79
undef 1 63 84
assign 1 64 85
assign 1 66 87
undef 1 66 92
return 1 67 93
assign 1 69 95
heldGet 0 69 95
heldSet 1 70 96
assign 1 71 97
decrement 0 71 97
return 1 72 98
assign 1 76 103
undef 1 76 108
return 1 77 109
assign 1 79 111
heldGet 0 79 111
return 1 79 112
assign 1 83 116
undef 1 83 121
return 1 83 121
push 1 87 124
assign 1 91 129
pop 0 91 129
return 1 91 130
assign 1 96 136
pop 0 96 136
return 1 96 137
assign 1 98 139
peek 0 98 139
return 1 98 140
push 1 102 143
return 1 0 147
assign 1 0 150
return 1 0 154
assign 1 0 157
return 1 0 161
assign 1 0 164
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 98246023: return bem_get_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 106851778: return bem_pop_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -992112052: return bem_peek_0();
case 789252923: return bem_holderGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case -988612302: return bem_topGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -977530049: return bem_topSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case 800335176: return bem_holderSet_1(bevd_0);
case -976921524: return bem_push_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerStack();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerStack.bevs_inst = (BEC_2_9_5_ContainerStack)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerStack.bevs_inst;
}
}
