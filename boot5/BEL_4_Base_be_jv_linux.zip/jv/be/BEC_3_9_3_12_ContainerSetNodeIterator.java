package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(0));
public static BEC_3_9_3_12_ContainerSetNodeIterator bevs_inst;
public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_set = beva__set;
bevp_slots = bevp_set.bem_slotsGet_0();
bevp_modu = bevp_slots.bem_sizeGet_0();
bevp_current = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_containerGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 657 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 657 */ {
bevt_2_tmpany_phold = bevp_slots.bem_get_1(bevl_i);
if (bevt_2_tmpany_phold == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 658 */ {
bevp_current = bevl_i;
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 660 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 657 */
 else  /* Line: 657 */ {
break;
} /* Line: 657 */
} /* Line: 657 */
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 667 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 667 */ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 669 */ {
bevt_2_tmpany_phold = bevo_0;
bevp_current = bevl_i.bem_add_1(bevt_2_tmpany_phold);
return bevl_toRet;
} /* Line: 671 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 667 */
 else  /* Line: 667 */ {
break;
} /* Line: 667 */
} /* Line: 667 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delete_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_1;
bevl_i = bevp_current.bem_subtract_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bevo_2;
if (bevl_i.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 679 */ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 681 */ {
bevt_5_tmpany_phold = bevl_sn.bem_keyGet_0();
bevt_4_tmpany_phold = bevp_set.bem_delete_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 682 */ {
bevp_current = bevl_i;
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 684 */
} /* Line: 682 */
} /* Line: 681 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_setGet_0() throws Throwable {
return bevp_set;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_setSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {644, 645, 646, 647, 653, 657, 657, 657, 658, 658, 658, 659, 660, 660, 657, 663, 663, 667, 667, 667, 668, 669, 669, 670, 670, 671, 667, 674, 678, 678, 679, 679, 679, 680, 681, 681, 682, 682, 683, 684, 684, 688, 688, 693, 697, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 23, 32, 35, 40, 41, 42, 47, 48, 49, 50, 52, 58, 59, 67, 70, 75, 76, 77, 82, 83, 84, 85, 87, 93, 106, 107, 108, 109, 114, 115, 116, 121, 122, 123, 125, 126, 127, 131, 132, 135, 138, 141, 144, 148, 151, 155, 158, 162, 165};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 644 16
assign 1 645 17
slotsGet 0 645 17
assign 1 646 18
sizeGet 0 646 18
assign 1 647 19
new 0 647 19
return 1 653 23
assign 1 657 32
assign 1 657 35
lesser 1 657 40
assign 1 658 41
get 1 658 41
assign 1 658 42
def 1 658 47
assign 1 659 48
assign 1 660 49
new 0 660 49
return 1 660 50
assign 1 657 52
increment 0 657 52
assign 1 663 58
new 0 663 58
return 1 663 59
assign 1 667 67
assign 1 667 70
lesser 1 667 75
assign 1 668 76
get 1 668 76
assign 1 669 77
def 1 669 82
assign 1 670 83
new 0 670 83
assign 1 670 84
add 1 670 84
return 1 671 85
assign 1 667 87
increment 0 667 87
return 1 674 93
assign 1 678 106
new 0 678 106
assign 1 678 107
subtract 1 678 107
assign 1 679 108
new 0 679 108
assign 1 679 109
greaterEquals 1 679 114
assign 1 680 115
get 1 680 115
assign 1 681 116
def 1 681 121
assign 1 682 122
keyGet 0 682 122
assign 1 682 123
delete 1 682 123
assign 1 683 125
assign 1 684 126
new 0 684 126
return 1 684 127
assign 1 688 131
new 0 688 131
return 1 688 132
return 1 693 135
return 1 697 138
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
return 1 0 162
assign 1 0 165
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 1392959045: return bem_setGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1586230380: return bem_moduGet_0();
case 104713553: return bem_new_0();
case -1471882487: return bem_nodeIteratorIteratorGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 1194623572: return bem_nextGet_0();
case 819712668: return bem_delete_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case 108485850: return bem_hasNextGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1575148127: return bem_moduSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1404041298: return bem_setSet_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator.bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_12_ContainerSetNodeIterator.bevs_inst;
}
}
