package be;
/* IO:File: source/build/Pass4.be */
public final class BEC_3_5_5_5_BuildVisitPass4 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass4() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass4_bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static BEC_3_5_5_5_BuildVisitPass4 bevs_inst;
public BEC_3_5_5_5_BuildVisitPass4 bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_6_TextString bevl_nps = null;
BEC_2_5_4_BuildNode bevl_nxn = null;
BEC_2_5_4_BuildNode bevl_nxnn = null;
BEC_2_5_4_BuildNode bevl_first = null;
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 21 */ {
bevt_5_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_5_tmpany_phold.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 21 */ {
if (bevl_nnode == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 21 */
 else  /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 21 */ {
bevt_9_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 21 */
 else  /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 21 */ {
if (bevl_nps == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 22 */ {
bevl_nps = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 23 */
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevl_nps.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_17_tmpany_phold = bevl_nxn.bem_typenameGet_0();
bevt_18_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_17_tmpany_phold.bevi_int != bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 27 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_3_5_5_5_BuildVisitPass4_bels_0));
bevt_19_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_20_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 28 */
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 31 */ {
beva_node.bem_delete_0();
} /* Line: 32 */
 else  /* Line: 33 */ {
bevl_first = beva_node;
} /* Line: 34 */
bevl_nnode.bem_delete_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 38 */
 else  /* Line: 21 */ {
break;
} /* Line: 21 */
} /* Line: 21 */
if (bevl_first == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_23_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_tmpany_phold);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_26_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_26_tmpany_phold.bevi_int == bevt_27_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 43 */
 else  /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 43 */ {
bevt_28_tmpany_phold = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_tmpany_phold);
beva_node.bem_delete_0();
} /* Line: 45 */
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_tmpany_phold = bevl_first.bem_nextDescendGet_0();
return bevt_29_tmpany_phold;
} /* Line: 49 */
bevt_30_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 20, 21, 21, 21, 21, 21, 21, 0, 0, 0, 21, 21, 21, 21, 0, 0, 0, 22, 22, 23, 25, 25, 25, 25, 26, 27, 27, 0, 27, 27, 27, 27, 0, 0, 28, 28, 28, 30, 31, 31, 32, 34, 36, 37, 38, 40, 40, 41, 41, 42, 43, 43, 43, 43, 43, 43, 0, 0, 0, 44, 44, 45, 47, 48, 49, 49, 51, 51};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 51, 54, 55, 56, 61, 62, 67, 68, 71, 75, 78, 79, 80, 85, 86, 89, 93, 96, 101, 102, 104, 105, 106, 107, 108, 109, 114, 115, 118, 119, 120, 125, 126, 129, 133, 134, 135, 137, 138, 143, 144, 147, 149, 150, 151, 157, 162, 163, 164, 165, 166, 171, 172, 173, 174, 179, 180, 183, 187, 190, 191, 192, 194, 195, 196, 197, 199, 200};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 16 10
assign 1 20 51
nextPeerGet 0 20 51
assign 1 21 54
typenameGet 0 21 54
assign 1 21 55
IDGet 0 21 55
assign 1 21 56
equals 1 21 61
assign 1 21 62
def 1 21 67
assign 1 0 68
assign 1 0 71
assign 1 0 75
assign 1 21 78
typenameGet 0 21 78
assign 1 21 79
COLONGet 0 21 79
assign 1 21 80
equals 1 21 85
assign 1 0 86
assign 1 0 89
assign 1 0 93
assign 1 22 96
undef 1 22 101
assign 1 23 102
new 0 23 102
assign 1 25 104
heldGet 0 25 104
assign 1 25 105
add 1 25 105
assign 1 25 106
heldGet 0 25 106
assign 1 25 107
add 1 25 107
assign 1 26 108
nextPeerGet 0 26 108
assign 1 27 109
undef 1 27 114
assign 1 0 115
assign 1 27 118
typenameGet 0 27 118
assign 1 27 119
IDGet 0 27 119
assign 1 27 120
notEquals 1 27 125
assign 1 0 126
assign 1 0 129
assign 1 28 133
new 0 28 133
assign 1 28 134
new 2 28 134
throw 1 28 135
assign 1 30 137
nextPeerGet 0 30 137
assign 1 31 138
def 1 31 143
delete 0 32 144
assign 1 34 147
delete 0 36 149
assign 1 37 150
assign 1 38 151
assign 1 40 157
def 1 40 162
assign 1 41 163
NAMEPATHGet 0 41 163
typenameSet 1 41 164
assign 1 42 165
new 0 42 165
assign 1 43 166
def 1 43 171
assign 1 43 172
typenameGet 0 43 172
assign 1 43 173
IDGet 0 43 173
assign 1 43 174
equals 1 43 179
assign 1 0 180
assign 1 0 183
assign 1 0 187
assign 1 44 190
heldGet 0 44 190
assign 1 44 191
add 1 44 191
delete 0 45 192
fromString 1 47 194
heldSet 1 48 195
assign 1 49 196
nextDescendGet 0 49 196
return 1 49 197
assign 1 51 199
nextDescendGet 0 51 199
return 1 51 200
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass4_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass4_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass4();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass4.bevs_inst = (BEC_3_5_5_5_BuildVisitPass4)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass4.bevs_inst;
}
}
