package be;
/* IO:File: source/extended/Serialize.be */
public final class BEC_2_6_10_SystemSerializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemSerializer() { }
private static byte[] becc_BEC_2_6_10_SystemSerializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_10_SystemSerializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_0 = {0x7C};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_1 = {0x23};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_2 = {0x26};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_3 = {0x40};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_4 = {0x3B};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_5 = {0x3F};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_6 = {0x5E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_7 = {0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x43,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x73,0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_8 = {0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_9 = {0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65,0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_10 = {0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x54,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_11 = {};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_12 = {0x70,0x6F,0x73,0x74,0x44,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_13 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_14 = {0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x46,0x72,0x6F,0x6D,0x53,0x74,0x72,0x69,0x6E,0x67,0x4E,0x65,0x77};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_15 = {0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x46,0x72,0x6F,0x6D,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
public static BEC_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_inst;

public static BET_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_type;

public BEC_2_4_6_TextString bevp_group;
public BEC_2_4_6_TextString bevp_defineReference;
public BEC_2_4_6_TextString bevp_getReference;
public BEC_2_4_6_TextString bevp_constructString;
public BEC_2_4_6_TextString bevp_nullMark;
public BEC_2_4_6_TextString bevp_getClassTag;
public BEC_2_4_6_TextString bevp_shift;
public BEC_2_4_6_TextString bevp_defineClassTag;
public BEC_2_4_6_TextString bevp_multiNullMark;
public BEC_2_4_6_TextString bevp_endGroup;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_6_3_EncodeHex bevp_encoder;
public BEC_2_5_4_LogicBool bevp_saveIdentity;
public BEC_2_6_10_SystemSerializer bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_2));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_3));
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_5));
bevt_6_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_6));
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bem_new_10(bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph, bevt_6_ta_ph, bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_new_10(BEC_2_4_6_TextString beva__group, BEC_2_4_6_TextString beva__defineReference, BEC_2_4_6_TextString beva__getReference, BEC_2_4_6_TextString beva__constructString, BEC_2_4_6_TextString beva__nullMark, BEC_2_4_6_TextString beva__getClassTag, BEC_2_4_6_TextString beva__shift, BEC_2_4_6_TextString beva__defineClassTag, BEC_2_4_6_TextString beva__multiNullMark, BEC_2_4_6_TextString beva__endGroup) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevp_group = beva__group;
bevp_defineReference = beva__defineReference;
bevp_getReference = beva__getReference;
bevp_constructString = beva__constructString;
bevp_nullMark = beva__nullMark;
bevp_getClassTag = beva__getClassTag;
bevp_shift = beva__shift;
bevp_defineClassTag = beva__defineClassTag;
bevp_multiNullMark = beva__multiNullMark;
bevp_endGroup = beva__endGroup;
bevt_6_ta_ph = bevp_group.bem_add_1(bevp_defineReference);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_getReference);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_constructString);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevp_nullMark);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_defineClassTag);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_getClassTag);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_shift);
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
bevp_toker = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_7_ta_ph);
bevp_encoder = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevp_saveIdentity = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serialize_1(BEC_2_6_6_SystemObject beva_instance) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bem_serialize_2(beva_instance, bevl_res);
return bevl_res;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serialize_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_instWriter) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_6_10_7_SystemSerializerSession bevt_1_ta_ph = null;
if (beva_instance == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 97*/ {
bevt_1_ta_ph = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_1(beva_instWriter);
bem_serializeI_2(beva_instance, bevt_1_ta_ph);
} /* Line: 98*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeI_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_5_4_LogicBool bevl_dosc = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bem_defineInstance_2(beva_instance, (BEC_3_6_10_7_SystemSerializerSession) beva_session );
bevt_1_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_6_10_SystemSerializer_bels_7));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = beva_instance.bemd_2(-1788833571, bevt_1_ta_ph, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 104*/ {
bevl_dosc = (BEC_2_5_4_LogicBool) beva_instance.bemd_0(-960178757);
} /* Line: 105*/
 else /* Line: 106*/ {
bevl_dosc = be.BECS_Runtime.boolTrue;
} /* Line: 107*/
if (bevl_dosc.bevi_bool)/* Line: 109*/ {
bem_serializeC_2(beva_instance, beva_session);
} /* Line: 110*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeC_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_3_MathInt bevl_multiNull = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevl_instWriter = beva_session.bemd_0(36174612);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = beva_instance.bemd_2(-1788833571, bevt_1_ta_ph, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 117*/ {
bevl_iter = beva_instance.bemd_0(-1097719160);
} /* Line: 118*/
 else /* Line: 119*/ {
bevl_iter = beva_instance.bemd_0(-1139674964);
} /* Line: 120*/
bevt_3_ta_ph = bevl_iter.bemd_0(-1094939461);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 122*/ {
bevl_instWriter.bemd_1(280224614, bevp_group);
while (true)
/* Line: 124*/ {
bevt_4_ta_ph = bevl_iter.bemd_0(-1094939461);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 124*/ {
bevl_i = bevl_iter.bemd_0(-1132747350);
if (bevl_i == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 126*/ {
bevl_multiNull = bevl_multiNull.bem_increment_0();
} /* Line: 128*/
 else /* Line: 129*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_multiNull.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 131*/ {
bevl_instWriter.bemd_1(280224614, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 133*/
 else /* Line: 131*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int == bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 134*/ {
bevl_instWriter.bemd_1(280224614, bevp_nullMark);
bevl_instWriter.bemd_1(280224614, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 137*/
 else /* Line: 131*/ {
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 138*/ {
bevl_instWriter.bemd_1(280224614, bevp_shift);
bevl_instWriter.bemd_1(280224614, bevp_nullMark);
bevt_12_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(280224614, bevt_12_ta_ph);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 142*/
} /* Line: 131*/
} /* Line: 131*/
if (bevp_saveIdentity.bevi_bool) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 144*/ {
bevl_instSerial = null;
} /* Line: 145*/
 else /* Line: 146*/ {
bevt_14_ta_ph = beva_session.bemd_0(1118976952);
bevl_instSerial = (BEC_2_4_3_MathInt) bevt_14_ta_ph.bemd_1(1285128257, bevl_i);
} /* Line: 147*/
if (bevl_instSerial == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 149*/ {
bem_serializeI_2(bevl_i, beva_session);
} /* Line: 151*/
 else /* Line: 152*/ {
bevl_instWriter.bemd_1(280224614, bevp_getReference);
bevt_16_ta_ph = bevl_instSerial.bem_toString_0();
bevl_instWriter.bemd_1(280224614, bevt_16_ta_ph);
} /* Line: 155*/
} /* Line: 149*/
} /* Line: 126*/
 else /* Line: 124*/ {
break;
} /* Line: 124*/
} /* Line: 124*/
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_multiNull.bevi_int == bevt_18_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 160*/ {
bevl_instWriter.bemd_1(280224614, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 162*/
 else /* Line: 160*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 163*/ {
bevl_instWriter.bemd_1(280224614, bevp_nullMark);
bevl_instWriter.bemd_1(280224614, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 166*/
 else /* Line: 160*/ {
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int > bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 167*/ {
bevl_instWriter.bemd_1(280224614, bevp_shift);
bevl_instWriter.bemd_1(280224614, bevp_nullMark);
bevt_23_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(280224614, bevt_23_ta_ph);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 171*/
} /* Line: 160*/
} /* Line: 160*/
bevl_instWriter.bemd_1(280224614, bevp_shift);
bevl_instWriter.bemd_1(280224614, bevp_group);
} /* Line: 174*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineInstance_2(BEC_2_6_6_SystemObject beva_instance, BEC_3_6_10_7_SystemSerializerSession beva_session) throws Throwable {
BEC_2_4_3_MathInt bevl_scount = null;
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_6_TextString bevl_instClass = null;
BEC_2_4_3_MathInt bevl_instClassTag = null;
BEC_2_4_6_TextString bevl_instClassTagStr = null;
BEC_2_4_6_TextString bevl_serializedString = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_6_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_9_11_ContainerIdentityMap bevt_20_ta_ph = null;
bevl_scount = beva_session.bem_serialCountGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevl_scount.bem_add_1(bevt_2_ta_ph);
beva_session.bem_serialCountSet_1(bevt_1_ta_ph);
bevl_instWriter = beva_session.bem_instWriterGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_10_SystemSerializer_bels_9));
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = beva_instance.bemd_2(-1788833571, bevt_4_ta_ph, bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 183*/ {
bevl_instClass = (BEC_2_4_6_TextString) beva_instance.bemd_0(1229780286);
} /* Line: 184*/
 else /* Line: 185*/ {
bevt_6_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_instClass = bevt_6_ta_ph.bem_className_1(beva_instance);
} /* Line: 186*/
bevt_7_ta_ph = beva_session.bem_classTagMapGet_0();
bevl_instClassTag = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bem_get_1(bevl_instClass);
if (bevl_instClassTag == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 189*/ {
bevl_instClassTag = beva_session.bem_classTagCountGet_0();
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_9_ta_ph = bevl_instClassTag.bem_add_1(bevt_10_ta_ph);
beva_session.bem_classTagCountSet_1(bevt_9_ta_ph);
bevt_11_ta_ph = beva_session.bem_classTagMapGet_0();
bevt_11_ta_ph.bem_put_2(bevl_instClass, bevl_instClassTag);
bevl_instWriter.bemd_1(280224614, bevp_shift);
bevl_instWriter.bemd_1(280224614, bevp_defineClassTag);
bevl_instWriter.bemd_1(280224614, bevl_instClass);
bevl_instWriter.bemd_1(280224614, bevp_shift);
bevl_instWriter.bemd_1(280224614, bevp_defineClassTag);
bevl_instWriter.bemd_1(280224614, bevl_instClassTagStr);
} /* Line: 199*/
 else /* Line: 200*/ {
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
} /* Line: 201*/
if (bevp_saveIdentity.bevi_bool)/* Line: 203*/ {
bevl_instWriter.bemd_1(280224614, bevp_defineReference);
bevt_12_ta_ph = bevl_scount.bem_toString_0();
bevl_instWriter.bemd_1(280224614, bevt_12_ta_ph);
} /* Line: 205*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_6_10_SystemSerializer_bels_10));
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_13_ta_ph = beva_instance.bemd_2(-1788833571, bevt_14_ta_ph, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 208*/ {
bevl_serializedString = (BEC_2_4_6_TextString) beva_instance.bemd_0(1444768255);
} /* Line: 209*/
 else /* Line: 210*/ {
bevl_serializedString = null;
} /* Line: 211*/
if (bevl_serializedString == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 213*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_6_10_SystemSerializer_bels_11));
bevt_17_ta_ph = bevl_serializedString.bem_notEquals_1(bevt_18_ta_ph);
if (bevt_17_ta_ph.bevi_bool)/* Line: 213*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 213*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 213*/
 else /* Line: 213*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 213*/ {
bevl_instWriter.bemd_1(280224614, bevp_constructString);
bevt_19_ta_ph = bevp_encoder.bem_encode_1(bevl_serializedString);
bevl_instWriter.bemd_1(280224614, bevt_19_ta_ph);
} /* Line: 215*/
bevl_instWriter.bemd_1(280224614, bevp_getClassTag);
bevl_instWriter.bemd_1(280224614, bevl_instClassTagStr);
if (bevp_saveIdentity.bevi_bool)/* Line: 219*/ {
bevt_20_ta_ph = beva_session.bem_uniqueGet_0();
bevt_20_ta_ph.bem_put_2(beva_instance, bevl_scount);
} /* Line: 220*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserialize_1(BEC_2_6_6_SystemObject beva_instReader) throws Throwable {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_9_4_ContainerList bevl_postDeserialize = null;
BEC_3_6_10_7_SystemSerializerSession bevl_session = null;
BEC_2_9_5_ContainerStack bevl_iterStack = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_9_3_ContainerMap bevl_instances = null;
BEC_2_6_6_SystemObject bevl_rootInst = null;
BEC_2_6_6_SystemObject bevl_groupInstIter = null;
BEC_2_4_6_TextString bevl_defineClassTagName = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_token = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_4_6_TextString bevl_instString = null;
BEC_2_4_3_MathInt bevl_glassTagVal = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_4_3_MathInt bevl_defineClassTagValue = null;
BEC_2_4_3_MathInt bevl_multiNullCount = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_7_TextStrings bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_6_9_SystemException bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_40_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_6_9_SystemException bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_5_4_LogicBool bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
bevl_postDeserialize = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_session = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_0();
bevl_iterStack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevt_2_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_4_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_3_ta_ph = bevt_4_ta_ph.bem_emptyGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_sameType_2(beva_instReader, bevt_3_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 229*/ {
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(beva_instReader);
} /* Line: 230*/
 else /* Line: 231*/ {
bevt_5_ta_ph = beva_instReader.bemd_0(-1236338332);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(bevt_5_ta_ph);
} /* Line: 232*/
bevl_instances = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_i = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 238*/ {
bevt_6_ta_ph = bevl_i.bemd_0(-1094939461);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 238*/ {
bevl_token = (BEC_2_4_6_TextString) bevl_i.bemd_0(-1132747350);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_state.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 240*/ {
bevt_9_ta_ph = bevl_token.bem_equals_1(bevp_defineReference);
if (bevt_9_ta_ph.bevi_bool)/* Line: 241*/ {
bevl_state = (new BEC_2_4_3_MathInt(1));
} /* Line: 242*/
 else /* Line: 241*/ {
bevt_10_ta_ph = bevl_token.bem_equals_1(bevp_constructString);
if (bevt_10_ta_ph.bevi_bool)/* Line: 243*/ {
bevl_state = (new BEC_2_4_3_MathInt(2));
} /* Line: 244*/
 else /* Line: 241*/ {
bevt_11_ta_ph = bevl_token.bem_equals_1(bevp_getClassTag);
if (bevt_11_ta_ph.bevi_bool)/* Line: 245*/ {
bevl_state = (new BEC_2_4_3_MathInt(8));
} /* Line: 246*/
 else /* Line: 241*/ {
bevt_12_ta_ph = bevl_token.bem_equals_1(bevp_shift);
if (bevt_12_ta_ph.bevi_bool)/* Line: 247*/ {
bevl_state = (new BEC_2_4_3_MathInt(1000));
} /* Line: 248*/
 else /* Line: 241*/ {
bevt_13_ta_ph = bevl_token.bem_equals_1(bevp_getReference);
if (bevt_13_ta_ph.bevi_bool)/* Line: 249*/ {
bevl_state = (new BEC_2_4_3_MathInt(4));
} /* Line: 250*/
 else /* Line: 241*/ {
bevt_14_ta_ph = bevl_token.bem_equals_1(bevp_nullMark);
if (bevt_14_ta_ph.bevi_bool)/* Line: 251*/ {
if (bevl_groupInstIter == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 253*/ {
bevl_groupInstIter.bemd_1(1560498159, null);
} /* Line: 254*/
} /* Line: 253*/
 else /* Line: 241*/ {
bevt_16_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_16_ta_ph.bevi_bool)/* Line: 256*/ {
if (bevl_inst == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 258*/ {
if (bevl_groupInstIter == null) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 259*/ {
bevl_iterStack.bem_push_1(bevl_groupInstIter);
} /* Line: 260*/
bevt_20_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_19_ta_ph = bevl_inst.bemd_2(-1788833571, bevt_20_ta_ph, bevt_21_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_19_ta_ph).bevi_bool)/* Line: 262*/ {
bevl_groupInstIter = bevl_inst.bemd_0(-1097719160);
} /* Line: 263*/
 else /* Line: 264*/ {
bevl_groupInstIter = bevl_inst.bemd_0(-1139674964);
} /* Line: 265*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_10_SystemSerializer_bels_12));
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_22_ta_ph = bevl_groupInstIter.bemd_2(-1788833571, bevt_23_ta_ph, bevt_24_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_22_ta_ph).bevi_bool)/* Line: 267*/ {
bevl_postDeserialize.bem_addValue_1(bevl_groupInstIter);
} /* Line: 268*/
} /* Line: 267*/
} /* Line: 258*/
} /* Line: 241*/
} /* Line: 241*/
} /* Line: 241*/
} /* Line: 241*/
} /* Line: 241*/
} /* Line: 241*/
} /* Line: 241*/
 else /* Line: 240*/ {
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(1000));
if (bevl_state.bevi_int == bevt_26_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 272*/ {
bevt_27_ta_ph = bevl_token.bem_equals_1(bevp_defineClassTag);
if (bevt_27_ta_ph.bevi_bool)/* Line: 274*/ {
if (bevl_defineClassTagName == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 275*/ {
bevl_state = (new BEC_2_4_3_MathInt(6));
} /* Line: 276*/
 else /* Line: 277*/ {
bevl_state = (new BEC_2_4_3_MathInt(7));
} /* Line: 278*/
} /* Line: 275*/
 else /* Line: 274*/ {
bevt_29_ta_ph = bevl_token.bem_equals_1(bevp_multiNullMark);
if (bevt_29_ta_ph.bevi_bool)/* Line: 280*/ {
bevl_state = (new BEC_2_4_3_MathInt(9));
} /* Line: 281*/
 else /* Line: 274*/ {
bevt_30_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_30_ta_ph.bevi_bool)/* Line: 282*/ {
bevl_groupInstIter = bevl_iterStack.bem_pop_0();
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 285*/
} /* Line: 274*/
} /* Line: 274*/
} /* Line: 274*/
 else /* Line: 287*/ {
bevt_32_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_state.bevi_int == bevt_32_ta_ph.bevi_int) {
bevt_31_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_31_ta_ph.bevi_bool)/* Line: 288*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 289*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(73, bece_BEC_2_6_10_SystemSerializer_bels_13));
bevt_34_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_35_ta_ph);
throw new be.BECS_ThrowBack(bevt_34_ta_ph);
} /* Line: 290*/
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 293*/
 else /* Line: 288*/ {
bevt_37_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_state.bevi_int == bevt_37_ta_ph.bevi_int) {
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 294*/ {
bevl_instString = bevp_encoder.bem_decode_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 296*/
 else /* Line: 288*/ {
bevt_39_ta_ph = (new BEC_2_4_3_MathInt(8));
if (bevl_state.bevi_int == bevt_39_ta_ph.bevi_int) {
bevt_38_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_38_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_38_ta_ph.bevi_bool)/* Line: 297*/ {
bevl_glassTagVal = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_40_ta_ph = bevl_session.bem_classTagMapGet_0();
bevl_klass = (BEC_2_4_6_TextString) bevt_40_ta_ph.bem_get_1(bevl_glassTagVal);
bevt_41_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevl_inst = bevt_41_ta_ph.bem_createInstance_1(bevl_klass);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_6_10_SystemSerializer_bels_14));
bevt_44_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_42_ta_ph = bevl_inst.bemd_2(-1788833571, bevt_43_ta_ph, bevt_44_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 301*/ {
bevl_inst = bevl_inst.bemd_1(1680504296, bevl_instString);
} /* Line: 302*/
bevt_46_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_10_SystemSerializer_bels_15));
bevt_47_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_45_ta_ph = bevl_inst.bemd_2(-1788833571, bevt_46_ta_ph, bevt_47_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 304*/ {
bevl_inst = bevl_inst.bemd_1(949985588, bevl_instString);
} /* Line: 305*/
if (bevl_rootInst == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 307*/ {
bevl_rootInst = bevl_inst;
} /* Line: 308*/
if (bevp_saveIdentity.bevi_bool)/* Line: 310*/ {
bevl_instances.bem_put_2(bevl_instSerial, bevl_inst);
} /* Line: 311*/
bevl_instString = null;
if (bevl_groupInstIter == null) {
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 315*/ {
bevl_groupInstIter.bemd_1(1560498159, bevl_inst);
} /* Line: 316*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 318*/
 else /* Line: 288*/ {
bevt_51_ta_ph = (new BEC_2_4_3_MathInt(4));
if (bevl_state.bevi_int == bevt_51_ta_ph.bevi_int) {
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 319*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_52_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_52_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_52_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_54_ta_ph = (new BEC_2_4_6_TextString(66, bece_BEC_2_6_10_SystemSerializer_bels_16));
bevt_53_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_54_ta_ph);
throw new be.BECS_ThrowBack(bevt_53_ta_ph);
} /* Line: 321*/
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_inst = bevl_instances.bem_get_1(bevl_instSerial);
if (bevl_groupInstIter == null) {
bevt_55_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_55_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_55_ta_ph.bevi_bool)/* Line: 325*/ {
bevl_groupInstIter.bemd_1(1560498159, bevl_inst);
} /* Line: 326*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 328*/
 else /* Line: 288*/ {
bevt_57_ta_ph = (new BEC_2_4_3_MathInt(6));
if (bevl_state.bevi_int == bevt_57_ta_ph.bevi_int) {
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 329*/ {
bevl_defineClassTagName = bevl_token;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 331*/
 else /* Line: 288*/ {
bevt_59_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_state.bevi_int == bevt_59_ta_ph.bevi_int) {
bevt_58_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_58_ta_ph.bevi_bool)/* Line: 332*/ {
bevl_defineClassTagValue = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_60_ta_ph = bevl_session.bem_classTagMapGet_0();
bevt_60_ta_ph.bem_put_2(bevl_defineClassTagValue, bevl_defineClassTagName);
bevl_defineClassTagName = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 337*/
 else /* Line: 288*/ {
bevt_62_ta_ph = (new BEC_2_4_3_MathInt(9));
if (bevl_state.bevi_int == bevt_62_ta_ph.bevi_int) {
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_61_ta_ph.bevi_bool)/* Line: 338*/ {
if (bevl_groupInstIter == null) {
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 340*/ {
bevl_multiNullCount = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_groupInstIter.bemd_1(589619709, bevl_multiNullCount);
} /* Line: 342*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 344*/
} /* Line: 288*/
} /* Line: 288*/
} /* Line: 288*/
} /* Line: 288*/
} /* Line: 288*/
} /* Line: 288*/
} /* Line: 288*/
} /* Line: 240*/
} /* Line: 240*/
 else /* Line: 238*/ {
break;
} /* Line: 238*/
} /* Line: 238*/
bevl_inst = null;
bevt_0_ta_loop = bevl_postDeserialize.bem_iteratorGet_0();
while (true)
/* Line: 349*/ {
bevt_64_ta_ph = bevt_0_ta_loop.bemd_0(-1094939461);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 349*/ {
bevl_groupInstIter = bevt_0_ta_loop.bemd_0(-1132747350);
bevl_groupInstIter.bemd_0(-1123788402);
} /* Line: 350*/
 else /* Line: 349*/ {
break;
} /* Line: 349*/
} /* Line: 349*/
return bevl_rootInst;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGet_0() throws Throwable {
return bevp_group;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_group = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGet_0() throws Throwable {
return bevp_defineReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGet_0() throws Throwable {
return bevp_getReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGet_0() throws Throwable {
return bevp_constructString;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGet_0() throws Throwable {
return bevp_nullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGet_0() throws Throwable {
return bevp_getClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGet_0() throws Throwable {
return bevp_shift;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGet_0() throws Throwable {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGet_0() throws Throwable {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGet_0() throws Throwable {
return bevp_endGroup;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() throws Throwable {
return bevp_toker;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGet_0() throws Throwable {
return bevp_encoder;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGet_0() throws Throwable {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 82, 82, 82, 82, 82, 82, 82, 83, 81, 85, 86, 91, 92, 93, 97, 97, 98, 98, 103, 104, 104, 104, 105, 107, 110, 115, 116, 117, 117, 117, 118, 120, 122, 123, 124, 125, 126, 126, 128, 131, 131, 131, 132, 133, 134, 134, 134, 135, 136, 137, 138, 138, 138, 139, 140, 141, 141, 142, 144, 144, 145, 147, 147, 149, 149, 151, 154, 155, 155, 160, 160, 160, 161, 162, 163, 163, 163, 164, 165, 166, 167, 167, 167, 168, 169, 170, 170, 171, 173, 174, 179, 180, 180, 180, 182, 183, 183, 183, 184, 186, 186, 188, 188, 189, 189, 190, 191, 192, 192, 192, 193, 193, 194, 195, 196, 197, 198, 199, 201, 204, 205, 205, 208, 208, 208, 209, 211, 213, 213, 213, 213, 0, 0, 0, 214, 215, 215, 217, 218, 220, 220, 225, 226, 227, 228, 229, 229, 229, 229, 230, 232, 232, 234, 238, 238, 239, 240, 240, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 253, 253, 254, 256, 258, 258, 259, 259, 260, 262, 262, 262, 263, 265, 267, 267, 267, 268, 272, 272, 272, 274, 275, 275, 276, 278, 280, 281, 282, 284, 285, 288, 288, 288, 289, 289, 290, 290, 290, 292, 293, 294, 294, 294, 295, 296, 297, 297, 297, 298, 299, 299, 300, 300, 301, 301, 301, 302, 304, 304, 304, 305, 307, 307, 308, 311, 313, 315, 315, 316, 318, 319, 319, 319, 320, 320, 321, 321, 321, 323, 324, 325, 325, 326, 328, 329, 329, 329, 330, 331, 332, 332, 332, 334, 335, 335, 336, 337, 338, 338, 338, 340, 340, 341, 342, 344, 348, 349, 0, 349, 349, 350, 352, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 99, 100, 101, 106, 111, 112, 113, 122, 123, 124, 125, 127, 130, 133, 167, 168, 169, 170, 171, 173, 176, 178, 180, 183, 185, 186, 191, 192, 195, 196, 201, 202, 203, 206, 207, 212, 213, 214, 215, 218, 219, 224, 225, 226, 227, 228, 229, 233, 238, 239, 242, 243, 245, 250, 251, 254, 255, 256, 264, 265, 270, 271, 272, 275, 276, 281, 282, 283, 284, 287, 288, 293, 294, 295, 296, 297, 298, 302, 303, 335, 336, 337, 338, 339, 340, 341, 342, 344, 347, 348, 350, 351, 352, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 373, 376, 377, 378, 380, 381, 382, 384, 387, 389, 394, 395, 396, 398, 401, 405, 408, 409, 410, 412, 413, 415, 416, 504, 505, 506, 507, 508, 509, 510, 511, 513, 516, 517, 519, 520, 523, 525, 526, 527, 532, 533, 535, 538, 540, 543, 545, 548, 550, 553, 555, 558, 560, 565, 566, 570, 572, 577, 578, 583, 584, 586, 587, 588, 590, 593, 595, 596, 597, 599, 611, 612, 617, 618, 620, 625, 626, 629, 633, 635, 638, 640, 641, 647, 648, 653, 654, 659, 660, 661, 662, 664, 665, 668, 669, 674, 675, 676, 679, 680, 685, 686, 687, 688, 689, 690, 691, 692, 693, 695, 697, 698, 699, 701, 703, 708, 709, 712, 714, 715, 720, 721, 723, 726, 727, 732, 733, 738, 739, 740, 741, 743, 744, 745, 750, 751, 753, 756, 757, 762, 763, 764, 767, 768, 773, 774, 775, 776, 777, 778, 781, 782, 787, 788, 793, 794, 795, 797, 812, 813, 813, 816, 818, 819, 825, 828, 831, 835, 838, 842, 845, 849, 852, 856, 859, 863, 866, 870, 873, 877, 880, 884, 887, 891, 894, 898, 901, 905, 908, 912, 915};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 65 52
new 0 65 52
assign 1 65 53
new 0 65 53
assign 1 65 54
new 0 65 54
assign 1 65 55
new 0 65 55
assign 1 65 56
new 0 65 56
assign 1 65 57
new 0 65 57
assign 1 65 58
new 0 65 58
assign 1 65 59
new 0 65 59
assign 1 65 60
new 0 65 60
assign 1 65 61
new 0 65 61
new 10 65 62
assign 1 71 74
assign 1 72 75
assign 1 73 76
assign 1 74 77
assign 1 75 78
assign 1 76 79
assign 1 77 80
assign 1 78 81
assign 1 79 82
assign 1 80 83
assign 1 82 84
add 1 82 84
assign 1 82 85
add 1 82 85
assign 1 82 86
add 1 82 86
assign 1 82 87
add 1 82 87
assign 1 82 88
add 1 82 88
assign 1 82 89
add 1 82 89
assign 1 82 90
add 1 82 90
assign 1 83 91
new 0 83 91
assign 1 81 92
new 2 81 92
assign 1 85 93
new 0 85 93
assign 1 86 94
new 0 86 94
assign 1 91 99
new 0 91 99
serialize 2 92 100
return 1 93 101
assign 1 97 106
def 1 97 111
assign 1 98 112
new 1 98 112
serializeI 2 98 113
defineInstance 2 103 122
assign 1 104 123
new 0 104 123
assign 1 104 124
new 0 104 124
assign 1 104 125
can 2 104 125
assign 1 105 127
serializeContentsGet 0 105 127
assign 1 107 130
new 0 107 130
serializeC 2 110 133
assign 1 115 167
instWriterGet 0 115 167
assign 1 116 168
new 0 116 168
assign 1 117 169
new 0 117 169
assign 1 117 170
new 0 117 170
assign 1 117 171
can 2 117 171
assign 1 118 173
serializationIteratorGet 0 118 173
assign 1 120 176
iteratorGet 0 120 176
assign 1 122 178
hasNextGet 0 122 178
write 1 123 180
assign 1 124 183
hasNextGet 0 124 183
assign 1 125 185
nextGet 0 125 185
assign 1 126 186
undef 1 126 191
assign 1 128 192
increment 0 128 192
assign 1 131 195
new 0 131 195
assign 1 131 196
equals 1 131 201
write 1 132 202
assign 1 133 203
new 0 133 203
assign 1 134 206
new 0 134 206
assign 1 134 207
equals 1 134 212
write 1 135 213
write 1 136 214
assign 1 137 215
new 0 137 215
assign 1 138 218
new 0 138 218
assign 1 138 219
greater 1 138 224
write 1 139 225
write 1 140 226
assign 1 141 227
toString 0 141 227
write 1 141 228
assign 1 142 229
new 0 142 229
assign 1 144 233
not 0 144 238
assign 1 145 239
assign 1 147 242
uniqueGet 0 147 242
assign 1 147 243
get 1 147 243
assign 1 149 245
undef 1 149 250
serializeI 2 151 251
write 1 154 254
assign 1 155 255
toString 0 155 255
write 1 155 256
assign 1 160 264
new 0 160 264
assign 1 160 265
equals 1 160 270
write 1 161 271
assign 1 162 272
new 0 162 272
assign 1 163 275
new 0 163 275
assign 1 163 276
equals 1 163 281
write 1 164 282
write 1 165 283
assign 1 166 284
new 0 166 284
assign 1 167 287
new 0 167 287
assign 1 167 288
greater 1 167 293
write 1 168 294
write 1 169 295
assign 1 170 296
toString 0 170 296
write 1 170 297
assign 1 171 298
new 0 171 298
write 1 173 302
write 1 174 303
assign 1 179 335
serialCountGet 0 179 335
assign 1 180 336
new 0 180 336
assign 1 180 337
add 1 180 337
serialCountSet 1 180 338
assign 1 182 339
instWriterGet 0 182 339
assign 1 183 340
new 0 183 340
assign 1 183 341
new 0 183 341
assign 1 183 342
can 2 183 342
assign 1 184 344
deserializeClassNameGet 0 184 344
assign 1 186 347
new 0 186 347
assign 1 186 348
className 1 186 348
assign 1 188 350
classTagMapGet 0 188 350
assign 1 188 351
get 1 188 351
assign 1 189 352
undef 1 189 357
assign 1 190 358
classTagCountGet 0 190 358
assign 1 191 359
toString 0 191 359
assign 1 192 360
new 0 192 360
assign 1 192 361
add 1 192 361
classTagCountSet 1 192 362
assign 1 193 363
classTagMapGet 0 193 363
put 2 193 364
write 1 194 365
write 1 195 366
write 1 196 367
write 1 197 368
write 1 198 369
write 1 199 370
assign 1 201 373
toString 0 201 373
write 1 204 376
assign 1 205 377
toString 0 205 377
write 1 205 378
assign 1 208 380
new 0 208 380
assign 1 208 381
new 0 208 381
assign 1 208 382
can 2 208 382
assign 1 209 384
serializeToString 0 209 384
assign 1 211 387
assign 1 213 389
def 1 213 394
assign 1 213 395
new 0 213 395
assign 1 213 396
notEquals 1 213 396
assign 1 0 398
assign 1 0 401
assign 1 0 405
write 1 214 408
assign 1 215 409
encode 1 215 409
write 1 215 410
write 1 217 412
write 1 218 413
assign 1 220 415
uniqueGet 0 220 415
put 2 220 416
assign 1 225 504
new 0 225 504
assign 1 226 505
new 0 226 505
assign 1 227 506
new 0 227 506
assign 1 228 507
new 0 228 507
assign 1 229 508
new 0 229 508
assign 1 229 509
new 0 229 509
assign 1 229 510
emptyGet 0 229 510
assign 1 229 511
sameType 2 229 511
assign 1 230 513
tokenize 1 230 513
assign 1 232 516
readString 0 232 516
assign 1 232 517
tokenize 1 232 517
assign 1 234 519
new 0 234 519
assign 1 238 520
linkedListIteratorGet 0 238 520
assign 1 238 523
hasNextGet 0 238 523
assign 1 239 525
nextGet 0 239 525
assign 1 240 526
new 0 240 526
assign 1 240 527
equals 1 240 532
assign 1 241 533
equals 1 241 533
assign 1 242 535
new 0 242 535
assign 1 243 538
equals 1 243 538
assign 1 244 540
new 0 244 540
assign 1 245 543
equals 1 245 543
assign 1 246 545
new 0 246 545
assign 1 247 548
equals 1 247 548
assign 1 248 550
new 0 248 550
assign 1 249 553
equals 1 249 553
assign 1 250 555
new 0 250 555
assign 1 251 558
equals 1 251 558
assign 1 253 560
def 1 253 565
nextSet 1 254 566
assign 1 256 570
equals 1 256 570
assign 1 258 572
def 1 258 577
assign 1 259 578
def 1 259 583
push 1 260 584
assign 1 262 586
new 0 262 586
assign 1 262 587
new 0 262 587
assign 1 262 588
can 2 262 588
assign 1 263 590
serializationIteratorGet 0 263 590
assign 1 265 593
iteratorGet 0 265 593
assign 1 267 595
new 0 267 595
assign 1 267 596
new 0 267 596
assign 1 267 597
can 2 267 597
addValue 1 268 599
assign 1 272 611
new 0 272 611
assign 1 272 612
equals 1 272 617
assign 1 274 618
equals 1 274 618
assign 1 275 620
undef 1 275 625
assign 1 276 626
new 0 276 626
assign 1 278 629
new 0 278 629
assign 1 280 633
equals 1 280 633
assign 1 281 635
new 0 281 635
assign 1 282 638
equals 1 282 638
assign 1 284 640
pop 0 284 640
assign 1 285 641
new 0 285 641
assign 1 288 647
new 0 288 647
assign 1 288 648
equals 1 288 653
assign 1 289 654
not 0 289 659
assign 1 290 660
new 0 290 660
assign 1 290 661
new 1 290 661
throw 1 290 662
assign 1 292 664
new 1 292 664
assign 1 293 665
new 0 293 665
assign 1 294 668
new 0 294 668
assign 1 294 669
equals 1 294 674
assign 1 295 675
decode 1 295 675
assign 1 296 676
new 0 296 676
assign 1 297 679
new 0 297 679
assign 1 297 680
equals 1 297 685
assign 1 298 686
new 1 298 686
assign 1 299 687
classTagMapGet 0 299 687
assign 1 299 688
get 1 299 688
assign 1 300 689
new 0 300 689
assign 1 300 690
createInstance 1 300 690
assign 1 301 691
new 0 301 691
assign 1 301 692
new 0 301 692
assign 1 301 693
can 2 301 693
assign 1 302 695
deserializeFromStringNew 1 302 695
assign 1 304 697
new 0 304 697
assign 1 304 698
new 0 304 698
assign 1 304 699
can 2 304 699
assign 1 305 701
deserializeFromString 1 305 701
assign 1 307 703
undef 1 307 708
assign 1 308 709
put 2 311 712
assign 1 313 714
assign 1 315 715
def 1 315 720
nextSet 1 316 721
assign 1 318 723
new 0 318 723
assign 1 319 726
new 0 319 726
assign 1 319 727
equals 1 319 732
assign 1 320 733
not 0 320 738
assign 1 321 739
new 0 321 739
assign 1 321 740
new 1 321 740
throw 1 321 741
assign 1 323 743
new 1 323 743
assign 1 324 744
get 1 324 744
assign 1 325 745
def 1 325 750
nextSet 1 326 751
assign 1 328 753
new 0 328 753
assign 1 329 756
new 0 329 756
assign 1 329 757
equals 1 329 762
assign 1 330 763
assign 1 331 764
new 0 331 764
assign 1 332 767
new 0 332 767
assign 1 332 768
equals 1 332 773
assign 1 334 774
new 1 334 774
assign 1 335 775
classTagMapGet 0 335 775
put 2 335 776
assign 1 336 777
assign 1 337 778
new 0 337 778
assign 1 338 781
new 0 338 781
assign 1 338 782
equals 1 338 787
assign 1 340 788
def 1 340 793
assign 1 341 794
new 1 341 794
skip 1 342 795
assign 1 344 797
new 0 344 797
assign 1 348 812
assign 1 349 813
iteratorGet 0 0 813
assign 1 349 816
hasNextGet 0 349 816
assign 1 349 818
nextGet 0 349 818
postDeserialize 0 350 819
return 1 352 825
return 1 0 828
assign 1 0 831
return 1 0 835
assign 1 0 838
return 1 0 842
assign 1 0 845
return 1 0 849
assign 1 0 852
return 1 0 856
assign 1 0 859
return 1 0 863
assign 1 0 866
return 1 0 870
assign 1 0 873
return 1 0 877
assign 1 0 880
return 1 0 884
assign 1 0 887
return 1 0 891
assign 1 0 894
return 1 0 898
assign 1 0 901
return 1 0 905
assign 1 0 908
return 1 0 912
assign 1 0 915
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -399163716: return bem_multiNullMarkGet_0();
case -902200821: return bem_constructStringGet_0();
case -1023089947: return bem_getClassTagGet_0();
case 1087948256: return bem_new_0();
case -986128725: return bem_toString_0();
case -1792890542: return bem_defineReferenceGet_0();
case 146372489: return bem_encoderGet_0();
case -1024017873: return bem_endGroupGet_0();
case 1727705918: return bem_getReferenceGet_0();
case 1668972651: return bem_groupGet_0();
case 739831016: return bem_create_0();
case 287087677: return bem_shiftGet_0();
case -1139674964: return bem_iteratorGet_0();
case -862490543: return bem_tokerGet_0();
case 1663568887: return bem_nullMarkGet_0();
case 40259909: return bem_defineClassTagGet_0();
case -620559885: return bem_saveIdentityGet_0();
case -569628997: return bem_print_0();
case 585417190: return bem_copy_0();
case 818346420: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1446291850: return bem_nullMarkSet_1(bevd_0);
case -1301361998: return bem_saveIdentitySet_1(bevd_0);
case 1092880543: return bem_getClassTagSet_1(bevd_0);
case -1983598883: return bem_notEquals_1(bevd_0);
case 1535049640: return bem_encoderSet_1(bevd_0);
case 808200237: return bem_def_1(bevd_0);
case 1510784310: return bem_defineClassTagSet_1(bevd_0);
case -2053341946: return bem_endGroupSet_1(bevd_0);
case 2142568763: return bem_defineReferenceSet_1(bevd_0);
case -373514558: return bem_shiftSet_1(bevd_0);
case 1325293323: return bem_serialize_1(bevd_0);
case 1649059878: return bem_deserialize_1(bevd_0);
case -885505062: return bem_tokerSet_1(bevd_0);
case 470769704: return bem_equals_1(bevd_0);
case 1491991994: return bem_multiNullMarkSet_1(bevd_0);
case 1779936155: return bem_groupSet_1(bevd_0);
case -1786302300: return bem_undef_1(bevd_0);
case 950796455: return bem_getReferenceSet_1(bevd_0);
case -1395935787: return bem_copyTo_1(bevd_0);
case -626453938: return bem_constructStringSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2127709277: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -125610407: return bem_serialize_2(bevd_0, bevd_1);
case 2040783616: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2003032267: return bem_defineInstance_2(bevd_0, (BEC_3_6_10_7_SystemSerializerSession) bevd_1);
case 2080210724: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1788833571: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1294296476: return bem_serializeC_2(bevd_0, bevd_1);
case -265545508: return bem_serializeI_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_x(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5, BEC_2_6_6_SystemObject bevd_6, BEC_2_6_6_SystemObject[] bevd_x) throws Throwable {
switch (callId) {
case -2114105780: return bem_new_10((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4, (BEC_2_4_6_TextString) bevd_5, (BEC_2_4_6_TextString) bevd_6, (BEC_2_4_6_TextString) bevd_x[0], (BEC_2_4_6_TextString) bevd_x[1], (BEC_2_4_6_TextString) bevd_x[2]);
}
return super.bemd_x(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5, bevd_6, bevd_x);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemSerializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_10_SystemSerializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemSerializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst = (BEC_2_6_10_SystemSerializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_type;
}
}
