package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_8_IOFileWriterNoOutput extends BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_8_IOFileWriterNoOutput() { }
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x4E,0x6F,0x4F,0x75,0x74,0x70,0x75,0x74};
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;

public static BET_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;

public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_writeIfPossible_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_write_1(BEC_2_4_6_TextString beva_str) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {774, 783, 783};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 26, 27};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 774 12
new 0 774 12
assign 1 783 26
new 0 783 26
return 1 783 27
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1818335248: return bem_toString_0();
case 2102454029: return bem_openAppend_0();
case 548957600: return bem_open_0();
case -662805893: return bem_extOpen_0();
case 95246164: return bem_close_0();
case 764459509: return bem_iteratorGet_0();
case -1854351103: return bem_print_0();
case -1182108874: return bem_create_0();
case 1704927424: return bem_new_0();
case -1778606491: return bem_openTruncate_0();
case 177935251: return bem_vfileGet_0();
case 1145598418: return bem_copy_0();
case 84237329: return bem_hashGet_0();
case -271942327: return bem_pathGet_0();
case -1530394503: return bem_isClosedGet_0();
case 1922308358: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 854124491: return bem_print_1(bevd_0);
case 1782625331: return bem_notEquals_1(bevd_0);
case 286474229: return bem_isClosedSet_1(bevd_0);
case -844033609: return bem_writeIfPossible_1(bevd_0);
case 1297596195: return bem_vfileSet_1(bevd_0);
case 775180462: return bem_def_1(bevd_0);
case 1697701048: return bem_equals_1(bevd_0);
case -756911966: return bem_new_1(bevd_0);
case -136696585: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 737950929: return bem_pathSet_1(bevd_0);
case -1378177790: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case 554077208: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 1780152727: return bem_undef_1(bevd_0);
case -1601489182: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1638131121: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 294957256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -997677553: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 91726751: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_8_IOFileWriterNoOutput();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst = (BEC_4_2_4_6_8_IOFileWriterNoOutput) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;
}
}
