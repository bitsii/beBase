package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 829 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 831 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 834 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 840 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(674226173, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 842 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 845 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 852 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(1865614801, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 854 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 857 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 864 */ {
bevl_r = bevp_container.bemd_0(-2068884270);
bevp_lock.bem_unlock_0();
} /* Line: 866 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 869 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 876 */ {
bevl_r = bevp_container.bemd_1(-1183192776, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 878 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 881 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 888 */ {
bevl_r = bevp_container.bemd_1(-1183192776, beva_key);
bevp_container.bemd_1(1668000226, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 891 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 894 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 901 */ {
bevl_r = bevp_container.bemd_2(-1844461366, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 903 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 906 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 913 */ {
bevp_container.bemd_1(2043146996, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 915 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 918 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 924 */ {
bevl_r = bevp_container.bemd_1(1076777494, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 926 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 929 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 936 */ {
bevp_container.bemd_1(1076777494, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 938 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 941 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 947 */ {
bevl_r = bevp_container.bemd_2(561048484, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 949 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 952 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 959 */ {
bevp_container.bemd_2(561048484, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 961 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 964 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 970 */ {
bevl_rc = bevp_container.bemd_3(-221566712, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 972 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 975 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 982 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1236198063);
bevp_lock.bem_unlock_0();
} /* Line: 984 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 987 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 994 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-841869134, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 996 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 999 */
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1006 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(674226173, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1007 */ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 1008 */
 else  /* Line: 1009 */ {
bevp_container.bemd_2(561048484, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 1011 */
bevp_lock.bem_unlock_0();
} /* Line: 1013 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1016 */
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1023 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(674226173, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1024 */ {
bevl_result = bevp_container.bemd_1(-1183192776, beva_key);
} /* Line: 1025 */
 else  /* Line: 1026 */ {
bevp_container.bemd_2(561048484, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1028 */
bevp_lock.bem_unlock_0();
} /* Line: 1030 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1033 */
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1040 */ {
bevp_container.bemd_3(1800257424, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1042 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1045 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1051 */ {
bevl_r = bevp_container.bemd_1(1668000226, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1053 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1056 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1063 */ {
bevl_r = bevp_container.bemd_2(-314684306, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1065 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1068 */
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1075 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(1737180590);
bevp_lock.bem_unlock_0();
} /* Line: 1077 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1080 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1087 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(802503032);
bevp_lock.bem_unlock_0();
} /* Line: 1089 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1092 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1099 */ {
bevl_r = bevp_container.bemd_0(-1721224705);
bevp_lock.bem_unlock_0();
} /* Line: 1101 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1104 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1111 */ {
bevp_container.bemd_0(-1673076470);
bevp_lock.bem_unlock_0();
} /* Line: 1113 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1116 */
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1122 */ {
bevp_container.bemd_0(-1223869755);
bevp_lock.bem_unlock_0();
} /* Line: 1124 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1127 */
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {825, 828, 830, 831, 833, 834, 839, 841, 842, 844, 845, 847, 851, 853, 854, 856, 857, 859, 863, 865, 866, 868, 869, 871, 875, 877, 878, 880, 881, 883, 887, 889, 890, 891, 893, 894, 896, 900, 902, 903, 905, 906, 908, 912, 914, 915, 917, 918, 923, 925, 926, 928, 929, 931, 935, 937, 938, 940, 941, 946, 948, 949, 951, 952, 954, 958, 960, 961, 963, 964, 969, 971, 972, 974, 975, 977, 981, 983, 984, 986, 987, 989, 993, 995, 996, 998, 999, 1001, 1005, 1007, 1008, 1010, 1011, 1013, 1015, 1016, 1018, 1022, 1024, 1025, 1027, 1028, 1030, 1032, 1033, 1035, 1039, 1041, 1042, 1044, 1045, 1050, 1052, 1053, 1055, 1056, 1058, 1062, 1064, 1065, 1067, 1068, 1070, 1074, 1076, 1077, 1079, 1080, 1082, 1086, 1088, 1089, 1091, 1092, 1094, 1098, 1100, 1101, 1103, 1104, 1106, 1110, 1112, 1113, 1115, 1116, 1121, 1123, 1124, 1126, 1127, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 242, 244, 246, 249, 250, 252, 256, 257, 259, 265, 267, 269, 272, 273, 275, 279, 280, 282, 286, 288, 289, 293, 294, 301, 303, 304, 308, 309, 311, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 375, 377, 378, 382, 383, 389, 391, 392, 396, 397, 402, 405, 408, 412, 416, 419, 422, 426};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 825 17
new 0 825 17
lock 0 828 18
assign 1 830 20
unlock 0 831 21
unlock 0 833 25
throw 1 834 26
lock 0 839 33
assign 1 841 35
has 1 841 35
unlock 0 842 36
unlock 0 844 40
throw 1 845 41
return 1 847 43
lock 0 851 48
assign 1 853 50
has 2 853 50
unlock 0 854 51
unlock 0 856 55
throw 1 857 56
return 1 859 58
lock 0 863 63
assign 1 865 65
get 0 865 65
unlock 0 866 66
unlock 0 868 70
throw 1 869 71
return 1 871 73
lock 0 875 78
assign 1 877 80
get 1 877 80
unlock 0 878 81
unlock 0 880 85
throw 1 881 86
return 1 883 88
lock 0 887 93
assign 1 889 95
get 1 889 95
delete 1 890 96
unlock 0 891 97
unlock 0 893 101
throw 1 894 102
return 1 896 104
lock 0 900 109
assign 1 902 111
get 2 902 111
unlock 0 903 112
unlock 0 905 116
throw 1 906 117
return 1 908 119
lock 0 912 123
addValue 1 914 125
unlock 0 915 126
unlock 0 917 130
throw 1 918 131
lock 0 923 138
assign 1 925 140
put 1 925 140
unlock 0 926 141
unlock 0 928 145
throw 1 929 146
return 1 931 148
lock 0 935 152
put 1 937 154
unlock 0 938 155
unlock 0 940 159
throw 1 941 160
lock 0 946 167
assign 1 948 169
put 2 948 169
unlock 0 949 170
unlock 0 951 174
throw 1 952 175
return 1 954 177
lock 0 958 181
put 2 960 183
unlock 0 961 184
unlock 0 963 188
throw 1 964 189
lock 0 969 196
assign 1 971 198
testAndPut 3 971 198
unlock 0 972 199
unlock 0 974 203
throw 1 975 204
return 1 977 206
lock 0 981 211
assign 1 983 213
getMap 0 983 213
unlock 0 984 214
unlock 0 986 218
throw 1 987 219
return 1 989 221
lock 0 993 226
assign 1 995 228
getMap 1 995 228
unlock 0 996 229
unlock 0 998 233
throw 1 999 234
return 1 1001 236
lock 0 1005 242
assign 1 1007 244
has 1 1007 244
assign 1 1008 246
new 0 1008 246
put 2 1010 249
assign 1 1011 250
new 0 1011 250
unlock 0 1013 252
unlock 0 1015 256
throw 1 1016 257
return 1 1018 259
lock 0 1022 265
assign 1 1024 267
has 1 1024 267
assign 1 1025 269
get 1 1025 269
put 2 1027 272
assign 1 1028 273
unlock 0 1030 275
unlock 0 1032 279
throw 1 1033 280
return 1 1035 282
lock 0 1039 286
put 3 1041 288
unlock 0 1042 289
unlock 0 1044 293
throw 1 1045 294
lock 0 1050 301
assign 1 1052 303
delete 1 1052 303
unlock 0 1053 304
unlock 0 1055 308
throw 1 1056 309
return 1 1058 311
lock 0 1062 316
assign 1 1064 318
delete 2 1064 318
unlock 0 1065 319
unlock 0 1067 323
throw 1 1068 324
return 1 1070 326
lock 0 1074 331
assign 1 1076 333
sizeGet 0 1076 333
unlock 0 1077 334
unlock 0 1079 338
throw 1 1080 339
return 1 1082 341
lock 0 1086 346
assign 1 1088 348
isEmptyGet 0 1088 348
unlock 0 1089 349
unlock 0 1091 353
throw 1 1092 354
return 1 1094 356
lock 0 1098 361
assign 1 1100 363
copy 0 1100 363
unlock 0 1101 364
unlock 0 1103 368
throw 1 1104 369
return 1 1106 371
lock 0 1110 375
clear 0 1112 377
unlock 0 1113 378
unlock 0 1115 382
throw 1 1116 383
lock 0 1121 389
close 0 1123 391
unlock 0 1124 392
unlock 0 1126 396
throw 1 1127 397
return 1 0 402
return 1 0 405
assign 1 0 408
assign 1 0 412
return 1 0 416
return 1 0 419
assign 1 0 422
assign 1 0 426
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1737180590: return bem_sizeGet_0();
case -1627101286: return bem_many_0();
case 1723936991: return bem_copyContainer_0();
case -1673076470: return bem_clear_0();
case 221369236: return bem_echo_0();
case -169510412: return bem_toString_0();
case -1200024888: return bem_tagGet_0();
case -1145946037: return bem_serializeToString_0();
case -458279913: return bem_serializationIteratorGet_0();
case 586787044: return bem_toAny_0();
case -4634496: return bem_once_0();
case -1721224705: return bem_copy_0();
case 1166902012: return bem_print_0();
case 1158769993: return bem_lockGet_0();
case -1760283647: return bem_sourceFileNameGet_0();
case 1662643176: return bem_new_0();
case -1588608331: return bem_iteratorGet_0();
case -744058216: return bem_lockGetDirect_0();
case -1855742442: return bem_deserializeClassNameGet_0();
case 536694332: return bem_containerGet_0();
case -2068884270: return bem_get_0();
case 737627600: return bem_classNameGet_0();
case -1223869755: return bem_close_0();
case -165877765: return bem_create_0();
case -1236198063: return bem_getMap_0();
case 419402773: return bem_fieldNamesGet_0();
case 802503032: return bem_isEmptyGet_0();
case 1800213309: return bem_serializeContents_0();
case 1202859281: return bem_fieldIteratorGet_0();
case -12708128: return bem_hashGet_0();
case -989057151: return bem_containerGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1396328003: return bem_otherClass_1(bevd_0);
case 1345066902: return bem_putReturn_1(bevd_0);
case -1617140536: return bem_defined_1(bevd_0);
case -1183192776: return bem_get_1(bevd_0);
case -1142555328: return bem_lockSetDirect_1(bevd_0);
case -1694968514: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2050626933: return bem_def_1(bevd_0);
case -39094467: return bem_equals_1(bevd_0);
case -1880368515: return bem_notEquals_1(bevd_0);
case 987201415: return bem_new_1(bevd_0);
case -1808032465: return bem_containerSet_1(bevd_0);
case -1058481552: return bem_undef_1(bevd_0);
case -1443846588: return bem_getAndClear_1(bevd_0);
case 2043146996: return bem_addValue_1(bevd_0);
case 1076777494: return bem_put_1(bevd_0);
case 128479842: return bem_lockSet_1(bevd_0);
case -327804541: return bem_sameClass_1(bevd_0);
case -306633068: return bem_undefined_1(bevd_0);
case -409899450: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2038137777: return bem_otherType_1(bevd_0);
case 674226173: return bem_has_1(bevd_0);
case 1039180755: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -883889211: return bem_sameObject_1(bevd_0);
case -841869134: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1402270539: return bem_containerSetDirect_1(bevd_0);
case 286179063: return bem_copyTo_1(bevd_0);
case -1143294403: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1668000226: return bem_delete_1(bevd_0);
case 1174135522: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1666962597: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -549233499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853281410: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -314684306: return bem_delete_2(bevd_0, bevd_1);
case -136430353: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 561048484: return bem_put_2(bevd_0, bevd_1);
case 2126382926: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 497483462: return bem_putReturn_2(bevd_0, bevd_1);
case -282890977: return bem_getOrPut_2(bevd_0, bevd_1);
case 1776809505: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -603592294: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -1844461366: return bem_get_2(bevd_0, bevd_1);
case 1983260459: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1865614801: return bem_has_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -221566712: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
case 1800257424: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
