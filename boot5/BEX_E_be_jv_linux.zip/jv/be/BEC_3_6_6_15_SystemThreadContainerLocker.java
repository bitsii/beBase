package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try /* Line: 585*/ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 587*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 590*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 596*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-1828493463, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 598*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 601*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 608*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-1357121872, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 610*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 613*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 620*/ {
bevl_r = bevp_container.bemd_0(-1307164317);
bevp_lock.bem_unlock_0();
} /* Line: 622*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 625*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 632*/ {
bevl_r = bevp_container.bemd_1(427083876, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 634*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 637*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 644*/ {
bevl_r = bevp_container.bemd_1(427083876, beva_key);
bevp_container.bemd_1(1327676490, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 647*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 650*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 657*/ {
bevl_r = bevp_container.bemd_2(49893363, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 659*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 662*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 669*/ {
bevp_container.bemd_1(1164088991, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 671*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 674*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 680*/ {
bevl_r = bevp_container.bemd_1(-5295796, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 682*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 685*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 692*/ {
bevp_container.bemd_1(-5295796, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 694*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 697*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 703*/ {
bevl_r = bevp_container.bemd_2(1199110579, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 705*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 708*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 715*/ {
bevp_container.bemd_2(1199110579, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 717*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 720*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 726*/ {
bevl_rc = bevp_container.bemd_3(1230274778, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 728*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 731*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSet_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 738*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-464580100);
bevp_lock.bem_unlock_0();
} /* Line: 740*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 743*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 750*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1177983924);
bevp_lock.bem_unlock_0();
} /* Line: 752*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 755*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 762*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-434227161, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 764*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 767*/
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 774*/ {
bevt_0_ta_ph = bevp_container.bemd_1(-1828493463, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 775*/ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 776*/
 else /* Line: 777*/ {
bevp_container.bemd_2(1199110579, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 779*/
bevp_lock.bem_unlock_0();
} /* Line: 781*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 784*/
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 791*/ {
bevt_0_ta_ph = bevp_container.bemd_1(-1828493463, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 792*/ {
bevl_result = bevp_container.bemd_1(427083876, beva_key);
} /* Line: 793*/
 else /* Line: 794*/ {
bevp_container.bemd_2(1199110579, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 796*/
bevp_lock.bem_unlock_0();
} /* Line: 798*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 801*/
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 808*/ {
bevp_container.bemd_3(73651347, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 810*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 813*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 819*/ {
bevl_r = bevp_container.bemd_1(1327676490, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 821*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 824*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 831*/ {
bevl_r = bevp_container.bemd_2(-919937258, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 833*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 836*/
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 843*/ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-1407306250);
bevp_lock.bem_unlock_0();
} /* Line: 845*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 848*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 855*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-2124667954);
bevp_lock.bem_unlock_0();
} /* Line: 857*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 860*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 867*/ {
bevl_r = bevp_container.bemd_0(-981204172);
bevp_lock.bem_unlock_0();
} /* Line: 869*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 872*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 879*/ {
bevp_container.bemd_0(-630224306);
bevp_lock.bem_unlock_0();
} /* Line: 881*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 884*/
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 890*/ {
bevp_container.bemd_0(-600132606);
bevp_lock.bem_unlock_0();
} /* Line: 892*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 895*/
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {581, 584, 586, 587, 589, 590, 595, 597, 598, 600, 601, 603, 607, 609, 610, 612, 613, 615, 619, 621, 622, 624, 625, 627, 631, 633, 634, 636, 637, 639, 643, 645, 646, 647, 649, 650, 652, 656, 658, 659, 661, 662, 664, 668, 670, 671, 673, 674, 679, 681, 682, 684, 685, 687, 691, 693, 694, 696, 697, 702, 704, 705, 707, 708, 710, 714, 716, 717, 719, 720, 725, 727, 728, 730, 731, 733, 737, 739, 740, 742, 743, 745, 749, 751, 752, 754, 755, 757, 761, 763, 764, 766, 767, 769, 773, 775, 776, 778, 779, 781, 783, 784, 786, 790, 792, 793, 795, 796, 798, 800, 801, 803, 807, 809, 810, 812, 813, 818, 820, 821, 823, 824, 826, 830, 832, 833, 835, 836, 838, 842, 844, 845, 847, 848, 850, 854, 856, 857, 859, 860, 862, 866, 868, 869, 871, 872, 874, 878, 880, 881, 883, 884, 889, 891, 892, 894, 895, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 241, 243, 244, 248, 249, 251, 257, 259, 261, 264, 265, 267, 271, 272, 274, 280, 282, 284, 287, 288, 290, 294, 295, 297, 301, 303, 304, 308, 309, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 376, 378, 379, 383, 384, 386, 390, 392, 393, 397, 398, 404, 406, 407, 411, 412, 417, 420, 424, 427};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 581 17
new 0 581 17
lock 0 584 18
assign 1 586 20
unlock 0 587 21
unlock 0 589 25
throw 1 590 26
lock 0 595 33
assign 1 597 35
has 1 597 35
unlock 0 598 36
unlock 0 600 40
throw 1 601 41
return 1 603 43
lock 0 607 48
assign 1 609 50
has 2 609 50
unlock 0 610 51
unlock 0 612 55
throw 1 613 56
return 1 615 58
lock 0 619 63
assign 1 621 65
get 0 621 65
unlock 0 622 66
unlock 0 624 70
throw 1 625 71
return 1 627 73
lock 0 631 78
assign 1 633 80
get 1 633 80
unlock 0 634 81
unlock 0 636 85
throw 1 637 86
return 1 639 88
lock 0 643 93
assign 1 645 95
get 1 645 95
delete 1 646 96
unlock 0 647 97
unlock 0 649 101
throw 1 650 102
return 1 652 104
lock 0 656 109
assign 1 658 111
get 2 658 111
unlock 0 659 112
unlock 0 661 116
throw 1 662 117
return 1 664 119
lock 0 668 123
addValue 1 670 125
unlock 0 671 126
unlock 0 673 130
throw 1 674 131
lock 0 679 138
assign 1 681 140
put 1 681 140
unlock 0 682 141
unlock 0 684 145
throw 1 685 146
return 1 687 148
lock 0 691 152
put 1 693 154
unlock 0 694 155
unlock 0 696 159
throw 1 697 160
lock 0 702 167
assign 1 704 169
put 2 704 169
unlock 0 705 170
unlock 0 707 174
throw 1 708 175
return 1 710 177
lock 0 714 181
put 2 716 183
unlock 0 717 184
unlock 0 719 188
throw 1 720 189
lock 0 725 196
assign 1 727 198
testAndPut 3 727 198
unlock 0 728 199
unlock 0 730 203
throw 1 731 204
return 1 733 206
lock 0 737 211
assign 1 739 213
getSet 0 739 213
unlock 0 740 214
unlock 0 742 218
throw 1 743 219
return 1 745 221
lock 0 749 226
assign 1 751 228
getMap 0 751 228
unlock 0 752 229
unlock 0 754 233
throw 1 755 234
return 1 757 236
lock 0 761 241
assign 1 763 243
getMap 1 763 243
unlock 0 764 244
unlock 0 766 248
throw 1 767 249
return 1 769 251
lock 0 773 257
assign 1 775 259
has 1 775 259
assign 1 776 261
new 0 776 261
put 2 778 264
assign 1 779 265
new 0 779 265
unlock 0 781 267
unlock 0 783 271
throw 1 784 272
return 1 786 274
lock 0 790 280
assign 1 792 282
has 1 792 282
assign 1 793 284
get 1 793 284
put 2 795 287
assign 1 796 288
unlock 0 798 290
unlock 0 800 294
throw 1 801 295
return 1 803 297
lock 0 807 301
put 3 809 303
unlock 0 810 304
unlock 0 812 308
throw 1 813 309
lock 0 818 316
assign 1 820 318
delete 1 820 318
unlock 0 821 319
unlock 0 823 323
throw 1 824 324
return 1 826 326
lock 0 830 331
assign 1 832 333
delete 2 832 333
unlock 0 833 334
unlock 0 835 338
throw 1 836 339
return 1 838 341
lock 0 842 346
assign 1 844 348
sizeGet 0 844 348
unlock 0 845 349
unlock 0 847 353
throw 1 848 354
return 1 850 356
lock 0 854 361
assign 1 856 363
isEmptyGet 0 856 363
unlock 0 857 364
unlock 0 859 368
throw 1 860 369
return 1 862 371
lock 0 866 376
assign 1 868 378
copy 0 868 378
unlock 0 869 379
unlock 0 871 383
throw 1 872 384
return 1 874 386
lock 0 878 390
clear 0 880 392
unlock 0 881 393
unlock 0 883 397
throw 1 884 398
lock 0 889 404
close 0 891 406
unlock 0 892 407
unlock 0 894 411
throw 1 895 412
return 1 0 417
assign 1 0 420
return 1 0 424
assign 1 0 427
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -473724802: return bem_copyContainer_0();
case -630224306: return bem_clear_0();
case -11439861: return bem_toString_0();
case 1027167395: return bem_print_0();
case -981204172: return bem_copy_0();
case -464580100: return bem_getSet_0();
case 122506395: return bem_lockGet_0();
case 517610545: return bem_create_0();
case -2124667954: return bem_isEmptyGet_0();
case -1177983924: return bem_getMap_0();
case -600132606: return bem_close_0();
case 1952943856: return bem_iteratorGet_0();
case -1407306250: return bem_sizeGet_0();
case 533428300: return bem_containerGet_0();
case -1501634450: return bem_new_0();
case 1962668450: return bem_hashGet_0();
case -1307164317: return bem_get_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1327676490: return bem_delete_1(bevd_0);
case -460873787: return bem_new_1(bevd_0);
case -2047953674: return bem_undef_1(bevd_0);
case 978237725: return bem_def_1(bevd_0);
case -5295796: return bem_put_1(bevd_0);
case -434227161: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 234623522: return bem_notEquals_1(bevd_0);
case 1164088991: return bem_addValue_1(bevd_0);
case 406055872: return bem_lockSet_1(bevd_0);
case 1166433784: return bem_containerSet_1(bevd_0);
case 1636659949: return bem_getAndClear_1(bevd_0);
case 105007733: return bem_equals_1(bevd_0);
case -1828493463: return bem_has_1(bevd_0);
case 427083876: return bem_get_1(bevd_0);
case 857299362: return bem_copyTo_1(bevd_0);
case -1806477140: return bem_putReturn_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -919937258: return bem_delete_2(bevd_0, bevd_1);
case 79702621: return bem_putReturn_2(bevd_0, bevd_1);
case -976124908: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 664895809: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 768821586: return bem_getOrPut_2(bevd_0, bevd_1);
case 1199110579: return bem_put_2(bevd_0, bevd_1);
case 49893363: return bem_get_2(bevd_0, bevd_1);
case -1815776256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1357121872: return bem_has_2(bevd_0, bevd_1);
case 569683502: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -450201493: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 73651347: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 1230274778: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
