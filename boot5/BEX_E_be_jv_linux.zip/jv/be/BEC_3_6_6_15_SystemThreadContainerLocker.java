package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try /* Line: 602*/ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 604*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 607*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 613*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-969395710, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 615*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 618*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 625*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-1553486244, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 627*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 630*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 637*/ {
bevl_r = bevp_container.bemd_0(-1440092732);
bevp_lock.bem_unlock_0();
} /* Line: 639*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 642*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 649*/ {
bevl_r = bevp_container.bemd_1(-659903631, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 651*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 654*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 661*/ {
bevl_r = bevp_container.bemd_1(-659903631, beva_key);
bevp_container.bemd_1(134691161, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 664*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 667*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 674*/ {
bevl_r = bevp_container.bemd_2(-1192221035, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 676*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 679*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 686*/ {
bevp_container.bemd_1(355611843, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 688*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 691*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 697*/ {
bevl_r = bevp_container.bemd_1(1219468866, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 699*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 702*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 709*/ {
bevp_container.bemd_1(1219468866, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 711*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 714*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 720*/ {
bevl_r = bevp_container.bemd_2(-1145815183, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 722*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 725*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 732*/ {
bevp_container.bemd_2(-1145815183, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 734*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 737*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 743*/ {
bevl_rc = bevp_container.bemd_3(1308496649, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 745*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 748*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSet_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 755*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-743490325);
bevp_lock.bem_unlock_0();
} /* Line: 757*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 760*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 767*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(520026575);
bevp_lock.bem_unlock_0();
} /* Line: 769*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 772*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 779*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(445389612, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 781*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 784*/
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 791*/ {
bevt_0_ta_ph = bevp_container.bemd_1(-969395710, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 792*/ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 793*/
 else /* Line: 794*/ {
bevp_container.bemd_2(-1145815183, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 796*/
bevp_lock.bem_unlock_0();
} /* Line: 798*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 801*/
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 808*/ {
bevt_0_ta_ph = bevp_container.bemd_1(-969395710, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 809*/ {
bevl_result = bevp_container.bemd_1(-659903631, beva_key);
} /* Line: 810*/
 else /* Line: 811*/ {
bevp_container.bemd_2(-1145815183, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 813*/
bevp_lock.bem_unlock_0();
} /* Line: 815*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 818*/
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 825*/ {
bevp_container.bemd_3(773209662, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 827*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 830*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 836*/ {
bevl_r = bevp_container.bemd_1(134691161, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 838*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 841*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 848*/ {
bevl_r = bevp_container.bemd_2(1931386184, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 850*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 853*/
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 860*/ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-2026840142);
bevp_lock.bem_unlock_0();
} /* Line: 862*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 865*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 872*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(1594353291);
bevp_lock.bem_unlock_0();
} /* Line: 874*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 877*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 884*/ {
bevl_r = bevp_container.bemd_0(807844599);
bevp_lock.bem_unlock_0();
} /* Line: 886*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 889*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 896*/ {
bevp_container.bemd_0(580248377);
bevp_lock.bem_unlock_0();
} /* Line: 898*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 901*/
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 907*/ {
bevp_container.bemd_0(428447159);
bevp_lock.bem_unlock_0();
} /* Line: 909*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 912*/
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {598, 601, 603, 604, 606, 607, 612, 614, 615, 617, 618, 620, 624, 626, 627, 629, 630, 632, 636, 638, 639, 641, 642, 644, 648, 650, 651, 653, 654, 656, 660, 662, 663, 664, 666, 667, 669, 673, 675, 676, 678, 679, 681, 685, 687, 688, 690, 691, 696, 698, 699, 701, 702, 704, 708, 710, 711, 713, 714, 719, 721, 722, 724, 725, 727, 731, 733, 734, 736, 737, 742, 744, 745, 747, 748, 750, 754, 756, 757, 759, 760, 762, 766, 768, 769, 771, 772, 774, 778, 780, 781, 783, 784, 786, 790, 792, 793, 795, 796, 798, 800, 801, 803, 807, 809, 810, 812, 813, 815, 817, 818, 820, 824, 826, 827, 829, 830, 835, 837, 838, 840, 841, 843, 847, 849, 850, 852, 853, 855, 859, 861, 862, 864, 865, 867, 871, 873, 874, 876, 877, 879, 883, 885, 886, 888, 889, 891, 895, 897, 898, 900, 901, 906, 908, 909, 911, 912, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 241, 243, 244, 248, 249, 251, 257, 259, 261, 264, 265, 267, 271, 272, 274, 280, 282, 284, 287, 288, 290, 294, 295, 297, 301, 303, 304, 308, 309, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 376, 378, 379, 383, 384, 386, 390, 392, 393, 397, 398, 404, 406, 407, 411, 412, 417, 420, 423, 427, 431, 434, 437, 441};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 598 17
new 0 598 17
lock 0 601 18
assign 1 603 20
unlock 0 604 21
unlock 0 606 25
throw 1 607 26
lock 0 612 33
assign 1 614 35
has 1 614 35
unlock 0 615 36
unlock 0 617 40
throw 1 618 41
return 1 620 43
lock 0 624 48
assign 1 626 50
has 2 626 50
unlock 0 627 51
unlock 0 629 55
throw 1 630 56
return 1 632 58
lock 0 636 63
assign 1 638 65
get 0 638 65
unlock 0 639 66
unlock 0 641 70
throw 1 642 71
return 1 644 73
lock 0 648 78
assign 1 650 80
get 1 650 80
unlock 0 651 81
unlock 0 653 85
throw 1 654 86
return 1 656 88
lock 0 660 93
assign 1 662 95
get 1 662 95
delete 1 663 96
unlock 0 664 97
unlock 0 666 101
throw 1 667 102
return 1 669 104
lock 0 673 109
assign 1 675 111
get 2 675 111
unlock 0 676 112
unlock 0 678 116
throw 1 679 117
return 1 681 119
lock 0 685 123
addValue 1 687 125
unlock 0 688 126
unlock 0 690 130
throw 1 691 131
lock 0 696 138
assign 1 698 140
put 1 698 140
unlock 0 699 141
unlock 0 701 145
throw 1 702 146
return 1 704 148
lock 0 708 152
put 1 710 154
unlock 0 711 155
unlock 0 713 159
throw 1 714 160
lock 0 719 167
assign 1 721 169
put 2 721 169
unlock 0 722 170
unlock 0 724 174
throw 1 725 175
return 1 727 177
lock 0 731 181
put 2 733 183
unlock 0 734 184
unlock 0 736 188
throw 1 737 189
lock 0 742 196
assign 1 744 198
testAndPut 3 744 198
unlock 0 745 199
unlock 0 747 203
throw 1 748 204
return 1 750 206
lock 0 754 211
assign 1 756 213
getSet 0 756 213
unlock 0 757 214
unlock 0 759 218
throw 1 760 219
return 1 762 221
lock 0 766 226
assign 1 768 228
getMap 0 768 228
unlock 0 769 229
unlock 0 771 233
throw 1 772 234
return 1 774 236
lock 0 778 241
assign 1 780 243
getMap 1 780 243
unlock 0 781 244
unlock 0 783 248
throw 1 784 249
return 1 786 251
lock 0 790 257
assign 1 792 259
has 1 792 259
assign 1 793 261
new 0 793 261
put 2 795 264
assign 1 796 265
new 0 796 265
unlock 0 798 267
unlock 0 800 271
throw 1 801 272
return 1 803 274
lock 0 807 280
assign 1 809 282
has 1 809 282
assign 1 810 284
get 1 810 284
put 2 812 287
assign 1 813 288
unlock 0 815 290
unlock 0 817 294
throw 1 818 295
return 1 820 297
lock 0 824 301
put 3 826 303
unlock 0 827 304
unlock 0 829 308
throw 1 830 309
lock 0 835 316
assign 1 837 318
delete 1 837 318
unlock 0 838 319
unlock 0 840 323
throw 1 841 324
return 1 843 326
lock 0 847 331
assign 1 849 333
delete 2 849 333
unlock 0 850 334
unlock 0 852 338
throw 1 853 339
return 1 855 341
lock 0 859 346
assign 1 861 348
sizeGet 0 861 348
unlock 0 862 349
unlock 0 864 353
throw 1 865 354
return 1 867 356
lock 0 871 361
assign 1 873 363
isEmptyGet 0 873 363
unlock 0 874 364
unlock 0 876 368
throw 1 877 369
return 1 879 371
lock 0 883 376
assign 1 885 378
copy 0 885 378
unlock 0 886 379
unlock 0 888 383
throw 1 889 384
return 1 891 386
lock 0 895 390
clear 0 897 392
unlock 0 898 393
unlock 0 900 397
throw 1 901 398
lock 0 906 404
close 0 908 406
unlock 0 909 407
unlock 0 911 411
throw 1 912 412
return 1 0 417
return 1 0 420
assign 1 0 423
assign 1 0 427
return 1 0 431
return 1 0 434
assign 1 0 437
assign 1 0 441
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1915513690: return bem_classNameGet_0();
case 1604055525: return bem_hashGet_0();
case 2146152698: return bem_containerGetDirect_0();
case 428447159: return bem_close_0();
case -1902821230: return bem_sourceFileNameGet_0();
case 1594353291: return bem_isEmptyGet_0();
case 1476572399: return bem_new_0();
case 807844599: return bem_copy_0();
case -2026840142: return bem_sizeGet_0();
case 1686011874: return bem_lockGetDirect_0();
case -1090822341: return bem_copyContainer_0();
case 708488762: return bem_create_0();
case -436514878: return bem_echo_0();
case 1534778339: return bem_serializeContents_0();
case 290193605: return bem_toString_0();
case -129556018: return bem_fieldNamesGet_0();
case 210349252: return bem_deserializeClassNameGet_0();
case 580248377: return bem_clear_0();
case 1854049419: return bem_containerGet_0();
case 1528097206: return bem_serializeToString_0();
case 198473032: return bem_tagGet_0();
case -1781364078: return bem_print_0();
case 1057028028: return bem_fieldIteratorGet_0();
case -1440092732: return bem_get_0();
case -1173533567: return bem_lockGet_0();
case 715553388: return bem_serializationIteratorGet_0();
case -450907329: return bem_iteratorGet_0();
case -743490325: return bem_getSet_0();
case 520026575: return bem_getMap_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -575460023: return bem_sameType_1(bevd_0);
case -969395710: return bem_has_1(bevd_0);
case -1627779291: return bem_lockSet_1(bevd_0);
case 949111243: return bem_lockSetDirect_1(bevd_0);
case 980788220: return bem_putReturn_1(bevd_0);
case -659903631: return bem_get_1(bevd_0);
case -746609219: return bem_sameObject_1(bevd_0);
case -1606202955: return bem_copyTo_1(bevd_0);
case 445389612: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1859153072: return bem_undef_1(bevd_0);
case 1880525273: return bem_otherType_1(bevd_0);
case -2147136498: return bem_getAndClear_1(bevd_0);
case 909428606: return bem_otherClass_1(bevd_0);
case 938863663: return bem_def_1(bevd_0);
case 1952504279: return bem_containerSetDirect_1(bevd_0);
case 355611843: return bem_addValue_1(bevd_0);
case 1219468866: return bem_put_1(bevd_0);
case 1141872328: return bem_new_1(bevd_0);
case -1768944168: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -835119407: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1877795134: return bem_containerSet_1(bevd_0);
case 1528010380: return bem_sameClass_1(bevd_0);
case 1342151407: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1865008630: return bem_equals_1(bevd_0);
case 134691161: return bem_delete_1(bevd_0);
case -999927226: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 506082618: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 389432552: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -1553486244: return bem_has_2(bevd_0, bevd_1);
case -1192221035: return bem_get_2(bevd_0, bevd_1);
case 465159939: return bem_putReturn_2(bevd_0, bevd_1);
case 1931386184: return bem_delete_2(bevd_0, bevd_1);
case -1145815183: return bem_put_2(bevd_0, bevd_1);
case 1582482490: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1524428651: return bem_getOrPut_2(bevd_0, bevd_1);
case -1978405023: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953140974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1983033893: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 773209662: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 1308496649: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
