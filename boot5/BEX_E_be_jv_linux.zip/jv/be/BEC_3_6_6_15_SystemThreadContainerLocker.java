package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try /* Line: 582*/ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 584*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 587*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 593*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(1423234676, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 595*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 598*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 605*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(445889852, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 607*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 610*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 617*/ {
bevl_r = bevp_container.bemd_0(875779381);
bevp_lock.bem_unlock_0();
} /* Line: 619*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 622*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 629*/ {
bevl_r = bevp_container.bemd_1(-25782840, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 631*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 634*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 641*/ {
bevl_r = bevp_container.bemd_1(-25782840, beva_key);
bevp_container.bemd_1(-283421386, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 644*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 647*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 654*/ {
bevl_r = bevp_container.bemd_2(-1296087435, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 656*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 659*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 666*/ {
bevp_container.bemd_1(134023251, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 668*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 671*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 677*/ {
bevl_r = bevp_container.bemd_1(-1052384575, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 679*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 682*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 689*/ {
bevp_container.bemd_1(-1052384575, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 691*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 694*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 700*/ {
bevl_r = bevp_container.bemd_2(1183773003, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 702*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 705*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 712*/ {
bevp_container.bemd_2(1183773003, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 714*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 717*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 723*/ {
bevl_rc = bevp_container.bemd_3(-441466293, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 725*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 728*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSet_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 735*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(570920866);
bevp_lock.bem_unlock_0();
} /* Line: 737*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 740*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 747*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1768065658);
bevp_lock.bem_unlock_0();
} /* Line: 749*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 752*/
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 759*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-408206348, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 761*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 764*/
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 771*/ {
bevt_0_ta_ph = bevp_container.bemd_1(1423234676, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 772*/ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 773*/
 else /* Line: 774*/ {
bevp_container.bemd_2(1183773003, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 776*/
bevp_lock.bem_unlock_0();
} /* Line: 778*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 781*/
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 788*/ {
bevt_0_ta_ph = bevp_container.bemd_1(1423234676, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 789*/ {
bevl_result = bevp_container.bemd_1(-25782840, beva_key);
} /* Line: 790*/
 else /* Line: 791*/ {
bevp_container.bemd_2(1183773003, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 793*/
bevp_lock.bem_unlock_0();
} /* Line: 795*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 798*/
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 805*/ {
bevp_container.bemd_3(-800959646, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 807*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 810*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 816*/ {
bevl_r = bevp_container.bemd_1(-283421386, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 818*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 821*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 828*/ {
bevl_r = bevp_container.bemd_2(-266454536, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 830*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 833*/
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 840*/ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-960604906);
bevp_lock.bem_unlock_0();
} /* Line: 842*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 845*/
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 852*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(2004745470);
bevp_lock.bem_unlock_0();
} /* Line: 854*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 857*/
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 864*/ {
bevl_r = bevp_container.bemd_0(-1401305769);
bevp_lock.bem_unlock_0();
} /* Line: 866*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 869*/
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 876*/ {
bevp_container.bemd_0(-2063510520);
bevp_lock.bem_unlock_0();
} /* Line: 878*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 881*/
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 887*/ {
bevp_container.bemd_0(-801890495);
bevp_lock.bem_unlock_0();
} /* Line: 889*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 892*/
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {578, 581, 583, 584, 586, 587, 592, 594, 595, 597, 598, 600, 604, 606, 607, 609, 610, 612, 616, 618, 619, 621, 622, 624, 628, 630, 631, 633, 634, 636, 640, 642, 643, 644, 646, 647, 649, 653, 655, 656, 658, 659, 661, 665, 667, 668, 670, 671, 676, 678, 679, 681, 682, 684, 688, 690, 691, 693, 694, 699, 701, 702, 704, 705, 707, 711, 713, 714, 716, 717, 722, 724, 725, 727, 728, 730, 734, 736, 737, 739, 740, 742, 746, 748, 749, 751, 752, 754, 758, 760, 761, 763, 764, 766, 770, 772, 773, 775, 776, 778, 780, 781, 783, 787, 789, 790, 792, 793, 795, 797, 798, 800, 804, 806, 807, 809, 810, 815, 817, 818, 820, 821, 823, 827, 829, 830, 832, 833, 835, 839, 841, 842, 844, 845, 847, 851, 853, 854, 856, 857, 859, 863, 865, 866, 868, 869, 871, 875, 877, 878, 880, 881, 886, 888, 889, 891, 892, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 241, 243, 244, 248, 249, 251, 257, 259, 261, 264, 265, 267, 271, 272, 274, 280, 282, 284, 287, 288, 290, 294, 295, 297, 301, 303, 304, 308, 309, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 376, 378, 379, 383, 384, 386, 390, 392, 393, 397, 398, 404, 406, 407, 411, 412, 417, 420, 424, 427};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 578 17
new 0 578 17
lock 0 581 18
assign 1 583 20
unlock 0 584 21
unlock 0 586 25
throw 1 587 26
lock 0 592 33
assign 1 594 35
has 1 594 35
unlock 0 595 36
unlock 0 597 40
throw 1 598 41
return 1 600 43
lock 0 604 48
assign 1 606 50
has 2 606 50
unlock 0 607 51
unlock 0 609 55
throw 1 610 56
return 1 612 58
lock 0 616 63
assign 1 618 65
get 0 618 65
unlock 0 619 66
unlock 0 621 70
throw 1 622 71
return 1 624 73
lock 0 628 78
assign 1 630 80
get 1 630 80
unlock 0 631 81
unlock 0 633 85
throw 1 634 86
return 1 636 88
lock 0 640 93
assign 1 642 95
get 1 642 95
delete 1 643 96
unlock 0 644 97
unlock 0 646 101
throw 1 647 102
return 1 649 104
lock 0 653 109
assign 1 655 111
get 2 655 111
unlock 0 656 112
unlock 0 658 116
throw 1 659 117
return 1 661 119
lock 0 665 123
addValue 1 667 125
unlock 0 668 126
unlock 0 670 130
throw 1 671 131
lock 0 676 138
assign 1 678 140
put 1 678 140
unlock 0 679 141
unlock 0 681 145
throw 1 682 146
return 1 684 148
lock 0 688 152
put 1 690 154
unlock 0 691 155
unlock 0 693 159
throw 1 694 160
lock 0 699 167
assign 1 701 169
put 2 701 169
unlock 0 702 170
unlock 0 704 174
throw 1 705 175
return 1 707 177
lock 0 711 181
put 2 713 183
unlock 0 714 184
unlock 0 716 188
throw 1 717 189
lock 0 722 196
assign 1 724 198
testAndPut 3 724 198
unlock 0 725 199
unlock 0 727 203
throw 1 728 204
return 1 730 206
lock 0 734 211
assign 1 736 213
getSet 0 736 213
unlock 0 737 214
unlock 0 739 218
throw 1 740 219
return 1 742 221
lock 0 746 226
assign 1 748 228
getMap 0 748 228
unlock 0 749 229
unlock 0 751 233
throw 1 752 234
return 1 754 236
lock 0 758 241
assign 1 760 243
getMap 1 760 243
unlock 0 761 244
unlock 0 763 248
throw 1 764 249
return 1 766 251
lock 0 770 257
assign 1 772 259
has 1 772 259
assign 1 773 261
new 0 773 261
put 2 775 264
assign 1 776 265
new 0 776 265
unlock 0 778 267
unlock 0 780 271
throw 1 781 272
return 1 783 274
lock 0 787 280
assign 1 789 282
has 1 789 282
assign 1 790 284
get 1 790 284
put 2 792 287
assign 1 793 288
unlock 0 795 290
unlock 0 797 294
throw 1 798 295
return 1 800 297
lock 0 804 301
put 3 806 303
unlock 0 807 304
unlock 0 809 308
throw 1 810 309
lock 0 815 316
assign 1 817 318
delete 1 817 318
unlock 0 818 319
unlock 0 820 323
throw 1 821 324
return 1 823 326
lock 0 827 331
assign 1 829 333
delete 2 829 333
unlock 0 830 334
unlock 0 832 338
throw 1 833 339
return 1 835 341
lock 0 839 346
assign 1 841 348
sizeGet 0 841 348
unlock 0 842 349
unlock 0 844 353
throw 1 845 354
return 1 847 356
lock 0 851 361
assign 1 853 363
isEmptyGet 0 853 363
unlock 0 854 364
unlock 0 856 368
throw 1 857 369
return 1 859 371
lock 0 863 376
assign 1 865 378
copy 0 865 378
unlock 0 866 379
unlock 0 868 383
throw 1 869 384
return 1 871 386
lock 0 875 390
clear 0 877 392
unlock 0 878 393
unlock 0 880 397
throw 1 881 398
lock 0 886 404
close 0 888 406
unlock 0 889 407
unlock 0 891 411
throw 1 892 412
return 1 0 417
assign 1 0 420
return 1 0 424
assign 1 0 427
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1336616742: return bem_fieldNamesGet_0();
case -2063510520: return bem_clear_0();
case -1054253204: return bem_new_0();
case -1768065658: return bem_getMap_0();
case -960604906: return bem_sizeGet_0();
case 457178368: return bem_classNameGet_0();
case -1401305769: return bem_copy_0();
case 514762065: return bem_lockGet_0();
case 1497956054: return bem_toString_0();
case -679465390: return bem_copyContainer_0();
case 570920866: return bem_getSet_0();
case -1826754149: return bem_tagGet_0();
case 1787710498: return bem_iteratorGet_0();
case 1745333375: return bem_hashGet_0();
case 1653499699: return bem_create_0();
case 562138791: return bem_print_0();
case 875779381: return bem_get_0();
case -801890495: return bem_close_0();
case 2004745470: return bem_isEmptyGet_0();
case 258681370: return bem_containerGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -283421386: return bem_delete_1(bevd_0);
case 134023251: return bem_addValue_1(bevd_0);
case 586710983: return bem_notEquals_1(bevd_0);
case -1471136482: return bem_new_1(bevd_0);
case -93958152: return bem_equals_1(bevd_0);
case -25782840: return bem_get_1(bevd_0);
case 112425026: return bem_undef_1(bevd_0);
case -1052384575: return bem_put_1(bevd_0);
case -1282419489: return bem_copyTo_1(bevd_0);
case -536211780: return bem_putReturn_1(bevd_0);
case 519586024: return bem_def_1(bevd_0);
case 1423234676: return bem_has_1(bevd_0);
case 695226211: return bem_containerSet_1(bevd_0);
case -2045148476: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1894503367: return bem_sameType_1(bevd_0);
case -1094345634: return bem_otherType_1(bevd_0);
case 897088300: return bem_sameObject_1(bevd_0);
case -408206348: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 766325569: return bem_lockSet_1(bevd_0);
case 681133373: return bem_getAndClear_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -319437940: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 445889852: return bem_has_2(bevd_0, bevd_1);
case -1052889707: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -856240260: return bem_putReturn_2(bevd_0, bevd_1);
case 1183773003: return bem_put_2(bevd_0, bevd_1);
case -1651612463: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1296087435: return bem_get_2(bevd_0, bevd_1);
case 209233844: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1166269920: return bem_getOrPut_2(bevd_0, bevd_1);
case -266454536: return bem_delete_2(bevd_0, bevd_1);
case -1399119392: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 402325359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -800959646: return bem_put_3(bevd_0, bevd_1, bevd_2);
case -441466293: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
