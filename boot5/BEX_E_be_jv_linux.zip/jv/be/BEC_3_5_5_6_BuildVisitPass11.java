package be;
/* IO:File: source/build/Pass11.be */
public final class BEC_3_5_5_6_BuildVisitPass11 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass11() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass11_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x31};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass11_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_2 = {0x74,0x68,0x72,0x6F,0x77};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitPass11_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_3 = {0x54,0x68,0x69,0x73,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x75,0x73,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x65,0x78,0x61,0x63,0x74,0x6C,0x79,0x20,0x6F,0x6E,0x65,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x2C,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitPass11_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitPass11_bels_3, 46));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_4 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_6 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_7 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_8 = {0x43,0x61,0x6C,0x6C,0x20,0x6E,0x6F,0x74,0x20,0x69,0x6E,0x20,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x70,0x6F,0x73,0x69,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_9 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_10 = {0x70,0x68,0x6F,0x6C,0x64};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_11 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_3_5_5_6_BuildVisitPass11 bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst;

public static BET_3_5_5_6_BuildVisitPass11 bece_BEC_3_5_5_6_BuildVisitPass11_bevs_type;

public BEC_2_5_4_BuildNode bevp_inMtd;
public BEC_3_5_5_6_BuildVisitPass11 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_fnode = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_5_4_BuildNode bevl_inode = null;
BEC_2_5_3_BuildVar bevl_ts = null;
BEC_2_5_4_BuildNode bevl_nsc = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_unwind = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_lastStep = null;
BEC_2_6_6_SystemObject bevl_pholdv = null;
BEC_2_6_6_SystemObject bevl_phold = null;
BEC_2_6_6_SystemObject bevl_prc = null;
BEC_2_6_6_SystemObject bevl_prcc = null;
BEC_2_6_6_SystemObject bevl_phold2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_108_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_109_tmpany_phold = null;
bevt_8_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_9_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
if (bevt_8_tmpany_phold.bevi_int == bevt_9_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevl_fnode = null;
bevt_14_tmpany_phold = beva_node.bem_containedGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_firstGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-1375462113);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-1092008123);
if (bevt_11_tmpany_phold == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevl_fnode = beva_node.bem_nextDescendGet_0();
} /* Line: 26 */
bevt_17_tmpany_phold = beva_node.bem_containedGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_firstGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1375462113);
bevl_it = bevt_15_tmpany_phold.bemd_0(15052169);
while (true)
 /* Line: 28 */ {
bevt_18_tmpany_phold = bevl_it.bemd_0(-505537007);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 28 */ {
bevl_inode = (BEC_2_5_4_BuildNode) bevl_it.bemd_0(844391958);
if (bevl_fnode == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevl_fnode = bevl_inode;
} /* Line: 31 */
beva_node.bem_beforeInsert_1(bevl_inode);
} /* Line: 33 */
 else  /* Line: 28 */ {
break;
} /* Line: 28 */
} /* Line: 28 */
beva_node.bem_delete_0();
return bevl_fnode;
} /* Line: 36 */
bevt_21_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_22_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_21_tmpany_phold.bevi_int == bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevp_inMtd = beva_node;
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(1489432452);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_0));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-12288982, bevt_26_tmpany_phold);
bevl_ts = (BEC_2_5_3_BuildVar) bevt_23_tmpany_phold.bemd_0(-1018822717);
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_ts.bem_isTypedSet_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_node.bem_classGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-1018822717);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(-1443534691);
bevl_ts.bem_namepathSet_1(bevt_28_tmpany_phold);
} /* Line: 42 */
bevt_32_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_36_tmpany_phold = beva_node.bem_heldGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_0(29768415);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_1));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(-1258943525, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_40_tmpany_phold = beva_node.bem_heldGet_0();
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_0(29768415);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_6_BuildVisitPass11_bels_2));
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_1(-1258943525, bevt_41_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_38_tmpany_phold).bevi_bool) /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 49 */ {
bevt_44_tmpany_phold = beva_node.bem_containedGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_lengthGet_0();
bevt_45_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass11_bevo_0;
if (bevt_43_tmpany_phold.bevi_int > bevt_45_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
 else  /* Line: 49 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 49 */ {
bevt_48_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass11_bevo_1;
bevt_51_tmpany_phold = beva_node.bem_containedGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_lengthGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_toString_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevt_46_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_47_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_46_tmpany_phold);
} /* Line: 50 */
bevt_54_tmpany_phold = beva_node.bem_heldGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_0(29768415);
bevt_55_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_4));
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(-1258943525, bevt_55_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_52_tmpany_phold).bevi_bool) /* Line: 52 */ {
bevt_58_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(-1690755245);
if (bevt_57_tmpany_phold == null) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_61_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-1690755245);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-1855412208);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 53 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 53 */ {
bevl_nsc = beva_node.bem_firstGet_0();
if (bevl_nsc == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_64_tmpany_phold = bevl_nsc.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
 else  /* Line: 61 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 61 */ {
bevt_68_tmpany_phold = bevl_nsc.bem_heldGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(29768415);
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_5));
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_1(-1258943525, bevt_69_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_66_tmpany_phold).bevi_bool) /* Line: 61 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
 else  /* Line: 61 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 61 */ {
} /* Line: 61 */
 else  /* Line: 63 */ {
bevt_70_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_70_tmpany_phold.bemd_1(-1215801968, null);
} /* Line: 65 */
} /* Line: 61 */
} /* Line: 53 */
bevt_73_tmpany_phold = beva_node.bem_heldGet_0();
bevt_72_tmpany_phold = bevt_73_tmpany_phold.bemd_0(1240582366);
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(-1577581367);
if (((BEC_2_5_4_LogicBool) bevt_71_tmpany_phold).bevi_bool) /* Line: 69 */ {
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(-479475838, beva_node);
bevt_75_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(1489432452);
bevt_76_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_6));
bevl_v = bevt_74_tmpany_phold.bemd_1(-12288982, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_nd.bemd_1(2098598976, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevl_v.bemd_0(-1018822717);
bevl_nd.bemd_1(1958639300, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_79_tmpany_phold.bemd_1(1285511521, bevt_80_tmpany_phold);
beva_node.bem_prepend_1((BEC_2_5_4_BuildNode) bevl_nd );
} /* Line: 76 */
bevt_83_tmpany_phold = beva_node.bem_heldGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_0(29768415);
bevt_84_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_7));
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(-1258943525, bevt_84_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_81_tmpany_phold).bevi_bool) /* Line: 79 */ {
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 80 */
bevl_unwind = be.BECS_Runtime.boolTrue;
bevl_c0 = beva_node.bem_containerGet_0();
if (bevl_c0 == null) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_3_5_5_6_BuildVisitPass11_bels_8));
bevt_87_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_88_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_87_tmpany_phold);
} /* Line: 85 */
bevt_90_tmpany_phold = bevl_c0.bemd_0(-1890031504);
bevt_91_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_1(-1258943525, bevt_91_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_89_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevt_94_tmpany_phold = bevl_c0.bemd_0(-1018822717);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(29768415);
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_9));
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_1(-1258943525, bevt_95_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 89 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 89 */
 else  /* Line: 89 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 89 */ {
bevt_96_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 89 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 89 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 89 */
 else  /* Line: 89 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 89 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 90 */
 else  /* Line: 89 */ {
bevt_98_tmpany_phold = bevl_c0.bemd_0(-1890031504);
bevt_99_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(-1258943525, bevt_99_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_97_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 92 */
} /* Line: 89 */
if (((BEC_2_5_4_LogicBool) bevl_unwind).bevi_bool) /* Line: 94 */ {
bevl_cnode = bevl_c0;
bevl_lastStep = null;
while (true)
 /* Line: 99 */ {
bevt_101_tmpany_phold = bevl_cnode.bemd_0(-1890031504);
bevt_102_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_1(-1814510964, bevt_102_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_100_tmpany_phold).bevi_bool) /* Line: 99 */ {
bevl_lastStep = bevl_cnode;
bevl_cnode = bevl_cnode.bemd_0(1609336053);
} /* Line: 102 */
 else  /* Line: 99 */ {
break;
} /* Line: 99 */
} /* Line: 99 */
bevt_103_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_6_BuildVisitPass11_bels_10));
bevl_pholdv = bevl_lastStep.bemd_2(-1997626959, bevt_103_tmpany_phold, bevp_build);
bevl_phold = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold.bemd_1(-479475838, beva_node);
bevt_104_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold.bemd_1(2098598976, bevt_104_tmpany_phold);
bevl_phold.bemd_1(1958639300, bevl_pholdv);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_phold );
bevl_phold.bemd_0(259915101);
bevl_prc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_prc.bemd_1(-479475838, beva_node);
bevt_105_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_prc.bemd_1(2098598976, bevt_105_tmpany_phold);
bevl_prcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_106_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_11));
bevl_prcc.bemd_1(1429540364, bevt_106_tmpany_phold);
bevl_prc.bemd_1(1958639300, bevl_prcc);
bevl_phold2 = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold2.bemd_1(-479475838, beva_node);
bevt_107_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold2.bemd_1(2098598976, bevt_107_tmpany_phold);
bevl_phold2.bemd_1(1958639300, bevl_pholdv);
bevl_prc.bemd_1(114554925, bevl_phold2);
bevl_prc.bemd_1(114554925, beva_node);
bevl_lastStep.bemd_1(-1114957024, bevl_prc);
bevt_108_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_108_tmpany_phold;
} /* Line: 127 */
} /* Line: 94 */
bevt_109_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_109_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inMtdGet_0() throws Throwable {
return bevp_inMtd;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inMtdGetDirect_0() throws Throwable {
return bevp_inMtd;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 23, 23, 23, 24, 25, 25, 25, 25, 25, 25, 26, 28, 28, 28, 28, 28, 29, 30, 30, 31, 33, 35, 36, 38, 38, 38, 38, 39, 40, 40, 40, 40, 40, 41, 41, 42, 42, 42, 42, 47, 47, 47, 47, 49, 49, 49, 49, 0, 49, 49, 49, 49, 0, 0, 49, 49, 49, 49, 49, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 52, 52, 52, 52, 53, 53, 53, 53, 53, 53, 53, 0, 0, 0, 60, 61, 61, 61, 61, 61, 61, 0, 0, 0, 61, 61, 61, 61, 0, 0, 0, 65, 65, 69, 69, 69, 70, 71, 72, 72, 72, 72, 73, 73, 74, 74, 75, 75, 75, 76, 79, 79, 79, 79, 80, 80, 82, 83, 84, 84, 85, 85, 85, 89, 89, 89, 89, 89, 89, 89, 0, 0, 0, 89, 0, 0, 0, 90, 91, 91, 91, 92, 95, 96, 99, 99, 99, 101, 102, 107, 107, 108, 109, 110, 110, 111, 112, 113, 114, 115, 116, 116, 117, 118, 118, 119, 120, 121, 122, 122, 123, 124, 125, 126, 127, 127, 130, 130, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {156, 157, 158, 163, 164, 165, 166, 167, 168, 169, 174, 175, 177, 178, 179, 180, 183, 185, 186, 191, 192, 194, 200, 201, 203, 204, 205, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 224, 225, 226, 231, 232, 233, 234, 235, 237, 240, 241, 242, 243, 245, 248, 252, 253, 254, 255, 260, 261, 264, 268, 271, 272, 273, 274, 275, 276, 277, 279, 280, 281, 282, 284, 285, 286, 291, 292, 293, 294, 296, 299, 303, 306, 307, 312, 313, 314, 315, 320, 321, 324, 328, 331, 332, 333, 334, 336, 339, 343, 348, 349, 353, 354, 355, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 372, 373, 374, 375, 377, 378, 380, 381, 382, 387, 388, 389, 390, 392, 393, 394, 396, 397, 398, 399, 401, 404, 408, 411, 413, 416, 420, 423, 426, 427, 428, 430, 434, 435, 438, 439, 440, 442, 443, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 478, 479, 482, 485, 488, 492};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 156
typenameGet 0 23 156
assign 1 23 157
EXPRGet 0 23 157
assign 1 23 158
equals 1 23 163
assign 1 24 164
assign 1 25 165
containedGet 0 25 165
assign 1 25 166
firstGet 0 25 166
assign 1 25 167
containedGet 0 25 167
assign 1 25 168
firstNodeGet 0 25 168
assign 1 25 169
undef 1 25 174
assign 1 26 175
nextDescendGet 0 26 175
assign 1 28 177
containedGet 0 28 177
assign 1 28 178
firstGet 0 28 178
assign 1 28 179
containedGet 0 28 179
assign 1 28 180
iteratorGet 0 28 180
assign 1 28 183
hasNextGet 0 28 183
assign 1 29 185
nextGet 0 29 185
assign 1 30 186
undef 1 30 191
assign 1 31 192
beforeInsert 1 33 194
delete 0 35 200
return 1 36 201
assign 1 38 203
typenameGet 0 38 203
assign 1 38 204
METHODGet 0 38 204
assign 1 38 205
equals 1 38 210
assign 1 39 211
assign 1 40 212
heldGet 0 40 212
assign 1 40 213
anyMapGet 0 40 213
assign 1 40 214
new 0 40 214
assign 1 40 215
get 1 40 215
assign 1 40 216
heldGet 0 40 216
assign 1 41 217
new 0 41 217
isTypedSet 1 41 218
assign 1 42 219
classGet 0 42 219
assign 1 42 220
heldGet 0 42 220
assign 1 42 221
namepathGet 0 42 221
namepathSet 1 42 222
assign 1 47 224
typenameGet 0 47 224
assign 1 47 225
CALLGet 0 47 225
assign 1 47 226
equals 1 47 231
assign 1 49 232
heldGet 0 49 232
assign 1 49 233
nameGet 0 49 233
assign 1 49 234
new 0 49 234
assign 1 49 235
equals 1 49 235
assign 1 0 237
assign 1 49 240
heldGet 0 49 240
assign 1 49 241
nameGet 0 49 241
assign 1 49 242
new 0 49 242
assign 1 49 243
equals 1 49 243
assign 1 0 245
assign 1 0 248
assign 1 49 252
containedGet 0 49 252
assign 1 49 253
lengthGet 0 49 253
assign 1 49 254
new 0 49 254
assign 1 49 255
greater 1 49 260
assign 1 0 261
assign 1 0 264
assign 1 0 268
assign 1 50 271
new 0 50 271
assign 1 50 272
containedGet 0 50 272
assign 1 50 273
lengthGet 0 50 273
assign 1 50 274
toString 0 50 274
assign 1 50 275
add 1 50 275
assign 1 50 276
new 2 50 276
throw 1 50 277
assign 1 52 279
heldGet 0 52 279
assign 1 52 280
nameGet 0 52 280
assign 1 52 281
new 0 52 281
assign 1 52 282
equals 1 52 282
assign 1 53 284
heldGet 0 53 284
assign 1 53 285
rtypeGet 0 53 285
assign 1 53 286
def 1 53 291
assign 1 53 292
heldGet 0 53 292
assign 1 53 293
rtypeGet 0 53 293
assign 1 53 294
impliedGet 0 53 294
assign 1 0 296
assign 1 0 299
assign 1 0 303
assign 1 60 306
firstGet 0 60 306
assign 1 61 307
def 1 61 312
assign 1 61 313
typenameGet 0 61 313
assign 1 61 314
VARGet 0 61 314
assign 1 61 315
equals 1 61 320
assign 1 0 321
assign 1 0 324
assign 1 0 328
assign 1 61 331
heldGet 0 61 331
assign 1 61 332
nameGet 0 61 332
assign 1 61 333
new 0 61 333
assign 1 61 334
equals 1 61 334
assign 1 0 336
assign 1 0 339
assign 1 0 343
assign 1 65 348
heldGet 0 65 348
rtypeSet 1 65 349
assign 1 69 353
heldGet 0 69 353
assign 1 69 354
boundGet 0 69 354
assign 1 69 355
not 0 69 355
assign 1 70 357
new 1 70 357
copyLoc 1 71 358
assign 1 72 359
heldGet 0 72 359
assign 1 72 360
anyMapGet 0 72 360
assign 1 72 361
new 0 72 361
assign 1 72 362
get 1 72 362
assign 1 73 363
VARGet 0 73 363
typenameSet 1 73 364
assign 1 74 365
heldGet 0 74 365
heldSet 1 74 366
assign 1 75 367
heldGet 0 75 367
assign 1 75 368
new 0 75 368
boundSet 1 75 369
prepend 1 76 370
assign 1 79 372
heldGet 0 79 372
assign 1 79 373
nameGet 0 79 373
assign 1 79 374
new 0 79 374
assign 1 79 375
equals 1 79 375
assign 1 80 377
nextDescendGet 0 80 377
return 1 80 378
assign 1 82 380
new 0 82 380
assign 1 83 381
containerGet 0 83 381
assign 1 84 382
undef 1 84 387
assign 1 85 388
new 0 85 388
assign 1 85 389
new 2 85 389
throw 1 85 390
assign 1 89 392
typenameGet 0 89 392
assign 1 89 393
CALLGet 0 89 393
assign 1 89 394
equals 1 89 394
assign 1 89 396
heldGet 0 89 396
assign 1 89 397
nameGet 0 89 397
assign 1 89 398
new 0 89 398
assign 1 89 399
equals 1 89 399
assign 1 0 401
assign 1 0 404
assign 1 0 408
assign 1 89 411
isSecondGet 0 89 411
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 90 423
new 0 90 423
assign 1 91 426
typenameGet 0 91 426
assign 1 91 427
BRACESGet 0 91 427
assign 1 91 428
equals 1 91 428
assign 1 92 430
new 0 92 430
assign 1 95 434
assign 1 96 435
assign 1 99 438
typenameGet 0 99 438
assign 1 99 439
BRACESGet 0 99 439
assign 1 99 440
notEquals 1 99 440
assign 1 101 442
assign 1 102 443
containerGet 0 102 443
assign 1 107 449
new 0 107 449
assign 1 107 450
tmpVar 2 107 450
assign 1 108 451
new 1 108 451
copyLoc 1 109 452
assign 1 110 453
VARGet 0 110 453
typenameSet 1 110 454
heldSet 1 111 455
replaceWith 1 112 456
addVariable 0 113 457
assign 1 114 458
new 1 114 458
copyLoc 1 115 459
assign 1 116 460
CALLGet 0 116 460
typenameSet 1 116 461
assign 1 117 462
new 0 117 462
assign 1 118 463
new 0 118 463
nameSet 1 118 464
heldSet 1 119 465
assign 1 120 466
new 1 120 466
copyLoc 1 121 467
assign 1 122 468
VARGet 0 122 468
typenameSet 1 122 469
heldSet 1 123 470
addValue 1 124 471
addValue 1 125 472
beforeInsert 1 126 473
assign 1 127 474
nextDescendGet 0 127 474
return 1 127 475
assign 1 130 478
nextDescendGet 0 130 478
return 1 130 479
return 1 0 482
return 1 0 485
assign 1 0 488
assign 1 0 492
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 296034201: return bem_buildGet_0();
case 1770146810: return bem_serializeToString_0();
case 1361603917: return bem_create_0();
case 1497740622: return bem_transGetDirect_0();
case -1809283124: return bem_transGet_0();
case -512745226: return bem_tagGet_0();
case 150594226: return bem_toAny_0();
case -2044264328: return bem_constGetDirect_0();
case 475849232: return bem_fieldNamesGet_0();
case -481458436: return bem_once_0();
case 970559243: return bem_hashGet_0();
case -232339846: return bem_classNameGet_0();
case 189063253: return bem_serializeContents_0();
case -696933955: return bem_toString_0();
case -2122292357: return bem_constGet_0();
case -791198660: return bem_serializationIteratorGet_0();
case 734719264: return bem_copy_0();
case 865626065: return bem_many_0();
case -1010395565: return bem_deserializeClassNameGet_0();
case 15052169: return bem_iteratorGet_0();
case -1817950071: return bem_buildGetDirect_0();
case -1897829372: return bem_ntypesGet_0();
case -866769073: return bem_new_0();
case -626586675: return bem_inMtdGet_0();
case -1238312381: return bem_print_0();
case 2125020791: return bem_inMtdGetDirect_0();
case 1064240293: return bem_sourceFileNameGet_0();
case -96306095: return bem_echo_0();
case 68732196: return bem_ntypesGetDirect_0();
case 1703076999: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1696224976: return bem_otherClass_1(bevd_0);
case -1555556152: return bem_defined_1(bevd_0);
case 721379891: return bem_otherType_1(bevd_0);
case -1411547316: return bem_sameObject_1(bevd_0);
case -567821052: return bem_transSetDirect_1(bevd_0);
case -1378821005: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -290974775: return bem_inMtdSetDirect_1(bevd_0);
case -802075689: return bem_buildSet_1(bevd_0);
case 954777710: return bem_undefined_1(bevd_0);
case -649697995: return bem_constSetDirect_1(bevd_0);
case 789848846: return bem_copyTo_1(bevd_0);
case 1091105903: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1258943525: return bem_equals_1(bevd_0);
case -1814510964: return bem_notEquals_1(bevd_0);
case -1120531188: return bem_buildSetDirect_1(bevd_0);
case 1689607871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -364708873: return bem_constSet_1(bevd_0);
case -304012900: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -750063225: return bem_end_1(bevd_0);
case -1973562246: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -759839001: return bem_ntypesSetDirect_1(bevd_0);
case 657166569: return bem_inMtdSet_1(bevd_0);
case -334908535: return bem_transSet_1(bevd_0);
case 952631001: return bem_undef_1(bevd_0);
case 2051076402: return bem_ntypesSet_1(bevd_0);
case -1708031237: return bem_begin_1(bevd_0);
case -1657467808: return bem_def_1(bevd_0);
case -2018144381: return bem_sameType_1(bevd_0);
case -1120668425: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -133579010: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -750254672: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1191848195: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 514912045: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2072659817: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1041788971: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 84003596: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass11_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass11_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass11();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst = (BEC_3_5_5_6_BuildVisitPass11) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_type;
}
}
