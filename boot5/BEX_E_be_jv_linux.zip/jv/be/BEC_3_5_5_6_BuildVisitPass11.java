package be;
/* IO:File: source/build/Pass11.be */
public final class BEC_3_5_5_6_BuildVisitPass11 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass11() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass11_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x31};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass11_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_2 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_3 = {0x54,0x68,0x69,0x73,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x75,0x73,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x65,0x78,0x61,0x63,0x74,0x6C,0x79,0x20,0x6F,0x6E,0x65,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x2C,0x20,0x6E,0x6F,0x74,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_5 = {0x43,0x61,0x6C,0x6C,0x20,0x6E,0x6F,0x74,0x20,0x69,0x6E,0x20,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x70,0x6F,0x73,0x69,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_6 = {0x70,0x68};
public static BEC_3_5_5_6_BuildVisitPass11 bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst;

public static BET_3_5_5_6_BuildVisitPass11 bece_BEC_3_5_5_6_BuildVisitPass11_bevs_type;

public BEC_2_5_4_BuildNode bevp_inMtd;
public BEC_3_5_5_6_BuildVisitPass11 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_fnode = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_5_4_BuildNode bevl_inode = null;
BEC_2_5_3_BuildVar bevl_ts = null;
BEC_2_5_4_BuildNode bevl_nsc = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_unwind = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_lastStep = null;
BEC_2_6_6_SystemObject bevl_pholdv = null;
BEC_2_6_6_SystemObject bevl_phold = null;
BEC_2_6_6_SystemObject bevl_prc = null;
BEC_2_6_6_SystemObject bevl_prcc = null;
BEC_2_6_6_SystemObject bevl_phold2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_5_4_LogicBool bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_5_4_BuildNode bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
BEC_2_4_3_MathInt bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_3_MathInt bevt_104_ta_ph = null;
BEC_2_4_3_MathInt bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_4_3_MathInt bevt_107_ta_ph = null;
BEC_2_5_4_BuildNode bevt_108_ta_ph = null;
BEC_2_5_4_BuildNode bevt_109_ta_ph = null;
bevt_8_ta_ph = beva_node.bem_typenameGet_0();
bevt_9_ta_ph = bevp_ntypes.bem_EXPRGet_0();
if (bevt_8_ta_ph.bevi_int == bevt_9_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 22*/ {
bevl_fnode = null;
bevt_14_ta_ph = beva_node.bem_containedGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_firstGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(1243490739);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(869574020);
if (bevt_11_ta_ph == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 24*/ {
bevl_fnode = beva_node.bem_nextDescendGet_0();
} /* Line: 25*/
bevt_17_ta_ph = beva_node.bem_containedGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bem_firstGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1243490739);
bevl_it = bevt_15_ta_ph.bemd_0(-1650622151);
while (true)
/* Line: 27*/ {
bevt_18_ta_ph = bevl_it.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 27*/ {
bevl_inode = (BEC_2_5_4_BuildNode) bevl_it.bemd_0(-645349501);
if (bevl_fnode == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 29*/ {
bevl_fnode = bevl_inode;
} /* Line: 30*/
beva_node.bem_beforeInsert_1(bevl_inode);
} /* Line: 32*/
 else /* Line: 27*/ {
break;
} /* Line: 27*/
} /* Line: 27*/
beva_node.bem_delete_0();
return bevl_fnode;
} /* Line: 35*/
bevt_21_ta_ph = beva_node.bem_typenameGet_0();
bevt_22_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_21_ta_ph.bevi_int == bevt_22_ta_ph.bevi_int) {
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 37*/ {
bevp_inMtd = beva_node;
bevt_25_ta_ph = beva_node.bem_heldGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(-704224906);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_0));
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(1615283662, bevt_26_ta_ph);
bevl_ts = (BEC_2_5_3_BuildVar) bevt_23_ta_ph.bemd_0(-2094503992);
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
bevl_ts.bem_isTypedSet_1(bevt_27_ta_ph);
bevt_30_ta_ph = beva_node.bem_classGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(-2094503992);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-1843396272);
bevl_ts.bem_namepathSet_1(bevt_28_ta_ph);
} /* Line: 41*/
bevt_32_ta_ph = beva_node.bem_typenameGet_0();
bevt_33_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_32_ta_ph.bevi_int == bevt_33_ta_ph.bevi_int) {
bevt_31_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_31_ta_ph.bevi_bool)/* Line: 46*/ {
bevt_36_ta_ph = beva_node.bem_heldGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bemd_0(1176098110);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_1));
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(689573322, bevt_37_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 48*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 48*/ {
bevt_40_ta_ph = beva_node.bem_heldGet_0();
bevt_39_ta_ph = bevt_40_ta_ph.bemd_0(1176098110);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_6_BuildVisitPass11_bels_2));
bevt_38_ta_ph = bevt_39_ta_ph.bemd_1(689573322, bevt_41_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_38_ta_ph).bevi_bool)/* Line: 48*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 48*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 48*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 48*/ {
bevt_44_ta_ph = beva_node.bem_containedGet_0();
bevt_43_ta_ph = bevt_44_ta_ph.bem_lengthGet_0();
bevt_45_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevt_43_ta_ph.bevi_int > bevt_45_ta_ph.bevi_int) {
bevt_42_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_42_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 48*/
 else /* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 48*/ {
bevt_48_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_3_5_5_6_BuildVisitPass11_bels_3));
bevt_51_ta_ph = beva_node.bem_containedGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bem_lengthGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_toString_0();
bevt_47_ta_ph = bevt_48_ta_ph.bem_add_1(bevt_49_ta_ph);
bevt_46_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_47_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_46_ta_ph);
} /* Line: 49*/
bevt_54_ta_ph = beva_node.bem_heldGet_0();
bevt_53_ta_ph = bevt_54_ta_ph.bemd_0(1176098110);
bevt_55_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_1));
bevt_52_ta_ph = bevt_53_ta_ph.bemd_1(689573322, bevt_55_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_52_ta_ph).bevi_bool)/* Line: 51*/ {
bevt_58_ta_ph = bevp_inMtd.bem_heldGet_0();
bevt_57_ta_ph = bevt_58_ta_ph.bemd_0(1913945961);
if (bevt_57_ta_ph == null) {
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 52*/ {
bevt_61_ta_ph = bevp_inMtd.bem_heldGet_0();
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(1913945961);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(1329288363);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 52*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 52*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 52*/
 else /* Line: 52*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 52*/ {
bevl_nsc = beva_node.bem_firstGet_0();
if (bevl_nsc == null) {
bevt_62_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_62_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_62_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_64_ta_ph = bevl_nsc.bem_typenameGet_0();
bevt_65_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_64_ta_ph.bevi_int == bevt_65_ta_ph.bevi_int) {
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 60*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 60*/
 else /* Line: 60*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 60*/ {
bevt_68_ta_ph = bevl_nsc.bem_heldGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bemd_0(1176098110);
bevt_69_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_0));
bevt_66_ta_ph = bevt_67_ta_ph.bemd_1(689573322, bevt_69_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_66_ta_ph).bevi_bool)/* Line: 60*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 60*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 60*/
 else /* Line: 60*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 60*/ {
} /* Line: 60*/
 else /* Line: 62*/ {
bevt_70_ta_ph = bevp_inMtd.bem_heldGet_0();
bevt_70_ta_ph.bemd_1(-1612376415, null);
} /* Line: 64*/
} /* Line: 60*/
} /* Line: 52*/
bevt_73_ta_ph = beva_node.bem_heldGet_0();
bevt_72_ta_ph = bevt_73_ta_ph.bemd_0(-2079252756);
bevt_71_ta_ph = bevt_72_ta_ph.bemd_0(-216446112);
if (((BEC_2_5_4_LogicBool) bevt_71_ta_ph).bevi_bool)/* Line: 68*/ {
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(-122296557, beva_node);
bevt_75_ta_ph = bevp_inMtd.bem_heldGet_0();
bevt_74_ta_ph = bevt_75_ta_ph.bemd_0(-704224906);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_0));
bevl_v = bevt_74_ta_ph.bemd_1(1615283662, bevt_76_ta_ph);
bevt_77_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_nd.bemd_1(-70479606, bevt_77_ta_ph);
bevt_78_ta_ph = bevl_v.bemd_0(-2094503992);
bevl_nd.bemd_1(1624984239, bevt_78_ta_ph);
bevt_79_ta_ph = beva_node.bem_heldGet_0();
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
bevt_79_ta_ph.bemd_1(1326076093, bevt_80_ta_ph);
beva_node.bem_prepend_1((BEC_2_5_4_BuildNode) bevl_nd );
} /* Line: 75*/
bevt_83_ta_ph = beva_node.bem_heldGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bemd_0(1176098110);
bevt_84_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_4));
bevt_81_ta_ph = bevt_82_ta_ph.bemd_1(689573322, bevt_84_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_81_ta_ph).bevi_bool)/* Line: 78*/ {
bevt_85_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_85_ta_ph;
} /* Line: 79*/
bevl_unwind = be.BECS_Runtime.boolTrue;
bevl_c0 = beva_node.bem_containerGet_0();
if (bevl_c0 == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_88_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_3_5_5_6_BuildVisitPass11_bels_5));
bevt_87_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_88_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_87_ta_ph);
} /* Line: 84*/
bevt_90_ta_ph = bevl_c0.bemd_0(-667627230);
bevt_91_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_89_ta_ph = bevt_90_ta_ph.bemd_1(689573322, bevt_91_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_89_ta_ph).bevi_bool)/* Line: 88*/ {
bevt_94_ta_ph = bevl_c0.bemd_0(-2094503992);
bevt_93_ta_ph = bevt_94_ta_ph.bemd_0(1176098110);
bevt_95_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_4));
bevt_92_ta_ph = bevt_93_ta_ph.bemd_1(689573322, bevt_95_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_92_ta_ph).bevi_bool)/* Line: 88*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 88*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 88*/
 else /* Line: 88*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 88*/ {
bevt_96_ta_ph = beva_node.bem_isSecondGet_0();
if (bevt_96_ta_ph.bevi_bool)/* Line: 88*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 88*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 88*/
 else /* Line: 88*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 88*/ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 89*/
 else /* Line: 88*/ {
bevt_98_ta_ph = bevl_c0.bemd_0(-667627230);
bevt_99_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevt_97_ta_ph = bevt_98_ta_ph.bemd_1(689573322, bevt_99_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 90*/ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 91*/
} /* Line: 88*/
if (((BEC_2_5_4_LogicBool) bevl_unwind).bevi_bool)/* Line: 93*/ {
bevl_cnode = bevl_c0;
bevl_lastStep = null;
while (true)
/* Line: 98*/ {
bevt_101_ta_ph = bevl_cnode.bemd_0(-667627230);
bevt_102_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevt_100_ta_ph = bevt_101_ta_ph.bemd_1(371048183, bevt_102_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_100_ta_ph).bevi_bool)/* Line: 98*/ {
bevl_lastStep = bevl_cnode;
bevl_cnode = bevl_cnode.bemd_0(1412047359);
} /* Line: 101*/
 else /* Line: 98*/ {
break;
} /* Line: 98*/
} /* Line: 98*/
bevt_103_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitPass11_bels_6));
bevl_pholdv = bevl_lastStep.bemd_2(-1704064198, bevt_103_ta_ph, bevp_build);
bevl_phold = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold.bemd_1(-122296557, beva_node);
bevt_104_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_phold.bemd_1(-70479606, bevt_104_ta_ph);
bevl_phold.bemd_1(1624984239, bevl_pholdv);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_phold );
bevl_phold.bemd_0(-296282587);
bevl_prc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_prc.bemd_1(-122296557, beva_node);
bevt_105_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_prc.bemd_1(-70479606, bevt_105_ta_ph);
bevl_prcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_106_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_4));
bevl_prcc.bemd_1(1682313600, bevt_106_ta_ph);
bevl_prc.bemd_1(1624984239, bevl_prcc);
bevl_phold2 = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold2.bemd_1(-122296557, beva_node);
bevt_107_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_phold2.bemd_1(-70479606, bevt_107_ta_ph);
bevl_phold2.bemd_1(1624984239, bevl_pholdv);
bevl_prc.bemd_1(-295442331, bevl_phold2);
bevl_prc.bemd_1(-295442331, beva_node);
bevl_lastStep.bemd_1(1566751724, bevl_prc);
bevt_108_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_108_ta_ph;
} /* Line: 126*/
} /* Line: 93*/
bevt_109_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_109_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inMtdGet_0() throws Throwable {
return bevp_inMtd;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {22, 22, 22, 22, 23, 24, 24, 24, 24, 24, 24, 25, 27, 27, 27, 27, 27, 28, 29, 29, 30, 32, 34, 35, 37, 37, 37, 37, 38, 39, 39, 39, 39, 39, 40, 40, 41, 41, 41, 41, 46, 46, 46, 46, 48, 48, 48, 48, 0, 48, 48, 48, 48, 0, 0, 48, 48, 48, 48, 48, 0, 0, 0, 49, 49, 49, 49, 49, 49, 49, 51, 51, 51, 51, 52, 52, 52, 52, 52, 52, 52, 0, 0, 0, 59, 60, 60, 60, 60, 60, 60, 0, 0, 0, 60, 60, 60, 60, 0, 0, 0, 64, 64, 68, 68, 68, 69, 70, 71, 71, 71, 71, 72, 72, 73, 73, 74, 74, 74, 75, 78, 78, 78, 78, 79, 79, 81, 82, 83, 83, 84, 84, 84, 88, 88, 88, 88, 88, 88, 88, 0, 0, 0, 88, 0, 0, 0, 89, 90, 90, 90, 91, 94, 95, 98, 98, 98, 100, 101, 106, 106, 107, 108, 109, 109, 110, 111, 112, 113, 114, 115, 115, 116, 117, 117, 118, 119, 120, 121, 121, 122, 123, 124, 125, 126, 126, 129, 129, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {149, 150, 151, 156, 157, 158, 159, 160, 161, 162, 167, 168, 170, 171, 172, 173, 176, 178, 179, 184, 185, 187, 193, 194, 196, 197, 198, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 217, 218, 219, 224, 225, 226, 227, 228, 230, 233, 234, 235, 236, 238, 241, 245, 246, 247, 248, 253, 254, 257, 261, 264, 265, 266, 267, 268, 269, 270, 272, 273, 274, 275, 277, 278, 279, 284, 285, 286, 287, 289, 292, 296, 299, 300, 305, 306, 307, 308, 313, 314, 317, 321, 324, 325, 326, 327, 329, 332, 336, 341, 342, 346, 347, 348, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 365, 366, 367, 368, 370, 371, 373, 374, 375, 380, 381, 382, 383, 385, 386, 387, 389, 390, 391, 392, 394, 397, 401, 404, 406, 409, 413, 416, 419, 420, 421, 423, 427, 428, 431, 432, 433, 435, 436, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 471, 472, 475, 478};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 22 149
typenameGet 0 22 149
assign 1 22 150
EXPRGet 0 22 150
assign 1 22 151
equals 1 22 156
assign 1 23 157
assign 1 24 158
containedGet 0 24 158
assign 1 24 159
firstGet 0 24 159
assign 1 24 160
containedGet 0 24 160
assign 1 24 161
firstNodeGet 0 24 161
assign 1 24 162
undef 1 24 167
assign 1 25 168
nextDescendGet 0 25 168
assign 1 27 170
containedGet 0 27 170
assign 1 27 171
firstGet 0 27 171
assign 1 27 172
containedGet 0 27 172
assign 1 27 173
iteratorGet 0 27 173
assign 1 27 176
hasNextGet 0 27 176
assign 1 28 178
nextGet 0 28 178
assign 1 29 179
undef 1 29 184
assign 1 30 185
beforeInsert 1 32 187
delete 0 34 193
return 1 35 194
assign 1 37 196
typenameGet 0 37 196
assign 1 37 197
METHODGet 0 37 197
assign 1 37 198
equals 1 37 203
assign 1 38 204
assign 1 39 205
heldGet 0 39 205
assign 1 39 206
anyMapGet 0 39 206
assign 1 39 207
new 0 39 207
assign 1 39 208
get 1 39 208
assign 1 39 209
heldGet 0 39 209
assign 1 40 210
new 0 40 210
isTypedSet 1 40 211
assign 1 41 212
classGet 0 41 212
assign 1 41 213
heldGet 0 41 213
assign 1 41 214
namepathGet 0 41 214
namepathSet 1 41 215
assign 1 46 217
typenameGet 0 46 217
assign 1 46 218
CALLGet 0 46 218
assign 1 46 219
equals 1 46 224
assign 1 48 225
heldGet 0 48 225
assign 1 48 226
nameGet 0 48 226
assign 1 48 227
new 0 48 227
assign 1 48 228
equals 1 48 228
assign 1 0 230
assign 1 48 233
heldGet 0 48 233
assign 1 48 234
nameGet 0 48 234
assign 1 48 235
new 0 48 235
assign 1 48 236
equals 1 48 236
assign 1 0 238
assign 1 0 241
assign 1 48 245
containedGet 0 48 245
assign 1 48 246
lengthGet 0 48 246
assign 1 48 247
new 0 48 247
assign 1 48 248
greater 1 48 253
assign 1 0 254
assign 1 0 257
assign 1 0 261
assign 1 49 264
new 0 49 264
assign 1 49 265
containedGet 0 49 265
assign 1 49 266
lengthGet 0 49 266
assign 1 49 267
toString 0 49 267
assign 1 49 268
add 1 49 268
assign 1 49 269
new 2 49 269
throw 1 49 270
assign 1 51 272
heldGet 0 51 272
assign 1 51 273
nameGet 0 51 273
assign 1 51 274
new 0 51 274
assign 1 51 275
equals 1 51 275
assign 1 52 277
heldGet 0 52 277
assign 1 52 278
rtypeGet 0 52 278
assign 1 52 279
def 1 52 284
assign 1 52 285
heldGet 0 52 285
assign 1 52 286
rtypeGet 0 52 286
assign 1 52 287
impliedGet 0 52 287
assign 1 0 289
assign 1 0 292
assign 1 0 296
assign 1 59 299
firstGet 0 59 299
assign 1 60 300
def 1 60 305
assign 1 60 306
typenameGet 0 60 306
assign 1 60 307
VARGet 0 60 307
assign 1 60 308
equals 1 60 313
assign 1 0 314
assign 1 0 317
assign 1 0 321
assign 1 60 324
heldGet 0 60 324
assign 1 60 325
nameGet 0 60 325
assign 1 60 326
new 0 60 326
assign 1 60 327
equals 1 60 327
assign 1 0 329
assign 1 0 332
assign 1 0 336
assign 1 64 341
heldGet 0 64 341
rtypeSet 1 64 342
assign 1 68 346
heldGet 0 68 346
assign 1 68 347
boundGet 0 68 347
assign 1 68 348
not 0 68 348
assign 1 69 350
new 1 69 350
copyLoc 1 70 351
assign 1 71 352
heldGet 0 71 352
assign 1 71 353
anyMapGet 0 71 353
assign 1 71 354
new 0 71 354
assign 1 71 355
get 1 71 355
assign 1 72 356
VARGet 0 72 356
typenameSet 1 72 357
assign 1 73 358
heldGet 0 73 358
heldSet 1 73 359
assign 1 74 360
heldGet 0 74 360
assign 1 74 361
new 0 74 361
boundSet 1 74 362
prepend 1 75 363
assign 1 78 365
heldGet 0 78 365
assign 1 78 366
nameGet 0 78 366
assign 1 78 367
new 0 78 367
assign 1 78 368
equals 1 78 368
assign 1 79 370
nextDescendGet 0 79 370
return 1 79 371
assign 1 81 373
new 0 81 373
assign 1 82 374
containerGet 0 82 374
assign 1 83 375
undef 1 83 380
assign 1 84 381
new 0 84 381
assign 1 84 382
new 2 84 382
throw 1 84 383
assign 1 88 385
typenameGet 0 88 385
assign 1 88 386
CALLGet 0 88 386
assign 1 88 387
equals 1 88 387
assign 1 88 389
heldGet 0 88 389
assign 1 88 390
nameGet 0 88 390
assign 1 88 391
new 0 88 391
assign 1 88 392
equals 1 88 392
assign 1 0 394
assign 1 0 397
assign 1 0 401
assign 1 88 404
isSecondGet 0 88 404
assign 1 0 406
assign 1 0 409
assign 1 0 413
assign 1 89 416
new 0 89 416
assign 1 90 419
typenameGet 0 90 419
assign 1 90 420
BRACESGet 0 90 420
assign 1 90 421
equals 1 90 421
assign 1 91 423
new 0 91 423
assign 1 94 427
assign 1 95 428
assign 1 98 431
typenameGet 0 98 431
assign 1 98 432
BRACESGet 0 98 432
assign 1 98 433
notEquals 1 98 433
assign 1 100 435
assign 1 101 436
containerGet 0 101 436
assign 1 106 442
new 0 106 442
assign 1 106 443
tmpVar 2 106 443
assign 1 107 444
new 1 107 444
copyLoc 1 108 445
assign 1 109 446
VARGet 0 109 446
typenameSet 1 109 447
heldSet 1 110 448
replaceWith 1 111 449
addVariable 0 112 450
assign 1 113 451
new 1 113 451
copyLoc 1 114 452
assign 1 115 453
CALLGet 0 115 453
typenameSet 1 115 454
assign 1 116 455
new 0 116 455
assign 1 117 456
new 0 117 456
nameSet 1 117 457
heldSet 1 118 458
assign 1 119 459
new 1 119 459
copyLoc 1 120 460
assign 1 121 461
VARGet 0 121 461
typenameSet 1 121 462
heldSet 1 122 463
addValue 1 123 464
addValue 1 124 465
beforeInsert 1 125 466
assign 1 126 467
nextDescendGet 0 126 467
return 1 126 468
assign 1 129 471
nextDescendGet 0 129 471
return 1 129 472
return 1 0 475
assign 1 0 478
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1648781300: return bem_constGet_0();
case -1650622151: return bem_iteratorGet_0();
case -17851578: return bem_new_0();
case -1406793129: return bem_print_0();
case -1100113880: return bem_inMtdGet_0();
case -1544307906: return bem_tagGet_0();
case -1869109136: return bem_classNameGet_0();
case -1744447963: return bem_toString_0();
case -1742872288: return bem_ntypesGet_0();
case -1063105140: return bem_create_0();
case -964376567: return bem_copy_0();
case -1862849517: return bem_hashGet_0();
case -311875845: return bem_buildGet_0();
case 1242623472: return bem_transGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1764708193: return bem_copyTo_1(bevd_0);
case -1472504739: return bem_undef_1(bevd_0);
case -634103428: return bem_constSet_1(bevd_0);
case -1167175972: return bem_ntypesSet_1(bevd_0);
case -54815286: return bem_def_1(bevd_0);
case -708773480: return bem_transSet_1(bevd_0);
case -1832844782: return bem_sameObject_1(bevd_0);
case -1113331744: return bem_end_1(bevd_0);
case 371048183: return bem_notEquals_1(bevd_0);
case 1875317450: return bem_inMtdSet_1(bevd_0);
case -1492086420: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1024867767: return bem_buildSet_1(bevd_0);
case 865270744: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 689573322: return bem_equals_1(bevd_0);
case -1063668189: return bem_begin_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1178647801: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1650827610: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523546720: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1121134228: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1135788730: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass11_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass11_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass11();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst = (BEC_3_5_5_6_BuildVisitPass11) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_type;
}
}
