package be;
/* IO:File: source/build/Pass12.be */
public class BEC_3_5_5_9_BuildVisitChkIfEmit extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitChkIfEmit() { }
private static byte[] becc_BEC_3_5_5_9_BuildVisitChkIfEmit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x43,0x68,0x6B,0x49,0x66,0x45,0x6D,0x69,0x74};
private static byte[] becc_BEC_3_5_5_9_BuildVisitChkIfEmit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_9_BuildVisitChkIfEmit_bels_0 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
public static BEC_3_5_5_9_BuildVisitChkIfEmit bece_BEC_3_5_5_9_BuildVisitChkIfEmit_bevs_inst;

public static BET_3_5_5_9_BuildVisitChkIfEmit bece_BEC_3_5_5_9_BuildVisitChkIfEmit_bevs_type;

public BEC_2_6_6_SystemObject bem_acceptIfEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevl_include = null;
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevl_negate = null;
BEC_2_4_6_TextString bevl_flag = null;
BEC_2_5_4_LogicBool bevl_foundFlag = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_9_10_ContainerLinkedList bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_12_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_19_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
BEC_2_5_4_BuildNode bevt_31_ta_ph = null;
bevl_include = be.BECS_Runtime.boolTrue;
bevt_3_ta_ph = bevp_build.bem_emitLangsGet_0();
bevl_emitLang = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_firstGet_0();
bevt_6_ta_ph = beva_node.bem_heldGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(1030060421);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_9_BuildVisitChkIfEmit_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(-526829482, bevt_7_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 22*/ {
bevl_negate = be.BECS_Runtime.boolTrue;
} /* Line: 23*/
 else /* Line: 24*/ {
bevl_negate = be.BECS_Runtime.boolFalse;
} /* Line: 25*/
if (bevl_negate.bevi_bool)/* Line: 27*/ {
bevt_10_ta_ph = beva_node.bem_heldGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1473137518);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_1(-420654954, bevl_emitLang);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 28*/ {
bevl_include = be.BECS_Runtime.boolFalse;
} /* Line: 29*/
bevt_12_ta_ph = bevp_build.bem_emitFlagsGet_0();
if (bevt_12_ta_ph == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_13_ta_ph = bevp_build.bem_emitFlagsGet_0();
bevt_0_ta_loop = bevt_13_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 32*/ {
bevt_14_ta_ph = bevt_0_ta_loop.bemd_0(-1739111147);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 32*/ {
bevl_flag = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-1514376542);
bevt_17_ta_ph = beva_node.bem_heldGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bemd_0(-1473137518);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-420654954, bevl_flag);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 33*/ {
bevl_include = be.BECS_Runtime.boolFalse;
} /* Line: 34*/
} /* Line: 33*/
 else /* Line: 32*/ {
break;
} /* Line: 32*/
} /* Line: 32*/
} /* Line: 32*/
} /* Line: 31*/
 else /* Line: 38*/ {
bevl_foundFlag = be.BECS_Runtime.boolFalse;
bevt_19_ta_ph = bevp_build.bem_emitFlagsGet_0();
if (bevt_19_ta_ph == null) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 40*/ {
bevt_20_ta_ph = bevp_build.bem_emitFlagsGet_0();
bevt_1_ta_loop = bevt_20_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 41*/ {
bevt_21_ta_ph = bevt_1_ta_loop.bemd_0(-1739111147);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 41*/ {
bevl_flag = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(-1514376542);
bevt_24_ta_ph = beva_node.bem_heldGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_0(-1473137518);
bevt_22_ta_ph = bevt_23_ta_ph.bemd_1(-420654954, bevl_flag);
if (((BEC_2_5_4_LogicBool) bevt_22_ta_ph).bevi_bool)/* Line: 42*/ {
bevl_foundFlag = be.BECS_Runtime.boolTrue;
} /* Line: 43*/
} /* Line: 42*/
 else /* Line: 41*/ {
break;
} /* Line: 41*/
} /* Line: 41*/
} /* Line: 41*/
if (bevl_foundFlag.bevi_bool) {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_29_ta_ph = beva_node.bem_heldGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-1473137518);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_1(-420654954, bevl_emitLang);
bevt_26_ta_ph = bevt_27_ta_ph.bemd_0(1877465750);
if (((BEC_2_5_4_LogicBool) bevt_26_ta_ph).bevi_bool)/* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 47*/
 else /* Line: 47*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 47*/ {
bevl_include = be.BECS_Runtime.boolFalse;
} /* Line: 48*/
} /* Line: 47*/
if (bevl_include.bevi_bool)/* Line: 51*/ {
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /* Line: 52*/
bevt_31_ta_ph = beva_node.bem_nextPeerGet_0();
return bevt_31_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 21, 21, 22, 22, 22, 22, 23, 25, 28, 28, 28, 29, 31, 31, 31, 32, 32, 0, 32, 32, 33, 33, 33, 34, 39, 40, 40, 40, 41, 41, 0, 41, 41, 42, 42, 42, 43, 47, 47, 47, 47, 47, 47, 0, 0, 0, 48, 52, 52, 54, 54};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {50, 51, 52, 53, 54, 55, 56, 58, 61, 64, 65, 66, 68, 70, 71, 76, 77, 78, 78, 81, 83, 84, 85, 86, 88, 98, 99, 100, 105, 106, 107, 107, 110, 112, 113, 114, 115, 117, 125, 130, 131, 132, 133, 134, 136, 139, 143, 146, 150, 151, 153, 154};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 50
new 0 20 50
assign 1 21 51
emitLangsGet 0 21 51
assign 1 21 52
firstGet 0 21 52
assign 1 22 53
heldGet 0 22 53
assign 1 22 54
valueGet 0 22 54
assign 1 22 55
new 0 22 55
assign 1 22 56
equals 1 22 56
assign 1 23 58
new 0 23 58
assign 1 25 61
new 0 25 61
assign 1 28 64
heldGet 0 28 64
assign 1 28 65
langsGet 0 28 65
assign 1 28 66
has 1 28 66
assign 1 29 68
new 0 29 68
assign 1 31 70
emitFlagsGet 0 31 70
assign 1 31 71
def 1 31 76
assign 1 32 77
emitFlagsGet 0 32 77
assign 1 32 78
iteratorGet 0 0 78
assign 1 32 81
hasNextGet 0 32 81
assign 1 32 83
nextGet 0 32 83
assign 1 33 84
heldGet 0 33 84
assign 1 33 85
langsGet 0 33 85
assign 1 33 86
has 1 33 86
assign 1 34 88
new 0 34 88
assign 1 39 98
new 0 39 98
assign 1 40 99
emitFlagsGet 0 40 99
assign 1 40 100
def 1 40 105
assign 1 41 106
emitFlagsGet 0 41 106
assign 1 41 107
iteratorGet 0 0 107
assign 1 41 110
hasNextGet 0 41 110
assign 1 41 112
nextGet 0 41 112
assign 1 42 113
heldGet 0 42 113
assign 1 42 114
langsGet 0 42 114
assign 1 42 115
has 1 42 115
assign 1 43 117
new 0 43 117
assign 1 47 125
not 0 47 130
assign 1 47 131
heldGet 0 47 131
assign 1 47 132
langsGet 0 47 132
assign 1 47 133
has 1 47 133
assign 1 47 134
not 0 47 134
assign 1 0 136
assign 1 0 139
assign 1 0 143
assign 1 48 146
new 0 48 146
assign 1 52 150
nextDescendGet 0 52 150
return 1 52 151
assign 1 54 153
nextPeerGet 0 54 153
return 1 54 154
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1614030728: return bem_buildGet_0();
case 1712538602: return bem_toString_0();
case -1301883703: return bem_hashGet_0();
case -1008787576: return bem_create_0();
case 1408609733: return bem_iteratorGet_0();
case -946881766: return bem_constGet_0();
case 627496592: return bem_transGet_0();
case -978033728: return bem_print_0();
case 1806064504: return bem_new_0();
case -1275315701: return bem_copy_0();
case 983761449: return bem_ntypesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -148010615: return bem_undef_1(bevd_0);
case 2105889386: return bem_notEquals_1(bevd_0);
case -1328433534: return bem_ntypesSet_1(bevd_0);
case -1217552554: return bem_print_1(bevd_0);
case -1162939778: return bem_def_1(bevd_0);
case -891149307: return bem_transSet_1(bevd_0);
case -189481749: return bem_begin_1(bevd_0);
case -1234820220: return bem_copyTo_1(bevd_0);
case -1088347164: return bem_end_1(bevd_0);
case 938177468: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -526829482: return bem_equals_1(bevd_0);
case -64628945: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -2034118591: return bem_constSet_1(bevd_0);
case 1422387460: return bem_buildSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -960117370: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 596327003: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -554972801: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 415995996: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_9_BuildVisitChkIfEmit_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_9_BuildVisitChkIfEmit_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_9_BuildVisitChkIfEmit();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_9_BuildVisitChkIfEmit.bece_BEC_3_5_5_9_BuildVisitChkIfEmit_bevs_inst = (BEC_3_5_5_9_BuildVisitChkIfEmit) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_9_BuildVisitChkIfEmit.bece_BEC_3_5_5_9_BuildVisitChkIfEmit_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_9_BuildVisitChkIfEmit.bece_BEC_3_5_5_9_BuildVisitChkIfEmit_bevs_type;
}
}
