package be;
/* IO:File: source/base/List.be */
public final class BEC_2_9_4_ContainerList extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
public static BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_9_4_ContainerList bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(16));
bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_9_SystemException bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_leni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 223*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 223*/ {
if (beva_capi == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 223*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 223*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 223*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 223*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_ta_ph);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 224*/
if (bevp_length == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 226*/ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 229*/ {
return this;
} /* Line: 230*/
} /* Line: 229*/

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_multiplier = (new BEC_2_4_3_MathInt(2));
bevp_capacity = beva_capi.bem_copy_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sizeSet_1(BEC_2_4_3_MathInt beva_val) throws Throwable {
bem_lengthSet_1(beva_val);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 270*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 271*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_length.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevp_length.bem_subtract_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_9_SystemException bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_ta_ph);
throw new be.BECS_ThrowBack(bevt_2_ta_ph);
} /* Line: 294*/
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_posi.bem_add_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
} /* Line: 297*/

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 313*/ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 313*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 313*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 313*/
 else /* Line: 313*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 313*/ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 319*/
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_fl = bevp_length.bem_subtract_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_j = beva_pos.bem_add_1(bevt_2_ta_ph);
bevl_i = beva_pos.bem_copy_0();
while (true)
/* Line: 332*/ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_4_ta_ph = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_ta_ph);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 332*/
 else /* Line: 332*/ {
break;
} /* Line: 332*/
} /* Line: 332*/
bem_put_2(bevl_fl, null);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = bevp_length.bem_subtract_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 338*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 348*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 348*/ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 348*/
 else /* Line: 348*/ {
break;
} /* Line: 348*/
} /* Line: 348*/
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_copy_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_n = bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 356*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_1_ta_ph = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_ta_ph);
bevl_i.bevi_int++;
} /* Line: 356*/
 else /* Line: 356*/ {
break;
} /* Line: 356*/
} /* Line: 356*/
return (BEC_2_9_4_ContainerList) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_create_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) throws Throwable {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = beva_xi.bem_lengthGet_0();
bevt_3_ta_ph = bevp_length.bem_add_1(bevt_4_ta_ph);
bevl_yi = (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_loop = bem_iteratorGet_0();
while (true)
/* Line: 368*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-86063738);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 368*/ {
bevl_c = bevt_0_ta_loop.bemd_0(-953066157);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 369*/
 else /* Line: 368*/ {
break;
} /* Line: 368*/
} /* Line: 368*/
bevt_1_ta_loop = beva_xi.bem_iteratorGet_0();
while (true)
/* Line: 371*/ {
bevt_6_ta_ph = bevt_1_ta_loop.bemd_0(-86063738);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 371*/ {
bevl_c = bevt_1_ta_loop.bemd_0(-953066157);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 372*/
 else /* Line: 371*/ {
break;
} /* Line: 371*/
} /* Line: 371*/
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_ta_ph, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_start.bem_copy_0();
while (true)
/* Line: 386*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 386*/ {
bevl_c = bevl_i.bem_copy_0();
bevl_j = bevl_i.bem_copy_0();
while (true)
/* Line: 388*/ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 388*/ {
bevt_3_ta_ph = bem_get_1(bevl_j);
bevt_4_ta_ph = bem_get_1(bevl_c);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(818495638, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 389*/ {
bevl_c = bevl_j.bem_copy_0();
} /* Line: 390*/
bevl_j.bevi_int++;
} /* Line: 388*/
 else /* Line: 388*/ {
break;
} /* Line: 388*/
} /* Line: 388*/
bevl_hold = bem_get_1(bevl_i);
bevt_5_ta_ph = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_ta_ph);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 386*/
 else /* Line: 386*/ {
break;
} /* Line: 386*/
} /* Line: 386*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
/* Line: 405*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 405*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 406*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 406*/
 else /* Line: 406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 406*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_ta_ph = bevl_so.bemd_1(818495638, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 409*/ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 411*/
 else /* Line: 412*/ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 414*/
} /* Line: 409*/
 else /* Line: 406*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 416*/ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 419*/
 else /* Line: 406*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 420*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 423*/
} /* Line: 406*/
} /* Line: 406*/
bevl_i.bevi_int++;
} /* Line: 425*/
 else /* Line: 405*/ {
break;
} /* Line: 405*/
} /* Line: 405*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_mergeSort_2(bevt_1_ta_ph, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_mlen.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 435*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_2_ta_ph = bem_create_1(bevt_3_ta_ph);
return (BEC_2_9_4_ContainerList) bevt_2_ta_ph;
} /* Line: 436*/
 else /* Line: 435*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_mlen.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 437*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_ta_ph, bevt_8_ta_ph);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 440*/
 else /* Line: 441*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_ta_ph);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 449*/
} /* Line: 435*/
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 455*/ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_list = java.util.Arrays.copyOf(this.bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 477*/
while (true)
/* Line: 480*/ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 480*/ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 491*/
 else /* Line: 480*/ {
break;
} /* Line: 480*/
} /* Line: 480*/
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 497*/ {
while (true)
/* Line: 498*/ {
bevt_1_ta_ph = beva_val.bemd_0(-86063738);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 498*/ {
bevt_2_ta_ph = beva_val.bemd_0(-953066157);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 499*/
 else /* Line: 498*/ {
break;
} /* Line: 498*/
} /* Line: 498*/
} /* Line: 498*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 505*/ {
bevt_1_ta_ph = beva_val.bemd_0(1952943856);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 506*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 511*/ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 522*/
 else /* Line: 523*/ {
bevt_1_ta_ph = bevp_length.bem_copy_0();
bem_put_2(bevt_1_ta_ph, beva_val);
} /* Line: 525*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_val == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 530*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_val, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 530*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 530*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 530*/
 else /* Line: 530*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 530*/ {
bem_addAll_1(beva_val);
} /* Line: 531*/
 else /* Line: 532*/ {
bem_addValueWhole_1(beva_val);
} /* Line: 533*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 539*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 539*/ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 541*/ {
bevt_3_ta_ph = beva_value.bemd_1(105007733, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 541*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 541*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 541*/
 else /* Line: 541*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 541*/ {
return bevl_i;
} /* Line: 542*/
bevl_i.bevi_int++;
} /* Line: 539*/
 else /* Line: 539*/ {
break;
} /* Line: 539*/
} /* Line: 539*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_find_1(beva_value);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 549*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 550*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_sortedFind_2(beva_value, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 569*/ {
bevt_3_ta_ph = bevl_high.bem_subtract_1(bevl_low);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = bevt_3_ta_ph.bem_divide_1(bevt_4_ta_ph);
bevl_mid = bevt_2_ta_ph.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_ta_ph = beva_value.bemd_1(105007733, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 572*/ {
return bevl_mid;
} /* Line: 573*/
 else /* Line: 572*/ {
bevt_6_ta_ph = beva_value.bemd_1(-1498568620, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 574*/ {
bevl_low = bevl_mid;
} /* Line: 576*/
 else /* Line: 572*/ {
bevt_7_ta_ph = beva_value.bemd_1(818495638, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 577*/ {
bevl_high = bevl_mid;
} /* Line: 579*/
} /* Line: 572*/
} /* Line: 572*/
if (bevl_lastMid == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 582*/ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 582*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 582*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 582*/
 else /* Line: 582*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 582*/ {
if (beva_returnNoMatch.bevi_bool)/* Line: 583*/ {
bevt_11_ta_ph = bem_get_1(bevl_low);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(818495638, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 583*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 583*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 583*/
 else /* Line: 583*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 583*/ {
return bevl_low;
} /* Line: 584*/
return null;
} /* Line: 586*/
bevl_lastMid = bevl_mid;
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_12_ta_ph.bevi_bool)/* Line: 589*/ {
return null;
} /* Line: 590*/
} /* Line: 589*/
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {215, 215, 215, 219, 223, 223, 0, 223, 223, 0, 0, 224, 224, 224, 226, 226, 229, 229, 230, 253, 254, 257, 262, 266, 270, 270, 270, 271, 271, 273, 273, 277, 277, 281, 281, 285, 285, 285, 289, 289, 289, 289, 293, 293, 293, 294, 294, 294, 296, 296, 297, 297, 297, 313, 313, 313, 313, 313, 0, 0, 0, 325, 329, 329, 330, 330, 331, 331, 332, 332, 332, 333, 333, 334, 332, 336, 337, 337, 337, 338, 338, 340, 340, 344, 344, 348, 348, 348, 349, 348, 351, 355, 356, 356, 356, 357, 357, 356, 359, 362, 362, 364, 364, 367, 367, 367, 367, 368, 0, 368, 368, 369, 371, 0, 371, 371, 372, 374, 378, 378, 382, 382, 386, 386, 386, 387, 388, 388, 388, 389, 389, 389, 390, 388, 393, 394, 394, 395, 386, 400, 401, 402, 403, 404, 405, 405, 406, 406, 406, 406, 0, 0, 0, 407, 408, 409, 410, 411, 413, 414, 416, 416, 417, 418, 419, 420, 420, 421, 422, 423, 425, 430, 430, 430, 434, 435, 435, 435, 436, 436, 436, 437, 437, 437, 438, 438, 439, 439, 439, 440, 442, 442, 443, 444, 445, 446, 447, 448, 449, 455, 455, 456, 477, 480, 480, 491, 493, 497, 497, 498, 499, 499, 505, 505, 506, 506, 511, 511, 522, 525, 525, 530, 530, 530, 530, 0, 0, 0, 531, 533, 539, 539, 539, 540, 541, 541, 541, 0, 0, 0, 542, 539, 545, 549, 549, 549, 550, 550, 552, 552, 558, 558, 558, 565, 566, 570, 570, 570, 570, 571, 572, 573, 574, 576, 577, 579, 582, 582, 582, 582, 0, 0, 0, 583, 583, 0, 0, 0, 584, 586, 588, 589, 590, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {39, 40, 41, 45, 56, 61, 62, 65, 70, 71, 74, 78, 79, 80, 82, 87, 88, 93, 94, 99, 100, 101, 105, 108, 116, 117, 122, 123, 124, 126, 127, 131, 132, 136, 137, 143, 144, 145, 151, 152, 153, 154, 164, 165, 170, 171, 172, 173, 175, 180, 181, 182, 183, 195, 196, 201, 202, 207, 208, 211, 215, 221, 236, 241, 242, 243, 244, 245, 246, 249, 254, 255, 256, 257, 258, 264, 265, 266, 267, 268, 269, 271, 272, 276, 277, 282, 285, 290, 291, 292, 298, 306, 307, 310, 315, 316, 317, 318, 324, 328, 329, 333, 334, 346, 347, 348, 349, 350, 350, 353, 355, 356, 362, 362, 365, 367, 368, 374, 378, 379, 383, 384, 398, 401, 406, 407, 408, 411, 416, 417, 418, 419, 421, 423, 429, 430, 431, 432, 433, 456, 457, 458, 459, 460, 463, 468, 469, 474, 475, 480, 481, 484, 488, 491, 492, 493, 495, 496, 499, 500, 504, 509, 510, 511, 512, 515, 520, 521, 522, 523, 527, 538, 539, 540, 560, 561, 562, 567, 568, 569, 570, 573, 574, 579, 580, 581, 582, 583, 584, 585, 588, 589, 590, 591, 592, 593, 594, 595, 596, 604, 609, 610, 613, 617, 622, 625, 631, 638, 643, 646, 648, 649, 661, 666, 667, 668, 675, 680, 683, 686, 687, 696, 701, 702, 703, 705, 708, 712, 715, 718, 729, 732, 737, 738, 739, 744, 745, 747, 750, 754, 757, 759, 765, 772, 773, 778, 779, 780, 782, 783, 788, 789, 790, 811, 812, 815, 816, 817, 818, 819, 820, 822, 825, 827, 830, 832, 836, 841, 842, 847, 848, 851, 855, 859, 860, 862, 865, 869, 872, 874, 876, 877, 879, 884, 887, 890};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 215 39
new 0 215 39
assign 1 215 40
new 0 215 40
new 2 215 41
new 2 219 45
assign 1 223 56
undef 1 223 61
assign 1 0 62
assign 1 223 65
undef 1 223 70
assign 1 0 71
assign 1 0 74
assign 1 224 78
new 0 224 78
assign 1 224 79
new 1 224 79
throw 1 224 80
assign 1 226 82
def 1 226 87
assign 1 229 88
equals 1 229 93
return 1 230 94
assign 1 253 99
copy 0 253 99
assign 1 254 100
new 0 254 100
assign 1 257 101
copy 0 257 101
return 1 262 105
lengthSet 1 266 108
assign 1 270 116
new 0 270 116
assign 1 270 117
equals 1 270 122
assign 1 271 123
new 0 271 123
return 1 271 124
assign 1 273 126
new 0 273 126
return 1 273 127
assign 1 277 131
toString 0 277 131
return 1 277 132
assign 1 281 136
new 1 281 136
new 1 281 137
assign 1 285 143
new 0 285 143
assign 1 285 144
get 1 285 144
return 1 285 145
assign 1 289 151
new 0 289 151
assign 1 289 152
subtract 1 289 152
assign 1 289 153
get 1 289 153
return 1 289 154
assign 1 293 164
new 0 293 164
assign 1 293 165
lesser 1 293 170
assign 1 294 171
new 0 294 171
assign 1 294 172
new 1 294 172
throw 1 294 173
assign 1 296 175
greaterEquals 1 296 180
assign 1 297 181
new 0 297 181
assign 1 297 182
add 1 297 182
lengthSet 1 297 183
assign 1 313 195
new 0 313 195
assign 1 313 196
greaterEquals 1 313 201
assign 1 313 202
lesser 1 313 207
assign 1 0 208
assign 1 0 211
assign 1 0 215
return 1 325 221
assign 1 329 236
lesser 1 329 241
assign 1 330 242
new 0 330 242
assign 1 330 243
subtract 1 330 243
assign 1 331 244
new 0 331 244
assign 1 331 245
add 1 331 245
assign 1 332 246
copy 0 332 246
assign 1 332 249
lesser 1 332 254
assign 1 333 255
get 1 333 255
put 2 333 256
incrementValue 0 334 257
incrementValue 0 332 258
put 2 336 264
assign 1 337 265
new 0 337 265
assign 1 337 266
subtract 1 337 266
lengthSet 1 337 267
assign 1 338 268
new 0 338 268
return 1 338 269
assign 1 340 271
new 0 340 271
return 1 340 272
assign 1 344 276
new 1 344 276
return 1 344 277
assign 1 348 282
new 0 348 282
assign 1 348 285
lesser 1 348 290
put 2 349 291
incrementValue 0 348 292
assign 1 351 298
new 0 351 298
assign 1 355 306
create 0 355 306
assign 1 356 307
new 0 356 307
assign 1 356 310
lesser 1 356 315
assign 1 357 316
get 1 357 316
put 2 357 317
incrementValue 0 356 318
return 1 359 324
assign 1 362 328
new 1 362 328
return 1 362 329
assign 1 364 333
new 1 364 333
return 1 364 334
assign 1 367 346
new 0 367 346
assign 1 367 347
lengthGet 0 367 347
assign 1 367 348
add 1 367 348
assign 1 367 349
new 2 367 349
assign 1 368 350
iteratorGet 0 0 350
assign 1 368 353
hasNextGet 0 368 353
assign 1 368 355
nextGet 0 368 355
addValueWhole 1 369 356
assign 1 371 362
iteratorGet 0 0 362
assign 1 371 365
hasNextGet 0 371 365
assign 1 371 367
nextGet 0 371 367
addValueWhole 1 372 368
return 1 374 374
assign 1 378 378
mergeSort 0 378 378
return 1 378 379
assign 1 382 383
new 0 382 383
sortValue 2 382 384
assign 1 386 398
copy 0 386 398
assign 1 386 401
lesser 1 386 406
assign 1 387 407
copy 0 387 407
assign 1 388 408
copy 0 388 408
assign 1 388 411
lesser 1 388 416
assign 1 389 417
get 1 389 417
assign 1 389 418
get 1 389 418
assign 1 389 419
lesser 1 389 419
assign 1 390 421
copy 0 390 421
incrementValue 0 388 423
assign 1 393 429
get 1 393 429
assign 1 394 430
get 1 394 430
put 2 394 431
put 2 395 432
incrementValue 0 386 433
assign 1 400 456
new 0 400 456
assign 1 401 457
new 0 401 457
assign 1 402 458
new 0 402 458
assign 1 403 459
lengthGet 0 403 459
assign 1 404 460
lengthGet 0 404 460
assign 1 405 463
lesser 1 405 468
assign 1 406 469
lesser 1 406 474
assign 1 406 475
lesser 1 406 480
assign 1 0 481
assign 1 0 484
assign 1 0 488
assign 1 407 491
get 1 407 491
assign 1 408 492
get 1 408 492
assign 1 409 493
lesser 1 409 493
incrementValue 0 410 495
put 2 411 496
incrementValue 0 413 499
put 2 414 500
assign 1 416 504
lesser 1 416 509
assign 1 417 510
get 1 417 510
incrementValue 0 418 511
put 2 419 512
assign 1 420 515
lesser 1 420 520
assign 1 421 521
get 1 421 521
incrementValue 0 422 522
put 2 423 523
incrementValue 0 425 527
assign 1 430 538
new 0 430 538
assign 1 430 539
mergeSort 2 430 539
return 1 430 540
assign 1 434 560
subtract 1 434 560
assign 1 435 561
new 0 435 561
assign 1 435 562
equals 1 435 567
assign 1 436 568
new 0 436 568
assign 1 436 569
create 1 436 569
return 1 436 570
assign 1 437 573
new 0 437 573
assign 1 437 574
equals 1 437 579
assign 1 438 580
new 0 438 580
assign 1 438 581
create 1 438 581
assign 1 439 582
new 0 439 582
assign 1 439 583
get 1 439 583
put 2 439 584
return 1 440 585
assign 1 442 588
new 0 442 588
assign 1 442 589
divide 1 442 589
assign 1 443 590
subtract 1 443 590
assign 1 444 591
add 1 444 591
assign 1 445 592
mergeSort 2 445 592
assign 1 446 593
mergeSort 2 446 593
assign 1 447 594
create 1 447 594
mergeIn 2 448 595
return 1 449 596
assign 1 455 604
greater 1 455 609
assign 1 456 610
multiply 1 456 610
assign 1 477 613
assign 1 480 617
lesser 1 480 622
incrementValue 0 491 625
setValue 1 493 631
assign 1 497 638
def 1 497 643
assign 1 498 646
hasNextGet 0 498 646
assign 1 499 648
nextGet 0 499 648
addValueWhole 1 499 649
assign 1 505 661
def 1 505 666
assign 1 506 667
iteratorGet 0 506 667
iterateAdd 1 506 668
assign 1 511 675
lesser 1 511 680
incrementValue 0 522 683
assign 1 525 686
copy 0 525 686
put 2 525 687
assign 1 530 696
def 1 530 701
assign 1 530 702
new 0 530 702
assign 1 530 703
sameType 2 530 703
assign 1 0 705
assign 1 0 708
assign 1 0 712
addAll 1 531 715
addValueWhole 1 533 718
assign 1 539 729
new 0 539 729
assign 1 539 732
lesser 1 539 737
assign 1 540 738
get 1 540 738
assign 1 541 739
def 1 541 744
assign 1 541 745
equals 1 541 745
assign 1 0 747
assign 1 0 750
assign 1 0 754
return 1 542 757
incrementValue 0 539 759
return 1 545 765
assign 1 549 772
find 1 549 772
assign 1 549 773
def 1 549 778
assign 1 550 779
new 0 550 779
return 1 550 780
assign 1 552 782
new 0 552 782
return 1 552 783
assign 1 558 788
new 0 558 788
assign 1 558 789
sortedFind 2 558 789
return 1 558 790
assign 1 565 811
assign 1 566 812
new 0 566 812
assign 1 570 815
subtract 1 570 815
assign 1 570 816
new 0 570 816
assign 1 570 817
divide 1 570 817
assign 1 570 818
add 1 570 818
assign 1 571 819
get 1 571 819
assign 1 572 820
equals 1 572 820
return 1 573 822
assign 1 574 825
greater 1 574 825
assign 1 576 827
assign 1 577 830
lesser 1 577 830
assign 1 579 832
assign 1 582 836
def 1 582 841
assign 1 582 842
equals 1 582 847
assign 1 0 848
assign 1 0 851
assign 1 0 855
assign 1 583 859
get 1 583 859
assign 1 583 860
lesser 1 583 860
assign 1 0 862
assign 1 0 865
assign 1 0 869
return 1 584 872
return 1 586 874
assign 1 588 876
assign 1 589 877
new 0 589 877
return 1 590 879
return 1 0 884
return 1 0 887
assign 1 0 890
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 916579823: return bem_lengthGet_0();
case -630224306: return bem_clear_0();
case -1065793524: return bem_lastGet_0();
case -11439861: return bem_toString_0();
case 2095545885: return bem_serializeToString_0();
case 1027167395: return bem_print_0();
case -981204172: return bem_copy_0();
case 1245091644: return bem_sort_0();
case 517610545: return bem_create_0();
case -1525278583: return bem_firstGet_0();
case 967910565: return bem_sortValue_0();
case -2124667954: return bem_isEmptyGet_0();
case 1952943856: return bem_iteratorGet_0();
case -1407306250: return bem_sizeGet_0();
case -1501634450: return bem_new_0();
case 1962668450: return bem_hashGet_0();
case 409243019: return bem_mergeSort_0();
case 601144328: return bem_multiplierGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 978237725: return bem_def_1(bevd_0);
case 1188770114: return bem_addValueWhole_1(bevd_0);
case -1828493463: return bem_has_1(bevd_0);
case -460873787: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1705093759: return bem_find_1(bevd_0);
case 234623522: return bem_notEquals_1(bevd_0);
case 432095637: return bem_addAll_1(bevd_0);
case -967501980: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case -1971588654: return bem_sizeSet_1((BEC_2_4_3_MathInt) bevd_0);
case -2089467419: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1943248372: return bem_iterateAdd_1(bevd_0);
case 1164088991: return bem_addValue_1(bevd_0);
case -2047953674: return bem_undef_1(bevd_0);
case -1038363611: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1327676490: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 427083876: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1509025565: return bem_sortedFind_1(bevd_0);
case 857299362: return bem_copyTo_1(bevd_0);
case 1424862659: return bem_multiplierSet_1(bevd_0);
case 105007733: return bem_equals_1(bevd_0);
case -2034360142: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2033608690: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1254489739: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -976124908: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 664895809: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -996234: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1199110579: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -917399680: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1815776256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1348816433: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -450201493: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
