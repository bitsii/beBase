package be;
/* IO:File: source/base/List.be */
public final class BEC_2_9_4_ContainerList extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
public static BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_4_ContainerList bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(16));
bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_9_SystemException bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_leni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
if (beva_capi == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 221*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 221*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_ta_ph);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 222*/
if (bevp_length == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 224*/ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 227*/ {
return this;
} /* Line: 228*/
} /* Line: 227*/

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = (new BEC_2_4_3_MathInt(2));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sizeSet_1(BEC_2_4_3_MathInt beva_val) throws Throwable {
bem_lengthSet_1(beva_val);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 268*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_length.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevp_length.bem_subtract_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_9_SystemException bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_ta_ph);
throw new be.BECS_ThrowBack(bevt_2_ta_ph);
} /* Line: 301*/
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_posi.bem_add_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
} /* Line: 304*/

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 320*/ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 320*/
 else /* Line: 320*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 320*/ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 326*/
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_fl = bevp_length.bem_subtract_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_j = beva_pos.bem_add_1(bevt_2_ta_ph);
bevl_i = beva_pos.bem_copy_0();
while (true)
/* Line: 339*/ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 339*/ {
bevt_4_ta_ph = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_ta_ph);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 339*/
 else /* Line: 339*/ {
break;
} /* Line: 339*/
} /* Line: 339*/
bem_put_2(bevl_fl, null);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = bevp_length.bem_subtract_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 345*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 359*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 359*/ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 359*/
 else /* Line: 359*/ {
break;
} /* Line: 359*/
} /* Line: 359*/
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_copy_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_n = bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 367*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 367*/ {
bevt_1_ta_ph = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_ta_ph);
bevl_i.bevi_int++;
} /* Line: 367*/
 else /* Line: 367*/ {
break;
} /* Line: 367*/
} /* Line: 367*/
return (BEC_2_9_4_ContainerList) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_create_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) throws Throwable {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = beva_xi.bem_lengthGet_0();
bevt_3_ta_ph = bevp_length.bem_add_1(bevt_4_ta_ph);
bevl_yi = (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_loop = bem_iteratorGet_0();
while (true)
/* Line: 379*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(1681879581);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 379*/ {
bevl_c = bevt_0_ta_loop.bemd_0(1696433337);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 380*/
 else /* Line: 379*/ {
break;
} /* Line: 379*/
} /* Line: 379*/
bevt_1_ta_loop = beva_xi.bem_iteratorGet_0();
while (true)
/* Line: 382*/ {
bevt_6_ta_ph = bevt_1_ta_loop.bemd_0(1681879581);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 382*/ {
bevl_c = bevt_1_ta_loop.bemd_0(1696433337);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 383*/
 else /* Line: 382*/ {
break;
} /* Line: 382*/
} /* Line: 382*/
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_ta_ph, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_start.bem_copy_0();
while (true)
/* Line: 397*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 397*/ {
bevl_c = bevl_i.bem_copy_0();
bevl_j = bevl_i.bem_copy_0();
while (true)
/* Line: 399*/ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 399*/ {
bevt_3_ta_ph = bem_get_1(bevl_j);
bevt_4_ta_ph = bem_get_1(bevl_c);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(-1420890175, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 400*/ {
bevl_c = bevl_j.bem_copy_0();
} /* Line: 401*/
bevl_j.bevi_int++;
} /* Line: 399*/
 else /* Line: 399*/ {
break;
} /* Line: 399*/
} /* Line: 399*/
bevl_hold = bem_get_1(bevl_i);
bevt_5_ta_ph = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_ta_ph);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 397*/
 else /* Line: 397*/ {
break;
} /* Line: 397*/
} /* Line: 397*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
/* Line: 416*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 416*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 417*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 417*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 417*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 417*/
 else /* Line: 417*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 417*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_ta_ph = bevl_so.bemd_1(-1420890175, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 420*/ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 422*/
 else /* Line: 423*/ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 425*/
} /* Line: 420*/
 else /* Line: 417*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 427*/ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 430*/
 else /* Line: 417*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 431*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 434*/
} /* Line: 417*/
} /* Line: 417*/
bevl_i.bevi_int++;
} /* Line: 436*/
 else /* Line: 416*/ {
break;
} /* Line: 416*/
} /* Line: 416*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_mergeSort_2(bevt_1_ta_ph, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_mlen.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_2_ta_ph = bem_create_1(bevt_3_ta_ph);
return (BEC_2_9_4_ContainerList) bevt_2_ta_ph;
} /* Line: 447*/
 else /* Line: 446*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_mlen.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 448*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_ta_ph, bevt_8_ta_ph);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 451*/
 else /* Line: 452*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_ta_ph);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 460*/
} /* Line: 446*/
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 465*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 466*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 472*/ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_list = java.util.Arrays.copyOf(this.bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 494*/
while (true)
/* Line: 497*/ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 497*/ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 508*/
 else /* Line: 497*/ {
break;
} /* Line: 497*/
} /* Line: 497*/
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 514*/ {
while (true)
/* Line: 515*/ {
bevt_1_ta_ph = beva_val.bemd_0(1681879581);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 515*/ {
bevt_2_ta_ph = beva_val.bemd_0(1696433337);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 516*/
 else /* Line: 515*/ {
break;
} /* Line: 515*/
} /* Line: 515*/
} /* Line: 515*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 522*/ {
bevt_1_ta_ph = beva_val.bemd_0(2066839134);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 523*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 528*/ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 539*/
 else /* Line: 540*/ {
bevt_1_ta_ph = bevp_length.bem_copy_0();
bem_put_2(bevt_1_ta_ph, beva_val);
} /* Line: 542*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 547*/ {
bevt_2_ta_ph = beva_val.bemd_1(1648088469, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 547*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 547*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 547*/
 else /* Line: 547*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 547*/ {
bem_addAll_1(beva_val);
} /* Line: 548*/
 else /* Line: 549*/ {
bem_addValueWhole_1(beva_val);
} /* Line: 550*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 556*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 556*/ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 558*/ {
bevt_3_ta_ph = beva_value.bemd_1(1812729488, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 558*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 558*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 558*/
 else /* Line: 558*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 558*/ {
return bevl_i;
} /* Line: 559*/
bevl_i.bevi_int++;
} /* Line: 556*/
 else /* Line: 556*/ {
break;
} /* Line: 556*/
} /* Line: 556*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_find_1(beva_value);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 566*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 567*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_sortedFind_2(beva_value, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 586*/ {
bevt_3_ta_ph = bevl_high.bem_subtract_1(bevl_low);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = bevt_3_ta_ph.bem_divide_1(bevt_4_ta_ph);
bevl_mid = bevt_2_ta_ph.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_ta_ph = beva_value.bemd_1(1812729488, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 589*/ {
return bevl_mid;
} /* Line: 590*/
 else /* Line: 589*/ {
bevt_6_ta_ph = beva_value.bemd_1(1877436683, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 591*/ {
bevl_low = bevl_mid;
} /* Line: 593*/
 else /* Line: 589*/ {
bevt_7_ta_ph = beva_value.bemd_1(-1420890175, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 594*/ {
bevl_high = bevl_mid;
} /* Line: 596*/
} /* Line: 589*/
} /* Line: 589*/
if (bevl_lastMid == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 599*/ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 599*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 599*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 599*/
 else /* Line: 599*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 599*/ {
if (beva_returnNoMatch.bevi_bool)/* Line: 600*/ {
bevt_11_ta_ph = bem_get_1(bevl_low);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(-1420890175, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 600*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 600*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 600*/
 else /* Line: 600*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 600*/ {
return bevl_low;
} /* Line: 601*/
return null;
} /* Line: 603*/
bevl_lastMid = bevl_mid;
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_12_ta_ph.bevi_bool)/* Line: 606*/ {
return null;
} /* Line: 607*/
} /* Line: 606*/
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public final BEC_2_4_3_MathInt bem_lengthGetDirect_0() throws Throwable {
return bevp_length;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_lengthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_4_3_MathInt bem_capacityGetDirect_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public final BEC_2_4_3_MathInt bem_multiplierGetDirect_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_multiplierSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {213, 213, 213, 217, 221, 221, 0, 221, 221, 0, 0, 222, 222, 222, 224, 224, 227, 227, 228, 252, 253, 254, 259, 263, 267, 267, 267, 268, 268, 270, 270, 280, 280, 284, 284, 288, 288, 292, 292, 292, 296, 296, 296, 296, 300, 300, 300, 301, 301, 301, 303, 303, 304, 304, 304, 320, 320, 320, 320, 320, 0, 0, 0, 332, 336, 336, 337, 337, 338, 338, 339, 339, 339, 340, 340, 341, 339, 343, 344, 344, 344, 345, 345, 347, 347, 351, 351, 355, 355, 359, 359, 359, 360, 359, 362, 366, 367, 367, 367, 368, 368, 367, 370, 373, 373, 375, 375, 378, 378, 378, 378, 379, 0, 379, 379, 380, 382, 0, 382, 382, 383, 385, 389, 389, 393, 393, 397, 397, 397, 398, 399, 399, 399, 400, 400, 400, 401, 399, 404, 405, 405, 406, 397, 411, 412, 413, 414, 415, 416, 416, 417, 417, 417, 417, 0, 0, 0, 418, 419, 420, 421, 422, 424, 425, 427, 427, 428, 429, 430, 431, 431, 432, 433, 434, 436, 441, 441, 441, 445, 446, 446, 446, 447, 447, 447, 448, 448, 448, 449, 449, 450, 450, 450, 451, 453, 453, 454, 455, 456, 457, 458, 459, 460, 465, 466, 466, 466, 472, 472, 473, 494, 497, 497, 508, 510, 514, 514, 515, 516, 516, 522, 522, 523, 523, 528, 528, 539, 542, 542, 547, 547, 547, 0, 0, 0, 548, 550, 556, 556, 556, 557, 558, 558, 558, 0, 0, 0, 559, 556, 562, 566, 566, 566, 567, 567, 569, 569, 575, 575, 575, 582, 583, 587, 587, 587, 587, 588, 589, 590, 591, 593, 594, 596, 599, 599, 599, 599, 0, 0, 0, 600, 600, 0, 0, 0, 601, 603, 605, 606, 607, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 42, 46, 57, 62, 63, 66, 71, 72, 75, 79, 80, 81, 83, 88, 89, 94, 95, 100, 101, 102, 106, 109, 117, 118, 123, 124, 125, 127, 128, 138, 139, 143, 144, 149, 150, 155, 156, 157, 163, 164, 165, 166, 176, 177, 182, 183, 184, 185, 187, 192, 193, 194, 195, 207, 208, 213, 214, 219, 220, 223, 227, 233, 248, 253, 254, 255, 256, 257, 258, 261, 266, 267, 268, 269, 270, 276, 277, 278, 279, 280, 281, 283, 284, 288, 289, 293, 294, 299, 302, 307, 308, 309, 315, 323, 324, 327, 332, 333, 334, 335, 341, 345, 346, 350, 351, 363, 364, 365, 366, 367, 367, 370, 372, 373, 379, 379, 382, 384, 385, 391, 395, 396, 400, 401, 415, 418, 423, 424, 425, 428, 433, 434, 435, 436, 438, 440, 446, 447, 448, 449, 450, 473, 474, 475, 476, 477, 480, 485, 486, 491, 492, 497, 498, 501, 505, 508, 509, 510, 512, 513, 516, 517, 521, 526, 527, 528, 529, 532, 537, 538, 539, 540, 544, 555, 556, 557, 577, 578, 579, 584, 585, 586, 587, 590, 591, 596, 597, 598, 599, 600, 601, 602, 605, 606, 607, 608, 609, 610, 611, 612, 613, 621, 623, 624, 625, 633, 638, 639, 642, 646, 651, 654, 660, 667, 672, 675, 677, 678, 690, 695, 696, 697, 704, 709, 712, 715, 716, 724, 729, 730, 732, 735, 739, 742, 745, 756, 759, 764, 765, 766, 771, 772, 774, 777, 781, 784, 786, 792, 799, 800, 805, 806, 807, 809, 810, 815, 816, 817, 838, 839, 842, 843, 844, 845, 846, 847, 849, 852, 854, 857, 859, 863, 868, 869, 874, 875, 878, 882, 886, 887, 889, 892, 896, 899, 901, 903, 904, 906, 911, 914, 917, 921, 924, 927, 931, 934, 937, 941};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 213 40
new 0 213 40
assign 1 213 41
new 0 213 41
new 2 213 42
new 2 217 46
assign 1 221 57
undef 1 221 62
assign 1 0 63
assign 1 221 66
undef 1 221 71
assign 1 0 72
assign 1 0 75
assign 1 222 79
new 0 222 79
assign 1 222 80
new 1 222 80
throw 1 222 81
assign 1 224 83
def 1 224 88
assign 1 227 89
equals 1 227 94
return 1 228 95
assign 1 252 100
copy 0 252 100
assign 1 253 101
copy 0 253 101
assign 1 254 102
new 0 254 102
return 1 259 106
lengthSet 1 263 109
assign 1 267 117
new 0 267 117
assign 1 267 118
equals 1 267 123
assign 1 268 124
new 0 268 124
return 1 268 125
assign 1 270 127
new 0 270 127
return 1 270 128
assign 1 280 138
toString 0 280 138
return 1 280 139
assign 1 284 143
new 1 284 143
new 1 284 144
assign 1 288 149
iteratorGet 0 288 149
return 1 288 150
assign 1 292 155
new 0 292 155
assign 1 292 156
get 1 292 156
return 1 292 157
assign 1 296 163
new 0 296 163
assign 1 296 164
subtract 1 296 164
assign 1 296 165
get 1 296 165
return 1 296 166
assign 1 300 176
new 0 300 176
assign 1 300 177
lesser 1 300 182
assign 1 301 183
new 0 301 183
assign 1 301 184
new 1 301 184
throw 1 301 185
assign 1 303 187
greaterEquals 1 303 192
assign 1 304 193
new 0 304 193
assign 1 304 194
add 1 304 194
lengthSet 1 304 195
assign 1 320 207
new 0 320 207
assign 1 320 208
greaterEquals 1 320 213
assign 1 320 214
lesser 1 320 219
assign 1 0 220
assign 1 0 223
assign 1 0 227
return 1 332 233
assign 1 336 248
lesser 1 336 253
assign 1 337 254
new 0 337 254
assign 1 337 255
subtract 1 337 255
assign 1 338 256
new 0 338 256
assign 1 338 257
add 1 338 257
assign 1 339 258
copy 0 339 258
assign 1 339 261
lesser 1 339 266
assign 1 340 267
get 1 340 267
put 2 340 268
incrementValue 0 341 269
incrementValue 0 339 270
put 2 343 276
assign 1 344 277
new 0 344 277
assign 1 344 278
subtract 1 344 278
lengthSet 1 344 279
assign 1 345 280
new 0 345 280
return 1 345 281
assign 1 347 283
new 0 347 283
return 1 347 284
assign 1 351 288
new 1 351 288
return 1 351 289
assign 1 355 293
new 1 355 293
return 1 355 294
assign 1 359 299
new 0 359 299
assign 1 359 302
lesser 1 359 307
put 2 360 308
incrementValue 0 359 309
assign 1 362 315
new 0 362 315
assign 1 366 323
create 0 366 323
assign 1 367 324
new 0 367 324
assign 1 367 327
lesser 1 367 332
assign 1 368 333
get 1 368 333
put 2 368 334
incrementValue 0 367 335
return 1 370 341
assign 1 373 345
new 1 373 345
return 1 373 346
assign 1 375 350
new 1 375 350
return 1 375 351
assign 1 378 363
new 0 378 363
assign 1 378 364
lengthGet 0 378 364
assign 1 378 365
add 1 378 365
assign 1 378 366
new 2 378 366
assign 1 379 367
iteratorGet 0 0 367
assign 1 379 370
hasNextGet 0 379 370
assign 1 379 372
nextGet 0 379 372
addValueWhole 1 380 373
assign 1 382 379
iteratorGet 0 0 379
assign 1 382 382
hasNextGet 0 382 382
assign 1 382 384
nextGet 0 382 384
addValueWhole 1 383 385
return 1 385 391
assign 1 389 395
mergeSort 0 389 395
return 1 389 396
assign 1 393 400
new 0 393 400
sortValue 2 393 401
assign 1 397 415
copy 0 397 415
assign 1 397 418
lesser 1 397 423
assign 1 398 424
copy 0 398 424
assign 1 399 425
copy 0 399 425
assign 1 399 428
lesser 1 399 433
assign 1 400 434
get 1 400 434
assign 1 400 435
get 1 400 435
assign 1 400 436
lesser 1 400 436
assign 1 401 438
copy 0 401 438
incrementValue 0 399 440
assign 1 404 446
get 1 404 446
assign 1 405 447
get 1 405 447
put 2 405 448
put 2 406 449
incrementValue 0 397 450
assign 1 411 473
new 0 411 473
assign 1 412 474
new 0 412 474
assign 1 413 475
new 0 413 475
assign 1 414 476
lengthGet 0 414 476
assign 1 415 477
lengthGet 0 415 477
assign 1 416 480
lesser 1 416 485
assign 1 417 486
lesser 1 417 491
assign 1 417 492
lesser 1 417 497
assign 1 0 498
assign 1 0 501
assign 1 0 505
assign 1 418 508
get 1 418 508
assign 1 419 509
get 1 419 509
assign 1 420 510
lesser 1 420 510
incrementValue 0 421 512
put 2 422 513
incrementValue 0 424 516
put 2 425 517
assign 1 427 521
lesser 1 427 526
assign 1 428 527
get 1 428 527
incrementValue 0 429 528
put 2 430 529
assign 1 431 532
lesser 1 431 537
assign 1 432 538
get 1 432 538
incrementValue 0 433 539
put 2 434 540
incrementValue 0 436 544
assign 1 441 555
new 0 441 555
assign 1 441 556
mergeSort 2 441 556
return 1 441 557
assign 1 445 577
subtract 1 445 577
assign 1 446 578
new 0 446 578
assign 1 446 579
equals 1 446 584
assign 1 447 585
new 0 447 585
assign 1 447 586
create 1 447 586
return 1 447 587
assign 1 448 590
new 0 448 590
assign 1 448 591
equals 1 448 596
assign 1 449 597
new 0 449 597
assign 1 449 598
create 1 449 598
assign 1 450 599
new 0 450 599
assign 1 450 600
get 1 450 600
put 2 450 601
return 1 451 602
assign 1 453 605
new 0 453 605
assign 1 453 606
divide 1 453 606
assign 1 454 607
subtract 1 454 607
assign 1 455 608
add 1 455 608
assign 1 456 609
mergeSort 2 456 609
assign 1 457 610
mergeSort 2 457 610
assign 1 458 611
create 1 458 611
mergeIn 2 459 612
return 1 460 613
assign 1 465 621
new 0 465 621
assign 1 466 623
new 0 466 623
assign 1 466 624
new 1 466 624
throw 1 466 625
assign 1 472 633
greater 1 472 638
assign 1 473 639
multiply 1 473 639
assign 1 494 642
assign 1 497 646
lesser 1 497 651
incrementValue 0 508 654
setValue 1 510 660
assign 1 514 667
def 1 514 672
assign 1 515 675
hasNextGet 0 515 675
assign 1 516 677
nextGet 0 516 677
addValueWhole 1 516 678
assign 1 522 690
def 1 522 695
assign 1 523 696
iteratorGet 0 523 696
iterateAdd 1 523 697
assign 1 528 704
lesser 1 528 709
incrementValue 0 539 712
assign 1 542 715
copy 0 542 715
put 2 542 716
assign 1 547 724
def 1 547 729
assign 1 547 730
sameType 1 547 730
assign 1 0 732
assign 1 0 735
assign 1 0 739
addAll 1 548 742
addValueWhole 1 550 745
assign 1 556 756
new 0 556 756
assign 1 556 759
lesser 1 556 764
assign 1 557 765
get 1 557 765
assign 1 558 766
def 1 558 771
assign 1 558 772
equals 1 558 772
assign 1 0 774
assign 1 0 777
assign 1 0 781
return 1 559 784
incrementValue 0 556 786
return 1 562 792
assign 1 566 799
find 1 566 799
assign 1 566 800
def 1 566 805
assign 1 567 806
new 0 567 806
return 1 567 807
assign 1 569 809
new 0 569 809
return 1 569 810
assign 1 575 815
new 0 575 815
assign 1 575 816
sortedFind 2 575 816
return 1 575 817
assign 1 582 838
assign 1 583 839
new 0 583 839
assign 1 587 842
subtract 1 587 842
assign 1 587 843
new 0 587 843
assign 1 587 844
divide 1 587 844
assign 1 587 845
add 1 587 845
assign 1 588 846
get 1 588 846
assign 1 589 847
equals 1 589 847
return 1 590 849
assign 1 591 852
greater 1 591 852
assign 1 593 854
assign 1 594 857
lesser 1 594 857
assign 1 596 859
assign 1 599 863
def 1 599 868
assign 1 599 869
equals 1 599 874
assign 1 0 875
assign 1 0 878
assign 1 0 882
assign 1 600 886
get 1 600 886
assign 1 600 887
lesser 1 600 887
assign 1 0 889
assign 1 0 892
assign 1 0 896
return 1 601 899
return 1 603 901
assign 1 605 903
assign 1 606 904
new 0 606 904
return 1 607 906
return 1 0 911
return 1 0 914
assign 1 0 917
return 1 0 921
return 1 0 924
assign 1 0 927
return 1 0 931
return 1 0 934
assign 1 0 937
assign 1 0 941
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1342623754: return bem_copy_0();
case 409380620: return bem_fieldIteratorGet_0();
case -1435697051: return bem_lengthGetDirect_0();
case 807655445: return bem_print_0();
case -284036298: return bem_sizeGet_0();
case -1718188704: return bem_hashGet_0();
case 247576523: return bem_classNameGet_0();
case 762553302: return bem_firstGet_0();
case -1766060558: return bem_clear_0();
case 498101216: return bem_echo_0();
case -677150073: return bem_toString_0();
case -1749437314: return bem_tagGet_0();
case 2066839134: return bem_iteratorGet_0();
case 1381751387: return bem_arrayIteratorGet_0();
case 1040626980: return bem_multiplierGet_0();
case 1625738524: return bem_anyrayGet_0();
case -225222698: return bem_create_0();
case -1189438197: return bem_mergeSort_0();
case -1190485338: return bem_sortValue_0();
case -1630894826: return bem_capacityGet_0();
case -98505880: return bem_isEmptyGet_0();
case 1147169825: return bem_lastGet_0();
case 107664471: return bem_multiplierGetDirect_0();
case -762241559: return bem_capacityGetDirect_0();
case 1146741600: return bem_sort_0();
case -543330026: return bem_fieldNamesGet_0();
case 1925175879: return bem_lengthGet_0();
case -1794485421: return bem_serializeContents_0();
case 398187407: return bem_sourceFileNameGet_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case 556565361: return bem_serializationIteratorGet_0();
case -141007990: return bem_anyraySet_0();
case 126387064: return bem_new_0();
case -2124354635: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 744528325: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case 1770175602: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -538424052: return bem_lengthSetDirect_1(bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -776005520: return bem_multiplierSetDirect_1(bevd_0);
case 1584364126: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case -1180006819: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1454412129: return bem_sortedFind_1(bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1149238266: return bem_addValue_1(bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case 1418181748: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1247201042: return bem_capacitySetDirect_1(bevd_0);
case -1198653622: return bem_find_1(bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case 1954378938: return bem_has_1(bevd_0);
case -519258616: return bem_iterateAdd_1(bevd_0);
case 1997957511: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case -1336774152: return bem_sizeSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1789014026: return bem_multiplierSet_1(bevd_0);
case 245560029: return bem_addValueWhole_1(bevd_0);
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -373002112: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case -518481492: return bem_addAll_1(bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case -404194174: return bem_copyTo_1(bevd_0);
case 1502842604: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 953464368: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 700918249: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1548046899: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -627787012: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1576081835: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 96226764: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
