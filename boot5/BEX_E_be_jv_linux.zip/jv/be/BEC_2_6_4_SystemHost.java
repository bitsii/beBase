package be;
/* IO:File: source/extended/Command.be */
public class BEC_2_6_4_SystemHost extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_SystemHost() { }
private static byte[] becc_BEC_2_6_4_SystemHost_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x48,0x6F,0x73,0x74};
private static byte[] becc_BEC_2_6_4_SystemHost_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_4_SystemHost_bels_0 = {0x68,0x6F,0x73,0x74,0x6E,0x61,0x6D,0x65,0x20,0x2D,0x73};
public static BEC_2_6_4_SystemHost bece_BEC_2_6_4_SystemHost_bevs_inst;

public static BET_2_6_4_SystemHost bece_BEC_2_6_4_SystemHost_bevs_type;

public BEC_2_6_4_SystemHost bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_SystemHost bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hostnameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_o = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_4_2_4_6_7_IOFileReaderCommand bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_4_SystemHost_bels_0));
bevt_0_tmpany_phold = (new BEC_4_2_4_6_7_IOFileReaderCommand()).bem_new_1(bevt_1_tmpany_phold);
bevl_r = bevt_0_tmpany_phold.bem_open_0();
bevl_o = (BEC_2_4_6_TextString) bevl_r.bemd_0(2024645456);
bevl_r.bemd_0(709853553);
bevl_l = bevl_o.bem_splitLines_0();
bevl_name = (BEC_2_4_6_TextString) bevl_l.bemd_0(578090968);
return bevl_name;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {146, 146, 146, 147, 148, 149, 150, 152};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 29, 30, 31, 32};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 146 25
new 0 146 25
assign 1 146 26
new 1 146 26
assign 1 146 27
open 0 146 27
assign 1 147 28
readString 0 147 28
close 0 148 29
assign 1 149 30
splitLines 0 149 30
assign 1 150 31
firstGet 0 150 31
return 1 152 32
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 908578243: return bem_many_0();
case -13815234: return bem_fieldNamesGet_0();
case 1201235982: return bem_once_0();
case 268720566: return bem_default_0();
case 1513901137: return bem_print_0();
case -1033467316: return bem_sourceFileNameGet_0();
case -316667874: return bem_echo_0();
case -1755712449: return bem_fieldIteratorGet_0();
case -1783183531: return bem_hashGet_0();
case -812156892: return bem_new_0();
case -5001660: return bem_copy_0();
case 1240185983: return bem_iteratorGet_0();
case -1523628327: return bem_hostnameGet_0();
case -350111569: return bem_toString_0();
case 105965675: return bem_classNameGet_0();
case 1590189157: return bem_deserializeClassNameGet_0();
case -1584056237: return bem_tagGet_0();
case 78507900: return bem_serializeContents_0();
case -926802099: return bem_serializationIteratorGet_0();
case 1058906403: return bem_serializeToString_0();
case 218061815: return bem_create_0();
case 301454853: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1387309622: return bem_def_1(bevd_0);
case 1801644657: return bem_undef_1(bevd_0);
case -1486270803: return bem_sameClass_1(bevd_0);
case -529986203: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 636080012: return bem_notEquals_1(bevd_0);
case -1009173585: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1501178892: return bem_equals_1(bevd_0);
case -1339800681: return bem_copyTo_1(bevd_0);
case -300868177: return bem_undefined_1(bevd_0);
case 522190896: return bem_defined_1(bevd_0);
case 658666820: return bem_sameType_1(bevd_0);
case 491086488: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -367405429: return bem_otherType_1(bevd_0);
case 315291080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -368171396: return bem_sameObject_1(bevd_0);
case 875182251: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 340348419: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736723624: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -894736335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -215779456: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1075456122: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -247437356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1773968373: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_SystemHost_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_4_SystemHost_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_SystemHost();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_inst = (BEC_2_6_4_SystemHost) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_type;
}
}
