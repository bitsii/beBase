package be;
/* IO:File: source/extended/Command.be */
public class BEC_2_6_4_SystemHost extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_SystemHost() { }
private static byte[] becc_BEC_2_6_4_SystemHost_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x48,0x6F,0x73,0x74};
private static byte[] becc_BEC_2_6_4_SystemHost_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_4_SystemHost_bels_0 = {0x68,0x6F,0x73,0x74,0x6E,0x61,0x6D,0x65,0x20,0x2D,0x73};
public static BEC_2_6_4_SystemHost bece_BEC_2_6_4_SystemHost_bevs_inst;

public static BET_2_6_4_SystemHost bece_BEC_2_6_4_SystemHost_bevs_type;

public BEC_2_6_4_SystemHost bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_SystemHost bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hostnameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_o = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_4_2_4_6_7_IOFileReaderCommand bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_9_TextTokenizer bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_7_TextStrings bevt_4_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_4_SystemHost_bels_0));
bevt_0_ta_ph = (new BEC_4_2_4_6_7_IOFileReaderCommand()).bem_new_1(bevt_1_ta_ph);
bevl_r = bevt_0_ta_ph.bem_open_0();
bevl_o = (BEC_2_4_6_TextString) bevl_r.bemd_0(-640865492);
bevl_r.bemd_0(2012848052);
bevt_4_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_3_ta_ph = bevt_4_ta_ph.bem_dosNewlineGet_0();
bevt_2_ta_ph = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_3_ta_ph);
bevl_l = bevt_2_ta_ph.bem_tokenize_1(bevl_o);
bevl_name = (BEC_2_4_6_TextString) bevl_l.bemd_0(-533509934);
return bevl_name;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {206, 206, 206, 207, 208, 209, 209, 209, 209, 210, 212};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 206 28
new 0 206 28
assign 1 206 29
new 1 206 29
assign 1 206 30
open 0 206 30
assign 1 207 31
readString 0 207 31
close 0 208 32
assign 1 209 33
new 0 209 33
assign 1 209 34
dosNewlineGet 0 209 34
assign 1 209 35
new 1 209 35
assign 1 209 36
tokenize 1 209 36
assign 1 210 37
firstGet 0 210 37
return 1 212 38
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2066241869: return bem_print_0();
case -1233241901: return bem_toString_0();
case -393844090: return bem_copy_0();
case 1160279532: return bem_create_0();
case 1862660644: return bem_new_0();
case -1079825495: return bem_iteratorGet_0();
case -748394026: return bem_hashGet_0();
case -1240571169: return bem_default_0();
case -1876510773: return bem_hostnameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1902022464: return bem_print_1(bevd_0);
case 310887766: return bem_undef_1(bevd_0);
case -1215278694: return bem_def_1(bevd_0);
case 1921787435: return bem_equals_1(bevd_0);
case 1633476346: return bem_notEquals_1(bevd_0);
case -465513410: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1745573040: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1324104974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1411462266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1926749857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_SystemHost_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_4_SystemHost_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_SystemHost();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_inst = (BEC_2_6_4_SystemHost) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_type;
}
}
