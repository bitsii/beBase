package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerMaps extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerMaps() { }
private static byte[] becc_BEC_2_9_4_ContainerMaps_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x73};
private static byte[] becc_BEC_2_9_4_ContainerMaps_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerMaps_bels_0 = {0x48,0x61,0x6E,0x64,0x6C,0x65,0x72};
public static BEC_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_inst;

public static BET_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_type;

public BEC_2_9_4_ContainerMaps bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_9_4_ContainerList bevl_varargs = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_9_4_ContainerMaps_bels_0));
beva_name = beva_name.bem_add_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bem_can_2(beva_name, bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 704*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_varargs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_varargs.bem_put_2(bevt_4_ta_ph, beva_args);
bevl_result = bem_invoke_2(beva_name, bevl_varargs);
} /* Line: 707*/
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromList_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_fromHandler_1(beva_list);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromHandler_1(BEC_2_9_4_ContainerList beva_list) throws Throwable {
BEC_2_4_3_MathInt bevl_ls = null;
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_ls = beva_list.bem_lengthGet_0();
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevl_ls.bem_add_1(bevt_1_ta_ph);
bevl_map = (new BEC_2_9_3_ContainerMap()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 719*/ {
if (bevl_i.bevi_int < bevl_ls.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 719*/ {
bevt_3_ta_ph = beva_list.bem_get_1(bevl_i);
bevl_i.bevi_int++;
bevt_5_ta_ph = bevl_i;
bevt_4_ta_ph = beva_list.bem_get_1(bevt_5_ta_ph);
bevl_map.bem_put_2(bevt_3_ta_ph, bevt_4_ta_ph);
bevl_i.bevi_int++;
} /* Line: 719*/
 else /* Line: 719*/ {
break;
} /* Line: 719*/
} /* Line: 719*/
return bevl_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fieldsIntoMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_9_3_ContainerMap beva_res) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_i = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(beva_inst);
while (true)
/* Line: 726*/ {
bevt_0_ta_ph = bevl_i.bemd_0(1765286468);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 726*/ {
bevt_1_ta_ph = bevl_i.bemd_0(1145852035);
bevt_2_ta_ph = bevl_i.bemd_0(-233330553);
beva_res.bem_put_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 727*/
 else /* Line: 726*/ {
break;
} /* Line: 726*/
} /* Line: 726*/
return beva_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapIntoFields_2(BEC_2_9_3_ContainerMap beva_from, BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_i = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(beva_inst);
while (true)
/* Line: 733*/ {
bevt_0_ta_ph = bevl_i.bemd_0(1765286468);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 733*/ {
bevt_2_ta_ph = bevl_i.bemd_0(1145852035);
bevt_1_ta_ph = beva_from.bem_get_1(bevt_2_ta_ph);
bevl_i.bemd_1(1580577611, bevt_1_ta_ph);
} /* Line: 734*/
 else /* Line: 733*/ {
break;
} /* Line: 733*/
} /* Line: 733*/
return beva_inst;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {703, 703, 704, 704, 705, 705, 706, 706, 707, 709, 713, 713, 717, 718, 718, 718, 719, 719, 719, 720, 720, 720, 720, 719, 722, 726, 726, 727, 727, 727, 729, 733, 733, 734, 734, 734, 736};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 34, 38, 39, 51, 52, 53, 54, 55, 58, 63, 64, 65, 67, 68, 69, 75, 82, 85, 87, 88, 89, 95, 102, 105, 107, 108, 109, 115};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 703 23
new 0 703 23
assign 1 703 24
add 1 703 24
assign 1 704 25
new 0 704 25
assign 1 704 26
can 2 704 26
assign 1 705 28
new 0 705 28
assign 1 705 29
new 1 705 29
assign 1 706 30
new 0 706 30
put 2 706 31
assign 1 707 32
invoke 2 707 32
return 1 709 34
assign 1 713 38
fromHandler 1 713 38
return 1 713 39
assign 1 717 51
lengthGet 0 717 51
assign 1 718 52
new 0 718 52
assign 1 718 53
add 1 718 53
assign 1 718 54
new 1 718 54
assign 1 719 55
new 0 719 55
assign 1 719 58
lesser 1 719 63
assign 1 720 64
get 1 720 64
assign 1 720 65
incrementValue 0 720 65
assign 1 720 67
get 1 720 67
put 2 720 68
incrementValue 0 719 69
return 1 722 75
assign 1 726 82
new 1 726 82
assign 1 726 85
hasNextGet 0 726 85
assign 1 727 87
nextNameGet 0 727 87
assign 1 727 88
currentGet 0 727 88
put 2 727 89
return 1 729 95
assign 1 733 102
new 1 733 102
assign 1 733 105
hasNextGet 0 733 105
assign 1 734 107
nextNameGet 0 734 107
assign 1 734 108
get 1 734 108
currentSet 1 734 109
return 1 736 115
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1104558808: return bem_hashGet_0();
case 1300072126: return bem_default_0();
case 300385203: return bem_toString_0();
case 1106770102: return bem_iteratorGet_0();
case 949701: return bem_print_0();
case 1569412621: return bem_create_0();
case 1211194663: return bem_new_0();
case 577809605: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -859684160: return bem_fromList_1((BEC_2_9_4_ContainerList) bevd_0);
case -1650199959: return bem_copyTo_1(bevd_0);
case -1230932201: return bem_print_1(bevd_0);
case -756175634: return bem_undef_1(bevd_0);
case -1992172428: return bem_fromHandler_1((BEC_2_9_4_ContainerList) bevd_0);
case 1215096844: return bem_def_1(bevd_0);
case 326054246: return bem_notEquals_1(bevd_0);
case -1016133256: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1847725704: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1174669181: return bem_fieldsIntoMap_2(bevd_0, (BEC_2_9_3_ContainerMap) bevd_1);
case 1753230616: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -753455512: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1204159569: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1245000173: return bem_mapIntoFields_2((BEC_2_9_3_ContainerMap) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerMaps_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerMaps_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerMaps();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst = (BEC_2_9_4_ContainerMaps) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_type;
}
}
