package be;
public class BET_2_6_19_SystemObjectFieldIterator extends BETS_Object {
public BET_2_6_19_SystemObjectFieldIterator() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "new_2", "advance_0", "hasNextGet_0", "hasCurrentGet_0", "nextNameGet_0", "currentNameGet_0", "nextGet_0", "currentGet_0", "nextSet_1", "currentSet_1", "skip_1", "posGet_0", "posSet_1", "instanceGet_0", "instanceSet_1", "instFieldNamesGet_0", "instFieldNamesSet_1", "lastidxGet_0", "lastidxSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "pos", "instance", "instFieldNames", "lastidx" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
}
