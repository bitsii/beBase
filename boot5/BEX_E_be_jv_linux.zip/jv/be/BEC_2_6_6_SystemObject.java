package be;
/* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject extends be.BECS_Object {
public BEC_2_6_6_SystemObject() { }

   public BEC_2_6_6_SystemObject bems_methodNotDefined(String name, BEC_2_6_6_SystemObject[] args) throws Throwable { 
     name = name.substring(0, name.lastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(name.getBytes("UTF-8")), new BEC_2_9_4_ContainerList(args));
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x5F};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_8 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public BEC_2_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_toAny_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_6_SystemObject_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(beva_name);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bem_classNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 72*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 77*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_6_SystemObject_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(beva_name);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bem_classNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 78*/
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevt_0_ta_ph = bem_createInstance_2(beva_cname, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_11_SystemInitializer bevt_8_ta_ph = null;
if (beva_cname == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 87*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_2));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 88*/
bevl_result = null;

        String key = new String(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int, "UTF-8");
        BETS_Object ti = be.BECS_Runtime.typeRefs.get(key);
        if (ti != null) {
            bevl_result = ti.bems_createInstance();
        } 
        if (bevl_result == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 144*/ {
if (beva_throwOnFail.bevi_bool)/* Line: 145*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_6_SystemObject_bels_3));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(beva_cname);
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 146*/
 else /* Line: 147*/ {
return null;
} /* Line: 148*/
} /* Line: 145*/
bevt_8_ta_ph = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_ta_ph = bevt_8_ta_ph.bem_initializeIfShould_1(bevl_result);
return bevt_7_ta_ph;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_fieldNamesGet_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_names = null;
bevl_names = (new BEC_2_9_4_ContainerList()).bem_new_0();

     BETS_Object bevs_cano = bemc_getType();
     String[] fnames = bevs_cano.bevs_fieldNames;
     
     for (int i = 0;i < fnames.length;i++) {
     
       bevl_names.bem_addValue_1(new BEC_2_4_6_TextString(fnames[i].getBytes("UTF-8")));

     }
     return bevl_names;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 222*/
if (beva_args == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 224*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_5));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 225*/
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
/* Line: 233*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_numargs.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(7));
bevt_11_ta_ph = bevl_numargs.bem_subtract_1(bevt_12_ta_ph);
bevl_args2 = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(7));
while (true)
/* Line: 236*/ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(7));
bevt_14_ta_ph = bevl_i.bem_subtract_1(bevt_15_ta_ph);
bevt_16_ta_ph = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_ta_ph, bevt_16_ta_ph);
bevl_i.bevi_int++;
} /* Line: 236*/
 else /* Line: 236*/ {
break;
} /* Line: 236*/
} /* Line: 236*/
} /* Line: 236*/
} /* Line: 234*/

        int ci = be.BECS_Ids.callIds.get(bevl_cname.bems_toJvString());
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_17_ta_ph.bevi_bool)/* Line: 316*/ {
bevl_rval.bemd_0(280712282);
} /* Line: 318*/
return bevl_rval;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 328*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_7));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 329*/
if (beva_numargs == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_8));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 332*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);

      
      String name = "" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      
      BETS_Object bevs_cano = bemc_getType();
      
      if (bevs_cano.bevs_methodNames.containsKey(name)) {
        return be.BECS_Runtime.boolTrue;
      }
      
      bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_9_ta_ph.bevi_bool)/* Line: 382*/ {
bevl_rval.bemd_0(280712282);
} /* Line: 383*/
if (bevl_rval == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 385*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /* Line: 386*/
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /*method end*/
public final BEC_2_4_6_TextString bem_classNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clname();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      bevl_xi = bemc_clnames();
      return bevl_xi;
} /*method end*/
public final BEC_2_4_6_TextString bem_sourceFileNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      bevl_xi = bemc_clfiles();
      return bevl_xi;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tagGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_classNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_print_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_echo_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
bevt_0_ta_ph.bem_echo_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_create_0();
bevt_0_ta_ph = bem_copyTo_1(bevt_1_ta_ph);
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
if (beva_copy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 645*/ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 646*/
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_ta_ph);
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_ta_ph);
while (true)
/* Line: 650*/ {
bevt_3_ta_ph = bevl_siter.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 650*/ {
bevt_4_ta_ph = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_ta_ph);
} /* Line: 651*/
 else /* Line: 650*/ {
break;
} /* Line: 650*/
} /* Line: 650*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_classNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (beva_other != null && this.getClass().equals(beva_other.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sameClass_1(beva_other);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (beva_other != null && beva_other.getClass().isAssignableFrom(this.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sameType_1(beva_other);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_getMethod_1(BEC_2_4_6_TextString beva_nameac) throws Throwable {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemMethod bevt_5_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_6));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_name = beva_nameac.bem_substring_2(bevt_1_ta_ph, bevl_cd);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_3_ta_ph = bevl_cd.bem_add_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_nameac.bem_substring_1(bevt_3_ta_ph);
bevl_ac = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_ta_ph);
bevt_5_ta_ph = bem_getMethod_2(bevl_name, bevl_ac);
return bevt_5_ta_ph;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_getMethod_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_ac) throws Throwable {
BEC_2_6_6_SystemMethod bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_6_SystemMethod()).bem_new_3(this, beva_name, beva_ac);
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_getInvocation_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_6_10_SystemInvocation bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_10_SystemInvocation()).bem_new_3(this, beva_name, beva_args);
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_once_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_many_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {30, 30, 41, 41, 52, 52, 63, 63, 67, 71, 72, 72, 72, 72, 72, 72, 72, 72, 77, 78, 78, 78, 78, 78, 78, 78, 78, 83, 83, 83, 87, 87, 88, 88, 88, 90, 144, 144, 146, 146, 146, 146, 148, 151, 151, 151, 156, 212, 221, 221, 222, 222, 222, 224, 224, 225, 225, 225, 227, 228, 228, 228, 228, 234, 234, 234, 235, 235, 235, 236, 236, 236, 237, 237, 237, 237, 236, 316, 318, 320, 328, 328, 329, 329, 329, 331, 331, 332, 332, 332, 334, 334, 334, 334, 382, 383, 385, 385, 386, 386, 388, 388, 429, 453, 492, 492, 531, 531, 542, 576, 587, 621, 625, 625, 625, 629, 629, 633, 633, 637, 637, 641, 641, 641, 645, 645, 646, 648, 648, 649, 649, 650, 651, 651, 657, 657, 663, 669, 669, 673, 673, 677, 677, 681, 681, 709, 765, 765, 769, 769, 769, 817, 817, 821, 821, 821, 825, 825, 826, 826, 827, 827, 827, 827, 828, 828, 832, 832, 836, 836};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 31, 35, 36, 40, 41, 45, 46, 49, 60, 62, 63, 64, 65, 66, 67, 68, 69, 82, 84, 85, 86, 87, 88, 89, 90, 91, 98, 99, 100, 113, 118, 119, 120, 121, 123, 130, 135, 137, 138, 139, 140, 143, 146, 147, 148, 152, 162, 188, 193, 194, 195, 196, 198, 203, 204, 205, 206, 208, 209, 210, 211, 212, 214, 215, 220, 221, 222, 223, 224, 227, 232, 233, 234, 235, 236, 237, 267, 269, 271, 290, 295, 296, 297, 298, 300, 305, 306, 307, 308, 310, 311, 312, 313, 324, 326, 328, 333, 334, 335, 337, 338, 346, 354, 362, 363, 371, 372, 376, 379, 383, 386, 391, 392, 397, 401, 402, 406, 407, 412, 413, 419, 420, 421, 431, 436, 437, 439, 440, 441, 442, 445, 447, 448, 458, 459, 465, 472, 473, 477, 478, 482, 483, 487, 488, 494, 502, 503, 508, 509, 514, 522, 523, 528, 529, 534, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 559, 560, 564, 565};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 30 30
new 0 30 30
return 1 30 31
assign 1 41 35
new 0 41 35
return 1 41 36
assign 1 52 40
new 0 52 40
return 1 52 41
assign 1 63 45
new 0 63 45
return 1 63 46
return 1 67 49
assign 1 71 60
new 0 71 60
assign 1 72 62
new 0 72 62
assign 1 72 63
add 1 72 63
assign 1 72 64
new 0 72 64
assign 1 72 65
add 1 72 65
assign 1 72 66
classNameGet 0 72 66
assign 1 72 67
add 1 72 67
assign 1 72 68
new 1 72 68
throw 1 72 69
assign 1 77 82
new 0 77 82
assign 1 78 84
new 0 78 84
assign 1 78 85
add 1 78 85
assign 1 78 86
new 0 78 86
assign 1 78 87
add 1 78 87
assign 1 78 88
classNameGet 0 78 88
assign 1 78 89
add 1 78 89
assign 1 78 90
new 1 78 90
throw 1 78 91
assign 1 83 98
new 0 83 98
assign 1 83 99
createInstance 2 83 99
return 1 83 100
assign 1 87 113
undef 1 87 118
assign 1 88 119
new 0 88 119
assign 1 88 120
new 1 88 120
throw 1 88 121
assign 1 90 123
assign 1 144 130
undef 1 144 135
assign 1 146 137
new 0 146 137
assign 1 146 138
add 1 146 138
assign 1 146 139
new 1 146 139
throw 1 146 140
return 1 148 143
assign 1 151 146
new 0 151 146
assign 1 151 147
initializeIfShould 1 151 147
return 1 151 148
assign 1 156 152
new 0 156 152
return 1 212 162
assign 1 221 188
undef 1 221 193
assign 1 222 194
new 0 222 194
assign 1 222 195
new 1 222 195
throw 1 222 196
assign 1 224 198
undef 1 224 203
assign 1 225 204
new 0 225 204
assign 1 225 205
new 1 225 205
throw 1 225 206
assign 1 227 208
lengthGet 0 227 208
assign 1 228 209
new 0 228 209
assign 1 228 210
add 1 228 210
assign 1 228 211
toString 0 228 211
assign 1 228 212
add 1 228 212
assign 1 234 214
new 0 234 214
assign 1 234 215
greater 1 234 220
assign 1 235 221
new 0 235 221
assign 1 235 222
subtract 1 235 222
assign 1 235 223
new 1 235 223
assign 1 236 224
new 0 236 224
assign 1 236 227
lesser 1 236 232
assign 1 237 233
new 0 237 233
assign 1 237 234
subtract 1 237 234
assign 1 237 235
get 1 237 235
put 2 237 236
incrementValue 0 236 237
assign 1 316 267
new 0 316 267
toString 0 318 269
return 1 320 271
assign 1 328 290
undef 1 328 295
assign 1 329 296
new 0 329 296
assign 1 329 297
new 1 329 297
throw 1 329 298
assign 1 331 300
undef 1 331 305
assign 1 332 306
new 0 332 306
assign 1 332 307
new 1 332 307
throw 1 332 308
assign 1 334 310
new 0 334 310
assign 1 334 311
add 1 334 311
assign 1 334 312
toString 0 334 312
assign 1 334 313
add 1 334 313
assign 1 382 324
new 0 382 324
toString 0 383 326
assign 1 385 328
def 1 385 333
assign 1 386 334
new 0 386 334
return 1 386 335
assign 1 388 337
new 0 388 337
return 1 388 338
return 1 429 346
return 1 453 354
assign 1 492 362
new 0 492 362
return 1 492 363
assign 1 531 371
new 0 531 371
return 1 531 372
assign 1 542 376
new 0 542 376
return 1 576 379
assign 1 587 383
new 0 587 383
return 1 621 386
assign 1 625 391
equals 1 625 391
assign 1 625 392
not 0 625 397
return 1 625 397
assign 1 629 401
classNameGet 0 629 401
return 1 629 402
assign 1 633 406
toString 0 633 406
print 0 633 407
assign 1 637 412
toString 0 637 412
echo 0 637 413
assign 1 641 419
create 0 641 419
assign 1 641 420
copyTo 1 641 420
return 1 641 421
assign 1 645 431
undef 1 645 436
return 1 646 437
assign 1 648 439
new 0 648 439
assign 1 648 440
new 2 648 440
assign 1 649 441
new 0 649 441
assign 1 649 442
new 2 649 442
assign 1 650 445
hasNextGet 0 650 445
assign 1 651 447
nextGet 0 651 447
nextSet 1 651 448
assign 1 657 458
classNameGet 0 657 458
return 1 657 459
return 1 663 465
assign 1 669 472
new 1 669 472
return 1 669 473
assign 1 673 477
new 1 673 477
return 1 673 478
assign 1 677 482
new 1 677 482
return 1 677 483
assign 1 681 487
new 0 681 487
return 1 681 488
return 1 709 494
assign 1 765 502
new 0 765 502
return 1 765 503
assign 1 769 508
sameClass 1 769 508
assign 1 769 509
not 0 769 514
return 1 769 514
assign 1 817 522
new 0 817 522
return 1 817 523
assign 1 821 528
sameType 1 821 528
assign 1 821 529
not 0 821 534
return 1 821 534
assign 1 825 546
new 0 825 546
assign 1 825 547
rfind 1 825 547
assign 1 826 548
new 0 826 548
assign 1 826 549
substring 2 826 549
assign 1 827 550
new 0 827 550
assign 1 827 551
add 1 827 551
assign 1 827 552
substring 1 827 552
assign 1 827 553
new 1 827 553
assign 1 828 554
getMethod 2 828 554
return 1 828 555
assign 1 832 559
new 3 832 559
return 1 832 560
assign 1 836 564
new 3 836 564
return 1 836 565
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 967234853: return bem_fieldIteratorGet_0();
case -119499799: return bem_serializationIteratorGet_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case -1724453868: return bem_serializeToString_0();
case -533443118: return bem_many_0();
case -194416815: return bem_tagGet_0();
case 1797865600: return bem_new_0();
case 1955915393: return bem_fieldNamesGet_0();
case 1777587047: return bem_hashGet_0();
case 1095297479: return bem_echo_0();
case -665649433: return bem_serializeContents_0();
case 766881626: return bem_print_0();
case 280712282: return bem_toString_0();
case 378307569: return bem_copy_0();
case -1715766851: return bem_toAny_0();
case -1455899172: return bem_create_0();
case 617445256: return bem_sourceFileNameGet_0();
case -180175097: return bem_classNameGet_0();
case 2011135674: return bem_iteratorGet_0();
case 509361355: return bem_once_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -445857610: return bem_notEquals_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 906320876: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemObject();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
