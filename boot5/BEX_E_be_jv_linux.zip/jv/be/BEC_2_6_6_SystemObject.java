package be;
/* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject extends be.BECS_Object {
public BEC_2_6_6_SystemObject() { }

   public BEC_2_6_6_SystemObject bems_methodNotDefined(String name, BEC_2_6_6_SystemObject[] args) throws Throwable { 
     name = name.substring(0, name.lastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(name.getBytes("UTF-8")), new BEC_2_9_4_ContainerList(args));
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_0, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_1, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_2, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_3, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_5, 16));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_8 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_8, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_6 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_7 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_11 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_11, 1));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_12 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_11 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public BEC_2_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_toAny_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 73 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 78 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_3;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 79 */
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = bem_createInstance_2(beva_cname, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_11_SystemInitializer bevt_8_tmpany_phold = null;
if (beva_cname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 89 */
bevl_result = null;

        String key = new String(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int, "UTF-8");
        BETS_Object ti = be.BECS_Runtime.typeRefs.get(key);
        if (ti != null) {
            bevl_result = ti.bems_createInstance();
        } 
        if (bevl_result == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 120 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 121 */ {
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_4;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(beva_cname);
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 122 */
 else  /* Line: 123 */ {
return null;
} /* Line: 124 */
} /* Line: 121 */
bevt_8_tmpany_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_initializeIfShould_1(bevl_result);
return bevt_7_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 136 */
if (beva_args == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_7));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 139 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_5;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
 /* Line: 147 */ {
bevt_10_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_6;
if (bevl_numargs.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevt_12_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_7;
bevt_11_tmpany_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpany_phold);
bevl_args2 = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 150 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_8;
bevt_14_tmpany_phold = bevl_i.bem_subtract_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpany_phold, bevt_16_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 150 */
 else  /* Line: 150 */ {
break;
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 148 */

        int ci = be.BECS_Ids.callIds.get(new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8"));
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 201 */ {
bevl_rval.bemd_0(677808118);
} /* Line: 203 */
return bevl_rval;
} /*method end*/
public BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_9));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 214 */
if (beva_numargs == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_10));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 217 */
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_9;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);

      
      String name = "" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      
      BETS_Object bevs_cano = bemc_getType();
      
      if (bevs_cano.bevs_methodNames.containsKey(name)) {
        return be.BECS_Runtime.boolTrue;
      }
      
      bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevl_rval.bemd_0(677808118);
} /* Line: 255 */
if (bevl_rval == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /* Line: 258 */
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /*method end*/
public final BEC_2_4_6_TextString bem_classNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clname();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      bevl_xi = bemc_clnames();
      return bevl_xi;
} /*method end*/
public final BEC_2_4_6_TextString bem_sourceFileNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      bevl_xi = bemc_clfiles();
      return bevl_xi;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tagGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_print_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_echo_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_echo_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_create_0();
bevt_0_tmpany_phold = bem_copyTo_1(bevt_1_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
if (beva_copy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 482 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 483 */
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpany_phold);
while (true)
 /* Line: 487 */ {
bevt_3_tmpany_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 487 */ {
bevt_4_tmpany_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpany_phold);
} /* Line: 488 */
 else  /* Line: 487 */ {
break;
} /* Line: 487 */
} /* Line: 487 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && this.getClass().equals(beva_other.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && beva_other.getClass().isAssignableFrom(this.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameType_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_getMethod_1(BEC_2_4_6_TextString beva_nameac) throws Throwable {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemMethod bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_12));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_10;
bevl_name = beva_nameac.bem_substring_2(bevt_1_tmpany_phold, bevl_cd);
bevt_4_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_11;
bevt_3_tmpany_phold = bevl_cd.bem_add_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = beva_nameac.bem_substring_1(bevt_3_tmpany_phold);
bevl_ac = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bem_getMethod_2(bevl_name, bevl_ac);
return bevt_5_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_getMethod_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_ac) throws Throwable {
BEC_2_6_6_SystemMethod bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_6_SystemMethod()).bem_new_3(this, beva_name, beva_ac);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_getInvocation_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_6_10_SystemInvocation bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_10_SystemInvocation()).bem_new_3(this, beva_name, beva_args);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_once_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_many_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {31, 31, 42, 42, 53, 53, 64, 64, 68, 72, 73, 73, 73, 73, 73, 73, 73, 73, 78, 79, 79, 79, 79, 79, 79, 79, 79, 84, 84, 84, 88, 88, 89, 89, 89, 91, 120, 120, 122, 122, 122, 122, 124, 127, 127, 127, 135, 135, 136, 136, 136, 138, 138, 139, 139, 139, 141, 142, 142, 142, 142, 148, 148, 148, 149, 149, 149, 150, 150, 150, 151, 151, 151, 151, 150, 201, 203, 205, 213, 213, 214, 214, 214, 216, 216, 217, 217, 217, 219, 219, 219, 219, 254, 255, 257, 257, 258, 258, 260, 260, 296, 320, 352, 352, 384, 384, 395, 421, 432, 458, 462, 462, 462, 466, 466, 470, 470, 474, 474, 478, 478, 478, 482, 482, 483, 485, 485, 486, 486, 487, 488, 488, 494, 494, 500, 506, 506, 510, 510, 514, 514, 518, 518, 541, 588, 588, 592, 592, 592, 624, 624, 628, 628, 628, 632, 632, 633, 633, 634, 634, 634, 634, 635, 635, 639, 639, 643, 643};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {46, 47, 51, 52, 56, 57, 61, 62, 65, 76, 78, 79, 80, 81, 82, 83, 84, 85, 98, 100, 101, 102, 103, 104, 105, 106, 107, 114, 115, 116, 129, 134, 135, 136, 137, 139, 146, 151, 153, 154, 155, 156, 159, 162, 163, 164, 190, 195, 196, 197, 198, 200, 205, 206, 207, 208, 210, 211, 212, 213, 214, 216, 217, 222, 223, 224, 225, 226, 229, 234, 235, 236, 237, 238, 239, 269, 271, 273, 292, 297, 298, 299, 300, 302, 307, 308, 309, 310, 312, 313, 314, 315, 326, 328, 330, 335, 336, 337, 339, 340, 348, 356, 364, 365, 373, 374, 378, 381, 385, 388, 393, 394, 399, 403, 404, 408, 409, 414, 415, 421, 422, 423, 433, 438, 439, 441, 442, 443, 444, 447, 449, 450, 460, 461, 467, 474, 475, 479, 480, 484, 485, 489, 490, 496, 504, 505, 510, 511, 516, 524, 525, 530, 531, 536, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 561, 562, 566, 567};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 31 46
new 0 31 46
return 1 31 47
assign 1 42 51
new 0 42 51
return 1 42 52
assign 1 53 56
new 0 53 56
return 1 53 57
assign 1 64 61
new 0 64 61
return 1 64 62
return 1 68 65
assign 1 72 76
new 0 72 76
assign 1 73 78
new 0 73 78
assign 1 73 79
add 1 73 79
assign 1 73 80
new 0 73 80
assign 1 73 81
add 1 73 81
assign 1 73 82
classNameGet 0 73 82
assign 1 73 83
add 1 73 83
assign 1 73 84
new 1 73 84
throw 1 73 85
assign 1 78 98
new 0 78 98
assign 1 79 100
new 0 79 100
assign 1 79 101
add 1 79 101
assign 1 79 102
new 0 79 102
assign 1 79 103
add 1 79 103
assign 1 79 104
classNameGet 0 79 104
assign 1 79 105
add 1 79 105
assign 1 79 106
new 1 79 106
throw 1 79 107
assign 1 84 114
new 0 84 114
assign 1 84 115
createInstance 2 84 115
return 1 84 116
assign 1 88 129
undef 1 88 134
assign 1 89 135
new 0 89 135
assign 1 89 136
new 1 89 136
throw 1 89 137
assign 1 91 139
assign 1 120 146
undef 1 120 151
assign 1 122 153
new 0 122 153
assign 1 122 154
add 1 122 154
assign 1 122 155
new 1 122 155
throw 1 122 156
return 1 124 159
assign 1 127 162
new 0 127 162
assign 1 127 163
initializeIfShould 1 127 163
return 1 127 164
assign 1 135 190
undef 1 135 195
assign 1 136 196
new 0 136 196
assign 1 136 197
new 1 136 197
throw 1 136 198
assign 1 138 200
undef 1 138 205
assign 1 139 206
new 0 139 206
assign 1 139 207
new 1 139 207
throw 1 139 208
assign 1 141 210
lengthGet 0 141 210
assign 1 142 211
new 0 142 211
assign 1 142 212
add 1 142 212
assign 1 142 213
toString 0 142 213
assign 1 142 214
add 1 142 214
assign 1 148 216
new 0 148 216
assign 1 148 217
greater 1 148 222
assign 1 149 223
new 0 149 223
assign 1 149 224
subtract 1 149 224
assign 1 149 225
new 1 149 225
assign 1 150 226
new 0 150 226
assign 1 150 229
lesser 1 150 234
assign 1 151 235
new 0 151 235
assign 1 151 236
subtract 1 151 236
assign 1 151 237
get 1 151 237
put 2 151 238
incrementValue 0 150 239
assign 1 201 269
new 0 201 269
toString 0 203 271
return 1 205 273
assign 1 213 292
undef 1 213 297
assign 1 214 298
new 0 214 298
assign 1 214 299
new 1 214 299
throw 1 214 300
assign 1 216 302
undef 1 216 307
assign 1 217 308
new 0 217 308
assign 1 217 309
new 1 217 309
throw 1 217 310
assign 1 219 312
new 0 219 312
assign 1 219 313
add 1 219 313
assign 1 219 314
toString 0 219 314
assign 1 219 315
add 1 219 315
assign 1 254 326
new 0 254 326
toString 0 255 328
assign 1 257 330
def 1 257 335
assign 1 258 336
new 0 258 336
return 1 258 337
assign 1 260 339
new 0 260 339
return 1 260 340
return 1 296 348
return 1 320 356
assign 1 352 364
new 0 352 364
return 1 352 365
assign 1 384 373
new 0 384 373
return 1 384 374
assign 1 395 378
new 0 395 378
return 1 421 381
assign 1 432 385
new 0 432 385
return 1 458 388
assign 1 462 393
equals 1 462 393
assign 1 462 394
not 0 462 399
return 1 462 399
assign 1 466 403
classNameGet 0 466 403
return 1 466 404
assign 1 470 408
toString 0 470 408
print 0 470 409
assign 1 474 414
toString 0 474 414
echo 0 474 415
assign 1 478 421
create 0 478 421
assign 1 478 422
copyTo 1 478 422
return 1 478 423
assign 1 482 433
undef 1 482 438
return 1 483 439
assign 1 485 441
new 0 485 441
assign 1 485 442
new 2 485 442
assign 1 486 443
new 0 486 443
assign 1 486 444
new 2 486 444
assign 1 487 447
hasNextGet 0 487 447
assign 1 488 449
nextGet 0 488 449
nextSet 1 488 450
assign 1 494 460
classNameGet 0 494 460
return 1 494 461
return 1 500 467
assign 1 506 474
new 1 506 474
return 1 506 475
assign 1 510 479
new 1 510 479
return 1 510 480
assign 1 514 484
new 1 514 484
return 1 514 485
assign 1 518 489
new 0 518 489
return 1 518 490
return 1 541 496
assign 1 588 504
new 0 588 504
return 1 588 505
assign 1 592 510
sameClass 1 592 510
assign 1 592 511
not 0 592 516
return 1 592 516
assign 1 624 524
new 0 624 524
return 1 624 525
assign 1 628 530
sameType 1 628 530
assign 1 628 531
not 0 628 536
return 1 628 536
assign 1 632 548
new 0 632 548
assign 1 632 549
rfind 1 632 549
assign 1 633 550
new 0 633 550
assign 1 633 551
substring 2 633 551
assign 1 634 552
new 0 634 552
assign 1 634 553
add 1 634 553
assign 1 634 554
substring 1 634 554
assign 1 634 555
new 1 634 555
assign 1 635 556
getMethod 2 635 556
return 1 635 557
assign 1 639 561
new 3 639 561
return 1 639 562
assign 1 643 566
new 3 643 566
return 1 643 567
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 847900593: return bem_serializeContents_0();
case -1099311989: return bem_once_0();
case -1220916727: return bem_many_0();
case 2080907218: return bem_echo_0();
case 1059907561: return bem_classNameGet_0();
case 774012273: return bem_new_0();
case -1228227275: return bem_deserializeClassNameGet_0();
case 1975956372: return bem_hashGet_0();
case -1131153280: return bem_copy_0();
case 827292547: return bem_create_0();
case 677808118: return bem_toString_0();
case -362294474: return bem_sourceFileNameGet_0();
case 1616854488: return bem_print_0();
case -497405976: return bem_tagGet_0();
case 887158094: return bem_fieldIteratorGet_0();
case -1571656834: return bem_toAny_0();
case 585989692: return bem_serializeToString_0();
case 988563641: return bem_iteratorGet_0();
case -1707345921: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 197557310: return bem_undef_1(bevd_0);
case -1133393159: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 410232788: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -970121374: return bem_equals_1(bevd_0);
case -1649058984: return bem_sameType_1(bevd_0);
case 1998346117: return bem_undefined_1(bevd_0);
case -1542443673: return bem_copyTo_1(bevd_0);
case 1434568333: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1727272588: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1013351049: return bem_otherClass_1(bevd_0);
case 1910844205: return bem_defined_1(bevd_0);
case 1730126997: return bem_def_1(bevd_0);
case -1599156894: return bem_sameClass_1(bevd_0);
case -248970787: return bem_sameObject_1(bevd_0);
case 1248878306: return bem_notEquals_1(bevd_0);
case -1883746791: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 755484682: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -831651783: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1440576715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1239513525: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383341402: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1754203643: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126803346: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemObject();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
