package be;
/* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject extends be.BECS_Object {
public BEC_2_6_6_SystemObject() { }

   public BEC_2_6_6_SystemObject bems_methodNotDefined(String name, BEC_2_6_6_SystemObject[] args) throws Throwable { 
     name = name.substring(0, name.lastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(name.getBytes("UTF-8")), new BEC_2_9_4_ContainerList(args));
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_0, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_1, 23));
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_0, 8));
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_1, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_3, 16));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_6, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_6 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_7 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_8 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_6, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_11 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public BEC_2_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_toAny_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 71 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 72 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_3;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 78 */
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = bem_createInstance_2(beva_cname, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_11_SystemInitializer bevt_8_tmpany_phold = null;
if (beva_cname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_2));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 88 */
bevl_result = null;

        String key = new String(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int, "UTF-8");
        BETS_Object ti = be.BECS_Runtime.typeRefs.get(key);
        if (ti != null) {
            bevl_result = ti.bems_createInstance();
        } 
        if (bevl_result == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 144 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 145 */ {
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_4;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(beva_cname);
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 146 */
 else  /* Line: 147 */ {
return null;
} /* Line: 148 */
} /* Line: 145 */
bevt_8_tmpany_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_initializeIfShould_1(bevl_result);
return bevt_7_tmpany_phold;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_fieldNamesGet_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_names = null;
bevl_names = (new BEC_2_9_4_ContainerList()).bem_new_0();

     BETS_Object bevs_cano = bemc_getType();
     String[] fnames = bevs_cano.bevs_fieldNames;
     
     for (int i = 0;i < fnames.length;i++) {
     
       bevl_names.bem_addValue_1(new BEC_2_4_6_TextString(fnames[i].getBytes("UTF-8")));

     }
     return bevl_names;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 222 */
if (beva_args == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_5));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 225 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_5;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
 /* Line: 233 */ {
bevt_10_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_6;
if (bevl_numargs.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_12_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_7;
bevt_11_tmpany_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpany_phold);
bevl_args2 = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 236 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 236 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_8;
bevt_14_tmpany_phold = bevl_i.bem_subtract_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpany_phold, bevt_16_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 236 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
} /* Line: 236 */
} /* Line: 234 */

        int ci = be.BECS_Ids.callIds.get(bevl_cname.bems_toJvString());
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevl_rval.bemd_0(-1995804558);
} /* Line: 318 */
return bevl_rval;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_7));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 329 */
if (beva_numargs == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_8));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 332 */
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_9;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);

      
      String name = "" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      
      BETS_Object bevs_cano = bemc_getType();
      
      if (bevs_cano.bevs_methodNames.containsKey(name)) {
        return be.BECS_Runtime.boolTrue;
      }
      
      bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevl_rval.bemd_0(-1995804558);
} /* Line: 383 */
if (bevl_rval == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 385 */ {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /* Line: 386 */
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /*method end*/
public final BEC_2_4_6_TextString bem_classNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clname();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      bevl_xi = bemc_clnames();
      return bevl_xi;
} /*method end*/
public final BEC_2_4_6_TextString bem_sourceFileNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      bevl_xi = bemc_clfiles();
      return bevl_xi;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tagGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_print_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_echo_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_echo_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_create_0();
bevt_0_tmpany_phold = bem_copyTo_1(bevt_1_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
if (beva_copy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 645 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 646 */
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpany_phold);
while (true)
 /* Line: 650 */ {
bevt_3_tmpany_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 650 */ {
bevt_4_tmpany_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpany_phold);
} /* Line: 651 */
 else  /* Line: 650 */ {
break;
} /* Line: 650 */
} /* Line: 650 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && this.getClass().equals(beva_other.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && beva_other.getClass().isAssignableFrom(this.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameType_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_getMethod_1(BEC_2_4_6_TextString beva_nameac) throws Throwable {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemMethod bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_6));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_10;
bevl_name = beva_nameac.bem_substring_2(bevt_1_tmpany_phold, bevl_cd);
bevt_4_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_11;
bevt_3_tmpany_phold = bevl_cd.bem_add_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = beva_nameac.bem_substring_1(bevt_3_tmpany_phold);
bevl_ac = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bem_getMethod_2(bevl_name, bevl_ac);
return bevt_5_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemMethod bem_getMethod_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_ac) throws Throwable {
BEC_2_6_6_SystemMethod bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_6_SystemMethod()).bem_new_3(this, beva_name, beva_ac);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_10_SystemInvocation bem_getInvocation_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_6_10_SystemInvocation bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_10_SystemInvocation()).bem_new_3(this, beva_name, beva_args);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_once_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_many_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {30, 30, 41, 41, 52, 52, 63, 63, 67, 71, 72, 72, 72, 72, 72, 72, 72, 72, 77, 78, 78, 78, 78, 78, 78, 78, 78, 83, 83, 83, 87, 87, 88, 88, 88, 90, 144, 144, 146, 146, 146, 146, 148, 151, 151, 151, 156, 212, 221, 221, 222, 222, 222, 224, 224, 225, 225, 225, 227, 228, 228, 228, 228, 234, 234, 234, 235, 235, 235, 236, 236, 236, 237, 237, 237, 237, 236, 316, 318, 320, 328, 328, 329, 329, 329, 331, 331, 332, 332, 332, 334, 334, 334, 334, 382, 383, 385, 385, 386, 386, 388, 388, 429, 453, 492, 492, 531, 531, 542, 576, 587, 621, 625, 625, 625, 629, 629, 633, 633, 637, 637, 641, 641, 641, 645, 645, 646, 648, 648, 649, 649, 650, 651, 651, 657, 657, 663, 669, 669, 673, 673, 677, 677, 681, 681, 709, 765, 765, 769, 769, 769, 817, 817, 821, 821, 821, 825, 825, 826, 826, 827, 827, 827, 827, 828, 828, 832, 832, 836, 836};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {42, 43, 47, 48, 52, 53, 57, 58, 61, 72, 74, 75, 76, 77, 78, 79, 80, 81, 94, 96, 97, 98, 99, 100, 101, 102, 103, 110, 111, 112, 125, 130, 131, 132, 133, 135, 142, 147, 149, 150, 151, 152, 155, 158, 159, 160, 164, 174, 200, 205, 206, 207, 208, 210, 215, 216, 217, 218, 220, 221, 222, 223, 224, 226, 227, 232, 233, 234, 235, 236, 239, 244, 245, 246, 247, 248, 249, 279, 281, 283, 302, 307, 308, 309, 310, 312, 317, 318, 319, 320, 322, 323, 324, 325, 336, 338, 340, 345, 346, 347, 349, 350, 358, 366, 374, 375, 383, 384, 388, 391, 395, 398, 403, 404, 409, 413, 414, 418, 419, 424, 425, 431, 432, 433, 443, 448, 449, 451, 452, 453, 454, 457, 459, 460, 470, 471, 477, 484, 485, 489, 490, 494, 495, 499, 500, 506, 514, 515, 520, 521, 526, 534, 535, 540, 541, 546, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 571, 572, 576, 577};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 30 42
new 0 30 42
return 1 30 43
assign 1 41 47
new 0 41 47
return 1 41 48
assign 1 52 52
new 0 52 52
return 1 52 53
assign 1 63 57
new 0 63 57
return 1 63 58
return 1 67 61
assign 1 71 72
new 0 71 72
assign 1 72 74
new 0 72 74
assign 1 72 75
add 1 72 75
assign 1 72 76
new 0 72 76
assign 1 72 77
add 1 72 77
assign 1 72 78
classNameGet 0 72 78
assign 1 72 79
add 1 72 79
assign 1 72 80
new 1 72 80
throw 1 72 81
assign 1 77 94
new 0 77 94
assign 1 78 96
new 0 78 96
assign 1 78 97
add 1 78 97
assign 1 78 98
new 0 78 98
assign 1 78 99
add 1 78 99
assign 1 78 100
classNameGet 0 78 100
assign 1 78 101
add 1 78 101
assign 1 78 102
new 1 78 102
throw 1 78 103
assign 1 83 110
new 0 83 110
assign 1 83 111
createInstance 2 83 111
return 1 83 112
assign 1 87 125
undef 1 87 130
assign 1 88 131
new 0 88 131
assign 1 88 132
new 1 88 132
throw 1 88 133
assign 1 90 135
assign 1 144 142
undef 1 144 147
assign 1 146 149
new 0 146 149
assign 1 146 150
add 1 146 150
assign 1 146 151
new 1 146 151
throw 1 146 152
return 1 148 155
assign 1 151 158
new 0 151 158
assign 1 151 159
initializeIfShould 1 151 159
return 1 151 160
assign 1 156 164
new 0 156 164
return 1 212 174
assign 1 221 200
undef 1 221 205
assign 1 222 206
new 0 222 206
assign 1 222 207
new 1 222 207
throw 1 222 208
assign 1 224 210
undef 1 224 215
assign 1 225 216
new 0 225 216
assign 1 225 217
new 1 225 217
throw 1 225 218
assign 1 227 220
lengthGet 0 227 220
assign 1 228 221
new 0 228 221
assign 1 228 222
add 1 228 222
assign 1 228 223
toString 0 228 223
assign 1 228 224
add 1 228 224
assign 1 234 226
new 0 234 226
assign 1 234 227
greater 1 234 232
assign 1 235 233
new 0 235 233
assign 1 235 234
subtract 1 235 234
assign 1 235 235
new 1 235 235
assign 1 236 236
new 0 236 236
assign 1 236 239
lesser 1 236 244
assign 1 237 245
new 0 237 245
assign 1 237 246
subtract 1 237 246
assign 1 237 247
get 1 237 247
put 2 237 248
incrementValue 0 236 249
assign 1 316 279
new 0 316 279
toString 0 318 281
return 1 320 283
assign 1 328 302
undef 1 328 307
assign 1 329 308
new 0 329 308
assign 1 329 309
new 1 329 309
throw 1 329 310
assign 1 331 312
undef 1 331 317
assign 1 332 318
new 0 332 318
assign 1 332 319
new 1 332 319
throw 1 332 320
assign 1 334 322
new 0 334 322
assign 1 334 323
add 1 334 323
assign 1 334 324
toString 0 334 324
assign 1 334 325
add 1 334 325
assign 1 382 336
new 0 382 336
toString 0 383 338
assign 1 385 340
def 1 385 345
assign 1 386 346
new 0 386 346
return 1 386 347
assign 1 388 349
new 0 388 349
return 1 388 350
return 1 429 358
return 1 453 366
assign 1 492 374
new 0 492 374
return 1 492 375
assign 1 531 383
new 0 531 383
return 1 531 384
assign 1 542 388
new 0 542 388
return 1 576 391
assign 1 587 395
new 0 587 395
return 1 621 398
assign 1 625 403
equals 1 625 403
assign 1 625 404
not 0 625 409
return 1 625 409
assign 1 629 413
classNameGet 0 629 413
return 1 629 414
assign 1 633 418
toString 0 633 418
print 0 633 419
assign 1 637 424
toString 0 637 424
echo 0 637 425
assign 1 641 431
create 0 641 431
assign 1 641 432
copyTo 1 641 432
return 1 641 433
assign 1 645 443
undef 1 645 448
return 1 646 449
assign 1 648 451
new 0 648 451
assign 1 648 452
new 2 648 452
assign 1 649 453
new 0 649 453
assign 1 649 454
new 2 649 454
assign 1 650 457
hasNextGet 0 650 457
assign 1 651 459
nextGet 0 651 459
nextSet 1 651 460
assign 1 657 470
classNameGet 0 657 470
return 1 657 471
return 1 663 477
assign 1 669 484
new 1 669 484
return 1 669 485
assign 1 673 489
new 1 673 489
return 1 673 490
assign 1 677 494
new 1 677 494
return 1 677 495
assign 1 681 499
new 0 681 499
return 1 681 500
return 1 709 506
assign 1 765 514
new 0 765 514
return 1 765 515
assign 1 769 520
sameClass 1 769 520
assign 1 769 521
not 0 769 526
return 1 769 526
assign 1 817 534
new 0 817 534
return 1 817 535
assign 1 821 540
sameType 1 821 540
assign 1 821 541
not 0 821 546
return 1 821 546
assign 1 825 558
new 0 825 558
assign 1 825 559
rfind 1 825 559
assign 1 826 560
new 0 826 560
assign 1 826 561
substring 2 826 561
assign 1 827 562
new 0 827 562
assign 1 827 563
add 1 827 563
assign 1 827 564
substring 1 827 564
assign 1 827 565
new 1 827 565
assign 1 828 566
getMethod 2 828 566
return 1 828 567
assign 1 832 571
new 3 832 571
return 1 832 572
assign 1 836 576
new 3 836 576
return 1 836 577
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1890761825: return bem_hashGet_0();
case -1154985755: return bem_echo_0();
case -1155411626: return bem_classNameGet_0();
case -225078823: return bem_serializationIteratorGet_0();
case 285074277: return bem_deserializeClassNameGet_0();
case -1845402369: return bem_create_0();
case 1835904283: return bem_fieldIteratorGet_0();
case 944745844: return bem_iteratorGet_0();
case -858518329: return bem_many_0();
case -703952395: return bem_toAny_0();
case 745980876: return bem_serializeToString_0();
case -967525204: return bem_fieldNamesGet_0();
case 863596927: return bem_sourceFileNameGet_0();
case 1592801927: return bem_serializeContents_0();
case 232809271: return bem_copy_0();
case -1995804558: return bem_toString_0();
case 841207683: return bem_new_0();
case -513985458: return bem_once_0();
case -1247813666: return bem_tagGet_0();
case 1562045422: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1200297939: return bem_undef_1(bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 12031225: return bem_def_1(bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case -1815546435: return bem_copyTo_1(bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemObject();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
