package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_8_JsonParseLog extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_JsonParseLog() { }
private static byte[] becc_BEC_2_4_8_JsonParseLog_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_4_8_JsonParseLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_0 = {0x47,0x6F,0x74,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7C};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_1 = {0x7C};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_2 = {0x62,0x65,0x67,0x69,0x6E,0x4D,0x61,0x70};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_3 = {0x65,0x6E,0x64,0x4D,0x61,0x70};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_4 = {0x6B,0x76,0x4D,0x69,0x64};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_5 = {0x62,0x65,0x67,0x69,0x6E,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_6 = {0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_7 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_8 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_9 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x4E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_10 = {0x47,0x6F,0x74,0x20,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x20,0x7C};
public static BEC_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_inst;

public static BET_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_type;

public BEC_2_4_8_JsonParseLog bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_4_8_JsonParseLog_bels_0));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_str);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_8_JsonParseLog_bels_1));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_beginMap_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_4_8_JsonParseLog_bels_2));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_endMap_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_4_8_JsonParseLog_bels_3));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_kvMid_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_4_8_JsonParseLog_bels_4));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_beginList_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_4_8_JsonParseLog_bels_5));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_endList_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_4_8_JsonParseLog_bels_6));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleTrue_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_4_8_JsonParseLog_bels_7));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleFalse_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_4_8_JsonParseLog_bels_8));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleNull_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_4_8_JsonParseLog_bels_9));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_8_JsonParseLog bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_JsonParseLog_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_int);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_8_JsonParseLog_bels_1));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {580, 580, 580, 580, 580, 584, 584, 588, 588, 592, 592, 596, 596, 600, 600, 604, 604, 608, 608, 612, 612, 616, 616, 616, 616, 616};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 31, 32, 33, 34, 39, 40, 45, 46, 51, 52, 57, 58, 63, 64, 69, 70, 75, 76, 81, 82, 90, 91, 92, 93, 94};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 580 30
new 0 580 30
assign 1 580 31
add 1 580 31
assign 1 580 32
new 0 580 32
assign 1 580 33
add 1 580 33
print 0 580 34
assign 1 584 39
new 0 584 39
print 0 584 40
assign 1 588 45
new 0 588 45
print 0 588 46
assign 1 592 51
new 0 592 51
print 0 592 52
assign 1 596 57
new 0 596 57
print 0 596 58
assign 1 600 63
new 0 600 63
print 0 600 64
assign 1 604 69
new 0 604 69
print 0 604 70
assign 1 608 75
new 0 608 75
print 0 608 76
assign 1 612 81
new 0 612 81
print 0 612 82
assign 1 616 90
new 0 616 90
assign 1 616 91
add 1 616 91
assign 1 616 92
new 0 616 92
assign 1 616 93
add 1 616 93
print 0 616 94
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1614815570: return bem_beginMap_0();
case 989732871: return bem_new_0();
case 1648346602: return bem_tagGet_0();
case -1136648067: return bem_sourceFileNameGet_0();
case -1786334802: return bem_classNameGet_0();
case -1335945178: return bem_endMap_0();
case 1773293529: return bem_hashGet_0();
case 1120802307: return bem_handleTrue_0();
case 1053844604: return bem_beginList_0();
case 140845305: return bem_handleNull_0();
case 1190493910: return bem_endList_0();
case -777055641: return bem_copy_0();
case 889719110: return bem_print_0();
case 2140998184: return bem_fieldNamesGet_0();
case 1812616799: return bem_create_0();
case 905805379: return bem_kvMid_0();
case 773889589: return bem_handleFalse_0();
case 1073013382: return bem_iteratorGet_0();
case -362215698: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -583708652: return bem_otherType_1(bevd_0);
case -1808275641: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case -1764717463: return bem_notEquals_1(bevd_0);
case 137331971: return bem_undef_1(bevd_0);
case -1875172918: return bem_sameObject_1(bevd_0);
case -930132980: return bem_def_1(bevd_0);
case -42885212: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 980301665: return bem_sameType_1(bevd_0);
case 1295257783: return bem_otherClass_1(bevd_0);
case -70357317: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 1978132891: return bem_copyTo_1(bevd_0);
case 319814146: return bem_sameClass_1(bevd_0);
case 754161535: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1681451114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450498968: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 831817632: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1805853509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1679839886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_JsonParseLog_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_8_JsonParseLog_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_JsonParseLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst = (BEC_2_4_8_JsonParseLog) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_type;
}
}
