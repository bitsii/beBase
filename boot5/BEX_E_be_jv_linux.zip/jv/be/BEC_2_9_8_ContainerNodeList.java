package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 111};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 13
new 2 111 13
return 1 111 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 767000060: return bem_toNodeList_0();
case 1410785273: return bem_lengthGet_0();
case 43310726: return bem_reverse_0();
case 1318937193: return bem_create_0();
case -1490589724: return bem_serializationIteratorGet_0();
case 325293841: return bem_firstNodeGet_0();
case 1327010431: return bem_hashGet_0();
case 705395935: return bem_secondGet_0();
case 1769965429: return bem_toString_0();
case -41247917: return bem_sizeGet_0();
case 236178222: return bem_firstGet_0();
case 812348983: return bem_lastNodeGet_0();
case 1503484932: return bem_lastGet_0();
case 393892077: return bem_linkedListIteratorGet_0();
case 966722567: return bem_iteratorGet_0();
case -469226465: return bem_print_0();
case -597658083: return bem_toList_0();
case 532380883: return bem_new_0();
case -1354304744: return bem_thirdGet_0();
case -639540574: return bem_isEmptyGet_0();
case 2120153411: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -886453937: return bem_newNode_1(bevd_0);
case 655591970: return bem_prependNode_1(bevd_0);
case -1794255237: return bem_deleteNode_1(bevd_0);
case 809206318: return bem_addAll_1(bevd_0);
case -2022183043: return bem_addValueWhole_1(bevd_0);
case 1173696720: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 2147027771: return bem_copyTo_1(bevd_0);
case 129567019: return bem_firstNodeSet_1(bevd_0);
case 1784393303: return bem_lastNodeSet_1(bevd_0);
case 292335752: return bem_prepend_1(bevd_0);
case -155669521: return bem_getNode_1(bevd_0);
case -1047294117: return bem_iterateAdd_1(bevd_0);
case 870914554: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1161919231: return bem_addValue_1(bevd_0);
case 1194286113: return bem_def_1(bevd_0);
case -533094380: return bem_undef_1(bevd_0);
case -16136112: return bem_notEquals_1(bevd_0);
case -268811991: return bem_equals_1(bevd_0);
case -1404926020: return bem_appendNode_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -672637344: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -153469850: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1688602503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853384897: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -1665151698: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 633926395: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 792362948: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
