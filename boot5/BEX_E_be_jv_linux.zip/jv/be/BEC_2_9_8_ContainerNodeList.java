package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList extends BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {117, 117};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 117 13
new 2 117 13
return 1 117 14
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1672202791: return bem_firstNodeGet_0();
case -1250586953: return bem_create_0();
case 723604668: return bem_toList_0();
case 1230276296: return bem_hashGet_0();
case 992700193: return bem_copy_0();
case 1836285625: return bem_new_0();
case -603423052: return bem_reverse_0();
case -604728977: return bem_isEmptyGet_0();
case 1896064862: return bem_secondGet_0();
case 955274690: return bem_firstGet_0();
case -10560512: return bem_toString_0();
case -677367618: return bem_lastNodeGet_0();
case 1073567004: return bem_lastGet_0();
case -933932691: return bem_linkedListIteratorGet_0();
case -1077821762: return bem_thirdGet_0();
case 1790764513: return bem_toNodeList_0();
case -1568895705: return bem_serializationIteratorGet_0();
case 1978701672: return bem_iteratorGet_0();
case 1293883485: return bem_print_0();
case -1000401074: return bem_lengthGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 715512076: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1409349899: return bem_undef_1(bevd_0);
case -1914959093: return bem_lastNodeSet_1(bevd_0);
case -1010302786: return bem_addAll_1(bevd_0);
case 622349959: return bem_iterateAdd_1(bevd_0);
case 527842454: return bem_prepend_1(bevd_0);
case -1933815953: return bem_addValue_1(bevd_0);
case 1876074479: return bem_prependNode_1(bevd_0);
case 125783560: return bem_firstNodeSet_1(bevd_0);
case -305715842: return bem_notEquals_1(bevd_0);
case 454651429: return bem_deleteNode_1(bevd_0);
case 52329100: return bem_copyTo_1(bevd_0);
case -1978152287: return bem_print_1(bevd_0);
case -354065162: return bem_addValueWhole_1(bevd_0);
case 522012533: return bem_appendNode_1(bevd_0);
case 2087398785: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -1559741716: return bem_getNode_1(bevd_0);
case -424518602: return bem_newNode_1(bevd_0);
case -1926574247: return bem_def_1(bevd_0);
case 850514472: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1507992233: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1686468839: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1974138487: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1007047738: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -146219286: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 878807750: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 530385415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_8_ContainerNodeList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
