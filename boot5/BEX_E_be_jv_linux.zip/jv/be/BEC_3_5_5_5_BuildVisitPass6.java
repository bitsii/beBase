package be;
/* IO:File: source/build/Pass6.be */
public final class BEC_3_5_5_5_BuildVisitPass6 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_5_BuildVisitPass6_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_5_BuildVisitPass6_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_0 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_1 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_3 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_4 = {0x5F};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_5 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_6 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_8 = {0x73,0x65,0x6C,0x66};
public static BEC_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;

public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_38_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_5_4_BuildEmit bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_6_BuildIfEmit bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_4_6_TextString bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_4_6_TextString bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_5_3_BuildVar bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_168_tmpany_phold = null;
BEC_2_4_6_TextString bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_175_tmpany_phold = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 22 */ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_12_tmpany_phold == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_15_tmpany_phold = beva_node.bem_containedGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_lengthGet_0();
bevt_16_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass6_bevo_0;
if (bevt_14_tmpany_phold.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_20_tmpany_phold = beva_node.bem_containedGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1041915448);
if (bevt_18_tmpany_phold == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_25_tmpany_phold = beva_node.bem_containedGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_firstGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(-1041915448);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(1254758327);
bevt_26_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(906958631, bevt_26_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_30_tmpany_phold = beva_node.bem_secondGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_containedGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_lengthGet_0();
bevt_31_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass6_bevo_1;
if (bevt_28_tmpany_phold.bevi_int > bevt_31_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevl_langs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-1041915448);
bevt_0_tmpany_loop = bevt_32_tmpany_phold.bemd_0(-1180336274);
while (true)
 /* Line: 27 */ {
bevt_35_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1483364085);
if (((BEC_2_5_4_LogicBool) bevt_35_tmpany_phold).bevi_bool) /* Line: 27 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(-207086375);
bevt_36_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_tmpany_phold);
} /* Line: 29 */
 else  /* Line: 27 */ {
break;
} /* Line: 27 */
} /* Line: 27 */
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_37_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
if (((BEC_2_5_4_LogicBool) bevl_doit).bevi_bool) /* Line: 33 */ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_39_tmpany_phold = beva_node.bem_secondGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_containedGet_0();
bevl_i = bevt_38_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 35 */ {
bevt_40_tmpany_phold = bevl_i.bemd_0(1483364085);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 35 */ {
bevl_si = bevl_i.bemd_0(-207086375);
bevt_42_tmpany_phold = bevl_si.bemd_0(962118953);
bevt_43_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_1(2141890129, bevt_43_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_41_tmpany_phold).bevi_bool) /* Line: 37 */ {
bevt_44_tmpany_phold = bevl_si.bemd_0(-859453617);
beva_node.bem_heldSet_1(bevt_44_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 41 */
} /* Line: 37 */
 else  /* Line: 35 */ {
break;
} /* Line: 35 */
} /* Line: 35 */
} /* Line: 35 */
bevt_45_tmpany_phold = bevl_doit.bemd_0(972622480);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 45 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 47 */
beva_node.bem_containedSet_1(null);
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_tmpany_phold , bevl_langs);
beva_node.bem_heldSet_1(bevt_46_tmpany_phold);
} /* Line: 50 */
 else  /* Line: 51 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 53 */
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_tmpany_phold = bevl_snode.bemd_0(962118953);
bevt_50_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_1(2141890129, bevt_50_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_48_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevl_snode = null;
} /* Line: 58 */
if (bevl_snode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 61 */ {
beva_node.bem_delete_0();
bevt_52_tmpany_phold = bevl_snode.bemd_0(-859453617);
bevt_52_tmpany_phold.bemd_1(-1950913364, beva_node);
} /* Line: 63 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 66 */
 else  /* Line: 22 */ {
bevt_54_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_tmpany_phold.bevi_int == bevt_55_tmpany_phold.bevi_int) {
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpany_phold.bevi_bool) /* Line: 67 */ {
bevl_langs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_tmpany_phold = beva_node.bem_containedGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_firstGet_0();
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-1041915448);
bevt_1_tmpany_loop = bevt_56_tmpany_phold.bemd_0(-1180336274);
while (true)
 /* Line: 70 */ {
bevt_59_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1483364085);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 70 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_tmpany_loop.bemd_0(-207086375);
bevt_60_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_tmpany_phold);
bevl_toremove.bemd_1(1550798981, bevl_lang);
} /* Line: 73 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
bevt_61_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevl_langs.bem_delete_1(bevt_61_tmpany_phold);
bevt_63_tmpany_phold = beva_node.bem_heldGet_0();
bevt_62_tmpany_phold = (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_tmpany_phold );
beva_node.bem_heldSet_1(bevt_62_tmpany_phold);
bevl_ii = bevl_toremove.bemd_0(-1180336274);
while (true)
 /* Line: 77 */ {
bevt_64_tmpany_phold = bevl_ii.bemd_0(1483364085);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 77 */ {
bevl_i = bevl_ii.bemd_0(-207086375);
bevl_i.bemd_0(-1865267599);
} /* Line: 79 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
} /* Line: 77 */
 else  /* Line: 22 */ {
bevt_66_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_67_tmpany_phold = bevp_ntypes.bem_IFGet_0();
if (bevt_66_tmpany_phold.bevi_int == bevt_67_tmpany_phold.bevi_int) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 81 */ {
if (bevl_nnode == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevl_lnode = beva_node;
while (true)
 /* Line: 84 */ {
if (bevl_nnode == null) {
bevt_69_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(962118953);
bevt_72_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(2141890129, bevt_72_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_70_tmpany_phold).bevi_bool) /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 84 */ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(1218096481, bevt_73_tmpany_phold);
bevl_enode.bemd_1(-1550287185, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(-1550287185, beva_node);
bevt_74_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(1218096481, bevt_74_tmpany_phold);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(-1550287185, beva_node);
bevt_75_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(1218096481, bevt_75_tmpany_phold);
bevl_brnode.bemd_1(1550798981, bevl_inode);
bevl_enode.bemd_1(1550798981, bevl_brnode);
bevt_77_tmpany_phold = bevl_nnode.bemd_0(-1041915448);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_78_tmpany_phold = bevl_nnode.bemd_0(-1041915448);
bevl_i = bevt_78_tmpany_phold.bemd_0(-1180336274);
while (true)
 /* Line: 97 */ {
bevt_79_tmpany_phold = bevl_i.bemd_0(1483364085);
if (((BEC_2_5_4_LogicBool) bevt_79_tmpany_phold).bevi_bool) /* Line: 97 */ {
bevt_80_tmpany_phold = bevl_i.bemd_0(-207086375);
bevl_inode.bemd_1(1550798981, bevt_80_tmpany_phold);
} /* Line: 98 */
 else  /* Line: 97 */ {
break;
} /* Line: 97 */
} /* Line: 97 */
} /* Line: 97 */
bevl_lnode.bemd_1(1550798981, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(-1069442244);
bevl_nnode.bemd_0(-1865267599);
bevl_nnode = bevl_nxnode;
} /* Line: 109 */
 else  /* Line: 84 */ {
break;
} /* Line: 84 */
} /* Line: 84 */
if (bevl_nnode == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_83_tmpany_phold = bevl_nnode.bemd_0(962118953);
bevt_84_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(2141890129, bevt_84_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
 else  /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 111 */ {
bevl_nnode.bemd_0(-1865267599);
bevl_lnode.bemd_1(1550798981, bevl_nnode);
} /* Line: 113 */
} /* Line: 111 */
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 116 */
 else  /* Line: 22 */ {
bevt_87_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevt_89_tmpany_phold = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_tmpany_phold.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(-1550287185, beva_node);
bevt_90_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(1218096481, bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevl_nd.bemd_1(1279675583, bevt_91_tmpany_phold);
bevl_parens.bemd_1(953316113, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_tmpany_phold = bevl_parens.bemd_0(-1041915448);
bevl_ii = bevt_92_tmpany_phold.bemd_0(-1180336274);
while (true)
 /* Line: 126 */ {
bevt_93_tmpany_phold = bevl_ii.bemd_0(1483364085);
if (((BEC_2_5_4_LogicBool) bevt_93_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevl_i = bevl_ii.bemd_0(-207086375);
bevl_ix = bevl_i.bemd_0(-1069442244);
bevt_95_tmpany_phold = bevl_i.bemd_0(962118953);
bevt_96_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_1(2141890129, bevt_96_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_94_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevl_toremove.bemd_1(1550798981, bevl_i);
} /* Line: 132 */
 else  /* Line: 131 */ {
bevt_98_tmpany_phold = bevl_i.bemd_0(962118953);
bevt_99_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(2141890129, bevt_99_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_97_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_100_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(-167897483, bevt_100_tmpany_phold);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_tmpany_phold = bevl_i.bemd_0(-859453617);
bevl_v.bemd_1(-1245919083, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1914689035, bevt_102_tmpany_phold);
bevl_i.bemd_1(1279675583, bevl_v);
bevt_103_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(1218096481, bevt_103_tmpany_phold);
bevl_i.bemd_0(-358953493);
} /* Line: 140 */
 else  /* Line: 131 */ {
bevt_105_tmpany_phold = bevl_i.bemd_0(962118953);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bemd_1(2141890129, bevt_106_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_104_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevt_108_tmpany_phold = bevl_ix.bemd_0(962118953);
bevt_109_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bemd_1(2141890129, bevt_109_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_107_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevt_110_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(-167897483, bevt_110_tmpany_phold);
bevt_111_tmpany_phold = bevl_i.bemd_0(-859453617);
bevt_112_tmpany_phold = bevl_ix.bemd_0(-859453617);
bevt_111_tmpany_phold.bemd_1(-1245919083, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = bevl_i.bemd_0(-859453617);
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_113_tmpany_phold.bemd_1(-1914689035, bevt_114_tmpany_phold);
bevl_i.bemd_0(-358953493);
bevt_115_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(1218096481, bevt_115_tmpany_phold);
} /* Line: 147 */
 else  /* Line: 148 */ {
bevt_117_tmpany_phold = (new BEC_2_4_6_TextString(30, bece_BEC_3_5_5_5_BuildVisitPass6_bels_3));
bevt_116_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_tmpany_phold, bevl_i);
throw new be.BECS_ThrowBack(bevt_116_tmpany_phold);
} /* Line: 149 */
} /* Line: 142 */
} /* Line: 131 */
} /* Line: 131 */
} /* Line: 131 */
 else  /* Line: 126 */ {
break;
} /* Line: 126 */
} /* Line: 126 */
bevl_ii = bevl_toremove.bemd_0(-1180336274);
while (true)
 /* Line: 153 */ {
bevt_118_tmpany_phold = bevl_ii.bemd_0(1483364085);
if (((BEC_2_5_4_LogicBool) bevt_118_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevl_i = bevl_ii.bemd_0(-207086375);
bevl_i.bemd_0(-1865267599);
} /* Line: 155 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
bevl_s = beva_node.bem_heldGet_0();
bevt_120_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_119_tmpany_phold = bevl_numargs.bemd_1(1563911541, bevt_120_tmpany_phold);
bevl_s.bemd_1(-1529748240, bevt_119_tmpany_phold);
bevt_121_tmpany_phold = bevl_s.bemd_0(773868727);
bevl_s.bemd_1(684067295, bevt_121_tmpany_phold);
bevt_124_tmpany_phold = bevl_s.bemd_0(773868727);
bevt_125_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_4));
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bemd_1(-167897483, bevt_125_tmpany_phold);
bevt_127_tmpany_phold = bevl_s.bemd_0(-1394880521);
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bemd_0(83573654);
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(-167897483, bevt_126_tmpany_phold);
bevl_s.bemd_1(-1245919083, bevt_122_tmpany_phold);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_tmpany_phold = bevl_i.bemd_0(962118953);
bevt_130_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_128_tmpany_phold = bevt_129_tmpany_phold.bemd_1(2141890129, bevt_130_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_128_tmpany_phold).bevi_bool) /* Line: 162 */ {
bevl_i.bemd_0(-698440509);
bevt_131_tmpany_phold = bevl_i.bemd_0(-859453617);
bevl_s.bemd_1(299317604, bevt_131_tmpany_phold);
bevt_134_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_133_tmpany_phold = bevt_134_tmpany_phold.bemd_0(-1669205076);
if (bevt_133_tmpany_phold == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevl_s.bemd_1(299317604, null);
} /* Line: 168 */
 else  /* Line: 166 */ {
bevt_138_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bemd_0(-1669205076);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(83573654);
bevt_139_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_5));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(2141890129, bevt_139_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_135_tmpany_phold).bevi_bool) /* Line: 169 */ {
bevt_140_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_141_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_140_tmpany_phold.bemd_1(-970416658, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_143_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_142_tmpany_phold.bemd_1(-693233275, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_145_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_144_tmpany_phold.bemd_1(-823187369, bevt_145_tmpany_phold);
bevt_147_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_0(-1669205076);
bevt_148_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_6));
bevt_146_tmpany_phold.bemd_1(577328175, bevt_148_tmpany_phold);
} /* Line: 174 */
 else  /* Line: 166 */ {
bevt_152_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_0(-1669205076);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(83573654);
bevt_153_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_7));
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(2141890129, bevt_153_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_149_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevt_154_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_155_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_154_tmpany_phold.bemd_1(-970416658, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_157_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_156_tmpany_phold.bemd_1(-693233275, bevt_157_tmpany_phold);
} /* Line: 177 */
} /* Line: 166 */
} /* Line: 166 */
bevl_i.bemd_0(-1865267599);
} /* Line: 179 */
 else  /* Line: 180 */ {
bevt_158_tmpany_phold = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(299317604, bevt_158_tmpany_phold);
bevt_159_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_160_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_159_tmpany_phold.bemd_1(-970416658, bevt_160_tmpany_phold);
bevt_161_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_162_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_161_tmpany_phold.bemd_1(-693233275, bevt_162_tmpany_phold);
bevt_163_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_164_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_163_tmpany_phold.bemd_1(-823187369, bevt_164_tmpany_phold);
bevt_165_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_166_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_165_tmpany_phold.bemd_1(-128320571, bevt_166_tmpany_phold);
bevt_167_tmpany_phold = bevl_s.bemd_0(-940477477);
bevt_169_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_8));
bevt_168_tmpany_phold = (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_169_tmpany_phold);
bevt_167_tmpany_phold.bemd_1(1837965853, bevt_168_tmpany_phold);
} /* Line: 186 */
bevl_clnode = beva_node.bem_classGet_0();
bevt_171_tmpany_phold = bevl_clnode.bemd_0(-859453617);
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_0(1312178722);
bevt_172_tmpany_phold = bevl_s.bemd_0(773868727);
bevt_170_tmpany_phold.bemd_2(11266688, bevt_172_tmpany_phold, beva_node);
bevt_174_tmpany_phold = bevl_clnode.bemd_0(-859453617);
bevt_173_tmpany_phold = bevt_174_tmpany_phold.bemd_0(619426878);
bevt_173_tmpany_phold.bemd_1(1550798981, beva_node);
} /* Line: 190 */
} /* Line: 22 */
} /* Line: 22 */
} /* Line: 22 */
bevt_175_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_175_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 21, 22, 22, 22, 22, 23, 24, 24, 24, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 24, 0, 0, 0, 26, 27, 27, 27, 27, 0, 27, 27, 29, 29, 31, 31, 32, 34, 35, 35, 35, 35, 36, 37, 37, 37, 38, 38, 41, 45, 46, 47, 49, 50, 50, 50, 52, 53, 56, 57, 57, 57, 58, 61, 61, 62, 63, 63, 66, 67, 67, 67, 67, 68, 69, 70, 70, 70, 70, 0, 70, 70, 72, 72, 73, 75, 75, 76, 76, 76, 77, 77, 78, 79, 81, 81, 81, 81, 82, 82, 83, 84, 84, 84, 84, 84, 0, 0, 0, 85, 86, 86, 87, 88, 89, 90, 90, 91, 92, 93, 93, 94, 95, 96, 96, 96, 97, 97, 97, 98, 98, 105, 106, 107, 108, 109, 111, 111, 111, 111, 111, 0, 0, 0, 112, 113, 116, 116, 117, 117, 117, 117, 118, 118, 119, 120, 121, 121, 122, 122, 123, 124, 125, 126, 126, 126, 127, 128, 131, 131, 131, 132, 133, 133, 133, 134, 134, 135, 136, 136, 137, 137, 138, 139, 139, 140, 141, 141, 141, 142, 142, 142, 143, 143, 144, 144, 144, 145, 145, 145, 146, 147, 147, 149, 149, 149, 153, 153, 154, 155, 157, 158, 158, 158, 159, 159, 160, 160, 160, 160, 160, 160, 160, 161, 162, 162, 162, 163, 165, 165, 166, 166, 166, 166, 168, 169, 169, 169, 169, 169, 171, 171, 171, 172, 172, 172, 173, 173, 173, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 177, 177, 177, 179, 181, 181, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 186, 188, 189, 189, 189, 189, 190, 190, 190, 192, 192};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {223, 224, 225, 226, 227, 232, 233, 234, 235, 240, 241, 242, 243, 244, 249, 250, 253, 257, 260, 261, 262, 263, 268, 269, 272, 276, 279, 280, 281, 282, 283, 284, 286, 289, 293, 296, 297, 298, 299, 300, 305, 306, 309, 313, 316, 317, 318, 319, 320, 320, 323, 325, 326, 327, 333, 334, 335, 337, 338, 339, 340, 343, 345, 346, 347, 348, 350, 351, 352, 360, 362, 363, 365, 366, 367, 368, 371, 372, 374, 375, 376, 377, 379, 381, 386, 387, 388, 389, 391, 394, 395, 396, 401, 402, 403, 404, 405, 406, 407, 407, 410, 412, 413, 414, 415, 421, 422, 423, 424, 425, 426, 429, 431, 432, 440, 441, 442, 447, 448, 453, 454, 457, 462, 463, 464, 465, 467, 470, 474, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 497, 498, 499, 502, 504, 505, 512, 513, 514, 515, 516, 522, 527, 528, 529, 530, 532, 535, 539, 542, 543, 546, 547, 550, 551, 552, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 573, 575, 576, 577, 578, 579, 581, 584, 585, 586, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 601, 602, 603, 605, 606, 607, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 622, 623, 624, 634, 637, 639, 640, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 664, 665, 666, 667, 668, 669, 674, 675, 678, 679, 680, 681, 682, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 699, 700, 701, 702, 703, 705, 706, 707, 708, 709, 710, 714, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 736, 737, 738, 739, 740, 741, 742, 743, 748, 749};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
resolveNp 0 18 223
assign 1 21 224
nextPeerGet 0 21 224
assign 1 22 225
typenameGet 0 22 225
assign 1 22 226
EMITGet 0 22 226
assign 1 22 227
equals 1 22 232
assign 1 23 233
nextAscendGet 0 23 233
assign 1 24 234
containedGet 0 24 234
assign 1 24 235
def 1 24 240
assign 1 24 241
containedGet 0 24 241
assign 1 24 242
lengthGet 0 24 242
assign 1 24 243
new 0 24 243
assign 1 24 244
greater 1 24 249
assign 1 0 250
assign 1 0 253
assign 1 0 257
assign 1 24 260
containedGet 0 24 260
assign 1 24 261
firstGet 0 24 261
assign 1 24 262
containedGet 0 24 262
assign 1 24 263
def 1 24 268
assign 1 0 269
assign 1 0 272
assign 1 0 276
assign 1 24 279
containedGet 0 24 279
assign 1 24 280
firstGet 0 24 280
assign 1 24 281
containedGet 0 24 281
assign 1 24 282
lengthGet 0 24 282
assign 1 24 283
new 0 24 283
assign 1 24 284
greater 1 24 284
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 24 296
secondGet 0 24 296
assign 1 24 297
containedGet 0 24 297
assign 1 24 298
lengthGet 0 24 298
assign 1 24 299
new 0 24 299
assign 1 24 300
greater 1 24 305
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 26 316
new 0 26 316
assign 1 27 317
containedGet 0 27 317
assign 1 27 318
firstGet 0 27 318
assign 1 27 319
containedGet 0 27 319
assign 1 27 320
iteratorGet 0 0 320
assign 1 27 323
hasNextGet 0 27 323
assign 1 27 325
nextGet 0 27 325
assign 1 29 326
heldGet 0 29 326
addValue 1 29 327
assign 1 31 333
new 0 31 333
delete 1 31 334
assign 1 32 335
new 0 32 335
assign 1 34 337
new 0 34 337
assign 1 35 338
secondGet 0 35 338
assign 1 35 339
containedGet 0 35 339
assign 1 35 340
iteratorGet 0 35 340
assign 1 35 343
hasNextGet 0 35 343
assign 1 36 345
nextGet 0 36 345
assign 1 37 346
typenameGet 0 37 346
assign 1 37 347
STRINGLGet 0 37 347
assign 1 37 348
equals 1 37 348
assign 1 38 350
heldGet 0 38 350
heldSet 1 38 351
assign 1 41 352
new 0 41 352
assign 1 45 360
not 0 45 360
delete 0 46 362
return 1 47 363
containedSet 1 49 365
assign 1 50 366
heldGet 0 50 366
assign 1 50 367
new 2 50 367
heldSet 1 50 368
delete 0 52 371
return 1 53 372
assign 1 56 374
scopeGet 0 56 374
assign 1 57 375
typenameGet 0 57 375
assign 1 57 376
METHODGet 0 57 376
assign 1 57 377
equals 1 57 377
assign 1 58 379
assign 1 61 381
def 1 61 386
delete 0 62 387
assign 1 63 388
heldGet 0 63 388
addEmit 1 63 389
return 1 66 391
assign 1 67 394
typenameGet 0 67 394
assign 1 67 395
IFEMITGet 0 67 395
assign 1 67 396
equals 1 67 401
assign 1 68 402
new 0 68 402
assign 1 69 403
new 0 69 403
assign 1 70 404
containedGet 0 70 404
assign 1 70 405
firstGet 0 70 405
assign 1 70 406
containedGet 0 70 406
assign 1 70 407
iteratorGet 0 0 407
assign 1 70 410
hasNextGet 0 70 410
assign 1 70 412
nextGet 0 70 412
assign 1 72 413
heldGet 0 72 413
addValue 1 72 414
addValue 1 73 415
assign 1 75 421
new 0 75 421
delete 1 75 422
assign 1 76 423
heldGet 0 76 423
assign 1 76 424
new 2 76 424
heldSet 1 76 425
assign 1 77 426
iteratorGet 0 77 426
assign 1 77 429
hasNextGet 0 77 429
assign 1 78 431
nextGet 0 78 431
delete 0 79 432
assign 1 81 440
typenameGet 0 81 440
assign 1 81 441
IFGet 0 81 441
assign 1 81 442
equals 1 81 447
assign 1 82 448
def 1 82 453
assign 1 83 454
assign 1 84 457
def 1 84 462
assign 1 84 463
typenameGet 0 84 463
assign 1 84 464
ELIFGet 0 84 464
assign 1 84 465
equals 1 84 465
assign 1 0 467
assign 1 0 470
assign 1 0 474
assign 1 85 477
new 1 85 477
assign 1 86 478
ELSEGet 0 86 478
typenameSet 1 86 479
copyLoc 1 87 480
assign 1 88 481
new 1 88 481
copyLoc 1 89 482
assign 1 90 483
BRACESGet 0 90 483
typenameSet 1 90 484
assign 1 91 485
new 1 91 485
copyLoc 1 92 486
assign 1 93 487
IFGet 0 93 487
typenameSet 1 93 488
addValue 1 94 489
addValue 1 95 490
assign 1 96 491
containedGet 0 96 491
assign 1 96 492
def 1 96 497
assign 1 97 498
containedGet 0 97 498
assign 1 97 499
iteratorGet 0 97 499
assign 1 97 502
hasNextGet 0 97 502
assign 1 98 504
nextGet 0 98 504
addValue 1 98 505
addValue 1 105 512
assign 1 106 513
assign 1 107 514
nextPeerGet 0 107 514
delete 0 108 515
assign 1 109 516
assign 1 111 522
def 1 111 527
assign 1 111 528
typenameGet 0 111 528
assign 1 111 529
ELSEGet 0 111 529
assign 1 111 530
equals 1 111 530
assign 1 0 532
assign 1 0 535
assign 1 0 539
delete 0 112 542
addValue 1 113 543
assign 1 116 546
nextDescendGet 0 116 546
return 1 116 547
assign 1 117 550
typenameGet 0 117 550
assign 1 117 551
METHODGet 0 117 551
assign 1 117 552
equals 1 117 557
assign 1 118 558
containedGet 0 118 558
assign 1 118 559
firstGet 0 118 559
assign 1 119 560
new 1 119 560
copyLoc 1 120 561
assign 1 121 562
IDGet 0 121 562
typenameSet 1 121 563
assign 1 122 564
new 0 122 564
heldSet 1 122 565
prepend 1 123 566
assign 1 124 567
new 0 124 567
assign 1 125 568
new 0 125 568
assign 1 126 569
containedGet 0 126 569
assign 1 126 570
iteratorGet 0 126 570
assign 1 126 573
hasNextGet 0 126 573
assign 1 127 575
nextGet 0 127 575
assign 1 128 576
nextPeerGet 0 128 576
assign 1 131 577
typenameGet 0 131 577
assign 1 131 578
COMMAGet 0 131 578
assign 1 131 579
equals 1 131 579
addValue 1 132 581
assign 1 133 584
typenameGet 0 133 584
assign 1 133 585
IDGet 0 133 585
assign 1 133 586
equals 1 133 586
assign 1 134 588
new 0 134 588
assign 1 134 589
add 1 134 589
assign 1 135 590
new 0 135 590
assign 1 136 591
heldGet 0 136 591
nameSet 1 136 592
assign 1 137 593
new 0 137 593
isArgSet 1 137 594
heldSet 1 138 595
assign 1 139 596
VARGet 0 139 596
typenameSet 1 139 597
addVariable 0 140 598
assign 1 141 601
typenameGet 0 141 601
assign 1 141 602
VARGet 0 141 602
assign 1 141 603
equals 1 141 603
assign 1 142 605
typenameGet 0 142 605
assign 1 142 606
IDGet 0 142 606
assign 1 142 607
equals 1 142 607
assign 1 143 609
new 0 143 609
assign 1 143 610
add 1 143 610
assign 1 144 611
heldGet 0 144 611
assign 1 144 612
heldGet 0 144 612
nameSet 1 144 613
assign 1 145 614
heldGet 0 145 614
assign 1 145 615
new 0 145 615
isArgSet 1 145 616
addVariable 0 146 617
assign 1 147 618
COMMAGet 0 147 618
typenameSet 1 147 619
assign 1 149 622
new 0 149 622
assign 1 149 623
new 2 149 623
throw 1 149 624
assign 1 153 634
iteratorGet 0 153 634
assign 1 153 637
hasNextGet 0 153 637
assign 1 154 639
nextGet 0 154 639
delete 0 155 640
assign 1 157 646
heldGet 0 157 646
assign 1 158 647
new 0 158 647
assign 1 158 648
subtract 1 158 648
numargsSet 1 158 649
assign 1 159 650
nameGet 0 159 650
orgNameSet 1 159 651
assign 1 160 652
nameGet 0 160 652
assign 1 160 653
new 0 160 653
assign 1 160 654
add 1 160 654
assign 1 160 655
numargsGet 0 160 655
assign 1 160 656
toString 0 160 656
assign 1 160 657
add 1 160 657
nameSet 1 160 658
assign 1 161 659
secondGet 0 161 659
assign 1 162 660
typenameGet 0 162 660
assign 1 162 661
VARGet 0 162 661
assign 1 162 662
equals 1 162 662
resolveNp 0 163 664
assign 1 165 665
heldGet 0 165 665
rtypeSet 1 165 666
assign 1 166 667
rtypeGet 0 166 667
assign 1 166 668
namepathGet 0 166 668
assign 1 166 669
undef 1 166 674
rtypeSet 1 168 675
assign 1 169 678
rtypeGet 0 169 678
assign 1 169 679
namepathGet 0 169 679
assign 1 169 680
toString 0 169 680
assign 1 169 681
new 0 169 681
assign 1 169 682
equals 1 169 682
assign 1 171 684
rtypeGet 0 171 684
assign 1 171 685
new 0 171 685
isTypedSet 1 171 686
assign 1 172 687
rtypeGet 0 172 687
assign 1 172 688
new 0 172 688
isSelfSet 1 172 689
assign 1 173 690
rtypeGet 0 173 690
assign 1 173 691
new 0 173 691
isThisSet 1 173 692
assign 1 174 693
rtypeGet 0 174 693
assign 1 174 694
namepathGet 0 174 694
assign 1 174 695
new 0 174 695
pathSet 1 174 696
assign 1 175 699
rtypeGet 0 175 699
assign 1 175 700
namepathGet 0 175 700
assign 1 175 701
toString 0 175 701
assign 1 175 702
new 0 175 702
assign 1 175 703
equals 1 175 703
assign 1 176 705
rtypeGet 0 176 705
assign 1 176 706
new 0 176 706
isTypedSet 1 176 707
assign 1 177 708
rtypeGet 0 177 708
assign 1 177 709
new 0 177 709
isSelfSet 1 177 710
delete 0 179 714
assign 1 181 717
new 0 181 717
rtypeSet 1 181 718
assign 1 182 719
rtypeGet 0 182 719
assign 1 182 720
new 0 182 720
isTypedSet 1 182 721
assign 1 183 722
rtypeGet 0 183 722
assign 1 183 723
new 0 183 723
isSelfSet 1 183 724
assign 1 184 725
rtypeGet 0 184 725
assign 1 184 726
new 0 184 726
isThisSet 1 184 727
assign 1 185 728
rtypeGet 0 185 728
assign 1 185 729
new 0 185 729
impliedSet 1 185 730
assign 1 186 731
rtypeGet 0 186 731
assign 1 186 732
new 0 186 732
assign 1 186 733
new 1 186 733
namepathSet 1 186 734
assign 1 188 736
classGet 0 188 736
assign 1 189 737
heldGet 0 189 737
assign 1 189 738
methodsGet 0 189 738
assign 1 189 739
nameGet 0 189 739
put 2 189 740
assign 1 190 741
heldGet 0 190 741
assign 1 190 742
orderedMethodsGet 0 190 742
addValue 1 190 743
assign 1 192 748
nextDescendGet 0 192 748
return 1 192 749
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -835557872: return bem_tagGet_0();
case 1288158584: return bem_constGetDirect_0();
case -1264037424: return bem_copy_0();
case -1833113172: return bem_serializationIteratorGet_0();
case 1913293650: return bem_constGet_0();
case -1789612391: return bem_fieldIteratorGet_0();
case 564794586: return bem_ntypesGet_0();
case 466996177: return bem_buildGetDirect_0();
case -2028995013: return bem_new_0();
case 28192138: return bem_serializeContents_0();
case -1180336274: return bem_iteratorGet_0();
case -630058369: return bem_buildGet_0();
case 1367151409: return bem_ntypesGetDirect_0();
case -1873931192: return bem_print_0();
case -1474366991: return bem_many_0();
case -2111591272: return bem_sourceFileNameGet_0();
case 15292588: return bem_serializeToString_0();
case 1266624801: return bem_hashGet_0();
case 83573654: return bem_toString_0();
case 486036595: return bem_once_0();
case 1600753962: return bem_toAny_0();
case 235626099: return bem_transGet_0();
case 610604781: return bem_echo_0();
case 2089347046: return bem_classNameGet_0();
case -1199667015: return bem_transGetDirect_0();
case 486198208: return bem_fieldNamesGet_0();
case -1005390218: return bem_deserializeClassNameGet_0();
case 1615388739: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1702750854: return bem_sameObject_1(bevd_0);
case -2096981964: return bem_transSet_1(bevd_0);
case -317025047: return bem_copyTo_1(bevd_0);
case 981626333: return bem_sameType_1(bevd_0);
case 572964893: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 720506728: return bem_end_1(bevd_0);
case 1634312519: return bem_begin_1(bevd_0);
case -1208980303: return bem_otherClass_1(bevd_0);
case 63361049: return bem_defined_1(bevd_0);
case -99128923: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -782460965: return bem_undef_1(bevd_0);
case -2129946342: return bem_ntypesSetDirect_1(bevd_0);
case -1374791728: return bem_otherType_1(bevd_0);
case -257313333: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2011440128: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 952474121: return bem_def_1(bevd_0);
case 1274450447: return bem_buildSetDirect_1(bevd_0);
case 2141890129: return bem_equals_1(bevd_0);
case -1482822102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1599766807: return bem_undefined_1(bevd_0);
case 1815836311: return bem_constSet_1(bevd_0);
case -348415642: return bem_notEquals_1(bevd_0);
case -239366557: return bem_transSetDirect_1(bevd_0);
case -1502477550: return bem_constSetDirect_1(bevd_0);
case -1305813490: return bem_buildSet_1(bevd_0);
case -1781088950: return bem_ntypesSet_1(bevd_0);
case 2034381311: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -454079439: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 861143274: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -260132007: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 749345524: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1277474521: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2028665645: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 455421503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass6_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass6_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst = (BEC_3_5_5_5_BuildVisitPass6) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;
}
}
