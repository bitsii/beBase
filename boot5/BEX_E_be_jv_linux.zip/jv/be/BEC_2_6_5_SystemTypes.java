package be;
/* IO:File: source/base/Types.be */
public final class BEC_2_6_5_SystemTypes extends BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemTypes() { }
private static byte[] becc_BEC_2_6_5_SystemTypes_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_6_5_SystemTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_inst;

public static BET_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_type;

public BEC_2_6_5_SystemTypes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_default_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_fieldNames_1(BEC_2_6_6_SystemObject beva_org) throws Throwable {
BEC_2_9_4_ContainerList bevl_names = null;
bevl_names = (new BEC_2_9_4_ContainerList()).bem_new_0();

     BETS_Object bevs_cano = beva_org.bemc_getType();
     String[] fnames = bevs_cano.bevs_fieldNames;

     for (int i = 0;i < fnames.length;i++) {

       bevl_names.bem_addValue_1(new BEC_2_4_6_TextString(fnames[i].getBytes("UTF-8")));

     }
     return bevl_names;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameType_2(BEC_2_6_6_SystemObject beva_org, BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (beva_other != null && beva_other.getClass().isAssignableFrom(beva_org.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherType_2(BEC_2_6_6_SystemObject beva_org, BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sameType_2(beva_org, beva_other);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {19, 75, 124, 124, 128, 128, 128};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 29, 37, 38, 43, 44, 49};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 19 19
new 0 19 19
return 1 75 29
assign 1 124 37
new 0 124 37
return 1 124 38
assign 1 128 43
sameType 2 128 43
assign 1 128 44
not 0 128 49
return 1 128 49
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1424738458: return bem_print_0();
case -903358941: return bem_toString_0();
case -902820172: return bem_default_0();
case -1639054862: return bem_hashGet_0();
case 743152734: return bem_create_0();
case 1242460733: return bem_new_0();
case 812771584: return bem_iteratorGet_0();
case -176347951: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1686036436: return bem_undef_1(bevd_0);
case -941197725: return bem_equals_1(bevd_0);
case -149548840: return bem_def_1(bevd_0);
case 1864059490: return bem_notEquals_1(bevd_0);
case -893961213: return bem_copyTo_1(bevd_0);
case 243497526: return bem_fieldNames_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1551948487: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1906205864: return bem_otherType_2(bevd_0, bevd_1);
case 625211722: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1456032033: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -407446386: return bem_sameType_2(bevd_0, bevd_1);
case 217238601: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemTypes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_5_SystemTypes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_5_SystemTypes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst = (BEC_2_6_5_SystemTypes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_type;
}
}
