package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_5_SystemTypes extends BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemTypes() { }
private static byte[] becc_BEC_2_6_5_SystemTypes_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_6_5_SystemTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_inst;

public static BET_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_bool;
public BEC_2_4_5_MathFloat bevp_float;
public BEC_2_6_5_SystemThing bevp_thing;
public BEC_2_4_6_TextString bevp_string;
public BEC_2_4_6_TextString bevp_byteBuffer;
public BEC_2_6_5_SystemTypes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_default_0() throws Throwable {
bevp_int = (new BEC_2_4_3_MathInt());
bevp_bool = be.BECS_Runtime.boolFalse;
bevp_float = (new BEC_2_4_5_MathFloat()).bem_new_0();
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_string = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_byteBuffer = (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public final BEC_2_4_3_MathInt bem_intGetDirect_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGet_0() throws Throwable {
return bevp_bool;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_boolGetDirect_0() throws Throwable {
return bevp_bool;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_boolSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGet_0() throws Throwable {
return bevp_float;
} /*method end*/
public final BEC_2_4_5_MathFloat bem_floatGetDirect_0() throws Throwable {
return bevp_float;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_floatSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGet_0() throws Throwable {
return bevp_thing;
} /*method end*/
public final BEC_2_6_5_SystemThing bem_thingGetDirect_0() throws Throwable {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGet_0() throws Throwable {
return bevp_string;
} /*method end*/
public final BEC_2_4_6_TextString bem_stringGetDirect_0() throws Throwable {
return bevp_string;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_string = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_stringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_string = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGet_0() throws Throwable {
return bevp_byteBuffer;
} /*method end*/
public final BEC_2_4_6_TextString bem_byteBufferGetDirect_0() throws Throwable {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_5_SystemTypes bem_byteBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {42, 43, 44, 45, 46, 47, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 28, 32, 35, 38, 42, 46, 49, 52, 56, 60, 63, 66, 70, 74, 77, 80, 84, 88, 91, 94, 98, 102, 105, 108, 112};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 42 23
new 0 42 23
assign 1 43 24
new 0 43 24
assign 1 44 25
new 0 44 25
assign 1 45 26
new 0 45 26
assign 1 46 27
new 0 46 27
assign 1 47 28
new 0 47 28
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
return 1 0 74
return 1 0 77
assign 1 0 80
assign 1 0 84
return 1 0 88
return 1 0 91
assign 1 0 94
assign 1 0 98
return 1 0 102
return 1 0 105
assign 1 0 108
assign 1 0 112
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1889785591: return bem_stringGet_0();
case -665649433: return bem_serializeContents_0();
case 378307569: return bem_copy_0();
case 636328392: return bem_thingGet_0();
case 1777587047: return bem_hashGet_0();
case -1455899172: return bem_create_0();
case 1197171511: return bem_intGet_0();
case 1688345906: return bem_byteBufferGet_0();
case -1724453868: return bem_serializeToString_0();
case 2011135674: return bem_iteratorGet_0();
case 1095297479: return bem_echo_0();
case 280712282: return bem_toString_0();
case 2029444086: return bem_floatGet_0();
case -180175097: return bem_classNameGet_0();
case 1797865600: return bem_new_0();
case -119499799: return bem_serializationIteratorGet_0();
case 766881626: return bem_print_0();
case -2111162250: return bem_boolGetDirect_0();
case -1981096252: return bem_stringGetDirect_0();
case 1955915393: return bem_fieldNamesGet_0();
case 642366952: return bem_intGetDirect_0();
case 967234853: return bem_fieldIteratorGet_0();
case -533443118: return bem_many_0();
case -870415194: return bem_thingGetDirect_0();
case 1489021633: return bem_byteBufferGetDirect_0();
case 509361355: return bem_once_0();
case 959410209: return bem_floatGetDirect_0();
case 1948677431: return bem_boolGet_0();
case -194416815: return bem_tagGet_0();
case -1034571137: return bem_default_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case -1715766851: return bem_toAny_0();
case 617445256: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -445857610: return bem_notEquals_1(bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case -1543815630: return bem_boolSetDirect_1(bevd_0);
case 906320876: return bem_defined_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
case 928703793: return bem_boolSet_1(bevd_0);
case -406904980: return bem_intSetDirect_1(bevd_0);
case -517371740: return bem_stringSetDirect_1(bevd_0);
case -1881497375: return bem_byteBufferSet_1(bevd_0);
case 1196731065: return bem_byteBufferSetDirect_1(bevd_0);
case -1319063517: return bem_thingSet_1(bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1263321703: return bem_floatSet_1(bevd_0);
case -408835075: return bem_thingSetDirect_1(bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case 333647938: return bem_stringSet_1(bevd_0);
case -902246161: return bem_floatSetDirect_1(bevd_0);
case -647767314: return bem_intSet_1(bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemTypes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_5_SystemTypes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_5_SystemTypes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst = (BEC_2_6_5_SystemTypes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_type;
}
}
