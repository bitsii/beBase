package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_7_8_ReplaceCallStep extends BEC_2_6_6_SystemObject {
public BEC_2_7_8_ReplaceCallStep() { }
private static byte[] becc_BEC_2_7_8_ReplaceCallStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x43,0x61,0x6C,0x6C,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_8_ReplaceCallStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_7_8_ReplaceCallStep_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_7_8_ReplaceCallStep_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_7_8_ReplaceCallStep bece_BEC_2_7_8_ReplaceCallStep_bevs_inst;

public static BET_2_7_8_ReplaceCallStep bece_BEC_2_7_8_ReplaceCallStep_bevs_type;

public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_callArgs;
public BEC_2_7_8_ReplaceCallStep bem_new_1(BEC_2_9_10_ContainerLinkedList beva_payloads) throws Throwable {
BEC_2_4_3_MathInt bevl_pi = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_callName = (BEC_2_4_6_TextString) beva_payloads.bem_get_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = beva_payloads.bem_lengthGet_0();
bevt_3_tmpany_phold = bece_BEC_2_7_8_ReplaceCallStep_bevo_0;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_subtract_1(bevt_3_tmpany_phold);
bevp_callArgs = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_tmpany_phold);
bevl_pi = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 24 */ {
bevt_5_tmpany_phold = beva_payloads.bem_lengthGet_0();
if (bevl_pi.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_7_tmpany_phold = bece_BEC_2_7_8_ReplaceCallStep_bevo_1;
bevt_6_tmpany_phold = bevl_pi.bem_subtract_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_payloads.bem_get_1(bevl_pi);
bevp_callArgs.bem_put_2(bevt_6_tmpany_phold, bevt_8_tmpany_phold);
bevl_pi = bevl_pi.bem_increment_0();
} /* Line: 24 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_r.bemd_2(686267336, bevp_callName, bevp_callArgs);
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_callNameGet_0() throws Throwable {
return bevp_callName;
} /*method end*/
public final BEC_2_4_6_TextString bem_callNameGetDirect_0() throws Throwable {
return bevp_callName;
} /*method end*/
public BEC_2_7_8_ReplaceCallStep bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_7_8_ReplaceCallStep bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_callArgsGet_0() throws Throwable {
return bevp_callArgs;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_callArgsGetDirect_0() throws Throwable {
return bevp_callArgs;
} /*method end*/
public BEC_2_7_8_ReplaceCallStep bem_callArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_7_8_ReplaceCallStep bem_callArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_callArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 20, 21, 21, 21, 21, 24, 24, 24, 24, 25, 25, 25, 25, 24, 31, 31, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 29, 30, 31, 32, 35, 36, 41, 42, 43, 44, 45, 46, 56, 57, 60, 63, 66, 70, 74, 77, 80, 84};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 26
new 0 20 26
assign 1 20 27
get 1 20 27
assign 1 21 28
lengthGet 0 21 28
assign 1 21 29
new 0 21 29
assign 1 21 30
subtract 1 21 30
assign 1 21 31
new 1 21 31
assign 1 24 32
new 0 24 32
assign 1 24 35
lengthGet 0 24 35
assign 1 24 36
lesser 1 24 41
assign 1 25 42
new 0 25 42
assign 1 25 43
subtract 1 25 43
assign 1 25 44
get 1 25 44
put 2 25 45
assign 1 24 46
increment 0 24 46
assign 1 31 56
invoke 2 31 56
return 1 31 57
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
return 1 0 74
return 1 0 77
assign 1 0 80
assign 1 0 84
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -162465408: return bem_classNameGet_0();
case 1276060513: return bem_callArgsGet_0();
case -1118611827: return bem_copy_0();
case 1279728583: return bem_callNameGetDirect_0();
case 216387563: return bem_many_0();
case 1901482140: return bem_tagGet_0();
case -702348589: return bem_toString_0();
case -275244597: return bem_hashGet_0();
case 1899370103: return bem_echo_0();
case -2036889336: return bem_toAny_0();
case -1528945516: return bem_fieldNamesGet_0();
case -1653065356: return bem_serializeToString_0();
case -1009286812: return bem_iteratorGet_0();
case 1555639231: return bem_print_0();
case 1664099551: return bem_callArgsGetDirect_0();
case -1774143633: return bem_once_0();
case -2101622436: return bem_sourceFileNameGet_0();
case -138934452: return bem_serializationIteratorGet_0();
case -826924838: return bem_fieldIteratorGet_0();
case 357618761: return bem_new_0();
case -716934857: return bem_serializeContents_0();
case -972328892: return bem_callNameGet_0();
case 1881523822: return bem_deserializeClassNameGet_0();
case 71860751: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 814727407: return bem_notEquals_1(bevd_0);
case -2130714868: return bem_equals_1(bevd_0);
case 66254795: return bem_sameType_1(bevd_0);
case -1493100314: return bem_otherClass_1(bevd_0);
case 1193778385: return bem_undefined_1(bevd_0);
case 1459678776: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1325575386: return bem_def_1(bevd_0);
case -1990683338: return bem_handle_1(bevd_0);
case -959745115: return bem_otherType_1(bevd_0);
case 564977847: return bem_callNameSet_1(bevd_0);
case 1510440723: return bem_callArgsSetDirect_1(bevd_0);
case 2082558825: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1082439894: return bem_sameObject_1(bevd_0);
case 1353620660: return bem_sameClass_1(bevd_0);
case -1339829082: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -626212611: return bem_callArgsSet_1(bevd_0);
case -68723535: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759126894: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -2109980302: return bem_undef_1(bevd_0);
case 2027670755: return bem_defined_1(bevd_0);
case -1751385288: return bem_callNameSetDirect_1(bevd_0);
case 1137403549: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 70790709: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020619337: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 163657925: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1186365239: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 686267336: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271558857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1157880701: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_7_8_ReplaceCallStep_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_8_ReplaceCallStep_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_7_8_ReplaceCallStep();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_inst = (BEC_2_7_8_ReplaceCallStep) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_type;
}
}
