package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_16_ContainerMapKeyValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_16_ContainerMapKeyValueIterator() { }
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4B,0x65,0x79,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;

public static BET_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bevp_onNode;
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_onNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 606 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 607 */
bevt_2_tmpany_phold = super.bem_hasNextGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_onNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 613 */ {
bevl_toRet = bevp_onNode.bemd_0(893861404);
bevp_onNode = null;
return bevl_toRet;
} /* Line: 616 */
bevp_onNode = super.bem_nextGet_0();
if (bevp_onNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 619 */ {
bevt_2_tmpany_phold = bevp_onNode.bemd_0(321140342);
return bevt_2_tmpany_phold;
} /* Line: 620 */
return bevp_onNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onNodeGet_0() throws Throwable {
return bevp_onNode;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_onNodeGetDirect_0() throws Throwable {
return bevp_onNode;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_onNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onNode = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_3_16_ContainerMapKeyValueIterator bem_onNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onNode = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {602, 606, 606, 607, 607, 609, 609, 613, 613, 614, 615, 616, 618, 619, 619, 620, 620, 622, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 20, 25, 26, 27, 29, 30, 37, 42, 43, 44, 45, 47, 48, 53, 54, 55, 57, 60, 63, 66, 70};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 602 13
assign 1 606 20
def 1 606 25
assign 1 607 26
new 0 607 26
return 1 607 27
assign 1 609 29
hasNextGet 0 609 29
return 1 609 30
assign 1 613 37
def 1 613 42
assign 1 614 43
valueGet 0 614 43
assign 1 615 44
return 1 616 45
assign 1 618 47
nextGet 0 618 47
assign 1 619 48
def 1 619 53
assign 1 620 54
keyGet 0 620 54
return 1 620 55
return 1 622 57
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1154985755: return bem_echo_0();
case 841207683: return bem_new_0();
case -564219457: return bem_containerGet_0();
case -1648763323: return bem_hasNextGet_0();
case -1661579204: return bem_nextGet_0();
case -1155411626: return bem_classNameGet_0();
case -513985458: return bem_once_0();
case -32688495: return bem_setGetDirect_0();
case -92748928: return bem_moduGetDirect_0();
case 944745844: return bem_iteratorGet_0();
case -225078823: return bem_serializationIteratorGet_0();
case -1197342813: return bem_slotsGetDirect_0();
case 232809271: return bem_copy_0();
case -1247813666: return bem_tagGet_0();
case -967525204: return bem_fieldNamesGet_0();
case -363767837: return bem_delete_0();
case -1158428247: return bem_currentGetDirect_0();
case 1835904283: return bem_fieldIteratorGet_0();
case 1885060316: return bem_onNodeGet_0();
case 434638295: return bem_onNodeGetDirect_0();
case 1115096156: return bem_currentGet_0();
case 745980876: return bem_serializeToString_0();
case 285074277: return bem_deserializeClassNameGet_0();
case -1890761825: return bem_hashGet_0();
case -858518329: return bem_many_0();
case -703952395: return bem_toAny_0();
case -1393580960: return bem_slotsGet_0();
case 1562045422: return bem_print_0();
case 1519244981: return bem_moduGet_0();
case 1592801927: return bem_serializeContents_0();
case 440740249: return bem_setGet_0();
case 863596927: return bem_sourceFileNameGet_0();
case -1845402369: return bem_create_0();
case -901997228: return bem_nodeIteratorIteratorGet_0();
case -1995804558: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 15825508: return bem_slotsSetDirect_1(bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1561897374: return bem_setSet_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1200297939: return bem_undef_1(bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 379497788: return bem_moduSet_1(bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
case 1953409061: return bem_onNodeSet_1(bevd_0);
case 531802368: return bem_moduSetDirect_1(bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
case -365196515: return bem_setSetDirect_1(bevd_0);
case 1085049356: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 12031225: return bem_def_1(bevd_0);
case -1815546435: return bem_copyTo_1(bevd_0);
case 761512572: return bem_slotsSet_1(bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
case -843186096: return bem_onNodeSetDirect_1(bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
case -2034557200: return bem_currentSetDirect_1(bevd_0);
case 490954609: return bem_currentSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_16_ContainerMapKeyValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst = (BEC_3_9_3_16_ContainerMapKeyValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;
}
}
