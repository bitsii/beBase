package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_16_ContainerMapKeyValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_16_ContainerMapKeyValueIterator() { }
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4B,0x65,0x79,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;

public static BET_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bevp_onNode;
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_onNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 572*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 573*/
bevt_2_ta_ph = super.bem_hasNextGet_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_onNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 579*/ {
bevl_toRet = bevp_onNode.bemd_0(-1447182790);
bevp_onNode = null;
return bevl_toRet;
} /* Line: 582*/
bevp_onNode = super.bem_nextGet_0();
if (bevp_onNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 585*/ {
bevt_2_ta_ph = bevp_onNode.bemd_0(-535554962);
return bevt_2_ta_ph;
} /* Line: 586*/
return bevp_onNode;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {568, 572, 572, 573, 573, 575, 575, 579, 579, 580, 581, 582, 584, 585, 585, 586, 586, 588};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 20, 25, 26, 27, 29, 30, 37, 42, 43, 44, 45, 47, 48, 53, 54, 55, 57};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 568 13
assign 1 572 20
def 1 572 25
assign 1 573 26
new 0 573 26
return 1 573 27
assign 1 575 29
hasNextGet 0 575 29
return 1 575 30
assign 1 579 37
def 1 579 42
assign 1 580 43
valueGet 0 580 43
assign 1 581 44
return 1 582 45
assign 1 584 47
nextGet 0 584 47
assign 1 585 48
def 1 585 53
assign 1 586 54
keyGet 0 586 54
return 1 586 55
return 1 588 57
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1104558808: return bem_hashGet_0();
case 1185540775: return bem_containerGet_0();
case -2110630561: return bem_nextGet_0();
case 300385203: return bem_toString_0();
case 1106770102: return bem_iteratorGet_0();
case 949701: return bem_print_0();
case 1569412621: return bem_create_0();
case -972501329: return bem_delete_0();
case 1211194663: return bem_new_0();
case 1765286468: return bem_hasNextGet_0();
case -1658389024: return bem_nodeIteratorIteratorGet_0();
case 577809605: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -756175634: return bem_undef_1(bevd_0);
case 1215096844: return bem_def_1(bevd_0);
case 326054246: return bem_notEquals_1(bevd_0);
case -1650199959: return bem_copyTo_1(bevd_0);
case 1234014821: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1016133256: return bem_equals_1(bevd_0);
case -1230932201: return bem_print_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1847725704: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1753230616: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -753455512: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1204159569: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_16_ContainerMapKeyValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst = (BEC_3_9_3_16_ContainerMapKeyValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;
}
}
