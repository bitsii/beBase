package be;
/* IO:File: source/build/CEmitter.be */
public final class BEC_2_5_9_BuildClassInfo extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildClassInfo() { }
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_0, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_1, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_2 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_2, 1));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_4, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_5 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_5, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_6 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_6, 11));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_7 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_4, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_8 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_8, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_9 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_9, 16));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_10 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_10, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_11 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_11, 16));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_12, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_13 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_13, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_14 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_14, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_15 = {0x42,0x45,0x58,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_15, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_16 = {0x42,0x45,0x4B,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_16, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_17 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_18 = {0x2E,0x6D,0x61,0x6B,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_18, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_19 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_19, 4));
public static BEC_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_inst;

public static BET_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_15_BuildCompilerProfile bevp_cpro;
public BEC_2_5_8_BuildNamePath bevp_npar;
public BEC_2_6_6_SystemObject bevp_nparSteps;
public BEC_2_4_6_TextString bevp_clName;
public BEC_2_4_6_TextString bevp_clBase;
public BEC_2_4_6_TextString bevp_midName;
public BEC_2_4_6_TextString bevp_incBlock;
public BEC_2_4_6_TextString bevp_mtdName;
public BEC_2_4_6_TextString bevp_cldefName;
public BEC_2_4_6_TextString bevp_shClassName;
public BEC_2_4_6_TextString bevp_shFileName;
public BEC_2_4_6_TextString bevp_cldefBuild;
public BEC_2_4_6_TextString bevp_libnameInit;
public BEC_2_4_6_TextString bevp_libnameInitDone;
public BEC_2_4_6_TextString bevp_libnameData;
public BEC_2_4_6_TextString bevp_libnameDataDone;
public BEC_2_4_6_TextString bevp_libnameDataClear;
public BEC_2_4_6_TextString bevp_libNotNullInit;
public BEC_2_4_6_TextString bevp_libNotNullInitDone;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_cuBase;
public BEC_3_2_4_4_IOFilePath bevp_nsDir;
public BEC_2_4_6_TextString bevp_xbase;
public BEC_2_4_6_TextString bevp_lbase;
public BEC_2_4_6_TextString bevp_nbase;
public BEC_2_4_6_TextString bevp_kbase;
public BEC_3_2_4_4_IOFilePath bevp_cuinitH;
public BEC_2_4_6_TextString bevp_namesIncH;
public BEC_3_2_4_4_IOFilePath bevp_cuinit;
public BEC_3_2_4_4_IOFilePath bevp_namesO;
public BEC_3_2_4_4_IOFilePath bevp_unitShlib;
public BEC_3_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_3_2_4_4_IOFilePath bevp_unitExe;
public BEC_3_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classExeO;
public BEC_3_2_4_4_IOFilePath bevp_makeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrcH;
public BEC_3_2_4_4_IOFilePath bevp_classIncH;
public BEC_3_2_4_4_IOFilePath bevp_classO;
public BEC_3_2_4_4_IOFilePath bevp_synSrc;
public BEC_2_5_9_BuildClassInfo bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_new_5(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) throws Throwable {
BEC_2_4_6_TextString bevl_cext = null;
BEC_2_4_6_TextString bevl_oext = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_tmpany_phold = bevp_emitter.bemd_0(139560394);
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_phold.bemd_0(1005298512);
bevp_npar = (BEC_2_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_tmpany_phold = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lastGet_0();
bevp_midName = (BEC_2_4_6_TextString) bevp_emitter.bemd_2(-1381722322, beva__libName, beva__np);
bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_0;
bevp_incBlock = bevt_2_tmpany_phold.bem_add_1(bevp_midName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevp_midName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_2;
bevp_mtdName = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_3;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_midName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_4;
bevp_cldefName = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_5;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_midName);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_6;
bevp_shClassName = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_7;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_midName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_8;
bevp_shFileName = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_9;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevp_midName);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_10;
bevp_cldefBuild = bevt_15_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_11;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevp_midName);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_12;
bevp_libnameInit = bevt_18_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_13;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevp_midName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_14;
bevp_libnameInitDone = bevt_21_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_15;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevp_midName);
bevt_26_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_16;
bevp_libnameData = bevt_24_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_17;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevp_midName);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_18;
bevp_libnameDataDone = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_19;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevp_midName);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_20;
bevp_libnameDataClear = bevt_30_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_21;
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevp_midName);
bevt_35_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_22;
bevp_libNotNullInit = bevt_33_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_23;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_midName);
bevt_38_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_24;
bevp_libNotNullInitDone = bevt_36_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = beva__emitPath.bem_copy_0();
bevt_39_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_25;
bevp_xbase = bevt_39_tmpany_phold.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_26;
bevp_kbase = bevt_40_tmpany_phold.bem_add_1(bevp_clBase);
bevt_41_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_27;
bevt_42_tmpany_phold = bevp_nbase.bem_add_1(bevt_43_tmpany_phold);
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_41_tmpany_phold.bem_addStep_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_28;
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_46_tmpany_phold = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_45_tmpany_phold.bem_addStep_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_48_tmpany_phold = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_47_tmpany_phold.bem_addStep_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_51_tmpany_phold = bevp_cpro.bem_libExtGet_0();
bevt_50_tmpany_phold = bevp_lbase.bem_add_1(bevt_51_tmpany_phold);
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_49_tmpany_phold.bem_addStep_1(bevt_50_tmpany_phold);
bevt_52_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_54_tmpany_phold = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_tmpany_phold = bevp_lbase.bem_add_1(bevt_54_tmpany_phold);
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_52_tmpany_phold.bem_addStep_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = bevp_cuBase.bem_copy_0();
bevt_57_tmpany_phold = bevp_cpro.bem_exeExtGet_0();
bevt_56_tmpany_phold = beva__exeName.bem_add_1(bevt_57_tmpany_phold);
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_55_tmpany_phold.bem_addStep_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_59_tmpany_phold = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_58_tmpany_phold.bem_addStep_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_61_tmpany_phold = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_60_tmpany_phold.bem_addStep_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_64_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_29;
bevt_63_tmpany_phold = bevp_xbase.bem_add_1(bevt_64_tmpany_phold);
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_62_tmpany_phold.bem_addStep_1(bevt_63_tmpany_phold);
bevt_65_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_66_tmpany_phold = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_65_tmpany_phold.bem_addStep_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_69_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_30;
bevt_68_tmpany_phold = bevp_kbase.bem_add_1(bevt_69_tmpany_phold);
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_67_tmpany_phold.bem_addStep_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = bevp_nsDir.bem_copy_0();
bevt_72_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_31;
bevt_71_tmpany_phold = bevp_kbase.bem_add_1(bevt_72_tmpany_phold);
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_70_tmpany_phold.bem_addStep_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_74_tmpany_phold = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_73_tmpany_phold.bem_addStep_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = bevp_basePath.bem_copy_0();
bevt_77_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_32;
bevt_76_tmpany_phold = bevp_kbase.bem_add_1(bevt_77_tmpany_phold);
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_75_tmpany_phold.bem_addStep_1(bevt_76_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirDo_1(BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(944745844);
while (true)
 /* Line: 110 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(-1648763323);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 110 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(-1661579204);
bevp_nsDir.bem_addStep_1(bevt_1_tmpany_phold);
} /* Line: 111 */
 else  /* Line: 110 */ {
break;
} /* Line: 110 */
} /* Line: 110 */
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_npGetDirect_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGet_0() throws Throwable {
return bevp_cpro;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_cproGetDirect_0() throws Throwable {
return bevp_cpro;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cproSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGet_0() throws Throwable {
return bevp_npar;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_nparGetDirect_0() throws Throwable {
return bevp_npar;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nparSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGet_0() throws Throwable {
return bevp_nparSteps;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_nparStepsGetDirect_0() throws Throwable {
return bevp_nparSteps;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nparSteps = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nparStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nparSteps = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGet_0() throws Throwable {
return bevp_clName;
} /*method end*/
public final BEC_2_4_6_TextString bem_clNameGetDirect_0() throws Throwable {
return bevp_clName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_clNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGet_0() throws Throwable {
return bevp_clBase;
} /*method end*/
public final BEC_2_4_6_TextString bem_clBaseGetDirect_0() throws Throwable {
return bevp_clBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_clBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGet_0() throws Throwable {
return bevp_midName;
} /*method end*/
public final BEC_2_4_6_TextString bem_midNameGetDirect_0() throws Throwable {
return bevp_midName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_midNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGet_0() throws Throwable {
return bevp_incBlock;
} /*method end*/
public final BEC_2_4_6_TextString bem_incBlockGetDirect_0() throws Throwable {
return bevp_incBlock;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_incBlockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGet_0() throws Throwable {
return bevp_mtdName;
} /*method end*/
public final BEC_2_4_6_TextString bem_mtdNameGetDirect_0() throws Throwable {
return bevp_mtdName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_mtdNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGet_0() throws Throwable {
return bevp_cldefName;
} /*method end*/
public final BEC_2_4_6_TextString bem_cldefNameGetDirect_0() throws Throwable {
return bevp_cldefName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cldefNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGet_0() throws Throwable {
return bevp_shClassName;
} /*method end*/
public final BEC_2_4_6_TextString bem_shClassNameGetDirect_0() throws Throwable {
return bevp_shClassName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_shClassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGet_0() throws Throwable {
return bevp_shFileName;
} /*method end*/
public final BEC_2_4_6_TextString bem_shFileNameGetDirect_0() throws Throwable {
return bevp_shFileName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_shFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGet_0() throws Throwable {
return bevp_cldefBuild;
} /*method end*/
public final BEC_2_4_6_TextString bem_cldefBuildGetDirect_0() throws Throwable {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cldefBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGet_0() throws Throwable {
return bevp_libnameInit;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameInitGetDirect_0() throws Throwable {
return bevp_libnameInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGet_0() throws Throwable {
return bevp_libnameInitDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameInitDoneGetDirect_0() throws Throwable {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGet_0() throws Throwable {
return bevp_libnameData;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataGetDirect_0() throws Throwable {
return bevp_libnameData;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGet_0() throws Throwable {
return bevp_libnameDataDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataDoneGetDirect_0() throws Throwable {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGet_0() throws Throwable {
return bevp_libnameDataClear;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataClearGetDirect_0() throws Throwable {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataClearSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGet_0() throws Throwable {
return bevp_libNotNullInit;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNotNullInitGetDirect_0() throws Throwable {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libNotNullInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGet_0() throws Throwable {
return bevp_libNotNullInitDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNotNullInitDoneGetDirect_0() throws Throwable {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_basePathGetDirect_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_basePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGet_0() throws Throwable {
return bevp_cuBase;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuBaseGetDirect_0() throws Throwable {
return bevp_cuBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGet_0() throws Throwable {
return bevp_nsDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_nsDirGetDirect_0() throws Throwable {
return bevp_nsDir;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nsDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGet_0() throws Throwable {
return bevp_xbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_xbaseGetDirect_0() throws Throwable {
return bevp_xbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_xbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGet_0() throws Throwable {
return bevp_lbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_lbaseGetDirect_0() throws Throwable {
return bevp_lbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_lbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGet_0() throws Throwable {
return bevp_nbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_nbaseGetDirect_0() throws Throwable {
return bevp_nbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGet_0() throws Throwable {
return bevp_kbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_kbaseGetDirect_0() throws Throwable {
return bevp_kbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_kbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGet_0() throws Throwable {
return bevp_cuinitH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuinitHGetDirect_0() throws Throwable {
return bevp_cuinitH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuinitHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGet_0() throws Throwable {
return bevp_namesIncH;
} /*method end*/
public final BEC_2_4_6_TextString bem_namesIncHGetDirect_0() throws Throwable {
return bevp_namesIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_namesIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGet_0() throws Throwable {
return bevp_cuinit;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuinitGetDirect_0() throws Throwable {
return bevp_cuinit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuinitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGet_0() throws Throwable {
return bevp_namesO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_namesOGetDirect_0() throws Throwable {
return bevp_namesO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_namesOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGet_0() throws Throwable {
return bevp_unitShlib;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitShlibGetDirect_0() throws Throwable {
return bevp_unitShlib;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitShlibSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGet_0() throws Throwable {
return bevp_unitExeLink;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitExeLinkGetDirect_0() throws Throwable {
return bevp_unitExeLink;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitExeLinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGet_0() throws Throwable {
return bevp_unitExe;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitExeGetDirect_0() throws Throwable {
return bevp_unitExe;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitExeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGet_0() throws Throwable {
return bevp_classExeSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classExeSrcGetDirect_0() throws Throwable {
return bevp_classExeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classExeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGet_0() throws Throwable {
return bevp_classExeO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classExeOGetDirect_0() throws Throwable {
return bevp_classExeO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classExeOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGet_0() throws Throwable {
return bevp_makeSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_makeSrcGetDirect_0() throws Throwable {
return bevp_makeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_makeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGet_0() throws Throwable {
return bevp_classSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classSrcGetDirect_0() throws Throwable {
return bevp_classSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGet_0() throws Throwable {
return bevp_classSrcH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classSrcHGetDirect_0() throws Throwable {
return bevp_classSrcH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classSrcHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGet_0() throws Throwable {
return bevp_classIncH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classIncHGetDirect_0() throws Throwable {
return bevp_classIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGet_0() throws Throwable {
return bevp_classO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classOGetDirect_0() throws Throwable {
return bevp_classO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGet_0() throws Throwable {
return bevp_synSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_synSrcGetDirect_0() throws Throwable {
return bevp_synSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_synSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 27, 28, 29, 29, 30, 31, 32, 34, 34, 36, 38, 39, 40, 43, 43, 45, 45, 45, 45, 47, 47, 47, 47, 49, 49, 49, 49, 51, 51, 51, 51, 53, 53, 53, 53, 55, 55, 55, 55, 57, 57, 57, 57, 59, 59, 59, 59, 61, 61, 61, 61, 63, 63, 63, 63, 65, 65, 65, 65, 66, 66, 66, 66, 68, 70, 71, 74, 74, 75, 76, 77, 77, 79, 79, 79, 79, 80, 80, 81, 81, 81, 82, 82, 82, 86, 86, 86, 86, 87, 87, 87, 87, 88, 88, 88, 88, 90, 90, 90, 91, 91, 91, 92, 92, 92, 92, 94, 94, 94, 95, 95, 95, 95, 96, 96, 96, 96, 97, 97, 97, 98, 98, 98, 98, 108, 109, 110, 110, 111, 111, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {109, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 323, 324, 325, 328, 330, 331, 340, 343, 346, 350, 354, 357, 360, 364, 368, 371, 374, 378, 382, 385, 388, 392, 396, 399, 402, 406, 410, 413, 416, 420, 424, 427, 430, 434, 438, 441, 444, 448, 452, 455, 458, 462, 466, 469, 472, 476, 480, 483, 486, 490, 494, 497, 500, 504, 508, 511, 514, 518, 522, 525, 528, 532, 536, 539, 542, 546, 550, 553, 556, 560, 564, 567, 570, 574, 578, 581, 584, 588, 592, 595, 598, 602, 606, 609, 612, 616, 620, 623, 626, 630, 634, 637, 640, 644, 648, 651, 654, 658, 662, 665, 668, 672, 676, 679, 682, 686, 690, 693, 696, 700, 704, 707, 710, 714, 718, 721, 724, 728, 732, 735, 738, 742, 746, 749, 752, 756, 760, 763, 766, 770, 774, 777, 780, 784, 788, 791, 794, 798, 802, 805, 808, 812, 816, 819, 822, 826, 830, 833, 836, 840, 844, 847, 850, 854, 858, 861, 864, 868, 872, 875, 878, 882, 886, 889, 892, 896, 900, 903, 906, 910, 914, 917, 920, 924, 928, 931, 934, 938, 942, 945, 948, 952};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 5 20 109
assign 1 27 193
assign 1 28 194
assign 1 29 195
buildGet 0 29 195
assign 1 29 196
compilerProfileGet 0 29 196
assign 1 30 197
parentGet 0 30 197
assign 1 31 198
stepsGet 0 31 198
assign 1 32 199
toString 0 32 199
assign 1 34 200
stepsGet 0 34 200
assign 1 34 201
lastGet 0 34 201
assign 1 36 202
midNameDo 2 36 202
nsDirDo 1 38 203
assign 1 39 204
cextGet 0 39 204
assign 1 40 205
oextGet 0 40 205
assign 1 43 206
new 0 43 206
assign 1 43 207
add 1 43 207
assign 1 45 208
new 0 45 208
assign 1 45 209
add 1 45 209
assign 1 45 210
new 0 45 210
assign 1 45 211
add 1 45 211
assign 1 47 212
new 0 47 212
assign 1 47 213
add 1 47 213
assign 1 47 214
new 0 47 214
assign 1 47 215
add 1 47 215
assign 1 49 216
new 0 49 216
assign 1 49 217
add 1 49 217
assign 1 49 218
new 0 49 218
assign 1 49 219
add 1 49 219
assign 1 51 220
new 0 51 220
assign 1 51 221
add 1 51 221
assign 1 51 222
new 0 51 222
assign 1 51 223
add 1 51 223
assign 1 53 224
new 0 53 224
assign 1 53 225
add 1 53 225
assign 1 53 226
new 0 53 226
assign 1 53 227
add 1 53 227
assign 1 55 228
new 0 55 228
assign 1 55 229
add 1 55 229
assign 1 55 230
new 0 55 230
assign 1 55 231
add 1 55 231
assign 1 57 232
new 0 57 232
assign 1 57 233
add 1 57 233
assign 1 57 234
new 0 57 234
assign 1 57 235
add 1 57 235
assign 1 59 236
new 0 59 236
assign 1 59 237
add 1 59 237
assign 1 59 238
new 0 59 238
assign 1 59 239
add 1 59 239
assign 1 61 240
new 0 61 240
assign 1 61 241
add 1 61 241
assign 1 61 242
new 0 61 242
assign 1 61 243
add 1 61 243
assign 1 63 244
new 0 63 244
assign 1 63 245
add 1 63 245
assign 1 63 246
new 0 63 246
assign 1 63 247
add 1 63 247
assign 1 65 248
new 0 65 248
assign 1 65 249
add 1 65 249
assign 1 65 250
new 0 65 250
assign 1 65 251
add 1 65 251
assign 1 66 252
new 0 66 252
assign 1 66 253
add 1 66 253
assign 1 66 254
new 0 66 254
assign 1 66 255
add 1 66 255
assign 1 68 256
assign 1 70 257
add 1 70 257
assign 1 71 258
copy 0 71 258
assign 1 74 259
new 0 74 259
assign 1 74 260
add 1 74 260
assign 1 75 261
assign 1 76 262
assign 1 77 263
new 0 77 263
assign 1 77 264
add 1 77 264
assign 1 79 265
copy 0 79 265
assign 1 79 266
new 0 79 266
assign 1 79 267
add 1 79 267
assign 1 79 268
addStep 1 79 268
assign 1 80 269
new 0 80 269
assign 1 80 270
add 1 80 270
assign 1 81 271
copy 0 81 271
assign 1 81 272
add 1 81 272
assign 1 81 273
addStep 1 81 273
assign 1 82 274
copy 0 82 274
assign 1 82 275
add 1 82 275
assign 1 82 276
addStep 1 82 276
assign 1 86 277
copy 0 86 277
assign 1 86 278
libExtGet 0 86 278
assign 1 86 279
add 1 86 279
assign 1 86 280
addStep 1 86 280
assign 1 87 281
copy 0 87 281
assign 1 87 282
exeLibExtGet 0 87 282
assign 1 87 283
add 1 87 283
assign 1 87 284
addStep 1 87 284
assign 1 88 285
copy 0 88 285
assign 1 88 286
exeExtGet 0 88 286
assign 1 88 287
add 1 88 287
assign 1 88 288
addStep 1 88 288
assign 1 90 289
copy 0 90 289
assign 1 90 290
add 1 90 290
assign 1 90 291
addStep 1 90 291
assign 1 91 292
copy 0 91 292
assign 1 91 293
add 1 91 293
assign 1 91 294
addStep 1 91 294
assign 1 92 295
copy 0 92 295
assign 1 92 296
new 0 92 296
assign 1 92 297
add 1 92 297
assign 1 92 298
addStep 1 92 298
assign 1 94 299
copy 0 94 299
assign 1 94 300
add 1 94 300
assign 1 94 301
addStep 1 94 301
assign 1 95 302
copy 0 95 302
assign 1 95 303
new 0 95 303
assign 1 95 304
add 1 95 304
assign 1 95 305
addStep 1 95 305
assign 1 96 306
copy 0 96 306
assign 1 96 307
new 0 96 307
assign 1 96 308
add 1 96 308
assign 1 96 309
addStep 1 96 309
assign 1 97 310
copy 0 97 310
assign 1 97 311
add 1 97 311
assign 1 97 312
addStep 1 97 312
assign 1 98 313
copy 0 98 313
assign 1 98 314
new 0 98 314
assign 1 98 315
add 1 98 315
assign 1 98 316
addStep 1 98 316
assign 1 108 323
new 0 108 323
addStep 1 109 324
assign 1 110 325
iteratorGet 0 110 325
assign 1 110 328
hasNextGet 0 110 328
assign 1 111 330
nextGet 0 111 330
addStep 1 111 331
return 1 0 340
return 1 0 343
assign 1 0 346
assign 1 0 350
return 1 0 354
return 1 0 357
assign 1 0 360
assign 1 0 364
return 1 0 368
return 1 0 371
assign 1 0 374
assign 1 0 378
return 1 0 382
return 1 0 385
assign 1 0 388
assign 1 0 392
return 1 0 396
return 1 0 399
assign 1 0 402
assign 1 0 406
return 1 0 410
return 1 0 413
assign 1 0 416
assign 1 0 420
return 1 0 424
return 1 0 427
assign 1 0 430
assign 1 0 434
return 1 0 438
return 1 0 441
assign 1 0 444
assign 1 0 448
return 1 0 452
return 1 0 455
assign 1 0 458
assign 1 0 462
return 1 0 466
return 1 0 469
assign 1 0 472
assign 1 0 476
return 1 0 480
return 1 0 483
assign 1 0 486
assign 1 0 490
return 1 0 494
return 1 0 497
assign 1 0 500
assign 1 0 504
return 1 0 508
return 1 0 511
assign 1 0 514
assign 1 0 518
return 1 0 522
return 1 0 525
assign 1 0 528
assign 1 0 532
return 1 0 536
return 1 0 539
assign 1 0 542
assign 1 0 546
return 1 0 550
return 1 0 553
assign 1 0 556
assign 1 0 560
return 1 0 564
return 1 0 567
assign 1 0 570
assign 1 0 574
return 1 0 578
return 1 0 581
assign 1 0 584
assign 1 0 588
return 1 0 592
return 1 0 595
assign 1 0 598
assign 1 0 602
return 1 0 606
return 1 0 609
assign 1 0 612
assign 1 0 616
return 1 0 620
return 1 0 623
assign 1 0 626
assign 1 0 630
return 1 0 634
return 1 0 637
assign 1 0 640
assign 1 0 644
return 1 0 648
return 1 0 651
assign 1 0 654
assign 1 0 658
return 1 0 662
return 1 0 665
assign 1 0 668
assign 1 0 672
return 1 0 676
return 1 0 679
assign 1 0 682
assign 1 0 686
return 1 0 690
return 1 0 693
assign 1 0 696
assign 1 0 700
return 1 0 704
return 1 0 707
assign 1 0 710
assign 1 0 714
return 1 0 718
return 1 0 721
assign 1 0 724
assign 1 0 728
return 1 0 732
return 1 0 735
assign 1 0 738
assign 1 0 742
return 1 0 746
return 1 0 749
assign 1 0 752
assign 1 0 756
return 1 0 760
return 1 0 763
assign 1 0 766
assign 1 0 770
return 1 0 774
return 1 0 777
assign 1 0 780
assign 1 0 784
return 1 0 788
return 1 0 791
assign 1 0 794
assign 1 0 798
return 1 0 802
return 1 0 805
assign 1 0 808
assign 1 0 812
return 1 0 816
return 1 0 819
assign 1 0 822
assign 1 0 826
return 1 0 830
return 1 0 833
assign 1 0 836
assign 1 0 840
return 1 0 844
return 1 0 847
assign 1 0 850
assign 1 0 854
return 1 0 858
return 1 0 861
assign 1 0 864
assign 1 0 868
return 1 0 872
return 1 0 875
assign 1 0 878
assign 1 0 882
return 1 0 886
return 1 0 889
assign 1 0 892
assign 1 0 896
return 1 0 900
return 1 0 903
assign 1 0 906
assign 1 0 910
return 1 0 914
return 1 0 917
assign 1 0 920
assign 1 0 924
return 1 0 928
return 1 0 931
assign 1 0 934
assign 1 0 938
return 1 0 942
return 1 0 945
assign 1 0 948
assign 1 0 952
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1493726653: return bem_unitExeLinkGet_0();
case -966607916: return bem_cuinitHGetDirect_0();
case -276698461: return bem_libnameDataDoneGet_0();
case -1848197415: return bem_cldefNameGetDirect_0();
case -1155411626: return bem_classNameGet_0();
case -481476994: return bem_nparGet_0();
case -1652639248: return bem_classOGetDirect_0();
case -1228672712: return bem_nbaseGetDirect_0();
case 430203927: return bem_shFileNameGetDirect_0();
case -1514483308: return bem_libnameInitDoneGet_0();
case 1839403813: return bem_libNotNullInitGet_0();
case 339309194: return bem_unitShlibGetDirect_0();
case -1154985755: return bem_echo_0();
case -591287112: return bem_cldefNameGet_0();
case -1484405905: return bem_nparStepsGet_0();
case -1837346138: return bem_cproGetDirect_0();
case -1007929507: return bem_unitExeGetDirect_0();
case -81066187: return bem_makeSrcGetDirect_0();
case 1862434639: return bem_unitExeLinkGetDirect_0();
case 1145975727: return bem_clBaseGetDirect_0();
case -820999575: return bem_npGet_0();
case 748954433: return bem_shClassNameGetDirect_0();
case -1845402369: return bem_create_0();
case -852315358: return bem_midNameGet_0();
case 517100821: return bem_classIncHGetDirect_0();
case -1813260273: return bem_libnameInitGetDirect_0();
case -1611867496: return bem_emitterGetDirect_0();
case -219853739: return bem_libnameDataClearGet_0();
case -707806126: return bem_clNameGet_0();
case -1029706534: return bem_basePathGetDirect_0();
case -1891403653: return bem_namesOGet_0();
case -2057927954: return bem_nparGetDirect_0();
case -494008271: return bem_libNotNullInitGetDirect_0();
case -2116236128: return bem_basePathGet_0();
case -1087765812: return bem_classSrcHGetDirect_0();
case 232809271: return bem_copy_0();
case -943111263: return bem_emitterGet_0();
case -492254378: return bem_classIncHGet_0();
case -799061949: return bem_classExeOGetDirect_0();
case -828071095: return bem_cuinitGetDirect_0();
case 701466066: return bem_xbaseGetDirect_0();
case 460520421: return bem_unitExeGet_0();
case 1562045422: return bem_print_0();
case -481678990: return bem_cuinitGet_0();
case -672368843: return bem_midNameGetDirect_0();
case -792617503: return bem_namesIncHGetDirect_0();
case -1053031155: return bem_unitShlibGet_0();
case 745980876: return bem_serializeToString_0();
case 579432640: return bem_mtdNameGet_0();
case 2134807594: return bem_classExeSrcGet_0();
case 888187423: return bem_cuinitHGet_0();
case 285074277: return bem_deserializeClassNameGet_0();
case 1626059244: return bem_libNotNullInitDoneGet_0();
case 2082126945: return bem_nsDirGet_0();
case 1838344397: return bem_libnameDataClearGetDirect_0();
case 2057063204: return bem_classSrcGetDirect_0();
case 1702123249: return bem_classSrcGet_0();
case 924944414: return bem_mtdNameGetDirect_0();
case -1533691969: return bem_kbaseGet_0();
case -1747116518: return bem_cproGet_0();
case -1718914386: return bem_classOGet_0();
case -1159901660: return bem_namesOGetDirect_0();
case -611094078: return bem_cuBaseGet_0();
case 841207683: return bem_new_0();
case -2143338556: return bem_nparStepsGetDirect_0();
case 1107806890: return bem_nbaseGet_0();
case -1995804558: return bem_toString_0();
case -1217360332: return bem_cldefBuildGetDirect_0();
case -191757079: return bem_cldefBuildGet_0();
case -547814021: return bem_lbaseGetDirect_0();
case -1648839666: return bem_emitPathGet_0();
case -967525204: return bem_fieldNamesGet_0();
case 321887022: return bem_classSrcHGet_0();
case -225078823: return bem_serializationIteratorGet_0();
case 1783068828: return bem_kbaseGetDirect_0();
case -1814966675: return bem_classExeSrcGetDirect_0();
case 863596927: return bem_sourceFileNameGet_0();
case -1404729394: return bem_libnameDataDoneGetDirect_0();
case 2088067585: return bem_libnameDataGet_0();
case -858518329: return bem_many_0();
case 728394627: return bem_xbaseGet_0();
case -205216643: return bem_libnameDataGetDirect_0();
case -1575257119: return bem_synSrcGetDirect_0();
case -703952395: return bem_toAny_0();
case -1052134799: return bem_clNameGetDirect_0();
case -1792813353: return bem_npGetDirect_0();
case 1592801927: return bem_serializeContents_0();
case 565333431: return bem_lbaseGet_0();
case -1703068086: return bem_clBaseGet_0();
case -1373091393: return bem_shClassNameGet_0();
case 1923332126: return bem_shFileNameGet_0();
case 1835904283: return bem_fieldIteratorGet_0();
case 1880204141: return bem_nsDirGetDirect_0();
case -1944468278: return bem_namesIncHGet_0();
case 1030104359: return bem_synSrcGet_0();
case -1680694402: return bem_emitPathGetDirect_0();
case -305427690: return bem_makeSrcGet_0();
case 944745844: return bem_iteratorGet_0();
case 1359534564: return bem_incBlockGet_0();
case -343087500: return bem_libnameInitGet_0();
case -1890761825: return bem_hashGet_0();
case -1247813666: return bem_tagGet_0();
case -298559628: return bem_libnameInitDoneGetDirect_0();
case -1336948311: return bem_incBlockGetDirect_0();
case -513985458: return bem_once_0();
case 495328335: return bem_cuBaseGetDirect_0();
case -2063161721: return bem_classExeOGet_0();
case -84177371: return bem_libNotNullInitDoneGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 568201906: return bem_cldefBuildSetDirect_1(bevd_0);
case 226220717: return bem_synSrcSetDirect_1(bevd_0);
case -1267889810: return bem_unitExeSet_1(bevd_0);
case 1994253206: return bem_nbaseSet_1(bevd_0);
case 1200132287: return bem_cuBaseSet_1(bevd_0);
case 827628124: return bem_clNameSet_1(bevd_0);
case 707432225: return bem_classIncHSetDirect_1(bevd_0);
case 761825105: return bem_nparSetDirect_1(bevd_0);
case 1745447718: return bem_xbaseSet_1(bevd_0);
case -1499443193: return bem_clBaseSetDirect_1(bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
case 2133114203: return bem_libNotNullInitSet_1(bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 1548009495: return bem_libNotNullInitDoneSet_1(bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case -1271911400: return bem_midNameSet_1(bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
case -1951600003: return bem_nparStepsSet_1(bevd_0);
case 1473748227: return bem_clBaseSet_1(bevd_0);
case -1026931903: return bem_nsDirSet_1(bevd_0);
case -51381357: return bem_nsDirDo_1((BEC_2_4_6_TextString) bevd_0);
case 969976599: return bem_shFileNameSetDirect_1(bevd_0);
case 483537176: return bem_libnameDataClearSetDirect_1(bevd_0);
case -1128778324: return bem_classOSetDirect_1(bevd_0);
case 793025499: return bem_classIncHSet_1(bevd_0);
case -750398281: return bem_kbaseSetDirect_1(bevd_0);
case -1568058222: return bem_lbaseSetDirect_1(bevd_0);
case -1625592217: return bem_classSrcHSet_1(bevd_0);
case -946426921: return bem_lbaseSet_1(bevd_0);
case -546266919: return bem_npSetDirect_1(bevd_0);
case 1357656990: return bem_libnameInitDoneSetDirect_1(bevd_0);
case -1815546435: return bem_copyTo_1(bevd_0);
case -364611093: return bem_unitExeLinkSetDirect_1(bevd_0);
case 118937464: return bem_classSrcHSetDirect_1(bevd_0);
case 1731557081: return bem_libnameDataDoneSet_1(bevd_0);
case 591926046: return bem_unitShlibSetDirect_1(bevd_0);
case 1852548661: return bem_shClassNameSet_1(bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1841247800: return bem_xbaseSetDirect_1(bevd_0);
case -1237231870: return bem_cldefNameSet_1(bevd_0);
case 617513508: return bem_clNameSetDirect_1(bevd_0);
case -1892959766: return bem_classExeOSet_1(bevd_0);
case -177948964: return bem_libNotNullInitSetDirect_1(bevd_0);
case 1999309330: return bem_libnameDataSet_1(bevd_0);
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -101690022: return bem_mtdNameSetDirect_1(bevd_0);
case -1233783040: return bem_emitterSet_1(bevd_0);
case -1131459582: return bem_mtdNameSet_1(bevd_0);
case -412826647: return bem_cuBaseSetDirect_1(bevd_0);
case 1255013640: return bem_libnameDataSetDirect_1(bevd_0);
case -1104570287: return bem_classSrcSetDirect_1(bevd_0);
case -215514627: return bem_nparStepsSetDirect_1(bevd_0);
case 230738465: return bem_classOSet_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1882991955: return bem_libnameInitSet_1(bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case 2100829714: return bem_emitterSetDirect_1(bevd_0);
case 71770569: return bem_cldefNameSetDirect_1(bevd_0);
case -909782248: return bem_namesIncHSet_1(bevd_0);
case 12031225: return bem_def_1(bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case 492360850: return bem_libnameDataClearSet_1(bevd_0);
case 163845928: return bem_nparSet_1(bevd_0);
case -1023555960: return bem_incBlockSet_1(bevd_0);
case 1052784673: return bem_unitExeSetDirect_1(bevd_0);
case -1574521114: return bem_classSrcSet_1(bevd_0);
case 1139165724: return bem_shClassNameSetDirect_1(bevd_0);
case -480081286: return bem_cproSetDirect_1(bevd_0);
case 62213586: return bem_cuinitHSet_1(bevd_0);
case 1200297939: return bem_undef_1(bevd_0);
case -984123850: return bem_cuinitHSetDirect_1(bevd_0);
case 1292390178: return bem_namesIncHSetDirect_1(bevd_0);
case 1298069101: return bem_kbaseSet_1(bevd_0);
case 833143372: return bem_nbaseSetDirect_1(bevd_0);
case -2066959701: return bem_unitExeLinkSet_1(bevd_0);
case 1687960958: return bem_synSrcSet_1(bevd_0);
case -756230388: return bem_libnameInitSetDirect_1(bevd_0);
case 1438689167: return bem_nsDirSetDirect_1(bevd_0);
case -748867815: return bem_makeSrcSetDirect_1(bevd_0);
case -318007856: return bem_cproSet_1(bevd_0);
case 725087216: return bem_basePathSet_1(bevd_0);
case -1564665612: return bem_makeSrcSet_1(bevd_0);
case -837352681: return bem_cldefBuildSet_1(bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
case 397729661: return bem_incBlockSetDirect_1(bevd_0);
case 1035952961: return bem_namesOSetDirect_1(bevd_0);
case 1399346277: return bem_midNameSetDirect_1(bevd_0);
case -1413708232: return bem_libnameDataDoneSetDirect_1(bevd_0);
case -1945228054: return bem_classExeOSetDirect_1(bevd_0);
case -581737223: return bem_classExeSrcSet_1(bevd_0);
case 1189552969: return bem_emitPathSetDirect_1(bevd_0);
case -252960699: return bem_npSet_1(bevd_0);
case 500428825: return bem_emitPathSet_1(bevd_0);
case -1846108887: return bem_shFileNameSet_1(bevd_0);
case 2132579892: return bem_cuinitSetDirect_1(bevd_0);
case 1785005992: return bem_libnameInitDoneSet_1(bevd_0);
case 568874344: return bem_basePathSetDirect_1(bevd_0);
case -1019865986: return bem_cuinitSet_1(bevd_0);
case -1195038066: return bem_namesOSet_1(bevd_0);
case 263073536: return bem_unitShlibSet_1(bevd_0);
case -2029139138: return bem_classExeSrcSetDirect_1(bevd_0);
case -474035050: return bem_libNotNullInitDoneSetDirect_1(bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1565718228: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -2094129946: return bem_new_5((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildClassInfo_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildClassInfo_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildClassInfo();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst = (BEC_2_5_9_BuildClassInfo) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_type;
}
}
