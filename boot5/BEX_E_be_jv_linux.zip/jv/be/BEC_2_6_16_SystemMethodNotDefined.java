package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_16_SystemMethodNotDefined extends BEC_2_6_9_SystemException {
public BEC_2_6_16_SystemMethodNotDefined() { }
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;

public static BET_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1610221244: return bem_methodNameGet_0();
case 1163801837: return bem_klassNameGetDirect_0();
case 232809271: return bem_copy_0();
case -173680583: return bem_langGet_0();
case 746147237: return bem_langGetDirect_0();
case -1247813666: return bem_tagGet_0();
case 1068061438: return bem_lineNumberGet_0();
case -225078823: return bem_serializationIteratorGet_0();
case 528392232: return bem_emitLangGetDirect_0();
case -858518329: return bem_many_0();
case -1532214182: return bem_translateEmittedExceptionInner_0();
case 1405021034: return bem_klassNameGet_0();
case 285074277: return bem_deserializeClassNameGet_0();
case 863596927: return bem_sourceFileNameGet_0();
case -732225643: return bem_vvGet_0();
case -1420075265: return bem_translateEmittedException_0();
case 944745844: return bem_iteratorGet_0();
case -1056066713: return bem_translatedGetDirect_0();
case 1176882915: return bem_framesGet_0();
case 2068288228: return bem_methodNameGetDirect_0();
case 32675018: return bem_framesTextGetDirect_0();
case -1149372418: return bem_vvGetDirect_0();
case -1561188213: return bem_emitLangGet_0();
case -967525204: return bem_fieldNamesGet_0();
case 2114927345: return bem_framesTextGet_0();
case -1155411626: return bem_classNameGet_0();
case -1297116660: return bem_descriptionGet_0();
case 1562045422: return bem_print_0();
case -513985458: return bem_once_0();
case -1154985755: return bem_echo_0();
case 1468266350: return bem_translatedGet_0();
case -1063367178: return bem_lineNumberGetDirect_0();
case -727184357: return bem_descriptionGetDirect_0();
case 841207683: return bem_new_0();
case 1378218886: return bem_framesGetDirect_0();
case 745980876: return bem_serializeToString_0();
case 1125446558: return bem_getFrameText_0();
case 1592801927: return bem_serializeContents_0();
case 1835904283: return bem_fieldIteratorGet_0();
case -703952395: return bem_toAny_0();
case -2112971109: return bem_fileNameGetDirect_0();
case -1845402369: return bem_create_0();
case -1890761825: return bem_hashGet_0();
case -1995804558: return bem_toString_0();
case -11762692: return bem_fileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1885955202: return bem_lineNumberSet_1(bevd_0);
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -26838185: return bem_fileNameSetDirect_1(bevd_0);
case 1773769835: return bem_framesSetDirect_1(bevd_0);
case 283372580: return bem_emitLangSet_1(bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 869135780: return bem_framesTextSetDirect_1(bevd_0);
case -2084725487: return bem_translatedSet_1(bevd_0);
case -1841440576: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -361827769: return bem_descriptionSet_1(bevd_0);
case -1257651199: return bem_vvSetDirect_1(bevd_0);
case 371296409: return bem_langSet_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case 333509553: return bem_descriptionSetDirect_1(bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1459894631: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 459016815: return bem_framesSet_1(bevd_0);
case 1200297939: return bem_undef_1(bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1483589531: return bem_methodNameSetDirect_1(bevd_0);
case 226740392: return bem_fileNameSet_1(bevd_0);
case 621722664: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1379884941: return bem_klassNameSet_1(bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
case 1085049356: return bem_new_1(bevd_0);
case 1894628261: return bem_methodNameSet_1(bevd_0);
case 136554628: return bem_emitLangSetDirect_1(bevd_0);
case 12031225: return bem_def_1(bevd_0);
case -1815546435: return bem_copyTo_1(bevd_0);
case 1205883794: return bem_langSetDirect_1(bevd_0);
case 186347959: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -394216315: return bem_translatedSetDirect_1(bevd_0);
case 290167733: return bem_vvSet_1(bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
case 504566395: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -908622121: return bem_lineNumberSetDirect_1(bevd_0);
case -1836249538: return bem_framesTextSet_1(bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
case -2071180497: return bem_klassNameSetDirect_1(bevd_0);
case -194528146: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1609507555: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemMethodNotDefined_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemMethodNotDefined_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemMethodNotDefined();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst = (BEC_2_6_16_SystemMethodNotDefined) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;
}
}
