package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_16_SystemMethodNotDefined extends BEC_2_6_9_SystemException {
public BEC_2_6_16_SystemMethodNotDefined() { }
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;

public static BET_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1461522196: return bem_fileNameGet_0();
case -324733615: return bem_serializeToString_0();
case -760211542: return bem_sourceFileNameGet_0();
case -1471452304: return bem_lineNumberGet_0();
case -472564109: return bem_fileNameGetDirect_0();
case 1288102045: return bem_translatedGetDirect_0();
case -371367793: return bem_klassNameGetDirect_0();
case -178992645: return bem_deserializeClassNameGet_0();
case 640998046: return bem_descriptionGetDirect_0();
case -1187132797: return bem_hashGet_0();
case -914683895: return bem_descriptionGet_0();
case 1035468461: return bem_klassNameGet_0();
case 854837664: return bem_create_0();
case 686779694: return bem_framesTextGetDirect_0();
case 1697432405: return bem_once_0();
case 1486098436: return bem_fieldNamesGet_0();
case 1236768538: return bem_iteratorGet_0();
case -1687769721: return bem_methodNameGetDirect_0();
case -1906259272: return bem_vvGetDirect_0();
case 1319933824: return bem_classNameGet_0();
case 1023482375: return bem_framesTextGet_0();
case -665700550: return bem_lineNumberGetDirect_0();
case 119468176: return bem_vvGet_0();
case -795764953: return bem_fieldIteratorGet_0();
case 1737862711: return bem_print_0();
case -1031550969: return bem_translatedGet_0();
case -604973932: return bem_serializeContents_0();
case -1159943693: return bem_echo_0();
case -1454042319: return bem_translateEmittedExceptionInner_0();
case -1698643956: return bem_serializationIteratorGet_0();
case -874849187: return bem_framesGetDirect_0();
case -1737374632: return bem_methodNameGet_0();
case -564186618: return bem_emitLangGet_0();
case 391490272: return bem_framesGet_0();
case -980484092: return bem_new_0();
case 2060226522: return bem_emitLangGetDirect_0();
case 2077314506: return bem_many_0();
case -2036442591: return bem_toAny_0();
case 396059776: return bem_tagGet_0();
case 1690392721: return bem_getFrameText_0();
case -1561062280: return bem_langGetDirect_0();
case -1330798167: return bem_langGet_0();
case 1616240746: return bem_toString_0();
case -1025420280: return bem_translateEmittedException_0();
case 239325412: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1754732193: return bem_notEquals_1(bevd_0);
case 1229731165: return bem_copyTo_1(bevd_0);
case -645727759: return bem_klassNameSet_1(bevd_0);
case 1806398953: return bem_framesSetDirect_1(bevd_0);
case -512519677: return bem_descriptionSet_1(bevd_0);
case 923477368: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -341377405: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1093973265: return bem_emitLangSetDirect_1(bevd_0);
case -1864431979: return bem_methodNameSet_1(bevd_0);
case -540486003: return bem_langSetDirect_1(bevd_0);
case -1007225589: return bem_langSet_1(bevd_0);
case 604385677: return bem_vvSetDirect_1(bevd_0);
case 1075750255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 962423408: return bem_def_1(bevd_0);
case 1109276399: return bem_sameObject_1(bevd_0);
case -58601680: return bem_sameType_1(bevd_0);
case 395717057: return bem_defined_1(bevd_0);
case -443733066: return bem_lineNumberSet_1(bevd_0);
case -1097624238: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2105787456: return bem_methodNameSetDirect_1(bevd_0);
case 1784508277: return bem_undefined_1(bevd_0);
case 486594455: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 215737112: return bem_otherType_1(bevd_0);
case -354650091: return bem_undef_1(bevd_0);
case 946211739: return bem_framesTextSetDirect_1(bevd_0);
case 97582880: return bem_fileNameSetDirect_1(bevd_0);
case -1120436550: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1021147088: return bem_otherClass_1(bevd_0);
case 850683733: return bem_equals_1(bevd_0);
case -492919920: return bem_new_1(bevd_0);
case 322830675: return bem_emitLangSet_1(bevd_0);
case -1811996103: return bem_framesTextSet_1(bevd_0);
case -1905766928: return bem_translatedSetDirect_1(bevd_0);
case 301993386: return bem_descriptionSetDirect_1(bevd_0);
case 1567099389: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 208741912: return bem_fileNameSet_1(bevd_0);
case 256448254: return bem_framesSet_1(bevd_0);
case -886177398: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1872644196: return bem_vvSet_1(bevd_0);
case -495079952: return bem_translatedSet_1(bevd_0);
case 1479379696: return bem_sameClass_1(bevd_0);
case 2004361336: return bem_klassNameSetDirect_1(bevd_0);
case 491468398: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1138906082: return bem_lineNumberSetDirect_1(bevd_0);
case -1291288835: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 602921151: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1012334348: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 661390803: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -434648658: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 192635884: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 103255187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 834345030: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 101805326: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemMethodNotDefined_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemMethodNotDefined_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemMethodNotDefined();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst = (BEC_2_6_16_SystemMethodNotDefined) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;
}
}
