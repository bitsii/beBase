package be;
/* IO:File: source/build/Constants.be */
public final class BEC_2_5_9_BuildConstants extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildConstants() { }
private static byte[] becc_BEC_2_5_9_BuildConstants_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_5_9_BuildConstants_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_0 = {0x62,0x72,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_1 = {0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_2 = {0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_3 = {0x70,0x61,0x72,0x65,0x6E,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_4 = {0x4E,0x4F,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_5 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_6 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_7 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_8 = {0x44,0x49,0x56,0x49,0x44,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_9 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_10 = {0x41,0x44,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_11 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_12 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_13 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_14 = {0x4C,0x45,0x53,0x53,0x45,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_15 = {0x4C,0x45,0x53,0x53,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_16 = {0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_17 = {0x4E,0x4F,0x54,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_18 = {0x41,0x4E,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_19 = {0x4F,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_20 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x41,0x4E,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_21 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x4F,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_22 = {0x49,0x4E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_23 = {0x41,0x44,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_24 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_25 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_26 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_27 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_28 = {0x44,0x49,0x56,0x49,0x44,0x45,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_29 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_30 = {0x41,0x4E,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_31 = {0x4F,0x52,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_32 = {0x41,0x53,0x53,0x49,0x47,0x4E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_33 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_34 = {0x2F};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_35 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_36 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_37 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_38 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_39 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_40 = {0x3A};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_41 = {0x2C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_42 = {0x2B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_43 = {};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_44 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_45 = {0x75,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_46 = {0x61,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_47 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_48 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_49 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_50 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_51 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_52 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_53 = {0x61,0x75,0x74,0x6F};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_54 = {0x69,0x66};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_55 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_56 = {0x65,0x6C,0x73,0x65,0x49,0x66};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_57 = {0x65,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_58 = {0x66,0x69,0x6E,0x61,0x6C,0x6C,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_59 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_60 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_61 = {0x73,0x6C,0x6F,0x74,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_62 = {0x77,0x68,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_63 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_64 = {0x66,0x6F,0x72};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_65 = {0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_66 = {0x65,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_67 = {0x69,0x66,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_68 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_69 = {0x62,0x72,0x65,0x61,0x6B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_70 = {0x63,0x6F,0x6E,0x74,0x69,0x6E,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_71 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_72 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_73 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_74 = {0x74,0x72,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_75 = {0x63,0x61,0x74,0x63,0x68};
public static BEC_2_5_9_BuildConstants bece_BEC_2_5_9_BuildConstants_bevs_inst;

public static BET_2_5_9_BuildConstants bece_BEC_2_5_9_BuildConstants_bevs_type;

public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public BEC_2_4_3_MathInt bevp_maxargs;
public BEC_2_4_3_MathInt bevp_extraSlots;
public BEC_2_4_3_MathInt bevp_mtdxPad;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_9_3_ContainerMap bevp_unwindTo;
public BEC_2_9_3_ContainerMap bevp_unwindOk;
public BEC_2_9_3_ContainerMap bevp_oper;
public BEC_2_9_3_ContainerMap bevp_operNames;
public BEC_2_9_3_ContainerMap bevp_conTypes;
public BEC_2_9_3_ContainerMap bevp_parensReq;
public BEC_2_9_3_ContainerMap bevp_anchorTypes;
public BEC_2_5_9_BuildConstants bem_new_1(BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_3_MathInt bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_4_3_MathInt bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_3_MathInt bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_3_MathInt bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_3_MathInt bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_3_MathInt bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_3_MathInt bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_3_MathInt bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_4_3_MathInt bevt_108_ta_ph = null;
BEC_2_4_6_TextString bevt_109_ta_ph = null;
BEC_2_4_3_MathInt bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_3_MathInt bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_4_3_MathInt bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_3_MathInt bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_4_3_MathInt bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_3_MathInt bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_4_3_MathInt bevt_122_ta_ph = null;
BEC_2_4_6_TextString bevt_123_ta_ph = null;
BEC_2_4_3_MathInt bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_4_3_MathInt bevt_126_ta_ph = null;
BEC_2_5_4_LogicBool bevt_127_ta_ph = null;
BEC_2_4_3_MathInt bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_4_3_MathInt bevt_130_ta_ph = null;
BEC_2_5_4_LogicBool bevt_131_ta_ph = null;
BEC_2_4_3_MathInt bevt_132_ta_ph = null;
BEC_2_5_4_LogicBool bevt_133_ta_ph = null;
BEC_2_4_3_MathInt bevt_134_ta_ph = null;
BEC_2_5_4_LogicBool bevt_135_ta_ph = null;
BEC_2_4_3_MathInt bevt_136_ta_ph = null;
BEC_2_5_4_LogicBool bevt_137_ta_ph = null;
BEC_2_4_3_MathInt bevt_138_ta_ph = null;
BEC_2_5_4_LogicBool bevt_139_ta_ph = null;
BEC_2_4_3_MathInt bevt_140_ta_ph = null;
BEC_2_5_4_LogicBool bevt_141_ta_ph = null;
BEC_2_4_3_MathInt bevt_142_ta_ph = null;
BEC_2_5_4_LogicBool bevt_143_ta_ph = null;
BEC_2_4_3_MathInt bevt_144_ta_ph = null;
BEC_2_5_4_LogicBool bevt_145_ta_ph = null;
BEC_2_4_3_MathInt bevt_146_ta_ph = null;
BEC_2_5_4_LogicBool bevt_147_ta_ph = null;
BEC_2_4_3_MathInt bevt_148_ta_ph = null;
BEC_2_5_4_LogicBool bevt_149_ta_ph = null;
BEC_2_4_3_MathInt bevt_150_ta_ph = null;
BEC_2_5_4_LogicBool bevt_151_ta_ph = null;
BEC_2_4_3_MathInt bevt_152_ta_ph = null;
BEC_2_5_4_LogicBool bevt_153_ta_ph = null;
BEC_2_4_3_MathInt bevt_154_ta_ph = null;
BEC_2_5_4_LogicBool bevt_155_ta_ph = null;
BEC_2_4_3_MathInt bevt_156_ta_ph = null;
BEC_2_5_4_LogicBool bevt_157_ta_ph = null;
BEC_2_4_3_MathInt bevt_158_ta_ph = null;
BEC_2_5_4_LogicBool bevt_159_ta_ph = null;
BEC_2_4_3_MathInt bevt_160_ta_ph = null;
BEC_2_5_4_LogicBool bevt_161_ta_ph = null;
BEC_2_4_3_MathInt bevt_162_ta_ph = null;
BEC_2_5_4_LogicBool bevt_163_ta_ph = null;
BEC_2_4_3_MathInt bevt_164_ta_ph = null;
BEC_2_5_4_LogicBool bevt_165_ta_ph = null;
BEC_2_4_3_MathInt bevt_166_ta_ph = null;
BEC_2_5_4_LogicBool bevt_167_ta_ph = null;
BEC_2_4_3_MathInt bevt_168_ta_ph = null;
BEC_2_5_4_LogicBool bevt_169_ta_ph = null;
BEC_2_4_3_MathInt bevt_170_ta_ph = null;
BEC_2_5_4_LogicBool bevt_171_ta_ph = null;
BEC_2_4_3_MathInt bevt_172_ta_ph = null;
BEC_2_5_4_LogicBool bevt_173_ta_ph = null;
BEC_2_4_3_MathInt bevt_174_ta_ph = null;
BEC_2_5_4_LogicBool bevt_175_ta_ph = null;
BEC_2_4_3_MathInt bevt_176_ta_ph = null;
BEC_2_5_4_LogicBool bevt_177_ta_ph = null;
BEC_2_4_3_MathInt bevt_178_ta_ph = null;
BEC_2_5_4_LogicBool bevt_179_ta_ph = null;
BEC_2_4_3_MathInt bevt_180_ta_ph = null;
BEC_2_5_4_LogicBool bevt_181_ta_ph = null;
BEC_2_4_3_MathInt bevt_182_ta_ph = null;
BEC_2_5_4_LogicBool bevt_183_ta_ph = null;
BEC_2_4_3_MathInt bevt_184_ta_ph = null;
BEC_2_5_4_LogicBool bevt_185_ta_ph = null;
BEC_2_4_3_MathInt bevt_186_ta_ph = null;
BEC_2_5_4_LogicBool bevt_187_ta_ph = null;
BEC_2_4_3_MathInt bevt_188_ta_ph = null;
BEC_2_5_4_LogicBool bevt_189_ta_ph = null;
BEC_2_4_3_MathInt bevt_190_ta_ph = null;
BEC_2_5_4_LogicBool bevt_191_ta_ph = null;
BEC_2_4_3_MathInt bevt_192_ta_ph = null;
BEC_2_5_4_LogicBool bevt_193_ta_ph = null;
BEC_2_4_3_MathInt bevt_194_ta_ph = null;
BEC_2_5_4_LogicBool bevt_195_ta_ph = null;
bevp_maxargs = (new BEC_2_4_3_MathInt(16));
bevp_extraSlots = (new BEC_2_4_3_MathInt(2));
bevp_mtdxPad = (new BEC_2_4_3_MathInt(26));
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
bevp_unwindTo = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_unwindOk = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_oper = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_operNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_conTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parensReq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_anchorTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_0));
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevp_unwindTo.bem_put_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_1));
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_2));
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_3));
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_6_ta_ph, bevt_7_ta_ph);
bevt_8_ta_ph = bevp_ntypes.bem_NOTGet_0();
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_8_ta_ph, bevt_9_ta_ph);
bevt_10_ta_ph = bevp_ntypes.bem_INCREMENTGet_0();
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_10_ta_ph, bevt_11_ta_ph);
bevt_12_ta_ph = bevp_ntypes.bem_DECREMENTGet_0();
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_12_ta_ph, bevt_13_ta_ph);
bevt_14_ta_ph = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_14_ta_ph, bevt_15_ta_ph);
bevt_16_ta_ph = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_16_ta_ph, bevt_17_ta_ph);
bevt_18_ta_ph = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_18_ta_ph, bevt_19_ta_ph);
bevt_20_ta_ph = bevp_ntypes.bem_DIVIDEGet_0();
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_20_ta_ph, bevt_21_ta_ph);
bevt_22_ta_ph = bevp_ntypes.bem_MODULUSGet_0();
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_22_ta_ph, bevt_23_ta_ph);
bevt_24_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevt_25_ta_ph = (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_24_ta_ph, bevt_25_ta_ph);
bevt_26_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_27_ta_ph = (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_26_ta_ph, bevt_27_ta_ph);
bevt_28_ta_ph = bevp_ntypes.bem_GREATERGet_0();
bevt_29_ta_ph = (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_28_ta_ph, bevt_29_ta_ph);
bevt_30_ta_ph = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_31_ta_ph = (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_30_ta_ph, bevt_31_ta_ph);
bevt_32_ta_ph = bevp_ntypes.bem_LESSERGet_0();
bevt_33_ta_ph = (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_32_ta_ph, bevt_33_ta_ph);
bevt_34_ta_ph = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_35_ta_ph = (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_34_ta_ph, bevt_35_ta_ph);
bevt_36_ta_ph = bevp_ntypes.bem_EQUALSGet_0();
bevt_37_ta_ph = (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_36_ta_ph, bevt_37_ta_ph);
bevt_38_ta_ph = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_39_ta_ph = (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_38_ta_ph, bevt_39_ta_ph);
bevt_40_ta_ph = bevp_ntypes.bem_ANDGet_0();
bevt_41_ta_ph = (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_40_ta_ph, bevt_41_ta_ph);
bevt_42_ta_ph = bevp_ntypes.bem_ORGet_0();
bevt_43_ta_ph = (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_42_ta_ph, bevt_43_ta_ph);
bevt_44_ta_ph = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_45_ta_ph = (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_46_ta_ph = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_47_ta_ph = (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_46_ta_ph, bevt_47_ta_ph);
bevt_48_ta_ph = bevp_ntypes.bem_INGet_0();
bevt_49_ta_ph = (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_50_ta_ph = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_51_ta_ph = (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_50_ta_ph, bevt_51_ta_ph);
bevt_52_ta_ph = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_53_ta_ph = (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_52_ta_ph, bevt_53_ta_ph);
bevt_54_ta_ph = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_55_ta_ph = (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_54_ta_ph, bevt_55_ta_ph);
bevt_56_ta_ph = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_57_ta_ph = (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_56_ta_ph, bevt_57_ta_ph);
bevt_58_ta_ph = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_59_ta_ph = (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_58_ta_ph, bevt_59_ta_ph);
bevt_60_ta_ph = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_61_ta_ph = (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_60_ta_ph, bevt_61_ta_ph);
bevt_62_ta_ph = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_63_ta_ph = (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_62_ta_ph, bevt_63_ta_ph);
bevt_64_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
bevt_65_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_oper.bem_put_2(bevt_64_ta_ph, bevt_65_ta_ph);
bevt_66_ta_ph = bevp_ntypes.bem_NOTGet_0();
bevt_67_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_4));
bevp_operNames.bem_put_2(bevt_66_ta_ph, bevt_67_ta_ph);
bevt_68_ta_ph = bevp_ntypes.bem_INCREMENTGet_0();
bevt_69_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_5));
bevp_operNames.bem_put_2(bevt_68_ta_ph, bevt_69_ta_ph);
bevt_70_ta_ph = bevp_ntypes.bem_DECREMENTGet_0();
bevt_71_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_6));
bevp_operNames.bem_put_2(bevt_70_ta_ph, bevt_71_ta_ph);
bevt_72_ta_ph = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_73_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_7));
bevp_operNames.bem_put_2(bevt_72_ta_ph, bevt_73_ta_ph);
bevt_74_ta_ph = bevp_ntypes.bem_DIVIDEGet_0();
bevt_75_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_8));
bevp_operNames.bem_put_2(bevt_74_ta_ph, bevt_75_ta_ph);
bevt_76_ta_ph = bevp_ntypes.bem_MODULUSGet_0();
bevt_77_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_9));
bevp_operNames.bem_put_2(bevt_76_ta_ph, bevt_77_ta_ph);
bevt_78_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevt_79_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_10));
bevp_operNames.bem_put_2(bevt_78_ta_ph, bevt_79_ta_ph);
bevt_80_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_81_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_11));
bevp_operNames.bem_put_2(bevt_80_ta_ph, bevt_81_ta_ph);
bevt_82_ta_ph = bevp_ntypes.bem_GREATERGet_0();
bevt_83_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_12));
bevp_operNames.bem_put_2(bevt_82_ta_ph, bevt_83_ta_ph);
bevt_84_ta_ph = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_85_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_13));
bevp_operNames.bem_put_2(bevt_84_ta_ph, bevt_85_ta_ph);
bevt_86_ta_ph = bevp_ntypes.bem_LESSERGet_0();
bevt_87_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_14));
bevp_operNames.bem_put_2(bevt_86_ta_ph, bevt_87_ta_ph);
bevt_88_ta_ph = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_89_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildConstants_bels_15));
bevp_operNames.bem_put_2(bevt_88_ta_ph, bevt_89_ta_ph);
bevt_90_ta_ph = bevp_ntypes.bem_EQUALSGet_0();
bevt_91_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_16));
bevp_operNames.bem_put_2(bevt_90_ta_ph, bevt_91_ta_ph);
bevt_92_ta_ph = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_93_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_17));
bevp_operNames.bem_put_2(bevt_92_ta_ph, bevt_93_ta_ph);
bevt_94_ta_ph = bevp_ntypes.bem_ANDGet_0();
bevt_95_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_18));
bevp_operNames.bem_put_2(bevt_94_ta_ph, bevt_95_ta_ph);
bevt_96_ta_ph = bevp_ntypes.bem_ORGet_0();
bevt_97_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_19));
bevp_operNames.bem_put_2(bevt_96_ta_ph, bevt_97_ta_ph);
bevt_98_ta_ph = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_99_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildConstants_bels_20));
bevp_operNames.bem_put_2(bevt_98_ta_ph, bevt_99_ta_ph);
bevt_100_ta_ph = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_101_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_21));
bevp_operNames.bem_put_2(bevt_100_ta_ph, bevt_101_ta_ph);
bevt_102_ta_ph = bevp_ntypes.bem_INGet_0();
bevt_103_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_22));
bevp_operNames.bem_put_2(bevt_102_ta_ph, bevt_103_ta_ph);
bevt_104_ta_ph = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_105_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_23));
bevp_operNames.bem_put_2(bevt_104_ta_ph, bevt_105_ta_ph);
bevt_106_ta_ph = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_107_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_24));
bevp_operNames.bem_put_2(bevt_106_ta_ph, bevt_107_ta_ph);
bevt_108_ta_ph = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_109_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildConstants_bels_25));
bevp_operNames.bem_put_2(bevt_108_ta_ph, bevt_109_ta_ph);
bevt_110_ta_ph = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_111_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildConstants_bels_26));
bevp_operNames.bem_put_2(bevt_110_ta_ph, bevt_111_ta_ph);
bevt_112_ta_ph = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_113_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_27));
bevp_operNames.bem_put_2(bevt_112_ta_ph, bevt_113_ta_ph);
bevt_114_ta_ph = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_115_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildConstants_bels_28));
bevp_operNames.bem_put_2(bevt_114_ta_ph, bevt_115_ta_ph);
bevt_116_ta_ph = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_117_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildConstants_bels_29));
bevp_operNames.bem_put_2(bevt_116_ta_ph, bevt_117_ta_ph);
bevt_118_ta_ph = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_119_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_30));
bevp_operNames.bem_put_2(bevt_118_ta_ph, bevt_119_ta_ph);
bevt_120_ta_ph = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_121_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_31));
bevp_operNames.bem_put_2(bevt_120_ta_ph, bevt_121_ta_ph);
bevt_122_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
bevt_123_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_32));
bevp_operNames.bem_put_2(bevt_122_ta_ph, bevt_123_ta_ph);
bevt_124_ta_ph = bevp_ntypes.bem_IFGet_0();
bevt_125_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_124_ta_ph, bevt_125_ta_ph);
bevt_126_ta_ph = bevp_ntypes.bem_ELIFGet_0();
bevt_127_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_126_ta_ph, bevt_127_ta_ph);
bevt_128_ta_ph = bevp_ntypes.bem_WHILEGet_0();
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_128_ta_ph, bevt_129_ta_ph);
bevt_130_ta_ph = bevp_ntypes.bem_FORGet_0();
bevt_131_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_130_ta_ph, bevt_131_ta_ph);
bevt_132_ta_ph = bevp_ntypes.bem_FOREACHGet_0();
bevt_133_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_132_ta_ph, bevt_133_ta_ph);
bevt_134_ta_ph = bevp_ntypes.bem_EMITGet_0();
bevt_135_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_134_ta_ph, bevt_135_ta_ph);
bevt_136_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
bevt_137_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_136_ta_ph, bevt_137_ta_ph);
bevt_138_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_139_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_138_ta_ph, bevt_139_ta_ph);
bevt_140_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_141_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_140_ta_ph, bevt_141_ta_ph);
bevt_142_ta_ph = bevp_ntypes.bem_EXPRGet_0();
bevt_143_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_142_ta_ph, bevt_143_ta_ph);
bevt_144_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevt_145_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_144_ta_ph, bevt_145_ta_ph);
bevt_146_ta_ph = bevp_ntypes.bem_FINALLYGet_0();
bevt_147_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_146_ta_ph, bevt_147_ta_ph);
bevt_148_ta_ph = bevp_ntypes.bem_TRYGet_0();
bevt_149_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_148_ta_ph, bevt_149_ta_ph);
bevt_150_ta_ph = bevp_ntypes.bem_LOOPGet_0();
bevt_151_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_150_ta_ph, bevt_151_ta_ph);
bevt_152_ta_ph = bevp_ntypes.bem_FIELDSGet_0();
bevt_153_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_152_ta_ph, bevt_153_ta_ph);
bevt_154_ta_ph = bevp_ntypes.bem_SLOTSGet_0();
bevt_155_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_154_ta_ph, bevt_155_ta_ph);
bevt_156_ta_ph = bevp_ntypes.bem_CATCHGet_0();
bevt_157_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_156_ta_ph, bevt_157_ta_ph);
bevt_158_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_159_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_158_ta_ph, bevt_159_ta_ph);
bevt_160_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevt_161_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_160_ta_ph, bevt_161_ta_ph);
bevt_162_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_163_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_162_ta_ph, bevt_163_ta_ph);
bevt_164_ta_ph = bevp_ntypes.bem_IDXGet_0();
bevt_165_ta_ph = be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_164_ta_ph, bevt_165_ta_ph);
bevt_166_ta_ph = bevp_ntypes.bem_IFGet_0();
bevt_167_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_166_ta_ph, bevt_167_ta_ph);
bevt_168_ta_ph = bevp_ntypes.bem_ELIFGet_0();
bevt_169_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_168_ta_ph, bevt_169_ta_ph);
bevt_170_ta_ph = bevp_ntypes.bem_WHILEGet_0();
bevt_171_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_170_ta_ph, bevt_171_ta_ph);
bevt_172_ta_ph = bevp_ntypes.bem_FORGet_0();
bevt_173_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_172_ta_ph, bevt_173_ta_ph);
bevt_174_ta_ph = bevp_ntypes.bem_FOREACHGet_0();
bevt_175_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_174_ta_ph, bevt_175_ta_ph);
bevt_176_ta_ph = bevp_ntypes.bem_EMITGet_0();
bevt_177_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_176_ta_ph, bevt_177_ta_ph);
bevt_178_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
bevt_179_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_178_ta_ph, bevt_179_ta_ph);
bevt_180_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_181_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_180_ta_ph, bevt_181_ta_ph);
bevt_182_ta_ph = bevp_ntypes.bem_CATCHGet_0();
bevt_183_ta_ph = be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_182_ta_ph, bevt_183_ta_ph);
bevt_184_ta_ph = bevp_ntypes.bem_IFGet_0();
bevt_185_ta_ph = be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_184_ta_ph, bevt_185_ta_ph);
bevt_186_ta_ph = bevp_ntypes.bem_ELIFGet_0();
bevt_187_ta_ph = be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_186_ta_ph, bevt_187_ta_ph);
bevt_188_ta_ph = bevp_ntypes.bem_WHILEGet_0();
bevt_189_ta_ph = be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_188_ta_ph, bevt_189_ta_ph);
bevt_190_ta_ph = bevp_ntypes.bem_FORGet_0();
bevt_191_ta_ph = be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_190_ta_ph, bevt_191_ta_ph);
bevt_192_ta_ph = bevp_ntypes.bem_FOREACHGet_0();
bevt_193_ta_ph = be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_192_ta_ph, bevt_193_ta_ph);
bevt_194_ta_ph = bevp_ntypes.bem_EXPRGet_0();
bevt_195_ta_ph = be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_194_ta_ph, bevt_195_ta_ph);
bem_prepare_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_prepare_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_space = null;
BEC_2_6_6_SystemObject bevl_ntok = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_3_MathInt bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_4_7_TextStrings bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_7_TextStrings bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_3_MathInt bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_3_MathInt bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_3_MathInt bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_3_MathInt bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_3_MathInt bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_3_MathInt bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_3_MathInt bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_3_MathInt bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_3_MathInt bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_4_3_MathInt bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_4_3_MathInt bevt_109_ta_ph = null;
bevp_matchMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_33));
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_34));
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
bevp_twtok = (new BEC_2_4_9_TextTokenizer()).bem_new_2((BEC_2_4_6_TextString) bevl_ntok , bevt_0_ta_ph);
bevt_1_ta_ph = bevp_ntypes.bem_DIVIDEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_1_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_35));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_2_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_2_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_36));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_3_ta_ph = bevp_ntypes.bem_RBRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_3_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_37));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_4_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_4_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_38));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_5_ta_ph = bevp_ntypes.bem_RPARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_5_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_39));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_6_ta_ph = bevp_ntypes.bem_SEMIGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_6_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_40));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_7_ta_ph = bevp_ntypes.bem_COLONGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_7_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_41));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_8_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_8_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_42));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_9_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_9_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildConstants_bels_43));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_10_ta_ph = bevp_ntypes.bem_ATYPEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_10_ta_ph);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_44));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_11_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(92));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_12_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_13_ta_ph = bevp_ntypes.bem_FSLASHGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(34));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_14_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_15_ta_ph = bevp_ntypes.bem_STRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(39));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_16_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_17_ta_ph = bevp_ntypes.bem_WSTRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(91));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_18_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_19_ta_ph = bevp_ntypes.bem_IDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(93));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_20_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_21_ta_ph = bevp_ntypes.bem_RIDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(37));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_22_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_23_ta_ph = bevp_ntypes.bem_MODULUSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_23_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(61));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_24_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_25_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_25_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(62));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_26_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_27_ta_ph = bevp_ntypes.bem_GREATERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_27_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_3_MathInt(60));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_28_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_29_ta_ph = bevp_ntypes.bem_LESSERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_3_MathInt(33));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_30_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_31_ta_ph = bevp_ntypes.bem_NOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_31_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_3_MathInt(38));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_32_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_33_ta_ph = bevp_ntypes.bem_ANDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_33_ta_ph);
bevt_34_ta_ph = (new BEC_2_4_3_MathInt(124));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_34_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_35_ta_ph = bevp_ntypes.bem_ORGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_35_ta_ph);
bevt_36_ta_ph = (new BEC_2_4_3_MathInt(42));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_36_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_37_ta_ph = bevp_ntypes.bem_MULTIPLYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_37_ta_ph);
bevt_38_ta_ph = (new BEC_2_4_3_MathInt(46));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_38_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_39_ta_ph = bevp_ntypes.bem_DOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_3_MathInt(32));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_40_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_41_ta_ph = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_41_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_3_MathInt(9));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_42_ta_ph);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_43_ta_ph = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_43_ta_ph);
bevt_44_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_ntok = bevt_44_ta_ph.bem_crGet_0();
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_45_ta_ph = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_45_ta_ph);
bevt_46_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_ntok = bevt_46_ta_ph.bem_lfGet_0();
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_47_ta_ph = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_47_ta_ph);
bevp_rwords = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_48_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_45));
bevt_49_ta_ph = bevp_ntypes.bem_USEGet_0();
bevp_rwords.bem_put_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_50_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_46));
bevt_51_ta_ph = bevp_ntypes.bem_ASGet_0();
bevp_rwords.bem_put_2(bevt_50_ta_ph, bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_47));
bevt_53_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevp_rwords.bem_put_2(bevt_52_ta_ph, bevt_53_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_48));
bevt_55_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevp_rwords.bem_put_2(bevt_54_ta_ph, bevt_55_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_49));
bevt_57_ta_ph = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_56_ta_ph, bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_50));
bevt_59_ta_ph = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_58_ta_ph, bevt_59_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_51));
bevt_61_ta_ph = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_60_ta_ph, bevt_61_ta_ph);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_52));
bevt_63_ta_ph = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_62_ta_ph, bevt_63_ta_ph);
bevt_64_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_53));
bevt_65_ta_ph = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_64_ta_ph, bevt_65_ta_ph);
bevt_66_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_54));
bevt_67_ta_ph = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_66_ta_ph, bevt_67_ta_ph);
bevt_68_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_55));
bevt_69_ta_ph = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_68_ta_ph, bevt_69_ta_ph);
bevt_70_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_56));
bevt_71_ta_ph = bevp_ntypes.bem_ELIFGet_0();
bevp_rwords.bem_put_2(bevt_70_ta_ph, bevt_71_ta_ph);
bevt_72_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_57));
bevt_73_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevp_rwords.bem_put_2(bevt_72_ta_ph, bevt_73_ta_ph);
bevt_74_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_58));
bevt_75_ta_ph = bevp_ntypes.bem_FINALLYGet_0();
bevp_rwords.bem_put_2(bevt_74_ta_ph, bevt_75_ta_ph);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_59));
bevt_77_ta_ph = bevp_ntypes.bem_LOOPGet_0();
bevp_rwords.bem_put_2(bevt_76_ta_ph, bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_60));
bevt_79_ta_ph = bevp_ntypes.bem_FIELDSGet_0();
bevp_rwords.bem_put_2(bevt_78_ta_ph, bevt_79_ta_ph);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_61));
bevt_81_ta_ph = bevp_ntypes.bem_SLOTSGet_0();
bevp_rwords.bem_put_2(bevt_80_ta_ph, bevt_81_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_62));
bevt_83_ta_ph = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_82_ta_ph, bevt_83_ta_ph);
bevt_84_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_63));
bevt_85_ta_ph = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_84_ta_ph, bevt_85_ta_ph);
bevt_86_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_64));
bevt_87_ta_ph = bevp_ntypes.bem_FORGet_0();
bevp_rwords.bem_put_2(bevt_86_ta_ph, bevt_87_ta_ph);
bevt_88_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_65));
bevt_89_ta_ph = bevp_ntypes.bem_INGet_0();
bevp_rwords.bem_put_2(bevt_88_ta_ph, bevt_89_ta_ph);
bevt_90_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_66));
bevt_91_ta_ph = bevp_ntypes.bem_EMITGet_0();
bevp_rwords.bem_put_2(bevt_90_ta_ph, bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_67));
bevt_93_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_92_ta_ph, bevt_93_ta_ph);
bevt_94_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_68));
bevt_95_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_94_ta_ph, bevt_95_ta_ph);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_69));
bevt_97_ta_ph = bevp_ntypes.bem_BREAKGet_0();
bevp_rwords.bem_put_2(bevt_96_ta_ph, bevt_97_ta_ph);
bevt_98_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_70));
bevt_99_ta_ph = bevp_ntypes.bem_CONTINUEGet_0();
bevp_rwords.bem_put_2(bevt_98_ta_ph, bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_71));
bevt_101_ta_ph = bevp_ntypes.bem_NULLGet_0();
bevp_rwords.bem_put_2(bevt_100_ta_ph, bevt_101_ta_ph);
bevt_102_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_72));
bevt_103_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevp_rwords.bem_put_2(bevt_102_ta_ph, bevt_103_ta_ph);
bevt_104_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_73));
bevt_105_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevp_rwords.bem_put_2(bevt_104_ta_ph, bevt_105_ta_ph);
bevt_106_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_74));
bevt_107_ta_ph = bevp_ntypes.bem_TRYGet_0();
bevp_rwords.bem_put_2(bevt_106_ta_ph, bevt_107_ta_ph);
bevt_108_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_75));
bevt_109_ta_ph = bevp_ntypes.bem_CATCHGet_0();
bevp_rwords.bem_put_2(bevt_108_ta_ph, bevt_109_ta_ph);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() throws Throwable {
return bevp_matchMap;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() throws Throwable {
return bevp_rwords;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxargsGet_0() throws Throwable {
return bevp_maxargs;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_maxargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_maxargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_extraSlotsGet_0() throws Throwable {
return bevp_extraSlots;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_extraSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extraSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxPadGet_0() throws Throwable {
return bevp_mtdxPad;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_mtdxPadSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mtdxPad = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindToGet_0() throws Throwable {
return bevp_unwindTo;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindToSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unwindTo = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindOkGet_0() throws Throwable {
return bevp_unwindOk;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindOkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unwindOk = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operGet_0() throws Throwable {
return bevp_oper;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_oper = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operNamesGet_0() throws Throwable {
return bevp_operNames;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_operNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_conTypesGet_0() throws Throwable {
return bevp_conTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_conTypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_conTypes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_parensReqGet_0() throws Throwable {
return bevp_parensReq;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_parensReqSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parensReq = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anchorTypesGet_0() throws Throwable {
return bevp_anchorTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_anchorTypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 21, 22, 23, 24, 25, 26, 27, 28, 29, 33, 33, 33, 35, 35, 35, 36, 36, 36, 37, 37, 37, 39, 39, 39, 40, 40, 40, 41, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 51, 51, 51, 52, 52, 52, 53, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 58, 58, 58, 59, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 65, 65, 65, 66, 66, 66, 67, 67, 67, 69, 69, 69, 70, 70, 70, 71, 71, 71, 72, 72, 72, 73, 73, 73, 74, 74, 74, 75, 75, 75, 76, 76, 76, 77, 77, 77, 78, 78, 78, 79, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83, 83, 84, 84, 84, 85, 85, 85, 86, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 89, 90, 90, 90, 91, 91, 91, 92, 92, 92, 93, 93, 93, 94, 94, 94, 95, 95, 95, 96, 96, 96, 97, 97, 97, 99, 99, 99, 100, 100, 100, 101, 101, 101, 102, 102, 102, 103, 103, 103, 104, 104, 104, 105, 105, 105, 106, 106, 106, 107, 107, 107, 108, 108, 108, 109, 109, 109, 110, 110, 110, 111, 111, 111, 112, 112, 112, 113, 113, 113, 114, 114, 114, 115, 115, 115, 116, 116, 116, 117, 117, 117, 118, 118, 118, 119, 119, 119, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 127, 127, 127, 128, 128, 128, 129, 129, 129, 131, 131, 131, 132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 136, 136, 136, 138, 144, 145, 147, 148, 148, 149, 149, 151, 152, 153, 153, 155, 156, 157, 157, 159, 160, 161, 161, 163, 164, 165, 165, 167, 168, 169, 169, 171, 172, 173, 173, 175, 176, 177, 177, 179, 180, 181, 181, 183, 184, 185, 185, 187, 188, 189, 189, 193, 193, 195, 196, 196, 198, 198, 200, 201, 201, 203, 203, 205, 206, 206, 208, 208, 210, 211, 211, 213, 213, 215, 216, 216, 218, 218, 220, 221, 221, 223, 223, 225, 226, 226, 228, 228, 230, 231, 231, 233, 233, 235, 236, 236, 238, 238, 240, 241, 241, 243, 243, 245, 246, 246, 248, 248, 250, 251, 251, 253, 253, 255, 256, 256, 258, 258, 260, 261, 261, 263, 263, 265, 266, 266, 268, 268, 270, 271, 271, 273, 273, 275, 276, 276, 278, 278, 280, 281, 281, 284, 285, 285, 285, 286, 286, 286, 287, 287, 287, 288, 288, 288, 289, 289, 289, 290, 290, 290, 291, 291, 291, 292, 292, 292, 293, 293, 293, 294, 294, 294, 295, 295, 295, 296, 296, 296, 297, 297, 297, 298, 298, 298, 299, 299, 299, 300, 300, 300, 301, 301, 301, 302, 302, 302, 303, 303, 303, 304, 304, 304, 305, 305, 305, 306, 306, 306, 307, 307, 307, 308, 308, 308, 309, 309, 309, 310, 310, 310, 311, 311, 311, 312, 312, 312, 313, 313, 313, 314, 314, 314, 315, 315, 315, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 953, 956, 960, 963, 967, 970, 974, 977, 981, 984, 988, 991, 995, 998, 1002, 1005, 1009, 1012, 1016, 1019, 1023, 1026, 1030, 1033, 1037, 1040, 1044, 1047};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 298
new 0 17 298
assign 1 18 299
new 0 18 299
assign 1 21 300
new 0 21 300
assign 1 22 301
new 0 22 301
assign 1 23 302
new 0 23 302
assign 1 24 303
new 0 24 303
assign 1 25 304
new 0 25 304
assign 1 26 305
new 0 26 305
assign 1 27 306
new 0 27 306
assign 1 28 307
new 0 28 307
assign 1 29 308
new 0 29 308
assign 1 33 309
new 0 33 309
assign 1 33 310
new 0 33 310
put 2 33 311
assign 1 35 312
new 0 35 312
assign 1 35 313
new 0 35 313
put 2 35 314
assign 1 36 315
new 0 36 315
assign 1 36 316
new 0 36 316
put 2 36 317
assign 1 37 318
new 0 37 318
assign 1 37 319
new 0 37 319
put 2 37 320
assign 1 39 321
NOTGet 0 39 321
assign 1 39 322
new 0 39 322
put 2 39 323
assign 1 40 324
INCREMENTGet 0 40 324
assign 1 40 325
new 0 40 325
put 2 40 326
assign 1 41 327
DECREMENTGet 0 41 327
assign 1 41 328
new 0 41 328
put 2 41 329
assign 1 42 330
INCREMENT_ASSIGNGet 0 42 330
assign 1 42 331
new 0 42 331
put 2 42 332
assign 1 43 333
DECREMENT_ASSIGNGet 0 43 333
assign 1 43 334
new 0 43 334
put 2 43 335
assign 1 44 336
MULTIPLYGet 0 44 336
assign 1 44 337
new 0 44 337
put 2 44 338
assign 1 45 339
DIVIDEGet 0 45 339
assign 1 45 340
new 0 45 340
put 2 45 341
assign 1 46 342
MODULUSGet 0 46 342
assign 1 46 343
new 0 46 343
put 2 46 344
assign 1 47 345
ADDGet 0 47 345
assign 1 47 346
new 0 47 346
put 2 47 347
assign 1 48 348
SUBTRACTGet 0 48 348
assign 1 48 349
new 0 48 349
put 2 48 350
assign 1 49 351
GREATERGet 0 49 351
assign 1 49 352
new 0 49 352
put 2 49 353
assign 1 50 354
GREATER_EQUALSGet 0 50 354
assign 1 50 355
new 0 50 355
put 2 50 356
assign 1 51 357
LESSERGet 0 51 357
assign 1 51 358
new 0 51 358
put 2 51 359
assign 1 52 360
LESSER_EQUALSGet 0 52 360
assign 1 52 361
new 0 52 361
put 2 52 362
assign 1 53 363
EQUALSGet 0 53 363
assign 1 53 364
new 0 53 364
put 2 53 365
assign 1 54 366
NOT_EQUALSGet 0 54 366
assign 1 54 367
new 0 54 367
put 2 54 368
assign 1 55 369
ANDGet 0 55 369
assign 1 55 370
new 0 55 370
put 2 55 371
assign 1 56 372
ORGet 0 56 372
assign 1 56 373
new 0 56 373
put 2 56 374
assign 1 57 375
LOGICAL_ANDGet 0 57 375
assign 1 57 376
new 0 57 376
put 2 57 377
assign 1 58 378
LOGICAL_ORGet 0 58 378
assign 1 58 379
new 0 58 379
put 2 58 380
assign 1 59 381
INGet 0 59 381
assign 1 59 382
new 0 59 382
put 2 59 383
assign 1 60 384
ADD_ASSIGNGet 0 60 384
assign 1 60 385
new 0 60 385
put 2 60 386
assign 1 61 387
SUBTRACT_ASSIGNGet 0 61 387
assign 1 61 388
new 0 61 388
put 2 61 389
assign 1 62 390
MULTIPLY_ASSIGNGet 0 62 390
assign 1 62 391
new 0 62 391
put 2 62 392
assign 1 63 393
DIVIDE_ASSIGNGet 0 63 393
assign 1 63 394
new 0 63 394
put 2 63 395
assign 1 64 396
MODULUS_ASSIGNGet 0 64 396
assign 1 64 397
new 0 64 397
put 2 64 398
assign 1 65 399
AND_ASSIGNGet 0 65 399
assign 1 65 400
new 0 65 400
put 2 65 401
assign 1 66 402
OR_ASSIGNGet 0 66 402
assign 1 66 403
new 0 66 403
put 2 66 404
assign 1 67 405
ASSIGNGet 0 67 405
assign 1 67 406
new 0 67 406
put 2 67 407
assign 1 69 408
NOTGet 0 69 408
assign 1 69 409
new 0 69 409
put 2 69 410
assign 1 70 411
INCREMENTGet 0 70 411
assign 1 70 412
new 0 70 412
put 2 70 413
assign 1 71 414
DECREMENTGet 0 71 414
assign 1 71 415
new 0 71 415
put 2 71 416
assign 1 72 417
MULTIPLYGet 0 72 417
assign 1 72 418
new 0 72 418
put 2 72 419
assign 1 73 420
DIVIDEGet 0 73 420
assign 1 73 421
new 0 73 421
put 2 73 422
assign 1 74 423
MODULUSGet 0 74 423
assign 1 74 424
new 0 74 424
put 2 74 425
assign 1 75 426
ADDGet 0 75 426
assign 1 75 427
new 0 75 427
put 2 75 428
assign 1 76 429
SUBTRACTGet 0 76 429
assign 1 76 430
new 0 76 430
put 2 76 431
assign 1 77 432
GREATERGet 0 77 432
assign 1 77 433
new 0 77 433
put 2 77 434
assign 1 78 435
GREATER_EQUALSGet 0 78 435
assign 1 78 436
new 0 78 436
put 2 78 437
assign 1 79 438
LESSERGet 0 79 438
assign 1 79 439
new 0 79 439
put 2 79 440
assign 1 80 441
LESSER_EQUALSGet 0 80 441
assign 1 80 442
new 0 80 442
put 2 80 443
assign 1 81 444
EQUALSGet 0 81 444
assign 1 81 445
new 0 81 445
put 2 81 446
assign 1 82 447
NOT_EQUALSGet 0 82 447
assign 1 82 448
new 0 82 448
put 2 82 449
assign 1 83 450
ANDGet 0 83 450
assign 1 83 451
new 0 83 451
put 2 83 452
assign 1 84 453
ORGet 0 84 453
assign 1 84 454
new 0 84 454
put 2 84 455
assign 1 85 456
LOGICAL_ANDGet 0 85 456
assign 1 85 457
new 0 85 457
put 2 85 458
assign 1 86 459
LOGICAL_ORGet 0 86 459
assign 1 86 460
new 0 86 460
put 2 86 461
assign 1 87 462
INGet 0 87 462
assign 1 87 463
new 0 87 463
put 2 87 464
assign 1 88 465
ADD_ASSIGNGet 0 88 465
assign 1 88 466
new 0 88 466
put 2 88 467
assign 1 89 468
SUBTRACT_ASSIGNGet 0 89 468
assign 1 89 469
new 0 89 469
put 2 89 470
assign 1 90 471
INCREMENT_ASSIGNGet 0 90 471
assign 1 90 472
new 0 90 472
put 2 90 473
assign 1 91 474
DECREMENT_ASSIGNGet 0 91 474
assign 1 91 475
new 0 91 475
put 2 91 476
assign 1 92 477
MULTIPLY_ASSIGNGet 0 92 477
assign 1 92 478
new 0 92 478
put 2 92 479
assign 1 93 480
DIVIDE_ASSIGNGet 0 93 480
assign 1 93 481
new 0 93 481
put 2 93 482
assign 1 94 483
MODULUS_ASSIGNGet 0 94 483
assign 1 94 484
new 0 94 484
put 2 94 485
assign 1 95 486
AND_ASSIGNGet 0 95 486
assign 1 95 487
new 0 95 487
put 2 95 488
assign 1 96 489
OR_ASSIGNGet 0 96 489
assign 1 96 490
new 0 96 490
put 2 96 491
assign 1 97 492
ASSIGNGet 0 97 492
assign 1 97 493
new 0 97 493
put 2 97 494
assign 1 99 495
IFGet 0 99 495
assign 1 99 496
new 0 99 496
put 2 99 497
assign 1 100 498
ELIFGet 0 100 498
assign 1 100 499
new 0 100 499
put 2 100 500
assign 1 101 501
WHILEGet 0 101 501
assign 1 101 502
new 0 101 502
put 2 101 503
assign 1 102 504
FORGet 0 102 504
assign 1 102 505
new 0 102 505
put 2 102 506
assign 1 103 507
FOREACHGet 0 103 507
assign 1 103 508
new 0 103 508
put 2 103 509
assign 1 104 510
EMITGet 0 104 510
assign 1 104 511
new 0 104 511
put 2 104 512
assign 1 105 513
IFEMITGet 0 105 513
assign 1 105 514
new 0 105 514
put 2 105 515
assign 1 106 516
METHODGet 0 106 516
assign 1 106 517
new 0 106 517
put 2 106 518
assign 1 107 519
CLASSGet 0 107 519
assign 1 107 520
new 0 107 520
put 2 107 521
assign 1 108 522
EXPRGet 0 108 522
assign 1 108 523
new 0 108 523
put 2 108 524
assign 1 109 525
ELSEGet 0 109 525
assign 1 109 526
new 0 109 526
put 2 109 527
assign 1 110 528
FINALLYGet 0 110 528
assign 1 110 529
new 0 110 529
put 2 110 530
assign 1 111 531
TRYGet 0 111 531
assign 1 111 532
new 0 111 532
put 2 111 533
assign 1 112 534
LOOPGet 0 112 534
assign 1 112 535
new 0 112 535
put 2 112 536
assign 1 113 537
FIELDSGet 0 113 537
assign 1 113 538
new 0 113 538
put 2 113 539
assign 1 114 540
SLOTSGet 0 114 540
assign 1 114 541
new 0 114 541
put 2 114 542
assign 1 115 543
CATCHGet 0 115 543
assign 1 115 544
new 0 115 544
put 2 115 545
assign 1 116 546
TRANSUNITGet 0 116 546
assign 1 116 547
new 0 116 547
put 2 116 548
assign 1 117 549
BRACESGet 0 117 549
assign 1 117 550
new 0 117 550
put 2 117 551
assign 1 118 552
PARENSGet 0 118 552
assign 1 118 553
new 0 118 553
put 2 118 554
assign 1 119 555
IDXGet 0 119 555
assign 1 119 556
new 0 119 556
put 2 119 557
assign 1 121 558
IFGet 0 121 558
assign 1 121 559
new 0 121 559
put 2 121 560
assign 1 122 561
ELIFGet 0 122 561
assign 1 122 562
new 0 122 562
put 2 122 563
assign 1 123 564
WHILEGet 0 123 564
assign 1 123 565
new 0 123 565
put 2 123 566
assign 1 124 567
FORGet 0 124 567
assign 1 124 568
new 0 124 568
put 2 124 569
assign 1 125 570
FOREACHGet 0 125 570
assign 1 125 571
new 0 125 571
put 2 125 572
assign 1 126 573
EMITGet 0 126 573
assign 1 126 574
new 0 126 574
put 2 126 575
assign 1 127 576
IFEMITGet 0 127 576
assign 1 127 577
new 0 127 577
put 2 127 578
assign 1 128 579
METHODGet 0 128 579
assign 1 128 580
new 0 128 580
put 2 128 581
assign 1 129 582
CATCHGet 0 129 582
assign 1 129 583
new 0 129 583
put 2 129 584
assign 1 131 585
IFGet 0 131 585
assign 1 131 586
new 0 131 586
put 2 131 587
assign 1 132 588
ELIFGet 0 132 588
assign 1 132 589
new 0 132 589
put 2 132 590
assign 1 133 591
WHILEGet 0 133 591
assign 1 133 592
new 0 133 592
put 2 133 593
assign 1 134 594
FORGet 0 134 594
assign 1 134 595
new 0 134 595
put 2 134 596
assign 1 135 597
FOREACHGet 0 135 597
assign 1 135 598
new 0 135 598
put 2 135 599
assign 1 136 600
EXPRGet 0 136 600
assign 1 136 601
new 0 136 601
put 2 136 602
prepare 0 138 603
assign 1 144 719
new 0 144 719
assign 1 145 720
new 0 145 720
assign 1 147 721
new 0 147 721
assign 1 148 722
new 0 148 722
assign 1 148 723
new 2 148 723
assign 1 149 724
DIVIDEGet 0 149 724
put 2 149 725
assign 1 151 726
new 0 151 726
addToken 1 152 727
assign 1 153 728
BRACESGet 0 153 728
put 2 153 729
assign 1 155 730
new 0 155 730
addToken 1 156 731
assign 1 157 732
RBRACESGet 0 157 732
put 2 157 733
assign 1 159 734
new 0 159 734
addToken 1 160 735
assign 1 161 736
PARENSGet 0 161 736
put 2 161 737
assign 1 163 738
new 0 163 738
addToken 1 164 739
assign 1 165 740
RPARENSGet 0 165 740
put 2 165 741
assign 1 167 742
new 0 167 742
addToken 1 168 743
assign 1 169 744
SEMIGet 0 169 744
put 2 169 745
assign 1 171 746
new 0 171 746
addToken 1 172 747
assign 1 173 748
COLONGet 0 173 748
put 2 173 749
assign 1 175 750
new 0 175 750
addToken 1 176 751
assign 1 177 752
COMMAGet 0 177 752
put 2 177 753
assign 1 179 754
new 0 179 754
addToken 1 180 755
assign 1 181 756
ADDGet 0 181 756
put 2 181 757
assign 1 183 758
new 0 183 758
addToken 1 184 759
assign 1 185 760
ATYPEGet 0 185 760
put 2 185 761
assign 1 187 762
new 0 187 762
addToken 1 188 763
assign 1 189 764
SUBTRACTGet 0 189 764
put 2 189 765
assign 1 193 766
new 0 193 766
assign 1 193 767
codeNew 1 193 767
addToken 1 195 768
assign 1 196 769
FSLASHGet 0 196 769
put 2 196 770
assign 1 198 771
new 0 198 771
assign 1 198 772
codeNew 1 198 772
addToken 1 200 773
assign 1 201 774
STRQGet 0 201 774
put 2 201 775
assign 1 203 776
new 0 203 776
assign 1 203 777
codeNew 1 203 777
addToken 1 205 778
assign 1 206 779
WSTRQGet 0 206 779
put 2 206 780
assign 1 208 781
new 0 208 781
assign 1 208 782
codeNew 1 208 782
addToken 1 210 783
assign 1 211 784
IDXGet 0 211 784
put 2 211 785
assign 1 213 786
new 0 213 786
assign 1 213 787
codeNew 1 213 787
addToken 1 215 788
assign 1 216 789
RIDXGet 0 216 789
put 2 216 790
assign 1 218 791
new 0 218 791
assign 1 218 792
codeNew 1 218 792
addToken 1 220 793
assign 1 221 794
MODULUSGet 0 221 794
put 2 221 795
assign 1 223 796
new 0 223 796
assign 1 223 797
codeNew 1 223 797
addToken 1 225 798
assign 1 226 799
ASSIGNGet 0 226 799
put 2 226 800
assign 1 228 801
new 0 228 801
assign 1 228 802
codeNew 1 228 802
addToken 1 230 803
assign 1 231 804
GREATERGet 0 231 804
put 2 231 805
assign 1 233 806
new 0 233 806
assign 1 233 807
codeNew 1 233 807
addToken 1 235 808
assign 1 236 809
LESSERGet 0 236 809
put 2 236 810
assign 1 238 811
new 0 238 811
assign 1 238 812
codeNew 1 238 812
addToken 1 240 813
assign 1 241 814
NOTGet 0 241 814
put 2 241 815
assign 1 243 816
new 0 243 816
assign 1 243 817
codeNew 1 243 817
addToken 1 245 818
assign 1 246 819
ANDGet 0 246 819
put 2 246 820
assign 1 248 821
new 0 248 821
assign 1 248 822
codeNew 1 248 822
addToken 1 250 823
assign 1 251 824
ORGet 0 251 824
put 2 251 825
assign 1 253 826
new 0 253 826
assign 1 253 827
codeNew 1 253 827
addToken 1 255 828
assign 1 256 829
MULTIPLYGet 0 256 829
put 2 256 830
assign 1 258 831
new 0 258 831
assign 1 258 832
codeNew 1 258 832
addToken 1 260 833
assign 1 261 834
DOTGet 0 261 834
put 2 261 835
assign 1 263 836
new 0 263 836
assign 1 263 837
codeNew 1 263 837
addToken 1 265 838
assign 1 266 839
SPACEGet 0 266 839
put 2 266 840
assign 1 268 841
new 0 268 841
assign 1 268 842
codeNew 1 268 842
addToken 1 270 843
assign 1 271 844
SPACEGet 0 271 844
put 2 271 845
assign 1 273 846
new 0 273 846
assign 1 273 847
crGet 0 273 847
addToken 1 275 848
assign 1 276 849
NEWLINEGet 0 276 849
put 2 276 850
assign 1 278 851
new 0 278 851
assign 1 278 852
lfGet 0 278 852
addToken 1 280 853
assign 1 281 854
NEWLINEGet 0 281 854
put 2 281 855
assign 1 284 856
new 0 284 856
assign 1 285 857
new 0 285 857
assign 1 285 858
USEGet 0 285 858
put 2 285 859
assign 1 286 860
new 0 286 860
assign 1 286 861
ASGet 0 286 861
put 2 286 862
assign 1 287 863
new 0 287 863
assign 1 287 864
CLASSGet 0 287 864
put 2 287 865
assign 1 288 866
new 0 288 866
assign 1 288 867
METHODGet 0 288 867
put 2 288 868
assign 1 289 869
new 0 289 869
assign 1 289 870
DEFMODGet 0 289 870
put 2 289 871
assign 1 290 872
new 0 290 872
assign 1 290 873
DEFMODGet 0 290 873
put 2 290 874
assign 1 291 875
new 0 291 875
assign 1 291 876
DEFMODGet 0 291 876
put 2 291 877
assign 1 292 878
new 0 292 878
assign 1 292 879
VARGet 0 292 879
put 2 292 880
assign 1 293 881
new 0 293 881
assign 1 293 882
VARGet 0 293 882
put 2 293 883
assign 1 294 884
new 0 294 884
assign 1 294 885
IFGet 0 294 885
put 2 294 886
assign 1 295 887
new 0 295 887
assign 1 295 888
IFGet 0 295 888
put 2 295 889
assign 1 296 890
new 0 296 890
assign 1 296 891
ELIFGet 0 296 891
put 2 296 892
assign 1 297 893
new 0 297 893
assign 1 297 894
ELSEGet 0 297 894
put 2 297 895
assign 1 298 896
new 0 298 896
assign 1 298 897
FINALLYGet 0 298 897
put 2 298 898
assign 1 299 899
new 0 299 899
assign 1 299 900
LOOPGet 0 299 900
put 2 299 901
assign 1 300 902
new 0 300 902
assign 1 300 903
FIELDSGet 0 300 903
put 2 300 904
assign 1 301 905
new 0 301 905
assign 1 301 906
SLOTSGet 0 301 906
put 2 301 907
assign 1 302 908
new 0 302 908
assign 1 302 909
WHILEGet 0 302 909
put 2 302 910
assign 1 303 911
new 0 303 911
assign 1 303 912
WHILEGet 0 303 912
put 2 303 913
assign 1 304 914
new 0 304 914
assign 1 304 915
FORGet 0 304 915
put 2 304 916
assign 1 305 917
new 0 305 917
assign 1 305 918
INGet 0 305 918
put 2 305 919
assign 1 306 920
new 0 306 920
assign 1 306 921
EMITGet 0 306 921
put 2 306 922
assign 1 307 923
new 0 307 923
assign 1 307 924
IFEMITGet 0 307 924
put 2 307 925
assign 1 308 926
new 0 308 926
assign 1 308 927
IFEMITGet 0 308 927
put 2 308 928
assign 1 309 929
new 0 309 929
assign 1 309 930
BREAKGet 0 309 930
put 2 309 931
assign 1 310 932
new 0 310 932
assign 1 310 933
CONTINUEGet 0 310 933
put 2 310 934
assign 1 311 935
new 0 311 935
assign 1 311 936
NULLGet 0 311 936
put 2 311 937
assign 1 312 938
new 0 312 938
assign 1 312 939
TRUEGet 0 312 939
put 2 312 940
assign 1 313 941
new 0 313 941
assign 1 313 942
FALSEGet 0 313 942
put 2 313 943
assign 1 314 944
new 0 314 944
assign 1 314 945
TRYGet 0 314 945
put 2 314 946
assign 1 315 947
new 0 315 947
assign 1 315 948
CATCHGet 0 315 948
put 2 315 949
return 1 0 953
assign 1 0 956
return 1 0 960
assign 1 0 963
return 1 0 967
assign 1 0 970
return 1 0 974
assign 1 0 977
return 1 0 981
assign 1 0 984
return 1 0 988
assign 1 0 991
return 1 0 995
assign 1 0 998
return 1 0 1002
assign 1 0 1005
return 1 0 1009
assign 1 0 1012
return 1 0 1016
assign 1 0 1019
return 1 0 1023
assign 1 0 1026
return 1 0 1030
assign 1 0 1033
return 1 0 1037
assign 1 0 1040
return 1 0 1044
assign 1 0 1047
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1990469129: return bem_twtokGet_0();
case 325753994: return bem_operGet_0();
case 1136025958: return bem_unwindOkGet_0();
case 1856881175: return bem_parensReqGet_0();
case -614880093: return bem_matchMapGet_0();
case -1967481250: return bem_hashGet_0();
case -1545451149: return bem_ntypesGet_0();
case -1469725455: return bem_maxargsGet_0();
case -1349172195: return bem_extraSlotsGet_0();
case 186551951: return bem_toString_0();
case 1922244281: return bem_operNamesGet_0();
case 1890623763: return bem_copy_0();
case -662849767: return bem_unwindToGet_0();
case 1850061638: return bem_conTypesGet_0();
case -643744552: return bem_iteratorGet_0();
case 2139846672: return bem_print_0();
case 293180816: return bem_mtdxPadGet_0();
case -1115198082: return bem_prepare_0();
case 1515047198: return bem_create_0();
case 670650041: return bem_new_0();
case -15145131: return bem_rwordsGet_0();
case -87153082: return bem_anchorTypesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1882156513: return bem_copyTo_1(bevd_0);
case -634716339: return bem_unwindOkSet_1(bevd_0);
case -485935447: return bem_new_1(bevd_0);
case -1583823897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1269852972: return bem_extraSlotsSet_1(bevd_0);
case 979449614: return bem_unwindToSet_1(bevd_0);
case 1273966288: return bem_twtokSet_1(bevd_0);
case -44126037: return bem_ntypesSet_1(bevd_0);
case 1486162682: return bem_maxargsSet_1(bevd_0);
case -1225169978: return bem_anchorTypesSet_1(bevd_0);
case 303989887: return bem_parensReqSet_1(bevd_0);
case -1829697728: return bem_matchMapSet_1(bevd_0);
case 640799027: return bem_mtdxPadSet_1(bevd_0);
case -1876852691: return bem_def_1(bevd_0);
case 1041331381: return bem_undef_1(bevd_0);
case 872046853: return bem_conTypesSet_1(bevd_0);
case 7869303: return bem_equals_1(bevd_0);
case 951741113: return bem_notEquals_1(bevd_0);
case -249999978: return bem_operSet_1(bevd_0);
case -397824524: return bem_rwordsSet_1(bevd_0);
case 214892348: return bem_operNamesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1779285405: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 582832509: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -881314990: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1602342275: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1686414234: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildConstants_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildConstants_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildConstants();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_inst = (BEC_2_5_9_BuildConstants) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_type;
}
}
