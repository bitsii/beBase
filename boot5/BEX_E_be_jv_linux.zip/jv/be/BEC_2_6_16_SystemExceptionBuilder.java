package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_16_SystemExceptionBuilder extends BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
public static BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;

public static BET_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;

public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public BEC_2_6_16_SystemExceptionBuilder bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() throws Throwable {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) throws Throwable {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_klass == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 161*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 161*/ {
if (beva_eline == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 161*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 161*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 161*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 161*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(-1));
return bevt_3_ta_ph;
} /* Line: 163*/
bevl_line = (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toJvString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_ex == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_6_16_SystemExceptionBuilder_bels_0));
bevt_1_ta_ph.bem_print_0();
} /* Line: 198*/
 else /* Line: 199*/ {
try /* Line: 200*/ {
beva_ex.bemd_0(-469226465);
} /* Line: 201*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_6_16_SystemExceptionBuilder_bels_1));
bevt_2_ta_ph.bem_print_0();
} /* Line: 203*/
} /* Line: 202*/
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 210*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_6_16_SystemExceptionBuilder_bels_0));
bevt_1_ta_ph.bem_print_0();
} /* Line: 211*/
 else /* Line: 212*/ {
try /* Line: 213*/ {
} /* Line: 213*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_6_16_SystemExceptionBuilder_bels_1));
bevt_2_ta_ph.bem_print_0();
} /* Line: 216*/
} /* Line: 215*/
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_passBack == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 222*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_passBack, bevp_except);
if (bevt_2_ta_ph.bevi_bool)/* Line: 222*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 222*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 222*/
 else /* Line: 222*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 222*/ {
beva_passBack.bemd_1(1892776386, beva_sinClass);
beva_passBack.bemd_1(1743489438, beva_sinMtd);
beva_passBack.bemd_1(-1982815380, beva_sfname);
beva_passBack.bemd_1(2078475142, beva_ilinep);
} /* Line: 226*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() throws Throwable {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_except = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_int = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() throws Throwable {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lastStr = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {152, 153, 161, 161, 0, 161, 161, 0, 0, 163, 163, 166, 192, 197, 197, 198, 198, 201, 203, 203, 209, 210, 210, 211, 211, 216, 216, 222, 222, 222, 222, 0, 0, 0, 223, 224, 225, 226, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 30, 35, 36, 39, 44, 45, 48, 52, 53, 55, 60, 67, 72, 73, 74, 78, 82, 83, 93, 94, 99, 100, 101, 108, 109, 119, 124, 125, 126, 128, 131, 135, 138, 139, 140, 141, 146, 149, 153, 156, 160, 163};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 152 20
new 0 152 20
assign 1 153 21
new 0 153 21
assign 1 161 30
undef 1 161 35
assign 1 0 36
assign 1 161 39
undef 1 161 44
assign 1 0 45
assign 1 0 48
assign 1 163 52
new 0 163 52
return 1 163 53
assign 1 166 55
new 0 166 55
return 1 192 60
assign 1 197 67
undef 1 197 72
assign 1 198 73
new 0 198 73
print 0 198 74
print 0 201 78
assign 1 203 82
new 0 203 82
print 0 203 83
assign 1 209 93
assign 1 210 94
undef 1 210 99
assign 1 211 100
new 0 211 100
print 0 211 101
assign 1 216 108
new 0 216 108
print 0 216 109
assign 1 222 119
def 1 222 124
assign 1 222 125
new 0 222 125
assign 1 222 126
sameType 2 222 126
assign 1 0 128
assign 1 0 131
assign 1 0 135
klassNameSet 1 223 138
methodNameSet 1 224 139
fileNameSet 1 225 140
lineNumberSet 1 226 141
return 1 0 146
assign 1 0 149
return 1 0 153
assign 1 0 156
return 1 0 160
assign 1 0 163
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 81507506: return bem_lastStrGet_0();
case 1689571156: return bem_default_0();
case 1327010431: return bem_hashGet_0();
case 1318937193: return bem_create_0();
case 2120153411: return bem_copy_0();
case 1769965429: return bem_toString_0();
case 906681710: return bem_intGet_0();
case -469226465: return bem_print_0();
case 532380883: return bem_new_0();
case 1746691966: return bem_exceptGet_0();
case 966722567: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -268811991: return bem_equals_1(bevd_0);
case 327518282: return bem_sendToConsole_1(bevd_0);
case 973802552: return bem_exceptSet_1(bevd_0);
case -16136112: return bem_notEquals_1(bevd_0);
case -533094380: return bem_undef_1(bevd_0);
case 1534827239: return bem_lastStrSet_1(bevd_0);
case 194087617: return bem_intSet_1(bevd_0);
case 1194286113: return bem_def_1(bevd_0);
case 1765763062: return bem_printException_1(bevd_0);
case 2147027771: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -506503217: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1665151698: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 792362948: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -672637344: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1688602503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) throws Throwable {
switch (callId) {
case -159400053: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return super.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;
}
}
