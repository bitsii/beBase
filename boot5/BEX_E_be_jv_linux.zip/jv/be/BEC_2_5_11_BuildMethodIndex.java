package be;
/* IO:File: source/build/EmitData.be */
public final class BEC_2_5_11_BuildMethodIndex extends BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildMethodIndex() { }
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static BEC_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;

public static BET_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_type;

public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildMtdSyn bevp_msyn;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_11_BuildMethodIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildMtdSyn beva__msyn) throws Throwable {
bevp_syn = beva__syn;
bevp_msyn = beva__msyn;
bevp_declaration = bevp_msyn.bem_declarationGet_0();
bevp_name = bevp_msyn.bem_nameGet_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_declaration.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_4_tmpany_phold = bem_sameClass_1(beva_x);
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 111 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 111 */
bevt_7_tmpany_phold = beva_x.bemd_0(-895545597);
bevt_6_tmpany_phold = bevp_declaration.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_9_tmpany_phold = beva_x.bemd_0(831773166);
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 112 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 112 */
 else  /* Line: 112 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 112 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 113 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildMethodIndex bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_msynGet_0() throws Throwable {
return bevp_msyn;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_msynGetDirect_0() throws Throwable {
return bevp_msyn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_msynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildMethodIndex bem_msynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_declarationGetDirect_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildMethodIndex bem_declarationSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildMethodIndex bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {99, 100, 101, 102, 107, 107, 107, 107, 111, 111, 0, 111, 111, 111, 0, 0, 111, 111, 112, 112, 112, 112, 0, 0, 0, 113, 113, 115, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 26, 27, 28, 29, 44, 49, 50, 53, 54, 59, 60, 63, 67, 68, 70, 71, 73, 74, 76, 79, 83, 86, 87, 89, 90, 93, 96, 99, 103, 107, 110, 113, 117, 121, 124, 127, 131, 135, 138, 141, 145};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 99 16
assign 1 100 17
assign 1 101 18
declarationGet 0 101 18
assign 1 102 19
nameGet 0 102 19
assign 1 107 26
toString 0 107 26
assign 1 107 27
add 1 107 27
assign 1 107 28
hashGet 0 107 28
return 1 107 29
assign 1 111 44
undef 1 111 49
assign 1 0 50
assign 1 111 53
sameClass 1 111 53
assign 1 111 54
not 0 111 59
assign 1 0 60
assign 1 0 63
assign 1 111 67
new 0 111 67
return 1 111 68
assign 1 112 70
declarationGet 0 112 70
assign 1 112 71
equals 1 112 71
assign 1 112 73
nameGet 0 112 73
assign 1 112 74
equals 1 112 74
assign 1 0 76
assign 1 0 79
assign 1 0 83
assign 1 113 86
new 0 113 86
return 1 113 87
assign 1 115 89
new 0 115 89
return 1 115 90
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
return 1 0 107
return 1 0 110
assign 1 0 113
assign 1 0 117
return 1 0 121
return 1 0 124
assign 1 0 127
assign 1 0 131
return 1 0 135
return 1 0 138
assign 1 0 141
assign 1 0 145
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 831773166: return bem_nameGet_0();
case -1995804558: return bem_toString_0();
case -858518329: return bem_many_0();
case -1890761825: return bem_hashGet_0();
case 1592801927: return bem_serializeContents_0();
case 579328628: return bem_nameGetDirect_0();
case -1845402369: return bem_create_0();
case 944745844: return bem_iteratorGet_0();
case 1367767168: return bem_declarationGetDirect_0();
case -703952395: return bem_toAny_0();
case 793684930: return bem_msynGet_0();
case 1835904283: return bem_fieldIteratorGet_0();
case -513985458: return bem_once_0();
case 745980876: return bem_serializeToString_0();
case 1562045422: return bem_print_0();
case 1952414871: return bem_synGetDirect_0();
case 1287114010: return bem_synGet_0();
case -1155411626: return bem_classNameGet_0();
case 487120351: return bem_msynGetDirect_0();
case -1247813666: return bem_tagGet_0();
case 841207683: return bem_new_0();
case -895545597: return bem_declarationGet_0();
case -225078823: return bem_serializationIteratorGet_0();
case -1154985755: return bem_echo_0();
case -967525204: return bem_fieldNamesGet_0();
case 285074277: return bem_deserializeClassNameGet_0();
case 232809271: return bem_copy_0();
case 863596927: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1815546435: return bem_copyTo_1(bevd_0);
case 1200297939: return bem_undef_1(bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
case -328591258: return bem_synSetDirect_1(bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case 440833669: return bem_nameSet_1(bevd_0);
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 12031225: return bem_def_1(bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case 1445694771: return bem_msynSet_1(bevd_0);
case 1617189437: return bem_declarationSetDirect_1(bevd_0);
case -1668700246: return bem_msynSetDirect_1(bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
case -491552121: return bem_declarationSet_1(bevd_0);
case 2005243076: return bem_nameSetDirect_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case 1212708152: return bem_synSet_1(bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2072540485: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildMtdSyn) bevd_1);
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildMethodIndex_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_11_BuildMethodIndex_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_11_BuildMethodIndex();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst = (BEC_2_5_11_BuildMethodIndex) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_type;
}
}
