package be;
/* IO:File: source/build/EmitData.be */
public final class BEC_2_5_11_BuildMethodIndex extends BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildMethodIndex() { }
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static BEC_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;

public static BET_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_type;

public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildMtdSyn bevp_msyn;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_11_BuildMethodIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildMtdSyn beva__msyn) throws Throwable {
bevp_syn = beva__syn;
bevp_msyn = beva__msyn;
bevp_declaration = bevp_msyn.bem_declarationGet_0();
bevp_name = bevp_msyn.bem_nameGet_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = bevp_declaration.bem_toString_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_name);
bevt_0_ta_ph = bevt_1_ta_ph.bem_hashGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_x == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 111*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 111*/ {
bevt_4_ta_ph = bem_sameClass_1(beva_x);
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 111*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 111*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 111*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 111*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 111*/
bevt_7_ta_ph = beva_x.bemd_0(1092712116);
bevt_6_ta_ph = bevp_declaration.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 112*/ {
bevt_9_ta_ph = beva_x.bemd_0(437300376);
bevt_8_ta_ph = bevp_name.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 112*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 112*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 112*/
 else /* Line: 112*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 112*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 113*/
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public final BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildMethodIndex bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_msynGet_0() throws Throwable {
return bevp_msyn;
} /*method end*/
public final BEC_2_5_6_BuildMtdSyn bem_msynGetDirect_0() throws Throwable {
return bevp_msyn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_msynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildMethodIndex bem_msynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_declarationGetDirect_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildMethodIndex bem_declarationSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildMethodIndex bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {99, 100, 101, 102, 107, 107, 107, 107, 111, 111, 0, 111, 111, 111, 0, 0, 111, 111, 112, 112, 112, 112, 0, 0, 0, 113, 113, 115, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 26, 27, 28, 29, 44, 49, 50, 53, 54, 59, 60, 63, 67, 68, 70, 71, 73, 74, 76, 79, 83, 86, 87, 89, 90, 93, 96, 99, 103, 107, 110, 113, 117, 121, 124, 127, 131, 135, 138, 141, 145};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 99 16
assign 1 100 17
assign 1 101 18
declarationGet 0 101 18
assign 1 102 19
nameGet 0 102 19
assign 1 107 26
toString 0 107 26
assign 1 107 27
add 1 107 27
assign 1 107 28
hashGet 0 107 28
return 1 107 29
assign 1 111 44
undef 1 111 49
assign 1 0 50
assign 1 111 53
sameClass 1 111 53
assign 1 111 54
not 0 111 59
assign 1 0 60
assign 1 0 63
assign 1 111 67
new 0 111 67
return 1 111 68
assign 1 112 70
declarationGet 0 112 70
assign 1 112 71
equals 1 112 71
assign 1 112 73
nameGet 0 112 73
assign 1 112 74
equals 1 112 74
assign 1 0 76
assign 1 0 79
assign 1 0 83
assign 1 113 86
new 0 113 86
return 1 113 87
assign 1 115 89
new 0 115 89
return 1 115 90
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
return 1 0 107
return 1 0 110
assign 1 0 113
assign 1 0 117
return 1 0 121
return 1 0 124
assign 1 0 127
assign 1 0 131
return 1 0 135
return 1 0 138
assign 1 0 141
assign 1 0 145
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -76304380: return bem_synGetDirect_0();
case -777055641: return bem_copy_0();
case 1840077909: return bem_synGet_0();
case -1786334802: return bem_classNameGet_0();
case 2024769987: return bem_msynGet_0();
case 889719110: return bem_print_0();
case -1136648067: return bem_sourceFileNameGet_0();
case -1124112738: return bem_nameGetDirect_0();
case 1773293529: return bem_hashGet_0();
case 1073013382: return bem_iteratorGet_0();
case 989732871: return bem_new_0();
case 687899158: return bem_msynGetDirect_0();
case 1092712116: return bem_declarationGet_0();
case -362215698: return bem_toString_0();
case 1812616799: return bem_create_0();
case 437300376: return bem_nameGet_0();
case 1648346602: return bem_tagGet_0();
case 382943659: return bem_declarationGetDirect_0();
case 2140998184: return bem_fieldNamesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -930132980: return bem_def_1(bevd_0);
case -1875172918: return bem_sameObject_1(bevd_0);
case -1822296314: return bem_declarationSet_1(bevd_0);
case 754161535: return bem_equals_1(bevd_0);
case 800426911: return bem_synSet_1(bevd_0);
case 319814146: return bem_sameClass_1(bevd_0);
case 137331971: return bem_undef_1(bevd_0);
case -583708652: return bem_otherType_1(bevd_0);
case 152940342: return bem_msynSet_1(bevd_0);
case -1764717463: return bem_notEquals_1(bevd_0);
case 1295257783: return bem_otherClass_1(bevd_0);
case -819888445: return bem_msynSetDirect_1(bevd_0);
case -328529345: return bem_synSetDirect_1(bevd_0);
case 980301665: return bem_sameType_1(bevd_0);
case -686700647: return bem_declarationSetDirect_1(bevd_0);
case -52636692: return bem_nameSet_1(bevd_0);
case 1978132891: return bem_copyTo_1(bevd_0);
case -42885212: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 736585149: return bem_nameSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1681451114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450498968: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2056223912: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildMtdSyn) bevd_1);
case 831817632: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1805853509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1679839886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildMethodIndex_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_11_BuildMethodIndex_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_11_BuildMethodIndex();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst = (BEC_2_5_11_BuildMethodIndex) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_type;
}
}
