package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x70,0x61,0x72,0x61,0x6D,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x6F,0x72,0x64,0x65,0x72,0x65,0x64};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x61,0x72,0x67,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_4, 4));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x70,0x61,0x72,0x61,0x6D,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_5, 6));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_6 = {0x6F,0x72,0x64,0x65,0x72,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_6, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_6 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_9 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_7 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_7, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_13 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_8 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_8, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_9 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_9, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_18 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_10 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_10, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_20 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_11 = {0x23};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_11, 1));
public static BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_initialArgs;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public BEC_2_6_10_SystemParameters bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevp_initialArgs = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_args = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toJson_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_9_4_ContainerMaps bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_10_JsonMarshaller bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[7];
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerMaps) BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_10_SystemParameters_bels_1));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_6_10_SystemParameters_bels_2));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_10_SystemParameters_bels_3));
bevd_x[0] = bevt_1_tmpany_phold;
bevd_x[1] = bevp_args;
bevd_x[2] = bevt_2_tmpany_phold;
bevd_x[3] = bevp_params;
bevd_x[4] = bevt_3_tmpany_phold;
bevd_x[5] = bevp_ordered;
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_phold.bem_forwardCall_2(new BEC_2_4_6_TextString("from".getBytes("UTF-8")), (new BEC_2_9_4_ContainerList(bevd_x, 6)).bem_copy_0());
bevt_5_tmpany_phold = (new BEC_2_4_10_JsonMarshaller()).bem_new_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_marshall_1(bevl_jsm);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fromJson_1(BEC_2_4_6_TextString beva_jsms) throws Throwable {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_4_12_JsonUnmarshaller bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_12_JsonUnmarshaller()).bem_new_0();
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_phold.bem_unmarshall_1(beva_jsms);
bevt_1_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_0;
bevp_args = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_1;
bevp_params = (BEC_2_9_3_ContainerMap) bevl_jsm.bem_get_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_2;
bevp_ordered = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fromJsonFile_1(BEC_2_2_4_IOFile beva_jsf) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = beva_jsf.bem_readerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1551817007);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-131411086);
bem_fromJson_1((BEC_2_4_6_TextString) bevt_0_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_toJsonFile_1(BEC_2_2_4_IOFile beva_jsf) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = beva_jsf.bem_writerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1551817007);
bevt_2_tmpany_phold = bem_toJson_0();
bevt_0_tmpany_phold.bemd_1(-400265978, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addValue_1(BEC_2_6_10_SystemParameters beva_p) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_9_10_ContainerLinkedList bevl_cp = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_9_4_ContainerList bevt_1_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_p.bem_argsGet_0();
bevp_args.bem_addValue_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = beva_p.bem_orderedGet_0();
bevp_ordered.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = beva_p.bem_paramsGet_0();
bevt_0_tmpany_loop = bevt_3_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 141 */ {
bevt_4_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-505537007);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevl_kv = bevt_0_tmpany_loop.bemd_0(844391958);
bevt_5_tmpany_phold = bevl_kv.bemd_0(-1387857009);
bevl_cp = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevt_5_tmpany_phold);
if (bevl_cp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_7_tmpany_phold = bevl_kv.bemd_0(-2133686389);
bevl_cp.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 144 */
 else  /* Line: 145 */ {
bevt_8_tmpany_phold = bevl_kv.bemd_0(-1387857009);
bevt_9_tmpany_phold = bevl_kv.bemd_0(-2133686389);
bevp_params.bem_put_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
} /* Line: 146 */
} /* Line: 143 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
bem_new_0();
bevp_initialArgs = beva__args;
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevl_ii = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 159 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(2003310604);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold );
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 159 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(-12288982, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(1508196541, bevt_9_tmpany_phold);
beva__args.bemd_2(1583656022, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 159 */
 else  /* Line: 159 */ {
break;
} /* Line: 159 */
} /* Line: 159 */
} /* Line: 159 */
bevp_args = bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(15052169);
while (true)
 /* Line: 166 */ {
bevt_10_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-505537007);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 166 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(844391958);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_12_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_13_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_3;
if (bevt_12_tmpany_phold.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_4;
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_5;
bevl_fa = bevl_i.bem_substring_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_18_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_6;
if (bevt_17_tmpany_phold.bevi_int > bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_7;
bevt_20_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_8;
bevl_fb = bevl_i.bem_substring_2(bevt_19_tmpany_phold, bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_23_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_9;
if (bevt_22_tmpany_phold.bevi_int > bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_10;
bevt_25_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_11;
bevl_fc = bevl_i.bem_substring_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
} /* Line: 175 */
} /* Line: 174 */
} /* Line: 172 */
if (bevl_pname == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 179 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 180 */ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 181 */
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
} /* Line: 184 */
 else  /* Line: 179 */ {
if (bevl_fb == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_12;
bevt_29_tmpany_phold = bevl_fb.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 185 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 185 */
 else  /* Line: 185 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 185 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_13;
bevt_32_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_31_tmpany_phold, bevt_32_tmpany_phold);
} /* Line: 186 */
 else  /* Line: 179 */ {
if (bevl_fa == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_35_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_14;
bevt_34_tmpany_phold = bevl_fa.bem_equals_1(bevt_35_tmpany_phold);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 187 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 187 */
 else  /* Line: 187 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 187 */ {
bevt_36_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_15;
bevt_37_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_16;
bevl_pos = bevl_par.bem_find_1(bevt_38_tmpany_phold);
if (bevl_pos == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevt_40_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_17;
bevl_key = bevl_par.bem_substring_2(bevt_40_tmpany_phold, bevl_pos);
bevt_42_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_18;
bevt_41_tmpany_phold = bevl_pos.bem_add_1(bevt_42_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_41_tmpany_phold);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 193 */
} /* Line: 190 */
 else  /* Line: 179 */ {
if (bevl_fc == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_45_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_19;
bevt_44_tmpany_phold = bevl_fc.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_46_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_20;
bevt_47_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevl_pnameComment = be.BECS_Runtime.boolTrue;
} /* Line: 197 */
 else  /* Line: 179 */ {
if (bevl_fa == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_50_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_21;
bevt_49_tmpany_phold = bevl_fa.bem_equals_1(bevt_50_tmpany_phold);
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 198 */
 else  /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 199 */
} /* Line: 179 */
} /* Line: 179 */
} /* Line: 179 */
} /* Line: 179 */
} /* Line: 179 */
 else  /* Line: 166 */ {
break;
} /* Line: 166 */
} /* Line: 166 */
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 207 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(1508196541, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 207 */
 else  /* Line: 207 */ {
break;
} /* Line: 207 */
} /* Line: 207 */
} /* Line: 207 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 212 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(1508196541, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 212 */
 else  /* Line: 212 */ {
break;
} /* Line: 212 */
} /* Line: 212 */
} /* Line: 212 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevl__params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 218 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(-505537007);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 218 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(844391958);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 222 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 222 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(1508196541, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 223 */
 else  /* Line: 222 */ {
break;
} /* Line: 222 */
} /* Line: 222 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(1508196541, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 226 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevp_params = bevl__params;
} /* Line: 228 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 234 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 236 */
return beva_isit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 256 */ {
bevl_pl = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 258 */
return bevl_pl;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 269 */ {
return beva_default;
} /* Line: 270 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
bem_addParam_2(beva_name, beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParam_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevl_vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 284 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) throws Throwable {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1551817007);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(-132574752);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(-1578603026);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(-1912023726);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_initialArgsGet_0() throws Throwable {
return bevp_initialArgs;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_initialArgsGetDirect_0() throws Throwable {
return bevp_initialArgs;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_initialArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_initialArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGet_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_orderedGetDirect_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_orderedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGet_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_fileTokGetDirect_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_fileTokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGet_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_preProcessorGetDirect_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_preProcessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_preProcessor = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {108, 109, 110, 111, 112, 112, 119, 119, 119, 119, 119, 120, 120, 120, 124, 124, 125, 125, 126, 126, 127, 127, 131, 131, 131, 131, 135, 135, 135, 135, 139, 139, 140, 140, 141, 141, 0, 141, 141, 142, 142, 143, 143, 144, 144, 146, 146, 146, 152, 153, 154, 158, 158, 159, 159, 159, 160, 160, 160, 159, 163, 164, 165, 166, 0, 166, 166, 167, 168, 169, 170, 170, 170, 170, 171, 171, 171, 172, 172, 172, 172, 173, 173, 173, 174, 174, 174, 174, 175, 175, 175, 179, 179, 180, 180, 181, 183, 184, 185, 185, 185, 185, 0, 0, 0, 186, 186, 186, 187, 187, 187, 187, 0, 0, 0, 188, 188, 188, 189, 189, 190, 190, 191, 191, 192, 192, 192, 193, 195, 195, 195, 195, 0, 0, 0, 196, 196, 196, 197, 198, 198, 198, 198, 0, 0, 0, 198, 198, 199, 205, 206, 206, 207, 207, 207, 207, 208, 208, 208, 207, 211, 211, 212, 212, 212, 212, 213, 213, 213, 212, 216, 216, 217, 218, 218, 219, 220, 221, 222, 0, 222, 222, 223, 223, 225, 226, 228, 233, 234, 234, 236, 239, 243, 243, 243, 247, 247, 251, 251, 255, 256, 256, 257, 258, 260, 264, 264, 268, 269, 269, 270, 272, 272, 276, 281, 282, 282, 283, 284, 286, 291, 291, 291, 292, 292, 293, 293, 294, 298, 298, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {53, 54, 55, 56, 57, 58, 70, 71, 72, 73, 74, 81, 82, 83, 91, 92, 93, 94, 95, 96, 97, 98, 105, 106, 107, 108, 115, 116, 117, 118, 134, 135, 136, 137, 138, 139, 139, 142, 144, 145, 146, 147, 152, 153, 154, 157, 158, 159, 169, 170, 171, 238, 243, 244, 247, 248, 250, 251, 252, 253, 260, 261, 262, 263, 263, 266, 268, 269, 270, 271, 272, 273, 274, 279, 280, 281, 282, 283, 284, 285, 290, 291, 292, 293, 294, 295, 296, 301, 302, 303, 304, 308, 313, 314, 319, 320, 322, 323, 326, 331, 332, 333, 335, 338, 342, 345, 346, 347, 350, 355, 356, 357, 359, 362, 366, 369, 370, 371, 372, 373, 374, 379, 380, 381, 382, 383, 384, 385, 389, 394, 395, 396, 398, 401, 405, 408, 409, 410, 411, 414, 419, 420, 421, 423, 426, 430, 432, 437, 438, 474, 475, 480, 481, 484, 485, 490, 491, 492, 493, 494, 501, 506, 507, 510, 511, 516, 517, 518, 519, 520, 527, 532, 533, 534, 537, 539, 540, 541, 542, 542, 545, 547, 548, 549, 555, 556, 562, 569, 570, 575, 576, 578, 583, 584, 585, 589, 590, 594, 595, 600, 601, 606, 607, 608, 610, 614, 615, 621, 622, 627, 628, 630, 631, 634, 640, 641, 646, 647, 648, 650, 660, 661, 662, 663, 664, 665, 666, 667, 672, 673, 676, 679, 682, 686, 690, 693, 696, 700, 704, 707, 710, 714, 718, 721, 724, 728, 732, 735, 738, 742, 746, 749, 752};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 108 53
new 0 108 53
assign 1 109 54
new 0 109 54
assign 1 110 55
new 0 110 55
assign 1 111 56
new 0 111 56
assign 1 112 57
new 0 112 57
assign 1 112 58
new 1 112 58
assign 1 119 70
new 0 119 70
assign 1 119 71
new 0 119 71
assign 1 119 72
new 0 119 72
assign 1 119 73
new 0 119 73
assign 1 119 74
from 6 119 74
assign 1 120 81
new 0 120 81
assign 1 120 82
marshall 1 120 82
return 1 120 83
assign 1 124 91
new 0 124 91
assign 1 124 92
unmarshall 1 124 92
assign 1 125 93
new 0 125 93
assign 1 125 94
get 1 125 94
assign 1 126 95
new 0 126 95
assign 1 126 96
get 1 126 96
assign 1 127 97
new 0 127 97
assign 1 127 98
get 1 127 98
assign 1 131 105
readerGet 0 131 105
assign 1 131 106
open 0 131 106
assign 1 131 107
readStringClose 0 131 107
fromJson 1 131 108
assign 1 135 115
writerGet 0 135 115
assign 1 135 116
open 0 135 116
assign 1 135 117
toJson 0 135 117
writeStringClose 1 135 118
assign 1 139 134
argsGet 0 139 134
addValue 1 139 135
assign 1 140 136
orderedGet 0 140 136
addValue 1 140 137
assign 1 141 138
paramsGet 0 141 138
assign 1 141 139
iteratorGet 0 0 139
assign 1 141 142
hasNextGet 0 141 142
assign 1 141 144
nextGet 0 141 144
assign 1 142 145
keyGet 0 142 145
assign 1 142 146
get 1 142 146
assign 1 143 147
def 1 143 152
assign 1 144 153
valueGet 0 144 153
addValue 1 144 154
assign 1 146 157
keyGet 0 146 157
assign 1 146 158
valueGet 0 146 158
put 2 146 159
new 0 152 169
assign 1 153 170
addArgs 1 154 171
assign 1 158 238
def 1 158 243
assign 1 159 244
new 0 159 244
assign 1 159 247
lengthGet 0 159 247
assign 1 159 248
lesser 1 159 248
assign 1 160 250
get 1 160 250
assign 1 160 251
process 1 160 251
put 2 160 252
assign 1 159 253
increment 0 159 253
assign 1 163 260
add 1 163 260
assign 1 164 261
assign 1 165 262
new 0 165 262
assign 1 166 263
iteratorGet 0 0 263
assign 1 166 266
hasNextGet 0 166 266
assign 1 166 268
nextGet 0 166 268
assign 1 167 269
assign 1 168 270
assign 1 169 271
assign 1 170 272
sizeGet 0 170 272
assign 1 170 273
new 0 170 273
assign 1 170 274
greater 1 170 279
assign 1 171 280
new 0 171 280
assign 1 171 281
new 0 171 281
assign 1 171 282
substring 2 171 282
assign 1 172 283
sizeGet 0 172 283
assign 1 172 284
new 0 172 284
assign 1 172 285
greater 1 172 290
assign 1 173 291
new 0 173 291
assign 1 173 292
new 0 173 292
assign 1 173 293
substring 2 173 293
assign 1 174 294
sizeGet 0 174 294
assign 1 174 295
new 0 174 295
assign 1 174 296
greater 1 174 301
assign 1 175 302
new 0 175 302
assign 1 175 303
new 0 175 303
assign 1 175 304
substring 2 175 304
assign 1 179 308
def 1 179 313
assign 1 180 314
not 0 180 319
addParameter 2 181 320
assign 1 183 322
assign 1 184 323
new 0 184 323
assign 1 185 326
def 1 185 331
assign 1 185 332
new 0 185 332
assign 1 185 333
equals 1 185 333
assign 1 0 335
assign 1 0 338
assign 1 0 342
assign 1 186 345
new 0 186 345
assign 1 186 346
sizeGet 0 186 346
assign 1 186 347
substring 2 186 347
assign 1 187 350
def 1 187 355
assign 1 187 356
new 0 187 356
assign 1 187 357
equals 1 187 357
assign 1 0 359
assign 1 0 362
assign 1 0 366
assign 1 188 369
new 0 188 369
assign 1 188 370
sizeGet 0 188 370
assign 1 188 371
substring 2 188 371
assign 1 189 372
new 0 189 372
assign 1 189 373
find 1 189 373
assign 1 190 374
def 1 190 379
assign 1 191 380
new 0 191 380
assign 1 191 381
substring 2 191 381
assign 1 192 382
new 0 192 382
assign 1 192 383
add 1 192 383
assign 1 192 384
substring 1 192 384
addParameter 2 193 385
assign 1 195 389
def 1 195 394
assign 1 195 395
new 0 195 395
assign 1 195 396
equals 1 195 396
assign 1 0 398
assign 1 0 401
assign 1 0 405
assign 1 196 408
new 0 196 408
assign 1 196 409
sizeGet 0 196 409
assign 1 196 410
substring 2 196 410
assign 1 197 411
new 0 197 411
assign 1 198 414
def 1 198 419
assign 1 198 420
new 0 198 420
assign 1 198 421
equals 1 198 421
assign 1 0 423
assign 1 0 426
assign 1 0 430
assign 1 198 432
not 0 198 437
addValue 1 199 438
assign 1 205 474
assign 1 206 475
def 1 206 480
assign 1 207 481
new 0 207 481
assign 1 207 484
lengthGet 0 207 484
assign 1 207 485
lesser 1 207 490
assign 1 208 491
get 1 208 491
assign 1 208 492
process 1 208 492
put 2 208 493
assign 1 207 494
increment 0 207 494
assign 1 211 501
def 1 211 506
assign 1 212 507
new 0 212 507
assign 1 212 510
lengthGet 0 212 510
assign 1 212 511
lesser 1 212 516
assign 1 213 517
get 1 213 517
assign 1 213 518
process 1 213 518
put 2 213 519
assign 1 212 520
increment 0 212 520
assign 1 216 527
def 1 216 532
assign 1 217 533
new 0 217 533
assign 1 218 534
keyIteratorGet 0 218 534
assign 1 218 537
hasNextGet 0 218 537
assign 1 219 539
nextGet 0 219 539
assign 1 220 540
get 1 220 540
assign 1 221 541
new 0 221 541
assign 1 222 542
linkedListIteratorGet 0 0 542
assign 1 222 545
hasNextGet 0 222 545
assign 1 222 547
nextGet 0 222 547
assign 1 223 548
process 1 223 548
addValue 1 223 549
assign 1 225 555
process 1 225 555
put 2 226 556
assign 1 228 562
assign 1 233 569
getFirst 1 233 569
assign 1 234 570
def 1 234 575
assign 1 236 576
new 1 236 576
return 1 239 578
assign 1 243 583
new 0 243 583
assign 1 243 584
isTrue 2 243 584
return 1 243 585
assign 1 247 589
has 1 247 589
return 1 247 590
assign 1 251 594
get 1 251 594
return 1 251 595
assign 1 255 600
get 1 255 600
assign 1 256 601
undef 1 256 606
assign 1 257 607
new 0 257 607
addValue 1 258 608
return 1 260 610
assign 1 264 614
getFirst 2 264 614
return 1 264 615
assign 1 268 621
get 1 268 621
assign 1 269 622
undef 1 269 627
return 1 270 628
assign 1 272 630
firstGet 0 272 630
return 1 272 631
addParam 2 276 634
assign 1 281 640
get 1 281 640
assign 1 282 641
undef 1 282 646
assign 1 283 647
new 0 283 647
put 2 284 648
addValue 1 286 650
assign 1 291 660
readerGet 0 291 660
assign 1 291 661
open 0 291 661
assign 1 291 662
readString 0 291 662
assign 1 292 663
readerGet 0 292 663
close 0 292 664
assign 1 293 665
tokenize 1 293 665
assign 1 293 666
toList 0 293 666
addArgs 1 294 667
assign 1 298 672
iteratorGet 0 298 672
return 1 298 673
return 1 0 676
return 1 0 679
assign 1 0 682
assign 1 0 686
return 1 0 690
return 1 0 693
assign 1 0 696
assign 1 0 700
return 1 0 704
return 1 0 707
assign 1 0 710
assign 1 0 714
return 1 0 718
return 1 0 721
assign 1 0 724
assign 1 0 728
return 1 0 732
return 1 0 735
assign 1 0 738
assign 1 0 742
return 1 0 746
return 1 0 749
assign 1 0 752
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1476241706: return bem_initialArgsGetDirect_0();
case 1770146810: return bem_serializeToString_0();
case -361847812: return bem_initialArgsGet_0();
case 1361603917: return bem_create_0();
case -1406642022: return bem_argsGet_0();
case -531363823: return bem_orderedGet_0();
case -512745226: return bem_tagGet_0();
case 150594226: return bem_toAny_0();
case -385386328: return bem_preProcessorGetDirect_0();
case 475849232: return bem_fieldNamesGet_0();
case -481458436: return bem_once_0();
case 970559243: return bem_hashGet_0();
case -1824524345: return bem_preProcessorGet_0();
case -232339846: return bem_classNameGet_0();
case 925810147: return bem_paramsGetDirect_0();
case 189063253: return bem_serializeContents_0();
case 911669853: return bem_orderedGetDirect_0();
case -696933955: return bem_toString_0();
case 1470934458: return bem_fileTokGet_0();
case -791198660: return bem_serializationIteratorGet_0();
case 734719264: return bem_copy_0();
case 865626065: return bem_many_0();
case -1010395565: return bem_deserializeClassNameGet_0();
case 1927137068: return bem_toJson_0();
case 15052169: return bem_iteratorGet_0();
case 1193373571: return bem_argsGetDirect_0();
case -866769073: return bem_new_0();
case -1500058276: return bem_fileTokGetDirect_0();
case -1238312381: return bem_print_0();
case 1550286188: return bem_paramsGet_0();
case 1064240293: return bem_sourceFileNameGet_0();
case -96306095: return bem_echo_0();
case 1703076999: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 114554925: return bem_addValue_1((BEC_2_6_10_SystemParameters) bevd_0);
case -2044477563: return bem_fileTokSetDirect_1(bevd_0);
case -1913255025: return bem_argsSet_1(bevd_0);
case -1696224976: return bem_otherClass_1(bevd_0);
case -1555556152: return bem_defined_1(bevd_0);
case 1370646954: return bem_fromJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case 721379891: return bem_otherType_1(bevd_0);
case -1411547316: return bem_sameObject_1(bevd_0);
case -538313847: return bem_addArgs_1(bevd_0);
case 1359254960: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case -1378821005: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 954777710: return bem_undefined_1(bevd_0);
case 1745130365: return bem_fromJson_1((BEC_2_4_6_TextString) bevd_0);
case -12288982: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -891153708: return bem_initialArgsSet_1(bevd_0);
case -1338583245: return bem_initialArgsSetDirect_1(bevd_0);
case 789848846: return bem_copyTo_1(bevd_0);
case 449184309: return bem_preProcessorSetDirect_1(bevd_0);
case -1258943525: return bem_equals_1(bevd_0);
case -1214651392: return bem_paramsSet_1(bevd_0);
case -1814510964: return bem_notEquals_1(bevd_0);
case 521110164: return bem_fileTokSet_1(bevd_0);
case -256855558: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case 1689607871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1438339735: return bem_orderedSet_1(bevd_0);
case -1908038341: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case -304012900: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 361737303: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1973562246: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1173432324: return bem_paramsSetDirect_1(bevd_0);
case 250543247: return bem_preProcessorSet_1(bevd_0);
case 670069213: return bem_toJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case 952631001: return bem_undef_1(bevd_0);
case -317328524: return bem_orderedSetDirect_1(bevd_0);
case -1657467808: return bem_def_1(bevd_0);
case -2018144381: return bem_sameType_1(bevd_0);
case -1120668425: return bem_sameClass_1(bevd_0);
case -1868714581: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case 869229730: return bem_argsSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 514912045: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 84003596: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1042684143: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -133579010: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -28844163: return bem_addParam_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1041788971: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -403305792: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1191848195: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1987789850: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1202795102: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -750254672: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2072659817: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
