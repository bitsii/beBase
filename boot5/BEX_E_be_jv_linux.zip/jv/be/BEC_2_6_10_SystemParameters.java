package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_8 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_1, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_10 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_12 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_3, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_4, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_17 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x23};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_5, 1));
public static BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public BEC_2_6_10_SystemParameters bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevp_args = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
bem_new_0();
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevl_ii = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 124 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(1740970372);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold );
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(590912902, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(2056188154, bevt_9_tmpany_phold);
beva__args.bemd_2(-2078297324, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 124 */
 else  /* Line: 124 */ {
break;
} /* Line: 124 */
} /* Line: 124 */
} /* Line: 124 */
bevp_args = bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(993759307);
while (true)
 /* Line: 131 */ {
bevt_10_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-568133260);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1008451889);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_12_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_13_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_0;
if (bevt_12_tmpany_phold.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_1;
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_2;
bevl_fa = bevl_i.bem_substring_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_18_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_3;
if (bevt_17_tmpany_phold.bevi_int > bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_4;
bevt_20_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_5;
bevl_fb = bevl_i.bem_substring_2(bevt_19_tmpany_phold, bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_23_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_6;
if (bevt_22_tmpany_phold.bevi_int > bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 139 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_7;
bevt_25_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_8;
bevl_fc = bevl_i.bem_substring_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
} /* Line: 140 */
} /* Line: 139 */
} /* Line: 137 */
if (bevl_pname == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 144 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 145 */ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 146 */
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
} /* Line: 149 */
 else  /* Line: 144 */ {
if (bevl_fb == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_9;
bevt_29_tmpany_phold = bevl_fb.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 150 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 150 */
 else  /* Line: 150 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 150 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_10;
bevt_32_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_31_tmpany_phold, bevt_32_tmpany_phold);
} /* Line: 151 */
 else  /* Line: 144 */ {
if (bevl_fa == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_35_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_11;
bevt_34_tmpany_phold = bevl_fa.bem_equals_1(bevt_35_tmpany_phold);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 152 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 152 */
 else  /* Line: 152 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 152 */ {
bevt_36_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_12;
bevt_37_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_13;
bevl_pos = bevl_par.bem_find_1(bevt_38_tmpany_phold);
if (bevl_pos == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevt_40_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_14;
bevl_key = bevl_par.bem_substring_2(bevt_40_tmpany_phold, bevl_pos);
bevt_42_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_15;
bevt_41_tmpany_phold = bevl_pos.bem_add_1(bevt_42_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_41_tmpany_phold);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 158 */
} /* Line: 155 */
 else  /* Line: 144 */ {
if (bevl_fc == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 160 */ {
bevt_45_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_16;
bevt_44_tmpany_phold = bevl_fc.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 160 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 160 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 160 */
 else  /* Line: 160 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 160 */ {
bevt_46_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_17;
bevt_47_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevl_pnameComment = be.BECS_Runtime.boolTrue;
} /* Line: 162 */
 else  /* Line: 144 */ {
if (bevl_fa == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevt_50_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_18;
bevt_49_tmpany_phold = bevl_fa.bem_equals_1(bevt_50_tmpany_phold);
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 163 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 163 */
 else  /* Line: 163 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 164 */
} /* Line: 144 */
} /* Line: 144 */
} /* Line: 144 */
} /* Line: 144 */
} /* Line: 144 */
 else  /* Line: 131 */ {
break;
} /* Line: 131 */
} /* Line: 131 */
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 172 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(2056188154, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 172 */
 else  /* Line: 172 */ {
break;
} /* Line: 172 */
} /* Line: 172 */
} /* Line: 172 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 176 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 177 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 177 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(2056188154, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 177 */
 else  /* Line: 177 */ {
break;
} /* Line: 177 */
} /* Line: 177 */
} /* Line: 177 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 181 */ {
bevl__params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 183 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(-568133260);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 183 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(-1008451889);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 187 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 187 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(2056188154, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 188 */
 else  /* Line: 187 */ {
break;
} /* Line: 187 */
} /* Line: 187 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(2056188154, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 191 */
 else  /* Line: 183 */ {
break;
} /* Line: 183 */
} /* Line: 183 */
bevp_params = bevl__params;
} /* Line: 193 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 199 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 201 */
return beva_isit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevl_pl = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 223 */
return bevl_pl;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 234 */ {
return beva_default;
} /* Line: 235 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
bem_addParam_2(beva_name, beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParam_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevl_vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 249 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) throws Throwable {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-319407083);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(-1900486105);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(-1817296654);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(-1901160793);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_paramsGetDirect_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGet_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_orderedGetDirect_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_orderedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGet_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_fileTokGetDirect_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_fileTokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGet_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_preProcessorGetDirect_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public final BEC_2_6_10_SystemParameters bem_preProcessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_preProcessor = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {108, 109, 110, 111, 111, 118, 119, 123, 123, 124, 124, 124, 125, 125, 125, 124, 128, 129, 130, 131, 0, 131, 131, 132, 133, 134, 135, 135, 135, 135, 136, 136, 136, 137, 137, 137, 137, 138, 138, 138, 139, 139, 139, 139, 140, 140, 140, 144, 144, 145, 145, 146, 148, 149, 150, 150, 150, 150, 0, 0, 0, 151, 151, 151, 152, 152, 152, 152, 0, 0, 0, 153, 153, 153, 154, 154, 155, 155, 156, 156, 157, 157, 157, 158, 160, 160, 160, 160, 0, 0, 0, 161, 161, 161, 162, 163, 163, 163, 163, 0, 0, 0, 163, 163, 164, 170, 171, 171, 172, 172, 172, 172, 173, 173, 173, 172, 176, 176, 177, 177, 177, 177, 178, 178, 178, 177, 181, 181, 182, 183, 183, 184, 185, 186, 187, 0, 187, 187, 188, 188, 190, 191, 193, 198, 199, 199, 201, 204, 208, 208, 208, 212, 212, 216, 216, 220, 221, 221, 222, 223, 225, 229, 229, 233, 234, 234, 235, 237, 237, 241, 246, 247, 247, 248, 249, 251, 256, 256, 256, 257, 257, 258, 258, 259, 263, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {43, 44, 45, 46, 47, 51, 52, 119, 124, 125, 128, 129, 131, 132, 133, 134, 141, 142, 143, 144, 144, 147, 149, 150, 151, 152, 153, 154, 155, 160, 161, 162, 163, 164, 165, 166, 171, 172, 173, 174, 175, 176, 177, 182, 183, 184, 185, 189, 194, 195, 200, 201, 203, 204, 207, 212, 213, 214, 216, 219, 223, 226, 227, 228, 231, 236, 237, 238, 240, 243, 247, 250, 251, 252, 253, 254, 255, 260, 261, 262, 263, 264, 265, 266, 270, 275, 276, 277, 279, 282, 286, 289, 290, 291, 292, 295, 300, 301, 302, 304, 307, 311, 313, 318, 319, 355, 356, 361, 362, 365, 366, 371, 372, 373, 374, 375, 382, 387, 388, 391, 392, 397, 398, 399, 400, 401, 408, 413, 414, 415, 418, 420, 421, 422, 423, 423, 426, 428, 429, 430, 436, 437, 443, 450, 451, 456, 457, 459, 464, 465, 466, 470, 471, 475, 476, 481, 482, 487, 488, 489, 491, 495, 496, 502, 503, 508, 509, 511, 512, 515, 521, 522, 527, 528, 529, 531, 541, 542, 543, 544, 545, 546, 547, 548, 553, 554, 557, 560, 563, 567, 571, 574, 577, 581, 585, 588, 591, 595, 599, 602, 605, 609, 613, 616, 619};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 108 43
new 0 108 43
assign 1 109 44
new 0 109 44
assign 1 110 45
new 0 110 45
assign 1 111 46
new 0 111 46
assign 1 111 47
new 1 111 47
new 0 118 51
addArgs 1 119 52
assign 1 123 119
def 1 123 124
assign 1 124 125
new 0 124 125
assign 1 124 128
lengthGet 0 124 128
assign 1 124 129
lesser 1 124 129
assign 1 125 131
get 1 125 131
assign 1 125 132
process 1 125 132
put 2 125 133
assign 1 124 134
increment 0 124 134
assign 1 128 141
add 1 128 141
assign 1 129 142
assign 1 130 143
new 0 130 143
assign 1 131 144
iteratorGet 0 0 144
assign 1 131 147
hasNextGet 0 131 147
assign 1 131 149
nextGet 0 131 149
assign 1 132 150
assign 1 133 151
assign 1 134 152
assign 1 135 153
sizeGet 0 135 153
assign 1 135 154
new 0 135 154
assign 1 135 155
greater 1 135 160
assign 1 136 161
new 0 136 161
assign 1 136 162
new 0 136 162
assign 1 136 163
substring 2 136 163
assign 1 137 164
sizeGet 0 137 164
assign 1 137 165
new 0 137 165
assign 1 137 166
greater 1 137 171
assign 1 138 172
new 0 138 172
assign 1 138 173
new 0 138 173
assign 1 138 174
substring 2 138 174
assign 1 139 175
sizeGet 0 139 175
assign 1 139 176
new 0 139 176
assign 1 139 177
greater 1 139 182
assign 1 140 183
new 0 140 183
assign 1 140 184
new 0 140 184
assign 1 140 185
substring 2 140 185
assign 1 144 189
def 1 144 194
assign 1 145 195
not 0 145 200
addParameter 2 146 201
assign 1 148 203
assign 1 149 204
new 0 149 204
assign 1 150 207
def 1 150 212
assign 1 150 213
new 0 150 213
assign 1 150 214
equals 1 150 214
assign 1 0 216
assign 1 0 219
assign 1 0 223
assign 1 151 226
new 0 151 226
assign 1 151 227
sizeGet 0 151 227
assign 1 151 228
substring 2 151 228
assign 1 152 231
def 1 152 236
assign 1 152 237
new 0 152 237
assign 1 152 238
equals 1 152 238
assign 1 0 240
assign 1 0 243
assign 1 0 247
assign 1 153 250
new 0 153 250
assign 1 153 251
sizeGet 0 153 251
assign 1 153 252
substring 2 153 252
assign 1 154 253
new 0 154 253
assign 1 154 254
find 1 154 254
assign 1 155 255
def 1 155 260
assign 1 156 261
new 0 156 261
assign 1 156 262
substring 2 156 262
assign 1 157 263
new 0 157 263
assign 1 157 264
add 1 157 264
assign 1 157 265
substring 1 157 265
addParameter 2 158 266
assign 1 160 270
def 1 160 275
assign 1 160 276
new 0 160 276
assign 1 160 277
equals 1 160 277
assign 1 0 279
assign 1 0 282
assign 1 0 286
assign 1 161 289
new 0 161 289
assign 1 161 290
sizeGet 0 161 290
assign 1 161 291
substring 2 161 291
assign 1 162 292
new 0 162 292
assign 1 163 295
def 1 163 300
assign 1 163 301
new 0 163 301
assign 1 163 302
equals 1 163 302
assign 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 163 313
not 0 163 318
addValue 1 164 319
assign 1 170 355
assign 1 171 356
def 1 171 361
assign 1 172 362
new 0 172 362
assign 1 172 365
lengthGet 0 172 365
assign 1 172 366
lesser 1 172 371
assign 1 173 372
get 1 173 372
assign 1 173 373
process 1 173 373
put 2 173 374
assign 1 172 375
increment 0 172 375
assign 1 176 382
def 1 176 387
assign 1 177 388
new 0 177 388
assign 1 177 391
lengthGet 0 177 391
assign 1 177 392
lesser 1 177 397
assign 1 178 398
get 1 178 398
assign 1 178 399
process 1 178 399
put 2 178 400
assign 1 177 401
increment 0 177 401
assign 1 181 408
def 1 181 413
assign 1 182 414
new 0 182 414
assign 1 183 415
keyIteratorGet 0 183 415
assign 1 183 418
hasNextGet 0 183 418
assign 1 184 420
nextGet 0 184 420
assign 1 185 421
get 1 185 421
assign 1 186 422
new 0 186 422
assign 1 187 423
linkedListIteratorGet 0 0 423
assign 1 187 426
hasNextGet 0 187 426
assign 1 187 428
nextGet 0 187 428
assign 1 188 429
process 1 188 429
addValue 1 188 430
assign 1 190 436
process 1 190 436
put 2 191 437
assign 1 193 443
assign 1 198 450
getFirst 1 198 450
assign 1 199 451
def 1 199 456
assign 1 201 457
new 1 201 457
return 1 204 459
assign 1 208 464
new 0 208 464
assign 1 208 465
isTrue 2 208 465
return 1 208 466
assign 1 212 470
has 1 212 470
return 1 212 471
assign 1 216 475
get 1 216 475
return 1 216 476
assign 1 220 481
get 1 220 481
assign 1 221 482
undef 1 221 487
assign 1 222 488
new 0 222 488
addValue 1 223 489
return 1 225 491
assign 1 229 495
getFirst 2 229 495
return 1 229 496
assign 1 233 502
get 1 233 502
assign 1 234 503
undef 1 234 508
return 1 235 509
assign 1 237 511
firstGet 0 237 511
return 1 237 512
addParam 2 241 515
assign 1 246 521
get 1 246 521
assign 1 247 522
undef 1 247 527
assign 1 248 528
new 0 248 528
put 2 249 529
addValue 1 251 531
assign 1 256 541
readerGet 0 256 541
assign 1 256 542
open 0 256 542
assign 1 256 543
readString 0 256 543
assign 1 257 544
readerGet 0 257 544
close 0 257 545
assign 1 258 546
tokenize 1 258 546
assign 1 258 547
toList 0 258 547
addArgs 1 259 548
assign 1 263 553
iteratorGet 0 263 553
return 1 263 554
return 1 0 557
return 1 0 560
assign 1 0 563
assign 1 0 567
return 1 0 571
return 1 0 574
assign 1 0 577
assign 1 0 581
return 1 0 585
return 1 0 588
assign 1 0 591
assign 1 0 595
return 1 0 599
return 1 0 602
assign 1 0 605
assign 1 0 609
return 1 0 613
return 1 0 616
assign 1 0 619
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1727044681: return bem_preProcessorGetDirect_0();
case -2091241279: return bem_create_0();
case -1400770094: return bem_many_0();
case 1299948053: return bem_serializeContents_0();
case -347731995: return bem_paramsGet_0();
case 336683519: return bem_fileTokGetDirect_0();
case -1423578661: return bem_print_0();
case 758802515: return bem_once_0();
case -512236724: return bem_deserializeClassNameGet_0();
case 1957608515: return bem_fieldIteratorGet_0();
case -923057320: return bem_serializationIteratorGet_0();
case 1349866592: return bem_toString_0();
case 675566088: return bem_classNameGet_0();
case -35248652: return bem_toAny_0();
case 1112901599: return bem_preProcessorGet_0();
case -914347833: return bem_new_0();
case -245363326: return bem_copy_0();
case -518710385: return bem_fieldNamesGet_0();
case 518862870: return bem_tagGet_0();
case -1050935903: return bem_argsGetDirect_0();
case 1052263558: return bem_serializeToString_0();
case 13807179: return bem_hashGet_0();
case -2035208893: return bem_echo_0();
case 646589914: return bem_sourceFileNameGet_0();
case 2073634617: return bem_fileTokGet_0();
case 500880129: return bem_paramsGetDirect_0();
case 993759307: return bem_iteratorGet_0();
case 162403702: return bem_orderedGet_0();
case 631816181: return bem_orderedGetDirect_0();
case 992975540: return bem_argsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case -537932837: return bem_equals_1(bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 262460528: return bem_fileTokSetDirect_1(bevd_0);
case 451537597: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case 493549682: return bem_preProcessorSetDirect_1(bevd_0);
case -1779942598: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case -1339004766: return bem_orderedSetDirect_1(bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -369133108: return bem_fileTokSet_1(bevd_0);
case -981884564: return bem_orderedSet_1(bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case -1988141605: return bem_addArgs_1(bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case 1645909378: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1129006485: return bem_preProcessorSet_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case 2012468585: return bem_argsSetDirect_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case 590912902: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -340377293: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case -285679185: return bem_argsSet_1(bevd_0);
case 195004042: return bem_paramsSetDirect_1(bevd_0);
case -1864369475: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -1698919889: return bem_paramsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -670158153: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 431882302: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1646031792: return bem_addParam_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 927775030: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 528650512: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
