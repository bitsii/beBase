package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_20_XmlTagIteratorException extends BEC_2_6_9_SystemException {
public BEC_2_3_20_XmlTagIteratorException() { }
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;

public static BET_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1010395565: return bem_deserializeClassNameGet_0();
case -687197627: return bem_klassNameGet_0();
case -325907731: return bem_klassNameGetDirect_0();
case 1121570398: return bem_translatedGetDirect_0();
case -791198660: return bem_serializationIteratorGet_0();
case -851092137: return bem_lineNumberGet_0();
case -1960677287: return bem_methodNameGet_0();
case -1423644737: return bem_vvGetDirect_0();
case 1573960527: return bem_translateEmittedExceptionInner_0();
case 15052169: return bem_iteratorGet_0();
case 475849232: return bem_fieldNamesGet_0();
case 1860102684: return bem_emitLangGetDirect_0();
case 1287415109: return bem_vvGet_0();
case -1238312381: return bem_print_0();
case 1550007097: return bem_emitLangGet_0();
case 1060475757: return bem_langGetDirect_0();
case 865626065: return bem_many_0();
case 1415834314: return bem_framesGetDirect_0();
case 1703076999: return bem_fieldIteratorGet_0();
case -17109179: return bem_framesTextGetDirect_0();
case -1700111347: return bem_lineNumberGetDirect_0();
case 189063253: return bem_serializeContents_0();
case 970559243: return bem_hashGet_0();
case 2028198508: return bem_langGet_0();
case -956387365: return bem_framesTextGet_0();
case -696933955: return bem_toString_0();
case -512745226: return bem_tagGet_0();
case 319588537: return bem_descriptionGetDirect_0();
case -232339846: return bem_classNameGet_0();
case 734719264: return bem_copy_0();
case -982760125: return bem_translatedGet_0();
case -866769073: return bem_new_0();
case 1361603917: return bem_create_0();
case 1064240293: return bem_sourceFileNameGet_0();
case 1585700136: return bem_descriptionGet_0();
case -1784672928: return bem_fileNameGet_0();
case -971632527: return bem_framesGet_0();
case 1770146810: return bem_serializeToString_0();
case -782276143: return bem_getFrameText_0();
case 292954363: return bem_methodNameGetDirect_0();
case -96306095: return bem_echo_0();
case 150594226: return bem_toAny_0();
case -481458436: return bem_once_0();
case 1816227094: return bem_fileNameGetDirect_0();
case -1325611671: return bem_translateEmittedException_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1836696422: return bem_klassNameSet_1(bevd_0);
case -1973562246: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1257389782: return bem_emitLangSetDirect_1(bevd_0);
case -2026107171: return bem_framesSetDirect_1(bevd_0);
case 25621957: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 513597303: return bem_klassNameSetDirect_1(bevd_0);
case -1411547316: return bem_sameObject_1(bevd_0);
case -256855558: return bem_new_1(bevd_0);
case 712530576: return bem_langSetDirect_1(bevd_0);
case -1936465676: return bem_framesSet_1(bevd_0);
case -1657467808: return bem_def_1(bevd_0);
case 954777710: return bem_undefined_1(bevd_0);
case 952631001: return bem_undef_1(bevd_0);
case -1914513671: return bem_descriptionSetDirect_1(bevd_0);
case -1120668425: return bem_sameClass_1(bevd_0);
case -1357241025: return bem_translatedSet_1(bevd_0);
case -1555556152: return bem_defined_1(bevd_0);
case -304012900: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1623768095: return bem_langSet_1(bevd_0);
case 721379891: return bem_otherType_1(bevd_0);
case -1693787409: return bem_fileNameSet_1(bevd_0);
case 1110603654: return bem_emitLangSet_1(bevd_0);
case 1275813394: return bem_lineNumberSetDirect_1(bevd_0);
case -1114423709: return bem_lineNumberSet_1(bevd_0);
case -2018144381: return bem_sameType_1(bevd_0);
case 789848846: return bem_copyTo_1(bevd_0);
case -1814510964: return bem_notEquals_1(bevd_0);
case -22690667: return bem_methodNameSetDirect_1(bevd_0);
case 153749823: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -456374980: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1881437180: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1877530984: return bem_fileNameSetDirect_1(bevd_0);
case 1173691118: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1343771467: return bem_descriptionSet_1(bevd_0);
case -2108877166: return bem_translatedSetDirect_1(bevd_0);
case 882276030: return bem_framesTextSetDirect_1(bevd_0);
case 1689607871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1258943525: return bem_equals_1(bevd_0);
case 2068819244: return bem_vvSetDirect_1(bevd_0);
case -1696224976: return bem_otherClass_1(bevd_0);
case -1378821005: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 357948679: return bem_vvSet_1(bevd_0);
case 1252005120: return bem_framesTextSet_1(bevd_0);
case 1628163629: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -256190222: return bem_methodNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -133579010: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -750254672: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1191848195: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 514912045: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2072659817: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1041788971: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 84003596: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -491665694: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_3_20_XmlTagIteratorException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_20_XmlTagIteratorException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_20_XmlTagIteratorException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst = (BEC_2_3_20_XmlTagIteratorException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;
}
}
