package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader extends BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 221458969: return bem_serializeToString_0();
case -1997863448: return bem_readDiscardClose_0();
case -68577615: return bem_close_0();
case -1238524057: return bem_print_0();
case 75521046: return bem_readBuffer_0();
case 993286746: return bem_echo_0();
case 137910263: return bem_create_0();
case -992634121: return bem_tagGet_0();
case -680708400: return bem_byteReaderGet_0();
case -1426056679: return bem_hashGet_0();
case 1386676683: return bem_readString_0();
case -1851472893: return bem_once_0();
case -1740004542: return bem_extOpen_0();
case -1714583788: return bem_classNameGet_0();
case -1200480933: return bem_isClosedGet_0();
case 814015164: return bem_copy_0();
case -438289515: return bem_fieldIteratorGet_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -777537417: return bem_serializeContents_0();
case -1823008399: return bem_vfileGetDirect_0();
case 954318819: return bem_readDiscard_0();
case 217381802: return bem_serializationIteratorGet_0();
case 205150354: return bem_new_0();
case 2072486892: return bem_isClosedGetDirect_0();
case -1331626162: return bem_iteratorGet_0();
case -652688204: return bem_blockSizeGetDirect_0();
case 1537335265: return bem_readBufferLine_0();
case -912342775: return bem_deserializeClassNameGet_0();
case -411592540: return bem_vfileGet_0();
case -1079456517: return bem_many_0();
case 699389440: return bem_readStringClose_0();
case 1295327203: return bem_blockSizeGet_0();
case 78412540: return bem_toAny_0();
case -1392846471: return bem_toString_0();
case 310047227: return bem_fieldNamesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1120036325: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 479499721: return bem_blockSizeSet_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case -232715737: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case -113434266: return bem_vfileSet_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -58136999: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 805447767: return bem_isClosedSet_1(bevd_0);
case -962756393: return bem_vfileSetDirect_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case -351473189: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case -2032755710: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case 1877772255: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case -107068883: return bem_isClosedSetDirect_1(bevd_0);
case -1723769003: return bem_blockSizeSetDirect_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250249994: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -965199060: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 306553594: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_6_NetSocketReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
