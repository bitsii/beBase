package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader extends BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -485814560: return bem_print_0();
case -1738244523: return bem_readDiscardClose_0();
case -1795535600: return bem_close_0();
case -668747312: return bem_hashGet_0();
case -1743078764: return bem_copy_0();
case 1139054130: return bem_readBufferLine_0();
case -1772356243: return bem_toString_0();
case 267413330: return bem_readStringClose_0();
case 516300098: return bem_readDiscard_0();
case -1013233122: return bem_extOpen_0();
case 1512799648: return bem_byteReaderGet_0();
case 800924819: return bem_blockSizeGet_0();
case -1150718279: return bem_vfileGet_0();
case 625793045: return bem_readBuffer_0();
case -1501266936: return bem_create_0();
case 607475508: return bem_iteratorGet_0();
case -1189610979: return bem_new_0();
case 619406274: return bem_readString_0();
case 879380527: return bem_isClosedGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 241865106: return bem_equals_1(bevd_0);
case -370641535: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -227435403: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -1780744233: return bem_isClosedSet_1(bevd_0);
case 1442679110: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 639336076: return bem_blockSizeSet_1(bevd_0);
case 551470188: return bem_copyTo_1(bevd_0);
case 898041849: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -805326223: return bem_notEquals_1(bevd_0);
case -347939855: return bem_def_1(bevd_0);
case 642304804: return bem_print_1(bevd_0);
case -430450331: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 421158622: return bem_undef_1(bevd_0);
case -2071110732: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1317434345: return bem_vfileSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1690321658: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1310310445: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1441215540: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1691003596: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1513682872: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 2025483598: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1247749511: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_6_NetSocketReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
