package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_10_SystemCallOnNull extends BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public BEC_2_6_10_SystemCallOnNull bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {367};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 367 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2077164627: return bem_framesGetDirect_0();
case -2091241279: return bem_create_0();
case -173700588: return bem_emitLangGetDirect_0();
case -783751398: return bem_framesGet_0();
case 692754988: return bem_lineNumberGet_0();
case 812717035: return bem_klassNameGet_0();
case -1400770094: return bem_many_0();
case 1299948053: return bem_serializeContents_0();
case 1128289035: return bem_vvGetDirect_0();
case -1916678018: return bem_klassNameGetDirect_0();
case -1423578661: return bem_print_0();
case 758802515: return bem_once_0();
case 136270207: return bem_langGet_0();
case 2075852854: return bem_langGetDirect_0();
case -512236724: return bem_deserializeClassNameGet_0();
case 1957608515: return bem_fieldIteratorGet_0();
case 1137068246: return bem_lineNumberGetDirect_0();
case -1782814028: return bem_methodNameGetDirect_0();
case -923057320: return bem_serializationIteratorGet_0();
case 1349866592: return bem_toString_0();
case 675566088: return bem_classNameGet_0();
case 1647479542: return bem_methodNameGet_0();
case 1330692049: return bem_fileNameGet_0();
case 1994694466: return bem_translateEmittedException_0();
case -35248652: return bem_toAny_0();
case -464329149: return bem_descriptionGetDirect_0();
case -914347833: return bem_new_0();
case -245363326: return bem_copy_0();
case -518710385: return bem_fieldNamesGet_0();
case 565230916: return bem_emitLangGet_0();
case 518862870: return bem_tagGet_0();
case -1293182152: return bem_framesTextGet_0();
case 1672751200: return bem_translateEmittedExceptionInner_0();
case 65676114: return bem_vvGet_0();
case -1907127525: return bem_translatedGetDirect_0();
case -1800483640: return bem_getFrameText_0();
case 1052263558: return bem_serializeToString_0();
case 13807179: return bem_hashGet_0();
case -2035208893: return bem_echo_0();
case 646589914: return bem_sourceFileNameGet_0();
case -1801383610: return bem_framesTextGetDirect_0();
case -155641927: return bem_translatedGet_0();
case -45972011: return bem_descriptionGet_0();
case 993759307: return bem_iteratorGet_0();
case 283918246: return bem_fileNameGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1233204063: return bem_translatedSet_1(bevd_0);
case 1266524180: return bem_framesTextSet_1(bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 282781357: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case 1329386294: return bem_klassNameSetDirect_1(bevd_0);
case 829087000: return bem_vvSet_1(bevd_0);
case 1549706951: return bem_descriptionSetDirect_1(bevd_0);
case -2108328903: return bem_framesTextSetDirect_1(bevd_0);
case 1142761677: return bem_emitLangSetDirect_1(bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1643916079: return bem_fileNameSet_1(bevd_0);
case 1352182051: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -16824022: return bem_framesSet_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case 1083792358: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -537932837: return bem_equals_1(bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case -339409609: return bem_emitLangSet_1(bevd_0);
case 351948987: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 2123122363: return bem_lineNumberSet_1(bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1320208295: return bem_descriptionSet_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case 1680820521: return bem_translatedSetDirect_1(bevd_0);
case -1244081508: return bem_methodNameSet_1(bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1251844866: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 511689094: return bem_fileNameSetDirect_1(bevd_0);
case 184956384: return bem_langSet_1(bevd_0);
case 1328917720: return bem_vvSetDirect_1(bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case -963645592: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1716883381: return bem_framesSetDirect_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -546015092: return bem_klassNameSet_1(bevd_0);
case -701297913: return bem_methodNameSetDirect_1(bevd_0);
case -340377293: return bem_new_1(bevd_0);
case 1281516558: return bem_lineNumberSetDirect_1(bevd_0);
case 291825405: return bem_langSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1962678371: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemCallOnNull();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
