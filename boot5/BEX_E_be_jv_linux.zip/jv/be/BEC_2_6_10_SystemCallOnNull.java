package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_10_SystemCallOnNull extends BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public BEC_2_6_10_SystemCallOnNull bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {366};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 366 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -677488078: return bem_fileNameGet_0();
case -332469880: return bem_methodNameGet_0();
case -1180336274: return bem_iteratorGet_0();
case -1873931192: return bem_print_0();
case 1299401669: return bem_methodNameGetDirect_0();
case -1005390218: return bem_deserializeClassNameGet_0();
case -1280990231: return bem_framesTextGet_0();
case 355897015: return bem_klassNameGetDirect_0();
case -1833113172: return bem_serializationIteratorGet_0();
case 2019864187: return bem_translateEmittedException_0();
case 499912552: return bem_langGet_0();
case 216488034: return bem_langGetDirect_0();
case 486036595: return bem_once_0();
case 650627790: return bem_framesGetDirect_0();
case 893819516: return bem_descriptionGet_0();
case -2113074324: return bem_klassNameGet_0();
case 486198208: return bem_fieldNamesGet_0();
case -1789612391: return bem_fieldIteratorGet_0();
case -414598998: return bem_translatedGet_0();
case 83573654: return bem_toString_0();
case -715946004: return bem_translatedGetDirect_0();
case -1408167825: return bem_framesGet_0();
case -1378912928: return bem_framesTextGetDirect_0();
case -2075263220: return bem_getFrameText_0();
case 1266624801: return bem_hashGet_0();
case -1419866779: return bem_lineNumberGet_0();
case 240462792: return bem_emitLangGet_0();
case -2028995013: return bem_new_0();
case -835557872: return bem_tagGet_0();
case -978167463: return bem_vvGetDirect_0();
case 1615388739: return bem_create_0();
case 610604781: return bem_echo_0();
case -2040844298: return bem_emitLangGetDirect_0();
case -1090479678: return bem_translateEmittedExceptionInner_0();
case -2111591272: return bem_sourceFileNameGet_0();
case 2089347046: return bem_classNameGet_0();
case 1600753962: return bem_toAny_0();
case 722840416: return bem_vvGet_0();
case 28192138: return bem_serializeContents_0();
case 1502073829: return bem_fileNameGetDirect_0();
case -1524172722: return bem_descriptionGetDirect_0();
case -1474366991: return bem_many_0();
case 15292588: return bem_serializeToString_0();
case 178924782: return bem_lineNumberGetDirect_0();
case -1264037424: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1792674751: return bem_translatedSetDirect_1(bevd_0);
case -2036046372: return bem_descriptionSetDirect_1(bevd_0);
case -637906169: return bem_lineNumberSet_1(bevd_0);
case -782460965: return bem_undef_1(bevd_0);
case 63361049: return bem_defined_1(bevd_0);
case 1407854223: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1798720087: return bem_lineNumberSetDirect_1(bevd_0);
case 1969847204: return bem_langSetDirect_1(bevd_0);
case -171174182: return bem_emitLangSet_1(bevd_0);
case 1289331226: return bem_vvSet_1(bevd_0);
case 2034381311: return bem_sameClass_1(bevd_0);
case -257313333: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1707619119: return bem_framesTextSet_1(bevd_0);
case 838251777: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -14933903: return bem_klassNameSet_1(bevd_0);
case -2052993013: return bem_methodNameSetDirect_1(bevd_0);
case -1379357757: return bem_methodNameSet_1(bevd_0);
case 1314079473: return bem_klassNameSetDirect_1(bevd_0);
case 487026714: return bem_framesSet_1(bevd_0);
case 1599766807: return bem_undefined_1(bevd_0);
case 1702750854: return bem_sameObject_1(bevd_0);
case -602251070: return bem_langSet_1(bevd_0);
case -18512538: return bem_framesSetDirect_1(bevd_0);
case 1504643735: return bem_translatedSet_1(bevd_0);
case 1494550577: return bem_vvSetDirect_1(bevd_0);
case -1208980303: return bem_otherClass_1(bevd_0);
case -1374791728: return bem_otherType_1(bevd_0);
case 405187323: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -317025047: return bem_copyTo_1(bevd_0);
case -348415642: return bem_notEquals_1(bevd_0);
case -99128923: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 952474121: return bem_def_1(bevd_0);
case -1507780801: return bem_new_1(bevd_0);
case 981626333: return bem_sameType_1(bevd_0);
case -2011440128: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -40544279: return bem_fileNameSet_1(bevd_0);
case 1522853956: return bem_fileNameSetDirect_1(bevd_0);
case 737278784: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1571709310: return bem_descriptionSet_1(bevd_0);
case 41258497: return bem_framesTextSetDirect_1(bevd_0);
case 1800715430: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1602734190: return bem_emitLangSetDirect_1(bevd_0);
case -1482822102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1315145363: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 2141890129: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -454079439: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 861143274: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -260132007: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 749345524: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1277474521: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2028665645: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 455421503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1452421085: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemCallOnNull();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
