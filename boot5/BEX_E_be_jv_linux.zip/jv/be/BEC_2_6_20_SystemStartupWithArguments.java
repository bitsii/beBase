package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_20_SystemStartupWithArguments extends BEC_2_6_6_SystemObject {
public BEC_2_6_20_SystemStartupWithArguments() { }
private static byte[] becc_BEC_2_6_20_SystemStartupWithArguments_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x57,0x69,0x74,0x68,0x41,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_6_20_SystemStartupWithArguments_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_20_SystemStartupWithArguments_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x4C,0x69,0x73,0x74,0x20,0x61,0x72,0x67,0x73,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
public static BEC_2_6_20_SystemStartupWithArguments bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst;

public static BET_2_6_20_SystemStartupWithArguments bece_BEC_2_6_20_SystemStartupWithArguments_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_20_SystemStartupWithArguments bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_20_SystemStartupWithArguments bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_ta_ph.bem_argsGet_0();
bevt_2_ta_ph = bevp_args.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(145, bece_BEC_2_6_20_SystemStartupWithArguments_bels_0));
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 72*/
bevt_7_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bevp_args.bem_get_1(bevt_9_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_createInstance_1((BEC_2_4_6_TextString) bevt_8_ta_ph );
bevl_x = bevt_6_ta_ph.bemd_0(-87056108);
bevt_10_ta_ph = bevl_x.bemd_1(-404274727, bevp_args);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_20_SystemStartupWithArguments bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {70, 70, 71, 71, 71, 71, 72, 72, 72, 74, 74, 74, 74, 74, 75, 75, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {32, 33, 34, 35, 36, 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 55, 58};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 70 32
new 0 70 32
assign 1 70 33
argsGet 0 70 33
assign 1 71 34
sizeGet 0 71 34
assign 1 71 35
new 0 71 35
assign 1 71 36
lesser 1 71 41
assign 1 72 42
new 0 72 42
assign 1 72 43
new 1 72 43
throw 1 72 44
assign 1 74 46
new 0 74 46
assign 1 74 47
new 0 74 47
assign 1 74 48
get 1 74 48
assign 1 74 49
createInstance 1 74 49
assign 1 74 50
new 0 74 50
assign 1 75 51
main 1 75 51
return 1 75 52
return 1 0 55
assign 1 0 58
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1450568577: return bem_hashGet_0();
case -566618225: return bem_argsGet_0();
case 1107488159: return bem_default_0();
case 1448984271: return bem_create_0();
case -87056108: return bem_new_0();
case 912871340: return bem_toString_0();
case -1166859559: return bem_iteratorGet_0();
case 2092961161: return bem_main_0();
case 633682209: return bem_print_0();
case 476934751: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1089041118: return bem_undef_1(bevd_0);
case 381130981: return bem_copyTo_1(bevd_0);
case 2106618550: return bem_def_1(bevd_0);
case -1486086431: return bem_equals_1(bevd_0);
case -1076047891: return bem_notEquals_1(bevd_0);
case 2112903635: return bem_argsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1900258780: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 551846529: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -658194391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -64978042: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_6_20_SystemStartupWithArguments_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_20_SystemStartupWithArguments_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_20_SystemStartupWithArguments();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_20_SystemStartupWithArguments.bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst = (BEC_2_6_20_SystemStartupWithArguments) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_20_SystemStartupWithArguments.bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_20_SystemStartupWithArguments.bece_BEC_2_6_20_SystemStartupWithArguments_bevs_type;
}
}
