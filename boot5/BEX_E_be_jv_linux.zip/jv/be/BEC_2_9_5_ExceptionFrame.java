package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_9_5_ExceptionFrame extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ExceptionFrame() { }
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clname = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x46,0x72,0x61,0x6D,0x65};
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x46,0x72,0x61,0x6D,0x65,0x3E,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_1 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_2 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_7 = {0x0A};
public static BEC_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_inst;

public static BET_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_type;

public BEC_2_4_6_TextString bevp_klassName;
public BEC_2_4_6_TextString bevp_methodName;
public BEC_2_4_6_TextString bevp_emitFileName;
public BEC_2_4_3_MathInt bevp_emitLine;
public BEC_2_4_6_TextString bevp_fileName;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_9_5_ExceptionFrame bem_new_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__emitFileName, BEC_2_4_3_MathInt beva__emitLine) throws Throwable {
bevp_klassName = beva__klassName;
bevp_methodName = beva__methodName;
bevp_emitFileName = beva__emitFileName;
bevp_emitLine = beva__emitLine;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_extractLine_0() throws Throwable {
BEC_2_6_16_SystemExceptionBuilder bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_16_SystemExceptionBuilder) BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
bevp_line = bevt_0_tmpany_phold.bem_getLineForEmitLine_2(bevp_klassName, bevp_emitLine);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevl_res = (new BEC_2_4_6_TextString(17, bece_BEC_2_9_5_ExceptionFrame_bels_0));
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_9_5_ExceptionFrame_bels_1));
bevl_res.bem_addValue_1(bevt_0_tmpany_phold);
if (bevp_klassName == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 493 */ {
bevl_res.bem_addValue_1(bevp_klassName);
} /* Line: 493 */
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_9_5_ExceptionFrame_bels_2));
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
if (bevp_methodName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 495 */ {
bevl_res.bem_addValue_1(bevp_methodName);
} /* Line: 495 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_9_5_ExceptionFrame_bels_3));
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
if (bevp_fileName == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevl_res.bem_addValue_1(bevp_fileName);
} /* Line: 497 */
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_9_5_ExceptionFrame_bels_4));
bevl_res.bem_addValue_1(bevt_6_tmpany_phold);
if (bevp_line == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 499 */ {
bevt_8_tmpany_phold = bevp_line.bem_toString_0();
bevl_res.bem_addValue_1(bevt_8_tmpany_phold);
} /* Line: 499 */
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_5));
bevl_res.bem_addValue_1(bevt_9_tmpany_phold);
if (bevp_emitFileName == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevl_res.bem_addValue_1(bevp_emitFileName);
} /* Line: 501 */
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_6));
bevl_res.bem_addValue_1(bevt_11_tmpany_phold);
if (bevp_emitLine == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_13_tmpany_phold = bevp_emitLine.bem_toString_0();
bevl_res.bem_addValue_1(bevt_13_tmpany_phold);
} /* Line: 503 */
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_9_5_ExceptionFrame_bels_7));
bevl_res.bem_addValue_1(bevt_14_tmpany_phold);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return bevp_klassName;
} /*method end*/
public final BEC_2_4_6_TextString bem_klassNameGetDirect_0() throws Throwable {
return bevp_klassName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public final BEC_2_4_6_TextString bem_methodNameGetDirect_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitFileNameGet_0() throws Throwable {
return bevp_emitFileName;
} /*method end*/
public final BEC_2_4_6_TextString bem_emitFileNameGetDirect_0() throws Throwable {
return bevp_emitFileName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_emitFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitLineGet_0() throws Throwable {
return bevp_emitLine;
} /*method end*/
public final BEC_2_4_3_MathInt bem_emitLineGetDirect_0() throws Throwable {
return bevp_emitLine;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitLineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_emitLineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public final BEC_2_4_6_TextString bem_fileNameGetDirect_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public final BEC_2_4_3_MathInt bem_lineGetDirect_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_lineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {471, 472, 473, 474, 487, 487, 491, 492, 492, 493, 493, 493, 494, 494, 495, 495, 495, 496, 496, 497, 497, 497, 498, 498, 499, 499, 499, 499, 500, 500, 501, 501, 501, 502, 502, 503, 503, 503, 503, 504, 504, 505, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 29, 34, 35, 55, 56, 57, 58, 63, 64, 66, 67, 68, 73, 74, 76, 77, 78, 83, 84, 86, 87, 88, 93, 94, 95, 97, 98, 99, 104, 105, 107, 108, 109, 114, 115, 116, 118, 119, 120, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 471 26
assign 1 472 27
assign 1 473 28
assign 1 474 29
assign 1 487 34
new 0 487 34
assign 1 487 35
getLineForEmitLine 2 487 35
assign 1 491 55
new 0 491 55
assign 1 492 56
new 0 492 56
addValue 1 492 57
assign 1 493 58
def 1 493 63
addValue 1 493 64
assign 1 494 66
new 0 494 66
addValue 1 494 67
assign 1 495 68
def 1 495 73
addValue 1 495 74
assign 1 496 76
new 0 496 76
addValue 1 496 77
assign 1 497 78
def 1 497 83
addValue 1 497 84
assign 1 498 86
new 0 498 86
addValue 1 498 87
assign 1 499 88
def 1 499 93
assign 1 499 94
toString 0 499 94
addValue 1 499 95
assign 1 500 97
new 0 500 97
addValue 1 500 98
assign 1 501 99
def 1 501 104
addValue 1 501 105
assign 1 502 107
new 0 502 107
addValue 1 502 108
assign 1 503 109
def 1 503 114
assign 1 503 115
toString 0 503 115
addValue 1 503 116
assign 1 504 118
new 0 504 118
addValue 1 504 119
return 1 505 120
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1737862711: return bem_print_0();
case -2036442591: return bem_toAny_0();
case -1698643956: return bem_serializationIteratorGet_0();
case -178992645: return bem_deserializeClassNameGet_0();
case 239325412: return bem_copy_0();
case -1737374632: return bem_methodNameGet_0();
case -1187132797: return bem_hashGet_0();
case 1236768538: return bem_iteratorGet_0();
case -1241033649: return bem_extractLine_0();
case 396059776: return bem_tagGet_0();
case -1635119200: return bem_lineGetDirect_0();
case 1319933824: return bem_classNameGet_0();
case 1616240746: return bem_toString_0();
case -520629360: return bem_emitLineGetDirect_0();
case -371367793: return bem_klassNameGetDirect_0();
case -980484092: return bem_new_0();
case -795764953: return bem_fieldIteratorGet_0();
case 1697432405: return bem_once_0();
case 1035468461: return bem_klassNameGet_0();
case -324733615: return bem_serializeToString_0();
case 2077314506: return bem_many_0();
case 803831998: return bem_emitFileNameGet_0();
case 854837664: return bem_create_0();
case -472564109: return bem_fileNameGetDirect_0();
case 2118534320: return bem_emitLineGet_0();
case -1739765069: return bem_lineGet_0();
case -1168205029: return bem_emitFileNameGetDirect_0();
case -1687769721: return bem_methodNameGetDirect_0();
case 1461522196: return bem_fileNameGet_0();
case 1486098436: return bem_fieldNamesGet_0();
case -760211542: return bem_sourceFileNameGet_0();
case -1159943693: return bem_echo_0();
case -604973932: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1109276399: return bem_sameObject_1(bevd_0);
case -1097624238: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 473000864: return bem_lineSet_1(bevd_0);
case 962423408: return bem_def_1(bevd_0);
case -1120436550: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -476565222: return bem_emitLineSet_1(bevd_0);
case 154468762: return bem_emitFileNameSetDirect_1(bevd_0);
case -354650091: return bem_undef_1(bevd_0);
case 1075750255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 850683733: return bem_equals_1(bevd_0);
case 1229731165: return bem_copyTo_1(bevd_0);
case 2105787456: return bem_methodNameSetDirect_1(bevd_0);
case 395717057: return bem_defined_1(bevd_0);
case -611296396: return bem_emitFileNameSet_1(bevd_0);
case 1784508277: return bem_undefined_1(bevd_0);
case -58601680: return bem_sameType_1(bevd_0);
case 1021147088: return bem_otherClass_1(bevd_0);
case -1842266869: return bem_emitLineSetDirect_1(bevd_0);
case -1754732193: return bem_notEquals_1(bevd_0);
case -645727759: return bem_klassNameSet_1(bevd_0);
case 1671368653: return bem_lineSetDirect_1(bevd_0);
case 486594455: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2004361336: return bem_klassNameSetDirect_1(bevd_0);
case 97582880: return bem_fileNameSetDirect_1(bevd_0);
case 215737112: return bem_otherType_1(bevd_0);
case 208741912: return bem_fileNameSet_1(bevd_0);
case -1864431979: return bem_methodNameSet_1(bevd_0);
case 1479379696: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 602921151: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1012334348: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 661390803: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -434648658: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 192635884: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 103255187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 834345030: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1256110432: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ExceptionFrame_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_5_ExceptionFrame_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ExceptionFrame();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst = (BEC_2_9_5_ExceptionFrame) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_type;
}
}
