package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_8_BuildAccessor extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildAccessor() { }
private static byte[] becc_BEC_2_5_8_BuildAccessor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] becc_BEC_2_5_8_BuildAccessor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildAccessor_bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
public static BEC_2_5_8_BuildAccessor bece_BEC_2_5_8_BuildAccessor_bevs_inst;

public static BET_2_5_8_BuildAccessor bece_BEC_2_5_8_BuildAccessor_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildAccessor bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_7_SystemClasses bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevl_ret = bevt_0_ta_ph.bem_className_1(this);
if (bevp_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 369*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_8_BuildAccessor_bels_0));
bevt_2_ta_ph = bevl_ret.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
} /* Line: 370*/
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_8_BuildAccessor bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {368, 368, 369, 369, 370, 370, 370, 370, 372, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 30, 31, 32, 33, 34, 36, 39, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 368 23
new 0 368 23
assign 1 368 24
className 1 368 24
assign 1 369 25
def 1 369 30
assign 1 370 31
new 0 370 31
assign 1 370 32
add 1 370 32
assign 1 370 33
toString 0 370 33
assign 1 370 34
add 1 370 34
return 1 372 36
return 1 0 39
assign 1 0 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1553579298: return bem_create_0();
case -879452611: return bem_iteratorGet_0();
case -1334228416: return bem_copy_0();
case -1613872813: return bem_toString_0();
case -302306326: return bem_print_0();
case 850665615: return bem_nameGet_0();
case -623084206: return bem_hashGet_0();
case -668031687: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1595922574: return bem_notEquals_1(bevd_0);
case -106068549: return bem_undef_1(bevd_0);
case -2083179763: return bem_def_1(bevd_0);
case 1553693181: return bem_copyTo_1(bevd_0);
case 484307125: return bem_nameSet_1(bevd_0);
case 183226086: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -529409169: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1780160067: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1663342083: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -123507493: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildAccessor_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildAccessor_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildAccessor();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildAccessor.bece_BEC_2_5_8_BuildAccessor_bevs_inst = (BEC_2_5_8_BuildAccessor) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildAccessor.bece_BEC_2_5_8_BuildAccessor_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_8_BuildAccessor.bece_BEC_2_5_8_BuildAccessor_bevs_type;
}
}
