package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 566 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 567 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 585 */
} /* Line: 567 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-1467489425, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {567, 567, 585, 591, 592, 596, 597, 598};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 28, 34, 35, 40, 41, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 567 20
undef 1 567 25
setName 1 585 28
assign 1 591 34
buildProfile 0 592 35
buildProfile 0 596 40
assign 1 597 41
new 0 597 41
newlineSet 1 598 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2022113180: return bem_toAny_0();
case -1002223418: return bem_deserializeClassNameGet_0();
case 1226301190: return bem_create_0();
case -433278174: return bem_isWinGet_0();
case 2128158896: return bem_iteratorGet_0();
case 520256150: return bem_print_0();
case -402973175: return bem_toString_0();
case 304205171: return bem_sourceFileNameGet_0();
case 722454495: return bem_nameGet_0();
case -728251540: return bem_echo_0();
case -504481294: return bem_separatorGetDirect_0();
case 619154838: return bem_separatorGet_0();
case -1347713072: return bem_many_0();
case 1971636542: return bem_fieldIteratorGet_0();
case 1505210733: return bem_isNixGet_0();
case 404656130: return bem_nullFileGetDirect_0();
case 1545963265: return bem_tagGet_0();
case 502686321: return bem_serializeToString_0();
case -92297996: return bem_serializeContents_0();
case 1362114893: return bem_hashGet_0();
case 737140358: return bem_nullFileGet_0();
case 592499503: return bem_serializationIteratorGet_0();
case -1626979383: return bem_nameGetDirect_0();
case -1541237194: return bem_once_0();
case 2082915487: return bem_copy_0();
case 1820005525: return bem_buildProfile_0();
case 1805972569: return bem_isNixGetDirect_0();
case 577608981: return bem_default_0();
case -1977850039: return bem_newlineGetDirect_0();
case 580957788: return bem_fieldNamesGet_0();
case 598032428: return bem_otherSeparatorGet_0();
case -2101831965: return bem_otherSeparatorGetDirect_0();
case -2116643638: return bem_newlineGet_0();
case 1646548716: return bem_isWinGetDirect_0();
case -302299890: return bem_new_0();
case -1909928939: return bem_classNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1104827466: return bem_undefined_1(bevd_0);
case 225439950: return bem_def_1(bevd_0);
case -1467489425: return bem_newlineSet_1(bevd_0);
case 1848239305: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -197215166: return bem_otherSeparatorSetDirect_1(bevd_0);
case 1605421146: return bem_nullFileSetDirect_1(bevd_0);
case 483768515: return bem_separatorSetDirect_1(bevd_0);
case -1241317639: return bem_sameClass_1(bevd_0);
case -1990059666: return bem_notEquals_1(bevd_0);
case 14285247: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1639949432: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case 1792795924: return bem_separatorSet_1(bevd_0);
case 456193338: return bem_equals_1(bevd_0);
case -1265978299: return bem_otherType_1(bevd_0);
case -1543668236: return bem_sameObject_1(bevd_0);
case 359436076: return bem_newlineSetDirect_1(bevd_0);
case 468336390: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2144617140: return bem_isWinSetDirect_1(bevd_0);
case -1951238169: return bem_isNixSet_1(bevd_0);
case -1896863293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 52206223: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -969382839: return bem_nameSet_1(bevd_0);
case 843456674: return bem_undef_1(bevd_0);
case -1023190150: return bem_otherSeparatorSet_1(bevd_0);
case -1133289250: return bem_copyTo_1(bevd_0);
case -1675072243: return bem_sameType_1(bevd_0);
case 294741010: return bem_otherClass_1(bevd_0);
case -2036568336: return bem_nameSetDirect_1(bevd_0);
case -799657616: return bem_defined_1(bevd_0);
case -1400936977: return bem_isWinSet_1(bevd_0);
case 135819040: return bem_isNixSetDirect_1(bevd_0);
case -2037649223: return bem_nullFileSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -602636079: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -679395862: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2109649093: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -541558230: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1478248032: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1942858685: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1297550285: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
