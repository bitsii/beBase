package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 551 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 552 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 575 */
} /* Line: 552 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-2093893203, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {552, 552, 575, 581, 582, 586, 587, 588};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 28, 34, 35, 40, 41, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 552 20
undef 1 552 25
setName 1 575 28
assign 1 581 34
buildProfile 0 582 35
buildProfile 0 586 40
assign 1 587 41
new 0 587 41
newlineSet 1 588 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1611055106: return bem_fieldNamesGet_0();
case -127339885: return bem_isWinGet_0();
case 1981654959: return bem_once_0();
case -217835874: return bem_tagGet_0();
case 3352978: return bem_isNixGet_0();
case -1184845662: return bem_isWinGetDirect_0();
case -397559289: return bem_fieldIteratorGet_0();
case -1465418055: return bem_nameGetDirect_0();
case -1629544591: return bem_many_0();
case 346235852: return bem_sourceFileNameGet_0();
case 599671203: return bem_otherSeparatorGetDirect_0();
case 718789172: return bem_iteratorGet_0();
case -207569400: return bem_serializeToString_0();
case -139666523: return bem_separatorGetDirect_0();
case -480687649: return bem_print_0();
case 1230302912: return bem_hashGet_0();
case 1934552751: return bem_newlineGet_0();
case 1593282962: return bem_isNixGetDirect_0();
case -360613383: return bem_serializeContents_0();
case 1703770598: return bem_otherSeparatorGet_0();
case -754156096: return bem_nullFileGetDirect_0();
case -327314699: return bem_newlineGetDirect_0();
case -915808255: return bem_serializationIteratorGet_0();
case -1278273894: return bem_toAny_0();
case 857471143: return bem_buildProfile_0();
case -1308933810: return bem_deserializeClassNameGet_0();
case 357537975: return bem_classNameGet_0();
case 2059101640: return bem_default_0();
case -1762356041: return bem_toString_0();
case -638442685: return bem_echo_0();
case 662857090: return bem_nullFileGet_0();
case 412923694: return bem_nameGet_0();
case 1132290948: return bem_separatorGet_0();
case -22393727: return bem_create_0();
case -507124439: return bem_new_0();
case 847337627: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -85231606: return bem_isNixSet_1(bevd_0);
case 1387628079: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1999267396: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 580318355: return bem_otherType_1(bevd_0);
case -2093893203: return bem_newlineSet_1(bevd_0);
case 1379835000: return bem_defined_1(bevd_0);
case 1273353241: return bem_notEquals_1(bevd_0);
case 1775222585: return bem_separatorSet_1(bevd_0);
case -238974491: return bem_isNixSetDirect_1(bevd_0);
case 1418552655: return bem_def_1(bevd_0);
case -665968375: return bem_sameType_1(bevd_0);
case -1792792197: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -966659213: return bem_otherSeparatorSet_1(bevd_0);
case -1256041694: return bem_copyTo_1(bevd_0);
case -1263961885: return bem_otherClass_1(bevd_0);
case -421397740: return bem_nullFileSet_1(bevd_0);
case 432484872: return bem_isWinSetDirect_1(bevd_0);
case 1787128072: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1342602458: return bem_nameSet_1(bevd_0);
case -794657115: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2056947488: return bem_sameClass_1(bevd_0);
case 1210343928: return bem_nullFileSetDirect_1(bevd_0);
case -408502512: return bem_equals_1(bevd_0);
case -436547338: return bem_undefined_1(bevd_0);
case 306411072: return bem_isWinSet_1(bevd_0);
case -670980987: return bem_otherSeparatorSetDirect_1(bevd_0);
case 593018128: return bem_nameSetDirect_1(bevd_0);
case 1530291279: return bem_sameObject_1(bevd_0);
case 321693734: return bem_undef_1(bevd_0);
case -1389906830: return bem_newlineSetDirect_1(bevd_0);
case 1849763669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1850585622: return bem_separatorSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -318431301: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1103544796: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138830036: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -554397969: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2122183893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 975610887: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -799307739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
