package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 566 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 567 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 585 */
} /* Line: 567 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(600032797, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {567, 567, 585, 591, 592, 596, 597, 598};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 28, 34, 35, 40, 41, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 567 20
undef 1 567 25
setName 1 585 28
assign 1 591 34
buildProfile 0 592 35
buildProfile 0 596 40
assign 1 597 41
new 0 597 41
newlineSet 1 598 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 744108516: return bem_isWinGet_0();
case 847900593: return bem_serializeContents_0();
case -1099311989: return bem_once_0();
case 1991865303: return bem_nullFileGet_0();
case -1220916727: return bem_many_0();
case 2080907218: return bem_echo_0();
case 1059907561: return bem_classNameGet_0();
case 774012273: return bem_new_0();
case -1228227275: return bem_deserializeClassNameGet_0();
case 1975956372: return bem_hashGet_0();
case -145884335: return bem_separatorGet_0();
case 800496164: return bem_newlineGet_0();
case 955964248: return bem_buildProfile_0();
case -1131153280: return bem_copy_0();
case 827292547: return bem_create_0();
case 677808118: return bem_toString_0();
case -1452252398: return bem_otherSeparatorGet_0();
case -362294474: return bem_sourceFileNameGet_0();
case 1616854488: return bem_print_0();
case -1822647821: return bem_isNixGet_0();
case -497405976: return bem_tagGet_0();
case 887158094: return bem_fieldIteratorGet_0();
case -1571656834: return bem_toAny_0();
case 1204337669: return bem_nameGet_0();
case 585989692: return bem_serializeToString_0();
case 988563641: return bem_iteratorGet_0();
case -1707345921: return bem_serializationIteratorGet_0();
case -236699214: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1688762922: return bem_nullFileSet_1(bevd_0);
case 197557310: return bem_undef_1(bevd_0);
case -1133393159: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1178060129: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 410232788: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1738131214: return bem_separatorSet_1(bevd_0);
case 600032797: return bem_newlineSet_1(bevd_0);
case -970121374: return bem_equals_1(bevd_0);
case -509282757: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -1649058984: return bem_sameType_1(bevd_0);
case 332207443: return bem_isWinSet_1(bevd_0);
case 1998346117: return bem_undefined_1(bevd_0);
case -1542443673: return bem_copyTo_1(bevd_0);
case 1434568333: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1727272588: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1013351049: return bem_otherClass_1(bevd_0);
case 1910844205: return bem_defined_1(bevd_0);
case 1730126997: return bem_def_1(bevd_0);
case -1599156894: return bem_sameClass_1(bevd_0);
case -248970787: return bem_sameObject_1(bevd_0);
case 1248878306: return bem_notEquals_1(bevd_0);
case 199348146: return bem_otherSeparatorSet_1(bevd_0);
case -1996018134: return bem_nameSet_1(bevd_0);
case -1883746791: return bem_otherType_1(bevd_0);
case 1404191644: return bem_isNixSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 755484682: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -831651783: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1440576715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1239513525: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383341402: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1754203643: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126803346: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
