package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 536 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 537 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 555 */
} /* Line: 537 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(1837788796, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {537, 537, 555, 561, 562, 566, 567, 568};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 28, 34, 35, 40, 41, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 537 20
undef 1 537 25
setName 1 555 28
assign 1 561 34
buildProfile 0 562 35
buildProfile 0 566 40
assign 1 567 41
new 0 567 41
newlineSet 1 568 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -511882924: return bem_otherSeparatorGetDirect_0();
case -1009286812: return bem_iteratorGet_0();
case 1872768111: return bem_nameGetDirect_0();
case 14277864: return bem_buildProfile_0();
case -138934452: return bem_serializationIteratorGet_0();
case -162465408: return bem_classNameGet_0();
case -1653065356: return bem_serializeToString_0();
case 35710370: return bem_default_0();
case -826924838: return bem_fieldIteratorGet_0();
case 357618761: return bem_new_0();
case 1079173462: return bem_isNixGetDirect_0();
case -674115535: return bem_separatorGetDirect_0();
case 1206679142: return bem_otherSeparatorGet_0();
case 16105327: return bem_newlineGet_0();
case -1528945516: return bem_fieldNamesGet_0();
case 71860751: return bem_create_0();
case 562585408: return bem_nullFileGetDirect_0();
case 1899370103: return bem_echo_0();
case -257986663: return bem_nameGet_0();
case -1110408952: return bem_separatorGet_0();
case 1531519425: return bem_isWinGet_0();
case -135422993: return bem_isNixGet_0();
case 1555639231: return bem_print_0();
case 1881523822: return bem_deserializeClassNameGet_0();
case 1901482140: return bem_tagGet_0();
case -1774143633: return bem_once_0();
case -1947518603: return bem_nullFileGet_0();
case -275244597: return bem_hashGet_0();
case 216387563: return bem_many_0();
case -716934857: return bem_serializeContents_0();
case 171029106: return bem_newlineGetDirect_0();
case -2101622436: return bem_sourceFileNameGet_0();
case -1959404700: return bem_isWinGetDirect_0();
case -2036889336: return bem_toAny_0();
case -702348589: return bem_toString_0();
case -1118611827: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1689781129: return bem_newlineSetDirect_1(bevd_0);
case -1106969435: return bem_isNixSetDirect_1(bevd_0);
case -2130714868: return bem_equals_1(bevd_0);
case 1353620660: return bem_sameClass_1(bevd_0);
case -2050032116: return bem_nullFileSet_1(bevd_0);
case 66254795: return bem_sameType_1(bevd_0);
case 29628007: return bem_otherSeparatorSetDirect_1(bevd_0);
case -1336240275: return bem_separatorSetDirect_1(bevd_0);
case 1459678776: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -68723535: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 814727407: return bem_notEquals_1(bevd_0);
case 1137403549: return bem_copyTo_1(bevd_0);
case 734757187: return bem_nameSet_1(bevd_0);
case -668891382: return bem_isWinSet_1(bevd_0);
case -1082439894: return bem_sameObject_1(bevd_0);
case 867532042: return bem_nullFileSetDirect_1(bevd_0);
case -1248174316: return bem_nameSetDirect_1(bevd_0);
case -1339829082: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1193778385: return bem_undefined_1(bevd_0);
case 1007660278: return bem_isNixSet_1(bevd_0);
case -1493100314: return bem_otherClass_1(bevd_0);
case -725487873: return bem_otherSeparatorSet_1(bevd_0);
case 1327715689: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -2109980302: return bem_undef_1(bevd_0);
case 1837788796: return bem_newlineSet_1(bevd_0);
case 2082558825: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -959745115: return bem_otherType_1(bevd_0);
case 2027670755: return bem_defined_1(bevd_0);
case -1739487055: return bem_separatorSet_1(bevd_0);
case 2123352609: return bem_isWinSetDirect_1(bevd_0);
case -1759126894: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1325575386: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 70790709: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020619337: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 163657925: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1186365239: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 686267336: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271558857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1157880701: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
