package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 251*/ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 281*/
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(1397965870, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {251, 251, 281, 287, 288, 292, 293, 294};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 24, 27, 32, 33, 38, 39, 40};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 251 19
undef 1 251 24
setName 1 281 27
assign 1 287 32
buildProfile 0 288 33
buildProfile 0 292 38
assign 1 293 39
new 0 293 39
newlineSet 1 294 40
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1714749318: return bem_nameGet_0();
case -1233241901: return bem_toString_0();
case 1862660644: return bem_new_0();
case -1618788881: return bem_separatorGet_0();
case -748394026: return bem_hashGet_0();
case -393844090: return bem_copy_0();
case 1121110905: return bem_scriptExtGet_0();
case -1240571169: return bem_default_0();
case -68652187: return bem_otherSeparatorGet_0();
case 2066241869: return bem_print_0();
case 118893440: return bem_properNameGet_0();
case -1079825495: return bem_iteratorGet_0();
case -1444449081: return bem_buildProfile_0();
case 1160279532: return bem_create_0();
case -1507617716: return bem_nullFileGet_0();
case -1594862523: return bem_newlineGet_0();
case 211850413: return bem_isNixGet_0();
case 1690883231: return bem_isWinGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -758987114: return bem_nullFileSet_1(bevd_0);
case 686634658: return bem_separatorSet_1(bevd_0);
case 1902022464: return bem_print_1(bevd_0);
case -341177330: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -1817095818: return bem_isWinSet_1(bevd_0);
case 477335908: return bem_otherSeparatorSet_1(bevd_0);
case 1819851806: return bem_properNameSet_1(bevd_0);
case -71355600: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 310887766: return bem_undef_1(bevd_0);
case 1921787435: return bem_equals_1(bevd_0);
case -1215278694: return bem_def_1(bevd_0);
case -1468774418: return bem_nameSet_1(bevd_0);
case 603451780: return bem_isNixSet_1(bevd_0);
case -465513410: return bem_copyTo_1(bevd_0);
case 1397965870: return bem_newlineSet_1(bevd_0);
case 1633476346: return bem_notEquals_1(bevd_0);
case -860307359: return bem_scriptExtSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1745573040: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1324104974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1411462266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1926749857: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
