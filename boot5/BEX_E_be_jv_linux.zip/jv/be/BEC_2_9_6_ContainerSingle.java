package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_6_ContainerSingle extends BEC_2_6_6_SystemObject {
public BEC_2_9_6_ContainerSingle() { }
private static byte[] becc_BEC_2_9_6_ContainerSingle_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x69,0x6E,0x67,0x6C,0x65};
private static byte[] becc_BEC_2_9_6_ContainerSingle_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_6_ContainerSingle bece_BEC_2_9_6_ContainerSingle_bevs_inst;

public static BET_2_9_6_ContainerSingle bece_BEC_2_9_6_ContainerSingle_bevs_type;

public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_6_ContainerSingle bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_6_ContainerSingle bem_new_1(BEC_2_6_6_SystemObject beva__first) throws Throwable {
bevp_first = beva__first;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_firstGetDirect_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_9_6_ContainerSingle bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_6_ContainerSingle bem_firstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 20, 23, 26, 30};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 16
return 1 0 20
return 1 0 23
assign 1 0 26
assign 1 0 30
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -835557872: return bem_tagGet_0();
case -1264037424: return bem_copy_0();
case -1833113172: return bem_serializationIteratorGet_0();
case -1789612391: return bem_fieldIteratorGet_0();
case 114010471: return bem_firstGet_0();
case -2028995013: return bem_new_0();
case 28192138: return bem_serializeContents_0();
case -1180336274: return bem_iteratorGet_0();
case -1873931192: return bem_print_0();
case -1474366991: return bem_many_0();
case -2111591272: return bem_sourceFileNameGet_0();
case 15292588: return bem_serializeToString_0();
case 1266624801: return bem_hashGet_0();
case 83573654: return bem_toString_0();
case 486036595: return bem_once_0();
case 1600753962: return bem_toAny_0();
case 610604781: return bem_echo_0();
case 2089347046: return bem_classNameGet_0();
case 880895272: return bem_firstGetDirect_0();
case 486198208: return bem_fieldNamesGet_0();
case -1005390218: return bem_deserializeClassNameGet_0();
case 1615388739: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -348415642: return bem_notEquals_1(bevd_0);
case 2034381311: return bem_sameClass_1(bevd_0);
case 1702750854: return bem_sameObject_1(bevd_0);
case -782460965: return bem_undef_1(bevd_0);
case -99128923: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 952474121: return bem_def_1(bevd_0);
case -257313333: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 63361049: return bem_defined_1(bevd_0);
case -1208980303: return bem_otherClass_1(bevd_0);
case -694908327: return bem_firstSetDirect_1(bevd_0);
case 1599766807: return bem_undefined_1(bevd_0);
case -1482822102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1425053649: return bem_firstSet_1(bevd_0);
case -317025047: return bem_copyTo_1(bevd_0);
case 981626333: return bem_sameType_1(bevd_0);
case -1507780801: return bem_new_1(bevd_0);
case -1374791728: return bem_otherType_1(bevd_0);
case 2141890129: return bem_equals_1(bevd_0);
case -2011440128: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -454079439: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 861143274: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -260132007: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 749345524: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1277474521: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2028665645: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 455421503: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_9_6_ContainerSingle_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_6_ContainerSingle_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_6_ContainerSingle();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_inst = (BEC_2_9_6_ContainerSingle) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_6_ContainerSingle.bece_BEC_2_9_6_ContainerSingle_bevs_type;
}
}
