package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_DigestSHA1 extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_DigestSHA1() { }

   
    public MessageDigest bevi_md;
    
   private static byte[] becc_BEC_2_6_4_DigestSHA1_clname = {0x44,0x69,0x67,0x65,0x73,0x74,0x3A,0x53,0x48,0x41,0x31};
private static byte[] becc_BEC_2_6_4_DigestSHA1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
public static BEC_2_6_4_DigestSHA1 bece_BEC_2_6_4_DigestSHA1_bevs_inst;
public BEC_2_6_4_DigestSHA1 bem_new_0() throws Throwable {

        bevi_md = MessageDigest.getInstance("SHA-1");
        return this;
} /*method end*/
public BEC_2_4_6_TextString bem_digest_1(BEC_2_4_6_TextString beva_with) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bem_new_0();

        bevi_md.update(beva_with.bevi_bytes, 0, beva_with.bevp_size.bevi_int);
        bevl_res = new BEC_2_4_6_TextString(bevi_md.digest());
        return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_digestToHex_1(BEC_2_4_6_TextString beva_input) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_3_EncodeHex bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevt_2_tmpany_phold = bem_digest_1(beva_input);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_encode_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {149, 164, 168, 168, 168, 168};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 25, 31, 32, 33, 34};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 149 21
return 1 164 25
assign 1 168 31
new 0 168 31
assign 1 168 32
digest 1 168 32
assign 1 168 33
encode 1 168 33
return 1 168 34
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -486730947: return bem_tagGet_0();
case 1823731495: return bem_fieldIteratorGet_0();
case 192353495: return bem_toString_0();
case 991850509: return bem_hashGet_0();
case -610207516: return bem_print_0();
case -2002314890: return bem_serializeContents_0();
case 380917179: return bem_deserializeClassNameGet_0();
case -706394436: return bem_classNameGet_0();
case -1997732490: return bem_serializeToString_0();
case 2007419844: return bem_sourceFileNameGet_0();
case 1071338406: return bem_once_0();
case 1222559837: return bem_toAny_0();
case 903380622: return bem_copy_0();
case -438931987: return bem_many_0();
case 89921707: return bem_echo_0();
case -145517521: return bem_iteratorGet_0();
case -288603233: return bem_serializationIteratorGet_0();
case 150815360: return bem_new_0();
case 1733022581: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -177732522: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 754254864: return bem_sameType_1(bevd_0);
case 1234343289: return bem_def_1(bevd_0);
case 698316509: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1886873191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1794454226: return bem_undef_1(bevd_0);
case -907803894: return bem_otherType_1(bevd_0);
case -2038181641: return bem_copyTo_1(bevd_0);
case -1587661946: return bem_sameObject_1(bevd_0);
case 794867581: return bem_digest_1((BEC_2_4_6_TextString) bevd_0);
case -174280441: return bem_otherClass_1(bevd_0);
case 1702402169: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1812425724: return bem_notEquals_1(bevd_0);
case -2087149042: return bem_undefined_1(bevd_0);
case 567792086: return bem_digestToHex_1((BEC_2_4_6_TextString) bevd_0);
case -226295549: return bem_sameClass_1(bevd_0);
case 568764092: return bem_equals_1(bevd_0);
case -1951248711: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -862992684: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 608937217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1346377346: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1911273797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1789964230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2066895296: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1538374916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_DigestSHA1_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_4_DigestSHA1_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_DigestSHA1();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_DigestSHA1.bece_BEC_2_6_4_DigestSHA1_bevs_inst = (BEC_2_6_4_DigestSHA1) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_DigestSHA1.bece_BEC_2_6_4_DigestSHA1_bevs_inst;
}
}
