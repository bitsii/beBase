package be;
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_11_SystemTestInExtending extends BEC_3_6_4_10_SystemTestExtendable {
public BEC_3_6_4_11_SystemTestInExtending() { }
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x49,0x6E,0x45,0x78,0x74,0x65,0x6E,0x64,0x69,0x6E,0x67};
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;

public static BET_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_type;

public BEC_2_6_6_SystemObject bevp_prop2a;
public BEC_3_6_4_11_SystemTestInExtending bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_bcall_0() throws Throwable {
bevp_propa.bemd_0(653341959);
return this;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_ccall_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prop2aGet_0() throws Throwable {
return bevp_prop2a;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_prop2aGetDirect_0() throws Throwable {
return bevp_prop2a;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_prop2aSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_4_11_SystemTestInExtending bem_prop2aSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {221, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 23, 26, 29, 33};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
print 0 221 16
return 1 0 23
return 1 0 26
assign 1 0 29
assign 1 0 33
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1066226610: return bem_fieldNamesGet_0();
case 363453571: return bem_bcall_0();
case -1976480232: return bem_once_0();
case -1500978633: return bem_tagGet_0();
case -1439875774: return bem_new_0();
case -283074086: return bem_acall_0();
case 332143017: return bem_propaGet_0();
case 191896611: return bem_copy_0();
case 1583078226: return bem_prop2aGetDirect_0();
case 1525639803: return bem_sourceFileNameGet_0();
case -1759630984: return bem_classNameGet_0();
case -114079936: return bem_serializeContents_0();
case -1195111829: return bem_create_0();
case 247282961: return bem_propbGet_0();
case -429513107: return bem_propaGetDirect_0();
case 1430998361: return bem_serializationIteratorGet_0();
case -1551806822: return bem_toAny_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case 2036147796: return bem_toString_0();
case 573647971: return bem_iteratorGet_0();
case -1737009900: return bem_many_0();
case 767561978: return bem_propbGetDirect_0();
case 653341959: return bem_print_0();
case 1201799861: return bem_serializeToString_0();
case -2072472298: return bem_hashGet_0();
case -1786926244: return bem_prop2aGet_0();
case -1748925107: return bem_echo_0();
case 2102651338: return bem_fieldIteratorGet_0();
case -1820027668: return bem_ccall_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -102295312: return bem_sameObject_1(bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case 2112832081: return bem_propaSet_1(bevd_0);
case 1256968945: return bem_propbSet_1(bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case -192271885: return bem_equals_1(bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case -94102376: return bem_prop2aSet_1(bevd_0);
case 884462515: return bem_def_1(bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 939965807: return bem_propbSetDirect_1(bevd_0);
case -539842211: return bem_prop2aSetDirect_1(bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
case 637787171: return bem_propaSetDirect_1(bevd_0);
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_6_4_11_SystemTestInExtending_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_11_SystemTestInExtending_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_4_11_SystemTestInExtending();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst = (BEC_3_6_4_11_SystemTestInExtending) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_type;
}
}
