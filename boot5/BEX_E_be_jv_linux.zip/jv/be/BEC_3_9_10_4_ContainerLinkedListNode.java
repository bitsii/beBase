package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_4_ContainerLinkedListNode extends BEC_2_6_6_SystemObject {
public BEC_3_9_10_4_ContainerLinkedListNode() { }
private static byte[] becc_BEC_3_9_10_4_ContainerLinkedListNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_4_ContainerLinkedListNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_4_ContainerLinkedListNode bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_prior;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_next;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_9_10_ContainerLinkedList bevp_mylist;
public BEC_3_9_10_4_ContainerLinkedListNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) throws Throwable {
bevp_held = beva__held;
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_insertBefore_1(BEC_2_6_6_SystemObject beva_toIns) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_toIns.bemd_1(1673799664, null);
beva_toIns.bemd_1(-1303020200, this);
beva_toIns.bemd_1(1395399800, bevp_mylist);
bevl_p = bevp_prior;
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) beva_toIns;
if (bevl_p == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevp_mylist.bem_firstNodeSet_1(beva_toIns);
} /* Line: 60 */
 else  /* Line: 61 */ {
bevl_p.bem_nextSet_1(beva_toIns);
beva_toIns.bemd_1(1673799664, bevl_p);
} /* Line: 63 */
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_delete_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevl_p = bevp_prior;
bevl_n = bevp_next;
bevp_next = null;
bevp_prior = null;
if (bevl_p == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevp_mylist.bem_firstNodeSet_1(bevl_n);
if (bevl_n == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 75 */ {
bevl_n.bem_priorSet_1(null);
} /* Line: 76 */
 else  /* Line: 77 */ {
bevp_mylist.bem_lastNodeSet_1(bevl_n);
} /* Line: 79 */
} /* Line: 75 */
 else  /* Line: 72 */ {
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevl_p.bem_nextSet_1(bevl_n);
bevp_mylist.bem_lastNodeSet_1(bevl_p);
} /* Line: 84 */
 else  /* Line: 85 */ {
bevl_p.bem_nextSet_1(bevl_n);
bevl_n.bem_priorSet_1(bevl_p);
} /* Line: 88 */
} /* Line: 72 */
bevp_mylist = null;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_priorGet_0() throws Throwable {
return bevp_prior;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_priorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_nextGet_0() throws Throwable {
return bevp_next;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_nextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_next = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_mylistGet_0() throws Throwable {
return bevp_mylist;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_mylistSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mylist = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {45, 46, 53, 54, 55, 56, 57, 58, 58, 60, 62, 63, 68, 69, 70, 71, 72, 72, 74, 75, 75, 76, 79, 81, 81, 83, 84, 87, 88, 90, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 20, 21, 22, 23, 24, 25, 30, 31, 34, 35, 45, 46, 47, 48, 49, 54, 55, 56, 61, 62, 65, 69, 74, 75, 76, 79, 80, 83, 87, 90, 94, 97, 101, 104, 108, 111};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 45 13
assign 1 46 14
priorSet 1 53 20
nextSet 1 54 21
mylistSet 1 55 22
assign 1 56 23
assign 1 57 24
assign 1 58 25
undef 1 58 30
firstNodeSet 1 60 31
nextSet 1 62 34
priorSet 1 63 35
assign 1 68 45
assign 1 69 46
assign 1 70 47
assign 1 71 48
assign 1 72 49
undef 1 72 54
firstNodeSet 1 74 55
assign 1 75 56
def 1 75 61
priorSet 1 76 62
lastNodeSet 1 79 65
assign 1 81 69
undef 1 81 74
nextSet 1 83 75
lastNodeSet 1 84 76
nextSet 1 87 79
priorSet 1 88 80
assign 1 90 83
return 1 0 87
assign 1 0 90
return 1 0 94
assign 1 0 97
return 1 0 101
assign 1 0 104
return 1 0 108
assign 1 0 111
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 648643859: return bem_sourceFileNameGet_0();
case -266150550: return bem_many_0();
case -140910844: return bem_nextGet_0();
case 1740583826: return bem_serializeToString_0();
case 895906767: return bem_toString_0();
case 978873391: return bem_deserializeClassNameGet_0();
case 1330053746: return bem_classNameGet_0();
case -1666892068: return bem_once_0();
case -1256903143: return bem_print_0();
case -748130189: return bem_echo_0();
case 1782125853: return bem_hashGet_0();
case -1175539557: return bem_mylistGet_0();
case 721298840: return bem_serializationIteratorGet_0();
case -67323485: return bem_create_0();
case -907223016: return bem_iteratorGet_0();
case -82076223: return bem_heldGet_0();
case 394710523: return bem_toAny_0();
case 19655765: return bem_tagGet_0();
case -1755437106: return bem_serializeContents_0();
case 278062989: return bem_delete_0();
case 1781926555: return bem_copy_0();
case -2089883321: return bem_new_0();
case -1693411633: return bem_fieldIteratorGet_0();
case 1396930364: return bem_priorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2119054446: return bem_otherType_1(bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case 803845413: return bem_def_1(bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1305409782: return bem_insertBefore_1(bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case 2101115729: return bem_heldSet_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case -1303020200: return bem_nextSet_1(bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1673799664: return bem_priorSet_1(bevd_0);
case -2097315666: return bem_sameClass_1(bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case 1395399800: return bem_mylistSet_1(bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -616454629: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_4_ContainerLinkedListNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_4_ContainerLinkedListNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_4_ContainerLinkedListNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst = (BEC_3_9_10_4_ContainerLinkedListNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst;
}
}
