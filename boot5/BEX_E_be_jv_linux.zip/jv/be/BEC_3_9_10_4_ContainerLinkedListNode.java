package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_4_ContainerLinkedListNode extends BEC_2_6_6_SystemObject {
public BEC_3_9_10_4_ContainerLinkedListNode() { }
private static byte[] becc_BEC_3_9_10_4_ContainerLinkedListNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_4_ContainerLinkedListNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_4_ContainerLinkedListNode bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst;

public static BET_3_9_10_4_ContainerLinkedListNode bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_prior;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_next;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_9_10_ContainerLinkedList bevp_mylist;
public BEC_3_9_10_4_ContainerLinkedListNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) throws Throwable {
bevp_held = beva__held;
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_insertBefore_1(BEC_2_6_6_SystemObject beva_toIns) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_toIns.bemd_1(384005520, null);
beva_toIns.bemd_1(-1910312720, this);
beva_toIns.bemd_1(1412027697, bevp_mylist);
bevl_p = bevp_prior;
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) beva_toIns;
if (bevl_p == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 57*/ {
bevp_mylist.bem_firstNodeSet_1(beva_toIns);
} /* Line: 59*/
 else /* Line: 60*/ {
bevl_p.bem_nextSet_1(beva_toIns);
beva_toIns.bemd_1(384005520, bevl_p);
} /* Line: 62*/
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_delete_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
bevl_p = bevp_prior;
bevl_n = bevp_next;
bevp_next = null;
bevp_prior = null;
if (bevl_p == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 71*/ {
bevp_mylist.bem_firstNodeSet_1(bevl_n);
if (bevl_n == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 74*/ {
bevl_n.bem_priorSet_1(null);
} /* Line: 75*/
 else /* Line: 76*/ {
bevp_mylist.bem_lastNodeSet_1(bevl_n);
} /* Line: 78*/
} /* Line: 74*/
 else /* Line: 71*/ {
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 80*/ {
bevl_p.bem_nextSet_1(bevl_n);
bevp_mylist.bem_lastNodeSet_1(bevl_p);
} /* Line: 83*/
 else /* Line: 84*/ {
bevl_p.bem_nextSet_1(bevl_n);
bevl_n.bem_priorSet_1(bevl_p);
} /* Line: 87*/
} /* Line: 71*/
bevp_mylist = null;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_priorGet_0() throws Throwable {
return bevp_prior;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_priorGetDirect_0() throws Throwable {
return bevp_prior;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_priorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_priorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_nextGet_0() throws Throwable {
return bevp_next;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_nextGetDirect_0() throws Throwable {
return bevp_next;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_nextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_next = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_nextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_next = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_heldGetDirect_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_mylistGet_0() throws Throwable {
return bevp_mylist;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_mylistGetDirect_0() throws Throwable {
return bevp_mylist;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_mylistSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mylist = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_10_4_ContainerLinkedListNode bem_mylistSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mylist = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {44, 45, 52, 53, 54, 55, 56, 57, 57, 59, 61, 62, 67, 68, 69, 70, 71, 71, 73, 74, 74, 75, 78, 80, 80, 82, 83, 86, 87, 89, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 23, 24, 25, 26, 27, 28, 33, 34, 37, 38, 48, 49, 50, 51, 52, 57, 58, 59, 64, 65, 68, 72, 77, 78, 79, 82, 83, 86, 90, 93, 96, 100, 104, 107, 110, 114, 118, 121, 124, 128, 132, 135, 138, 142};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 44 16
assign 1 45 17
priorSet 1 52 23
nextSet 1 53 24
mylistSet 1 54 25
assign 1 55 26
assign 1 56 27
assign 1 57 28
undef 1 57 33
firstNodeSet 1 59 34
nextSet 1 61 37
priorSet 1 62 38
assign 1 67 48
assign 1 68 49
assign 1 69 50
assign 1 70 51
assign 1 71 52
undef 1 71 57
firstNodeSet 1 73 58
assign 1 74 59
def 1 74 64
priorSet 1 75 65
lastNodeSet 1 78 68
assign 1 80 72
undef 1 80 77
nextSet 1 82 78
lastNodeSet 1 83 79
nextSet 1 86 82
priorSet 1 87 83
assign 1 89 86
return 1 0 90
return 1 0 93
assign 1 0 96
assign 1 0 100
return 1 0 104
return 1 0 107
assign 1 0 110
assign 1 0 114
return 1 0 118
return 1 0 121
assign 1 0 124
assign 1 0 128
return 1 0 132
return 1 0 135
assign 1 0 138
assign 1 0 142
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1721836166: return bem_mylistGetDirect_0();
case 1451773420: return bem_nextGet_0();
case 989732871: return bem_new_0();
case -281318932: return bem_delete_0();
case 1648346602: return bem_tagGet_0();
case -615663451: return bem_heldGetDirect_0();
case -1136648067: return bem_sourceFileNameGet_0();
case -1786334802: return bem_classNameGet_0();
case 1773293529: return bem_hashGet_0();
case 1368563841: return bem_mylistGet_0();
case -712690498: return bem_priorGet_0();
case 830521427: return bem_nextGetDirect_0();
case -777055641: return bem_copy_0();
case 63298884: return bem_priorGetDirect_0();
case 889719110: return bem_print_0();
case 2140998184: return bem_fieldNamesGet_0();
case 1812616799: return bem_create_0();
case -1793556608: return bem_heldGet_0();
case 1073013382: return bem_iteratorGet_0();
case -362215698: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -463430599: return bem_heldSetDirect_1(bevd_0);
case -930132980: return bem_def_1(bevd_0);
case -1875172918: return bem_sameObject_1(bevd_0);
case 754161535: return bem_equals_1(bevd_0);
case 319814146: return bem_sameClass_1(bevd_0);
case 137331971: return bem_undef_1(bevd_0);
case -583708652: return bem_otherType_1(bevd_0);
case -1900045484: return bem_insertBefore_1(bevd_0);
case 384005520: return bem_priorSet_1(bevd_0);
case -1651590674: return bem_heldSet_1(bevd_0);
case -1764717463: return bem_notEquals_1(bevd_0);
case 1295257783: return bem_otherClass_1(bevd_0);
case -1423333975: return bem_priorSetDirect_1(bevd_0);
case 980301665: return bem_sameType_1(bevd_0);
case -1813950117: return bem_mylistSetDirect_1(bevd_0);
case 658374216: return bem_nextSetDirect_1(bevd_0);
case -1910312720: return bem_nextSet_1(bevd_0);
case 1412027697: return bem_mylistSet_1(bevd_0);
case 1978132891: return bem_copyTo_1(bevd_0);
case -42885212: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1681451114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450498968: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2056223912: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 831817632: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1805853509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1679839886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_4_ContainerLinkedListNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_4_ContainerLinkedListNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_4_ContainerLinkedListNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst = (BEC_3_9_10_4_ContainerLinkedListNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_type;
}
}
