package be;
public class BET_2_9_12_ContainerBoundedQueue extends BETS_Object {
public BET_2_9_12_ContainerBoundedQueue() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "addValue_1", "enqueue_1", "dequeue_0", "isEmptyGet_0", "get_0", "put_1", "topGet_0", "topSet_1", "bottomGet_0", "bottomSet_1", "endGet_0", "endSet_1", "lengthGet_0", "lengthSet_1", "maxGet_0", "maxSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "top", "bottom", "end", "length", "max" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_9_12_ContainerBoundedQueue();
}
}
