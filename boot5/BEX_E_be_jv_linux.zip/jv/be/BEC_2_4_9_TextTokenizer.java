package be;
/* IO:File: source/base/Tokenize.be */
public final class BEC_2_4_9_TextTokenizer extends BEC_2_6_6_SystemObject {
public BEC_2_4_9_TextTokenizer() { }
private static byte[] becc_BEC_2_4_9_TextTokenizer_clname = {0x54,0x65,0x78,0x74,0x3A,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_4_9_TextTokenizer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_2 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_3 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_inst;

public static BET_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_type;

public BEC_2_9_3_ContainerMap bevp_tmap;
public BEC_2_5_4_LogicBool bevp_includeTokens;
public BEC_2_4_9_TextTokenizer bem_new_1(BEC_2_4_6_TextString beva_delims) throws Throwable {
bevp_includeTokens = be.BECS_Runtime.boolFalse;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_new_2(BEC_2_4_6_TextString beva_delims, BEC_2_5_4_LogicBool beva__includeTokens) throws Throwable {
bevp_includeTokens = beva__includeTokens;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokensStringSet_1(BEC_2_4_6_TextString beva_delims) throws Throwable {
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_tmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = beva_delims.bem_stringIteratorGet_0();
while (true)
 /* Line: 23 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevl_chi = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_chi.bem_toString_0();
bevp_tmap.bem_put_2(bevl_chi, bevt_2_tmpany_phold);
} /* Line: 24 */
 else  /* Line: 23 */ {
break;
} /* Line: 23 */
} /* Line: 23 */
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_addToken_1(BEC_2_4_6_TextString beva__delim) throws Throwable {
BEC_2_4_6_TextString bevl_delim = null;
bevl_delim = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_delim.bem_addValue_1(beva__delim);
bevp_tmap.bem_put_2(bevl_delim, beva__delim);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_tmpany_phold = bem_tokenizeIterator_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_2(BEC_2_6_6_SystemObject beva_str, BEC_2_6_6_SystemObject beva_tokenAcceptor) throws Throwable {
BEC_2_4_9_TextTokenizer bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_tmpany_phold = bem_tokenizeIterator_2(bevt_1_tmpany_phold, beva_tokenAcceptor);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokenizeIterator_2(BEC_2_6_6_SystemObject beva_i, BEC_2_6_6_SystemObject beva_acceptor) throws Throwable {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 45 */ {
bevt_0_tmpany_phold = beva_i.bemd_0(-1648763323);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 45 */ {
beva_i.bemd_1(88808523, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_3_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_0;
if (bevt_3_tmpany_phold.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_5_tmpany_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(-335456359, bevt_5_tmpany_phold);
} /* Line: 50 */
if (bevp_includeTokens.bevi_bool) /* Line: 52 */ {
beva_acceptor.bemd_1(-335456359, bevl_cc);
} /* Line: 53 */
} /* Line: 52 */
 else  /* Line: 55 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 56 */
} /* Line: 48 */
 else  /* Line: 45 */ {
break;
} /* Line: 45 */
} /* Line: 45 */
bevt_7_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_1;
if (bevt_7_tmpany_phold.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_9_tmpany_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(-335456359, bevt_9_tmpany_phold);
} /* Line: 60 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_1(BEC_2_6_6_SystemObject beva_i) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 68 */ {
bevt_0_tmpany_phold = beva_i.bemd_0(-1648763323);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 68 */ {
beva_i.bemd_1(88808523, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 71 */ {
bevt_3_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_2;
if (bevt_3_tmpany_phold.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_5_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 73 */
if (bevp_includeTokens.bevi_bool) /* Line: 75 */ {
bevl_splits.bem_addValue_1(bevl_cc);
} /* Line: 76 */
} /* Line: 75 */
 else  /* Line: 78 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 79 */
} /* Line: 71 */
 else  /* Line: 68 */ {
break;
} /* Line: 68 */
} /* Line: 68 */
bevt_7_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_3;
if (bevt_7_tmpany_phold.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_9_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_9_tmpany_phold);
} /* Line: 83 */
return bevl_splits;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGet_0() throws Throwable {
return bevp_tmap;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_tmapGetDirect_0() throws Throwable {
return bevp_tmap;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_tmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGet_0() throws Throwable {
return bevp_includeTokens;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_includeTokensGetDirect_0() throws Throwable {
return bevp_includeTokens;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_includeTokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_includeTokensSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {12, 13, 17, 18, 22, 23, 0, 23, 23, 24, 24, 29, 30, 31, 35, 35, 35, 39, 39, 39, 43, 44, 45, 46, 47, 48, 48, 49, 49, 49, 49, 50, 50, 53, 56, 59, 59, 59, 59, 60, 60, 65, 66, 67, 68, 69, 70, 71, 71, 72, 72, 72, 72, 73, 73, 76, 79, 82, 82, 82, 82, 83, 83, 85, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 23, 24, 32, 33, 33, 36, 38, 39, 40, 50, 51, 52, 58, 59, 60, 65, 66, 67, 83, 84, 87, 89, 90, 91, 96, 97, 98, 99, 104, 105, 106, 109, 113, 120, 121, 122, 127, 128, 129, 148, 149, 150, 153, 155, 156, 157, 162, 163, 164, 165, 170, 171, 172, 175, 179, 186, 187, 188, 193, 194, 195, 197, 200, 203, 206, 210, 214, 217, 220, 224};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 12 18
new 0 12 18
tokensStringSet 1 13 19
assign 1 17 23
tokensStringSet 1 18 24
assign 1 22 32
new 0 22 32
assign 1 23 33
stringIteratorGet 0 0 33
assign 1 23 36
hasNextGet 0 23 36
assign 1 23 38
nextGet 0 23 38
assign 1 24 39
toString 0 24 39
put 2 24 40
assign 1 29 50
new 0 29 50
addValue 1 30 51
put 2 31 52
assign 1 35 58
new 1 35 58
assign 1 35 59
tokenizeIterator 1 35 59
return 1 35 60
assign 1 39 65
new 1 39 65
assign 1 39 66
tokenizeIterator 2 39 66
return 1 39 67
assign 1 43 83
new 0 43 83
assign 1 44 84
new 0 44 84
assign 1 45 87
hasNextGet 0 45 87
next 1 46 89
assign 1 47 90
get 1 47 90
assign 1 48 91
def 1 48 96
assign 1 49 97
sizeGet 0 49 97
assign 1 49 98
new 0 49 98
assign 1 49 99
greater 1 49 104
assign 1 50 105
extractString 0 50 105
acceptToken 1 50 106
acceptToken 1 53 109
addValue 1 56 113
assign 1 59 120
sizeGet 0 59 120
assign 1 59 121
new 0 59 121
assign 1 59 122
greater 1 59 127
assign 1 60 128
extractString 0 60 128
acceptToken 1 60 129
assign 1 65 148
new 0 65 148
assign 1 66 149
new 0 66 149
assign 1 67 150
new 0 67 150
assign 1 68 153
hasNextGet 0 68 153
next 1 69 155
assign 1 70 156
get 1 70 156
assign 1 71 157
def 1 71 162
assign 1 72 163
sizeGet 0 72 163
assign 1 72 164
new 0 72 164
assign 1 72 165
greater 1 72 170
assign 1 73 171
extractString 0 73 171
addValue 1 73 172
addValue 1 76 175
addValue 1 79 179
assign 1 82 186
sizeGet 0 82 186
assign 1 82 187
new 0 82 187
assign 1 82 188
greater 1 82 193
assign 1 83 194
extractString 0 83 194
addValue 1 83 195
return 1 85 197
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
return 1 0 214
return 1 0 217
assign 1 0 220
assign 1 0 224
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1995804558: return bem_toString_0();
case -858518329: return bem_many_0();
case -1890761825: return bem_hashGet_0();
case 1592801927: return bem_serializeContents_0();
case -1845402369: return bem_create_0();
case 944745844: return bem_iteratorGet_0();
case 1130914409: return bem_includeTokensGet_0();
case -703952395: return bem_toAny_0();
case 1835904283: return bem_fieldIteratorGet_0();
case -513985458: return bem_once_0();
case 745980876: return bem_serializeToString_0();
case 1983305916: return bem_tmapGet_0();
case 1562045422: return bem_print_0();
case -177563030: return bem_tmapGetDirect_0();
case -1155411626: return bem_classNameGet_0();
case -1247813666: return bem_tagGet_0();
case 841207683: return bem_new_0();
case -225078823: return bem_serializationIteratorGet_0();
case -1154985755: return bem_echo_0();
case -967525204: return bem_fieldNamesGet_0();
case 285074277: return bem_deserializeClassNameGet_0();
case 232809271: return bem_copy_0();
case 863596927: return bem_sourceFileNameGet_0();
case -2042871639: return bem_includeTokensGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -592008712: return bem_addToken_1((BEC_2_4_6_TextString) bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1496002746: return bem_includeTokensSetDirect_1(bevd_0);
case 1021365280: return bem_tmapSet_1(bevd_0);
case -2061296688: return bem_tmapSetDirect_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 40598074: return bem_tokenizeIterator_1(bevd_0);
case 1200297939: return bem_undef_1(bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
case 1085049356: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 195154384: return bem_tokenize_1(bevd_0);
case 12031225: return bem_def_1(bevd_0);
case -1815546435: return bem_copyTo_1(bevd_0);
case -1674960887: return bem_tokensStringSet_1((BEC_2_4_6_TextString) bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
case 1401429051: return bem_includeTokensSet_1(bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2072540485: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -890286943: return bem_tokenize_2(bevd_0, bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -514096525: return bem_tokenizeIterator_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_4_9_TextTokenizer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_9_TextTokenizer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_9_TextTokenizer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst = (BEC_2_4_9_TextTokenizer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_type;
}
}
