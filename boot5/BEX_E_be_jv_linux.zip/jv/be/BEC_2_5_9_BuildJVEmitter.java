package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_6, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_7, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_8, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_9, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_10, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_12, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_13, 14));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_14, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_27, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_28, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 9));
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1435066194);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-249503778);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 46 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 59 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 59 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
return bevt_3_tmpany_phold;
} /* Line: 60 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 66 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 66 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
return bevt_3_tmpany_phold;
} /* Line: 67 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-40755554);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 37, 37, 37, 37, 37, 42, 43, 44, 44, 45, 45, 46, 46, 48, 48, 48, 49, 55, 55, 55, 55, 55, 55, 59, 59, 59, 0, 0, 0, 60, 60, 62, 62, 66, 66, 66, 0, 0, 0, 67, 67, 69, 69, 73, 73, 77, 77, 77, 77, 77, 78, 78, 78, 78, 78, 78, 79, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 81, 85, 85, 85, 89, 89, 89, 89, 89, 89, 89, 93, 93, 97, 97, 101, 101, 101, 101};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {54, 55, 56, 57, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 105, 106, 107, 108, 109, 119, 120, 121, 122, 124, 125, 126, 127, 129, 130, 131, 132, 141, 142, 143, 144, 145, 146, 154, 159, 160, 162, 165, 169, 172, 173, 175, 176, 184, 189, 190, 192, 195, 199, 202, 203, 205, 206, 210, 211, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 260, 261, 262, 271, 272, 273, 274, 275, 276, 277, 281, 282, 286, 287, 293, 294, 295, 296};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 54
new 0 17 54
assign 1 18 55
new 0 18 55
assign 1 19 56
new 0 19 56
new 1 23 57
assign 1 27 78
new 0 27 78
assign 1 27 79
toString 0 27 79
assign 1 27 80
add 1 27 80
incrementValue 0 28 81
assign 1 29 82
new 0 29 82
assign 1 29 83
addValue 1 29 83
assign 1 29 84
addValue 1 29 84
assign 1 29 85
new 0 29 85
assign 1 29 86
addValue 1 29 86
addValue 1 29 87
assign 1 31 88
containedGet 0 31 88
assign 1 31 89
firstGet 0 31 89
assign 1 31 90
containedGet 0 31 90
assign 1 31 91
firstGet 0 31 91
assign 1 31 92
new 0 31 92
assign 1 31 93
add 1 31 93
assign 1 31 94
new 0 31 94
assign 1 31 95
add 1 31 95
assign 1 31 96
finalAssign 4 31 96
addValue 1 31 97
assign 1 37 105
new 0 37 105
assign 1 37 106
add 1 37 106
assign 1 37 107
new 0 37 107
assign 1 37 108
add 1 37 108
return 1 37 109
getInt 2 42 119
assign 1 43 120
toHexString 1 43 120
assign 1 44 121
new 0 44 121
assign 1 44 122
begins 1 44 122
assign 1 45 124
new 0 45 124
assign 1 45 125
substring 1 45 125
assign 1 46 126
new 0 46 126
addValue 1 46 127
assign 1 48 129
new 0 48 129
assign 1 48 130
once 0 48 130
addValue 1 48 131
addValue 1 49 132
assign 1 55 141
new 0 55 141
assign 1 55 142
add 1 55 142
assign 1 55 143
new 0 55 143
assign 1 55 144
add 1 55 144
assign 1 55 145
add 1 55 145
return 1 55 146
assign 1 59 154
def 1 59 159
assign 1 59 160
isFinalGet 0 59 160
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 60 172
new 0 60 172
return 1 60 173
assign 1 62 175
new 0 62 175
return 1 62 176
assign 1 66 184
def 1 66 189
assign 1 66 190
isFinalGet 0 66 190
assign 1 0 192
assign 1 0 195
assign 1 0 199
assign 1 67 202
new 0 67 202
return 1 67 203
assign 1 69 205
new 0 69 205
return 1 69 206
assign 1 73 210
new 0 73 210
return 1 73 211
assign 1 77 233
new 0 77 233
assign 1 77 234
add 1 77 234
assign 1 77 235
new 0 77 235
assign 1 77 236
add 1 77 236
assign 1 77 237
add 1 77 237
assign 1 78 238
new 0 78 238
assign 1 78 239
addValue 1 78 239
assign 1 78 240
addValue 1 78 240
assign 1 78 241
new 0 78 241
assign 1 78 242
addValue 1 78 242
addValue 1 78 243
assign 1 79 244
new 0 79 244
assign 1 79 245
addValue 1 79 245
addValue 1 79 246
assign 1 80 247
new 0 80 247
assign 1 80 248
addValue 1 80 248
assign 1 80 249
outputPlatformGet 0 80 249
assign 1 80 250
nameGet 0 80 250
assign 1 80 251
addValue 1 80 251
assign 1 80 252
new 0 80 252
assign 1 80 253
addValue 1 80 253
addValue 1 80 254
return 1 81 255
assign 1 85 260
libNameGet 0 85 260
assign 1 85 261
beginNs 1 85 261
return 1 85 262
assign 1 89 271
new 0 89 271
assign 1 89 272
libNs 1 89 272
assign 1 89 273
add 1 89 273
assign 1 89 274
new 0 89 274
assign 1 89 275
add 1 89 275
assign 1 89 276
add 1 89 276
return 1 89 277
assign 1 93 281
getNameSpace 1 93 281
return 1 93 282
assign 1 97 286
new 0 97 286
return 1 97 287
assign 1 101 293
new 0 101 293
assign 1 101 294
once 0 101 294
assign 1 101 295
add 1 101 295
return 1 101 296
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1327462668: return bem_fullLibEmitNameGet_0();
case -1259120400: return bem_libEmitNameGet_0();
case 639045658: return bem_mainStartGet_0();
case -1672259538: return bem_nlGet_0();
case 504584048: return bem_lastMethodsSizeGet_0();
case 89921707: return bem_echo_0();
case -795989187: return bem_nameToIdGet_0();
case -610207516: return bem_print_0();
case 484987452: return bem_nativeCSlotsGet_0();
case 1604876294: return bem_instanceNotEqualGet_0();
case 380917179: return bem_deserializeClassNameGet_0();
case -1565680531: return bem_scvpGet_0();
case -2035508001: return bem_classCallsGet_0();
case 645482674: return bem_baseSmtdDecGet_0();
case -664618949: return bem_mnodeGet_0();
case 1664066810: return bem_floatNpGet_0();
case -150681189: return bem_csynGet_0();
case 1222559837: return bem_toAny_0();
case 291147618: return bem_libEmitPathGet_0();
case -486730947: return bem_tagGet_0();
case -165315950: return bem_callNamesGet_0();
case 234332187: return bem_dynMethodsGet_0();
case 2089951871: return bem_onceCountGet_0();
case -1470548579: return bem_getClassOutput_0();
case -1997732490: return bem_serializeToString_0();
case 340632909: return bem_overrideMtdDecGet_0();
case -1864406869: return bem_smnlcsGet_0();
case -1710038659: return bem_msynGet_0();
case 92699923: return bem_classEndGet_0();
case -466730532: return bem_fileExtGet_0();
case 1245144026: return bem_returnTypeGet_0();
case -947915274: return bem_constGet_0();
case 1614682263: return bem_maxSpillArgsLenGet_0();
case -1785578246: return bem_instOfGet_0();
case 1520539941: return bem_mainOutsideNsGet_0();
case 1789586174: return bem_boolCcGet_0();
case 2065061843: return bem_ccMethodsGet_0();
case 1658362138: return bem_objectCcGet_0();
case 1636926494: return bem_intNpGet_0();
case -288603233: return bem_serializationIteratorGet_0();
case 192353495: return bem_toString_0();
case -1881036076: return bem_spropDecGet_0();
case -438931987: return bem_many_0();
case -145517521: return bem_iteratorGet_0();
case -1278099896: return bem_coanyiantReturnsGet_0();
case -32236453: return bem_idToNameGet_0();
case 960204183: return bem_propDecGet_0();
case 1071190062: return bem_initialDecGet_0();
case -970081462: return bem_objectNpGet_0();
case 1605056877: return bem_trueValueGet_0();
case 1749561132: return bem_lastMethodBodySizeGet_0();
case 1300269356: return bem_smnlecsGet_0();
case 762504326: return bem_falseValueGet_0();
case 1733022581: return bem_create_0();
case 1335950016: return bem_ntypesGet_0();
case 225577791: return bem_endNs_0();
case 1870927900: return bem_lastMethodBodyLinesGet_0();
case 2130394362: return bem_superCallsGet_0();
case 687553165: return bem_inFilePathedGet_0();
case -706394436: return bem_classNameGet_0();
case 1711023576: return bem_randGet_0();
case 2070804201: return bem_invpGet_0();
case 1280186650: return bem_saveSyns_0();
case -311092750: return bem_doEmit_0();
case 1319222899: return bem_ccCacheGet_0();
case -2096226183: return bem_methodCatchGet_0();
case -2002314890: return bem_serializeContents_0();
case -2072061563: return bem_qGet_0();
case 991850509: return bem_hashGet_0();
case 150815360: return bem_new_0();
case 479184205: return bem_classEmitsGet_0();
case 903380622: return bem_copy_0();
case 1440275612: return bem_lineCountGet_0();
case -767530431: return bem_mainEndGet_0();
case 271291303: return bem_buildGet_0();
case 1217040782: return bem_boolTypeGet_0();
case 2007419844: return bem_sourceFileNameGet_0();
case -673069023: return bem_useDynMethodsGet_0();
case 1586197594: return bem_buildCreate_0();
case -1974430825: return bem_transGet_0();
case 2122261574: return bem_methodsGet_0();
case -1586047191: return bem_instanceEqualGet_0();
case 1984902264: return bem_getLibOutput_0();
case -784073193: return bem_lastMethodsLinesGet_0();
case -110291763: return bem_buildInitial_0();
case 1823731495: return bem_fieldIteratorGet_0();
case 916989175: return bem_baseMtdDecGet_0();
case -1466255253: return bem_nullValueGet_0();
case 518156557: return bem_emitLib_0();
case 887242723: return bem_maxDynArgsGet_0();
case 208951447: return bem_superNameGet_0();
case -1126533349: return bem_runtimeInitGet_0();
case 1249238814: return bem_stringNpGet_0();
case -1447881888: return bem_cnodeGet_0();
case -501582308: return bem_onceDecsGet_0();
case -1654733608: return bem_synEmitPathGet_0();
case 1023674705: return bem_mainInClassGet_0();
case -1858992592: return bem_buildClassInfo_0();
case -145418244: return bem_methodCallsGet_0();
case 1071338406: return bem_once_0();
case 1691913434: return bem_beginNs_0();
case -313507982: return bem_classConfGet_0();
case -2106422900: return bem_boolNpGet_0();
case 448278742: return bem_emitLangGet_0();
case -358129382: return bem_parentConfGet_0();
case 1803756097: return bem_classesInDepthOrderGet_0();
case -1698641251: return bem_preClassGet_0();
case 508773904: return bem_exceptDecGet_0();
case -310641901: return bem_lastCallGet_0();
case -1536430062: return bem_propertyDecsGet_0();
case 1625981955: return bem_methodBodyGet_0();
case 958859319: return bem_afterCast_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1163467581: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -509687652: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1595747658: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1924850644: return bem_lineCountSet_1(bevd_0);
case 1234343289: return bem_def_1(bevd_0);
case 880602948: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1868741780: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -221944484: return bem_buildSet_1(bevd_0);
case -1083026774: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -13067159: return bem_lastCallSet_1(bevd_0);
case -1626191129: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 930515809: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 754254864: return bem_sameType_1(bevd_0);
case 1317197214: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -406202149: return bem_callNamesSet_1(bevd_0);
case -1951248711: return bem_defined_1(bevd_0);
case 1355170315: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1290028668: return bem_nativeCSlotsSet_1(bevd_0);
case -494705269: return bem_invpSet_1(bevd_0);
case 599775562: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1328569386: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 264973749: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1939337819: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -226295549: return bem_sameClass_1(bevd_0);
case 510417069: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -2038181641: return bem_copyTo_1(bevd_0);
case -1830543505: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 565197247: return bem_synEmitPathSet_1(bevd_0);
case 1855913247: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1842283409: return bem_intNpSet_1(bevd_0);
case 1656541985: return bem_dynMethodsSet_1(bevd_0);
case -1374467194: return bem_mnodeSet_1(bevd_0);
case -1492115222: return bem_maxDynArgsSet_1(bevd_0);
case 1816011880: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1886873191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -907803894: return bem_otherType_1(bevd_0);
case -1587661946: return bem_sameObject_1(bevd_0);
case -1794454226: return bem_undef_1(bevd_0);
case -1682126076: return bem_transSet_1(bevd_0);
case -177732522: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -842169840: return bem_preClassSet_1(bevd_0);
case 403449013: return bem_stringNpSet_1(bevd_0);
case -790234324: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 867400467: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1623788258: return bem_nullValueSet_1(bevd_0);
case -600404289: return bem_methodCallsSet_1(bevd_0);
case -840183948: return bem_instOfSet_1(bevd_0);
case -1833791374: return bem_objectCcSet_1(bevd_0);
case 1596779610: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1675591126: return bem_libEmitPathSet_1(bevd_0);
case -1738471801: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -2129435301: return bem_classesInDepthOrderSet_1(bevd_0);
case -174280441: return bem_otherClass_1(bevd_0);
case 1470257172: return bem_boolCcSet_1(bevd_0);
case 1890271306: return bem_onceDecsSet_1(bevd_0);
case 270039785: return bem_lastMethodBodySizeSet_1(bevd_0);
case -217327154: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1104773767: return bem_onceCountSet_1(bevd_0);
case -1118520378: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 64312473: return bem_superCallsSet_1(bevd_0);
case -1930766021: return bem_methodBodySet_1(bevd_0);
case -1151707645: return bem_classConfSet_1(bevd_0);
case 439026951: return bem_fullLibEmitNameSet_1(bevd_0);
case 187357147: return bem_trueValueSet_1(bevd_0);
case -1595295855: return bem_parentConfSet_1(bevd_0);
case 288589869: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1812425724: return bem_notEquals_1(bevd_0);
case -574208127: return bem_ccMethodsSet_1(bevd_0);
case -172593730: return bem_nlSet_1(bevd_0);
case -1047157193: return bem_fileExtSet_1(bevd_0);
case 393340485: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 194552824: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1311100946: return bem_objectNpSet_1(bevd_0);
case -681133339: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 769740360: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1532594481: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -859042917: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 571875326: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -128240801: return bem_smnlcsSet_1(bevd_0);
case 592126697: return bem_randSet_1(bevd_0);
case -464099566: return bem_begin_1(bevd_0);
case -583354586: return bem_scvpSet_1(bevd_0);
case -1597843358: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1568093965: return bem_idToNameSet_1(bevd_0);
case 1575094400: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -2075578205: return bem_classEmitsSet_1(bevd_0);
case 754556361: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2116311133: return bem_lastMethodsSizeSet_1(bevd_0);
case 1580118479: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1055744033: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -485545442: return bem_emitLangSet_1(bevd_0);
case -107007777: return bem_nameToIdSet_1(bevd_0);
case 484478915: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 914568343: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -383003180: return bem_cnodeSet_1(bevd_0);
case -547709779: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1738608210: return bem_methodCatchSet_1(bevd_0);
case 1691792693: return bem_exceptDecSet_1(bevd_0);
case -1632818389: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -932625885: return bem_ntypesSet_1(bevd_0);
case -1695646346: return bem_inFilePathedSet_1(bevd_0);
case 993004177: return bem_instanceNotEqualSet_1(bevd_0);
case 2141895276: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1135927600: return bem_returnTypeSet_1(bevd_0);
case 472616034: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -270320161: return bem_end_1(bevd_0);
case -2111080973: return bem_smnlecsSet_1(bevd_0);
case 698316509: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1702402169: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1828061188: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 51156458: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1449699433: return bem_floatNpSet_1(bevd_0);
case 1375718520: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1635360960: return bem_boolNpSet_1(bevd_0);
case -926129314: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1485158908: return bem_constSet_1(bevd_0);
case -567021107: return bem_classCallsSet_1(bevd_0);
case -2049153406: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -976267608: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 213539814: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 2072065: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 380694491: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 568764092: return bem_equals_1(bevd_0);
case -1256236580: return bem_falseValueSet_1(bevd_0);
case -1928064485: return bem_csynSet_1(bevd_0);
case 1661170617: return bem_instanceEqualSet_1(bevd_0);
case 1927966968: return bem_msynSet_1(bevd_0);
case 175734810: return bem_ccCacheSet_1(bevd_0);
case -67653611: return bem_qSet_1(bevd_0);
case -2087149042: return bem_undefined_1(bevd_0);
case 1751247115: return bem_methodsSet_1(bevd_0);
case 498696074: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -2145968304: return bem_lastMethodsLinesSet_1(bevd_0);
case -1371067321: return bem_propertyDecsSet_1(bevd_0);
case 1536902815: return bem_libEmitNameSet_1(bevd_0);
case -228018998: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1523750230: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1346377346: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1540077789: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1538374916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2118466960: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1812225636: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 2037713741: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1158934771: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -801018094: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 608937217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -862992684: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -121068716: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1911273797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2066895296: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -947936468: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 532765284: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1789964230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1317793155: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1779308294: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1228599587: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -154733971: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 638950289: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1346824922: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 13925121: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -82675633: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1412309072: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
}
