package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(909332085);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(1681879581);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(1696433337);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(1681879581);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(1696433337);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_ta_ph = bevl_bet.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_ta_ph);
bevl_tout.bemd_1(-554380480, bevl_bet);
bevl_tout.bemd_0(1344525652);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1297616941);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(762553302);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_21));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_0_ta_ph = bevl_bc.bem_begins_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
beva_sdec.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 85*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
beva_sdec.bem_addValue_1(bevt_4_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 98*/
 else /* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 98*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 99*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 105*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 105*/
 else /* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 105*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 106*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_exceptDec);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_ms = bevt_0_ta_ph.bem_add_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_30));
bevt_6_ta_ph = bevl_ms.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_9_ta_ph = bevl_ms.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(749770559);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_36));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 82, 83, 83, 84, 84, 85, 85, 87, 87, 88, 94, 94, 94, 94, 94, 94, 98, 98, 98, 0, 0, 0, 99, 99, 101, 101, 105, 105, 105, 0, 0, 0, 106, 106, 108, 108, 112, 112, 116, 116, 116, 116, 116, 117, 117, 117, 117, 117, 117, 118, 118, 118, 119, 119, 119, 119, 119, 119, 119, 119, 120, 124, 124, 124, 128, 128, 128, 128, 128, 128, 128, 132, 132, 136, 136, 140, 140, 140};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {51, 52, 53, 54, 112, 113, 114, 115, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 148, 151, 153, 155, 158, 159, 161, 162, 163, 164, 170, 171, 172, 173, 174, 175, 176, 177, 178, 178, 181, 183, 185, 188, 189, 191, 192, 193, 194, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 267, 268, 269, 270, 272, 273, 274, 275, 277, 278, 279, 288, 289, 290, 291, 292, 293, 301, 306, 307, 309, 312, 316, 319, 320, 322, 323, 331, 336, 337, 339, 342, 346, 349, 350, 352, 353, 357, 358, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 407, 408, 409, 418, 419, 420, 421, 422, 423, 424, 428, 429, 433, 434, 439, 440, 441};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 51
new 0 16 51
assign 1 17 52
new 0 17 52
assign 1 18 53
new 0 18 53
new 1 22 54
assign 1 26 112
classDirGet 0 26 112
assign 1 26 113
fileGet 0 26 113
assign 1 26 114
existsGet 0 26 114
assign 1 26 115
not 0 26 120
assign 1 27 121
classDirGet 0 27 121
assign 1 27 122
fileGet 0 27 122
makeDirs 0 27 123
assign 1 29 125
typePathGet 0 29 125
assign 1 29 126
fileGet 0 29 126
assign 1 29 127
writerGet 0 29 127
assign 1 29 128
open 0 29 128
assign 1 30 129
new 0 30 129
assign 1 31 130
new 0 31 130
addValue 1 31 131
assign 1 32 132
new 0 32 132
assign 1 32 133
addValue 1 32 133
assign 1 32 134
typeEmitNameGet 0 32 134
assign 1 32 135
addValue 1 32 135
assign 1 32 136
new 0 32 136
addValue 1 32 137
assign 1 33 138
new 0 33 138
assign 1 33 139
addValue 1 33 139
assign 1 33 140
typeEmitNameGet 0 33 140
assign 1 33 141
addValue 1 33 141
assign 1 33 142
new 0 33 142
addValue 1 33 143
assign 1 35 144
new 0 35 144
addValue 1 35 145
assign 1 36 146
new 0 36 146
assign 1 37 147
mtdListGet 0 37 147
assign 1 37 148
iteratorGet 0 0 148
assign 1 37 151
hasNextGet 0 37 151
assign 1 37 153
nextGet 0 37 153
assign 1 39 155
new 0 39 155
assign 1 41 158
new 0 41 158
addValue 1 41 159
assign 1 43 161
addValue 1 43 161
assign 1 43 162
nameGet 0 43 162
assign 1 43 163
addValue 1 43 163
addValue 1 43 164
assign 1 45 170
new 0 45 170
addValue 1 45 171
assign 1 46 172
new 0 46 172
addValue 1 46 173
assign 1 48 174
new 0 48 174
addValue 1 48 175
assign 1 49 176
new 0 49 176
assign 1 50 177
ptyListGet 0 50 177
assign 1 50 178
iteratorGet 0 0 178
assign 1 50 181
hasNextGet 0 50 181
assign 1 50 183
nextGet 0 50 183
assign 1 52 185
new 0 52 185
assign 1 54 188
new 0 54 188
addValue 1 54 189
assign 1 56 191
addValue 1 56 191
assign 1 56 192
nameGet 0 56 192
assign 1 56 193
addValue 1 56 193
addValue 1 56 194
assign 1 58 200
new 0 58 200
addValue 1 58 201
assign 1 60 202
new 0 60 202
addValue 1 60 203
assign 1 62 204
new 0 62 204
addValue 1 62 205
assign 1 63 206
new 0 63 206
assign 1 63 207
addValue 1 63 207
assign 1 63 208
emitNameGet 0 63 208
assign 1 63 209
addValue 1 63 209
assign 1 63 210
new 0 63 210
addValue 1 63 211
assign 1 64 212
new 0 64 212
addValue 1 64 213
assign 1 65 214
new 0 65 214
addValue 1 65 215
write 1 66 216
close 0 67 217
assign 1 71 238
new 0 71 238
assign 1 71 239
toString 0 71 239
assign 1 71 240
add 1 71 240
incrementValue 0 72 241
assign 1 73 242
new 0 73 242
assign 1 73 243
addValue 1 73 243
assign 1 73 244
addValue 1 73 244
assign 1 73 245
new 0 73 245
assign 1 73 246
addValue 1 73 246
addValue 1 73 247
assign 1 75 248
containedGet 0 75 248
assign 1 75 249
firstGet 0 75 249
assign 1 75 250
containedGet 0 75 250
assign 1 75 251
firstGet 0 75 251
assign 1 75 252
new 0 75 252
assign 1 75 253
add 1 75 253
assign 1 75 254
new 0 75 254
assign 1 75 255
add 1 75 255
assign 1 75 256
finalAssign 4 75 256
addValue 1 75 257
getInt 2 81 267
assign 1 82 268
toHexString 1 82 268
assign 1 83 269
new 0 83 269
assign 1 83 270
begins 1 83 270
assign 1 84 272
new 0 84 272
assign 1 84 273
substring 1 84 273
assign 1 85 274
new 0 85 274
addValue 1 85 275
assign 1 87 277
new 0 87 277
addValue 1 87 278
addValue 1 88 279
assign 1 94 288
new 0 94 288
assign 1 94 289
add 1 94 289
assign 1 94 290
new 0 94 290
assign 1 94 291
add 1 94 291
assign 1 94 292
add 1 94 292
return 1 94 293
assign 1 98 301
def 1 98 306
assign 1 98 307
isFinalGet 0 98 307
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 99 319
new 0 99 319
return 1 99 320
assign 1 101 322
new 0 101 322
return 1 101 323
assign 1 105 331
def 1 105 336
assign 1 105 337
isFinalGet 0 105 337
assign 1 0 339
assign 1 0 342
assign 1 0 346
assign 1 106 349
new 0 106 349
return 1 106 350
assign 1 108 352
new 0 108 352
return 1 108 353
assign 1 112 357
new 0 112 357
return 1 112 358
assign 1 116 380
new 0 116 380
assign 1 116 381
add 1 116 381
assign 1 116 382
new 0 116 382
assign 1 116 383
add 1 116 383
assign 1 116 384
add 1 116 384
assign 1 117 385
new 0 117 385
assign 1 117 386
addValue 1 117 386
assign 1 117 387
addValue 1 117 387
assign 1 117 388
new 0 117 388
assign 1 117 389
addValue 1 117 389
addValue 1 117 390
assign 1 118 391
new 0 118 391
assign 1 118 392
addValue 1 118 392
addValue 1 118 393
assign 1 119 394
new 0 119 394
assign 1 119 395
addValue 1 119 395
assign 1 119 396
outputPlatformGet 0 119 396
assign 1 119 397
nameGet 0 119 397
assign 1 119 398
addValue 1 119 398
assign 1 119 399
new 0 119 399
assign 1 119 400
addValue 1 119 400
addValue 1 119 401
return 1 120 402
assign 1 124 407
libNameGet 0 124 407
assign 1 124 408
beginNs 1 124 408
return 1 124 409
assign 1 128 418
new 0 128 418
assign 1 128 419
libNs 1 128 419
assign 1 128 420
add 1 128 420
assign 1 128 421
new 0 128 421
assign 1 128 422
add 1 128 422
assign 1 128 423
add 1 128 423
return 1 128 424
assign 1 132 428
getNameSpace 1 132 428
return 1 132 429
assign 1 136 433
new 0 136 433
return 1 136 434
assign 1 140 439
new 0 140 439
assign 1 140 440
add 1 140 440
return 1 140 441
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2087154349: return bem_lineCountGet_0();
case -1403449723: return bem_libEmitPathGetDirect_0();
case 1003660340: return bem_instanceNotEqualGetDirect_0();
case 686364963: return bem_classCallsGetDirect_0();
case -1007733145: return bem_lastCallGet_0();
case 338637891: return bem_newDecGet_0();
case 1302786775: return bem_mnodeGetDirect_0();
case -931056988: return bem_methodBodyGetDirect_0();
case -573724382: return bem_msynGetDirect_0();
case 1467407448: return bem_classCallsGet_0();
case -247881267: return bem_inClassGetDirect_0();
case 1334640486: return bem_scvpGetDirect_0();
case 1991564976: return bem_mainOutsideNsGet_0();
case 1805440388: return bem_maxDynArgsGet_0();
case -1273723283: return bem_libEmitPathGet_0();
case -479629740: return bem_fileExtGet_0();
case 2006354938: return bem_libEmitNameGet_0();
case -2098457644: return bem_lastMethodsSizeGet_0();
case -17507460: return bem_maxDynArgsGetDirect_0();
case -1136519468: return bem_parentConfGet_0();
case 1904580323: return bem_nullValueGet_0();
case 538054662: return bem_trueValueGet_0();
case 2135939180: return bem_fullLibEmitNameGet_0();
case -17403046: return bem_nameToIdGet_0();
case -170521167: return bem_ccMethodsGet_0();
case 1396105842: return bem_invpGetDirect_0();
case 1241654449: return bem_superCallsGet_0();
case 1516065540: return bem_emitLangGet_0();
case 337536168: return bem_falseValueGet_0();
case -1943100664: return bem_runtimeInitGet_0();
case 398187407: return bem_sourceFileNameGet_0();
case -1069524953: return bem_ntypesGetDirect_0();
case 330426334: return bem_buildInitial_0();
case -733746955: return bem_propertyDecsGet_0();
case 1974406555: return bem_afterCast_0();
case -744799827: return bem_nullValueGetDirect_0();
case -253876868: return bem_classEndGet_0();
case -1492883302: return bem_gcMarksGet_0();
case -1499692384: return bem_gcMarksGetDirect_0();
case -2124354635: return bem_serializeToString_0();
case 1275791866: return bem_csynGetDirect_0();
case 807655445: return bem_print_0();
case -403112368: return bem_classConfGet_0();
case 179683686: return bem_endNs_0();
case 351189407: return bem_getClassOutput_0();
case 1632706461: return bem_mnodeGet_0();
case 1224606852: return bem_belslitsGetDirect_0();
case 1371397345: return bem_callNamesGetDirect_0();
case -1799651808: return bem_onceDecsGetDirect_0();
case 757259130: return bem_objectNpGet_0();
case 1176845505: return bem_randGetDirect_0();
case 48649281: return bem_cnodeGetDirect_0();
case 1006302603: return bem_beginNs_0();
case 1789330709: return bem_classConfGetDirect_0();
case 1685712810: return bem_lastMethodsLinesGetDirect_0();
case -1139319809: return bem_intNpGetDirect_0();
case -958997185: return bem_ntypesGet_0();
case 2066839134: return bem_iteratorGet_0();
case 2060144109: return bem_transGetDirect_0();
case 848700110: return bem_constGetDirect_0();
case 1547207303: return bem_nativeCSlotsGetDirect_0();
case -1883143670: return bem_msynGet_0();
case -677150073: return bem_toString_0();
case 1553544530: return bem_onceDecsGet_0();
case 1989744943: return bem_nativeCSlotsGet_0();
case -233466092: return bem_synEmitPathGet_0();
case 940745874: return bem_nlGet_0();
case -192032247: return bem_lineCountGetDirect_0();
case 753870723: return bem_loadIds_0();
case 387201814: return bem_trueValueGetDirect_0();
case 1835774971: return bem_libEmitNameGetDirect_0();
case -1815968589: return bem_superNameGet_0();
case -1322629178: return bem_boolTypeGet_0();
case 738358861: return bem_csynGet_0();
case -2100206868: return bem_fileExtGetDirect_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case -1645622072: return bem_lastMethodBodyLinesGetDirect_0();
case 1655167443: return bem_scvpGet_0();
case -1411010778: return bem_getLibOutput_0();
case 1919741834: return bem_inFilePathedGet_0();
case 1272850415: return bem_stringNpGet_0();
case 851544412: return bem_nlGetDirect_0();
case -2064448447: return bem_useDynMethodsGet_0();
case -225222698: return bem_create_0();
case 1900895099: return bem_classesInDepthOrderGet_0();
case 2144912452: return bem_objectCcGetDirect_0();
case -1968219189: return bem_buildCreate_0();
case 409380620: return bem_fieldIteratorGet_0();
case -1992009723: return bem_exceptDecGetDirect_0();
case 126387064: return bem_new_0();
case 1169473386: return bem_boolNpGet_0();
case 1104879329: return bem_returnTypeGetDirect_0();
case -1477188736: return bem_intNpGet_0();
case 99309404: return bem_writeBET_0();
case 1322306631: return bem_belslitsGet_0();
case 498101216: return bem_echo_0();
case 995804816: return bem_lastMethodBodyLinesGet_0();
case 466694146: return bem_methodBodyGet_0();
case 2104593718: return bem_lastCallGetDirect_0();
case -316306029: return bem_maxSpillArgsLenGetDirect_0();
case -21892242: return bem_mainEndGet_0();
case 63775818: return bem_ccCacheGet_0();
case -785931033: return bem_doEmit_0();
case -930137217: return bem_superCallsGetDirect_0();
case 580832955: return bem_instOfGet_0();
case -857834610: return bem_buildGet_0();
case 520989330: return bem_nameToIdPathGetDirect_0();
case 1009312227: return bem_falseValueGetDirect_0();
case -1153439244: return bem_mainInClassGet_0();
case 369771441: return bem_smnlecsGetDirect_0();
case 1252408017: return bem_dynMethodsGetDirect_0();
case -611008178: return bem_invpGet_0();
case 1958544513: return bem_spropDecGet_0();
case -325544348: return bem_callNamesGet_0();
case 155419445: return bem_classEmitsGetDirect_0();
case -1983864734: return bem_idToNamePathGetDirect_0();
case 1216586145: return bem_boolNpGetDirect_0();
case -1804368680: return bem_initialDecGet_0();
case 1143596317: return bem_instanceEqualGetDirect_0();
case 1299320890: return bem_propDecGet_0();
case -1534819050: return bem_preClassGet_0();
case 1479437747: return bem_returnTypeGet_0();
case -767800185: return bem_preClassOutput_0();
case -635707812: return bem_stringNpGetDirect_0();
case -807299077: return bem_lastMethodBodySizeGet_0();
case 966877923: return bem_smnlecsGet_0();
case 1472441979: return bem_lastMethodBodySizeGetDirect_0();
case 5994302: return bem_exceptDecGet_0();
case 40527273: return bem_inClassGet_0();
case -1749437314: return bem_tagGet_0();
case -655203991: return bem_methodsGetDirect_0();
case 238239955: return bem_dynMethodsGet_0();
case -1392864820: return bem_floatNpGetDirect_0();
case -1871452361: return bem_buildClassInfo_0();
case -985119914: return bem_constGet_0();
case 1192168884: return bem_classEmitsGet_0();
case 1602621592: return bem_qGet_0();
case -1157287574: return bem_covariantReturnsGet_0();
case -649807497: return bem_floatNpGet_0();
case -541578442: return bem_methodCallsGetDirect_0();
case -1929205832: return bem_boolCcGetDirect_0();
case 83304049: return bem_objectCcGet_0();
case 1375066346: return bem_objectNpGetDirect_0();
case -1396728636: return bem_maxSpillArgsLenGet_0();
case 1425035297: return bem_instanceNotEqualGet_0();
case 1220136762: return bem_methodCallsGet_0();
case -1718188704: return bem_hashGet_0();
case -533623047: return bem_methodCatchGet_0();
case 1027972795: return bem_baseMtdDecGet_0();
case 1342623754: return bem_copy_0();
case 899835984: return bem_methodsGet_0();
case 622511296: return bem_emitLib_0();
case -2000944880: return bem_smnlcsGet_0();
case -1932002478: return bem_cnodeGet_0();
case 247576523: return bem_classNameGet_0();
case 865062366: return bem_nameToIdGetDirect_0();
case -2083606801: return bem_parentConfGetDirect_0();
case -543330026: return bem_fieldNamesGet_0();
case 1192441529: return bem_nameToIdPathGet_0();
case -2017207524: return bem_inFilePathedGetDirect_0();
case 701186016: return bem_ccCacheGetDirect_0();
case -1135521084: return bem_baseSmtdDecGet_0();
case -1752889733: return bem_propertyDecsGetDirect_0();
case 2068281764: return bem_saveIds_0();
case 1430362491: return bem_transGet_0();
case 1797338639: return bem_fullLibEmitNameGetDirect_0();
case -156446267: return bem_synEmitPathGetDirect_0();
case -1859785548: return bem_idToNameGetDirect_0();
case -1108281800: return bem_instanceEqualGet_0();
case 1855845835: return bem_buildGetDirect_0();
case -799901555: return bem_idToNamePathGet_0();
case 2045226133: return bem_mainStartGet_0();
case -439737695: return bem_methodCatchGetDirect_0();
case 1335720039: return bem_saveSyns_0();
case -1695985307: return bem_qGetDirect_0();
case 371488943: return bem_preClassGetDirect_0();
case -2059446119: return bem_boolCcGet_0();
case -2082349873: return bem_emitLangGetDirect_0();
case 564397274: return bem_idToNameGet_0();
case -2048633995: return bem_typeDecGet_0();
case -2001220840: return bem_overrideMtdDecGet_0();
case -1794485421: return bem_serializeContents_0();
case 1424415170: return bem_randGet_0();
case -506514059: return bem_instOfGetDirect_0();
case 1904218847: return bem_smnlcsGetDirect_0();
case -695542815: return bem_lastMethodsLinesGet_0();
case 556565361: return bem_serializationIteratorGet_0();
case 355071341: return bem_ccMethodsGetDirect_0();
case 1571294361: return bem_classesInDepthOrderGetDirect_0();
case -755361166: return bem_lastMethodsSizeGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1248448893: return bem_libEmitNameSetDirect_1(bevd_0);
case 1560617261: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -2058882560: return bem_ccMethodsSetDirect_1(bevd_0);
case 1835532630: return bem_constSet_1(bevd_0);
case -450724192: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 221703024: return bem_propertyDecsSetDirect_1(bevd_0);
case -1752285710: return bem_returnTypeSetDirect_1(bevd_0);
case 1393493303: return bem_objectNpSetDirect_1(bevd_0);
case 5983379: return bem_preClassSet_1(bevd_0);
case 1907119025: return bem_emitLangSetDirect_1(bevd_0);
case -438527076: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1817826534: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1638642502: return bem_callNamesSetDirect_1(bevd_0);
case -255481174: return bem_smnlecsSet_1(bevd_0);
case -845459748: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case -185267593: return bem_preClassSetDirect_1(bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case -60581240: return bem_methodBodySetDirect_1(bevd_0);
case -693989476: return bem_classEmitsSet_1(bevd_0);
case -404194174: return bem_copyTo_1(bevd_0);
case -2059700365: return bem_msynSet_1(bevd_0);
case -1994284484: return bem_maxSpillArgsLenSet_1(bevd_0);
case 704982706: return bem_parentConfSetDirect_1(bevd_0);
case -936536965: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -841629309: return bem_nullValueSetDirect_1(bevd_0);
case 25555633: return bem_ccCacheSetDirect_1(bevd_0);
case 1457306320: return bem_maxDynArgsSet_1(bevd_0);
case 1238173939: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1813765414: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1705431441: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1814514120: return bem_exceptDecSetDirect_1(bevd_0);
case -860096944: return bem_end_1(bevd_0);
case 825826155: return bem_cnodeSetDirect_1(bevd_0);
case 627999947: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -772289305: return bem_randSetDirect_1(bevd_0);
case 1748412101: return bem_instanceEqualSetDirect_1(bevd_0);
case -183964138: return bem_nativeCSlotsSet_1(bevd_0);
case -1225022404: return bem_returnTypeSet_1(bevd_0);
case 1496500047: return bem_methodCatchSetDirect_1(bevd_0);
case 524339090: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1905566353: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1357738492: return bem_superCallsSetDirect_1(bevd_0);
case 1116863205: return bem_trueValueSetDirect_1(bevd_0);
case -1133958102: return bem_nlSetDirect_1(bevd_0);
case 2125647154: return bem_qSet_1(bevd_0);
case 2022741106: return bem_falseValueSet_1(bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -347806802: return bem_ntypesSet_1(bevd_0);
case 1171267456: return bem_invpSet_1(bevd_0);
case -170806381: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1565934185: return bem_boolCcSetDirect_1(bevd_0);
case 220618622: return bem_scvpSet_1(bevd_0);
case -929581181: return bem_intNpSet_1(bevd_0);
case -1874833356: return bem_stringNpSetDirect_1(bevd_0);
case 871090668: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2125872141: return bem_classConfSet_1(bevd_0);
case -394986408: return bem_libEmitPathSet_1(bevd_0);
case -1865537438: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -907907090: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 98515388: return bem_csynSet_1(bevd_0);
case -466323179: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1174948833: return bem_gcMarksSet_1(bevd_0);
case -634776273: return bem_classEmitsSetDirect_1(bevd_0);
case 166102614: return bem_objectNpSet_1(bevd_0);
case 1445341038: return bem_belslitsSetDirect_1(bevd_0);
case 643548482: return bem_buildSetDirect_1(bevd_0);
case -333276786: return bem_ccCacheSet_1(bevd_0);
case 2136360349: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 686685053: return bem_methodBodySet_1(bevd_0);
case -1922674628: return bem_idToNameSet_1(bevd_0);
case 1656331720: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 358002107: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1303822081: return bem_gcMarksSetDirect_1(bevd_0);
case -1458355968: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -934885152: return bem_boolNpSet_1(bevd_0);
case 703430755: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -412836858: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -702095651: return bem_scvpSetDirect_1(bevd_0);
case -378017084: return bem_methodsSetDirect_1(bevd_0);
case -689542850: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case -1422931072: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 87192390: return bem_smnlcsSetDirect_1(bevd_0);
case -706718921: return bem_ccMethodsSet_1(bevd_0);
case -155216284: return bem_boolCcSet_1(bevd_0);
case -250311142: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1564350641: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1653231508: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 626366986: return bem_lastMethodsLinesSet_1(bevd_0);
case -1775322592: return bem_nameToIdSet_1(bevd_0);
case -636861096: return bem_stringNpSet_1(bevd_0);
case -776402593: return bem_classCallsSet_1(bevd_0);
case -1774717483: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1143836115: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1593019334: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1743834701: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1428690346: return bem_ntypesSetDirect_1(bevd_0);
case 389360318: return bem_inFilePathedSet_1(bevd_0);
case -333309214: return bem_idToNamePathSet_1(bevd_0);
case 114831915: return bem_methodCallsSetDirect_1(bevd_0);
case 960865297: return bem_belslitsSet_1(bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case -1829908091: return bem_floatNpSetDirect_1(bevd_0);
case -1737202813: return bem_inFilePathedSetDirect_1(bevd_0);
case 2091209925: return bem_qSetDirect_1(bevd_0);
case 691321870: return bem_exceptDecSet_1(bevd_0);
case -1043950199: return bem_objectCcSet_1(bevd_0);
case -79170001: return bem_emitLangSet_1(bevd_0);
case -894151885: return bem_callNamesSet_1(bevd_0);
case 30711742: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1111606063: return bem_synEmitPathSet_1(bevd_0);
case -24360525: return bem_nullValueSet_1(bevd_0);
case -836041959: return bem_methodCallsSet_1(bevd_0);
case -1578751254: return bem_randSet_1(bevd_0);
case 1544773660: return bem_lastCallSetDirect_1(bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
case 1384400227: return bem_fileExtSet_1(bevd_0);
case 1148491173: return bem_idToNameSetDirect_1(bevd_0);
case 2003552490: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -660713819: return bem_lastMethodsSizeSet_1(bevd_0);
case -1905806097: return bem_synEmitPathSetDirect_1(bevd_0);
case 1812776395: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1206570236: return bem_smnlecsSetDirect_1(bevd_0);
case -1653613309: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1420393256: return bem_classCallsSetDirect_1(bevd_0);
case -1341270267: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -143688028: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -561195760: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2092090388: return bem_intNpSetDirect_1(bevd_0);
case -1897820560: return bem_mnodeSet_1(bevd_0);
case 895001239: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1927225078: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1072307391: return bem_instOfSet_1(bevd_0);
case -2119429973: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1456667347: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1507028574: return bem_transSetDirect_1(bevd_0);
case -1646676132: return bem_mnodeSetDirect_1(bevd_0);
case -1442118080: return bem_dynMethodsSetDirect_1(bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case 785145234: return bem_buildSet_1(bevd_0);
case -80681040: return bem_lineCountSetDirect_1(bevd_0);
case 1290342107: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1154388096: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2031391887: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 926196764: return bem_parentConfSet_1(bevd_0);
case 1502842604: return bem_def_1(bevd_0);
case 1416881737: return bem_methodCatchSet_1(bevd_0);
case -936491216: return bem_propertyDecsSet_1(bevd_0);
case 751866755: return bem_begin_1(bevd_0);
case -1128003588: return bem_maxDynArgsSetDirect_1(bevd_0);
case 1362402849: return bem_classesInDepthOrderSet_1(bevd_0);
case 71809580: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -705442457: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -652173880: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1420294612: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1469645134: return bem_objectCcSetDirect_1(bevd_0);
case 117560274: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 815573408: return bem_inClassSet_1(bevd_0);
case 1925204515: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 2078858608: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1323721267: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1096877473: return bem_fileExtSetDirect_1(bevd_0);
case -1396686409: return bem_cnodeSet_1(bevd_0);
case 1995667852: return bem_invpSetDirect_1(bevd_0);
case -2022139977: return bem_smnlcsSet_1(bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case -665974850: return bem_instanceNotEqualSet_1(bevd_0);
case 1010411362: return bem_idToNamePathSetDirect_1(bevd_0);
case 530794489: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1100845740: return bem_nameToIdPathSet_1(bevd_0);
case 82915460: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1638572677: return bem_boolNpSetDirect_1(bevd_0);
case -470114064: return bem_onceDecsSet_1(bevd_0);
case -331988870: return bem_fullLibEmitNameSet_1(bevd_0);
case 1248959659: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1843137071: return bem_nameToIdSetDirect_1(bevd_0);
case 599280134: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -969564803: return bem_libEmitPathSetDirect_1(bevd_0);
case -808442685: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1202279567: return bem_floatNpSet_1(bevd_0);
case -1744323983: return bem_msynSetDirect_1(bevd_0);
case 1340760510: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -790936174: return bem_inClassSetDirect_1(bevd_0);
case -1141973511: return bem_superCallsSet_1(bevd_0);
case 1205261977: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -2132945136: return bem_instanceEqualSet_1(bevd_0);
case 921169143: return bem_falseValueSetDirect_1(bevd_0);
case -1821787550: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1662580805: return bem_nlSet_1(bevd_0);
case -1516956354: return bem_onceDecsSetDirect_1(bevd_0);
case -1876466258: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1458889989: return bem_classConfSetDirect_1(bevd_0);
case -65315758: return bem_constSetDirect_1(bevd_0);
case 848141829: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -436386552: return bem_methodsSet_1(bevd_0);
case 636839391: return bem_csynSetDirect_1(bevd_0);
case 37570993: return bem_libEmitNameSet_1(bevd_0);
case 995032904: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -251911853: return bem_lineCountSet_1(bevd_0);
case -1353987546: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1419297414: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1180006819: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2010530107: return bem_trueValueSet_1(bevd_0);
case 1665706820: return bem_transSet_1(bevd_0);
case 1109212991: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -165539302: return bem_lastCallSet_1(bevd_0);
case 252691957: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1363283872: return bem_instOfSetDirect_1(bevd_0);
case 962771272: return bem_dynMethodsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1752669674: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 307141032: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -959826594: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1023457258: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -736854295: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2019000825: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -812798356: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -924250391: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -2098469700: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 26704511: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 191623926: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1816385946: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1792850881: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1924942600: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -2021581130: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 279866041: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1828238235: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -677458390: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -926673652: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 72334552: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 742546919: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
