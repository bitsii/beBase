package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 32*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 33*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(-829023044);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 43*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-86063738);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 43*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(-953066157);
if (bevl_firstmnsyn.bevi_bool)/* Line: 44*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 45*/
 else /* Line: 46*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 47*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 49*/
 else /* Line: 43*/ {
break;
} /* Line: 43*/
} /* Line: 43*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 56*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-86063738);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 56*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(-953066157);
bevt_34_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_34_ta_ph.bevi_bool))/* Line: 57*/ {
if (bevl_firstptsyn.bevi_bool)/* Line: 58*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 59*/
 else /* Line: 60*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_35_ta_ph);
} /* Line: 61*/
bevt_37_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_38_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_36_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 63*/
} /* Line: 57*/
 else /* Line: 56*/ {
break;
} /* Line: 56*/
} /* Line: 56*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_43_ta_ph = bevl_bet.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_42_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_48_ta_ph);
bevl_tout.bemd_1(-193994338, bevl_bet);
bevl_tout.bemd_0(-600132606);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1084469308);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1525278583);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_21));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_0_ta_ph = bevl_bc.bem_begins_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 91*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
beva_sdec.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 93*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
beva_sdec.bem_addValue_1(bevt_4_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 106*/
 else /* Line: 106*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 106*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 107*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 113*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 113*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 113*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 113*/
 else /* Line: 113*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 113*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 114*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_exceptDec);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_ms = bevt_0_ta_ph.bem_add_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_30));
bevt_6_ta_ph = bevl_ms.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_9_ta_ph = bevl_ms.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1358501419);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_36));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {22, 23, 24, 28, 32, 32, 32, 32, 32, 33, 33, 33, 35, 35, 35, 35, 36, 37, 37, 38, 38, 38, 38, 38, 38, 39, 39, 39, 39, 39, 39, 41, 41, 42, 43, 43, 0, 43, 43, 45, 47, 47, 49, 49, 49, 49, 51, 51, 52, 52, 54, 54, 55, 56, 56, 0, 56, 56, 57, 59, 61, 61, 63, 63, 63, 63, 66, 66, 68, 68, 70, 70, 71, 71, 71, 71, 71, 71, 72, 72, 73, 73, 74, 75, 79, 79, 79, 80, 81, 81, 81, 81, 81, 81, 83, 83, 83, 83, 83, 83, 83, 83, 83, 83, 89, 90, 91, 91, 92, 92, 93, 93, 95, 95, 96, 102, 102, 102, 102, 102, 102, 106, 106, 106, 0, 0, 0, 107, 107, 109, 109, 113, 113, 113, 0, 0, 0, 114, 114, 116, 116, 120, 120, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 128, 132, 132, 132, 136, 136, 136, 136, 136, 136, 136, 140, 140, 144, 144, 148, 148, 148};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {51, 52, 53, 54, 113, 114, 115, 116, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 149, 152, 154, 156, 159, 160, 162, 163, 164, 165, 171, 172, 173, 174, 175, 176, 177, 178, 179, 179, 182, 184, 185, 188, 191, 192, 194, 195, 196, 197, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 271, 272, 273, 274, 276, 277, 278, 279, 281, 282, 283, 292, 293, 294, 295, 296, 297, 305, 310, 311, 313, 316, 320, 323, 324, 326, 327, 335, 340, 341, 343, 346, 350, 353, 354, 356, 357, 361, 362, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 411, 412, 413, 422, 423, 424, 425, 426, 427, 428, 432, 433, 437, 438, 443, 444, 445};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 22 51
new 0 22 51
assign 1 23 52
new 0 23 52
assign 1 24 53
new 0 24 53
new 1 28 54
assign 1 32 113
classDirGet 0 32 113
assign 1 32 114
fileGet 0 32 114
assign 1 32 115
existsGet 0 32 115
assign 1 32 116
not 0 32 121
assign 1 33 122
classDirGet 0 33 122
assign 1 33 123
fileGet 0 33 123
makeDirs 0 33 124
assign 1 35 126
typePathGet 0 35 126
assign 1 35 127
fileGet 0 35 127
assign 1 35 128
writerGet 0 35 128
assign 1 35 129
open 0 35 129
assign 1 36 130
new 0 36 130
assign 1 37 131
new 0 37 131
addValue 1 37 132
assign 1 38 133
new 0 38 133
assign 1 38 134
addValue 1 38 134
assign 1 38 135
typeEmitNameGet 0 38 135
assign 1 38 136
addValue 1 38 136
assign 1 38 137
new 0 38 137
addValue 1 38 138
assign 1 39 139
new 0 39 139
assign 1 39 140
addValue 1 39 140
assign 1 39 141
typeEmitNameGet 0 39 141
assign 1 39 142
addValue 1 39 142
assign 1 39 143
new 0 39 143
addValue 1 39 144
assign 1 41 145
new 0 41 145
addValue 1 41 146
assign 1 42 147
new 0 42 147
assign 1 43 148
mtdListGet 0 43 148
assign 1 43 149
iteratorGet 0 0 149
assign 1 43 152
hasNextGet 0 43 152
assign 1 43 154
nextGet 0 43 154
assign 1 45 156
new 0 45 156
assign 1 47 159
new 0 47 159
addValue 1 47 160
assign 1 49 162
addValue 1 49 162
assign 1 49 163
nameGet 0 49 163
assign 1 49 164
addValue 1 49 164
addValue 1 49 165
assign 1 51 171
new 0 51 171
addValue 1 51 172
assign 1 52 173
new 0 52 173
addValue 1 52 174
assign 1 54 175
new 0 54 175
addValue 1 54 176
assign 1 55 177
new 0 55 177
assign 1 56 178
ptyListGet 0 56 178
assign 1 56 179
iteratorGet 0 0 179
assign 1 56 182
hasNextGet 0 56 182
assign 1 56 184
nextGet 0 56 184
assign 1 57 185
isSlotGet 0 57 185
assign 1 59 188
new 0 59 188
assign 1 61 191
new 0 61 191
addValue 1 61 192
assign 1 63 194
addValue 1 63 194
assign 1 63 195
nameGet 0 63 195
assign 1 63 196
addValue 1 63 196
addValue 1 63 197
assign 1 66 204
new 0 66 204
addValue 1 66 205
assign 1 68 206
new 0 68 206
addValue 1 68 207
assign 1 70 208
new 0 70 208
addValue 1 70 209
assign 1 71 210
new 0 71 210
assign 1 71 211
addValue 1 71 211
assign 1 71 212
emitNameGet 0 71 212
assign 1 71 213
addValue 1 71 213
assign 1 71 214
new 0 71 214
addValue 1 71 215
assign 1 72 216
new 0 72 216
addValue 1 72 217
assign 1 73 218
new 0 73 218
addValue 1 73 219
write 1 74 220
close 0 75 221
assign 1 79 242
new 0 79 242
assign 1 79 243
toString 0 79 243
assign 1 79 244
add 1 79 244
incrementValue 0 80 245
assign 1 81 246
new 0 81 246
assign 1 81 247
addValue 1 81 247
assign 1 81 248
addValue 1 81 248
assign 1 81 249
new 0 81 249
assign 1 81 250
addValue 1 81 250
addValue 1 81 251
assign 1 83 252
containedGet 0 83 252
assign 1 83 253
firstGet 0 83 253
assign 1 83 254
containedGet 0 83 254
assign 1 83 255
firstGet 0 83 255
assign 1 83 256
new 0 83 256
assign 1 83 257
add 1 83 257
assign 1 83 258
new 0 83 258
assign 1 83 259
add 1 83 259
assign 1 83 260
finalAssign 4 83 260
addValue 1 83 261
getInt 2 89 271
assign 1 90 272
toHexString 1 90 272
assign 1 91 273
new 0 91 273
assign 1 91 274
begins 1 91 274
assign 1 92 276
new 0 92 276
assign 1 92 277
substring 1 92 277
assign 1 93 278
new 0 93 278
addValue 1 93 279
assign 1 95 281
new 0 95 281
addValue 1 95 282
addValue 1 96 283
assign 1 102 292
new 0 102 292
assign 1 102 293
add 1 102 293
assign 1 102 294
new 0 102 294
assign 1 102 295
add 1 102 295
assign 1 102 296
add 1 102 296
return 1 102 297
assign 1 106 305
def 1 106 310
assign 1 106 311
isFinalGet 0 106 311
assign 1 0 313
assign 1 0 316
assign 1 0 320
assign 1 107 323
new 0 107 323
return 1 107 324
assign 1 109 326
new 0 109 326
return 1 109 327
assign 1 113 335
def 1 113 340
assign 1 113 341
isFinalGet 0 113 341
assign 1 0 343
assign 1 0 346
assign 1 0 350
assign 1 114 353
new 0 114 353
return 1 114 354
assign 1 116 356
new 0 116 356
return 1 116 357
assign 1 120 361
new 0 120 361
return 1 120 362
assign 1 124 384
new 0 124 384
assign 1 124 385
add 1 124 385
assign 1 124 386
new 0 124 386
assign 1 124 387
add 1 124 387
assign 1 124 388
add 1 124 388
assign 1 125 389
new 0 125 389
assign 1 125 390
addValue 1 125 390
assign 1 125 391
addValue 1 125 391
assign 1 125 392
new 0 125 392
assign 1 125 393
addValue 1 125 393
addValue 1 125 394
assign 1 126 395
new 0 126 395
assign 1 126 396
addValue 1 126 396
addValue 1 126 397
assign 1 127 398
new 0 127 398
assign 1 127 399
addValue 1 127 399
assign 1 127 400
outputPlatformGet 0 127 400
assign 1 127 401
nameGet 0 127 401
assign 1 127 402
addValue 1 127 402
assign 1 127 403
new 0 127 403
assign 1 127 404
addValue 1 127 404
addValue 1 127 405
return 1 128 406
assign 1 132 411
libNameGet 0 132 411
assign 1 132 412
beginNs 1 132 412
return 1 132 413
assign 1 136 422
new 0 136 422
assign 1 136 423
libNs 1 136 423
assign 1 136 424
add 1 136 424
assign 1 136 425
new 0 136 425
assign 1 136 426
add 1 136 426
assign 1 136 427
add 1 136 427
return 1 136 428
assign 1 140 432
getNameSpace 1 140 432
return 1 140 433
assign 1 144 437
new 0 144 437
return 1 144 438
assign 1 148 443
new 0 148 443
assign 1 148 444
add 1 148 444
return 1 148 445
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -556561835: return bem_instanceNotEqualGet_0();
case -926204005: return bem_emitLib_0();
case 326328388: return bem_lastMethodsLinesGet_0();
case 951196727: return bem_methodCatchGet_0();
case 514389022: return bem_boolNpGet_0();
case 239003291: return bem_callNamesGet_0();
case 1560880885: return bem_saveIds_0();
case -1882164386: return bem_beginNs_0();
case 620923711: return bem_transGet_0();
case -1644262147: return bem_buildInitial_0();
case 1962668450: return bem_hashGet_0();
case -550265769: return bem_classEndGet_0();
case -531420556: return bem_mainInClassGet_0();
case 1272743147: return bem_nameToIdPathGet_0();
case 1046935364: return bem_cnodeGet_0();
case -1550783177: return bem_baseSmtdDecGet_0();
case -1699700006: return bem_randGet_0();
case 1952943856: return bem_iteratorGet_0();
case -308843961: return bem_classConfGet_0();
case 1021139679: return bem_maxDynArgsGet_0();
case -2139075710: return bem_onceDecsGet_0();
case 1517004685: return bem_emitLangGet_0();
case 801902083: return bem_spropDecGet_0();
case 406098263: return bem_lineCountGet_0();
case 1381821887: return bem_covariantReturnsGet_0();
case 2114260397: return bem_methodBodyGet_0();
case -1096705136: return bem_inFilePathedGet_0();
case -1823389245: return bem_baseMtdDecGet_0();
case -1461368744: return bem_boolCcGet_0();
case 713253065: return bem_instOfGet_0();
case 720734104: return bem_classCallsGet_0();
case -231961835: return bem_fileExtGet_0();
case 1027167395: return bem_print_0();
case 140673708: return bem_ntypesGet_0();
case -1653249435: return bem_constGet_0();
case 406656028: return bem_msynGet_0();
case -1275652428: return bem_overrideMtdDecGet_0();
case -1626649948: return bem_buildClassInfo_0();
case 1892556353: return bem_loadIds_0();
case -981204172: return bem_copy_0();
case 65828234: return bem_gcMarksGet_0();
case 2083360768: return bem_idToNamePathGet_0();
case 1208408634: return bem_dynMethodsGet_0();
case 789280404: return bem_propertyDecsGet_0();
case -1124831641: return bem_belslitsGet_0();
case -1501634450: return bem_new_0();
case 1427497638: return bem_smnlcsGet_0();
case 1344119598: return bem_inClassGet_0();
case 38201250: return bem_ccMethodsGet_0();
case -887414419: return bem_lastMethodBodySizeGet_0();
case 112751161: return bem_initialDecGet_0();
case -2032882395: return bem_preClassGet_0();
case -429060890: return bem_writeBET_0();
case -1785199596: return bem_mainStartGet_0();
case 117347037: return bem_lastCallGet_0();
case -1355685979: return bem_returnTypeGet_0();
case 682606793: return bem_trueValueGet_0();
case 2079583211: return bem_newDecGet_0();
case 664539038: return bem_classesInDepthOrderGet_0();
case 766843001: return bem_lastMethodBodyLinesGet_0();
case -1039152589: return bem_boolTypeGet_0();
case -510180250: return bem_objectNpGet_0();
case 893825701: return bem_typeDecGet_0();
case -857669365: return bem_smnlecsGet_0();
case 1734393691: return bem_getClassOutput_0();
case 885814143: return bem_classEmitsGet_0();
case 993364350: return bem_runtimeInitGet_0();
case 1654972306: return bem_libEmitPathGet_0();
case 714405491: return bem_parentConfGet_0();
case -81676601: return bem_buildCreate_0();
case 293374071: return bem_idToNameGet_0();
case 1783903004: return bem_intNpGet_0();
case -578299096: return bem_stringNpGet_0();
case -1781056170: return bem_maxSpillArgsLenGet_0();
case 712726055: return bem_libEmitNameGet_0();
case 1846483902: return bem_scvpGet_0();
case 2128763425: return bem_nameToIdGet_0();
case 588595052: return bem_fullLibEmitNameGet_0();
case -1427805535: return bem_superNameGet_0();
case 1042252895: return bem_mainOutsideNsGet_0();
case -1769336505: return bem_saveSyns_0();
case -1045230770: return bem_useDynMethodsGet_0();
case 1438194167: return bem_superCallsGet_0();
case -205262063: return bem_invpGet_0();
case 1428682878: return bem_nullValueGet_0();
case 226897390: return bem_nativeCSlotsGet_0();
case -1158869371: return bem_doEmit_0();
case -11439861: return bem_toString_0();
case 4250483: return bem_exceptDecGet_0();
case -1568574256: return bem_instanceEqualGet_0();
case 885070529: return bem_endNs_0();
case -1144118318: return bem_floatNpGet_0();
case 313012912: return bem_mainEndGet_0();
case -824317803: return bem_nlGet_0();
case -844097059: return bem_falseValueGet_0();
case -1397386186: return bem_objectCcGet_0();
case -264466509: return bem_ccCacheGet_0();
case -1943529873: return bem_synEmitPathGet_0();
case -1707808096: return bem_mnodeGet_0();
case -1494434359: return bem_qGet_0();
case -1914373581: return bem_csynGet_0();
case -112767609: return bem_buildGet_0();
case -325668352: return bem_preClassOutput_0();
case -995036197: return bem_methodsGet_0();
case 517610545: return bem_create_0();
case -1948331912: return bem_propDecGet_0();
case 1746264016: return bem_methodCallsGet_0();
case -254456712: return bem_getLibOutput_0();
case -715347878: return bem_lastMethodsSizeGet_0();
case 991057223: return bem_afterCast_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 149502832: return bem_lastCallSet_1(bevd_0);
case 318003038: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 470328868: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 105007733: return bem_equals_1(bevd_0);
case -2013087450: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -261409280: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 175706548: return bem_instOfSet_1(bevd_0);
case -422547858: return bem_preClassSet_1(bevd_0);
case 864865895: return bem_lineCountSet_1(bevd_0);
case -1483342607: return bem_synEmitPathSet_1(bevd_0);
case 1753029372: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1274762127: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1852726388: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1614274869: return bem_msynSet_1(bevd_0);
case -1298882603: return bem_nameToIdPathSet_1(bevd_0);
case -1468091058: return bem_inClassSet_1(bevd_0);
case -8269136: return bem_lastMethodsLinesSet_1(bevd_0);
case 1642564856: return bem_idToNamePathSet_1(bevd_0);
case 234623522: return bem_notEquals_1(bevd_0);
case -1648408493: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1019035829: return bem_begin_1(bevd_0);
case 464049298: return bem_constSet_1(bevd_0);
case 38319371: return bem_classesInDepthOrderSet_1(bevd_0);
case -1598575778: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1023139230: return bem_objectNpSet_1(bevd_0);
case -633354664: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -940412526: return bem_invpSet_1(bevd_0);
case -1484351605: return bem_superCallsSet_1(bevd_0);
case 80310638: return bem_stringNpSet_1(bevd_0);
case 159513796: return bem_belslitsSet_1(bevd_0);
case -1811960996: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 881440240: return bem_ccMethodsSet_1(bevd_0);
case 444469081: return bem_gcMarksSet_1(bevd_0);
case 711296703: return bem_dynMethodsSet_1(bevd_0);
case 99095806: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1637747919: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -583472760: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 108424553: return bem_lastMethodBodySizeSet_1(bevd_0);
case -138776987: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1097276276: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -1519953283: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -716215247: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1246284645: return bem_randSet_1(bevd_0);
case 687204731: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1425037931: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -592176328: return bem_parentConfSet_1(bevd_0);
case -170998105: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -864547: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 166670949: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -2106796433: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -456470910: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1208179951: return bem_smnlcsSet_1(bevd_0);
case 375905880: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1411824260: return bem_intNpSet_1(bevd_0);
case 397354083: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -897201779: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1920447034: return bem_methodCatchSet_1(bevd_0);
case 866626362: return bem_csynSet_1(bevd_0);
case 1835580207: return bem_falseValueSet_1(bevd_0);
case -361136526: return bem_idToNameSet_1(bevd_0);
case -1307441786: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 926488414: return bem_nullValueSet_1(bevd_0);
case -2113339179: return bem_trueValueSet_1(bevd_0);
case 1779004900: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -901975780: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1197434043: return bem_end_1(bevd_0);
case -1935517936: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -808348524: return bem_returnTypeSet_1(bevd_0);
case 1856868490: return bem_boolNpSet_1(bevd_0);
case 1309869578: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1870741269: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 744481562: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1038349529: return bem_fullLibEmitNameSet_1(bevd_0);
case -1406357580: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 2110244838: return bem_buildSet_1(bevd_0);
case -1029038529: return bem_boolCcSet_1(bevd_0);
case 109570607: return bem_methodBodySet_1(bevd_0);
case 1719365987: return bem_emitLangSet_1(bevd_0);
case -1558703434: return bem_libEmitNameSet_1(bevd_0);
case -1299416634: return bem_ccCacheSet_1(bevd_0);
case 582740164: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 657123996: return bem_callNamesSet_1(bevd_0);
case 119504570: return bem_cnodeSet_1(bevd_0);
case 27665983: return bem_libEmitPathSet_1(bevd_0);
case -2063315875: return bem_lastMethodsSizeSet_1(bevd_0);
case -1332587468: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 760035440: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 772496333: return bem_scvpSet_1(bevd_0);
case -1341087244: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 514629872: return bem_objectCcSet_1(bevd_0);
case 1323205701: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 857299362: return bem_copyTo_1(bevd_0);
case 1192925569: return bem_smnlecsSet_1(bevd_0);
case -1006408470: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1987652470: return bem_classEmitsSet_1(bevd_0);
case -1908473169: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1633196550: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 978237725: return bem_def_1(bevd_0);
case -1765952112: return bem_onceDecsSet_1(bevd_0);
case -326291840: return bem_nameToIdSet_1(bevd_0);
case 1618808587: return bem_maxDynArgsSet_1(bevd_0);
case -791420730: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -460873787: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -2047953674: return bem_undef_1(bevd_0);
case 1574057435: return bem_instanceEqualSet_1(bevd_0);
case 1438361240: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 113251201: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 127019382: return bem_classConfSet_1(bevd_0);
case 58486872: return bem_ntypesSet_1(bevd_0);
case -1992246573: return bem_instanceNotEqualSet_1(bevd_0);
case -1627511424: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -2064688702: return bem_fileExtSet_1(bevd_0);
case 1970003272: return bem_decNameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1253742062: return bem_maxSpillArgsLenSet_1(bevd_0);
case -197689756: return bem_exceptDecSet_1(bevd_0);
case 939133411: return bem_propertyDecsSet_1(bevd_0);
case -1837218522: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1242554677: return bem_nlSet_1(bevd_0);
case 65957002: return bem_classCallsSet_1(bevd_0);
case 103094324: return bem_nativeCSlotsSet_1(bevd_0);
case -2067291820: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 923718851: return bem_methodsSet_1(bevd_0);
case 808283499: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1181786802: return bem_transSet_1(bevd_0);
case 1514679226: return bem_inFilePathedSet_1(bevd_0);
case 590788019: return bem_floatNpSet_1(bevd_0);
case 227960770: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 429736378: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1162000498: return bem_qSet_1(bevd_0);
case 1221427286: return bem_methodCallsSet_1(bevd_0);
case -135002544: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1366365337: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 255191105: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1092126873: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -822254784: return bem_mnodeSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1815776256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 42643109: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 299345515: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1851579780: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -632471541: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1506914933: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1616402830: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -347868937: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 409791889: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1368859121: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -450201493: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1036438363: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -976124908: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 664895809: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1464498530: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -496707179: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -190605724: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 60907544: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -171681911: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 2047911633: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1372894048: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1281071238: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1167772048: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1525601720: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -42472690: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
