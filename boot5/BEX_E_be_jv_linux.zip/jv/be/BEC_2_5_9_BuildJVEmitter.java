package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(1502192509);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(2079194339);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(1790843424);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(2079194339);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(1790843424);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_ta_ph = bevl_bet.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_ta_ph);
bevl_tout.bemd_1(-1516598663, bevl_bet);
bevl_tout.bemd_0(-1265790650);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-888461784);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(838566730);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_21));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_typeName);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_0_ta_ph = bevl_bc.bem_begins_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 88*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
beva_sdec.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 90*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
beva_sdec.bem_addValue_1(bevt_4_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 103*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 103*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 103*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 103*/
 else /* Line: 103*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 103*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 104*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 110*/
 else /* Line: 110*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 110*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 111*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_exceptDec);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_30));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_ms = bevt_0_ta_ph.bem_add_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_6_ta_ph = bevl_ms.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_9_ta_ph = bevl_ms.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(474531258);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJVEmitter_bels_36));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_39));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 81, 81, 81, 81, 86, 87, 88, 88, 89, 89, 90, 90, 92, 92, 93, 99, 99, 99, 99, 99, 99, 103, 103, 103, 0, 0, 0, 104, 104, 106, 106, 110, 110, 110, 0, 0, 0, 111, 111, 113, 113, 117, 117, 121, 121, 121, 121, 121, 122, 122, 122, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 125, 129, 129, 129, 133, 133, 133, 133, 133, 133, 133, 137, 137, 141, 141, 145, 145, 145};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {52, 53, 54, 55, 113, 114, 115, 116, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 149, 152, 154, 156, 159, 160, 162, 163, 164, 165, 171, 172, 173, 174, 175, 176, 177, 178, 179, 179, 182, 184, 186, 189, 190, 192, 193, 194, 195, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 266, 267, 268, 269, 270, 279, 280, 281, 282, 284, 285, 286, 287, 289, 290, 291, 300, 301, 302, 303, 304, 305, 313, 318, 319, 321, 324, 328, 331, 332, 334, 335, 343, 348, 349, 351, 354, 358, 361, 362, 364, 365, 369, 370, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 419, 420, 421, 430, 431, 432, 433, 434, 435, 436, 440, 441, 445, 446, 451, 452, 453};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 52
new 0 16 52
assign 1 17 53
new 0 17 53
assign 1 18 54
new 0 18 54
new 1 22 55
assign 1 26 113
classDirGet 0 26 113
assign 1 26 114
fileGet 0 26 114
assign 1 26 115
existsGet 0 26 115
assign 1 26 116
not 0 26 121
assign 1 27 122
classDirGet 0 27 122
assign 1 27 123
fileGet 0 27 123
makeDirs 0 27 124
assign 1 29 126
typePathGet 0 29 126
assign 1 29 127
fileGet 0 29 127
assign 1 29 128
writerGet 0 29 128
assign 1 29 129
open 0 29 129
assign 1 30 130
new 0 30 130
assign 1 31 131
new 0 31 131
addValue 1 31 132
assign 1 32 133
new 0 32 133
assign 1 32 134
addValue 1 32 134
assign 1 32 135
typeEmitNameGet 0 32 135
assign 1 32 136
addValue 1 32 136
assign 1 32 137
new 0 32 137
addValue 1 32 138
assign 1 33 139
new 0 33 139
assign 1 33 140
addValue 1 33 140
assign 1 33 141
typeEmitNameGet 0 33 141
assign 1 33 142
addValue 1 33 142
assign 1 33 143
new 0 33 143
addValue 1 33 144
assign 1 35 145
new 0 35 145
addValue 1 35 146
assign 1 36 147
new 0 36 147
assign 1 37 148
mtdListGet 0 37 148
assign 1 37 149
iteratorGet 0 0 149
assign 1 37 152
hasNextGet 0 37 152
assign 1 37 154
nextGet 0 37 154
assign 1 39 156
new 0 39 156
assign 1 41 159
new 0 41 159
addValue 1 41 160
assign 1 43 162
addValue 1 43 162
assign 1 43 163
nameGet 0 43 163
assign 1 43 164
addValue 1 43 164
addValue 1 43 165
assign 1 45 171
new 0 45 171
addValue 1 45 172
assign 1 46 173
new 0 46 173
addValue 1 46 174
assign 1 48 175
new 0 48 175
addValue 1 48 176
assign 1 49 177
new 0 49 177
assign 1 50 178
ptyListGet 0 50 178
assign 1 50 179
iteratorGet 0 0 179
assign 1 50 182
hasNextGet 0 50 182
assign 1 50 184
nextGet 0 50 184
assign 1 52 186
new 0 52 186
assign 1 54 189
new 0 54 189
addValue 1 54 190
assign 1 56 192
addValue 1 56 192
assign 1 56 193
nameGet 0 56 193
assign 1 56 194
addValue 1 56 194
addValue 1 56 195
assign 1 58 201
new 0 58 201
addValue 1 58 202
assign 1 60 203
new 0 60 203
addValue 1 60 204
assign 1 62 205
new 0 62 205
addValue 1 62 206
assign 1 63 207
new 0 63 207
assign 1 63 208
addValue 1 63 208
assign 1 63 209
emitNameGet 0 63 209
assign 1 63 210
addValue 1 63 210
assign 1 63 211
new 0 63 211
addValue 1 63 212
assign 1 64 213
new 0 64 213
addValue 1 64 214
assign 1 65 215
new 0 65 215
addValue 1 65 216
write 1 66 217
close 0 67 218
assign 1 71 239
new 0 71 239
assign 1 71 240
toString 0 71 240
assign 1 71 241
add 1 71 241
incrementValue 0 72 242
assign 1 73 243
new 0 73 243
assign 1 73 244
addValue 1 73 244
assign 1 73 245
addValue 1 73 245
assign 1 73 246
new 0 73 246
assign 1 73 247
addValue 1 73 247
addValue 1 73 248
assign 1 75 249
containedGet 0 75 249
assign 1 75 250
firstGet 0 75 250
assign 1 75 251
containedGet 0 75 251
assign 1 75 252
firstGet 0 75 252
assign 1 75 253
new 0 75 253
assign 1 75 254
add 1 75 254
assign 1 75 255
new 0 75 255
assign 1 75 256
add 1 75 256
assign 1 75 257
finalAssign 4 75 257
addValue 1 75 258
assign 1 81 266
new 0 81 266
assign 1 81 267
add 1 81 267
assign 1 81 268
new 0 81 268
assign 1 81 269
add 1 81 269
return 1 81 270
getInt 2 86 279
assign 1 87 280
toHexString 1 87 280
assign 1 88 281
new 0 88 281
assign 1 88 282
begins 1 88 282
assign 1 89 284
new 0 89 284
assign 1 89 285
substring 1 89 285
assign 1 90 286
new 0 90 286
addValue 1 90 287
assign 1 92 289
new 0 92 289
addValue 1 92 290
addValue 1 93 291
assign 1 99 300
new 0 99 300
assign 1 99 301
add 1 99 301
assign 1 99 302
new 0 99 302
assign 1 99 303
add 1 99 303
assign 1 99 304
add 1 99 304
return 1 99 305
assign 1 103 313
def 1 103 318
assign 1 103 319
isFinalGet 0 103 319
assign 1 0 321
assign 1 0 324
assign 1 0 328
assign 1 104 331
new 0 104 331
return 1 104 332
assign 1 106 334
new 0 106 334
return 1 106 335
assign 1 110 343
def 1 110 348
assign 1 110 349
isFinalGet 0 110 349
assign 1 0 351
assign 1 0 354
assign 1 0 358
assign 1 111 361
new 0 111 361
return 1 111 362
assign 1 113 364
new 0 113 364
return 1 113 365
assign 1 117 369
new 0 117 369
return 1 117 370
assign 1 121 392
new 0 121 392
assign 1 121 393
add 1 121 393
assign 1 121 394
new 0 121 394
assign 1 121 395
add 1 121 395
assign 1 121 396
add 1 121 396
assign 1 122 397
new 0 122 397
assign 1 122 398
addValue 1 122 398
assign 1 122 399
addValue 1 122 399
assign 1 122 400
new 0 122 400
assign 1 122 401
addValue 1 122 401
addValue 1 122 402
assign 1 123 403
new 0 123 403
assign 1 123 404
addValue 1 123 404
addValue 1 123 405
assign 1 124 406
new 0 124 406
assign 1 124 407
addValue 1 124 407
assign 1 124 408
outputPlatformGet 0 124 408
assign 1 124 409
nameGet 0 124 409
assign 1 124 410
addValue 1 124 410
assign 1 124 411
new 0 124 411
assign 1 124 412
addValue 1 124 412
addValue 1 124 413
return 1 125 414
assign 1 129 419
libNameGet 0 129 419
assign 1 129 420
beginNs 1 129 420
return 1 129 421
assign 1 133 430
new 0 133 430
assign 1 133 431
libNs 1 133 431
assign 1 133 432
add 1 133 432
assign 1 133 433
new 0 133 433
assign 1 133 434
add 1 133 434
assign 1 133 435
add 1 133 435
return 1 133 436
assign 1 137 440
getNameSpace 1 137 440
return 1 137 441
assign 1 141 445
new 0 141 445
return 1 141 446
assign 1 145 451
new 0 145 451
assign 1 145 452
add 1 145 452
return 1 145 453
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -194416815: return bem_tagGet_0();
case 1503058021: return bem_nlGetDirect_0();
case 2135388716: return bem_methodCatchGetDirect_0();
case 925024910: return bem_initialDecGet_0();
case 1793358884: return bem_trueValueGet_0();
case 806522578: return bem_methodBodyGetDirect_0();
case 1162753942: return bem_nullValueGetDirect_0();
case 635189742: return bem_maxDynArgsGet_0();
case -1833628544: return bem_inFilePathedGetDirect_0();
case 1150141335: return bem_ccMethodsGet_0();
case -1054904858: return bem_superCallsGet_0();
case 94089935: return bem_emitLangGet_0();
case -1589051638: return bem_libEmitPathGet_0();
case 359521037: return bem_maxSpillArgsLenGet_0();
case -862722877: return bem_transGet_0();
case 1264734915: return bem_libEmitPathGetDirect_0();
case 1703693602: return bem_callNamesGetDirect_0();
case -1110811398: return bem_trueValueGetDirect_0();
case -1004023772: return bem_ntypesGet_0();
case 326197819: return bem_nativeCSlotsGet_0();
case 1912670781: return bem_objectCcGet_0();
case 1905534162: return bem_instanceEqualGetDirect_0();
case -1910053839: return bem_onceCountGetDirect_0();
case 53468262: return bem_fileExtGetDirect_0();
case -262537222: return bem_objectNpGet_0();
case 308691748: return bem_preClassGet_0();
case 1477577581: return bem_libEmitNameGet_0();
case 140319723: return bem_csynGetDirect_0();
case 1905038552: return bem_cnodeGetDirect_0();
case -887367478: return bem_preClassOutput_0();
case 1744287157: return bem_csynGet_0();
case 1777587047: return bem_hashGet_0();
case 1219132974: return bem_inFilePathedGet_0();
case 1072486295: return bem_lastCallGet_0();
case 641774147: return bem_propertyDecsGetDirect_0();
case -1315567811: return bem_lastMethodBodySizeGetDirect_0();
case 1805652978: return bem_emitLib_0();
case 1591732244: return bem_msynGetDirect_0();
case -24175734: return bem_stringNpGetDirect_0();
case -1079372620: return bem_classConfGetDirect_0();
case -381582083: return bem_floatNpGet_0();
case 669810060: return bem_qGetDirect_0();
case 511450341: return bem_mnodeGetDirect_0();
case 1412274749: return bem_idToNameGet_0();
case -155070458: return bem_getLibOutput_0();
case 378307569: return bem_copy_0();
case -722727430: return bem_lastMethodBodyLinesGet_0();
case 617445256: return bem_sourceFileNameGet_0();
case 853174851: return bem_classConfGet_0();
case -1398473876: return bem_nullValueGet_0();
case 992286008: return bem_transGetDirect_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case 390411238: return bem_baseMtdDecGet_0();
case -1455899172: return bem_create_0();
case -1850944799: return bem_classCallsGet_0();
case 273402662: return bem_falseValueGet_0();
case 1797865600: return bem_new_0();
case -332630483: return bem_newDecGet_0();
case 116621852: return bem_objectNpGetDirect_0();
case 1325518620: return bem_nameToIdPathGetDirect_0();
case -665649433: return bem_serializeContents_0();
case 781778477: return bem_doEmit_0();
case -1419548458: return bem_boolNpGet_0();
case 765572505: return bem_lastMethodsLinesGetDirect_0();
case 1873117573: return bem_returnTypeGet_0();
case -2098924929: return bem_libEmitNameGetDirect_0();
case 1506947334: return bem_methodCallsGet_0();
case -2029379403: return bem_buildInitial_0();
case 627195809: return bem_synEmitPathGetDirect_0();
case 265398337: return bem_scvpGet_0();
case 298858449: return bem_boolCcGetDirect_0();
case -1249098594: return bem_baseSmtdDecGet_0();
case 1173022244: return bem_fullLibEmitNameGet_0();
case -1597178570: return bem_inClassGet_0();
case -1490773144: return bem_typeDecGet_0();
case -494144822: return bem_mainOutsideNsGet_0();
case 890445537: return bem_onceDecsGet_0();
case 42922333: return bem_methodsGetDirect_0();
case -1455283550: return bem_dynMethodsGet_0();
case 931416163: return bem_qGet_0();
case -1447417557: return bem_invpGetDirect_0();
case -533443118: return bem_many_0();
case -14913198: return bem_invpGet_0();
case 2011135674: return bem_iteratorGet_0();
case -2029574796: return bem_stringNpGet_0();
case -1858273663: return bem_onceCountGet_0();
case -1845454093: return bem_scvpGetDirect_0();
case 1602165649: return bem_synEmitPathGet_0();
case -1846365398: return bem_nameToIdGetDirect_0();
case -1195435374: return bem_emitLangGetDirect_0();
case -842767332: return bem_maxDynArgsGetDirect_0();
case 1697253613: return bem_runtimeInitGet_0();
case 451789076: return bem_idToNameGetDirect_0();
case -937783525: return bem_boolTypeGet_0();
case 191867381: return bem_mnodeGet_0();
case 249454576: return bem_classesInDepthOrderGet_0();
case 225943401: return bem_instanceEqualGet_0();
case -405931701: return bem_gcMarksGetDirect_0();
case 1586318625: return bem_idToNamePathGet_0();
case 176349111: return bem_belslitsGet_0();
case 1865390464: return bem_superNameGet_0();
case -998905752: return bem_buildClassInfo_0();
case 509361355: return bem_once_0();
case -785595880: return bem_propertyDecsGet_0();
case -476211692: return bem_falseValueGetDirect_0();
case -1073959042: return bem_instanceNotEqualGet_0();
case 1955915393: return bem_fieldNamesGet_0();
case -528718446: return bem_smnlcsGet_0();
case 1568568871: return bem_randGetDirect_0();
case 967234853: return bem_fieldIteratorGet_0();
case 816218742: return bem_returnTypeGetDirect_0();
case 382988070: return bem_maxSpillArgsLenGetDirect_0();
case -723188689: return bem_spropDecGet_0();
case -2039345401: return bem_classesInDepthOrderGetDirect_0();
case 193084255: return bem_methodsGet_0();
case 791802958: return bem_ntypesGetDirect_0();
case -302442152: return bem_intNpGetDirect_0();
case 107469584: return bem_inClassGetDirect_0();
case -697135632: return bem_ccMethodsGetDirect_0();
case -1392864962: return bem_lastCallGetDirect_0();
case 785425739: return bem_overrideMtdDecGet_0();
case -404516557: return bem_constGetDirect_0();
case 1818057755: return bem_constGet_0();
case 1653455970: return bem_mainInClassGet_0();
case -475612631: return bem_buildCreate_0();
case -519502326: return bem_afterCast_0();
case 681603953: return bem_methodCatchGet_0();
case 1296912518: return bem_exceptDecGet_0();
case 342698497: return bem_ccCacheGetDirect_0();
case -2068461189: return bem_getClassOutput_0();
case -119499799: return bem_serializationIteratorGet_0();
case 1374272360: return bem_buildGet_0();
case 888353027: return bem_buildGetDirect_0();
case 582263442: return bem_parentConfGet_0();
case -1909355469: return bem_msynGet_0();
case -350896681: return bem_mainStartGet_0();
case -2114221887: return bem_classEndGet_0();
case -746962069: return bem_covariantReturnsGet_0();
case -84082019: return bem_fileExtGet_0();
case 1144881729: return bem_instOfGet_0();
case 766881626: return bem_print_0();
case 1815197226: return bem_lastMethodsSizeGetDirect_0();
case -2009919476: return bem_endNs_0();
case 1469415500: return bem_boolCcGet_0();
case 538252033: return bem_superCallsGetDirect_0();
case 1095297479: return bem_echo_0();
case -1067351774: return bem_beginNs_0();
case -1740207467: return bem_writeBET_0();
case 545742559: return bem_lineCountGetDirect_0();
case 2114382260: return bem_objectCcGetDirect_0();
case -426028537: return bem_classEmitsGetDirect_0();
case -406956880: return bem_parentConfGetDirect_0();
case -603451589: return bem_smnlecsGetDirect_0();
case -259726049: return bem_intNpGet_0();
case -780776169: return bem_mainEndGet_0();
case 1041877869: return bem_loadIds_0();
case -796414705: return bem_lastMethodBodySizeGet_0();
case 740706827: return bem_onceDecsGetDirect_0();
case -53013739: return bem_saveIds_0();
case 1583959093: return bem_fullLibEmitNameGetDirect_0();
case -291178400: return bem_preClassGetDirect_0();
case -572855542: return bem_smnlcsGetDirect_0();
case -901721978: return bem_idToNamePathGetDirect_0();
case -1534298015: return bem_gcMarksGet_0();
case -1724453868: return bem_serializeToString_0();
case 534980941: return bem_smnlecsGet_0();
case 1677885439: return bem_classCallsGetDirect_0();
case 609528497: return bem_methodCallsGetDirect_0();
case -139920320: return bem_nlGet_0();
case 1292393197: return bem_methodBodyGet_0();
case 1970270900: return bem_nativeCSlotsGetDirect_0();
case -126383080: return bem_floatNpGetDirect_0();
case 1755540748: return bem_lineCountGet_0();
case 2114339043: return bem_useDynMethodsGet_0();
case 155717476: return bem_exceptDecGetDirect_0();
case 731225401: return bem_boolNpGetDirect_0();
case 216105249: return bem_callNamesGet_0();
case -1715766851: return bem_toAny_0();
case 393266297: return bem_propDecGet_0();
case 280712282: return bem_toString_0();
case -2093608456: return bem_lastMethodBodyLinesGetDirect_0();
case -1615994079: return bem_lastMethodsSizeGet_0();
case -1032091093: return bem_saveSyns_0();
case -1629252621: return bem_dynMethodsGetDirect_0();
case -2037381545: return bem_classEmitsGet_0();
case 219531782: return bem_belslitsGetDirect_0();
case -180175097: return bem_classNameGet_0();
case -335816057: return bem_ccCacheGet_0();
case 1566139441: return bem_lastMethodsLinesGet_0();
case -853823601: return bem_instOfGetDirect_0();
case 1622329715: return bem_nameToIdGet_0();
case -1643489318: return bem_randGet_0();
case -1584738850: return bem_instanceNotEqualGetDirect_0();
case 265237464: return bem_cnodeGet_0();
case -1434921080: return bem_nameToIdPathGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -48953027: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1308316390: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1639496724: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -529095435: return bem_mnodeSet_1(bevd_0);
case 360270858: return bem_emitLangSetDirect_1(bevd_0);
case 341384273: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -462989387: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 987219935: return bem_objectNpSetDirect_1(bevd_0);
case 20780357: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1392524141: return bem_instanceEqualSet_1(bevd_0);
case -12217689: return bem_buildSet_1(bevd_0);
case 1684752051: return bem_lineCountSet_1(bevd_0);
case -1693674995: return bem_maxDynArgsSet_1(bevd_0);
case 1941094200: return bem_superCallsSetDirect_1(bevd_0);
case -1745491494: return bem_lastCallSetDirect_1(bevd_0);
case 1740491206: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -282516978: return bem_trueValueSet_1(bevd_0);
case -1732707510: return bem_returnTypeSetDirect_1(bevd_0);
case -2145909328: return bem_belslitsSetDirect_1(bevd_0);
case 241846506: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1006679348: return bem_csynSetDirect_1(bevd_0);
case -1886087943: return bem_nlSet_1(bevd_0);
case 741315762: return bem_boolCcSetDirect_1(bevd_0);
case -1023881759: return bem_objectCcSet_1(bevd_0);
case -1993960773: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -185362349: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -623614909: return bem_lineCountSetDirect_1(bevd_0);
case -964072264: return bem_onceDecsSetDirect_1(bevd_0);
case -375031861: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1064450762: return bem_exceptDecSetDirect_1(bevd_0);
case 1753124539: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1294747668: return bem_idToNamePathSetDirect_1(bevd_0);
case -2146158908: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1281335557: return bem_classesInDepthOrderSet_1(bevd_0);
case -880837714: return bem_qSet_1(bevd_0);
case 1709840017: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 397253092: return bem_fileExtSetDirect_1(bevd_0);
case -202691091: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 437033803: return bem_ccMethodsSet_1(bevd_0);
case -1006525682: return bem_floatNpSetDirect_1(bevd_0);
case -844508708: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 2003727579: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1544380828: return bem_lastMethodsLinesSet_1(bevd_0);
case 864670097: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1793084059: return bem_inFilePathedSet_1(bevd_0);
case -1629616876: return bem_exceptDecSet_1(bevd_0);
case -903684133: return bem_nullValueSet_1(bevd_0);
case 1636011974: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -749429326: return bem_onceCountSet_1(bevd_0);
case 1085566846: return bem_libEmitPathSetDirect_1(bevd_0);
case 945540098: return bem_callNamesSetDirect_1(bevd_0);
case -564128983: return bem_methodBodySetDirect_1(bevd_0);
case 1217957725: return bem_csynSet_1(bevd_0);
case -168181914: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1196623344: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1015239461: return bem_methodsSetDirect_1(bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case -618590448: return bem_idToNameSet_1(bevd_0);
case -742612571: return bem_stringNpSetDirect_1(bevd_0);
case -1391031501: return bem_begin_1(bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 305397663: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 775921207: return bem_nullValueSetDirect_1(bevd_0);
case -490149994: return bem_nameToIdSetDirect_1(bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case -427578580: return bem_ntypesSetDirect_1(bevd_0);
case 88297429: return bem_belslitsSet_1(bevd_0);
case 2016986154: return bem_propertyDecsSet_1(bevd_0);
case 1406152602: return bem_cnodeSetDirect_1(bevd_0);
case -1532668713: return bem_classConfSet_1(bevd_0);
case 1724958438: return bem_callNamesSet_1(bevd_0);
case -681546933: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -122545246: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -387591732: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1552488279: return bem_mnodeSetDirect_1(bevd_0);
case 2116345555: return bem_stringNpSet_1(bevd_0);
case 1479177301: return bem_libEmitNameSet_1(bevd_0);
case 2122371181: return bem_gcMarksSet_1(bevd_0);
case 756151160: return bem_ntypesSet_1(bevd_0);
case -19180211: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1789100262: return bem_ccMethodsSetDirect_1(bevd_0);
case -1296564950: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -842341677: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1136413901: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1148800720: return bem_inFilePathedSetDirect_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
case -910606222: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 817706635: return bem_libEmitPathSet_1(bevd_0);
case 1059589799: return bem_onceDecsSet_1(bevd_0);
case 110035441: return bem_dynMethodsSetDirect_1(bevd_0);
case -702801474: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -527332365: return bem_lastMethodBodySizeSet_1(bevd_0);
case 594913348: return bem_constSet_1(bevd_0);
case 2114809377: return bem_returnTypeSet_1(bevd_0);
case 949703483: return bem_emitLangSet_1(bevd_0);
case 1410737548: return bem_qSetDirect_1(bevd_0);
case -1404330161: return bem_msynSetDirect_1(bevd_0);
case 138306944: return bem_objectCcSetDirect_1(bevd_0);
case 1276508571: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 50632438: return bem_superCallsSet_1(bevd_0);
case 424860281: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case 1304342816: return bem_intNpSet_1(bevd_0);
case 134424426: return bem_ccCacheSetDirect_1(bevd_0);
case 592490345: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 2140389869: return bem_falseValueSetDirect_1(bevd_0);
case 1603883404: return bem_objectNpSet_1(bevd_0);
case -163019173: return bem_instOfSetDirect_1(bevd_0);
case -25858983: return bem_methodCatchSet_1(bevd_0);
case -1673551969: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1781002948: return bem_boolNpSet_1(bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case 1020727048: return bem_nameToIdPathSetDirect_1(bevd_0);
case -711928018: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1927957525: return bem_buildSetDirect_1(bevd_0);
case 1524571590: return bem_inClassSetDirect_1(bevd_0);
case 509576162: return bem_lastCallSet_1(bevd_0);
case 952899824: return bem_preClassSetDirect_1(bevd_0);
case -797792135: return bem_classCallsSet_1(bevd_0);
case 1395019619: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1887825906: return bem_nameToIdSet_1(bevd_0);
case -570774443: return bem_classConfSetDirect_1(bevd_0);
case 1466821967: return bem_libEmitNameSetDirect_1(bevd_0);
case -1691755245: return bem_inClassSet_1(bevd_0);
case 17388890: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 962611113: return bem_smnlcsSetDirect_1(bevd_0);
case 54167562: return bem_nativeCSlotsSet_1(bevd_0);
case -330563246: return bem_maxSpillArgsLenSet_1(bevd_0);
case 242734772: return bem_fullLibEmitNameSet_1(bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case -955624889: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -2110862616: return bem_msynSet_1(bevd_0);
case 775660429: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 87642485: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 906320876: return bem_defined_1(bevd_0);
case -1108084673: return bem_gcMarksSetDirect_1(bevd_0);
case -1734217806: return bem_dynMethodsSet_1(bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case 747087398: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1829666884: return bem_falseValueSet_1(bevd_0);
case -1626634561: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -664533281: return bem_propertyDecsSetDirect_1(bevd_0);
case 1655420142: return bem_nameToIdPathSet_1(bevd_0);
case 1838349708: return bem_end_1(bevd_0);
case 208610385: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1647180839: return bem_preClassSet_1(bevd_0);
case -431277594: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -48333136: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 318983403: return bem_scvpSet_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1525819013: return bem_transSet_1(bevd_0);
case 678733787: return bem_classEmitsSet_1(bevd_0);
case 36140349: return bem_smnlecsSet_1(bevd_0);
case 1218845835: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 457461480: return bem_transSetDirect_1(bevd_0);
case -312092686: return bem_randSetDirect_1(bevd_0);
case 1081048320: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 984149159: return bem_synEmitPathSet_1(bevd_0);
case 1964918425: return bem_fileExtSet_1(bevd_0);
case 1758385264: return bem_trueValueSetDirect_1(bevd_0);
case 165843339: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 447550300: return bem_methodCallsSetDirect_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case -178270225: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1383403171: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1370108073: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1840406895: return bem_idToNameSetDirect_1(bevd_0);
case 1689231097: return bem_nlSetDirect_1(bevd_0);
case 614068934: return bem_boolCcSet_1(bevd_0);
case 779352739: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 720005040: return bem_methodsSet_1(bevd_0);
case -1114052391: return bem_classEmitsSetDirect_1(bevd_0);
case 1112183445: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 431570509: return bem_scvpSetDirect_1(bevd_0);
case -448332600: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -851746261: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -508619442: return bem_randSet_1(bevd_0);
case 1287489458: return bem_smnlcsSet_1(bevd_0);
case -130022558: return bem_floatNpSet_1(bevd_0);
case 1263273147: return bem_intNpSetDirect_1(bevd_0);
case -296122309: return bem_invpSet_1(bevd_0);
case 2075892111: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1195171881: return bem_lastMethodsSizeSet_1(bevd_0);
case 1314267609: return bem_smnlecsSetDirect_1(bevd_0);
case -6129830: return bem_ccCacheSet_1(bevd_0);
case 564592730: return bem_synEmitPathSetDirect_1(bevd_0);
case -1168215307: return bem_parentConfSet_1(bevd_0);
case 50094943: return bem_methodCallsSet_1(bevd_0);
case -876242992: return bem_onceCountSetDirect_1(bevd_0);
case -131728502: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1472297393: return bem_instOfSet_1(bevd_0);
case -1140658310: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 129505499: return bem_cnodeSet_1(bevd_0);
case 17540745: return bem_boolNpSetDirect_1(bevd_0);
case -758514411: return bem_methodCatchSetDirect_1(bevd_0);
case 1311059440: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1863238097: return bem_constSetDirect_1(bevd_0);
case 2090015697: return bem_classCallsSetDirect_1(bevd_0);
case -1822121174: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -2056146751: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1997143892: return bem_methodBodySet_1(bevd_0);
case 30463453: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1683877236: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case 1470773498: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 614546705: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1098824142: return bem_invpSetDirect_1(bevd_0);
case -865411360: return bem_instanceEqualSetDirect_1(bevd_0);
case -445857610: return bem_notEquals_1(bevd_0);
case -1964836079: return bem_idToNamePathSet_1(bevd_0);
case -1709839462: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1733701727: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -486007806: return bem_instanceNotEqualSet_1(bevd_0);
case -1072160123: return bem_parentConfSetDirect_1(bevd_0);
case 553108475: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -159251373: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1231370067: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2092916220: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 129624468: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1540886850: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 262954177: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1824869793: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -338194135: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2134677627: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 272537972: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 347930777: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 563986203: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1263289406: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 660998527: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1785762629: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -137129399: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -309777014: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1284545505: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1590297588: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1395339005: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -352058123: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
