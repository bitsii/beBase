package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_6, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_7, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_8, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_9, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_10, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_12, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_13, 14));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_14, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_27, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_28, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 9));
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-35560540);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1889227325);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 46 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 59 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 59 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
return bevt_3_tmpany_phold;
} /* Line: 60 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 66 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 66 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
return bevt_3_tmpany_phold;
} /* Line: 67 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1546357286);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 37, 37, 37, 37, 37, 42, 43, 44, 44, 45, 45, 46, 46, 48, 48, 48, 49, 55, 55, 55, 55, 55, 55, 59, 59, 59, 0, 0, 0, 60, 60, 62, 62, 66, 66, 66, 0, 0, 0, 67, 67, 69, 69, 73, 73, 77, 77, 77, 77, 77, 78, 78, 78, 78, 78, 78, 79, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 81, 85, 85, 85, 89, 89, 89, 89, 89, 89, 89, 93, 93, 97, 97, 101, 101, 101, 101};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {54, 55, 56, 57, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 105, 106, 107, 108, 109, 119, 120, 121, 122, 124, 125, 126, 127, 129, 130, 131, 132, 141, 142, 143, 144, 145, 146, 154, 159, 160, 162, 165, 169, 172, 173, 175, 176, 184, 189, 190, 192, 195, 199, 202, 203, 205, 206, 210, 211, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 260, 261, 262, 271, 272, 273, 274, 275, 276, 277, 281, 282, 286, 287, 293, 294, 295, 296};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 54
new 0 17 54
assign 1 18 55
new 0 18 55
assign 1 19 56
new 0 19 56
new 1 23 57
assign 1 27 78
new 0 27 78
assign 1 27 79
toString 0 27 79
assign 1 27 80
add 1 27 80
incrementValue 0 28 81
assign 1 29 82
new 0 29 82
assign 1 29 83
addValue 1 29 83
assign 1 29 84
addValue 1 29 84
assign 1 29 85
new 0 29 85
assign 1 29 86
addValue 1 29 86
addValue 1 29 87
assign 1 31 88
containedGet 0 31 88
assign 1 31 89
firstGet 0 31 89
assign 1 31 90
containedGet 0 31 90
assign 1 31 91
firstGet 0 31 91
assign 1 31 92
new 0 31 92
assign 1 31 93
add 1 31 93
assign 1 31 94
new 0 31 94
assign 1 31 95
add 1 31 95
assign 1 31 96
finalAssign 4 31 96
addValue 1 31 97
assign 1 37 105
new 0 37 105
assign 1 37 106
add 1 37 106
assign 1 37 107
new 0 37 107
assign 1 37 108
add 1 37 108
return 1 37 109
getInt 2 42 119
assign 1 43 120
toHexString 1 43 120
assign 1 44 121
new 0 44 121
assign 1 44 122
begins 1 44 122
assign 1 45 124
new 0 45 124
assign 1 45 125
substring 1 45 125
assign 1 46 126
new 0 46 126
addValue 1 46 127
assign 1 48 129
new 0 48 129
assign 1 48 130
once 0 48 130
addValue 1 48 131
addValue 1 49 132
assign 1 55 141
new 0 55 141
assign 1 55 142
add 1 55 142
assign 1 55 143
new 0 55 143
assign 1 55 144
add 1 55 144
assign 1 55 145
add 1 55 145
return 1 55 146
assign 1 59 154
def 1 59 159
assign 1 59 160
isFinalGet 0 59 160
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 60 172
new 0 60 172
return 1 60 173
assign 1 62 175
new 0 62 175
return 1 62 176
assign 1 66 184
def 1 66 189
assign 1 66 190
isFinalGet 0 66 190
assign 1 0 192
assign 1 0 195
assign 1 0 199
assign 1 67 202
new 0 67 202
return 1 67 203
assign 1 69 205
new 0 69 205
return 1 69 206
assign 1 73 210
new 0 73 210
return 1 73 211
assign 1 77 233
new 0 77 233
assign 1 77 234
add 1 77 234
assign 1 77 235
new 0 77 235
assign 1 77 236
add 1 77 236
assign 1 77 237
add 1 77 237
assign 1 78 238
new 0 78 238
assign 1 78 239
addValue 1 78 239
assign 1 78 240
addValue 1 78 240
assign 1 78 241
new 0 78 241
assign 1 78 242
addValue 1 78 242
addValue 1 78 243
assign 1 79 244
new 0 79 244
assign 1 79 245
addValue 1 79 245
addValue 1 79 246
assign 1 80 247
new 0 80 247
assign 1 80 248
addValue 1 80 248
assign 1 80 249
outputPlatformGet 0 80 249
assign 1 80 250
nameGet 0 80 250
assign 1 80 251
addValue 1 80 251
assign 1 80 252
new 0 80 252
assign 1 80 253
addValue 1 80 253
addValue 1 80 254
return 1 81 255
assign 1 85 260
libNameGet 0 85 260
assign 1 85 261
beginNs 1 85 261
return 1 85 262
assign 1 89 271
new 0 89 271
assign 1 89 272
libNs 1 89 272
assign 1 89 273
add 1 89 273
assign 1 89 274
new 0 89 274
assign 1 89 275
add 1 89 275
assign 1 89 276
add 1 89 276
return 1 89 277
assign 1 93 281
getNameSpace 1 93 281
return 1 93 282
assign 1 97 286
new 0 97 286
return 1 97 287
assign 1 101 293
new 0 101 293
assign 1 101 294
once 0 101 294
assign 1 101 295
add 1 101 295
return 1 101 296
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case 769881243: return bem_synEmitPathGet_0();
case -863935940: return bem_copy_0();
case -660838505: return bem_initialDecGet_0();
case 982594103: return bem_saveSyns_0();
case -2138151223: return bem_objectNpGet_0();
case -1193556301: return bem_cnodeGet_0();
case 282425611: return bem_maxSpillArgsLenGet_0();
case -437044003: return bem_instanceEqualGet_0();
case -1806278931: return bem_dynConditionsAllGet_0();
case -355495718: return bem_coanyiantReturnsGet_0();
case -176876439: return bem_fieldIteratorGet_0();
case -980391072: return bem_csynGet_0();
case -1701410698: return bem_ntypesGet_0();
case -440213206: return bem_lineCountGet_0();
case 96032377: return bem_buildCreate_0();
case -186101535: return bem_msynGet_0();
case 628190677: return bem_transGet_0();
case 708456626: return bem_nameToIdGet_0();
case 1948037477: return bem_spropDecGet_0();
case 1230099738: return bem_methodCatchGet_0();
case -1827750495: return bem_mainStartGet_0();
case -1268379046: return bem_classConfGet_0();
case 1055346870: return bem_methodsGet_0();
case -415304406: return bem_afterCast_0();
case -1532337396: return bem_returnTypeGet_0();
case 196901153: return bem_callNamesGet_0();
case 819726132: return bem_stringNpGet_0();
case -316641464: return bem_libEmitPathGet_0();
case 908949462: return bem_buildClassInfo_0();
case -131080468: return bem_print_0();
case -74598148: return bem_superNameGet_0();
case -1678429516: return bem_classCallsGet_0();
case 865364657: return bem_serializeContents_0();
case 1482095315: return bem_emitLib_0();
case -127854262: return bem_ccMethodsGet_0();
case -227417779: return bem_preClassGet_0();
case 1106940065: return bem_runtimeInitGet_0();
case 364520690: return bem_ccCacheGet_0();
case -1553150546: return bem_mainEndGet_0();
case -1253273495: return bem_boolCcGet_0();
case 140703288: return bem_getLibOutput_0();
case -1233217785: return bem_invpGet_0();
case 1840398987: return bem_libEmitNameGet_0();
case -1196329855: return bem_tagGet_0();
case -1895992021: return bem_deserializeClassNameGet_0();
case 1871393210: return bem_baseSmtdDecGet_0();
case 1030499827: return bem_iteratorGet_0();
case 1797341089: return bem_once_0();
case 132757848: return bem_baseMtdDecGet_0();
case -1399659722: return bem_classesInDepthOrderGet_0();
case -420119970: return bem_intNpGet_0();
case -1439602778: return bem_boolNpGet_0();
case 2093612864: return bem_nativeCSlotsGet_0();
case -1835406239: return bem_constGet_0();
case -145312000: return bem_serializationIteratorGet_0();
case -354770697: return bem_endNs_0();
case -410411449: return bem_mnodeGet_0();
case -411613865: return bem_falseValueGet_0();
case 1776668483: return bem_objectCcGet_0();
case 632946141: return bem_doEmit_0();
case -1625843188: return bem_mainInClassGet_0();
case -236609190: return bem_lastMethodsSizeGet_0();
case 1038193525: return bem_useDynMethodsGet_0();
case -528906285: return bem_instOfGet_0();
case 1063910563: return bem_parentConfGet_0();
case 148209611: return bem_scvpGet_0();
case -473779247: return bem_trueValueGet_0();
case 1462505683: return bem_instanceNotEqualGet_0();
case 1025570736: return bem_mainOutsideNsGet_0();
case 101987176: return bem_nullValueGet_0();
case 521055509: return bem_serializeToString_0();
case 2038513814: return bem_lastMethodBodyLinesGet_0();
case -1883912499: return bem_boolTypeGet_0();
case 657801083: return bem_toString_0();
case 958435126: return bem_nlGet_0();
case -570457243: return bem_randGet_0();
case 1676820253: return bem_fullLibEmitNameGet_0();
case -795099180: return bem_lastMethodBodySizeGet_0();
case -316245103: return bem_echo_0();
case -1581561223: return bem_propDecGet_0();
case 1497459507: return bem_idToNameGet_0();
case 904467476: return bem_create_0();
case 714053375: return bem_many_0();
case 216537271: return bem_getClassOutput_0();
case -1607106381: return bem_onceDecsGet_0();
case 1788796699: return bem_lastCallGet_0();
case -180851755: return bem_propertyDecsGet_0();
case -1239151636: return bem_sourceFileNameGet_0();
case -1594227513: return bem_buildInitial_0();
case 475724789: return bem_inFilePathedGet_0();
case 850291067: return bem_classEmitsGet_0();
case -1536664622: return bem_superCallsGet_0();
case -349544485: return bem_onceCountGet_0();
case -1221116258: return bem_smnlecsGet_0();
case 1989274006: return bem_exceptDecGet_0();
case -629628110: return bem_toAny_0();
case 374523547: return bem_buildGet_0();
case 1953612931: return bem_methodCallsGet_0();
case 879068661: return bem_lastMethodsLinesGet_0();
case -465953812: return bem_qGet_0();
case -1771287084: return bem_maxDynArgsGet_0();
case -2110228371: return bem_classEndGet_0();
case 2119497309: return bem_smnlcsGet_0();
case -407078717: return bem_fileExtGet_0();
case 269723613: return bem_hashGet_0();
case 2071886229: return bem_emitLangGet_0();
case 1917888644: return bem_overrideMtdDecGet_0();
case -820547047: return bem_new_0();
case 332161361: return bem_floatNpGet_0();
case 1021615634: return bem_classNameGet_0();
case -1872486443: return bem_beginNs_0();
case 134467605: return bem_methodBodyGet_0();
case -1642459483: return bem_dynMethodsGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case -1584774500: return bem_sameClass_1(bevd_0);
case 1762488488: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2105893033: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1343299422: return bem_nlSet_1(bevd_0);
case 883034998: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -966879103: return bem_trueValueSet_1(bevd_0);
case 218874128: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1152978774: return bem_boolNpSet_1(bevd_0);
case 468838490: return bem_floatNpSet_1(bevd_0);
case -1644687987: return bem_intNpSet_1(bevd_0);
case -1963744679: return bem_boolCcSet_1(bevd_0);
case 109424770: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1820972057: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -422560687: return bem_maxDynArgsSet_1(bevd_0);
case -868932692: return bem_cnodeSet_1(bevd_0);
case 741005867: return bem_propertyDecsSet_1(bevd_0);
case -132932347: return bem_methodsSet_1(bevd_0);
case 40526978: return bem_ccCacheSet_1(bevd_0);
case -268040666: return bem_classEmitsSet_1(bevd_0);
case -470736044: return bem_classCallsSet_1(bevd_0);
case -320954434: return bem_instOfSet_1(bevd_0);
case -1245302991: return bem_methodCallsSet_1(bevd_0);
case 358636632: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1074673344: return bem_copyTo_1(bevd_0);
case 1609402131: return bem_synEmitPathSet_1(bevd_0);
case -871338285: return bem_smnlcsSet_1(bevd_0);
case -1413543289: return bem_csynSet_1(bevd_0);
case 788271940: return bem_sameObject_1(bevd_0);
case 1700132942: return bem_falseValueSet_1(bevd_0);
case -682228113: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 316617566: return bem_instanceEqualSet_1(bevd_0);
case -1524451141: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 2050254872: return bem_randSet_1(bevd_0);
case 361986168: return bem_returnTypeSet_1(bevd_0);
case -1360190659: return bem_preClassSet_1(bevd_0);
case 1091259852: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -977322719: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -592181161: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1012624693: return bem_fileExtSet_1(bevd_0);
case -1900959423: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2105323180: return bem_constSet_1(bevd_0);
case 141556846: return bem_dynConditionsAllSet_1(bevd_0);
case 1362571028: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1693196376: return bem_otherType_1(bevd_0);
case -1060251279: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -2134234064: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 2080890716: return bem_nameToIdSet_1(bevd_0);
case 2139267389: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -2040571200: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 825926318: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1526634164: return bem_begin_1(bevd_0);
case 516327874: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -455244874: return bem_undefined_1(bevd_0);
case 80790810: return bem_notEquals_1(bevd_0);
case 418487858: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1056438081: return bem_parentConfSet_1(bevd_0);
case 552260281: return bem_methodCatchSet_1(bevd_0);
case -2100757503: return bem_callNamesSet_1(bevd_0);
case 1019022541: return bem_stringNpSet_1(bevd_0);
case 652025878: return bem_invpSet_1(bevd_0);
case -640391325: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -652712675: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -724037881: return bem_classesInDepthOrderSet_1(bevd_0);
case -1308362506: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -412909069: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -859372101: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -975394700: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1713753372: return bem_ccMethodsSet_1(bevd_0);
case 1387264412: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 932660582: return bem_libEmitNameSet_1(bevd_0);
case -1375485749: return bem_lastCallSet_1(bevd_0);
case 694202318: return bem_objectCcSet_1(bevd_0);
case -171735322: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1590668734: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1568563081: return bem_dynMethodsSet_1(bevd_0);
case 964202571: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1808338509: return bem_def_1(bevd_0);
case -507776640: return bem_onceCountSet_1(bevd_0);
case -1906708623: return bem_onceDecsSet_1(bevd_0);
case -1350692697: return bem_nativeCSlotsSet_1(bevd_0);
case 1926393329: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1347362301: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 779072074: return bem_scvpSet_1(bevd_0);
case -591542432: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -780740456: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -39691138: return bem_mnodeSet_1(bevd_0);
case 964986774: return bem_buildSet_1(bevd_0);
case 1913896471: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1308839829: return bem_smnlecsSet_1(bevd_0);
case -361034019: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 901454637: return bem_libEmitPathSet_1(bevd_0);
case -475836758: return bem_emitLangSet_1(bevd_0);
case -1102936411: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -905026588: return bem_fullLibEmitNameSet_1(bevd_0);
case -1203542452: return bem_lastMethodBodySizeSet_1(bevd_0);
case 566034428: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1001145040: return bem_exceptDecSet_1(bevd_0);
case -560471223: return bem_otherClass_1(bevd_0);
case 1392169787: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1090107136: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 470010214: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1131276608: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1634369463: return bem_msynSet_1(bevd_0);
case 1515929018: return bem_idToNameSet_1(bevd_0);
case 681555470: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1415564500: return bem_end_1(bevd_0);
case 1388099454: return bem_ntypesSet_1(bevd_0);
case -2062910233: return bem_lastMethodsSizeSet_1(bevd_0);
case -1454582741: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1462817918: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -507902848: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 455691587: return bem_qSet_1(bevd_0);
case 1397730331: return bem_lastMethodsLinesSet_1(bevd_0);
case -310482308: return bem_objectNpSet_1(bevd_0);
case -439337428: return bem_transSet_1(bevd_0);
case 779198300: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1683934309: return bem_nullValueSet_1(bevd_0);
case 443313913: return bem_instanceNotEqualSet_1(bevd_0);
case 1255807617: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1373326102: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 2063004658: return bem_sameType_1(bevd_0);
case 2016817692: return bem_equals_1(bevd_0);
case 1878002658: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 153472398: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 544484580: return bem_defined_1(bevd_0);
case -1356394981: return bem_classConfSet_1(bevd_0);
case 1937357848: return bem_lineCountSet_1(bevd_0);
case 1906132711: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1354444477: return bem_undef_1(bevd_0);
case 894606563: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1422975546: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1030110022: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -110208328: return bem_methodBodySet_1(bevd_0);
case -8307203: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1291351436: return bem_inFilePathedSet_1(bevd_0);
case -43988650: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -530407350: return bem_superCallsSet_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case -805622159: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1429936742: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -388925148: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -947364062: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 941928420: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 423661912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 901264448: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -236631668: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 468491321: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 338963035: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 26301084: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1164296058: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -884026318: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 235613807: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 783807335: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1749906718: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 374588116: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -539434931: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 883042907: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callCase) {
case 1712371485: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 785548216: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 625719453: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callCase, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callCase) {
case 1536203617: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callCase, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callCase) {
case 115774253: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 2114037615: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 949414652: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callCase, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
}
