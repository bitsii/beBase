package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_18, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_22, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_24, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_25, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_27, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_28, 14));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_29, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_35, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_40 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_41 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_42 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_42, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_43 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_43, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_44 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_45 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_45, 9));
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
bevt_4_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_existsGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_6_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_9_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_7_tmpany_phold.bemd_0(-1387305530);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_12_tmpany_phold = bevl_bet.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_17_tmpany_phold = bevl_bet.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_16_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_21_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_22_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_22_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bemd_0(791593169);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(415427106);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_24_tmpany_phold);
} /* Line: 42 */
bevt_26_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_27_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_28_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevt_33_tmpany_phold = bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_32_tmpany_phold.bem_addValue_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevl_tout.bemd_1(-953580170, bevl_bet);
bevl_tout.bemd_0(1681206955);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1243039790);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(391671439);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 78 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 91 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 91 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 91 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 91 */
 else  /* Line: 91 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 91 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_30));
return bevt_3_tmpany_phold;
} /* Line: 92 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
return bevt_3_tmpany_phold;
} /* Line: 99 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_39));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_40));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1204337669);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_41));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_44));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 48, 48, 50, 50, 51, 51, 51, 51, 51, 51, 52, 52, 53, 53, 54, 55, 59, 59, 59, 60, 61, 61, 61, 61, 61, 61, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 69, 69, 69, 69, 69, 74, 75, 76, 76, 77, 77, 78, 78, 80, 80, 80, 81, 87, 87, 87, 87, 87, 87, 91, 91, 91, 0, 0, 0, 92, 92, 94, 94, 98, 98, 98, 0, 0, 0, 99, 99, 101, 101, 105, 105, 109, 109, 109, 109, 109, 110, 110, 110, 110, 110, 110, 111, 111, 111, 112, 112, 112, 112, 112, 112, 112, 112, 113, 117, 117, 117, 121, 121, 121, 121, 121, 121, 121, 125, 125, 129, 129, 133, 133, 133, 133};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {72, 73, 74, 75, 122, 123, 124, 125, 130, 131, 132, 133, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 158, 161, 163, 165, 168, 169, 171, 172, 173, 174, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 247, 248, 249, 250, 251, 261, 262, 263, 264, 266, 267, 268, 269, 271, 272, 273, 274, 283, 284, 285, 286, 287, 288, 296, 301, 302, 304, 307, 311, 314, 315, 317, 318, 326, 331, 332, 334, 337, 341, 344, 345, 347, 348, 352, 353, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 402, 403, 404, 413, 414, 415, 416, 417, 418, 419, 423, 424, 428, 429, 435, 436, 437, 438};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 72
new 0 17 72
assign 1 18 73
new 0 18 73
assign 1 19 74
new 0 19 74
new 1 23 75
assign 1 27 122
classDirGet 0 27 122
assign 1 27 123
fileGet 0 27 123
assign 1 27 124
existsGet 0 27 124
assign 1 27 125
not 0 27 130
assign 1 28 131
classDirGet 0 28 131
assign 1 28 132
fileGet 0 28 132
makeDirs 0 28 133
assign 1 30 135
typePathGet 0 30 135
assign 1 30 136
fileGet 0 30 136
assign 1 30 137
writerGet 0 30 137
assign 1 30 138
open 0 30 138
assign 1 31 139
new 0 31 139
assign 1 32 140
new 0 32 140
addValue 1 32 141
assign 1 33 142
new 0 33 142
assign 1 33 143
addValue 1 33 143
assign 1 33 144
typeEmitNameGet 0 33 144
assign 1 33 145
addValue 1 33 145
assign 1 33 146
new 0 33 146
addValue 1 33 147
assign 1 34 148
new 0 34 148
assign 1 34 149
addValue 1 34 149
assign 1 34 150
typeEmitNameGet 0 34 150
assign 1 34 151
addValue 1 34 151
assign 1 34 152
new 0 34 152
addValue 1 34 153
assign 1 36 154
new 0 36 154
addValue 1 36 155
assign 1 37 156
new 0 37 156
assign 1 38 157
mtdListGet 0 38 157
assign 1 38 158
iteratorGet 0 0 158
assign 1 38 161
hasNextGet 0 38 161
assign 1 38 163
nextGet 0 38 163
assign 1 40 165
new 0 40 165
assign 1 42 168
new 0 42 168
addValue 1 42 169
assign 1 44 171
addValue 1 44 171
assign 1 44 172
nameGet 0 44 172
assign 1 44 173
addValue 1 44 173
addValue 1 44 174
assign 1 46 180
new 0 46 180
addValue 1 46 181
assign 1 47 182
new 0 47 182
addValue 1 47 183
assign 1 48 184
new 0 48 184
addValue 1 48 185
assign 1 50 186
new 0 50 186
addValue 1 50 187
assign 1 51 188
new 0 51 188
assign 1 51 189
addValue 1 51 189
assign 1 51 190
emitNameGet 0 51 190
assign 1 51 191
addValue 1 51 191
assign 1 51 192
new 0 51 192
addValue 1 51 193
assign 1 52 194
new 0 52 194
addValue 1 52 195
assign 1 53 196
new 0 53 196
addValue 1 53 197
write 1 54 198
close 0 55 199
assign 1 59 220
new 0 59 220
assign 1 59 221
toString 0 59 221
assign 1 59 222
add 1 59 222
incrementValue 0 60 223
assign 1 61 224
new 0 61 224
assign 1 61 225
addValue 1 61 225
assign 1 61 226
addValue 1 61 226
assign 1 61 227
new 0 61 227
assign 1 61 228
addValue 1 61 228
addValue 1 61 229
assign 1 63 230
containedGet 0 63 230
assign 1 63 231
firstGet 0 63 231
assign 1 63 232
containedGet 0 63 232
assign 1 63 233
firstGet 0 63 233
assign 1 63 234
new 0 63 234
assign 1 63 235
add 1 63 235
assign 1 63 236
new 0 63 236
assign 1 63 237
add 1 63 237
assign 1 63 238
finalAssign 4 63 238
addValue 1 63 239
assign 1 69 247
new 0 69 247
assign 1 69 248
add 1 69 248
assign 1 69 249
new 0 69 249
assign 1 69 250
add 1 69 250
return 1 69 251
getInt 2 74 261
assign 1 75 262
toHexString 1 75 262
assign 1 76 263
new 0 76 263
assign 1 76 264
begins 1 76 264
assign 1 77 266
new 0 77 266
assign 1 77 267
substring 1 77 267
assign 1 78 268
new 0 78 268
addValue 1 78 269
assign 1 80 271
new 0 80 271
assign 1 80 272
once 0 80 272
addValue 1 80 273
addValue 1 81 274
assign 1 87 283
new 0 87 283
assign 1 87 284
add 1 87 284
assign 1 87 285
new 0 87 285
assign 1 87 286
add 1 87 286
assign 1 87 287
add 1 87 287
return 1 87 288
assign 1 91 296
def 1 91 301
assign 1 91 302
isFinalGet 0 91 302
assign 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 92 314
new 0 92 314
return 1 92 315
assign 1 94 317
new 0 94 317
return 1 94 318
assign 1 98 326
def 1 98 331
assign 1 98 332
isFinalGet 0 98 332
assign 1 0 334
assign 1 0 337
assign 1 0 341
assign 1 99 344
new 0 99 344
return 1 99 345
assign 1 101 347
new 0 101 347
return 1 101 348
assign 1 105 352
new 0 105 352
return 1 105 353
assign 1 109 375
new 0 109 375
assign 1 109 376
add 1 109 376
assign 1 109 377
new 0 109 377
assign 1 109 378
add 1 109 378
assign 1 109 379
add 1 109 379
assign 1 110 380
new 0 110 380
assign 1 110 381
addValue 1 110 381
assign 1 110 382
addValue 1 110 382
assign 1 110 383
new 0 110 383
assign 1 110 384
addValue 1 110 384
addValue 1 110 385
assign 1 111 386
new 0 111 386
assign 1 111 387
addValue 1 111 387
addValue 1 111 388
assign 1 112 389
new 0 112 389
assign 1 112 390
addValue 1 112 390
assign 1 112 391
outputPlatformGet 0 112 391
assign 1 112 392
nameGet 0 112 392
assign 1 112 393
addValue 1 112 393
assign 1 112 394
new 0 112 394
assign 1 112 395
addValue 1 112 395
addValue 1 112 396
return 1 113 397
assign 1 117 402
libNameGet 0 117 402
assign 1 117 403
beginNs 1 117 403
return 1 117 404
assign 1 121 413
new 0 121 413
assign 1 121 414
libNs 1 121 414
assign 1 121 415
add 1 121 415
assign 1 121 416
new 0 121 416
assign 1 121 417
add 1 121 417
assign 1 121 418
add 1 121 418
return 1 121 419
assign 1 125 423
getNameSpace 1 125 423
return 1 125 424
assign 1 129 428
new 0 129 428
return 1 129 429
assign 1 133 435
new 0 133 435
assign 1 133 436
once 0 133 436
assign 1 133 437
add 1 133 437
return 1 133 438
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -841999632: return bem_exceptDecGet_0();
case -1571656834: return bem_toAny_0();
case 624481848: return bem_typeDecGet_0();
case -1914494730: return bem_objectCcGet_0();
case -821018265: return bem_stringNpGet_0();
case 99171040: return bem_classConfGet_0();
case -1220916727: return bem_many_0();
case 827292547: return bem_create_0();
case -751133094: return bem_coanyiantReturnsGet_0();
case 2093210380: return bem_floatNpGet_0();
case -1316333523: return bem_trueValueGet_0();
case -1893119669: return bem_buildCreate_0();
case 1577052979: return bem_lastMethodBodySizeGet_0();
case -1902275389: return bem_propDecGet_0();
case 1975956372: return bem_hashGet_0();
case 1169640650: return bem_invpGet_0();
case -457396695: return bem_instanceEqualGet_0();
case -362294474: return bem_sourceFileNameGet_0();
case 2080907218: return bem_echo_0();
case -631319917: return bem_objectNpGet_0();
case -538946103: return bem_writeBET_0();
case 585989692: return bem_serializeToString_0();
case -91344286: return bem_emitLangGet_0();
case 1645723223: return bem_randGet_0();
case -1773927844: return bem_buildGet_0();
case -1497402380: return bem_instanceNotEqualGet_0();
case -428067895: return bem_superCallsGet_0();
case 117275789: return bem_classEndGet_0();
case -136937581: return bem_propertyDecsGet_0();
case 1335338732: return bem_afterCast_0();
case 1968096544: return bem_lastCallGet_0();
case -1079755442: return bem_transGet_0();
case -1565430470: return bem_mainEndGet_0();
case 1059907561: return bem_classNameGet_0();
case 1421981990: return bem_mainInClassGet_0();
case -1768606456: return bem_emitLib_0();
case 1620920006: return bem_lineCountGet_0();
case 370244557: return bem_constGet_0();
case 718141709: return bem_libEmitNameGet_0();
case 988563641: return bem_iteratorGet_0();
case 227137526: return bem_useDynMethodsGet_0();
case -877050956: return bem_lastMethodsSizeGet_0();
case -374717092: return bem_lastMethodBodyLinesGet_0();
case 1013103989: return bem_mainStartGet_0();
case -249092502: return bem_ccMethodsGet_0();
case -1099311989: return bem_once_0();
case 415680990: return bem_boolTypeGet_0();
case -1652022291: return bem_superNameGet_0();
case -184992549: return bem_nlGet_0();
case 744922212: return bem_methodCatchGet_0();
case -1189286597: return bem_boolCcGet_0();
case -1131153280: return bem_copy_0();
case 760196139: return bem_preClassGet_0();
case 847900593: return bem_serializeContents_0();
case -1857343056: return bem_intNpGet_0();
case -128923278: return bem_instOfGet_0();
case 1848877146: return bem_onceDecsGet_0();
case -1915157262: return bem_cnodeGet_0();
case -1902048126: return bem_baseMtdDecGet_0();
case 878193071: return bem_scvpGet_0();
case 1407836438: return bem_baseSmtdDecGet_0();
case 1491479033: return bem_doEmit_0();
case 1616854488: return bem_print_0();
case -1202020522: return bem_classCallsGet_0();
case -1228227275: return bem_deserializeClassNameGet_0();
case 1357381598: return bem_fullLibEmitNameGet_0();
case 887158094: return bem_fieldIteratorGet_0();
case 1392747911: return bem_methodBodyGet_0();
case -207082183: return bem_nullValueGet_0();
case 584284373: return bem_ntypesGet_0();
case -1286565950: return bem_runtimeInitGet_0();
case -821453988: return bem_libEmitPathGet_0();
case 1082794036: return bem_dynMethodsGet_0();
case -1230881137: return bem_getClassOutput_0();
case -1079000572: return bem_returnTypeGet_0();
case 184429035: return bem_mnodeGet_0();
case 855226967: return bem_smnlcsGet_0();
case -969264291: return bem_falseValueGet_0();
case -1329173210: return bem_synEmitPathGet_0();
case -561329023: return bem_beginNs_0();
case -1503704688: return bem_fileExtGet_0();
case 864284274: return bem_methodCallsGet_0();
case 741192765: return bem_boolNpGet_0();
case -1846538755: return bem_csynGet_0();
case -1772825492: return bem_maxSpillArgsLenGet_0();
case -767836310: return bem_buildClassInfo_0();
case -1152623152: return bem_qGet_0();
case -1707345921: return bem_serializationIteratorGet_0();
case -1086639125: return bem_initialDecGet_0();
case 1656768820: return bem_inFilePathedGet_0();
case 845349245: return bem_methodsGet_0();
case 1777892480: return bem_nameToIdGet_0();
case -1354048135: return bem_buildInitial_0();
case -497405976: return bem_tagGet_0();
case 1171176103: return bem_msynGet_0();
case 1004554567: return bem_overrideMtdDecGet_0();
case 106472539: return bem_callNamesGet_0();
case 1293252554: return bem_mainOutsideNsGet_0();
case -555444736: return bem_lastMethodsLinesGet_0();
case 1351582760: return bem_spropDecGet_0();
case 1480101904: return bem_idToNameGet_0();
case 1337430873: return bem_ccCacheGet_0();
case 582951904: return bem_endNs_0();
case 1590744094: return bem_classEmitsGet_0();
case 1824306314: return bem_onceCountGet_0();
case 695648862: return bem_parentConfGet_0();
case 774012273: return bem_new_0();
case 687775088: return bem_nativeCSlotsGet_0();
case 1504304684: return bem_saveSyns_0();
case 1677158218: return bem_smnlecsGet_0();
case 779832114: return bem_maxDynArgsGet_0();
case 677808118: return bem_toString_0();
case 1030426151: return bem_getLibOutput_0();
case 535318578: return bem_classesInDepthOrderGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -527328154: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1136561958: return bem_lastMethodsLinesSet_1(bevd_0);
case -1329388071: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 869223348: return bem_smnlcsSet_1(bevd_0);
case 1427303825: return bem_fullLibEmitNameSet_1(bevd_0);
case -786885693: return bem_superCallsSet_1(bevd_0);
case 738019799: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1815986611: return bem_instOfSet_1(bevd_0);
case -971281910: return bem_end_1(bevd_0);
case -2086850593: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 2060264560: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 112458643: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -5184489: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -59866298: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1870423385: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1323112122: return bem_inFilePathedSet_1(bevd_0);
case -1178060129: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -545872466: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1040789320: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 248925202: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -234691942: return bem_fileExtSet_1(bevd_0);
case 1937929299: return bem_nullValueSet_1(bevd_0);
case 1434568333: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -20336869: return bem_ccCacheSet_1(bevd_0);
case -248970787: return bem_sameObject_1(bevd_0);
case -150125052: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1041309372: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1675320990: return bem_invpSet_1(bevd_0);
case 1438527302: return bem_preClassSet_1(bevd_0);
case 884591144: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1341656313: return bem_classEmitsSet_1(bevd_0);
case 68546191: return bem_csynSet_1(bevd_0);
case -945999966: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1176310149: return bem_instanceNotEqualSet_1(bevd_0);
case 810857845: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1504509345: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -24880307: return bem_instanceEqualSet_1(bevd_0);
case -784802870: return bem_randSet_1(bevd_0);
case -1908551743: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1730126997: return bem_def_1(bevd_0);
case 132614834: return bem_methodsSet_1(bevd_0);
case -415775033: return bem_exceptDecSet_1(bevd_0);
case 1729558346: return bem_ntypesSet_1(bevd_0);
case 1341307714: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -584803665: return bem_lastCallSet_1(bevd_0);
case 1885249201: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1493842410: return bem_begin_1(bevd_0);
case -1727272588: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -727637446: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1929091134: return bem_classConfSet_1(bevd_0);
case 582199000: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -147126263: return bem_cnodeSet_1(bevd_0);
case 727761583: return bem_boolCcSet_1(bevd_0);
case 277943443: return bem_returnTypeSet_1(bevd_0);
case -970121374: return bem_equals_1(bevd_0);
case 2012275656: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -842581355: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -837789845: return bem_qSet_1(bevd_0);
case -1143421621: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 410232788: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1649058984: return bem_sameType_1(bevd_0);
case 1092186617: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1851375535: return bem_libEmitNameSet_1(bevd_0);
case -741632140: return bem_lineCountSet_1(bevd_0);
case 1910844205: return bem_defined_1(bevd_0);
case 1747350255: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1846621749: return bem_libEmitPathSet_1(bevd_0);
case -585677451: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 970629013: return bem_constSet_1(bevd_0);
case 1297437914: return bem_synEmitPathSet_1(bevd_0);
case 1248878306: return bem_notEquals_1(bevd_0);
case 143397029: return bem_onceCountSet_1(bevd_0);
case -837642396: return bem_nameToIdSet_1(bevd_0);
case 2013235837: return bem_msynSet_1(bevd_0);
case 197557310: return bem_undef_1(bevd_0);
case 1348369813: return bem_callNamesSet_1(bevd_0);
case -453391559: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1655987378: return bem_classesInDepthOrderSet_1(bevd_0);
case 1158473690: return bem_parentConfSet_1(bevd_0);
case -1413329170: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 235341545: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1474632: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1486049215: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1268369889: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1316436217: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1013351049: return bem_otherClass_1(bevd_0);
case 1713737415: return bem_idToNameSet_1(bevd_0);
case -1155564258: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1597511697: return bem_objectNpSet_1(bevd_0);
case 999691213: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1032165379: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -2051001301: return bem_maxDynArgsSet_1(bevd_0);
case 529998379: return bem_scvpSet_1(bevd_0);
case 277416153: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1998346117: return bem_undefined_1(bevd_0);
case 252654077: return bem_nlSet_1(bevd_0);
case 1964439242: return bem_trueValueSet_1(bevd_0);
case 1672762678: return bem_onceDecsSet_1(bevd_0);
case 868614930: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1298783045: return bem_floatNpSet_1(bevd_0);
case 233621484: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1087152076: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -381537429: return bem_lastMethodsSizeSet_1(bevd_0);
case -1015181430: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -629843412: return bem_transSet_1(bevd_0);
case -1947909271: return bem_intNpSet_1(bevd_0);
case -177561964: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 120324159: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1968905722: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -497076681: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -331920617: return bem_stringNpSet_1(bevd_0);
case -1542443673: return bem_copyTo_1(bevd_0);
case -1533963422: return bem_classCallsSet_1(bevd_0);
case 1351185432: return bem_buildSet_1(bevd_0);
case -778163202: return bem_dynMethodsSet_1(bevd_0);
case -564232292: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -109022500: return bem_boolNpSet_1(bevd_0);
case -993376127: return bem_propertyDecsSet_1(bevd_0);
case -997148105: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -61960090: return bem_smnlecsSet_1(bevd_0);
case -1599156894: return bem_sameClass_1(bevd_0);
case 1672316804: return bem_objectCcSet_1(bevd_0);
case 313500780: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -399792683: return bem_methodBodySet_1(bevd_0);
case 1723737238: return bem_emitLangSet_1(bevd_0);
case 786034052: return bem_nativeCSlotsSet_1(bevd_0);
case 1736815823: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1434663825: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1133393159: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 507398372: return bem_methodCallsSet_1(bevd_0);
case -172772234: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 111523660: return bem_lastMethodBodySizeSet_1(bevd_0);
case -301336604: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1255401767: return bem_ccMethodsSet_1(bevd_0);
case 630839727: return bem_falseValueSet_1(bevd_0);
case -1883746791: return bem_otherType_1(bevd_0);
case 768162410: return bem_mnodeSet_1(bevd_0);
case 1093183463: return bem_methodCatchSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 354612611: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -2060133765: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 458777507: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -861964307: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -54986983: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1754203643: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -831651783: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1239513525: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2027846548: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -327105943: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1242062610: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1126803346: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 174369424: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 755484682: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 390308754: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1440576715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -53342175: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -383341402: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -586956151: return bem_writeOnceDecs_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 748538124: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1922422837: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1817345384: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1856263547: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 526259242: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 2004056102: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 975169817: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
