package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_17, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_22, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_24, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_26, 14));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_29, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_36, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_39, 9));
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 27 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(-2145436361);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_tmpany_phold = bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_tmpany_phold = bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 37 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1529906664);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 37 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-845898149);
if (bevl_firstmnsyn.bevi_bool) /* Line: 38 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39 */
 else  /* Line: 40 */ {
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 41 */
bevt_27_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 43 */
 else  /* Line: 37 */ {
break;
} /* Line: 37 */
} /* Line: 37 */
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 50 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1529906664);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(-845898149);
if (bevl_firstptsyn.bevi_bool) /* Line: 51 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52 */
 else  /* Line: 53 */ {
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 54 */
bevt_36_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 56 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_tmpany_phold = bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_tmpany_phold.bem_addValue_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_tmpany_phold);
bevl_tout.bemd_1(770248313, bevl_bet);
bevl_tout.bemd_0(836237170);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(784618553);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-755903458);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 90 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 103 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_tmpany_phold;
} /* Line: 104 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_tmpany_phold;
} /* Line: 111 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1284507729);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 81, 81, 81, 81, 86, 87, 88, 88, 89, 89, 90, 90, 92, 92, 92, 93, 99, 99, 99, 99, 99, 99, 103, 103, 103, 0, 0, 0, 104, 104, 106, 106, 110, 110, 110, 0, 0, 0, 111, 111, 113, 113, 117, 117, 121, 121, 121, 121, 121, 122, 122, 122, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 125, 129, 129, 129, 133, 133, 133, 133, 133, 133, 133, 137, 137, 141, 141, 145, 145, 145, 145};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {66, 67, 68, 69, 127, 128, 129, 130, 135, 136, 137, 138, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 163, 166, 168, 170, 173, 174, 176, 177, 178, 179, 185, 186, 187, 188, 189, 190, 191, 192, 193, 193, 196, 198, 200, 203, 204, 206, 207, 208, 209, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 280, 281, 282, 283, 284, 294, 295, 296, 297, 299, 300, 301, 302, 304, 305, 306, 307, 316, 317, 318, 319, 320, 321, 329, 334, 335, 337, 340, 344, 347, 348, 350, 351, 359, 364, 365, 367, 370, 374, 377, 378, 380, 381, 385, 386, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 435, 436, 437, 446, 447, 448, 449, 450, 451, 452, 456, 457, 461, 462, 468, 469, 470, 471};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 66
new 0 16 66
assign 1 17 67
new 0 17 67
assign 1 18 68
new 0 18 68
new 1 22 69
assign 1 26 127
classDirGet 0 26 127
assign 1 26 128
fileGet 0 26 128
assign 1 26 129
existsGet 0 26 129
assign 1 26 130
not 0 26 135
assign 1 27 136
classDirGet 0 27 136
assign 1 27 137
fileGet 0 27 137
makeDirs 0 27 138
assign 1 29 140
typePathGet 0 29 140
assign 1 29 141
fileGet 0 29 141
assign 1 29 142
writerGet 0 29 142
assign 1 29 143
open 0 29 143
assign 1 30 144
new 0 30 144
assign 1 31 145
new 0 31 145
addValue 1 31 146
assign 1 32 147
new 0 32 147
assign 1 32 148
addValue 1 32 148
assign 1 32 149
typeEmitNameGet 0 32 149
assign 1 32 150
addValue 1 32 150
assign 1 32 151
new 0 32 151
addValue 1 32 152
assign 1 33 153
new 0 33 153
assign 1 33 154
addValue 1 33 154
assign 1 33 155
typeEmitNameGet 0 33 155
assign 1 33 156
addValue 1 33 156
assign 1 33 157
new 0 33 157
addValue 1 33 158
assign 1 35 159
new 0 35 159
addValue 1 35 160
assign 1 36 161
new 0 36 161
assign 1 37 162
mtdListGet 0 37 162
assign 1 37 163
iteratorGet 0 0 163
assign 1 37 166
hasNextGet 0 37 166
assign 1 37 168
nextGet 0 37 168
assign 1 39 170
new 0 39 170
assign 1 41 173
new 0 41 173
addValue 1 41 174
assign 1 43 176
addValue 1 43 176
assign 1 43 177
nameGet 0 43 177
assign 1 43 178
addValue 1 43 178
addValue 1 43 179
assign 1 45 185
new 0 45 185
addValue 1 45 186
assign 1 46 187
new 0 46 187
addValue 1 46 188
assign 1 48 189
new 0 48 189
addValue 1 48 190
assign 1 49 191
new 0 49 191
assign 1 50 192
ptyListGet 0 50 192
assign 1 50 193
iteratorGet 0 0 193
assign 1 50 196
hasNextGet 0 50 196
assign 1 50 198
nextGet 0 50 198
assign 1 52 200
new 0 52 200
assign 1 54 203
new 0 54 203
addValue 1 54 204
assign 1 56 206
addValue 1 56 206
assign 1 56 207
nameGet 0 56 207
assign 1 56 208
addValue 1 56 208
addValue 1 56 209
assign 1 58 215
new 0 58 215
addValue 1 58 216
assign 1 60 217
new 0 60 217
addValue 1 60 218
assign 1 62 219
new 0 62 219
addValue 1 62 220
assign 1 63 221
new 0 63 221
assign 1 63 222
addValue 1 63 222
assign 1 63 223
emitNameGet 0 63 223
assign 1 63 224
addValue 1 63 224
assign 1 63 225
new 0 63 225
addValue 1 63 226
assign 1 64 227
new 0 64 227
addValue 1 64 228
assign 1 65 229
new 0 65 229
addValue 1 65 230
write 1 66 231
close 0 67 232
assign 1 71 253
new 0 71 253
assign 1 71 254
toString 0 71 254
assign 1 71 255
add 1 71 255
incrementValue 0 72 256
assign 1 73 257
new 0 73 257
assign 1 73 258
addValue 1 73 258
assign 1 73 259
addValue 1 73 259
assign 1 73 260
new 0 73 260
assign 1 73 261
addValue 1 73 261
addValue 1 73 262
assign 1 75 263
containedGet 0 75 263
assign 1 75 264
firstGet 0 75 264
assign 1 75 265
containedGet 0 75 265
assign 1 75 266
firstGet 0 75 266
assign 1 75 267
new 0 75 267
assign 1 75 268
add 1 75 268
assign 1 75 269
new 0 75 269
assign 1 75 270
add 1 75 270
assign 1 75 271
finalAssign 4 75 271
addValue 1 75 272
assign 1 81 280
new 0 81 280
assign 1 81 281
add 1 81 281
assign 1 81 282
new 0 81 282
assign 1 81 283
add 1 81 283
return 1 81 284
getInt 2 86 294
assign 1 87 295
toHexString 1 87 295
assign 1 88 296
new 0 88 296
assign 1 88 297
begins 1 88 297
assign 1 89 299
new 0 89 299
assign 1 89 300
substring 1 89 300
assign 1 90 301
new 0 90 301
addValue 1 90 302
assign 1 92 304
new 0 92 304
assign 1 92 305
once 0 92 305
addValue 1 92 306
addValue 1 93 307
assign 1 99 316
new 0 99 316
assign 1 99 317
add 1 99 317
assign 1 99 318
new 0 99 318
assign 1 99 319
add 1 99 319
assign 1 99 320
add 1 99 320
return 1 99 321
assign 1 103 329
def 1 103 334
assign 1 103 335
isFinalGet 0 103 335
assign 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 104 347
new 0 104 347
return 1 104 348
assign 1 106 350
new 0 106 350
return 1 106 351
assign 1 110 359
def 1 110 364
assign 1 110 365
isFinalGet 0 110 365
assign 1 0 367
assign 1 0 370
assign 1 0 374
assign 1 111 377
new 0 111 377
return 1 111 378
assign 1 113 380
new 0 113 380
return 1 113 381
assign 1 117 385
new 0 117 385
return 1 117 386
assign 1 121 408
new 0 121 408
assign 1 121 409
add 1 121 409
assign 1 121 410
new 0 121 410
assign 1 121 411
add 1 121 411
assign 1 121 412
add 1 121 412
assign 1 122 413
new 0 122 413
assign 1 122 414
addValue 1 122 414
assign 1 122 415
addValue 1 122 415
assign 1 122 416
new 0 122 416
assign 1 122 417
addValue 1 122 417
addValue 1 122 418
assign 1 123 419
new 0 123 419
assign 1 123 420
addValue 1 123 420
addValue 1 123 421
assign 1 124 422
new 0 124 422
assign 1 124 423
addValue 1 124 423
assign 1 124 424
outputPlatformGet 0 124 424
assign 1 124 425
nameGet 0 124 425
assign 1 124 426
addValue 1 124 426
assign 1 124 427
new 0 124 427
assign 1 124 428
addValue 1 124 428
addValue 1 124 429
return 1 125 430
assign 1 129 435
libNameGet 0 129 435
assign 1 129 436
beginNs 1 129 436
return 1 129 437
assign 1 133 446
new 0 133 446
assign 1 133 447
libNs 1 133 447
assign 1 133 448
add 1 133 448
assign 1 133 449
new 0 133 449
assign 1 133 450
add 1 133 450
assign 1 133 451
add 1 133 451
return 1 133 452
assign 1 137 456
getNameSpace 1 137 456
return 1 137 457
assign 1 141 461
new 0 141 461
return 1 141 462
assign 1 145 468
new 0 145 468
assign 1 145 469
once 0 145 469
assign 1 145 470
add 1 145 470
return 1 145 471
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1789593002: return bem_covariantReturnsGet_0();
case -1343071952: return bem_objectNpGetDirect_0();
case -753349704: return bem_methodCatchGetDirect_0();
case -1879407979: return bem_exceptDecGetDirect_0();
case -1481530003: return bem_msynGetDirect_0();
case 2107346127: return bem_intNpGet_0();
case -239036990: return bem_parentConfGetDirect_0();
case -1126078378: return bem_libEmitPathGet_0();
case -721019281: return bem_gcMarksGet_0();
case -1930501381: return bem_nativeCSlotsGet_0();
case 1221198176: return bem_invpGet_0();
case -1127001114: return bem_classConfGet_0();
case -1561539236: return bem_emitLib_0();
case -2090731148: return bem_mainStartGet_0();
case 1525639803: return bem_sourceFileNameGet_0();
case -189650229: return bem_emitLangGetDirect_0();
case 1430998361: return bem_serializationIteratorGet_0();
case 96503955: return bem_onceDecsGet_0();
case -701893840: return bem_exceptDecGet_0();
case -831283656: return bem_inClassGetDirect_0();
case -1267591601: return bem_dynMethodsGet_0();
case 2110123618: return bem_methodCallsGet_0();
case 1750900875: return bem_qGetDirect_0();
case -1229491884: return bem_superCallsGetDirect_0();
case -983124163: return bem_classCallsGetDirect_0();
case -2113260570: return bem_lastCallGetDirect_0();
case 364017019: return bem_useDynMethodsGet_0();
case 1167818197: return bem_propertyDecsGetDirect_0();
case -1968462388: return bem_newDecGet_0();
case 76102507: return bem_ntypesGet_0();
case 1818749741: return bem_libEmitNameGet_0();
case -1749928875: return bem_falseValueGet_0();
case 151169496: return bem_synEmitPathGetDirect_0();
case 477850373: return bem_initialDecGet_0();
case 653341959: return bem_print_0();
case -1154344801: return bem_afterCast_0();
case 1465793201: return bem_lastMethodBodySizeGetDirect_0();
case 1991411526: return bem_instanceNotEqualGet_0();
case 540928271: return bem_spropDecGet_0();
case -1301091886: return bem_constGet_0();
case -1154317113: return bem_scvpGetDirect_0();
case -256172309: return bem_propertyDecsGet_0();
case 1201799861: return bem_serializeToString_0();
case 2036147796: return bem_toString_0();
case 703171708: return bem_typeDecGet_0();
case 2021538698: return bem_smnlecsGetDirect_0();
case -1988137379: return bem_buildInitial_0();
case -1607181481: return bem_lineCountGetDirect_0();
case 820735986: return bem_floatNpGetDirect_0();
case 124966448: return bem_preClassGetDirect_0();
case 1702339863: return bem_baseMtdDecGet_0();
case 282644081: return bem_instanceNotEqualGetDirect_0();
case -905938943: return bem_boolCcGet_0();
case 1842922616: return bem_superCallsGet_0();
case 2124168322: return bem_classesInDepthOrderGetDirect_0();
case 1918631468: return bem_nameToIdGetDirect_0();
case -372006967: return bem_lastMethodBodyLinesGetDirect_0();
case -1499561935: return bem_maxSpillArgsLenGetDirect_0();
case -1169856790: return bem_preClassGet_0();
case -281008580: return bem_belslitsGet_0();
case 574045883: return bem_floatNpGet_0();
case 699081351: return bem_inFilePathedGetDirect_0();
case 1672904146: return bem_classEmitsGet_0();
case -1072121668: return bem_trueValueGet_0();
case 1602703848: return bem_lineCountGet_0();
case -32719865: return bem_boolNpGet_0();
case -2030451253: return bem_onceCountGetDirect_0();
case 1272845987: return bem_doEmit_0();
case 1884972604: return bem_fileExtGetDirect_0();
case 837130565: return bem_qGet_0();
case 2102651338: return bem_fieldIteratorGet_0();
case -921966256: return bem_inFilePathedGet_0();
case 1679915631: return bem_invpGetDirect_0();
case -1976480232: return bem_once_0();
case -256842229: return bem_mainOutsideNsGet_0();
case 1353268715: return bem_objectCcGet_0();
case -218032701: return bem_lastCallGet_0();
case -52300617: return bem_methodsGet_0();
case -2085024130: return bem_getLibOutput_0();
case -1439875774: return bem_new_0();
case -266805409: return bem_gcMarksGetDirect_0();
case -178903786: return bem_nameToIdPathGet_0();
case -130754471: return bem_cnodeGet_0();
case -1360338771: return bem_returnTypeGetDirect_0();
case 685379657: return bem_instOfGet_0();
case 856249940: return bem_buildCreate_0();
case 1398133031: return bem_saveIds_0();
case -1805409428: return bem_saveSyns_0();
case -576737050: return bem_endNs_0();
case 573647971: return bem_iteratorGet_0();
case -1500978633: return bem_tagGet_0();
case 1798714376: return bem_lastMethodsSizeGetDirect_0();
case -1896829134: return bem_getClassOutput_0();
case 1413833108: return bem_fileExtGet_0();
case 1188285097: return bem_transGetDirect_0();
case -329136550: return bem_stringNpGet_0();
case -1496832667: return bem_mainEndGet_0();
case -355582036: return bem_lastMethodsLinesGetDirect_0();
case -1737009900: return bem_many_0();
case -884323417: return bem_boolCcGetDirect_0();
case 1403826830: return bem_classEndGet_0();
case -399725753: return bem_nullValueGet_0();
case -320915487: return bem_randGetDirect_0();
case 1145277132: return bem_methodBodyGetDirect_0();
case 1631601431: return bem_falseValueGetDirect_0();
case -1143010507: return bem_baseSmtdDecGet_0();
case -398048564: return bem_csynGet_0();
case -901967678: return bem_boolNpGetDirect_0();
case 1203133510: return bem_methodCallsGetDirect_0();
case -955775186: return bem_stringNpGetDirect_0();
case 1577224610: return bem_classCallsGet_0();
case 1517870031: return bem_belslitsGetDirect_0();
case 1409252097: return bem_trueValueGetDirect_0();
case -1084845610: return bem_callNamesGetDirect_0();
case -992106683: return bem_callNamesGet_0();
case -935708492: return bem_classEmitsGetDirect_0();
case 980643754: return bem_inClassGet_0();
case 1677701730: return bem_ccCacheGetDirect_0();
case -436179246: return bem_onceCountGet_0();
case -1551806822: return bem_toAny_0();
case -1487636550: return bem_buildClassInfo_0();
case 745641805: return bem_libEmitNameGetDirect_0();
case -751906394: return bem_parentConfGet_0();
case -1748925107: return bem_echo_0();
case -440172566: return bem_csynGetDirect_0();
case -17089686: return bem_ccCacheGet_0();
case -1015805705: return bem_methodCatchGet_0();
case 1278581707: return bem_smnlcsGet_0();
case 1194752072: return bem_smnlcsGetDirect_0();
case 824958238: return bem_idToNameGet_0();
case -78002744: return bem_idToNamePathGetDirect_0();
case 1735899156: return bem_lastMethodBodySizeGet_0();
case 1851284713: return bem_intNpGetDirect_0();
case -286587052: return bem_methodBodyGet_0();
case 1870339225: return bem_libEmitPathGetDirect_0();
case -40713097: return bem_nameToIdGet_0();
case -2069481901: return bem_nameToIdPathGetDirect_0();
case -1489821550: return bem_mainInClassGet_0();
case 228530153: return bem_mnodeGet_0();
case 200584881: return bem_methodsGetDirect_0();
case -964022707: return bem_superNameGet_0();
case 1435219418: return bem_objectCcGetDirect_0();
case 1259519558: return bem_overrideMtdDecGet_0();
case 1494007739: return bem_instanceEqualGetDirect_0();
case 1392746832: return bem_cnodeGetDirect_0();
case -1357433736: return bem_ccMethodsGetDirect_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case 502543860: return bem_lastMethodsSizeGet_0();
case -2072472298: return bem_hashGet_0();
case 1980051232: return bem_randGet_0();
case -1434665554: return bem_runtimeInitGet_0();
case -1974667725: return bem_lastMethodBodyLinesGet_0();
case 843722789: return bem_classConfGetDirect_0();
case -1718364629: return bem_maxDynArgsGetDirect_0();
case -1218003683: return bem_nlGet_0();
case 338783801: return bem_instanceEqualGet_0();
case 281941226: return bem_nullValueGetDirect_0();
case -618039031: return bem_lastMethodsLinesGet_0();
case -1466334146: return bem_ccMethodsGet_0();
case -394712935: return bem_instOfGetDirect_0();
case 2746191: return bem_fullLibEmitNameGet_0();
case 1266643727: return bem_mnodeGetDirect_0();
case -171362156: return bem_maxDynArgsGet_0();
case -1011604363: return bem_onceDecsGetDirect_0();
case 1346885925: return bem_fullLibEmitNameGetDirect_0();
case -1195111829: return bem_create_0();
case -1066226610: return bem_fieldNamesGet_0();
case -1712541527: return bem_scvpGet_0();
case -114079936: return bem_serializeContents_0();
case 1443945356: return bem_preClassOutput_0();
case -501696984: return bem_propDecGet_0();
case 201123673: return bem_nativeCSlotsGetDirect_0();
case -836057376: return bem_maxSpillArgsLenGet_0();
case 1141430968: return bem_objectNpGet_0();
case -757890554: return bem_boolTypeGet_0();
case 298218513: return bem_ntypesGetDirect_0();
case -904680778: return bem_buildGetDirect_0();
case 1818425323: return bem_classesInDepthOrderGet_0();
case -1909224708: return bem_returnTypeGet_0();
case -246068216: return bem_synEmitPathGet_0();
case 1951297698: return bem_idToNamePathGet_0();
case -878179779: return bem_buildGet_0();
case 532047870: return bem_constGetDirect_0();
case 191896611: return bem_copy_0();
case 1013088935: return bem_loadIds_0();
case 1503006897: return bem_smnlecsGet_0();
case -421382413: return bem_idToNameGetDirect_0();
case -2102571971: return bem_dynMethodsGetDirect_0();
case 152968336: return bem_writeBET_0();
case -268634707: return bem_emitLangGet_0();
case -256870877: return bem_nlGetDirect_0();
case -1759630984: return bem_classNameGet_0();
case -90594128: return bem_transGet_0();
case 1950716125: return bem_msynGet_0();
case -105422382: return bem_beginNs_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 459759419: return bem_ccMethodsSet_1(bevd_0);
case -1873104258: return bem_methodCatchSet_1(bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case -98987572: return bem_end_1(bevd_0);
case -740252297: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -2026826253: return bem_objectNpSet_1(bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1852491781: return bem_intNpSet_1(bevd_0);
case -946835465: return bem_inFilePathedSet_1(bevd_0);
case -2107891516: return bem_trueValueSetDirect_1(bevd_0);
case -275057314: return bem_qSetDirect_1(bevd_0);
case 1854629241: return bem_randSet_1(bevd_0);
case 654795686: return bem_objectCcSet_1(bevd_0);
case 57366417: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -2046806314: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -264867820: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1219776855: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1863842331: return bem_instOfSetDirect_1(bevd_0);
case -1558483592: return bem_classEmitsSet_1(bevd_0);
case -343635918: return bem_constSet_1(bevd_0);
case -1146352342: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -813133516: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1725945273: return bem_ntypesSet_1(bevd_0);
case 1015064066: return bem_stringNpSet_1(bevd_0);
case -831799077: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -102295312: return bem_sameObject_1(bevd_0);
case 289073556: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1539136423: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1491477601: return bem_nameToIdPathSetDirect_1(bevd_0);
case -88128892: return bem_floatNpSet_1(bevd_0);
case 2004002995: return bem_parentConfSet_1(bevd_0);
case -479577022: return bem_propertyDecsSet_1(bevd_0);
case 662590206: return bem_classConfSet_1(bevd_0);
case -1293585518: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 287980432: return bem_synEmitPathSet_1(bevd_0);
case 901569307: return bem_nameToIdPathSet_1(bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case -1109448371: return bem_falseValueSetDirect_1(bevd_0);
case 1148228963: return bem_boolNpSetDirect_1(bevd_0);
case 257175245: return bem_idToNameSet_1(bevd_0);
case -1276836309: return bem_methodsSet_1(bevd_0);
case 1714272624: return bem_boolCcSetDirect_1(bevd_0);
case 2031215187: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 278239251: return bem_propertyDecsSetDirect_1(bevd_0);
case 93911718: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 414665430: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1053163201: return bem_fileExtSetDirect_1(bevd_0);
case -883072796: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -634684176: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case -947569950: return bem_fullLibEmitNameSet_1(bevd_0);
case 825141481: return bem_nullValueSetDirect_1(bevd_0);
case 1419871383: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 999469947: return bem_dynMethodsSetDirect_1(bevd_0);
case 1454668925: return bem_lineCountSetDirect_1(bevd_0);
case 1854583767: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -809187750: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1810557966: return bem_methodBodySet_1(bevd_0);
case -1508758513: return bem_buildSet_1(bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case -1947367963: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1542613256: return bem_scvpSetDirect_1(bevd_0);
case -109466617: return bem_callNamesSetDirect_1(bevd_0);
case 213162022: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 1898302667: return bem_nlSetDirect_1(bevd_0);
case 360757386: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1794862188: return bem_methodCallsSet_1(bevd_0);
case -195982894: return bem_libEmitNameSet_1(bevd_0);
case -1412746881: return bem_trueValueSet_1(bevd_0);
case -2096968766: return bem_callNamesSet_1(bevd_0);
case -1003318147: return bem_libEmitNameSetDirect_1(bevd_0);
case -1644493814: return bem_libEmitPathSet_1(bevd_0);
case -897648117: return bem_synEmitPathSetDirect_1(bevd_0);
case -1011557663: return bem_constSetDirect_1(bevd_0);
case 1153136910: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1763891254: return bem_msynSet_1(bevd_0);
case 75630506: return bem_parentConfSetDirect_1(bevd_0);
case 618012114: return bem_buildSetDirect_1(bevd_0);
case 1746804248: return bem_begin_1(bevd_0);
case 1600246925: return bem_instanceEqualSet_1(bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case -799256448: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1371101231: return bem_cnodeSetDirect_1(bevd_0);
case -444611263: return bem_emitLangSetDirect_1(bevd_0);
case -67154693: return bem_ccCacheSetDirect_1(bevd_0);
case 1752587062: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1732518107: return bem_gcMarksSet_1(bevd_0);
case -1430043058: return bem_mnodeSet_1(bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
case -806193983: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -361820289: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1139234739: return bem_idToNamePathSetDirect_1(bevd_0);
case -712903169: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -2071206471: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1280325706: return bem_smnlcsSetDirect_1(bevd_0);
case 514888203: return bem_nlSet_1(bevd_0);
case -1838817820: return bem_onceCountSet_1(bevd_0);
case 2119144855: return bem_floatNpSetDirect_1(bevd_0);
case -1337461771: return bem_classCallsSetDirect_1(bevd_0);
case 1691695497: return bem_onceDecsSet_1(bevd_0);
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1551197314: return bem_idToNamePathSet_1(bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
case -1452455521: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -1412732139: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
case -1327947995: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 611655703: return bem_randSetDirect_1(bevd_0);
case -1368497532: return bem_methodCallsSetDirect_1(bevd_0);
case 1090522896: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 411755123: return bem_superCallsSetDirect_1(bevd_0);
case -932777916: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -429213776: return bem_smnlecsSet_1(bevd_0);
case 364698209: return bem_boolCcSet_1(bevd_0);
case -1501766672: return bem_dynMethodsSet_1(bevd_0);
case 493336279: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 704461389: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1180524753: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1394582674: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 655789134: return bem_lastMethodsLinesSet_1(bevd_0);
case -1109701375: return bem_transSet_1(bevd_0);
case -594817566: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1568862008: return bem_instOfSet_1(bevd_0);
case -813463627: return bem_exceptDecSetDirect_1(bevd_0);
case -639856937: return bem_nameToIdSet_1(bevd_0);
case 1647467397: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 45139376: return bem_qSet_1(bevd_0);
case 846793220: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1323397153: return bem_onceDecsSetDirect_1(bevd_0);
case 92764541: return bem_returnTypeSetDirect_1(bevd_0);
case 506735351: return bem_classesInDepthOrderSet_1(bevd_0);
case 669175906: return bem_csynSet_1(bevd_0);
case -423440639: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 2076897761: return bem_nameToIdSetDirect_1(bevd_0);
case 541250355: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 4682191: return bem_boolNpSet_1(bevd_0);
case -1755840098: return bem_emitLangSet_1(bevd_0);
case 1970005509: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1587880985: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1774106450: return bem_preClassSet_1(bevd_0);
case -1904415135: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1965878133: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -2132544374: return bem_maxDynArgsSetDirect_1(bevd_0);
case -358851487: return bem_lastMethodsSizeSet_1(bevd_0);
case 91382750: return bem_ntypesSetDirect_1(bevd_0);
case 1083097722: return bem_ccCacheSet_1(bevd_0);
case -437935930: return bem_maxDynArgsSet_1(bevd_0);
case 1543499001: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -778629615: return bem_lastCallSetDirect_1(bevd_0);
case -944076679: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -2119425164: return bem_methodBodySetDirect_1(bevd_0);
case 958630235: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 884462515: return bem_def_1(bevd_0);
case 878876383: return bem_classEmitsSetDirect_1(bevd_0);
case -70429501: return bem_intNpSetDirect_1(bevd_0);
case 568057412: return bem_gcMarksSetDirect_1(bevd_0);
case 1013146664: return bem_methodCatchSetDirect_1(bevd_0);
case 1131914545: return bem_classCallsSet_1(bevd_0);
case 1973211926: return bem_msynSetDirect_1(bevd_0);
case 1673525387: return bem_idToNameSetDirect_1(bevd_0);
case -1470873170: return bem_csynSetDirect_1(bevd_0);
case 161506281: return bem_nativeCSlotsSet_1(bevd_0);
case -100706639: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -244472465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1011878557: return bem_objectNpSetDirect_1(bevd_0);
case -1458051895: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 557564066: return bem_returnTypeSet_1(bevd_0);
case 1468505584: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1718755240: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 753856265: return bem_onceCountSetDirect_1(bevd_0);
case 1965067879: return bem_belslitsSetDirect_1(bevd_0);
case 1666944420: return bem_cnodeSet_1(bevd_0);
case -107745525: return bem_lineCountSet_1(bevd_0);
case 498536426: return bem_invpSetDirect_1(bevd_0);
case 1309050162: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1402614323: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1704327802: return bem_inFilePathedSetDirect_1(bevd_0);
case -1760195436: return bem_falseValueSet_1(bevd_0);
case 170790194: return bem_objectCcSetDirect_1(bevd_0);
case -1508385747: return bem_classConfSetDirect_1(bevd_0);
case 1664039386: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1142015466: return bem_scvpSet_1(bevd_0);
case -2068576105: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -192271885: return bem_equals_1(bevd_0);
case -593912620: return bem_methodsSetDirect_1(bevd_0);
case -218301693: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1160208105: return bem_superCallsSet_1(bevd_0);
case 105390252: return bem_lastCallSet_1(bevd_0);
case 1468060517: return bem_invpSet_1(bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case 35221010: return bem_smnlecsSetDirect_1(bevd_0);
case -1288118404: return bem_exceptDecSet_1(bevd_0);
case 1138947652: return bem_transSetDirect_1(bevd_0);
case -1751215994: return bem_inClassSetDirect_1(bevd_0);
case -647412611: return bem_mnodeSetDirect_1(bevd_0);
case 1508932546: return bem_inClassSet_1(bevd_0);
case 1185279864: return bem_ccMethodsSetDirect_1(bevd_0);
case -1033090327: return bem_stringNpSetDirect_1(bevd_0);
case 183507390: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 1890461323: return bem_fileExtSet_1(bevd_0);
case -327875116: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1738987361: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 47222598: return bem_belslitsSet_1(bevd_0);
case -948837503: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -379443394: return bem_preClassSetDirect_1(bevd_0);
case 1350014525: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1567582613: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1485786532: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1201077197: return bem_libEmitPathSetDirect_1(bevd_0);
case 1637902388: return bem_nullValueSet_1(bevd_0);
case 365485749: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -2125915032: return bem_instanceEqualSetDirect_1(bevd_0);
case 266252568: return bem_instanceNotEqualSet_1(bevd_0);
case 1730652785: return bem_smnlcsSet_1(bevd_0);
case 763551924: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 628484851: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1849256042: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1377522817: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686251334: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 2165739: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1911371820: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2131581250: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -348914157: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -885279147: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 2036618192: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1858390115: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 971183197: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1215729437: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1154727345: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1256856387: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 196703174: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 126051419: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 56692196: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1340559363: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -2101094000: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
