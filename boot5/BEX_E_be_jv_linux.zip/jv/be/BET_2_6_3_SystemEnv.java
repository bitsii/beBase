package be;
public class BET_2_6_3_SystemEnv extends BETS_Object {
public BET_2_6_3_SystemEnv() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "set_2", "get_1", "getCached_1", "unset_1", "mapGet_0", "mapSet_1", "load_0", "default_0", "cwdGet_0", "workingDirectoryGet_0" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "map" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_3_SystemEnv();
}
}
