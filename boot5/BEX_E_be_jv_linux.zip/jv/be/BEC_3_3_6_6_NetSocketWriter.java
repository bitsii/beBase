package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketWriter extends BEC_2_2_6_IOWriter {
public BEC_3_3_6_6_NetSocketWriter() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketWriter_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_3_3_6_6_NetSocketWriter bece_BEC_3_3_6_6_NetSocketWriter_bevs_inst;

public static BET_3_3_6_6_NetSocketWriter bece_BEC_3_3_6_6_NetSocketWriter_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 908578243: return bem_many_0();
case 431722266: return bem_vfileGet_0();
case -1488617970: return bem_vfileGetDirect_0();
case -13815234: return bem_fieldNamesGet_0();
case 1201235982: return bem_once_0();
case 1513901137: return bem_print_0();
case -1033467316: return bem_sourceFileNameGet_0();
case -316667874: return bem_echo_0();
case -1755712449: return bem_fieldIteratorGet_0();
case 1675457753: return bem_extOpen_0();
case -1783183531: return bem_hashGet_0();
case 1576067193: return bem_isClosedGetDirect_0();
case -812156892: return bem_new_0();
case -5001660: return bem_copy_0();
case 1240185983: return bem_iteratorGet_0();
case -350111569: return bem_toString_0();
case 105965675: return bem_classNameGet_0();
case 1590189157: return bem_deserializeClassNameGet_0();
case -1584056237: return bem_tagGet_0();
case 78507900: return bem_serializeContents_0();
case -1132866570: return bem_isClosedGet_0();
case -926802099: return bem_serializationIteratorGet_0();
case 1058906403: return bem_serializeToString_0();
case 709853553: return bem_close_0();
case 218061815: return bem_create_0();
case 301454853: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1339800681: return bem_copyTo_1(bevd_0);
case 636080012: return bem_notEquals_1(bevd_0);
case 1501178892: return bem_equals_1(bevd_0);
case -529986203: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 109396788: return bem_vfileSetDirect_1(bevd_0);
case 1387309622: return bem_def_1(bevd_0);
case 522190896: return bem_defined_1(bevd_0);
case -422085315: return bem_isClosedSetDirect_1(bevd_0);
case -368171396: return bem_sameObject_1(bevd_0);
case -1485470295: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -300868177: return bem_undefined_1(bevd_0);
case 491086488: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -671327234: return bem_vfileSet_1(bevd_0);
case 315291080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -367405429: return bem_otherType_1(bevd_0);
case 1801644657: return bem_undef_1(bevd_0);
case 875182251: return bem_otherClass_1(bevd_0);
case -1051591650: return bem_isClosedSet_1(bevd_0);
case -1486270803: return bem_sameClass_1(bevd_0);
case -1009173585: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 658666820: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 340348419: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736723624: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -894736335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -215779456: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1075456122: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -247437356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1773968373: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketWriter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketWriter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_6_NetSocketWriter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_6_NetSocketWriter.bece_BEC_3_3_6_6_NetSocketWriter_bevs_inst = (BEC_3_3_6_6_NetSocketWriter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_6_NetSocketWriter.bece_BEC_3_3_6_6_NetSocketWriter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_6_NetSocketWriter.bece_BEC_3_3_6_6_NetSocketWriter_bevs_type;
}
}
