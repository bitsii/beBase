package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x63,0x63,0x4E,0x6F,0x52,0x74,0x74,0x69};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x2A,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x63,0x63,0x53,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x66,0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x42,0x45,0x44,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x42,0x45,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x63,0x63,0x42,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x2C,0x20,0x67,0x63,0x5F,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 41*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 42*/
 else /* Line: 43*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 44*/
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_extends);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
if (bevp_parentConf == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_ta_ph = bevl_begin.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_libNameGet_0();
bevt_15_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_16_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
} /* Line: 53*/
 else /* Line: 54*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_20_ta_ph);
} /* Line: 59*/
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_22_ta_ph);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_24_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_25_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_23_ta_ph = bevt_24_ta_ph.bem_has_1(bevt_25_ta_ph);
if (!(bevt_23_ta_ph.bevi_bool))/* Line: 74*/ {
bevt_26_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_27_ta_ph);
} /* Line: 76*/
bevt_28_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_28_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_34_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_34_ta_ph);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_36_ta_ph = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_36_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_37_ta_ph);
bevp_heow.bem_write_1(bevt_29_ta_ph);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 85*/ {
bevt_46_ta_ph = (new BEC_2_4_6_TextString(40, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_47_ta_ph);
} /* Line: 87*/
bevt_50_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevt_51_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_add_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevt_52_ta_ph);
bevp_heow.bem_write_1(bevt_48_ta_ph);
bevt_55_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_56_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_add_1(bevt_56_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bem_add_1(bevt_57_ta_ph);
bevp_deow.bem_write_1(bevt_53_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_58_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_7_ta_ph = bem_overrideMtdDecGet_0();
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_22_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-1843396272);
bevt_20_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_ta_ph );
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_relEmitName_1(bevt_23_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_26_ta_ph);
bevt_25_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevp_heow.bem_write_1(bevt_0_ta_ph);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_5_ta_ph = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_ta_ph = bevp_build.bem_libNameGet_0();
bevt_6_ta_ph = beva_returnType.bem_relEmitName_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_0_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_14_ta_ph = bevp_methods.bem_addValue_1(bevt_15_ta_ph);
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(beva_exceptDec);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_20_ta_ph = bevp_classHeadBody.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_22_ta_ph = beva_returnType.bem_relEmitName_1(bevt_23_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_mtdName);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_17_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevp_classHeadBody.bem_addValue_1(bevt_26_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_typenameGet_0();
bevt_2_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_ta_ph.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 142*/ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 143*/
 else /* Line: 142*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(1176098110);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(689573322, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 144*/ {
bevl_tcall = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
} /* Line: 145*/
 else /* Line: 142*/ {
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1176098110);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(689573322, bevt_10_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 146*/ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
} /* Line: 147*/
 else /* Line: 148*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_ta_ph );
} /* Line: 149*/
} /* Line: 142*/
} /* Line: 142*/
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1176098110);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(689573322, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 155*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevl_tcall = bevt_4_ta_ph.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 157*/
bevt_5_ta_ph = super.bem_formCallTarg_1(beva_node);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-274737415);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1561077498, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 167*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-741074223);
bevp_classHeaders.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 168*/
 else /* Line: 169*/ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 170*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_8_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevl_clh = bevt_4_ta_ph.bem_add_1(bevt_10_ta_ph);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_ta_ph = bevl_initialDec.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevl_bein);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_11_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_24_ta_ph = bevl_initialDec.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_32_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_21_ta_ph.bem_addValue_1(bevt_29_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1243490739);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-2087991173);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_8_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_v.bem_isTypedGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 201*/ {
bevt_4_ta_ph = bevp_build.bem_libNameGet_0();
bevt_3_ta_ph = bevp_objectCc.bem_relEmitName_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_b.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_2_ta_ph.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 202*/
 else /* Line: 203*/ {
bevt_9_ta_ph = beva_v.bem_namepathGet_0();
bevt_8_ta_ph = bem_getClassConfig_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = beva_b.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_6_ta_ph.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 204*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_0_ta_ph = beva_type.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 209*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 210*/
 else /* Line: 211*/ {
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 212*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 213*/
 else /* Line: 214*/ {
bevl_ccall = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
} /* Line: 215*/
} /* Line: 212*/
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_7_ta_ph = bevl_ccall.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_cc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevt_8_ta_ph = bem_overrideMtdDecGet_0();
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_bemBase);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_18_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_19_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_len);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(beva_belsBase);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_22_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_23_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-635948859);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 235*/
 else /* Line: 236*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-635948859);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 237*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-635948859);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 244*/
 else /* Line: 245*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-635948859);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 246*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_litArgs = bevt_0_ta_ph.bem_add_1(beva_sdec);
bevt_5_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 253*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_ta_ph = bevp_build.bem_libNameGet_0();
bevt_13_ta_ph = beva_newcc.bem_relEmitName_1(bevt_14_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = beva_newcc.bem_relEmitName_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_litArgs);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_7_ta_ph.bem_add_1(bevt_19_ta_ph);
} /* Line: 254*/
 else /* Line: 255*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_27_ta_ph = bevp_build.bem_libNameGet_0();
bevt_26_ta_ph = beva_newcc.bem_relEmitName_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_30_ta_ph = bevp_build.bem_libNameGet_0();
bevt_29_ta_ph = beva_newcc.bem_relEmitName_1(bevt_30_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_31_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevl_litArgs);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_20_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 256*/
return bevl_newCall;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_1_ta_ph = beva_typeName.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevp_setOutputTime = null;
bevt_1_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 305*/ {
bevt_5_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 305*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 305*/ {
return this;
} /* Line: 306*/
 else /* Line: 307*/ {
bevt_7_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevl_outts = bevt_6_ta_ph.bem_lastUpdatedGet_0();
bevt_9_ta_ph = bevp_inClass.bem_fromFileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-70563895);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bemd_0(1093717407);
bevt_10_ta_ph = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_ta_ph.bevi_bool)/* Line: 310*/ {
return this;
} /* Line: 313*/
bevp_setOutputTime = bevl_outts;
} /* Line: 316*/
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_1_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 321*/ {
bevt_1_ta_ph = bem_getLibOutput_0();
return bevt_1_ta_ph;
} /* Line: 322*/
bevt_2_ta_ph = super.bem_getClassOutput_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 328*/ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_1_ta_ph = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 331*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_2_4_IOFile bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 336*/ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_1_ta_ph = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_4_ta_ph = beva_cle.bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_fileGet_0();
bevt_3_ta_ph.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 344*/
} /* Line: 342*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) throws Throwable {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_7_ta_ph = bevl_bet.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(beva_mvn);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(beva_mvn);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevt_12_ta_ph = bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_14_ta_ph = bevl_bet.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 354*/
return bevl_bet;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_4_ContainerList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_9_4_ContainerList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
bevp_deow.bem_write_1(bevt_2_ta_ph);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = bevl_beh.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_ta_ph = bevl_beh.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevl_beh.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_beh.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevl_beh.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevl_beh.bem_addValue_1(bevt_19_ta_ph);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_23_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_22_ta_ph = bevl_bet.bem_addValue_1(bevt_23_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_25_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_20_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevl_bet.bem_addValue_1(bevt_27_ta_ph);
bevt_29_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (!(bevt_28_ta_ph.bevi_bool))/* Line: 374*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_31_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 376*/ {
bevt_32_ta_ph = bevt_0_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 376*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(-645349501);
if (bevl_firstmnsyn.bevi_bool)/* Line: 377*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 378*/
 else /* Line: 379*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevl_bet.bem_addValue_1(bevt_33_ta_ph);
} /* Line: 380*/
bevt_35_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_36_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_36_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 382*/
 else /* Line: 376*/ {
break;
} /* Line: 376*/
} /* Line: 376*/
} /* Line: 376*/
bevt_37_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevl_bet.bem_addValue_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_40_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_38_ta_ph = bevt_39_ta_ph.bem_has_1(bevt_40_ta_ph);
if (!(bevt_38_ta_ph.bevi_bool))/* Line: 387*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
} /* Line: 388*/
bevt_42_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 392*/ {
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_46_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_46_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 394*/ {
bevt_47_ta_ph = bevt_1_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 394*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(-645349501);
if (bevl_firstptsyn.bevi_bool)/* Line: 395*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 396*/
 else /* Line: 397*/ {
bevt_48_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevl_bet.bem_addValue_1(bevt_48_ta_ph);
} /* Line: 398*/
bevt_50_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_51_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_51_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 400*/
 else /* Line: 394*/ {
break;
} /* Line: 394*/
} /* Line: 394*/
} /* Line: 394*/
bevt_52_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevt_55_ta_ph = bevl_bet.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevt_54_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_60_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_61_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevt_59_ta_ph = bevt_60_ta_ph.bem_equals_1(bevt_61_ta_ph);
if (bevt_59_ta_ph.bevi_bool)/* Line: 408*/ {
bevt_64_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_63_ta_ph = bevl_bet.bem_addValue_1(bevt_64_ta_ph);
bevt_65_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_62_ta_ph = bevt_63_ta_ph.bem_addValue_1(bevt_65_ta_ph);
bevt_66_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_62_ta_ph.bem_addValue_1(bevt_66_ta_ph);
} /* Line: 409*/
 else /* Line: 410*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_68_ta_ph = bevl_bet.bem_addValue_1(bevt_69_ta_ph);
bevt_70_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bem_addValue_1(bevt_70_ta_ph);
bevt_71_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_67_ta_ph.bem_addValue_1(bevt_71_ta_ph);
} /* Line: 411*/
bevt_72_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_bet.bem_addValue_1(bevt_72_ta_ph);
bevt_75_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_74_ta_ph = bevl_bet.bem_addValue_1(bevt_75_ta_ph);
bevt_76_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_73_ta_ph = bevt_74_ta_ph.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevt_73_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevl_bet.bem_addValue_1(bevt_78_ta_ph);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_79_ta_ph = bem_genMark_1(bevt_80_ta_ph);
bevl_bet.bem_addValue_1(bevt_79_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_bet.bem_addValue_1(bevt_81_ta_ph);
bevt_82_ta_ph = bem_getClassOutput_0();
bevt_82_ta_ph.bem_write_1(bevl_bet);
bevt_83_ta_ph = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_83_ta_ph.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_2_4_IOFile bevt_20_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_2_4_IOFile bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_2_4_IOFile bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_31_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_45_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_56_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
if (bevp_deow == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 434*/ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_8_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_libName);
bevp_deon = bevt_4_ta_ph.bem_add_1(bevp_headExt);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_14_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevl_libName);
bevp_heon = bevt_10_ta_ph.bem_add_1(bevp_headExt);
bevt_16_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_ta_ph.bem_addStep_1(bevp_deon);
bevt_17_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_ta_ph.bem_addStep_1(bevp_heon);
bevt_21_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_existsGet_0();
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_23_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_fileGet_0();
bevt_22_ta_ph.bem_makeDirs_0();
} /* Line: 441*/
bevt_25_ta_ph = bevp_deop.bem_fileGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_ta_ph.bemd_0(566256852);
bevt_27_ta_ph = bevp_heop.bem_fileGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_ta_ph.bemd_0(566256852);
bevt_29_ta_ph = bevp_build.bem_paramsGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (bevt_28_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_32_ta_ph = bevp_build.bem_paramsGet_0();
bevt_33_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_31_ta_ph = bevt_32_ta_ph.bem_get_1(bevt_33_ta_ph);
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 448*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 448*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-645349501);
bevt_35_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_ta_ph.bem_fileGet_0();
bevt_37_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(566256852);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_ta_ph.bemd_0(1638235897);
bevt_38_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_38_ta_ph.bemd_0(1731603151);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 454*/
 else /* Line: 448*/ {
break;
} /* Line: 448*/
} /* Line: 448*/
} /* Line: 448*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevp_deow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_43_ta_ph = bevp_build.bem_paramsGet_0();
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_42_ta_ph = bevt_43_ta_ph.bem_has_1(bevt_44_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 468*/ {
bevt_46_ta_ph = bevp_build.bem_paramsGet_0();
bevt_47_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_45_ta_ph = bevt_46_ta_ph.bem_get_1(bevt_47_ta_ph);
bevt_1_ta_loop = bevt_45_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 470*/ {
bevt_48_ta_ph = bevt_1_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 470*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(-645349501);
bevt_49_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_49_ta_ph.bem_fileGet_0();
bevt_51_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bemd_0(566256852);
bevl_inc = (BEC_2_4_6_TextString) bevt_50_ta_ph.bemd_0(1638235897);
bevt_52_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_52_ta_ph.bemd_0(1731603151);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 476*/
 else /* Line: 470*/ {
break;
} /* Line: 470*/
} /* Line: 470*/
} /* Line: 470*/
bevt_54_ta_ph = bevp_build.bem_paramsGet_0();
bevt_55_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_53_ta_ph = bevt_54_ta_ph.bem_has_1(bevt_55_ta_ph);
if (bevt_53_ta_ph.bevi_bool)/* Line: 479*/ {
bevt_57_ta_ph = bevp_build.bem_paramsGet_0();
bevt_58_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_56_ta_ph = bevt_57_ta_ph.bem_get_1(bevt_58_ta_ph);
bevt_2_ta_loop = bevt_56_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 481*/ {
bevt_59_ta_ph = bevt_2_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 481*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(-645349501);
bevt_60_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_60_ta_ph.bem_fileGet_0();
bevt_62_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(566256852);
bevl_inc = (BEC_2_4_6_TextString) bevt_61_ta_ph.bemd_0(1638235897);
bevt_63_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_63_ta_ph.bemd_0(1731603151);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 487*/
 else /* Line: 481*/ {
break;
} /* Line: 481*/
} /* Line: 481*/
} /* Line: 481*/
} /* Line: 479*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_15_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_27_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
if (bevp_shlibe == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 500*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_existsGet_0();
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 502*/ {
bevt_8_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 503*/
bevt_10_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_ta_ph.bemd_0(566256852);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_shlibe.bem_write_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_paramsGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_12_ta_ph = bevt_13_ta_ph.bem_has_1(bevt_14_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 509*/ {
bevt_16_ta_ph = bevp_build.bem_paramsGet_0();
bevt_17_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_15_ta_ph = bevt_16_ta_ph.bem_get_1(bevt_17_ta_ph);
bevt_0_ta_loop = bevt_15_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 511*/ {
bevt_18_ta_ph = bevt_0_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 511*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-645349501);
bevt_19_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_ta_ph.bem_fileGet_0();
bevt_21_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(566256852);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_ta_ph.bemd_0(1638235897);
bevt_22_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_22_ta_ph.bemd_0(1731603151);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 517*/
 else /* Line: 511*/ {
break;
} /* Line: 511*/
} /* Line: 511*/
} /* Line: 511*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevp_shlibe.bem_write_1(bevt_23_ta_ph);
bevp_lineCount.bem_increment_0();
bevt_25_ta_ph = bevp_build.bem_paramsGet_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 523*/ {
bevt_28_ta_ph = bevp_build.bem_paramsGet_0();
bevt_29_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_27_ta_ph = bevt_28_ta_ph.bem_get_1(bevt_29_ta_ph);
bevt_1_ta_loop = bevt_27_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 524*/ {
bevt_30_ta_ph = bevt_1_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 524*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(-645349501);
bevt_31_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_ta_ph.bem_fileGet_0();
bevt_33_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(566256852);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_ta_ph.bemd_0(1638235897);
bevt_34_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_34_ta_ph.bemd_0(1731603151);
bevt_35_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 529*/
 else /* Line: 524*/ {
break;
} /* Line: 524*/
} /* Line: 524*/
} /* Line: 524*/
} /* Line: 523*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevp_heow.bem_write_1(bevt_1_ta_ph);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 547*/ {
bevl_mh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_5_ta_ph = bevl_mh.bem_addValue_1(bevt_6_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 550*/
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 571*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_4_ta_ph = beva_sdec.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 572*/
 else /* Line: 571*/ {
bevt_8_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_9_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_7_ta_ph = bevt_8_ta_ph.bem_has_1(bevt_9_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 573*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_11_ta_ph = beva_sdec.bem_addValue_1(bevt_12_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(beva_belsName);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_10_ta_ph.bem_addValue_1(bevt_13_ta_ph);
} /* Line: 574*/
} /* Line: 571*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(2142334966);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 586*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 586*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(-645349501);
if (bevl_first.bevi_bool)/* Line: 587*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 588*/
 else /* Line: 589*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevp_ccMethods.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 590*/
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_7_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 592*/
 else /* Line: 586*/ {
break;
} /* Line: 586*/
} /* Line: 586*/
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = bevl_initialDec.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_bein);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_4_ta_ph.bem_addValue_1(bevt_13_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
bevt_1_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_ta_ph.bem_relEmitName_1(bevt_2_ta_ph);
bevt_4_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-1843396272);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_ta_ph = bem_overrideMtdDecGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevl_oname);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_20_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_notEquals_1(bevl_oname);
if (bevt_19_ta_ph.bevi_bool)/* Line: 633*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_ta_ph, bevl_asnr);
} /* Line: 634*/
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_24_ta_ph = bevt_25_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevl_asnr);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_28_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_29_ta_ph);
bevt_28_ta_ph.bem_addValue_1(bevp_nl);
bevt_37_ta_ph = bem_overrideMtdDecGet_0();
bevt_36_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevl_oname);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevt_40_ta_ph);
bevt_31_ta_ph = bevt_32_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_30_ta_ph = bevt_31_ta_ph.bem_addValue_1(bevt_41_ta_ph);
bevt_30_ta_ph.bem_addValue_1(bevp_nl);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_44_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevl_stinst);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_47_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_48_ta_ph);
bevt_47_ta_ph.bem_addValue_1(bevp_nl);
bevt_55_ta_ph = bem_overrideMtdDecGet_0();
bevt_54_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_55_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_62_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(178977635);
if (bevt_61_ta_ph == null) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 653*/ {
bevt_65_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_64_ta_ph = bevt_65_ta_ph.bemd_0(178977635);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_1(689573322, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 653*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 653*/ {
bevt_67_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_66_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_67_ta_ph);
bevt_66_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 654*/
 else /* Line: 655*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_68_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_69_ta_ph);
bevt_68_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 656*/
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_70_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_71_ta_ph);
bevt_70_ta_ph.bem_addValue_1(bevp_nl);
bevt_78_ta_ph = bem_overrideMtdDecGet_0();
bevt_77_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_76_ta_ph = bevt_77_ta_ph.bem_addValue_1(bevt_79_ta_ph);
bevt_80_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bem_addValue_1(bevt_80_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevt_81_ta_ph);
bevt_73_ta_ph = bevt_74_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_72_ta_ph = bevt_73_ta_ph.bem_addValue_1(bevt_82_ta_ph);
bevt_72_ta_ph.bem_addValue_1(bevp_nl);
bevt_84_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_83_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_85_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_89_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_90_ta_ph);
bevt_91_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_88_ta_ph = bevt_89_ta_ph.bem_addValue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_87_ta_ph = bevt_88_ta_ph.bem_addValue_1(bevt_92_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_95_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_96_ta_ph);
bevt_94_ta_ph = bevt_95_ta_ph.bem_addValue_1(bevl_tinst);
bevt_97_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_93_ta_ph = bevt_94_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_98_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_99_ta_ph);
bevt_98_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_libEmitName);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_libEmitName);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevp_heow.bem_write_1(bevt_4_ta_ph);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 21, 22, 23, 27, 29, 30, 31, 32, 33, 37, 41, 41, 42, 42, 42, 44, 44, 46, 46, 46, 46, 46, 46, 48, 48, 49, 49, 51, 51, 53, 53, 53, 53, 53, 53, 53, 55, 55, 57, 57, 59, 59, 62, 62, 64, 64, 66, 68, 70, 72, 74, 74, 74, 75, 75, 76, 76, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 85, 86, 86, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 91, 91, 91, 91, 93, 93, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 100, 100, 100, 104, 106, 107, 108, 108, 109, 113, 113, 117, 117, 121, 121, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 128, 130, 130, 130, 130, 130, 130, 132, 132, 132, 132, 132, 132, 132, 132, 132, 132, 134, 136, 136, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 146, 146, 146, 146, 147, 149, 149, 151, 155, 155, 155, 155, 156, 156, 157, 159, 159, 163, 163, 163, 163, 163, 163, 163, 163, 167, 167, 167, 167, 168, 168, 168, 170, 176, 176, 176, 176, 176, 178, 178, 178, 178, 178, 178, 178, 178, 180, 182, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 188, 193, 193, 193, 194, 195, 195, 195, 195, 195, 195, 197, 197, 197, 197, 197, 197, 197, 197, 197, 197, 201, 201, 201, 202, 202, 202, 202, 202, 204, 204, 204, 204, 204, 204, 204, 209, 209, 210, 212, 212, 212, 213, 215, 218, 218, 218, 218, 218, 218, 218, 218, 223, 223, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 228, 228, 228, 228, 228, 228, 228, 228, 228, 230, 230, 230, 234, 234, 234, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 239, 243, 243, 243, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 248, 252, 252, 252, 252, 252, 253, 253, 253, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 258, 263, 264, 265, 265, 266, 272, 272, 272, 272, 276, 276, 280, 280, 285, 285, 289, 289, 293, 293, 297, 297, 297, 304, 305, 0, 305, 305, 305, 305, 305, 0, 0, 306, 308, 308, 308, 309, 309, 309, 310, 313, 316, 321, 322, 322, 324, 324, 328, 329, 330, 330, 331, 336, 338, 339, 339, 340, 341, 342, 342, 343, 343, 343, 344, 350, 351, 351, 351, 352, 352, 352, 352, 352, 352, 352, 352, 352, 353, 353, 353, 353, 354, 354, 354, 356, 360, 360, 360, 360, 360, 360, 361, 362, 362, 362, 362, 362, 362, 363, 363, 364, 364, 364, 364, 365, 365, 366, 366, 367, 367, 368, 368, 369, 371, 372, 372, 372, 372, 372, 372, 372, 372, 373, 373, 374, 374, 374, 375, 376, 376, 0, 376, 376, 378, 380, 380, 382, 382, 382, 382, 385, 385, 387, 387, 387, 388, 388, 391, 391, 392, 392, 392, 393, 394, 394, 0, 394, 394, 396, 398, 398, 400, 400, 400, 400, 403, 403, 405, 405, 407, 407, 407, 407, 407, 407, 408, 408, 408, 409, 409, 409, 409, 409, 409, 411, 411, 411, 411, 411, 411, 413, 413, 415, 415, 415, 415, 415, 415, 416, 416, 417, 417, 417, 418, 418, 421, 421, 422, 422, 434, 434, 435, 436, 436, 436, 436, 436, 436, 436, 437, 437, 437, 437, 437, 437, 437, 438, 438, 439, 439, 440, 440, 440, 440, 440, 441, 441, 441, 443, 443, 443, 444, 444, 444, 446, 446, 446, 448, 448, 448, 448, 0, 448, 448, 450, 450, 451, 451, 451, 452, 452, 454, 458, 458, 461, 461, 462, 462, 468, 468, 468, 470, 470, 470, 470, 0, 470, 470, 472, 472, 473, 473, 473, 474, 474, 476, 479, 479, 479, 481, 481, 481, 481, 0, 481, 481, 483, 483, 484, 484, 484, 485, 485, 487, 494, 495, 500, 500, 501, 502, 502, 502, 502, 502, 503, 503, 503, 505, 505, 505, 507, 507, 509, 509, 509, 511, 511, 511, 511, 0, 511, 511, 513, 513, 514, 514, 514, 515, 515, 517, 521, 521, 522, 523, 523, 523, 524, 524, 524, 524, 0, 524, 524, 525, 525, 526, 526, 526, 527, 527, 528, 528, 529, 535, 540, 541, 543, 543, 545, 545, 547, 547, 547, 548, 549, 549, 549, 550, 553, 554, 559, 559, 563, 563, 567, 567, 571, 571, 571, 572, 572, 572, 572, 572, 573, 573, 573, 574, 574, 574, 574, 574, 580, 580, 581, 583, 583, 583, 583, 585, 586, 0, 586, 586, 588, 590, 590, 592, 592, 592, 592, 592, 592, 596, 596, 596, 601, 603, 603, 603, 603, 603, 605, 605, 605, 605, 605, 605, 605, 605, 605, 605, 605, 607, 611, 611, 612, 612, 612, 612, 613, 617, 617, 618, 618, 618, 618, 619, 619, 619, 619, 623, 623, 623, 627, 627, 627, 628, 628, 628, 629, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 632, 633, 633, 634, 634, 637, 637, 637, 637, 637, 637, 637, 639, 639, 639, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 647, 647, 647, 647, 647, 647, 650, 650, 650, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 653, 653, 653, 653, 0, 653, 653, 653, 0, 0, 654, 654, 654, 656, 656, 656, 658, 659, 662, 662, 662, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 665, 665, 665, 667, 667, 667, 669, 671, 671, 671, 671, 671, 671, 671, 673, 673, 673, 673, 673, 673, 675, 675, 675, 681, 681, 681, 681, 681, 682, 682, 682, 682, 682, 684, 689, 689, 690, 690, 690, 690, 691, 691, 691, 691, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 185, 250, 255, 256, 257, 258, 261, 262, 264, 265, 266, 267, 268, 269, 270, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 289, 290, 291, 292, 293, 294, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 308, 309, 310, 311, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 339, 340, 341, 342, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 422, 423, 424, 425, 426, 427, 431, 432, 436, 437, 441, 442, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 521, 522, 523, 528, 529, 532, 533, 534, 535, 537, 540, 541, 542, 543, 545, 548, 549, 553, 563, 564, 565, 566, 568, 569, 570, 572, 573, 583, 584, 585, 586, 587, 588, 589, 590, 600, 601, 602, 603, 605, 606, 607, 610, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 747, 748, 753, 754, 755, 756, 757, 758, 761, 762, 763, 764, 765, 766, 767, 785, 786, 788, 791, 792, 793, 795, 798, 801, 802, 803, 804, 805, 806, 807, 808, 812, 813, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 904, 905, 906, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 943, 980, 981, 982, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1019, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1097, 1102, 1103, 1104, 1105, 1106, 1113, 1114, 1115, 1116, 1120, 1121, 1125, 1126, 1130, 1131, 1135, 1136, 1140, 1141, 1146, 1147, 1148, 1164, 1165, 1167, 1170, 1171, 1172, 1173, 1178, 1179, 1182, 1186, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1197, 1199, 1207, 1209, 1210, 1212, 1213, 1219, 1221, 1222, 1223, 1224, 1235, 1237, 1238, 1239, 1240, 1241, 1242, 1247, 1248, 1249, 1250, 1251, 1274, 1275, 1276, 1277, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293, 1294, 1296, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1432, 1433, 1434, 1434, 1437, 1439, 1441, 1444, 1445, 1447, 1448, 1449, 1450, 1457, 1458, 1459, 1460, 1461, 1463, 1464, 1466, 1467, 1468, 1469, 1470, 1472, 1473, 1474, 1474, 1477, 1479, 1481, 1484, 1485, 1487, 1488, 1489, 1490, 1497, 1498, 1499, 1500, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1511, 1512, 1513, 1514, 1515, 1516, 1519, 1520, 1521, 1522, 1523, 1524, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1616, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1649, 1650, 1651, 1652, 1654, 1655, 1656, 1657, 1658, 1659, 1660, 1661, 1662, 1664, 1665, 1666, 1667, 1667, 1670, 1672, 1673, 1674, 1675, 1676, 1677, 1678, 1679, 1680, 1687, 1688, 1689, 1690, 1691, 1692, 1693, 1694, 1695, 1697, 1698, 1699, 1700, 1700, 1703, 1705, 1706, 1707, 1708, 1709, 1710, 1711, 1712, 1713, 1720, 1721, 1722, 1724, 1725, 1726, 1727, 1727, 1730, 1732, 1733, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1751, 1752, 1795, 1800, 1801, 1802, 1803, 1804, 1805, 1810, 1811, 1812, 1813, 1815, 1816, 1817, 1818, 1819, 1820, 1821, 1822, 1824, 1825, 1826, 1827, 1827, 1830, 1832, 1833, 1834, 1835, 1836, 1837, 1838, 1839, 1840, 1847, 1848, 1849, 1850, 1851, 1852, 1854, 1855, 1856, 1857, 1857, 1860, 1862, 1863, 1864, 1865, 1866, 1867, 1868, 1869, 1870, 1871, 1872, 1880, 1891, 1892, 1893, 1894, 1895, 1896, 1897, 1898, 1899, 1901, 1902, 1903, 1904, 1905, 1907, 1908, 1913, 1914, 1918, 1919, 1924, 1925, 1943, 1944, 1945, 1947, 1948, 1949, 1950, 1951, 1954, 1955, 1956, 1958, 1959, 1960, 1961, 1962, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1994, 1997, 1999, 2001, 2004, 2005, 2007, 2008, 2009, 2010, 2011, 2012, 2018, 2019, 2020, 2040, 2041, 2042, 2043, 2044, 2045, 2046, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055, 2056, 2057, 2066, 2067, 2068, 2069, 2070, 2071, 2072, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2093, 2098, 2099, 2100, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2234, 2235, 2237, 2238, 2239, 2240, 2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2252, 2253, 2254, 2255, 2256, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268, 2269, 2270, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2283, 2288, 2289, 2292, 2293, 2294, 2296, 2299, 2303, 2304, 2305, 2308, 2309, 2310, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337, 2338, 2339, 2340, 2341, 2342, 2343, 2344, 2345, 2346, 2347, 2348, 2349, 2350, 2351, 2363, 2364, 2365, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2386, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2394, 2395, 2398, 2401, 2405, 2408, 2412, 2415, 2419, 2422, 2426, 2429, 2433, 2436, 2440, 2443, 2447, 2450, 2454, 2457, 2461, 2464, 2468, 2471};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 170
new 0 17 170
assign 1 18 171
new 0 18 171
assign 1 19 172
new 0 19 172
assign 1 21 173
new 0 21 173
assign 1 22 174
new 0 22 174
assign 1 23 175
new 0 23 175
new 1 27 176
assign 1 29 177
new 0 29 177
assign 1 30 178
new 0 30 178
assign 1 31 179
new 0 31 179
assign 1 32 180
new 0 32 180
assign 1 33 181
new 0 33 181
addValue 1 37 185
assign 1 41 250
def 1 41 255
assign 1 42 256
libNameGet 0 42 256
assign 1 42 257
relEmitName 1 42 257
assign 1 42 258
extend 1 42 258
assign 1 44 261
new 0 44 261
assign 1 44 262
extend 1 44 262
assign 1 46 264
new 0 46 264
assign 1 46 265
emitNameGet 0 46 265
assign 1 46 266
addValue 1 46 266
assign 1 46 267
addValue 1 46 267
assign 1 46 268
new 0 46 268
assign 1 46 269
addValue 1 46 269
assign 1 48 270
def 1 48 275
assign 1 49 276
new 0 49 276
addValue 1 49 277
assign 1 51 278
new 0 51 278
addValue 1 51 279
assign 1 53 280
new 0 53 280
assign 1 53 281
addValue 1 53 281
assign 1 53 282
libNameGet 0 53 282
assign 1 53 283
relEmitName 1 53 283
assign 1 53 284
addValue 1 53 284
assign 1 53 285
new 0 53 285
addValue 1 53 286
assign 1 55 289
new 0 55 289
addValue 1 55 290
assign 1 57 291
new 0 57 291
addValue 1 57 292
assign 1 59 293
new 0 59 293
addValue 1 59 294
assign 1 62 296
new 0 62 296
addValue 1 62 297
assign 1 64 298
new 0 64 298
addValue 1 64 299
write 1 66 300
write 1 68 301
write 1 70 302
clear 0 72 303
assign 1 74 304
emitChecksGet 0 74 304
assign 1 74 305
new 0 74 305
assign 1 74 306
has 1 74 306
assign 1 75 308
new 0 75 308
write 1 75 309
assign 1 76 310
new 0 76 310
write 1 76 311
assign 1 78 313
new 0 78 313
write 1 78 314
assign 1 79 315
new 0 79 315
assign 1 79 316
emitNameGet 0 79 316
assign 1 79 317
add 1 79 317
assign 1 79 318
new 0 79 318
assign 1 79 319
add 1 79 319
assign 1 79 320
getHeaderInitialInst 1 79 320
assign 1 79 321
add 1 79 321
assign 1 79 322
new 0 79 322
assign 1 79 323
add 1 79 323
write 1 79 324
assign 1 80 325
new 0 80 325
write 1 80 326
assign 1 81 327
new 0 81 327
write 1 81 328
assign 1 82 329
new 0 82 329
write 1 82 330
assign 1 83 331
new 0 83 331
write 1 83 332
assign 1 84 333
new 0 84 333
write 1 84 334
assign 1 85 335
emitChecksGet 0 85 335
assign 1 85 336
new 0 85 336
assign 1 85 337
has 1 85 337
assign 1 86 339
new 0 86 339
write 1 86 340
assign 1 87 341
new 0 87 341
write 1 87 342
assign 1 89 344
new 0 89 344
assign 1 89 345
emitNameGet 0 89 345
assign 1 89 346
add 1 89 346
assign 1 89 347
new 0 89 347
assign 1 89 348
add 1 89 348
write 1 89 349
assign 1 91 350
new 0 91 350
assign 1 91 351
emitNameGet 0 91 351
assign 1 91 352
add 1 91 352
assign 1 91 353
new 0 91 353
assign 1 91 354
add 1 91 354
write 1 91 355
assign 1 93 356
new 0 93 356
return 1 93 357
assign 1 97 387
overrideMtdDecGet 0 97 387
assign 1 97 388
addValue 1 97 388
assign 1 97 389
getClassConfig 1 97 389
assign 1 97 390
libNameGet 0 97 390
assign 1 97 391
relEmitName 1 97 391
assign 1 97 392
addValue 1 97 392
assign 1 97 393
new 0 97 393
assign 1 97 394
addValue 1 97 394
assign 1 97 395
emitNameGet 0 97 395
assign 1 97 396
addValue 1 97 396
assign 1 97 397
new 0 97 397
assign 1 97 398
addValue 1 97 398
assign 1 97 399
addValue 1 97 399
assign 1 97 400
new 0 97 400
assign 1 97 401
addValue 1 97 401
addValue 1 97 402
assign 1 98 403
new 0 98 403
assign 1 98 404
addValue 1 98 404
assign 1 98 405
heldGet 0 98 405
assign 1 98 406
namepathGet 0 98 406
assign 1 98 407
getClassConfig 1 98 407
assign 1 98 408
libNameGet 0 98 408
assign 1 98 409
relEmitName 1 98 409
assign 1 98 410
addValue 1 98 410
assign 1 98 411
new 0 98 411
assign 1 98 412
addValue 1 98 412
addValue 1 98 413
assign 1 100 414
new 0 100 414
assign 1 100 415
addValue 1 100 415
addValue 1 100 416
assign 1 104 422
new 0 104 422
write 1 106 423
clear 0 107 424
assign 1 108 425
new 0 108 425
write 1 108 426
return 1 109 427
assign 1 113 431
new 0 113 431
return 1 113 432
assign 1 117 436
new 0 117 436
return 1 117 437
assign 1 121 441
new 0 121 441
return 1 121 442
assign 1 126 472
addValue 1 126 472
assign 1 126 473
libNameGet 0 126 473
assign 1 126 474
relEmitName 1 126 474
assign 1 126 475
addValue 1 126 475
assign 1 126 476
new 0 126 476
assign 1 126 477
addValue 1 126 477
assign 1 126 478
emitNameGet 0 126 478
assign 1 126 479
addValue 1 126 479
assign 1 126 480
new 0 126 480
assign 1 126 481
addValue 1 126 481
assign 1 126 482
addValue 1 126 482
assign 1 126 483
new 0 126 483
addValue 1 126 484
addValue 1 128 485
assign 1 130 486
new 0 130 486
assign 1 130 487
addValue 1 130 487
assign 1 130 488
addValue 1 130 488
assign 1 130 489
new 0 130 489
assign 1 130 490
addValue 1 130 490
addValue 1 130 491
assign 1 132 492
new 0 132 492
assign 1 132 493
addValue 1 132 493
assign 1 132 494
libNameGet 0 132 494
assign 1 132 495
relEmitName 1 132 495
assign 1 132 496
addValue 1 132 496
assign 1 132 497
new 0 132 497
assign 1 132 498
addValue 1 132 498
assign 1 132 499
addValue 1 132 499
assign 1 132 500
new 0 132 500
addValue 1 132 501
addValue 1 134 502
assign 1 136 503
new 0 136 503
addValue 1 136 504
assign 1 142 521
typenameGet 0 142 521
assign 1 142 522
NULLGet 0 142 522
assign 1 142 523
equals 1 142 528
assign 1 143 529
new 0 143 529
assign 1 144 532
heldGet 0 144 532
assign 1 144 533
nameGet 0 144 533
assign 1 144 534
new 0 144 534
assign 1 144 535
equals 1 144 535
assign 1 145 537
new 0 145 537
assign 1 146 540
heldGet 0 146 540
assign 1 146 541
nameGet 0 146 541
assign 1 146 542
new 0 146 542
assign 1 146 543
equals 1 146 543
assign 1 147 545
new 0 147 545
assign 1 149 548
heldGet 0 149 548
assign 1 149 549
nameForVar 1 149 549
return 1 151 553
assign 1 155 563
heldGet 0 155 563
assign 1 155 564
nameGet 0 155 564
assign 1 155 565
new 0 155 565
assign 1 155 566
equals 1 155 566
assign 1 156 568
new 0 156 568
assign 1 156 569
add 1 156 569
return 1 157 570
assign 1 159 572
formCallTarg 1 159 572
return 1 159 573
assign 1 163 583
new 0 163 583
assign 1 163 584
addValue 1 163 584
assign 1 163 585
secondGet 0 163 585
assign 1 163 586
formTarg 1 163 586
assign 1 163 587
addValue 1 163 587
assign 1 163 588
new 0 163 588
assign 1 163 589
addValue 1 163 589
addValue 1 163 590
assign 1 167 600
heldGet 0 167 600
assign 1 167 601
langsGet 0 167 601
assign 1 167 602
new 0 167 602
assign 1 167 603
has 1 167 603
assign 1 168 605
heldGet 0 168 605
assign 1 168 606
textGet 0 168 606
addValue 1 168 607
handleClassEmit 1 170 610
assign 1 176 652
new 0 176 652
assign 1 176 653
emitNameGet 0 176 653
assign 1 176 654
add 1 176 654
assign 1 176 655
new 0 176 655
assign 1 176 656
add 1 176 656
assign 1 178 657
new 0 178 657
assign 1 178 658
typeEmitNameGet 0 178 658
assign 1 178 659
add 1 178 659
assign 1 178 660
new 0 178 660
assign 1 178 661
add 1 178 661
assign 1 178 662
add 1 178 662
assign 1 178 663
new 0 178 663
assign 1 178 664
add 1 178 664
addClassHeader 1 180 665
assign 1 182 666
new 0 182 666
assign 1 184 667
typeEmitNameGet 0 184 667
assign 1 184 668
addValue 1 184 668
assign 1 184 669
new 0 184 669
assign 1 184 670
addValue 1 184 670
assign 1 184 671
emitNameGet 0 184 671
assign 1 184 672
addValue 1 184 672
assign 1 184 673
new 0 184 673
assign 1 184 674
addValue 1 184 674
assign 1 184 675
addValue 1 184 675
assign 1 184 676
new 0 184 676
addValue 1 184 677
assign 1 186 678
new 0 186 678
assign 1 186 679
addValue 1 186 679
assign 1 186 680
typeEmitNameGet 0 186 680
assign 1 186 681
addValue 1 186 681
assign 1 186 682
new 0 186 682
assign 1 186 683
addValue 1 186 683
assign 1 186 684
emitNameGet 0 186 684
assign 1 186 685
addValue 1 186 685
assign 1 186 686
new 0 186 686
assign 1 186 687
emitNameGet 0 186 687
assign 1 186 688
add 1 186 688
assign 1 186 689
new 0 186 689
assign 1 186 690
add 1 186 690
addValue 1 186 691
return 1 188 692
assign 1 193 712
new 0 193 712
assign 1 193 713
toString 0 193 713
assign 1 193 714
add 1 193 714
incrementValue 0 194 715
assign 1 195 716
new 0 195 716
assign 1 195 717
addValue 1 195 717
assign 1 195 718
addValue 1 195 718
assign 1 195 719
new 0 195 719
assign 1 195 720
addValue 1 195 720
addValue 1 195 721
assign 1 197 722
containedGet 0 197 722
assign 1 197 723
firstGet 0 197 723
assign 1 197 724
containedGet 0 197 724
assign 1 197 725
firstGet 0 197 725
assign 1 197 726
new 0 197 726
assign 1 197 727
add 1 197 727
assign 1 197 728
new 0 197 728
assign 1 197 729
add 1 197 729
assign 1 197 730
finalAssign 4 197 730
addValue 1 197 731
assign 1 201 747
isTypedGet 0 201 747
assign 1 201 748
not 0 201 753
assign 1 202 754
libNameGet 0 202 754
assign 1 202 755
relEmitName 1 202 755
assign 1 202 756
addValue 1 202 756
assign 1 202 757
new 0 202 757
addValue 1 202 758
assign 1 204 761
namepathGet 0 204 761
assign 1 204 762
getClassConfig 1 204 762
assign 1 204 763
libNameGet 0 204 763
assign 1 204 764
relEmitName 1 204 764
assign 1 204 765
addValue 1 204 765
assign 1 204 766
new 0 204 766
addValue 1 204 767
assign 1 209 785
new 0 209 785
assign 1 209 786
equals 1 209 786
assign 1 210 788
new 0 210 788
assign 1 212 791
emitChecksGet 0 212 791
assign 1 212 792
new 0 212 792
assign 1 212 793
has 1 212 793
assign 1 213 795
new 0 213 795
assign 1 215 798
new 0 215 798
assign 1 218 801
new 0 218 801
assign 1 218 802
add 1 218 802
assign 1 218 803
libNameGet 0 218 803
assign 1 218 804
relEmitName 1 218 804
assign 1 218 805
add 1 218 805
assign 1 218 806
new 0 218 806
assign 1 218 807
add 1 218 807
return 1 218 808
assign 1 223 812
new 0 223 812
return 1 223 813
assign 1 227 840
overrideMtdDecGet 0 227 840
assign 1 227 841
addValue 1 227 841
assign 1 227 842
new 0 227 842
assign 1 227 843
addValue 1 227 843
assign 1 227 844
emitNameGet 0 227 844
assign 1 227 845
addValue 1 227 845
assign 1 227 846
new 0 227 846
assign 1 227 847
addValue 1 227 847
assign 1 227 848
addValue 1 227 848
assign 1 227 849
new 0 227 849
assign 1 227 850
addValue 1 227 850
assign 1 227 851
addValue 1 227 851
assign 1 227 852
new 0 227 852
assign 1 227 853
addValue 1 227 853
addValue 1 227 854
assign 1 228 855
new 0 228 855
assign 1 228 856
addValue 1 228 856
assign 1 228 857
addValue 1 228 857
assign 1 228 858
new 0 228 858
assign 1 228 859
addValue 1 228 859
assign 1 228 860
addValue 1 228 860
assign 1 228 861
new 0 228 861
assign 1 228 862
addValue 1 228 862
addValue 1 228 863
assign 1 230 864
new 0 230 864
assign 1 230 865
addValue 1 230 865
addValue 1 230 866
assign 1 234 904
emitChecksGet 0 234 904
assign 1 234 905
new 0 234 905
assign 1 234 906
has 1 234 906
assign 1 235 908
new 0 235 908
assign 1 235 909
libNameGet 0 235 909
assign 1 235 910
relEmitName 1 235 910
assign 1 235 911
add 1 235 911
assign 1 235 912
new 0 235 912
assign 1 235 913
add 1 235 913
assign 1 235 914
libNameGet 0 235 914
assign 1 235 915
relEmitName 1 235 915
assign 1 235 916
add 1 235 916
assign 1 235 917
new 0 235 917
assign 1 235 918
add 1 235 918
assign 1 235 919
heldGet 0 235 919
assign 1 235 920
literalValueGet 0 235 920
assign 1 235 921
add 1 235 921
assign 1 235 922
new 0 235 922
assign 1 235 923
add 1 235 923
assign 1 237 926
new 0 237 926
assign 1 237 927
libNameGet 0 237 927
assign 1 237 928
relEmitName 1 237 928
assign 1 237 929
add 1 237 929
assign 1 237 930
new 0 237 930
assign 1 237 931
add 1 237 931
assign 1 237 932
libNameGet 0 237 932
assign 1 237 933
relEmitName 1 237 933
assign 1 237 934
add 1 237 934
assign 1 237 935
new 0 237 935
assign 1 237 936
add 1 237 936
assign 1 237 937
heldGet 0 237 937
assign 1 237 938
literalValueGet 0 237 938
assign 1 237 939
add 1 237 939
assign 1 237 940
new 0 237 940
assign 1 237 941
add 1 237 941
return 1 239 943
assign 1 243 980
emitChecksGet 0 243 980
assign 1 243 981
new 0 243 981
assign 1 243 982
has 1 243 982
assign 1 244 984
new 0 244 984
assign 1 244 985
libNameGet 0 244 985
assign 1 244 986
relEmitName 1 244 986
assign 1 244 987
add 1 244 987
assign 1 244 988
new 0 244 988
assign 1 244 989
add 1 244 989
assign 1 244 990
libNameGet 0 244 990
assign 1 244 991
relEmitName 1 244 991
assign 1 244 992
add 1 244 992
assign 1 244 993
new 0 244 993
assign 1 244 994
add 1 244 994
assign 1 244 995
heldGet 0 244 995
assign 1 244 996
literalValueGet 0 244 996
assign 1 244 997
add 1 244 997
assign 1 244 998
new 0 244 998
assign 1 244 999
add 1 244 999
assign 1 246 1002
new 0 246 1002
assign 1 246 1003
libNameGet 0 246 1003
assign 1 246 1004
relEmitName 1 246 1004
assign 1 246 1005
add 1 246 1005
assign 1 246 1006
new 0 246 1006
assign 1 246 1007
add 1 246 1007
assign 1 246 1008
libNameGet 0 246 1008
assign 1 246 1009
relEmitName 1 246 1009
assign 1 246 1010
add 1 246 1010
assign 1 246 1011
new 0 246 1011
assign 1 246 1012
add 1 246 1012
assign 1 246 1013
heldGet 0 246 1013
assign 1 246 1014
literalValueGet 0 246 1014
assign 1 246 1015
add 1 246 1015
assign 1 246 1016
new 0 246 1016
assign 1 246 1017
add 1 246 1017
return 1 248 1019
assign 1 252 1057
new 0 252 1057
assign 1 252 1058
add 1 252 1058
assign 1 252 1059
new 0 252 1059
assign 1 252 1060
add 1 252 1060
assign 1 252 1061
add 1 252 1061
assign 1 253 1062
emitChecksGet 0 253 1062
assign 1 253 1063
new 0 253 1063
assign 1 253 1064
has 1 253 1064
assign 1 254 1066
new 0 254 1066
assign 1 254 1067
libNameGet 0 254 1067
assign 1 254 1068
relEmitName 1 254 1068
assign 1 254 1069
add 1 254 1069
assign 1 254 1070
new 0 254 1070
assign 1 254 1071
add 1 254 1071
assign 1 254 1072
libNameGet 0 254 1072
assign 1 254 1073
relEmitName 1 254 1073
assign 1 254 1074
add 1 254 1074
assign 1 254 1075
new 0 254 1075
assign 1 254 1076
add 1 254 1076
assign 1 254 1077
add 1 254 1077
assign 1 254 1078
new 0 254 1078
assign 1 254 1079
add 1 254 1079
assign 1 256 1082
new 0 256 1082
assign 1 256 1083
libNameGet 0 256 1083
assign 1 256 1084
relEmitName 1 256 1084
assign 1 256 1085
add 1 256 1085
assign 1 256 1086
new 0 256 1086
assign 1 256 1087
add 1 256 1087
assign 1 256 1088
libNameGet 0 256 1088
assign 1 256 1089
relEmitName 1 256 1089
assign 1 256 1090
add 1 256 1090
assign 1 256 1091
new 0 256 1091
assign 1 256 1092
add 1 256 1092
assign 1 256 1093
add 1 256 1093
assign 1 256 1094
new 0 256 1094
assign 1 256 1095
add 1 256 1095
return 1 258 1097
getCode 2 263 1102
assign 1 264 1103
toHexString 1 264 1103
assign 1 265 1104
new 0 265 1104
addValue 1 265 1105
addValue 1 266 1106
assign 1 272 1113
new 0 272 1113
assign 1 272 1114
add 1 272 1114
assign 1 272 1115
add 1 272 1115
return 1 272 1116
assign 1 276 1120
new 0 276 1120
return 1 276 1121
assign 1 280 1125
new 0 280 1125
return 1 280 1126
assign 1 285 1130
new 0 285 1130
return 1 285 1131
assign 1 289 1135
new 0 289 1135
return 1 289 1136
assign 1 293 1140
new 0 293 1140
return 1 293 1141
assign 1 297 1146
new 0 297 1146
assign 1 297 1147
add 1 297 1147
return 1 297 1148
assign 1 304 1164
assign 1 305 1165
singleCCGet 0 305 1165
assign 1 0 1167
assign 1 305 1170
classPathGet 0 305 1170
assign 1 305 1171
fileGet 0 305 1171
assign 1 305 1172
existsGet 0 305 1172
assign 1 305 1173
not 0 305 1178
assign 1 0 1179
assign 1 0 1182
return 1 306 1186
assign 1 308 1189
classPathGet 0 308 1189
assign 1 308 1190
fileGet 0 308 1190
assign 1 308 1191
lastUpdatedGet 0 308 1191
assign 1 309 1192
fromFileGet 0 309 1192
assign 1 309 1193
fileGet 0 309 1193
assign 1 309 1194
lastUpdatedGet 0 309 1194
assign 1 310 1195
greater 1 310 1195
return 1 313 1197
assign 1 316 1199
assign 1 321 1207
singleCCGet 0 321 1207
assign 1 322 1209
getLibOutput 0 322 1209
return 1 322 1210
assign 1 324 1212
getClassOutput 0 324 1212
return 1 324 1213
assign 1 328 1219
singleCCGet 0 328 1219
assign 1 329 1221
new 0 329 1221
assign 1 330 1222
countLines 1 330 1222
addValue 1 330 1223
write 1 331 1224
assign 1 336 1235
singleCCGet 0 336 1235
assign 1 338 1237
new 0 338 1237
assign 1 339 1238
countLines 1 339 1238
addValue 1 339 1239
write 1 340 1240
close 0 341 1241
assign 1 342 1242
def 1 342 1247
assign 1 343 1248
pathGet 0 343 1248
assign 1 343 1249
fileGet 0 343 1249
lastUpdatedSet 1 343 1250
assign 1 344 1251
assign 1 350 1274
new 0 350 1274
assign 1 351 1275
emitChecksGet 0 351 1275
assign 1 351 1276
new 0 351 1276
assign 1 351 1277
has 1 351 1277
assign 1 352 1279
new 0 352 1279
assign 1 352 1280
addValue 1 352 1280
assign 1 352 1281
addValue 1 352 1281
assign 1 352 1282
new 0 352 1282
assign 1 352 1283
addValue 1 352 1283
assign 1 352 1284
addValue 1 352 1284
assign 1 352 1285
new 0 352 1285
assign 1 352 1286
addValue 1 352 1286
addValue 1 352 1287
assign 1 353 1288
addValue 1 353 1288
assign 1 353 1289
new 0 353 1289
assign 1 353 1290
addValue 1 353 1290
addValue 1 353 1291
assign 1 354 1292
new 0 354 1292
assign 1 354 1293
addValue 1 354 1293
addValue 1 354 1294
return 1 356 1296
assign 1 360 1389
new 0 360 1389
assign 1 360 1390
typeEmitNameGet 0 360 1390
assign 1 360 1391
add 1 360 1391
assign 1 360 1392
new 0 360 1392
assign 1 360 1393
add 1 360 1393
write 1 360 1394
assign 1 361 1395
new 0 361 1395
assign 1 362 1396
new 0 362 1396
assign 1 362 1397
addValue 1 362 1397
assign 1 362 1398
typeEmitNameGet 0 362 1398
assign 1 362 1399
addValue 1 362 1399
assign 1 362 1400
new 0 362 1400
addValue 1 362 1401
assign 1 363 1402
new 0 363 1402
addValue 1 363 1403
assign 1 364 1404
typeEmitNameGet 0 364 1404
assign 1 364 1405
addValue 1 364 1405
assign 1 364 1406
new 0 364 1406
addValue 1 364 1407
assign 1 365 1408
new 0 365 1408
addValue 1 365 1409
assign 1 366 1410
new 0 366 1410
addValue 1 366 1411
assign 1 367 1412
new 0 367 1412
addValue 1 367 1413
assign 1 368 1414
new 0 368 1414
addValue 1 368 1415
write 1 369 1416
assign 1 371 1417
new 0 371 1417
assign 1 372 1418
typeEmitNameGet 0 372 1418
assign 1 372 1419
addValue 1 372 1419
assign 1 372 1420
new 0 372 1420
assign 1 372 1421
addValue 1 372 1421
assign 1 372 1422
typeEmitNameGet 0 372 1422
assign 1 372 1423
addValue 1 372 1423
assign 1 372 1424
new 0 372 1424
addValue 1 372 1425
assign 1 373 1426
new 0 373 1426
addValue 1 373 1427
assign 1 374 1428
emitChecksGet 0 374 1428
assign 1 374 1429
new 0 374 1429
assign 1 374 1430
has 1 374 1430
assign 1 375 1432
new 0 375 1432
assign 1 376 1433
mtdListGet 0 376 1433
assign 1 376 1434
iteratorGet 0 0 1434
assign 1 376 1437
hasNextGet 0 376 1437
assign 1 376 1439
nextGet 0 376 1439
assign 1 378 1441
new 0 378 1441
assign 1 380 1444
new 0 380 1444
addValue 1 380 1445
assign 1 382 1447
addValue 1 382 1447
assign 1 382 1448
nameGet 0 382 1448
assign 1 382 1449
addValue 1 382 1449
addValue 1 382 1450
assign 1 385 1457
new 0 385 1457
addValue 1 385 1458
assign 1 387 1459
emitChecksGet 0 387 1459
assign 1 387 1460
new 0 387 1460
assign 1 387 1461
has 1 387 1461
assign 1 388 1463
new 0 388 1463
addValue 1 388 1464
assign 1 391 1466
new 0 391 1466
addValue 1 391 1467
assign 1 392 1468
emitChecksGet 0 392 1468
assign 1 392 1469
new 0 392 1469
assign 1 392 1470
has 1 392 1470
assign 1 393 1472
new 0 393 1472
assign 1 394 1473
ptyListGet 0 394 1473
assign 1 394 1474
iteratorGet 0 0 1474
assign 1 394 1477
hasNextGet 0 394 1477
assign 1 394 1479
nextGet 0 394 1479
assign 1 396 1481
new 0 396 1481
assign 1 398 1484
new 0 398 1484
addValue 1 398 1485
assign 1 400 1487
addValue 1 400 1487
assign 1 400 1488
nameGet 0 400 1488
assign 1 400 1489
addValue 1 400 1489
addValue 1 400 1490
assign 1 403 1497
new 0 403 1497
addValue 1 403 1498
assign 1 405 1499
new 0 405 1499
addValue 1 405 1500
assign 1 407 1501
new 0 407 1501
assign 1 407 1502
addValue 1 407 1502
assign 1 407 1503
typeEmitNameGet 0 407 1503
assign 1 407 1504
addValue 1 407 1504
assign 1 407 1505
new 0 407 1505
addValue 1 407 1506
assign 1 408 1507
emitNameGet 0 408 1507
assign 1 408 1508
new 0 408 1508
assign 1 408 1509
equals 1 408 1509
assign 1 409 1511
new 0 409 1511
assign 1 409 1512
addValue 1 409 1512
assign 1 409 1513
emitNameGet 0 409 1513
assign 1 409 1514
addValue 1 409 1514
assign 1 409 1515
new 0 409 1515
addValue 1 409 1516
assign 1 411 1519
new 0 411 1519
assign 1 411 1520
addValue 1 411 1520
assign 1 411 1521
emitNameGet 0 411 1521
assign 1 411 1522
addValue 1 411 1522
assign 1 411 1523
new 0 411 1523
addValue 1 411 1524
assign 1 413 1526
new 0 413 1526
addValue 1 413 1527
assign 1 415 1528
new 0 415 1528
assign 1 415 1529
addValue 1 415 1529
assign 1 415 1530
typeEmitNameGet 0 415 1530
assign 1 415 1531
addValue 1 415 1531
assign 1 415 1532
new 0 415 1532
addValue 1 415 1533
assign 1 416 1534
new 0 416 1534
addValue 1 416 1535
assign 1 417 1536
new 0 417 1536
assign 1 417 1537
genMark 1 417 1537
addValue 1 417 1538
assign 1 418 1539
new 0 418 1539
addValue 1 418 1540
assign 1 421 1541
getClassOutput 0 421 1541
write 1 421 1542
assign 1 422 1543
countLines 1 422 1543
addValue 1 422 1544
assign 1 434 1616
undef 1 434 1621
assign 1 435 1622
libNameGet 0 435 1622
assign 1 436 1623
new 0 436 1623
assign 1 436 1624
sizeGet 0 436 1624
assign 1 436 1625
add 1 436 1625
assign 1 436 1626
new 0 436 1626
assign 1 436 1627
add 1 436 1627
assign 1 436 1628
add 1 436 1628
assign 1 436 1629
add 1 436 1629
assign 1 437 1630
new 0 437 1630
assign 1 437 1631
sizeGet 0 437 1631
assign 1 437 1632
add 1 437 1632
assign 1 437 1633
new 0 437 1633
assign 1 437 1634
add 1 437 1634
assign 1 437 1635
add 1 437 1635
assign 1 437 1636
add 1 437 1636
assign 1 438 1637
parentGet 0 438 1637
assign 1 438 1638
addStep 1 438 1638
assign 1 439 1639
parentGet 0 439 1639
assign 1 439 1640
addStep 1 439 1640
assign 1 440 1641
parentGet 0 440 1641
assign 1 440 1642
fileGet 0 440 1642
assign 1 440 1643
existsGet 0 440 1643
assign 1 440 1644
not 0 440 1649
assign 1 441 1650
parentGet 0 441 1650
assign 1 441 1651
fileGet 0 441 1651
makeDirs 0 441 1652
assign 1 443 1654
fileGet 0 443 1654
assign 1 443 1655
writerGet 0 443 1655
assign 1 443 1656
open 0 443 1656
assign 1 444 1657
fileGet 0 444 1657
assign 1 444 1658
writerGet 0 444 1658
assign 1 444 1659
open 0 444 1659
assign 1 446 1660
paramsGet 0 446 1660
assign 1 446 1661
new 0 446 1661
assign 1 446 1662
has 1 446 1662
assign 1 448 1664
paramsGet 0 448 1664
assign 1 448 1665
new 0 448 1665
assign 1 448 1666
get 1 448 1666
assign 1 448 1667
iteratorGet 0 0 1667
assign 1 448 1670
hasNextGet 0 448 1670
assign 1 448 1672
nextGet 0 448 1672
assign 1 450 1673
apNew 1 450 1673
assign 1 450 1674
fileGet 0 450 1674
assign 1 451 1675
readerGet 0 451 1675
assign 1 451 1676
open 0 451 1676
assign 1 451 1677
readString 0 451 1677
assign 1 452 1678
readerGet 0 452 1678
close 0 452 1679
write 1 454 1680
assign 1 458 1687
new 0 458 1687
write 1 458 1688
assign 1 461 1689
new 0 461 1689
write 1 461 1690
assign 1 462 1691
new 0 462 1691
write 1 462 1692
assign 1 468 1693
paramsGet 0 468 1693
assign 1 468 1694
new 0 468 1694
assign 1 468 1695
has 1 468 1695
assign 1 470 1697
paramsGet 0 470 1697
assign 1 470 1698
new 0 470 1698
assign 1 470 1699
get 1 470 1699
assign 1 470 1700
iteratorGet 0 0 1700
assign 1 470 1703
hasNextGet 0 470 1703
assign 1 470 1705
nextGet 0 470 1705
assign 1 472 1706
apNew 1 472 1706
assign 1 472 1707
fileGet 0 472 1707
assign 1 473 1708
readerGet 0 473 1708
assign 1 473 1709
open 0 473 1709
assign 1 473 1710
readString 0 473 1710
assign 1 474 1711
readerGet 0 474 1711
close 0 474 1712
write 1 476 1713
assign 1 479 1720
paramsGet 0 479 1720
assign 1 479 1721
new 0 479 1721
assign 1 479 1722
has 1 479 1722
assign 1 481 1724
paramsGet 0 481 1724
assign 1 481 1725
new 0 481 1725
assign 1 481 1726
get 1 481 1726
assign 1 481 1727
iteratorGet 0 0 1727
assign 1 481 1730
hasNextGet 0 481 1730
assign 1 481 1732
nextGet 0 481 1732
assign 1 483 1733
apNew 1 483 1733
assign 1 483 1734
fileGet 0 483 1734
assign 1 484 1735
readerGet 0 484 1735
assign 1 484 1736
open 0 484 1736
assign 1 484 1737
readString 0 484 1737
assign 1 485 1738
readerGet 0 485 1738
close 0 485 1739
write 1 487 1740
begin 1 494 1751
prepHeaderOutput 0 495 1752
assign 1 500 1795
undef 1 500 1800
assign 1 501 1801
new 0 501 1801
assign 1 502 1802
parentGet 0 502 1802
assign 1 502 1803
fileGet 0 502 1803
assign 1 502 1804
existsGet 0 502 1804
assign 1 502 1805
not 0 502 1810
assign 1 503 1811
parentGet 0 503 1811
assign 1 503 1812
fileGet 0 503 1812
makeDirs 0 503 1813
assign 1 505 1815
fileGet 0 505 1815
assign 1 505 1816
writerGet 0 505 1816
assign 1 505 1817
open 0 505 1817
assign 1 507 1818
new 0 507 1818
write 1 507 1819
assign 1 509 1820
paramsGet 0 509 1820
assign 1 509 1821
new 0 509 1821
assign 1 509 1822
has 1 509 1822
assign 1 511 1824
paramsGet 0 511 1824
assign 1 511 1825
new 0 511 1825
assign 1 511 1826
get 1 511 1826
assign 1 511 1827
iteratorGet 0 0 1827
assign 1 511 1830
hasNextGet 0 511 1830
assign 1 511 1832
nextGet 0 511 1832
assign 1 513 1833
apNew 1 513 1833
assign 1 513 1834
fileGet 0 513 1834
assign 1 514 1835
readerGet 0 514 1835
assign 1 514 1836
open 0 514 1836
assign 1 514 1837
readString 0 514 1837
assign 1 515 1838
readerGet 0 515 1838
close 0 515 1839
write 1 517 1840
assign 1 521 1847
new 0 521 1847
write 1 521 1848
increment 0 522 1849
assign 1 523 1850
paramsGet 0 523 1850
assign 1 523 1851
new 0 523 1851
assign 1 523 1852
has 1 523 1852
assign 1 524 1854
paramsGet 0 524 1854
assign 1 524 1855
new 0 524 1855
assign 1 524 1856
get 1 524 1856
assign 1 524 1857
iteratorGet 0 0 1857
assign 1 524 1860
hasNextGet 0 524 1860
assign 1 524 1862
nextGet 0 524 1862
assign 1 525 1863
apNew 1 525 1863
assign 1 525 1864
fileGet 0 525 1864
assign 1 526 1865
readerGet 0 526 1865
assign 1 526 1866
open 0 526 1866
assign 1 526 1867
readString 0 526 1867
assign 1 527 1868
readerGet 0 527 1868
close 0 527 1869
assign 1 528 1870
countLines 1 528 1870
addValue 1 528 1871
write 1 529 1872
return 1 535 1880
close 0 540 1891
assign 1 541 1892
assign 1 543 1893
new 0 543 1893
write 1 543 1894
assign 1 545 1895
new 0 545 1895
write 1 545 1896
assign 1 547 1897
emitChecksGet 0 547 1897
assign 1 547 1898
new 0 547 1898
assign 1 547 1899
has 1 547 1899
assign 1 548 1901
new 0 548 1901
assign 1 549 1902
new 0 549 1902
assign 1 549 1903
addValue 1 549 1903
addValue 1 549 1904
write 1 550 1905
close 0 553 1907
close 0 554 1908
assign 1 559 1913
new 0 559 1913
return 1 559 1914
assign 1 563 1918
new 0 563 1918
addValue 1 563 1919
assign 1 567 1924
new 0 567 1924
addValue 1 567 1925
assign 1 571 1943
emitChecksGet 0 571 1943
assign 1 571 1944
new 0 571 1944
assign 1 571 1945
has 1 571 1945
assign 1 572 1947
new 0 572 1947
assign 1 572 1948
addValue 1 572 1948
assign 1 572 1949
addValue 1 572 1949
assign 1 572 1950
new 0 572 1950
addValue 1 572 1951
assign 1 573 1954
emitChecksGet 0 573 1954
assign 1 573 1955
new 0 573 1955
assign 1 573 1956
has 1 573 1956
assign 1 574 1958
new 0 574 1958
assign 1 574 1959
addValue 1 574 1959
assign 1 574 1960
addValue 1 574 1960
assign 1 574 1961
new 0 574 1961
addValue 1 574 1962
assign 1 580 1986
heldGet 0 580 1986
assign 1 580 1987
synGet 0 580 1987
assign 1 581 1988
ptyListGet 0 581 1988
assign 1 583 1989
emitNameGet 0 583 1989
assign 1 583 1990
addValue 1 583 1990
assign 1 583 1991
new 0 583 1991
addValue 1 583 1992
assign 1 585 1993
new 0 585 1993
assign 1 586 1994
iteratorGet 0 0 1994
assign 1 586 1997
hasNextGet 0 586 1997
assign 1 586 1999
nextGet 0 586 1999
assign 1 588 2001
new 0 588 2001
assign 1 590 2004
new 0 590 2004
addValue 1 590 2005
assign 1 592 2007
addValue 1 592 2007
assign 1 592 2008
new 0 592 2008
assign 1 592 2009
addValue 1 592 2009
assign 1 592 2010
nameGet 0 592 2010
assign 1 592 2011
addValue 1 592 2011
addValue 1 592 2012
assign 1 596 2018
new 0 596 2018
assign 1 596 2019
addValue 1 596 2019
addValue 1 596 2020
assign 1 601 2040
new 0 601 2040
assign 1 603 2041
new 0 603 2041
assign 1 603 2042
emitNameGet 0 603 2042
assign 1 603 2043
add 1 603 2043
assign 1 603 2044
new 0 603 2044
assign 1 603 2045
add 1 603 2045
assign 1 605 2046
emitNameGet 0 605 2046
assign 1 605 2047
addValue 1 605 2047
assign 1 605 2048
new 0 605 2048
assign 1 605 2049
addValue 1 605 2049
assign 1 605 2050
emitNameGet 0 605 2050
assign 1 605 2051
addValue 1 605 2051
assign 1 605 2052
new 0 605 2052
assign 1 605 2053
addValue 1 605 2053
assign 1 605 2054
addValue 1 605 2054
assign 1 605 2055
new 0 605 2055
addValue 1 605 2056
return 1 607 2057
assign 1 611 2066
libNameGet 0 611 2066
assign 1 611 2067
relEmitName 1 611 2067
assign 1 612 2068
new 0 612 2068
assign 1 612 2069
add 1 612 2069
assign 1 612 2070
new 0 612 2070
assign 1 612 2071
add 1 612 2071
return 1 613 2072
assign 1 617 2084
libNameGet 0 617 2084
assign 1 617 2085
relEmitName 1 617 2085
assign 1 618 2086
new 0 618 2086
assign 1 618 2087
add 1 618 2087
assign 1 618 2088
new 0 618 2088
assign 1 618 2089
add 1 618 2089
assign 1 619 2090
new 0 619 2090
assign 1 619 2091
add 1 619 2091
assign 1 619 2092
add 1 619 2092
return 1 619 2093
assign 1 623 2098
new 0 623 2098
assign 1 623 2099
add 1 623 2099
return 1 623 2100
assign 1 627 2208
getClassConfig 1 627 2208
assign 1 627 2209
libNameGet 0 627 2209
assign 1 627 2210
relEmitName 1 627 2210
assign 1 628 2211
heldGet 0 628 2211
assign 1 628 2212
namepathGet 0 628 2212
assign 1 628 2213
getClassConfig 1 628 2213
assign 1 629 2214
getInitialInst 1 629 2214
assign 1 631 2215
overrideMtdDecGet 0 631 2215
assign 1 631 2216
addValue 1 631 2216
assign 1 631 2217
new 0 631 2217
assign 1 631 2218
addValue 1 631 2218
assign 1 631 2219
emitNameGet 0 631 2219
assign 1 631 2220
addValue 1 631 2220
assign 1 631 2221
new 0 631 2221
assign 1 631 2222
addValue 1 631 2222
assign 1 631 2223
addValue 1 631 2223
assign 1 631 2224
new 0 631 2224
assign 1 631 2225
addValue 1 631 2225
assign 1 631 2226
addValue 1 631 2226
assign 1 631 2227
new 0 631 2227
assign 1 631 2228
addValue 1 631 2228
addValue 1 631 2229
assign 1 632 2230
new 0 632 2230
assign 1 633 2231
emitNameGet 0 633 2231
assign 1 633 2232
notEquals 1 633 2232
assign 1 634 2234
new 0 634 2234
assign 1 634 2235
formCast 3 634 2235
assign 1 637 2237
addValue 1 637 2237
assign 1 637 2238
new 0 637 2238
assign 1 637 2239
addValue 1 637 2239
assign 1 637 2240
addValue 1 637 2240
assign 1 637 2241
new 0 637 2241
assign 1 637 2242
addValue 1 637 2242
addValue 1 637 2243
assign 1 639 2244
new 0 639 2244
assign 1 639 2245
addValue 1 639 2245
addValue 1 639 2246
assign 1 642 2247
overrideMtdDecGet 0 642 2247
assign 1 642 2248
addValue 1 642 2248
assign 1 642 2249
addValue 1 642 2249
assign 1 642 2250
new 0 642 2250
assign 1 642 2251
addValue 1 642 2251
assign 1 642 2252
emitNameGet 0 642 2252
assign 1 642 2253
addValue 1 642 2253
assign 1 642 2254
new 0 642 2254
assign 1 642 2255
addValue 1 642 2255
assign 1 642 2256
addValue 1 642 2256
assign 1 642 2257
new 0 642 2257
assign 1 642 2258
addValue 1 642 2258
addValue 1 642 2259
assign 1 647 2260
new 0 647 2260
assign 1 647 2261
addValue 1 647 2261
assign 1 647 2262
addValue 1 647 2262
assign 1 647 2263
new 0 647 2263
assign 1 647 2264
addValue 1 647 2264
addValue 1 647 2265
assign 1 650 2266
new 0 650 2266
assign 1 650 2267
addValue 1 650 2267
addValue 1 650 2268
assign 1 652 2269
overrideMtdDecGet 0 652 2269
assign 1 652 2270
addValue 1 652 2270
assign 1 652 2271
new 0 652 2271
assign 1 652 2272
addValue 1 652 2272
assign 1 652 2273
emitNameGet 0 652 2273
assign 1 652 2274
addValue 1 652 2274
assign 1 652 2275
new 0 652 2275
assign 1 652 2276
addValue 1 652 2276
assign 1 652 2277
addValue 1 652 2277
assign 1 652 2278
new 0 652 2278
assign 1 652 2279
addValue 1 652 2279
addValue 1 652 2280
assign 1 653 2281
heldGet 0 653 2281
assign 1 653 2282
extendsGet 0 653 2282
assign 1 653 2283
undef 1 653 2288
assign 1 0 2289
assign 1 653 2292
heldGet 0 653 2292
assign 1 653 2293
extendsGet 0 653 2293
assign 1 653 2294
equals 1 653 2294
assign 1 0 2296
assign 1 0 2299
assign 1 654 2303
new 0 654 2303
assign 1 654 2304
addValue 1 654 2304
addValue 1 654 2305
assign 1 656 2308
new 0 656 2308
assign 1 656 2309
addValue 1 656 2309
addValue 1 656 2310
addValue 1 658 2312
clear 0 659 2313
assign 1 662 2314
new 0 662 2314
assign 1 662 2315
addValue 1 662 2315
addValue 1 662 2316
assign 1 664 2317
overrideMtdDecGet 0 664 2317
assign 1 664 2318
addValue 1 664 2318
assign 1 664 2319
new 0 664 2319
assign 1 664 2320
addValue 1 664 2320
assign 1 664 2321
emitNameGet 0 664 2321
assign 1 664 2322
addValue 1 664 2322
assign 1 664 2323
new 0 664 2323
assign 1 664 2324
addValue 1 664 2324
assign 1 664 2325
addValue 1 664 2325
assign 1 664 2326
new 0 664 2326
assign 1 664 2327
addValue 1 664 2327
addValue 1 664 2328
assign 1 665 2329
new 0 665 2329
assign 1 665 2330
addValue 1 665 2330
addValue 1 665 2331
assign 1 667 2332
new 0 667 2332
assign 1 667 2333
addValue 1 667 2333
addValue 1 667 2334
assign 1 669 2335
getTypeInst 1 669 2335
assign 1 671 2336
new 0 671 2336
assign 1 671 2337
addValue 1 671 2337
assign 1 671 2338
emitNameGet 0 671 2338
assign 1 671 2339
addValue 1 671 2339
assign 1 671 2340
new 0 671 2340
assign 1 671 2341
addValue 1 671 2341
addValue 1 671 2342
assign 1 673 2343
new 0 673 2343
assign 1 673 2344
addValue 1 673 2344
assign 1 673 2345
addValue 1 673 2345
assign 1 673 2346
new 0 673 2346
assign 1 673 2347
addValue 1 673 2347
addValue 1 673 2348
assign 1 675 2349
new 0 675 2349
assign 1 675 2350
addValue 1 675 2350
addValue 1 675 2351
assign 1 681 2363
new 0 681 2363
assign 1 681 2364
add 1 681 2364
assign 1 681 2365
new 0 681 2365
assign 1 681 2366
add 1 681 2366
write 1 681 2367
assign 1 682 2368
new 0 682 2368
assign 1 682 2369
add 1 682 2369
assign 1 682 2370
new 0 682 2370
assign 1 682 2371
add 1 682 2371
write 1 682 2372
emitLib 0 684 2373
assign 1 689 2386
libNameGet 0 689 2386
assign 1 689 2387
relEmitName 1 689 2387
assign 1 690 2388
new 0 690 2388
assign 1 690 2389
add 1 690 2389
assign 1 690 2390
new 0 690 2390
assign 1 690 2391
add 1 690 2391
assign 1 691 2392
new 0 691 2392
assign 1 691 2393
add 1 691 2393
assign 1 691 2394
add 1 691 2394
return 1 691 2395
return 1 0 2398
assign 1 0 2401
return 1 0 2405
assign 1 0 2408
return 1 0 2412
assign 1 0 2415
return 1 0 2419
assign 1 0 2422
return 1 0 2426
assign 1 0 2429
return 1 0 2433
assign 1 0 2436
return 1 0 2440
assign 1 0 2443
return 1 0 2447
assign 1 0 2450
return 1 0 2454
assign 1 0 2457
return 1 0 2461
assign 1 0 2464
return 1 0 2468
assign 1 0 2471
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 323068348: return bem_inFilePathedGet_0();
case -1742872288: return bem_ntypesGet_0();
case 1139291279: return bem_ccMethodsGet_0();
case 1837821584: return bem_scvpGet_0();
case -1847862474: return bem_idToNamePathGet_0();
case 1373485542: return bem_dynMethodsGet_0();
case -697615483: return bem_fileExtGet_0();
case -817816717: return bem_preClassGet_0();
case 2062134685: return bem_ccCacheGet_0();
case -1850181517: return bem_lastMethodBodyLinesGet_0();
case 168865628: return bem_cnodeGet_0();
case -1470497874: return bem_buildInitial_0();
case 172705043: return bem_propDecGet_0();
case -1571276036: return bem_libEmitNameGet_0();
case -1048960358: return bem_randGet_0();
case -191146645: return bem_classCallsGet_0();
case -2140336148: return bem_classHeadersGet_0();
case -1869109136: return bem_classNameGet_0();
case -1408678963: return bem_qGet_0();
case 1145147302: return bem_intNpGet_0();
case -1848481770: return bem_getLibOutput_0();
case 1904654942: return bem_fullLibEmitNameGet_0();
case -1334177629: return bem_buildClassInfo_0();
case -1709553061: return bem_classConfGet_0();
case 881000385: return bem_parentConfGet_0();
case 795779294: return bem_emitLangGet_0();
case 642171726: return bem_mainEndGet_0();
case -175001067: return bem_exceptDecGet_0();
case 1834691664: return bem_methodCatchGet_0();
case -66437749: return bem_msynGet_0();
case 989314328: return bem_shlibeGet_0();
case 345869211: return bem_belslitsGet_0();
case -1546872974: return bem_loadIds_0();
case -1650622151: return bem_iteratorGet_0();
case 1588167742: return bem_emitLib_0();
case -1544307906: return bem_tagGet_0();
case 635923837: return bem_idToNameGet_0();
case -89687002: return bem_synEmitPathGet_0();
case -1758257394: return bem_useDynMethodsGet_0();
case -1406793129: return bem_print_0();
case -723673529: return bem_headExtGet_0();
case -1339651028: return bem_onceDecsGet_0();
case 278188316: return bem_writeBET_0();
case -833760748: return bem_inClassGet_0();
case -1251096321: return bem_libEmitPathGet_0();
case -1728344528: return bem_superNameGet_0();
case -403978956: return bem_typeDecGet_0();
case 1448836649: return bem_deowGet_0();
case -515852788: return bem_methodCallsGet_0();
case 240137651: return bem_lastMethodsLinesGet_0();
case 851437340: return bem_buildPropList_0();
case -1473642952: return bem_instanceEqualGet_0();
case -456848568: return bem_spropDecGet_0();
case 1932389725: return bem_lastMethodBodySizeGet_0();
case 878283040: return bem_lastMethodsSizeGet_0();
case -310164539: return bem_endNs_0();
case -33118629: return bem_newDecGet_0();
case -1745199484: return bem_stringNpGet_0();
case -1702560668: return bem_nameToIdPathGet_0();
case 448161942: return bem_nlGet_0();
case 511554608: return bem_deonGet_0();
case 1674227993: return bem_smnlecsGet_0();
case -1612099627: return bem_nativeCSlotsGet_0();
case -1086420345: return bem_baseMtdDecGet_0();
case -1687589351: return bem_preClassOutput_0();
case 580779631: return bem_setOutputTimeGet_0();
case 1989627728: return bem_objectNpGet_0();
case 158540098: return bem_boolTypeGet_0();
case 1592590251: return bem_invpGet_0();
case 695970418: return bem_methodsGet_0();
case 1505629153: return bem_gcMarksGet_0();
case -1964316072: return bem_lineCountGet_0();
case -1744447963: return bem_toString_0();
case 1549133114: return bem_mainInClassGet_0();
case -472030254: return bem_classEndGet_0();
case -425701808: return bem_overrideMtdDecGet_0();
case -1063105140: return bem_create_0();
case -17851578: return bem_new_0();
case -46543645: return bem_trueValueGet_0();
case 1242623472: return bem_transGet_0();
case 945259559: return bem_classHeadBodyGet_0();
case -1433140825: return bem_returnTypeGet_0();
case 1593325911: return bem_baseSmtdDecGet_0();
case -1862849517: return bem_hashGet_0();
case -1363440214: return bem_mainOutsideNsGet_0();
case 929443055: return bem_covariantReturnsGet_0();
case -199935101: return bem_buildCreate_0();
case -964376567: return bem_copy_0();
case -213682365: return bem_afterCast_0();
case 482577178: return bem_boolCcGet_0();
case 1818128155: return bem_superCallsGet_0();
case 2116713115: return bem_objectCcGet_0();
case 14288677: return bem_falseValueGet_0();
case -1454184378: return bem_classesInDepthOrderGet_0();
case -207221462: return bem_heopGet_0();
case -1109746780: return bem_beginNs_0();
case 1062040967: return bem_propertyDecsGet_0();
case 288293896: return bem_mainStartGet_0();
case 1825933510: return bem_smnlcsGet_0();
case -107128798: return bem_maxSpillArgsLenGet_0();
case 422595026: return bem_classEmitsGet_0();
case 1090480344: return bem_nameToIdGet_0();
case -311875845: return bem_buildGet_0();
case 2093337972: return bem_instanceNotEqualGet_0();
case 906633671: return bem_nullValueGet_0();
case -1411549209: return bem_deopGet_0();
case -1749801974: return bem_initialDecGet_0();
case 551406596: return bem_heowGet_0();
case -1723014: return bem_lastCallGet_0();
case 2101865165: return bem_boolNpGet_0();
case -1037927164: return bem_heonGet_0();
case 53354778: return bem_runtimeInitGet_0();
case 321238180: return bem_saveSyns_0();
case -1022686241: return bem_instOfGet_0();
case 1475747178: return bem_doEmit_0();
case 1608567712: return bem_getClassOutput_0();
case 242112293: return bem_saveIds_0();
case 1188567291: return bem_prepHeaderOutput_0();
case 596301414: return bem_csynGet_0();
case -852344027: return bem_callNamesGet_0();
case 115446801: return bem_methodBodyGet_0();
case 1406718718: return bem_floatNpGet_0();
case 343642447: return bem_maxDynArgsGet_0();
case -1648781300: return bem_constGet_0();
case -601711211: return bem_mnodeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1416367906: return bem_classCallsSet_1(bevd_0);
case 1395141126: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -37992639: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1654561022: return bem_ccMethodsSet_1(bevd_0);
case 348006120: return bem_idToNameSet_1(bevd_0);
case -1608144688: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -795508194: return bem_ccCacheSet_1(bevd_0);
case 1276879168: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 898392770: return bem_classHeadersSet_1(bevd_0);
case -656704030: return bem_boolNpSet_1(bevd_0);
case -1392314400: return bem_preClassSet_1(bevd_0);
case 2133332413: return bem_heowSet_1(bevd_0);
case 1388679866: return bem_falseValueSet_1(bevd_0);
case -54815286: return bem_def_1(bevd_0);
case 1353899175: return bem_nameToIdSet_1(bevd_0);
case -1264751514: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -468123532: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1247985902: return bem_msynSet_1(bevd_0);
case -2030517412: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1050214746: return bem_inClassSet_1(bevd_0);
case -832567076: return bem_instanceEqualSet_1(bevd_0);
case 1551821899: return bem_headExtSet_1(bevd_0);
case 1772791794: return bem_scvpSet_1(bevd_0);
case -36191473: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1823618978: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -885602778: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1879509831: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1228336767: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 282846398: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1144148799: return bem_objectNpSet_1(bevd_0);
case -165218561: return bem_inFilePathedSet_1(bevd_0);
case -1639849794: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1476310369: return bem_methodCallsSet_1(bevd_0);
case -530409840: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 675470434: return bem_libEmitNameSet_1(bevd_0);
case 1700457382: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1024867767: return bem_buildSet_1(bevd_0);
case -24622357: return bem_mnodeSet_1(bevd_0);
case 689573322: return bem_equals_1(bevd_0);
case -662153228: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 240885009: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1957741454: return bem_propertyDecsSet_1(bevd_0);
case -1136750515: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 143433474: return bem_superCallsSet_1(bevd_0);
case -1217606941: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1063668189: return bem_begin_1(bevd_0);
case 1471540287: return bem_deowSet_1(bevd_0);
case 827390257: return bem_smnlcsSet_1(bevd_0);
case 576817025: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 537818088: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1067539483: return bem_nativeCSlotsSet_1(bevd_0);
case 581833555: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 716242869: return bem_heonSet_1(bevd_0);
case 1564316354: return bem_methodBodySet_1(bevd_0);
case 265532230: return bem_fileExtSet_1(bevd_0);
case -1159185985: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1832844782: return bem_sameObject_1(bevd_0);
case 295466991: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1687355188: return bem_nullValueSet_1(bevd_0);
case 371048183: return bem_notEquals_1(bevd_0);
case -1473913152: return bem_intNpSet_1(bevd_0);
case -1275993696: return bem_trueValueSet_1(bevd_0);
case 788808081: return bem_dynMethodsSet_1(bevd_0);
case 937061535: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -68581565: return bem_emitLangSet_1(bevd_0);
case -1264702012: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case -25632601: return bem_deonSet_1(bevd_0);
case 1497537928: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 2104045665: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -976779970: return bem_objectCcSet_1(bevd_0);
case 1260834106: return bem_classesInDepthOrderSet_1(bevd_0);
case -1219175542: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -841408467: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1635872230: return bem_fullLibEmitNameSet_1(bevd_0);
case -1185669536: return bem_shlibeSet_1(bevd_0);
case 904022707: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -518194617: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1113331744: return bem_end_1(bevd_0);
case 1344889814: return bem_belslitsSet_1(bevd_0);
case 979424094: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 202653656: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -255357934: return bem_libEmitPathSet_1(bevd_0);
case -1492086420: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 896469763: return bem_lineCountSet_1(bevd_0);
case 1675893608: return bem_stringNpSet_1(bevd_0);
case 1563061447: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1864225131: return bem_lastMethodsSizeSet_1(bevd_0);
case -2063195266: return bem_lastMethodsLinesSet_1(bevd_0);
case -669953607: return bem_boolCcSet_1(bevd_0);
case -2026467957: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -144466290: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1779131762: return bem_classEmitsSet_1(bevd_0);
case 516456619: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -634103428: return bem_constSet_1(bevd_0);
case -1949852077: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1720843255: return bem_onceDecsSet_1(bevd_0);
case -2042624892: return bem_heopSet_1(bevd_0);
case 951565983: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1854460739: return bem_exceptDecSet_1(bevd_0);
case -1364615440: return bem_maxDynArgsSet_1(bevd_0);
case -1472683674: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1427097082: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -18932262: return bem_callNamesSet_1(bevd_0);
case -248628898: return bem_idToNamePathSet_1(bevd_0);
case -233049509: return bem_gcMarksSet_1(bevd_0);
case 763307205: return bem_cnodeSet_1(bevd_0);
case -446873327: return bem_csynSet_1(bevd_0);
case -489749780: return bem_instanceNotEqualSet_1(bevd_0);
case -1368388934: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -2137312933: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1550634382: return bem_deopSet_1(bevd_0);
case -423813550: return bem_classConfSet_1(bevd_0);
case 891037512: return bem_methodsSet_1(bevd_0);
case 908143927: return bem_classHeadBodySet_1(bevd_0);
case -2118367234: return bem_synEmitPathSet_1(bevd_0);
case 1823194930: return bem_returnTypeSet_1(bevd_0);
case 1965712615: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1552025867: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1229613272: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 849009869: return bem_nlSet_1(bevd_0);
case 865270744: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -648945031: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1238330634: return bem_methodCatchSet_1(bevd_0);
case -1167175972: return bem_ntypesSet_1(bevd_0);
case 1276828005: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 612766762: return bem_smnlecsSet_1(bevd_0);
case -2048436917: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1498151318: return bem_parentConfSet_1(bevd_0);
case -708773480: return bem_transSet_1(bevd_0);
case -1151830135: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 77846106: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1420308135: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1150315870: return bem_invpSet_1(bevd_0);
case -1110515547: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -522694891: return bem_floatNpSet_1(bevd_0);
case -1700904402: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -790762626: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -1288094758: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1891229802: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 939987870: return bem_setOutputTimeSet_1(bevd_0);
case 2064436185: return bem_instOfSet_1(bevd_0);
case -1968666168: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1214965065: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -695475400: return bem_qSet_1(bevd_0);
case -1108957080: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1199291070: return bem_nameToIdPathSet_1(bevd_0);
case 938508311: return bem_lastCallSet_1(bevd_0);
case 1764708193: return bem_copyTo_1(bevd_0);
case -505487772: return bem_randSet_1(bevd_0);
case -1472504739: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 596089581: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1228807813: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -984363126: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1854901638: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -511862352: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1596076075: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1269110753: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -114648207: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -905239156: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1135788730: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523546720: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1650827610: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 655992945: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1121134228: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1178647801: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 144934315: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1426012566: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1682120256: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1164282049: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -617085642: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -934065273: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1823097484: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1779956490: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -87313812: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1450027329: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1556441013: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
