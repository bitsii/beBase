package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_24, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x2A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_26, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_33, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_34, 14));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_35, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_64, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_68, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_69, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_70, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_71, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_78, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_80, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_83, 28));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_84, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_87, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_90, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x2A,0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_91, 3));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_101, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_102, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_103, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_104, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_105, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_106, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_107, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_108, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_109, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_110, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_111, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_112, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_113, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_114, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_117, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x2A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_118, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_119, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_120, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_122, 19));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_123, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_131, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_139, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_140, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x5D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_159 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_160 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_161 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_162 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_163 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_164 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_164, 22));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_165 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_166 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_167 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_168 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_169 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_170 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_171 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_172 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_173 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_174 = {0x66,0x6F,0x72,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x69,0x20,0x3D,0x20,0x30,0x3B,0x20,0x69,0x20,0x3C,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x20,0x69,0x2B,0x2B,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_175 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x67,0x5F,0x6C,0x65,0x20,0x3D,0x20,0x2A,0x28,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B,0x69,0x5D,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_176 = {0x62,0x65,0x76,0x67,0x5F,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_177 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_178 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_179 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_180 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_181 = {0x5D,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_182 = {0x7D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_183 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_184 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_185 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_186 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_186, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_187 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_187, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_188 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_188, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_189 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_189, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_190 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_191 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_192 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_193 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_194 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_195 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_196 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_197 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_198 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_199 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_200 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_201 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_202 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_203 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_204 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_205 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_206 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_207 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_208 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_209 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_210 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_211 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_212 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_213 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_214 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_214, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_215 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_215, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_216 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_217 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_218 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_219 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_219, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_220 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_52 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_220, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_221 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_53 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_221, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_222 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_222, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_223 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_55 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_223, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_224 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_56 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_224, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_225 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_226 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_227 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_228 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_229 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_230 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_231 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_232 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_233 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_234 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_235 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_236 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_237 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_238 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_239 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_240 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_241 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_242 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_243 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_244 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_245 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_246 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_247 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_248 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_249 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_250 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_251 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_252 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_253 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_253, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_254 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_254, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_255 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_59 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_255, 2));
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_6_TextString bevp_onceDecRefs;
public BEC_2_4_3_MathInt bevp_onceDecRefsCount;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefs = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefsCount = (new BEC_2_4_3_MathInt(0));
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 45 */
 else  /* Line: 46 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 47 */
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
if (bevp_parentConf == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_tmpany_phold = bevl_begin.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 56 */
 else  /* Line: 57 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevl_begin.bem_addValue_1(bevt_20_tmpany_phold);
} /* Line: 62 */
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevl_begin.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevl_begin.bem_addValue_1(bevt_22_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevp_heow.bem_write_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevp_heow.bem_write_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_31_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevp_heow.bem_write_1(bevt_26_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_44_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevp_heow.bem_write_1(bevt_41_tmpany_phold);
bevt_48_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_49_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevt_50_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevt_50_tmpany_phold);
bevp_deow.bem_write_1(bevt_46_tmpany_phold);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
return bevt_51_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_7_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_6_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_17_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_22_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(592530042);
bevt_20_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_tmpany_phold );
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_25_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_26_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_0_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_14_tmpany_phold = bevp_methods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_20_tmpany_phold = bevp_classHeadBody.bem_addValue_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_22_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_17_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevp_classHeadBody.bem_addValue_1(bevt_26_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_tmpany_phold.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 140 */ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
} /* Line: 141 */
 else  /* Line: 140 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-391498004);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-39094467, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevl_tcall = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
} /* Line: 143 */
 else  /* Line: 140 */ {
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-391498004);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(-39094467, bevt_10_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 144 */ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
} /* Line: 145 */
 else  /* Line: 146 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_tmpany_phold );
} /* Line: 147 */
} /* Line: 140 */
} /* Line: 140 */
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-391498004);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-39094467, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevl_tcall = bevt_4_tmpany_phold.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 155 */
bevt_5_tmpany_phold = super.bem_formCallTarg_1(beva_node);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_2_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1882620798);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(674226173, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 165 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1901414044);
bevp_classHeaders.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 166 */
 else  /* Line: 167 */ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 168 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_8_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevl_clh = bevt_4_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_11_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_24_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_32_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1327301284);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1473587806);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_4_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = beva_b.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_2_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 200 */
 else  /* Line: 201 */ {
bevt_9_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_8_tmpany_phold = bem_getClassConfig_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_6_tmpany_phold = beva_b.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_6_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
} /* Line: 202 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
} /* Line: 208 */
 else  /* Line: 209 */ {
bevl_ccall = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
} /* Line: 210 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_18_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevt_22_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1673542536);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1673542536);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 236 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 237 */
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_20_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(beva_lisz);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_belsName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
return bevt_12_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevp_onceDecRefsCount.bevi_int++;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_notEmpty_1(bevp_onceDecRefs);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 244 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_onceDecRefs.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 245 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_3_tmpany_phold = bevp_onceDecRefs.bem_addValue_1(bevt_4_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(beva_anyName);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_typeName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-391498004);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_41;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
bevp_setOutputTime = null;
bevt_1_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 300 */ {
return this;
} /* Line: 301 */
 else  /* Line: 302 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevl_outts = bevt_6_tmpany_phold.bem_lastUpdatedGet_0();
bevt_9_tmpany_phold = bevp_inClass.bem_fromFileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1622593208);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bemd_0(239150254);
bevt_10_tmpany_phold = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 305 */ {
return this;
} /* Line: 308 */
bevp_setOutputTime = bevl_outts;
} /* Line: 311 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_1_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_1_tmpany_phold = bem_getLibOutput_0();
return bevt_1_tmpany_phold;
} /* Line: 317 */
bevt_2_tmpany_phold = super.bem_getClassOutput_0();
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 323 */ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 326 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 331 */ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 337 */ {
bevt_4_tmpany_phold = beva_cle.bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 339 */
} /* Line: 337 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) throws Throwable {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_4_tmpany_phold = bevl_bet.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_9_tmpany_phold = bevl_bet.bem_addValue_1(beva_mvn);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_11_tmpany_phold = bevl_bet.bem_addValue_1(bevt_12_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_bet;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_42;
bevt_5_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_43;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevp_deow.bem_write_1(bevt_2_tmpany_phold);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_8_tmpany_phold = bevl_beh.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevl_beh.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_tmpany_phold = bevl_beh.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevl_beh.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevl_beh.bem_addValue_1(bevt_17_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_19_tmpany_phold = bevl_beh.bem_addValue_1(bevt_20_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_18_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevl_beh.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevl_beh.bem_addValue_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_151));
bevl_beh.bem_addValue_1(bevt_24_tmpany_phold);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_28_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_27_tmpany_phold = bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_153));
bevt_25_tmpany_phold.bem_addValue_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_154));
bevl_bet.bem_addValue_1(bevt_32_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_33_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_33_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 370 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 370 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1759131101);
if (bevl_firstmnsyn.bevi_bool) /* Line: 371 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 372 */
 else  /* Line: 373 */ {
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
bevl_bet.bem_addValue_1(bevt_35_tmpany_phold);
} /* Line: 374 */
bevt_37_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_38_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_36_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 376 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_157));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_158));
bevl_bet.bem_addValue_1(bevt_41_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_42_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_42_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 383 */ {
bevt_43_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_43_tmpany_phold).bevi_bool) /* Line: 383 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(1759131101);
if (bevl_firstptsyn.bevi_bool) /* Line: 384 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 385 */
 else  /* Line: 386 */ {
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_159));
bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
} /* Line: 387 */
bevt_46_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_47_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_addValue_1(bevt_47_tmpany_phold);
bevt_45_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 389 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_160));
bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_161));
bevl_bet.bem_addValue_1(bevt_49_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_162));
bevt_51_tmpany_phold = bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_163));
bevt_50_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_57_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_44;
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_60_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_165));
bevt_59_tmpany_phold = bevl_bet.bem_addValue_1(bevt_60_tmpany_phold);
bevt_61_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bem_addValue_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_166));
bevt_58_tmpany_phold.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 397 */
 else  /* Line: 398 */ {
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_167));
bevt_64_tmpany_phold = bevl_bet.bem_addValue_1(bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_addValue_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_168));
bevt_63_tmpany_phold.bem_addValue_1(bevt_67_tmpany_phold);
} /* Line: 399 */
bevt_68_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_169));
bevl_bet.bem_addValue_1(bevt_68_tmpany_phold);
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_170));
bevt_70_tmpany_phold = bevl_bet.bem_addValue_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_addValue_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_171));
bevt_69_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_172));
bevl_bet.bem_addValue_1(bevt_74_tmpany_phold);
bevt_76_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_173));
bevt_75_tmpany_phold = bem_genMark_1(bevt_76_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_174));
bevl_bet.bem_addValue_1(bevt_77_tmpany_phold);
bevt_78_tmpany_phold = (new BEC_2_4_6_TextString(56, bece_BEC_2_5_9_BuildCCEmitter_bels_175));
bevl_bet.bem_addValue_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_176));
bevt_79_tmpany_phold = bem_genMark_1(bevt_80_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_79_tmpany_phold);
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_177));
bevl_bet.bem_addValue_1(bevt_81_tmpany_phold);
bevt_82_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_178));
bevl_bet.bem_addValue_1(bevt_82_tmpany_phold);
bevt_90_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_179));
bevt_89_tmpany_phold = bevp_onceDecs.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_180));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_86_tmpany_phold = bevt_87_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_93_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_181));
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_addValue_1(bevt_93_tmpany_phold);
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bem_addValue_1(bevp_onceDecRefs);
bevt_94_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_182));
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bem_addValue_1(bevt_94_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_183));
bevt_98_tmpany_phold = bevp_onceDecs.bem_addValue_1(bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_101_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_184));
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_addValue_1(bevt_101_tmpany_phold);
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_185));
bevt_95_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevp_onceDecRefs.bem_clear_0();
bevp_onceDecRefsCount = (new BEC_2_4_3_MathInt(0));
bevt_103_tmpany_phold = bem_getClassOutput_0();
bevt_103_tmpany_phold.bem_write_1(bevl_bet);
bevt_104_tmpany_phold = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_104_tmpany_phold.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_20_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_31_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
if (bevp_deow == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 430 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_45;
bevt_8_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_46;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_4_tmpany_phold.bem_add_1(bevp_headExt);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_47;
bevt_14_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_48;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_10_tmpany_phold.bem_add_1(bevp_headExt);
bevt_16_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_17_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_21_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_existsGet_0();
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 436 */ {
bevt_23_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_fileGet_0();
bevt_22_tmpany_phold.bem_makeDirs_0();
} /* Line: 437 */
bevt_25_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_tmpany_phold.bemd_0(-1769365769);
bevt_27_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_tmpany_phold.bemd_0(-1769365769);
bevt_29_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_190));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_has_1(bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 442 */ {
bevt_32_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_191));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_get_1(bevt_33_tmpany_phold);
bevt_0_tmpany_loop = bevt_31_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 444 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 444 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1759131101);
bevt_35_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_tmpany_phold.bem_fileGet_0();
bevt_37_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-1769365769);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bemd_0(683698932);
bevt_38_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_38_tmpany_phold.bemd_0(-1223869755);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 450 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
} /* Line: 444 */
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_192));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_193));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_194));
bevp_deow.bem_write_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_195));
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_196));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_has_1(bevt_45_tmpany_phold);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 464 */ {
bevt_47_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_197));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_get_1(bevt_48_tmpany_phold);
bevt_1_tmpany_loop = bevt_46_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 466 */ {
bevt_49_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_49_tmpany_phold).bevi_bool) /* Line: 466 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(1759131101);
bevt_50_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_50_tmpany_phold.bem_fileGet_0();
bevt_52_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(-1769365769);
bevl_inc = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bemd_0(683698932);
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_53_tmpany_phold.bemd_0(-1223869755);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 472 */
 else  /* Line: 466 */ {
break;
} /* Line: 466 */
} /* Line: 466 */
} /* Line: 466 */
bevt_55_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_198));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_has_1(bevt_56_tmpany_phold);
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 475 */ {
bevt_58_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_199));
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_get_1(bevt_59_tmpany_phold);
bevt_2_tmpany_loop = bevt_57_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 477 */ {
bevt_60_tmpany_phold = bevt_2_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 477 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(1759131101);
bevt_61_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_61_tmpany_phold.bem_fileGet_0();
bevt_63_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(-1769365769);
bevl_inc = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bemd_0(683698932);
bevt_64_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_64_tmpany_phold.bemd_0(-1223869755);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 483 */
 else  /* Line: 477 */ {
break;
} /* Line: 477 */
} /* Line: 477 */
} /* Line: 477 */
} /* Line: 475 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_27_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 496 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_existsGet_0();
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevt_8_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 499 */
bevt_10_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_tmpany_phold.bemd_0(-1769365769);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_200));
bevp_shlibe.bem_write_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_201));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_has_1(bevt_14_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 505 */ {
bevt_16_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_202));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_get_1(bevt_17_tmpany_phold);
bevt_0_tmpany_loop = bevt_15_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 507 */ {
bevt_18_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 507 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1759131101);
bevt_19_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-1769365769);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bemd_0(683698932);
bevt_22_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_22_tmpany_phold.bemd_0(-1223869755);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 513 */
 else  /* Line: 507 */ {
break;
} /* Line: 507 */
} /* Line: 507 */
} /* Line: 507 */
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_203));
bevp_shlibe.bem_write_1(bevt_23_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_25_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_204));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_has_1(bevt_26_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 519 */ {
bevt_28_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_205));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_get_1(bevt_29_tmpany_phold);
bevt_1_tmpany_loop = bevt_27_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 520 */ {
bevt_30_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 520 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(1759131101);
bevt_31_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_tmpany_phold.bem_fileGet_0();
bevt_33_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-1769365769);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bemd_0(683698932);
bevt_34_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_34_tmpany_phold.bemd_0(-1223869755);
bevt_35_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 525 */
 else  /* Line: 520 */ {
break;
} /* Line: 520 */
} /* Line: 520 */
} /* Line: 520 */
} /* Line: 519 */
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_206));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_207));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_208));
bevt_1_tmpany_phold = beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_209));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(141565666);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_210));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 562 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 562 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(1759131101);
if (bevl_first.bevi_bool) /* Line: 563 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 564 */
 else  /* Line: 565 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_211));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 566 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_212));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 568 */
 else  /* Line: 562 */ {
break;
} /* Line: 562 */
} /* Line: 562 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_213));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_49;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_50;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_216));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_217));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_218));
bevt_4_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_51;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_52;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_53;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_54;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_55;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_56;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
bevt_1_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_tmpany_phold.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(592530042);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_225));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_226));
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_227));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_228));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_229));
bevt_20_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 609 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_230));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_tmpany_phold, bevl_asnr);
} /* Line: 610 */
bevt_25_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_231));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_232));
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_233));
bevt_28_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_29_tmpany_phold);
bevt_28_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_234));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_235));
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_236));
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_237));
bevt_44_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_45_tmpany_phold);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_238));
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_addValue_1(bevt_46_tmpany_phold);
bevt_42_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_239));
bevt_47_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_48_tmpany_phold);
bevt_47_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_55_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_54_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_55_tmpany_phold);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_240));
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_57_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bem_addValue_1(bevt_57_tmpany_phold);
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_241));
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_242));
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_49_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_62_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(599162753);
if (bevt_61_tmpany_phold == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 629 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 629 */ {
bevt_65_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_0(599162753);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_1(-39094467, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 629 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 629 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 629 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 629 */ {
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_243));
bevt_66_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_67_tmpany_phold);
bevt_66_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 630 */
 else  /* Line: 631 */ {
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_244));
bevt_68_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_69_tmpany_phold);
bevt_68_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 632 */
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_245));
bevt_70_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_71_tmpany_phold);
bevt_70_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_246));
bevt_74_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_75_tmpany_phold);
bevt_76_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bem_addValue_1(bevt_76_tmpany_phold);
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_247));
bevt_72_tmpany_phold = bevt_73_tmpany_phold.bem_addValue_1(bevt_77_tmpany_phold);
bevt_72_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_248));
bevt_80_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_81_tmpany_phold);
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_82_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_249));
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bem_addValue_1(bevt_82_tmpany_phold);
bevt_78_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_84_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_250));
bevt_83_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_84_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_251));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_252));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_57;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_58;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_59;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_headExtGetDirect_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public final BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public final BEC_2_4_6_TextString bem_classHeadersGetDirect_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGet_0() throws Throwable {
return bevp_onceDecRefs;
} /*method end*/
public final BEC_2_4_6_TextString bem_onceDecRefsGetDirect_0() throws Throwable {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGet_0() throws Throwable {
return bevp_onceDecRefsCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_onceDecRefsCountGetDirect_0() throws Throwable {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public final BEC_2_4_6_TextString bem_deonGetDirect_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public final BEC_2_4_6_TextString bem_heonGetDirect_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 19, 20, 22, 23, 24, 25, 26, 30, 32, 33, 34, 35, 36, 40, 44, 44, 45, 45, 45, 47, 47, 49, 49, 49, 49, 49, 49, 51, 51, 52, 52, 54, 54, 56, 56, 56, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 65, 65, 67, 67, 69, 71, 73, 75, 77, 77, 78, 78, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 86, 86, 87, 87, 87, 87, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 98, 98, 98, 102, 104, 105, 106, 106, 107, 111, 111, 115, 115, 119, 119, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 126, 128, 128, 128, 128, 128, 128, 130, 130, 130, 130, 130, 130, 130, 130, 130, 130, 132, 134, 134, 140, 140, 140, 140, 141, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 147, 147, 149, 153, 153, 153, 153, 154, 154, 155, 157, 157, 161, 161, 161, 161, 161, 161, 161, 161, 165, 165, 165, 165, 166, 166, 166, 168, 174, 174, 174, 174, 174, 176, 176, 176, 176, 176, 176, 176, 176, 178, 180, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 191, 191, 191, 192, 193, 193, 193, 193, 193, 193, 195, 195, 195, 195, 195, 195, 195, 195, 195, 195, 199, 199, 199, 200, 200, 200, 200, 200, 202, 202, 202, 202, 202, 202, 202, 207, 207, 208, 210, 212, 212, 212, 212, 212, 212, 212, 212, 217, 217, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 222, 222, 222, 222, 222, 222, 222, 222, 222, 224, 224, 224, 228, 228, 228, 228, 228, 228, 228, 228, 228, 228, 228, 228, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 243, 244, 244, 245, 245, 247, 247, 247, 248, 248, 248, 248, 248, 253, 254, 255, 255, 255, 256, 262, 262, 262, 262, 266, 266, 270, 270, 275, 275, 279, 279, 279, 279, 279, 280, 280, 280, 280, 280, 280, 281, 281, 281, 282, 282, 282, 282, 282, 282, 282, 282, 284, 284, 288, 288, 292, 292, 292, 292, 299, 300, 0, 300, 300, 300, 300, 300, 0, 0, 301, 303, 303, 303, 304, 304, 304, 305, 308, 311, 316, 317, 317, 319, 319, 323, 324, 325, 325, 326, 331, 333, 334, 334, 335, 336, 337, 337, 338, 338, 338, 339, 345, 346, 346, 346, 346, 346, 346, 346, 346, 346, 347, 347, 347, 347, 348, 348, 348, 349, 353, 353, 353, 353, 353, 353, 354, 355, 355, 355, 355, 355, 355, 356, 356, 357, 357, 357, 357, 358, 358, 359, 359, 360, 360, 360, 360, 360, 361, 361, 362, 362, 363, 363, 364, 366, 367, 367, 367, 367, 367, 367, 367, 367, 368, 368, 369, 370, 370, 0, 370, 370, 372, 374, 374, 376, 376, 376, 376, 378, 378, 379, 379, 381, 381, 382, 383, 383, 0, 383, 383, 385, 387, 387, 389, 389, 389, 389, 391, 391, 393, 393, 395, 395, 395, 395, 395, 395, 396, 396, 396, 397, 397, 397, 397, 397, 397, 399, 399, 399, 399, 399, 399, 401, 401, 403, 403, 403, 403, 403, 403, 404, 404, 405, 405, 405, 406, 406, 407, 407, 408, 408, 408, 409, 409, 410, 410, 412, 412, 412, 412, 412, 412, 412, 412, 412, 412, 412, 412, 412, 413, 413, 413, 413, 413, 413, 413, 413, 413, 414, 415, 417, 417, 418, 418, 430, 430, 431, 432, 432, 432, 432, 432, 432, 432, 433, 433, 433, 433, 433, 433, 433, 434, 434, 435, 435, 436, 436, 436, 436, 436, 437, 437, 437, 439, 439, 439, 440, 440, 440, 442, 442, 442, 444, 444, 444, 444, 0, 444, 444, 446, 446, 447, 447, 447, 448, 448, 450, 454, 454, 455, 455, 457, 457, 458, 458, 464, 464, 464, 466, 466, 466, 466, 0, 466, 466, 468, 468, 469, 469, 469, 470, 470, 472, 475, 475, 475, 477, 477, 477, 477, 0, 477, 477, 479, 479, 480, 480, 480, 481, 481, 483, 490, 491, 496, 496, 497, 498, 498, 498, 498, 498, 499, 499, 499, 501, 501, 501, 503, 503, 505, 505, 505, 507, 507, 507, 507, 0, 507, 507, 509, 509, 510, 510, 510, 511, 511, 513, 517, 517, 518, 519, 519, 519, 520, 520, 520, 520, 0, 520, 520, 521, 521, 522, 522, 522, 523, 523, 524, 524, 525, 531, 535, 536, 538, 538, 540, 540, 541, 542, 547, 547, 551, 551, 551, 551, 551, 556, 556, 557, 559, 559, 559, 559, 561, 562, 0, 562, 562, 564, 566, 566, 568, 568, 568, 568, 568, 568, 572, 572, 572, 577, 579, 579, 579, 579, 579, 581, 581, 581, 581, 581, 581, 581, 581, 581, 581, 581, 583, 587, 587, 588, 588, 588, 588, 589, 593, 593, 594, 594, 594, 594, 595, 595, 595, 595, 599, 599, 599, 603, 603, 603, 604, 604, 604, 605, 607, 607, 607, 607, 607, 607, 607, 607, 607, 607, 607, 607, 607, 607, 607, 608, 609, 609, 610, 610, 613, 613, 613, 613, 613, 613, 613, 615, 615, 615, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 623, 623, 623, 623, 623, 623, 626, 626, 626, 628, 628, 628, 628, 628, 628, 628, 628, 628, 628, 628, 628, 629, 629, 629, 629, 0, 629, 629, 629, 0, 0, 630, 630, 630, 632, 632, 632, 634, 635, 638, 638, 638, 640, 642, 642, 642, 642, 642, 642, 642, 644, 644, 644, 644, 644, 644, 646, 646, 646, 652, 652, 653, 653, 655, 660, 660, 661, 661, 661, 661, 662, 662, 662, 662, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 358, 416, 421, 422, 423, 424, 427, 428, 430, 431, 432, 433, 434, 435, 436, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 455, 456, 457, 458, 459, 460, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 576, 577, 578, 579, 580, 581, 585, 586, 590, 591, 595, 596, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 675, 676, 677, 682, 683, 686, 687, 688, 689, 691, 694, 695, 696, 697, 699, 702, 703, 707, 717, 718, 719, 720, 722, 723, 724, 726, 727, 737, 738, 739, 740, 741, 742, 743, 744, 754, 755, 756, 757, 759, 760, 761, 764, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 901, 902, 907, 908, 909, 910, 911, 912, 915, 916, 917, 918, 919, 920, 921, 936, 937, 939, 942, 944, 945, 946, 947, 948, 949, 950, 951, 955, 956, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1126, 1127, 1128, 1130, 1131, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1146, 1147, 1148, 1149, 1150, 1151, 1158, 1159, 1160, 1161, 1165, 1166, 1170, 1171, 1175, 1176, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1226, 1227, 1233, 1234, 1235, 1236, 1252, 1253, 1255, 1258, 1259, 1260, 1261, 1266, 1267, 1270, 1274, 1277, 1278, 1279, 1280, 1281, 1282, 1283, 1285, 1287, 1295, 1297, 1298, 1300, 1301, 1307, 1309, 1310, 1311, 1312, 1323, 1325, 1326, 1327, 1328, 1329, 1330, 1335, 1336, 1337, 1338, 1339, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1538, 1541, 1543, 1545, 1548, 1549, 1551, 1552, 1553, 1554, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1568, 1571, 1573, 1575, 1578, 1579, 1581, 1582, 1583, 1584, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1602, 1604, 1605, 1606, 1607, 1608, 1609, 1612, 1613, 1614, 1615, 1616, 1617, 1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1648, 1649, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1659, 1660, 1661, 1662, 1663, 1664, 1665, 1666, 1667, 1668, 1669, 1670, 1743, 1748, 1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1770, 1771, 1776, 1777, 1778, 1779, 1781, 1782, 1783, 1784, 1785, 1786, 1787, 1788, 1789, 1791, 1792, 1793, 1794, 1794, 1797, 1799, 1800, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1814, 1815, 1816, 1817, 1818, 1819, 1820, 1821, 1822, 1823, 1824, 1826, 1827, 1828, 1829, 1829, 1832, 1834, 1835, 1836, 1837, 1838, 1839, 1840, 1841, 1842, 1849, 1850, 1851, 1853, 1854, 1855, 1856, 1856, 1859, 1861, 1862, 1863, 1864, 1865, 1866, 1867, 1868, 1869, 1880, 1881, 1924, 1929, 1930, 1931, 1932, 1933, 1934, 1939, 1940, 1941, 1942, 1944, 1945, 1946, 1947, 1948, 1949, 1950, 1951, 1953, 1954, 1955, 1956, 1956, 1959, 1961, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1969, 1976, 1977, 1978, 1979, 1980, 1981, 1983, 1984, 1985, 1986, 1986, 1989, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2009, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2026, 2027, 2034, 2035, 2036, 2037, 2038, 2060, 2061, 2062, 2063, 2064, 2065, 2066, 2067, 2068, 2068, 2071, 2073, 2075, 2078, 2079, 2081, 2082, 2083, 2084, 2085, 2086, 2092, 2093, 2094, 2114, 2115, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2124, 2125, 2126, 2127, 2128, 2129, 2130, 2131, 2140, 2141, 2142, 2143, 2144, 2145, 2146, 2158, 2159, 2160, 2161, 2162, 2163, 2164, 2165, 2166, 2167, 2172, 2173, 2174, 2267, 2268, 2269, 2270, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2283, 2284, 2285, 2286, 2287, 2288, 2289, 2290, 2291, 2293, 2294, 2296, 2297, 2298, 2299, 2300, 2301, 2302, 2303, 2304, 2305, 2306, 2307, 2308, 2309, 2310, 2311, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337, 2338, 2339, 2340, 2341, 2342, 2347, 2348, 2351, 2352, 2353, 2355, 2358, 2362, 2363, 2364, 2367, 2368, 2369, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2384, 2385, 2386, 2387, 2388, 2389, 2390, 2391, 2392, 2398, 2399, 2400, 2401, 2402, 2415, 2416, 2417, 2418, 2419, 2420, 2421, 2422, 2423, 2424, 2427, 2430, 2433, 2437, 2441, 2444, 2447, 2451, 2455, 2458, 2461, 2465, 2469, 2472, 2475, 2479, 2483, 2486, 2489, 2493, 2497, 2500, 2503, 2507, 2511, 2514, 2517, 2521, 2525, 2528, 2531, 2535, 2539, 2542, 2545, 2549, 2553, 2556, 2559, 2563, 2567, 2570, 2573, 2577, 2581, 2584, 2587, 2591, 2595, 2598, 2601, 2605};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 341
new 0 18 341
assign 1 19 342
new 0 19 342
assign 1 20 343
new 0 20 343
assign 1 22 344
new 0 22 344
assign 1 23 345
new 0 23 345
assign 1 24 346
new 0 24 346
assign 1 25 347
new 0 25 347
assign 1 26 348
new 0 26 348
new 1 30 349
assign 1 32 350
new 0 32 350
assign 1 33 351
new 0 33 351
assign 1 34 352
new 0 34 352
assign 1 35 353
new 0 35 353
assign 1 36 354
new 0 36 354
addValue 1 40 358
assign 1 44 416
def 1 44 421
assign 1 45 422
libNameGet 0 45 422
assign 1 45 423
relEmitName 1 45 423
assign 1 45 424
extend 1 45 424
assign 1 47 427
new 0 47 427
assign 1 47 428
extend 1 47 428
assign 1 49 430
new 0 49 430
assign 1 49 431
emitNameGet 0 49 431
assign 1 49 432
addValue 1 49 432
assign 1 49 433
addValue 1 49 433
assign 1 49 434
new 0 49 434
assign 1 49 435
addValue 1 49 435
assign 1 51 436
def 1 51 441
assign 1 52 442
new 0 52 442
addValue 1 52 443
assign 1 54 444
new 0 54 444
addValue 1 54 445
assign 1 56 446
new 0 56 446
assign 1 56 447
addValue 1 56 447
assign 1 56 448
libNameGet 0 56 448
assign 1 56 449
relEmitName 1 56 449
assign 1 56 450
addValue 1 56 450
assign 1 56 451
new 0 56 451
addValue 1 56 452
assign 1 58 455
new 0 58 455
addValue 1 58 456
assign 1 60 457
new 0 60 457
addValue 1 60 458
assign 1 62 459
new 0 62 459
addValue 1 62 460
assign 1 65 462
new 0 65 462
addValue 1 65 463
assign 1 67 464
new 0 67 464
addValue 1 67 465
write 1 69 466
write 1 71 467
write 1 73 468
clear 0 75 469
assign 1 77 470
new 0 77 470
write 1 77 471
assign 1 78 472
new 0 78 472
write 1 78 473
assign 1 79 474
new 0 79 474
write 1 79 475
assign 1 80 476
new 0 80 476
assign 1 80 477
emitNameGet 0 80 477
assign 1 80 478
add 1 80 478
assign 1 80 479
new 0 80 479
assign 1 80 480
add 1 80 480
assign 1 80 481
getHeaderInitialInst 1 80 481
assign 1 80 482
add 1 80 482
assign 1 80 483
new 0 80 483
assign 1 80 484
add 1 80 484
write 1 80 485
assign 1 81 486
new 0 81 486
write 1 81 487
assign 1 82 488
new 0 82 488
write 1 82 489
assign 1 83 490
new 0 83 490
write 1 83 491
assign 1 84 492
new 0 84 492
write 1 84 493
assign 1 85 494
new 0 85 494
write 1 85 495
assign 1 86 496
new 0 86 496
write 1 86 497
assign 1 87 498
new 0 87 498
assign 1 87 499
emitNameGet 0 87 499
assign 1 87 500
add 1 87 500
assign 1 87 501
new 0 87 501
assign 1 87 502
add 1 87 502
write 1 87 503
assign 1 89 504
new 0 89 504
assign 1 89 505
emitNameGet 0 89 505
assign 1 89 506
add 1 89 506
assign 1 89 507
new 0 89 507
assign 1 89 508
add 1 89 508
write 1 89 509
assign 1 91 510
new 0 91 510
return 1 91 511
assign 1 95 541
overrideMtdDecGet 0 95 541
assign 1 95 542
addValue 1 95 542
assign 1 95 543
getClassConfig 1 95 543
assign 1 95 544
libNameGet 0 95 544
assign 1 95 545
relEmitName 1 95 545
assign 1 95 546
addValue 1 95 546
assign 1 95 547
new 0 95 547
assign 1 95 548
addValue 1 95 548
assign 1 95 549
emitNameGet 0 95 549
assign 1 95 550
addValue 1 95 550
assign 1 95 551
new 0 95 551
assign 1 95 552
addValue 1 95 552
assign 1 95 553
addValue 1 95 553
assign 1 95 554
new 0 95 554
assign 1 95 555
addValue 1 95 555
addValue 1 95 556
assign 1 96 557
new 0 96 557
assign 1 96 558
addValue 1 96 558
assign 1 96 559
heldGet 0 96 559
assign 1 96 560
namepathGet 0 96 560
assign 1 96 561
getClassConfig 1 96 561
assign 1 96 562
libNameGet 0 96 562
assign 1 96 563
relEmitName 1 96 563
assign 1 96 564
addValue 1 96 564
assign 1 96 565
new 0 96 565
assign 1 96 566
addValue 1 96 566
addValue 1 96 567
assign 1 98 568
new 0 98 568
assign 1 98 569
addValue 1 98 569
addValue 1 98 570
assign 1 102 576
new 0 102 576
write 1 104 577
clear 0 105 578
assign 1 106 579
new 0 106 579
write 1 106 580
return 1 107 581
assign 1 111 585
new 0 111 585
return 1 111 586
assign 1 115 590
new 0 115 590
return 1 115 591
assign 1 119 595
new 0 119 595
return 1 119 596
assign 1 124 626
addValue 1 124 626
assign 1 124 627
libNameGet 0 124 627
assign 1 124 628
relEmitName 1 124 628
assign 1 124 629
addValue 1 124 629
assign 1 124 630
new 0 124 630
assign 1 124 631
addValue 1 124 631
assign 1 124 632
emitNameGet 0 124 632
assign 1 124 633
addValue 1 124 633
assign 1 124 634
new 0 124 634
assign 1 124 635
addValue 1 124 635
assign 1 124 636
addValue 1 124 636
assign 1 124 637
new 0 124 637
addValue 1 124 638
addValue 1 126 639
assign 1 128 640
new 0 128 640
assign 1 128 641
addValue 1 128 641
assign 1 128 642
addValue 1 128 642
assign 1 128 643
new 0 128 643
assign 1 128 644
addValue 1 128 644
addValue 1 128 645
assign 1 130 646
new 0 130 646
assign 1 130 647
addValue 1 130 647
assign 1 130 648
libNameGet 0 130 648
assign 1 130 649
relEmitName 1 130 649
assign 1 130 650
addValue 1 130 650
assign 1 130 651
new 0 130 651
assign 1 130 652
addValue 1 130 652
assign 1 130 653
addValue 1 130 653
assign 1 130 654
new 0 130 654
addValue 1 130 655
addValue 1 132 656
assign 1 134 657
new 0 134 657
addValue 1 134 658
assign 1 140 675
typenameGet 0 140 675
assign 1 140 676
NULLGet 0 140 676
assign 1 140 677
equals 1 140 682
assign 1 141 683
new 0 141 683
assign 1 142 686
heldGet 0 142 686
assign 1 142 687
nameGet 0 142 687
assign 1 142 688
new 0 142 688
assign 1 142 689
equals 1 142 689
assign 1 143 691
new 0 143 691
assign 1 144 694
heldGet 0 144 694
assign 1 144 695
nameGet 0 144 695
assign 1 144 696
new 0 144 696
assign 1 144 697
equals 1 144 697
assign 1 145 699
new 0 145 699
assign 1 147 702
heldGet 0 147 702
assign 1 147 703
nameForVar 1 147 703
return 1 149 707
assign 1 153 717
heldGet 0 153 717
assign 1 153 718
nameGet 0 153 718
assign 1 153 719
new 0 153 719
assign 1 153 720
equals 1 153 720
assign 1 154 722
new 0 154 722
assign 1 154 723
add 1 154 723
return 1 155 724
assign 1 157 726
formCallTarg 1 157 726
return 1 157 727
assign 1 161 737
new 0 161 737
assign 1 161 738
addValue 1 161 738
assign 1 161 739
secondGet 0 161 739
assign 1 161 740
formTarg 1 161 740
assign 1 161 741
addValue 1 161 741
assign 1 161 742
new 0 161 742
assign 1 161 743
addValue 1 161 743
addValue 1 161 744
assign 1 165 754
heldGet 0 165 754
assign 1 165 755
langsGet 0 165 755
assign 1 165 756
new 0 165 756
assign 1 165 757
has 1 165 757
assign 1 166 759
heldGet 0 166 759
assign 1 166 760
textGet 0 166 760
addValue 1 166 761
handleClassEmit 1 168 764
assign 1 174 806
new 0 174 806
assign 1 174 807
emitNameGet 0 174 807
assign 1 174 808
add 1 174 808
assign 1 174 809
new 0 174 809
assign 1 174 810
add 1 174 810
assign 1 176 811
new 0 176 811
assign 1 176 812
typeEmitNameGet 0 176 812
assign 1 176 813
add 1 176 813
assign 1 176 814
new 0 176 814
assign 1 176 815
add 1 176 815
assign 1 176 816
add 1 176 816
assign 1 176 817
new 0 176 817
assign 1 176 818
add 1 176 818
addClassHeader 1 178 819
assign 1 180 820
new 0 180 820
assign 1 182 821
typeEmitNameGet 0 182 821
assign 1 182 822
addValue 1 182 822
assign 1 182 823
new 0 182 823
assign 1 182 824
addValue 1 182 824
assign 1 182 825
emitNameGet 0 182 825
assign 1 182 826
addValue 1 182 826
assign 1 182 827
new 0 182 827
assign 1 182 828
addValue 1 182 828
assign 1 182 829
addValue 1 182 829
assign 1 182 830
new 0 182 830
addValue 1 182 831
assign 1 184 832
new 0 184 832
assign 1 184 833
addValue 1 184 833
assign 1 184 834
typeEmitNameGet 0 184 834
assign 1 184 835
addValue 1 184 835
assign 1 184 836
new 0 184 836
assign 1 184 837
addValue 1 184 837
assign 1 184 838
emitNameGet 0 184 838
assign 1 184 839
addValue 1 184 839
assign 1 184 840
new 0 184 840
assign 1 184 841
emitNameGet 0 184 841
assign 1 184 842
add 1 184 842
assign 1 184 843
new 0 184 843
assign 1 184 844
add 1 184 844
addValue 1 184 845
return 1 186 846
assign 1 191 866
new 0 191 866
assign 1 191 867
toString 0 191 867
assign 1 191 868
add 1 191 868
incrementValue 0 192 869
assign 1 193 870
new 0 193 870
assign 1 193 871
addValue 1 193 871
assign 1 193 872
addValue 1 193 872
assign 1 193 873
new 0 193 873
assign 1 193 874
addValue 1 193 874
addValue 1 193 875
assign 1 195 876
containedGet 0 195 876
assign 1 195 877
firstGet 0 195 877
assign 1 195 878
containedGet 0 195 878
assign 1 195 879
firstGet 0 195 879
assign 1 195 880
new 0 195 880
assign 1 195 881
add 1 195 881
assign 1 195 882
new 0 195 882
assign 1 195 883
add 1 195 883
assign 1 195 884
finalAssign 4 195 884
addValue 1 195 885
assign 1 199 901
isTypedGet 0 199 901
assign 1 199 902
not 0 199 907
assign 1 200 908
libNameGet 0 200 908
assign 1 200 909
relEmitName 1 200 909
assign 1 200 910
addValue 1 200 910
assign 1 200 911
new 0 200 911
addValue 1 200 912
assign 1 202 915
namepathGet 0 202 915
assign 1 202 916
getClassConfig 1 202 916
assign 1 202 917
libNameGet 0 202 917
assign 1 202 918
relEmitName 1 202 918
assign 1 202 919
addValue 1 202 919
assign 1 202 920
new 0 202 920
addValue 1 202 921
assign 1 207 936
new 0 207 936
assign 1 207 937
equals 1 207 937
assign 1 208 939
new 0 208 939
assign 1 210 942
new 0 210 942
assign 1 212 944
new 0 212 944
assign 1 212 945
add 1 212 945
assign 1 212 946
libNameGet 0 212 946
assign 1 212 947
relEmitName 1 212 947
assign 1 212 948
add 1 212 948
assign 1 212 949
new 0 212 949
assign 1 212 950
add 1 212 950
return 1 212 951
assign 1 217 955
new 0 217 955
return 1 217 956
assign 1 221 983
overrideMtdDecGet 0 221 983
assign 1 221 984
addValue 1 221 984
assign 1 221 985
new 0 221 985
assign 1 221 986
addValue 1 221 986
assign 1 221 987
emitNameGet 0 221 987
assign 1 221 988
addValue 1 221 988
assign 1 221 989
new 0 221 989
assign 1 221 990
addValue 1 221 990
assign 1 221 991
addValue 1 221 991
assign 1 221 992
new 0 221 992
assign 1 221 993
addValue 1 221 993
assign 1 221 994
addValue 1 221 994
assign 1 221 995
new 0 221 995
assign 1 221 996
addValue 1 221 996
addValue 1 221 997
assign 1 222 998
new 0 222 998
assign 1 222 999
addValue 1 222 999
assign 1 222 1000
addValue 1 222 1000
assign 1 222 1001
new 0 222 1001
assign 1 222 1002
addValue 1 222 1002
assign 1 222 1003
addValue 1 222 1003
assign 1 222 1004
new 0 222 1004
assign 1 222 1005
addValue 1 222 1005
addValue 1 222 1006
assign 1 224 1007
new 0 224 1007
assign 1 224 1008
addValue 1 224 1008
addValue 1 224 1009
assign 1 228 1024
new 0 228 1024
assign 1 228 1025
libNameGet 0 228 1025
assign 1 228 1026
relEmitName 1 228 1026
assign 1 228 1027
add 1 228 1027
assign 1 228 1028
new 0 228 1028
assign 1 228 1029
add 1 228 1029
assign 1 228 1030
heldGet 0 228 1030
assign 1 228 1031
literalValueGet 0 228 1031
assign 1 228 1032
add 1 228 1032
assign 1 228 1033
new 0 228 1033
assign 1 228 1034
add 1 228 1034
return 1 228 1035
assign 1 232 1049
new 0 232 1049
assign 1 232 1050
libNameGet 0 232 1050
assign 1 232 1051
relEmitName 1 232 1051
assign 1 232 1052
add 1 232 1052
assign 1 232 1053
new 0 232 1053
assign 1 232 1054
add 1 232 1054
assign 1 232 1055
heldGet 0 232 1055
assign 1 232 1056
literalValueGet 0 232 1056
assign 1 232 1057
add 1 232 1057
assign 1 232 1058
new 0 232 1058
assign 1 232 1059
add 1 232 1059
return 1 232 1060
assign 1 237 1088
new 0 237 1088
assign 1 237 1089
libNameGet 0 237 1089
assign 1 237 1090
relEmitName 1 237 1090
assign 1 237 1091
add 1 237 1091
assign 1 237 1092
new 0 237 1092
assign 1 237 1093
add 1 237 1093
assign 1 237 1094
add 1 237 1094
assign 1 237 1095
new 0 237 1095
assign 1 237 1096
add 1 237 1096
assign 1 237 1097
add 1 237 1097
assign 1 237 1098
new 0 237 1098
assign 1 237 1099
add 1 237 1099
return 1 237 1100
assign 1 239 1102
new 0 239 1102
assign 1 239 1103
libNameGet 0 239 1103
assign 1 239 1104
relEmitName 1 239 1104
assign 1 239 1105
add 1 239 1105
assign 1 239 1106
new 0 239 1106
assign 1 239 1107
add 1 239 1107
assign 1 239 1108
add 1 239 1108
assign 1 239 1109
new 0 239 1109
assign 1 239 1110
add 1 239 1110
assign 1 239 1111
add 1 239 1111
assign 1 239 1112
new 0 239 1112
assign 1 239 1113
add 1 239 1113
return 1 239 1114
incrementValue 0 243 1126
assign 1 244 1127
new 0 244 1127
assign 1 244 1128
notEmpty 1 244 1128
assign 1 245 1130
new 0 245 1130
addValue 1 245 1131
assign 1 247 1133
new 0 247 1133
assign 1 247 1134
addValue 1 247 1134
addValue 1 247 1135
assign 1 248 1136
new 0 248 1136
assign 1 248 1137
add 1 248 1137
assign 1 248 1138
new 0 248 1138
assign 1 248 1139
add 1 248 1139
return 1 248 1140
getCode 2 253 1146
assign 1 254 1147
toHexString 1 254 1147
assign 1 255 1148
new 0 255 1148
assign 1 255 1149
once 0 255 1149
addValue 1 255 1150
addValue 1 256 1151
assign 1 262 1158
new 0 262 1158
assign 1 262 1159
add 1 262 1159
assign 1 262 1160
add 1 262 1160
return 1 262 1161
assign 1 266 1165
new 0 266 1165
return 1 266 1166
assign 1 270 1170
new 0 270 1170
return 1 270 1171
assign 1 275 1175
new 0 275 1175
return 1 275 1176
assign 1 279 1199
new 0 279 1199
assign 1 279 1200
add 1 279 1200
assign 1 279 1201
new 0 279 1201
assign 1 279 1202
add 1 279 1202
assign 1 279 1203
add 1 279 1203
assign 1 280 1204
new 0 280 1204
assign 1 280 1205
addValue 1 280 1205
assign 1 280 1206
addValue 1 280 1206
assign 1 280 1207
new 0 280 1207
assign 1 280 1208
addValue 1 280 1208
addValue 1 280 1209
assign 1 281 1210
new 0 281 1210
assign 1 281 1211
addValue 1 281 1211
addValue 1 281 1212
assign 1 282 1213
new 0 282 1213
assign 1 282 1214
addValue 1 282 1214
assign 1 282 1215
outputPlatformGet 0 282 1215
assign 1 282 1216
nameGet 0 282 1216
assign 1 282 1217
addValue 1 282 1217
assign 1 282 1218
new 0 282 1218
assign 1 282 1219
addValue 1 282 1219
addValue 1 282 1220
assign 1 284 1221
new 0 284 1221
return 1 284 1222
assign 1 288 1226
new 0 288 1226
return 1 288 1227
assign 1 292 1233
new 0 292 1233
assign 1 292 1234
once 0 292 1234
assign 1 292 1235
add 1 292 1235
return 1 292 1236
assign 1 299 1252
assign 1 300 1253
singleCCGet 0 300 1253
assign 1 0 1255
assign 1 300 1258
classPathGet 0 300 1258
assign 1 300 1259
fileGet 0 300 1259
assign 1 300 1260
existsGet 0 300 1260
assign 1 300 1261
not 0 300 1266
assign 1 0 1267
assign 1 0 1270
return 1 301 1274
assign 1 303 1277
classPathGet 0 303 1277
assign 1 303 1278
fileGet 0 303 1278
assign 1 303 1279
lastUpdatedGet 0 303 1279
assign 1 304 1280
fromFileGet 0 304 1280
assign 1 304 1281
fileGet 0 304 1281
assign 1 304 1282
lastUpdatedGet 0 304 1282
assign 1 305 1283
greater 1 305 1283
return 1 308 1285
assign 1 311 1287
assign 1 316 1295
singleCCGet 0 316 1295
assign 1 317 1297
getLibOutput 0 317 1297
return 1 317 1298
assign 1 319 1300
getClassOutput 0 319 1300
return 1 319 1301
assign 1 323 1307
singleCCGet 0 323 1307
assign 1 324 1309
new 0 324 1309
assign 1 325 1310
countLines 1 325 1310
addValue 1 325 1311
write 1 326 1312
assign 1 331 1323
singleCCGet 0 331 1323
assign 1 333 1325
new 0 333 1325
assign 1 334 1326
countLines 1 334 1326
addValue 1 334 1327
write 1 335 1328
close 0 336 1329
assign 1 337 1330
def 1 337 1335
assign 1 338 1336
pathGet 0 338 1336
assign 1 338 1337
fileGet 0 338 1337
lastUpdatedSet 1 338 1338
assign 1 339 1339
assign 1 345 1359
new 0 345 1359
assign 1 346 1360
new 0 346 1360
assign 1 346 1361
addValue 1 346 1361
assign 1 346 1362
addValue 1 346 1362
assign 1 346 1363
new 0 346 1363
assign 1 346 1364
addValue 1 346 1364
assign 1 346 1365
addValue 1 346 1365
assign 1 346 1366
new 0 346 1366
assign 1 346 1367
addValue 1 346 1367
addValue 1 346 1368
assign 1 347 1369
addValue 1 347 1369
assign 1 347 1370
new 0 347 1370
assign 1 347 1371
addValue 1 347 1371
addValue 1 347 1372
assign 1 348 1373
new 0 348 1373
assign 1 348 1374
addValue 1 348 1374
addValue 1 348 1375
return 1 349 1376
assign 1 353 1490
new 0 353 1490
assign 1 353 1491
typeEmitNameGet 0 353 1491
assign 1 353 1492
add 1 353 1492
assign 1 353 1493
new 0 353 1493
assign 1 353 1494
add 1 353 1494
write 1 353 1495
assign 1 354 1496
new 0 354 1496
assign 1 355 1497
new 0 355 1497
assign 1 355 1498
addValue 1 355 1498
assign 1 355 1499
typeEmitNameGet 0 355 1499
assign 1 355 1500
addValue 1 355 1500
assign 1 355 1501
new 0 355 1501
addValue 1 355 1502
assign 1 356 1503
new 0 356 1503
addValue 1 356 1504
assign 1 357 1505
typeEmitNameGet 0 357 1505
assign 1 357 1506
addValue 1 357 1506
assign 1 357 1507
new 0 357 1507
addValue 1 357 1508
assign 1 358 1509
new 0 358 1509
addValue 1 358 1510
assign 1 359 1511
new 0 359 1511
addValue 1 359 1512
assign 1 360 1513
new 0 360 1513
assign 1 360 1514
addValue 1 360 1514
assign 1 360 1515
addValue 1 360 1515
assign 1 360 1516
new 0 360 1516
addValue 1 360 1517
assign 1 361 1518
new 0 361 1518
addValue 1 361 1519
assign 1 362 1520
new 0 362 1520
addValue 1 362 1521
assign 1 363 1522
new 0 363 1522
addValue 1 363 1523
write 1 364 1524
assign 1 366 1525
new 0 366 1525
assign 1 367 1526
typeEmitNameGet 0 367 1526
assign 1 367 1527
addValue 1 367 1527
assign 1 367 1528
new 0 367 1528
assign 1 367 1529
addValue 1 367 1529
assign 1 367 1530
typeEmitNameGet 0 367 1530
assign 1 367 1531
addValue 1 367 1531
assign 1 367 1532
new 0 367 1532
addValue 1 367 1533
assign 1 368 1534
new 0 368 1534
addValue 1 368 1535
assign 1 369 1536
new 0 369 1536
assign 1 370 1537
mtdListGet 0 370 1537
assign 1 370 1538
iteratorGet 0 0 1538
assign 1 370 1541
hasNextGet 0 370 1541
assign 1 370 1543
nextGet 0 370 1543
assign 1 372 1545
new 0 372 1545
assign 1 374 1548
new 0 374 1548
addValue 1 374 1549
assign 1 376 1551
addValue 1 376 1551
assign 1 376 1552
nameGet 0 376 1552
assign 1 376 1553
addValue 1 376 1553
addValue 1 376 1554
assign 1 378 1560
new 0 378 1560
addValue 1 378 1561
assign 1 379 1562
new 0 379 1562
addValue 1 379 1563
assign 1 381 1564
new 0 381 1564
addValue 1 381 1565
assign 1 382 1566
new 0 382 1566
assign 1 383 1567
ptyListGet 0 383 1567
assign 1 383 1568
iteratorGet 0 0 1568
assign 1 383 1571
hasNextGet 0 383 1571
assign 1 383 1573
nextGet 0 383 1573
assign 1 385 1575
new 0 385 1575
assign 1 387 1578
new 0 387 1578
addValue 1 387 1579
assign 1 389 1581
addValue 1 389 1581
assign 1 389 1582
nameGet 0 389 1582
assign 1 389 1583
addValue 1 389 1583
addValue 1 389 1584
assign 1 391 1590
new 0 391 1590
addValue 1 391 1591
assign 1 393 1592
new 0 393 1592
addValue 1 393 1593
assign 1 395 1594
new 0 395 1594
assign 1 395 1595
addValue 1 395 1595
assign 1 395 1596
typeEmitNameGet 0 395 1596
assign 1 395 1597
addValue 1 395 1597
assign 1 395 1598
new 0 395 1598
addValue 1 395 1599
assign 1 396 1600
emitNameGet 0 396 1600
assign 1 396 1601
new 0 396 1601
assign 1 396 1602
equals 1 396 1602
assign 1 397 1604
new 0 397 1604
assign 1 397 1605
addValue 1 397 1605
assign 1 397 1606
emitNameGet 0 397 1606
assign 1 397 1607
addValue 1 397 1607
assign 1 397 1608
new 0 397 1608
addValue 1 397 1609
assign 1 399 1612
new 0 399 1612
assign 1 399 1613
addValue 1 399 1613
assign 1 399 1614
emitNameGet 0 399 1614
assign 1 399 1615
addValue 1 399 1615
assign 1 399 1616
new 0 399 1616
addValue 1 399 1617
assign 1 401 1619
new 0 401 1619
addValue 1 401 1620
assign 1 403 1621
new 0 403 1621
assign 1 403 1622
addValue 1 403 1622
assign 1 403 1623
typeEmitNameGet 0 403 1623
assign 1 403 1624
addValue 1 403 1624
assign 1 403 1625
new 0 403 1625
addValue 1 403 1626
assign 1 404 1627
new 0 404 1627
addValue 1 404 1628
assign 1 405 1629
new 0 405 1629
assign 1 405 1630
genMark 1 405 1630
addValue 1 405 1631
assign 1 406 1632
new 0 406 1632
addValue 1 406 1633
assign 1 407 1634
new 0 407 1634
addValue 1 407 1635
assign 1 408 1636
new 0 408 1636
assign 1 408 1637
genMark 1 408 1637
addValue 1 408 1638
assign 1 409 1639
new 0 409 1639
addValue 1 409 1640
assign 1 410 1641
new 0 410 1641
addValue 1 410 1642
assign 1 412 1643
new 0 412 1643
assign 1 412 1644
addValue 1 412 1644
assign 1 412 1645
typeEmitNameGet 0 412 1645
assign 1 412 1646
addValue 1 412 1646
assign 1 412 1647
new 0 412 1647
assign 1 412 1648
addValue 1 412 1648
assign 1 412 1649
addValue 1 412 1649
assign 1 412 1650
new 0 412 1650
assign 1 412 1651
addValue 1 412 1651
assign 1 412 1652
addValue 1 412 1652
assign 1 412 1653
new 0 412 1653
assign 1 412 1654
addValue 1 412 1654
addValue 1 412 1655
assign 1 413 1656
new 0 413 1656
assign 1 413 1657
addValue 1 413 1657
assign 1 413 1658
typeEmitNameGet 0 413 1658
assign 1 413 1659
addValue 1 413 1659
assign 1 413 1660
new 0 413 1660
assign 1 413 1661
addValue 1 413 1661
assign 1 413 1662
addValue 1 413 1662
assign 1 413 1663
new 0 413 1663
addValue 1 413 1664
clear 0 414 1665
assign 1 415 1666
new 0 415 1666
assign 1 417 1667
getClassOutput 0 417 1667
write 1 417 1668
assign 1 418 1669
countLines 1 418 1669
addValue 1 418 1670
assign 1 430 1743
undef 1 430 1748
assign 1 431 1749
libNameGet 0 431 1749
assign 1 432 1750
new 0 432 1750
assign 1 432 1751
sizeGet 0 432 1751
assign 1 432 1752
add 1 432 1752
assign 1 432 1753
new 0 432 1753
assign 1 432 1754
add 1 432 1754
assign 1 432 1755
add 1 432 1755
assign 1 432 1756
add 1 432 1756
assign 1 433 1757
new 0 433 1757
assign 1 433 1758
sizeGet 0 433 1758
assign 1 433 1759
add 1 433 1759
assign 1 433 1760
new 0 433 1760
assign 1 433 1761
add 1 433 1761
assign 1 433 1762
add 1 433 1762
assign 1 433 1763
add 1 433 1763
assign 1 434 1764
parentGet 0 434 1764
assign 1 434 1765
addStep 1 434 1765
assign 1 435 1766
parentGet 0 435 1766
assign 1 435 1767
addStep 1 435 1767
assign 1 436 1768
parentGet 0 436 1768
assign 1 436 1769
fileGet 0 436 1769
assign 1 436 1770
existsGet 0 436 1770
assign 1 436 1771
not 0 436 1776
assign 1 437 1777
parentGet 0 437 1777
assign 1 437 1778
fileGet 0 437 1778
makeDirs 0 437 1779
assign 1 439 1781
fileGet 0 439 1781
assign 1 439 1782
writerGet 0 439 1782
assign 1 439 1783
open 0 439 1783
assign 1 440 1784
fileGet 0 440 1784
assign 1 440 1785
writerGet 0 440 1785
assign 1 440 1786
open 0 440 1786
assign 1 442 1787
paramsGet 0 442 1787
assign 1 442 1788
new 0 442 1788
assign 1 442 1789
has 1 442 1789
assign 1 444 1791
paramsGet 0 444 1791
assign 1 444 1792
new 0 444 1792
assign 1 444 1793
get 1 444 1793
assign 1 444 1794
iteratorGet 0 0 1794
assign 1 444 1797
hasNextGet 0 444 1797
assign 1 444 1799
nextGet 0 444 1799
assign 1 446 1800
apNew 1 446 1800
assign 1 446 1801
fileGet 0 446 1801
assign 1 447 1802
readerGet 0 447 1802
assign 1 447 1803
open 0 447 1803
assign 1 447 1804
readString 0 447 1804
assign 1 448 1805
readerGet 0 448 1805
close 0 448 1806
write 1 450 1807
assign 1 454 1814
new 0 454 1814
write 1 454 1815
assign 1 455 1816
new 0 455 1816
write 1 455 1817
assign 1 457 1818
new 0 457 1818
write 1 457 1819
assign 1 458 1820
new 0 458 1820
write 1 458 1821
assign 1 464 1822
paramsGet 0 464 1822
assign 1 464 1823
new 0 464 1823
assign 1 464 1824
has 1 464 1824
assign 1 466 1826
paramsGet 0 466 1826
assign 1 466 1827
new 0 466 1827
assign 1 466 1828
get 1 466 1828
assign 1 466 1829
iteratorGet 0 0 1829
assign 1 466 1832
hasNextGet 0 466 1832
assign 1 466 1834
nextGet 0 466 1834
assign 1 468 1835
apNew 1 468 1835
assign 1 468 1836
fileGet 0 468 1836
assign 1 469 1837
readerGet 0 469 1837
assign 1 469 1838
open 0 469 1838
assign 1 469 1839
readString 0 469 1839
assign 1 470 1840
readerGet 0 470 1840
close 0 470 1841
write 1 472 1842
assign 1 475 1849
paramsGet 0 475 1849
assign 1 475 1850
new 0 475 1850
assign 1 475 1851
has 1 475 1851
assign 1 477 1853
paramsGet 0 477 1853
assign 1 477 1854
new 0 477 1854
assign 1 477 1855
get 1 477 1855
assign 1 477 1856
iteratorGet 0 0 1856
assign 1 477 1859
hasNextGet 0 477 1859
assign 1 477 1861
nextGet 0 477 1861
assign 1 479 1862
apNew 1 479 1862
assign 1 479 1863
fileGet 0 479 1863
assign 1 480 1864
readerGet 0 480 1864
assign 1 480 1865
open 0 480 1865
assign 1 480 1866
readString 0 480 1866
assign 1 481 1867
readerGet 0 481 1867
close 0 481 1868
write 1 483 1869
begin 1 490 1880
prepHeaderOutput 0 491 1881
assign 1 496 1924
undef 1 496 1929
assign 1 497 1930
new 0 497 1930
assign 1 498 1931
parentGet 0 498 1931
assign 1 498 1932
fileGet 0 498 1932
assign 1 498 1933
existsGet 0 498 1933
assign 1 498 1934
not 0 498 1939
assign 1 499 1940
parentGet 0 499 1940
assign 1 499 1941
fileGet 0 499 1941
makeDirs 0 499 1942
assign 1 501 1944
fileGet 0 501 1944
assign 1 501 1945
writerGet 0 501 1945
assign 1 501 1946
open 0 501 1946
assign 1 503 1947
new 0 503 1947
write 1 503 1948
assign 1 505 1949
paramsGet 0 505 1949
assign 1 505 1950
new 0 505 1950
assign 1 505 1951
has 1 505 1951
assign 1 507 1953
paramsGet 0 507 1953
assign 1 507 1954
new 0 507 1954
assign 1 507 1955
get 1 507 1955
assign 1 507 1956
iteratorGet 0 0 1956
assign 1 507 1959
hasNextGet 0 507 1959
assign 1 507 1961
nextGet 0 507 1961
assign 1 509 1962
apNew 1 509 1962
assign 1 509 1963
fileGet 0 509 1963
assign 1 510 1964
readerGet 0 510 1964
assign 1 510 1965
open 0 510 1965
assign 1 510 1966
readString 0 510 1966
assign 1 511 1967
readerGet 0 511 1967
close 0 511 1968
write 1 513 1969
assign 1 517 1976
new 0 517 1976
write 1 517 1977
increment 0 518 1978
assign 1 519 1979
paramsGet 0 519 1979
assign 1 519 1980
new 0 519 1980
assign 1 519 1981
has 1 519 1981
assign 1 520 1983
paramsGet 0 520 1983
assign 1 520 1984
new 0 520 1984
assign 1 520 1985
get 1 520 1985
assign 1 520 1986
iteratorGet 0 0 1986
assign 1 520 1989
hasNextGet 0 520 1989
assign 1 520 1991
nextGet 0 520 1991
assign 1 521 1992
apNew 1 521 1992
assign 1 521 1993
fileGet 0 521 1993
assign 1 522 1994
readerGet 0 522 1994
assign 1 522 1995
open 0 522 1995
assign 1 522 1996
readString 0 522 1996
assign 1 523 1997
readerGet 0 523 1997
close 0 523 1998
assign 1 524 1999
countLines 1 524 1999
addValue 1 524 2000
write 1 525 2001
return 1 531 2009
close 0 535 2014
assign 1 536 2015
assign 1 538 2016
new 0 538 2016
write 1 538 2017
assign 1 540 2018
new 0 540 2018
write 1 540 2019
close 0 541 2020
close 0 542 2021
assign 1 547 2026
new 0 547 2026
return 1 547 2027
assign 1 551 2034
new 0 551 2034
assign 1 551 2035
addValue 1 551 2035
assign 1 551 2036
addValue 1 551 2036
assign 1 551 2037
new 0 551 2037
addValue 1 551 2038
assign 1 556 2060
heldGet 0 556 2060
assign 1 556 2061
synGet 0 556 2061
assign 1 557 2062
ptyListGet 0 557 2062
assign 1 559 2063
emitNameGet 0 559 2063
assign 1 559 2064
addValue 1 559 2064
assign 1 559 2065
new 0 559 2065
addValue 1 559 2066
assign 1 561 2067
new 0 561 2067
assign 1 562 2068
iteratorGet 0 0 2068
assign 1 562 2071
hasNextGet 0 562 2071
assign 1 562 2073
nextGet 0 562 2073
assign 1 564 2075
new 0 564 2075
assign 1 566 2078
new 0 566 2078
addValue 1 566 2079
assign 1 568 2081
addValue 1 568 2081
assign 1 568 2082
new 0 568 2082
assign 1 568 2083
addValue 1 568 2083
assign 1 568 2084
nameGet 0 568 2084
assign 1 568 2085
addValue 1 568 2085
addValue 1 568 2086
assign 1 572 2092
new 0 572 2092
assign 1 572 2093
addValue 1 572 2093
addValue 1 572 2094
assign 1 577 2114
new 0 577 2114
assign 1 579 2115
new 0 579 2115
assign 1 579 2116
emitNameGet 0 579 2116
assign 1 579 2117
add 1 579 2117
assign 1 579 2118
new 0 579 2118
assign 1 579 2119
add 1 579 2119
assign 1 581 2120
emitNameGet 0 581 2120
assign 1 581 2121
addValue 1 581 2121
assign 1 581 2122
new 0 581 2122
assign 1 581 2123
addValue 1 581 2123
assign 1 581 2124
emitNameGet 0 581 2124
assign 1 581 2125
addValue 1 581 2125
assign 1 581 2126
new 0 581 2126
assign 1 581 2127
addValue 1 581 2127
assign 1 581 2128
addValue 1 581 2128
assign 1 581 2129
new 0 581 2129
addValue 1 581 2130
return 1 583 2131
assign 1 587 2140
libNameGet 0 587 2140
assign 1 587 2141
relEmitName 1 587 2141
assign 1 588 2142
new 0 588 2142
assign 1 588 2143
add 1 588 2143
assign 1 588 2144
new 0 588 2144
assign 1 588 2145
add 1 588 2145
return 1 589 2146
assign 1 593 2158
libNameGet 0 593 2158
assign 1 593 2159
relEmitName 1 593 2159
assign 1 594 2160
new 0 594 2160
assign 1 594 2161
add 1 594 2161
assign 1 594 2162
new 0 594 2162
assign 1 594 2163
add 1 594 2163
assign 1 595 2164
new 0 595 2164
assign 1 595 2165
add 1 595 2165
assign 1 595 2166
add 1 595 2166
return 1 595 2167
assign 1 599 2172
new 0 599 2172
assign 1 599 2173
add 1 599 2173
return 1 599 2174
assign 1 603 2267
getClassConfig 1 603 2267
assign 1 603 2268
libNameGet 0 603 2268
assign 1 603 2269
relEmitName 1 603 2269
assign 1 604 2270
heldGet 0 604 2270
assign 1 604 2271
namepathGet 0 604 2271
assign 1 604 2272
getClassConfig 1 604 2272
assign 1 605 2273
getInitialInst 1 605 2273
assign 1 607 2274
overrideMtdDecGet 0 607 2274
assign 1 607 2275
addValue 1 607 2275
assign 1 607 2276
new 0 607 2276
assign 1 607 2277
addValue 1 607 2277
assign 1 607 2278
emitNameGet 0 607 2278
assign 1 607 2279
addValue 1 607 2279
assign 1 607 2280
new 0 607 2280
assign 1 607 2281
addValue 1 607 2281
assign 1 607 2282
addValue 1 607 2282
assign 1 607 2283
new 0 607 2283
assign 1 607 2284
addValue 1 607 2284
assign 1 607 2285
addValue 1 607 2285
assign 1 607 2286
new 0 607 2286
assign 1 607 2287
addValue 1 607 2287
addValue 1 607 2288
assign 1 608 2289
new 0 608 2289
assign 1 609 2290
emitNameGet 0 609 2290
assign 1 609 2291
notEquals 1 609 2291
assign 1 610 2293
new 0 610 2293
assign 1 610 2294
formCast 3 610 2294
assign 1 613 2296
addValue 1 613 2296
assign 1 613 2297
new 0 613 2297
assign 1 613 2298
addValue 1 613 2298
assign 1 613 2299
addValue 1 613 2299
assign 1 613 2300
new 0 613 2300
assign 1 613 2301
addValue 1 613 2301
addValue 1 613 2302
assign 1 615 2303
new 0 615 2303
assign 1 615 2304
addValue 1 615 2304
addValue 1 615 2305
assign 1 618 2306
overrideMtdDecGet 0 618 2306
assign 1 618 2307
addValue 1 618 2307
assign 1 618 2308
addValue 1 618 2308
assign 1 618 2309
new 0 618 2309
assign 1 618 2310
addValue 1 618 2310
assign 1 618 2311
emitNameGet 0 618 2311
assign 1 618 2312
addValue 1 618 2312
assign 1 618 2313
new 0 618 2313
assign 1 618 2314
addValue 1 618 2314
assign 1 618 2315
addValue 1 618 2315
assign 1 618 2316
new 0 618 2316
assign 1 618 2317
addValue 1 618 2317
addValue 1 618 2318
assign 1 623 2319
new 0 623 2319
assign 1 623 2320
addValue 1 623 2320
assign 1 623 2321
addValue 1 623 2321
assign 1 623 2322
new 0 623 2322
assign 1 623 2323
addValue 1 623 2323
addValue 1 623 2324
assign 1 626 2325
new 0 626 2325
assign 1 626 2326
addValue 1 626 2326
addValue 1 626 2327
assign 1 628 2328
overrideMtdDecGet 0 628 2328
assign 1 628 2329
addValue 1 628 2329
assign 1 628 2330
new 0 628 2330
assign 1 628 2331
addValue 1 628 2331
assign 1 628 2332
emitNameGet 0 628 2332
assign 1 628 2333
addValue 1 628 2333
assign 1 628 2334
new 0 628 2334
assign 1 628 2335
addValue 1 628 2335
assign 1 628 2336
addValue 1 628 2336
assign 1 628 2337
new 0 628 2337
assign 1 628 2338
addValue 1 628 2338
addValue 1 628 2339
assign 1 629 2340
heldGet 0 629 2340
assign 1 629 2341
extendsGet 0 629 2341
assign 1 629 2342
undef 1 629 2347
assign 1 0 2348
assign 1 629 2351
heldGet 0 629 2351
assign 1 629 2352
extendsGet 0 629 2352
assign 1 629 2353
equals 1 629 2353
assign 1 0 2355
assign 1 0 2358
assign 1 630 2362
new 0 630 2362
assign 1 630 2363
addValue 1 630 2363
addValue 1 630 2364
assign 1 632 2367
new 0 632 2367
assign 1 632 2368
addValue 1 632 2368
addValue 1 632 2369
addValue 1 634 2371
clear 0 635 2372
assign 1 638 2373
new 0 638 2373
assign 1 638 2374
addValue 1 638 2374
addValue 1 638 2375
assign 1 640 2376
getTypeInst 1 640 2376
assign 1 642 2377
new 0 642 2377
assign 1 642 2378
addValue 1 642 2378
assign 1 642 2379
emitNameGet 0 642 2379
assign 1 642 2380
addValue 1 642 2380
assign 1 642 2381
new 0 642 2381
assign 1 642 2382
addValue 1 642 2382
addValue 1 642 2383
assign 1 644 2384
new 0 644 2384
assign 1 644 2385
addValue 1 644 2385
assign 1 644 2386
addValue 1 644 2386
assign 1 644 2387
new 0 644 2387
assign 1 644 2388
addValue 1 644 2388
addValue 1 644 2389
assign 1 646 2390
new 0 646 2390
assign 1 646 2391
addValue 1 646 2391
addValue 1 646 2392
assign 1 652 2398
new 0 652 2398
write 1 652 2399
assign 1 653 2400
new 0 653 2400
write 1 653 2401
emitLib 0 655 2402
assign 1 660 2415
libNameGet 0 660 2415
assign 1 660 2416
relEmitName 1 660 2416
assign 1 661 2417
new 0 661 2417
assign 1 661 2418
add 1 661 2418
assign 1 661 2419
new 0 661 2419
assign 1 661 2420
add 1 661 2420
assign 1 662 2421
new 0 662 2421
assign 1 662 2422
add 1 662 2422
assign 1 662 2423
add 1 662 2423
return 1 662 2424
return 1 0 2427
return 1 0 2430
assign 1 0 2433
assign 1 0 2437
return 1 0 2441
return 1 0 2444
assign 1 0 2447
assign 1 0 2451
return 1 0 2455
return 1 0 2458
assign 1 0 2461
assign 1 0 2465
return 1 0 2469
return 1 0 2472
assign 1 0 2475
assign 1 0 2479
return 1 0 2483
return 1 0 2486
assign 1 0 2489
assign 1 0 2493
return 1 0 2497
return 1 0 2500
assign 1 0 2503
assign 1 0 2507
return 1 0 2511
return 1 0 2514
assign 1 0 2517
assign 1 0 2521
return 1 0 2525
return 1 0 2528
assign 1 0 2531
assign 1 0 2535
return 1 0 2539
return 1 0 2542
assign 1 0 2545
assign 1 0 2549
return 1 0 2553
return 1 0 2556
assign 1 0 2559
assign 1 0 2563
return 1 0 2567
return 1 0 2570
assign 1 0 2573
assign 1 0 2577
return 1 0 2581
return 1 0 2584
assign 1 0 2587
assign 1 0 2591
return 1 0 2595
return 1 0 2598
assign 1 0 2601
assign 1 0 2605
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 179191360: return bem_shlibeGetDirect_0();
case -1093085716: return bem_lastMethodsLinesGetDirect_0();
case -283396003: return bem_classEndGet_0();
case -754551371: return bem_smnlcsGetDirect_0();
case 1004853414: return bem_libEmitNameGet_0();
case 72694489: return bem_stringNpGet_0();
case -1588608331: return bem_iteratorGet_0();
case -1602918313: return bem_idToNamePathGet_0();
case 1161293428: return bem_classCallsGet_0();
case 95401045: return bem_preClassOutput_0();
case 1128077718: return bem_classHeadersGet_0();
case 1564374252: return bem_ccCacheGet_0();
case 1202859281: return bem_fieldIteratorGet_0();
case 1557144728: return bem_superNameGet_0();
case 2029762031: return bem_typeDecGet_0();
case 56079504: return bem_classEmitsGetDirect_0();
case -1396976187: return bem_buildPropList_0();
case -603645081: return bem_propertyDecsGet_0();
case 311591306: return bem_heopGetDirect_0();
case 1380050120: return bem_maxSpillArgsLenGet_0();
case -2112752566: return bem_doEmit_0();
case 1110294080: return bem_nameToIdPathGet_0();
case -1627101286: return bem_many_0();
case -100814457: return bem_ntypesGetDirect_0();
case 582860610: return bem_methodBodyGet_0();
case 1512066816: return bem_getLibOutput_0();
case -1845643109: return bem_getClassOutput_0();
case -513219895: return bem_parentConfGetDirect_0();
case 786795891: return bem_cnodeGet_0();
case 844624122: return bem_classHeadBodyGetDirect_0();
case -4634496: return bem_once_0();
case 1246209306: return bem_buildGetDirect_0();
case -1111347317: return bem_gcMarksGetDirect_0();
case -1721224705: return bem_copy_0();
case -1556518060: return bem_saveSyns_0();
case 303589218: return bem_boolCcGetDirect_0();
case 419402773: return bem_fieldNamesGet_0();
case 2025123065: return bem_idToNamePathGetDirect_0();
case -479976948: return bem_classesInDepthOrderGetDirect_0();
case -1958763688: return bem_onceDecRefsCountGetDirect_0();
case -1561631662: return bem_libEmitNameGetDirect_0();
case 1722495918: return bem_prepHeaderOutput_0();
case -353694220: return bem_constGet_0();
case 149646750: return bem_callNamesGet_0();
case -1865178957: return bem_idToNameGet_0();
case 1210303768: return bem_intNpGet_0();
case 242917326: return bem_mainOutsideNsGet_0();
case -459295076: return bem_propDecGet_0();
case -1927067601: return bem_instanceNotEqualGet_0();
case 868332592: return bem_superCallsGet_0();
case -314683662: return bem_trueValueGet_0();
case 1391064500: return bem_boolCcGet_0();
case -467957724: return bem_objectNpGetDirect_0();
case 286110200: return bem_headExtGet_0();
case 1906031473: return bem_headExtGetDirect_0();
case 1662643176: return bem_new_0();
case -1313732597: return bem_deopGetDirect_0();
case -831042054: return bem_deonGet_0();
case 1206855817: return bem_onceCountGet_0();
case -344629384: return bem_superCallsGetDirect_0();
case 1759078114: return bem_lastCallGet_0();
case -171689742: return bem_classCallsGetDirect_0();
case 2142058906: return bem_coanyiantReturnsGet_0();
case 1597561486: return bem_initialDecGet_0();
case 974008916: return bem_qGetDirect_0();
case 1839420530: return bem_mainStartGet_0();
case -497698315: return bem_smnlecsGetDirect_0();
case -1760283647: return bem_sourceFileNameGet_0();
case -1699295924: return bem_dynMethodsGet_0();
case 470691008: return bem_methodCatchGet_0();
case 147269736: return bem_preClassGet_0();
case -489591995: return bem_lastCallGetDirect_0();
case -1062799150: return bem_loadIds_0();
case -207635536: return bem_objectCcGet_0();
case -1276527172: return bem_deonGetDirect_0();
case 1761864287: return bem_lastMethodBodyLinesGetDirect_0();
case -315881346: return bem_setOutputTimeGetDirect_0();
case 742999095: return bem_mnodeGetDirect_0();
case 130322879: return bem_methodsGetDirect_0();
case 2111755914: return bem_inClassGet_0();
case -167591032: return bem_classHeadersGetDirect_0();
case 1046565625: return bem_deowGet_0();
case -387900945: return bem_floatNpGetDirect_0();
case -115926348: return bem_nlGetDirect_0();
case 335195916: return bem_trueValueGetDirect_0();
case -1095636681: return bem_idToNameGetDirect_0();
case -872325961: return bem_classConfGet_0();
case 1394903963: return bem_maxSpillArgsLenGetDirect_0();
case -1521156245: return bem_instOfGetDirect_0();
case -910709803: return bem_falseValueGet_0();
case -982910531: return bem_floatNpGet_0();
case -1692893660: return bem_synEmitPathGetDirect_0();
case -1855742442: return bem_deserializeClassNameGet_0();
case 1191480107: return bem_randGetDirect_0();
case -144607300: return bem_emitLangGetDirect_0();
case -2075550655: return bem_maxDynArgsGetDirect_0();
case 521705053: return bem_afterCast_0();
case 272848921: return bem_lineCountGet_0();
case 323304959: return bem_fullLibEmitNameGet_0();
case 646945866: return bem_runtimeInitGet_0();
case -1885688168: return bem_scvpGetDirect_0();
case 1475961368: return bem_inFilePathedGetDirect_0();
case -1234434160: return bem_lineCountGetDirect_0();
case 737627600: return bem_classNameGet_0();
case -119541260: return bem_onceDecsGet_0();
case 595465554: return bem_msynGetDirect_0();
case -550587972: return bem_lastMethodBodyLinesGet_0();
case -659220089: return bem_onceCountGetDirect_0();
case -2124219423: return bem_methodsGet_0();
case -1037835868: return bem_heonGet_0();
case -2028012180: return bem_randGet_0();
case 358183114: return bem_buildInitial_0();
case -1530362442: return bem_onceDecsGetDirect_0();
case 2098731743: return bem_dynMethodsGetDirect_0();
case 1501482800: return bem_stringNpGetDirect_0();
case -1060640173: return bem_fullLibEmitNameGetDirect_0();
case 459784483: return bem_fileExtGetDirect_0();
case -388340383: return bem_csynGetDirect_0();
case -362750095: return bem_nameToIdGetDirect_0();
case 854609813: return bem_mnodeGet_0();
case 939629729: return bem_lastMethodsLinesGet_0();
case 2035599254: return bem_endNs_0();
case 576221642: return bem_lastMethodsSizeGet_0();
case 939185730: return bem_buildGet_0();
case -1556234938: return bem_boolTypeGet_0();
case 1267836020: return bem_cnodeGetDirect_0();
case 586787044: return bem_toAny_0();
case 2116805682: return bem_fileExtGet_0();
case 211374093: return bem_boolNpGet_0();
case -1470992263: return bem_baseMtdDecGet_0();
case -165877765: return bem_create_0();
case -1842285567: return bem_useDynMethodsGet_0();
case -1915645260: return bem_baseSmtdDecGet_0();
case 118898673: return bem_deopGet_0();
case 835192816: return bem_methodCatchGetDirect_0();
case -1650946699: return bem_emitLib_0();
case 72488635: return bem_falseValueGetDirect_0();
case 1113228370: return bem_preClassGetDirect_0();
case -597701970: return bem_lastMethodBodySizeGetDirect_0();
case -511925450: return bem_buildClassInfo_0();
case -137209775: return bem_transGetDirect_0();
case -653168993: return bem_constGetDirect_0();
case -1178068153: return bem_invpGetDirect_0();
case 132357516: return bem_onceDecRefsGetDirect_0();
case -1287234058: return bem_instanceEqualGet_0();
case -494242792: return bem_overrideMtdDecGet_0();
case 276470433: return bem_exceptDecGet_0();
case 1800213309: return bem_serializeContents_0();
case 441265266: return bem_beginNs_0();
case -392511625: return bem_classesInDepthOrderGet_0();
case 981768014: return bem_mainInClassGet_0();
case 2032439951: return bem_smnlcsGet_0();
case -975986011: return bem_boolNpGetDirect_0();
case -695988398: return bem_inClassGetDirect_0();
case 1218991193: return bem_heopGet_0();
case -511071132: return bem_spropDecGet_0();
case -252928832: return bem_classEmitsGet_0();
case 469439634: return bem_classHeadBodyGet_0();
case 2039853873: return bem_writeBET_0();
case 1560728406: return bem_invpGet_0();
case -664128834: return bem_ccCacheGetDirect_0();
case -1761834400: return bem_gcMarksGet_0();
case -12708128: return bem_hashGet_0();
case -846048525: return bem_nativeCSlotsGet_0();
case -745232665: return bem_objectCcGetDirect_0();
case 362800146: return bem_heowGetDirect_0();
case 1037754520: return bem_deowGetDirect_0();
case -169510412: return bem_toString_0();
case -1862621457: return bem_saveIds_0();
case 336704923: return bem_parentConfGet_0();
case -1618970282: return bem_setOutputTimeGet_0();
case -109234441: return bem_csynGet_0();
case -1566162686: return bem_lastMethodBodySizeGet_0();
case -993617581: return bem_buildCreate_0();
case 262231222: return bem_exceptDecGetDirect_0();
case -510558373: return bem_propertyDecsGetDirect_0();
case -1198649333: return bem_returnTypeGetDirect_0();
case 1999833548: return bem_onceDecRefsCountGet_0();
case 1515796479: return bem_returnTypeGet_0();
case -971903410: return bem_heonGetDirect_0();
case -179811431: return bem_instanceNotEqualGetDirect_0();
case -1143466111: return bem_classConfGetDirect_0();
case -2059713661: return bem_transGet_0();
case -788364745: return bem_methodCallsGetDirect_0();
case 1816155455: return bem_ccMethodsGetDirect_0();
case -907262473: return bem_synEmitPathGet_0();
case 221369236: return bem_echo_0();
case -1397891100: return bem_methodBodyGetDirect_0();
case -842086118: return bem_shlibeGet_0();
case 1166902012: return bem_print_0();
case -9710743: return bem_objectNpGet_0();
case 1426087889: return bem_emitLangGet_0();
case -141131113: return bem_onceDecRefsGet_0();
case 1550410170: return bem_mainEndGet_0();
case 1017932049: return bem_nativeCSlotsGetDirect_0();
case 732780796: return bem_nullValueGetDirect_0();
case 31598141: return bem_maxDynArgsGet_0();
case -1145946037: return bem_serializeToString_0();
case 1347630701: return bem_libEmitPathGetDirect_0();
case -1869540263: return bem_nullValueGet_0();
case 1722509898: return bem_libEmitPathGet_0();
case -458279913: return bem_serializationIteratorGet_0();
case -1200024888: return bem_tagGet_0();
case 1853279452: return bem_nlGet_0();
case 539454243: return bem_heowGet_0();
case 540632450: return bem_nameToIdPathGetDirect_0();
case 1054621592: return bem_ntypesGet_0();
case -1623059821: return bem_nameToIdGet_0();
case 192917752: return bem_intNpGetDirect_0();
case 2127277089: return bem_scvpGet_0();
case 2057711701: return bem_callNamesGetDirect_0();
case -445282875: return bem_inFilePathedGet_0();
case -1580484215: return bem_qGet_0();
case 994892288: return bem_smnlecsGet_0();
case -1637057300: return bem_lastMethodsSizeGetDirect_0();
case -1653153035: return bem_ccMethodsGet_0();
case 113219868: return bem_methodCallsGet_0();
case -471107257: return bem_instanceEqualGetDirect_0();
case -710568213: return bem_instOfGet_0();
case -1195198401: return bem_msynGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1562636847: return bem_dynMethodsSetDirect_1(bevd_0);
case -254218891: return bem_methodCallsSet_1(bevd_0);
case -399368056: return bem_libEmitPathSetDirect_1(bevd_0);
case -1960951718: return bem_methodsSet_1(bevd_0);
case 1534631981: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1762361048: return bem_returnTypeSet_1(bevd_0);
case -2050626933: return bem_def_1(bevd_0);
case -611884541: return bem_onceDecRefsSetDirect_1(bevd_0);
case 35519170: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1819288759: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1491999499: return bem_lastCallSetDirect_1(bevd_0);
case -559052675: return bem_exceptDecSet_1(bevd_0);
case 1465608210: return bem_boolNpSetDirect_1(bevd_0);
case -994087512: return bem_lastCallSet_1(bevd_0);
case -851506663: return bem_stringNpSetDirect_1(bevd_0);
case -1335788945: return bem_scvpSetDirect_1(bevd_0);
case 1855029601: return bem_nameToIdSet_1(bevd_0);
case -17941591: return bem_deowSet_1(bevd_0);
case 326094850: return bem_returnTypeSetDirect_1(bevd_0);
case 391411053: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1457743409: return bem_deonSetDirect_1(bevd_0);
case 55240576: return bem_ccCacheSet_1(bevd_0);
case 384919535: return bem_instanceEqualSetDirect_1(bevd_0);
case -1288986837: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1989092718: return bem_nlSetDirect_1(bevd_0);
case 1029495916: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1072436581: return bem_classHeadersSetDirect_1(bevd_0);
case 431414030: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -119189706: return bem_methodBodySetDirect_1(bevd_0);
case -409395627: return bem_idToNamePathSet_1(bevd_0);
case 45250919: return bem_instanceNotEqualSet_1(bevd_0);
case -1370932579: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -3837837: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1101654971: return bem_heonSet_1(bevd_0);
case -1535611993: return bem_heopSetDirect_1(bevd_0);
case -481622398: return bem_invpSet_1(bevd_0);
case -1662912450: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1166090576: return bem_transSetDirect_1(bevd_0);
case 1013341233: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1906002079: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1421424282: return bem_objectNpSetDirect_1(bevd_0);
case 542060779: return bem_heopSet_1(bevd_0);
case 1209838081: return bem_buildSet_1(bevd_0);
case 50067596: return bem_deopSet_1(bevd_0);
case 2029816561: return bem_qSet_1(bevd_0);
case -306633068: return bem_undefined_1(bevd_0);
case -1672157279: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1105338352: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 286179063: return bem_copyTo_1(bevd_0);
case 1155805267: return bem_onceDecRefsCountSet_1(bevd_0);
case -1880368515: return bem_notEquals_1(bevd_0);
case 1951320212: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 598994785: return bem_lineCountSet_1(bevd_0);
case 1650003521: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1565569812: return bem_nameToIdSetDirect_1(bevd_0);
case -309965282: return bem_falseValueSet_1(bevd_0);
case 394072620: return bem_heowSet_1(bevd_0);
case 2112027131: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1265971461: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 190499273: return bem_headExtSet_1(bevd_0);
case -91912175: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 401839231: return bem_idToNameSetDirect_1(bevd_0);
case 983144175: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 704252345: return bem_cnodeSetDirect_1(bevd_0);
case -1979116079: return bem_emitLangSet_1(bevd_0);
case -2038137777: return bem_otherType_1(bevd_0);
case 119621604: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1725008072: return bem_buildSetDirect_1(bevd_0);
case 791870347: return bem_invpSetDirect_1(bevd_0);
case 1110395429: return bem_smnlcsSet_1(bevd_0);
case 1396222332: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1900841537: return bem_ccMethodsSetDirect_1(bevd_0);
case 993208196: return bem_preClassSet_1(bevd_0);
case 1883996725: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 799464576: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1578461083: return bem_methodsSetDirect_1(bevd_0);
case 938189990: return bem_maxSpillArgsLenSet_1(bevd_0);
case 963552784: return bem_emitLangSetDirect_1(bevd_0);
case -1034492196: return bem_stringNpSet_1(bevd_0);
case -2030297825: return bem_heonSetDirect_1(bevd_0);
case -1058481552: return bem_undef_1(bevd_0);
case 233378828: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -391905348: return bem_instanceEqualSet_1(bevd_0);
case 1691066355: return bem_falseValueSetDirect_1(bevd_0);
case -1486790811: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1879322390: return bem_inClassSetDirect_1(bevd_0);
case 247975749: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1793219583: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1990443100: return bem_nameToIdPathSet_1(bevd_0);
case 904038627: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1064363565: return bem_synEmitPathSetDirect_1(bevd_0);
case 446646701: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1174135522: return bem_sameType_1(bevd_0);
case 2008433664: return bem_gcMarksSetDirect_1(bevd_0);
case 192526423: return bem_ntypesSetDirect_1(bevd_0);
case 1127647431: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -141782472: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 436934077: return bem_classHeadersSet_1(bevd_0);
case 1113875953: return bem_nativeCSlotsSet_1(bevd_0);
case -1600997438: return bem_onceDecRefsSet_1(bevd_0);
case 69420446: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1776159439: return bem_fullLibEmitNameSet_1(bevd_0);
case -1618710767: return bem_callNamesSetDirect_1(bevd_0);
case 1931852804: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2132180555: return bem_methodBodySet_1(bevd_0);
case -1913671571: return bem_preClassSetDirect_1(bevd_0);
case 1520364034: return bem_trueValueSetDirect_1(bevd_0);
case 806739242: return bem_propertyDecsSet_1(bevd_0);
case 1396328003: return bem_otherClass_1(bevd_0);
case 1758865233: return bem_deonSet_1(bevd_0);
case 1693025540: return bem_onceCountSet_1(bevd_0);
case -1617140536: return bem_defined_1(bevd_0);
case -39697458: return bem_headExtSetDirect_1(bevd_0);
case 1793503524: return bem_classCallsSet_1(bevd_0);
case 258335862: return bem_ccMethodsSet_1(bevd_0);
case 1616376889: return bem_smnlcsSetDirect_1(bevd_0);
case -1154445750: return bem_classHeadBodySet_1(bevd_0);
case 720390236: return bem_nullValueSetDirect_1(bevd_0);
case 1689964653: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1600111015: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 2146235744: return bem_mnodeSet_1(bevd_0);
case 1057780314: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1162058423: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1802945522: return bem_objectNpSet_1(bevd_0);
case -1479148419: return bem_deowSetDirect_1(bevd_0);
case -347192012: return bem_callNamesSet_1(bevd_0);
case -270678816: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1563933337: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -277133471: return bem_superCallsSet_1(bevd_0);
case 1554251407: return bem_instOfSet_1(bevd_0);
case -551560068: return bem_classConfSet_1(bevd_0);
case -1549712255: return bem_shlibeSet_1(bevd_0);
case 136184828: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 354761634: return bem_onceDecsSet_1(bevd_0);
case -708546940: return bem_methodCallsSetDirect_1(bevd_0);
case -2014335012: return bem_inFilePathedSet_1(bevd_0);
case 1651797817: return bem_fileExtSet_1(bevd_0);
case -39094467: return bem_equals_1(bevd_0);
case 1819630603: return bem_methodCatchSetDirect_1(bevd_0);
case 709495499: return bem_libEmitNameSetDirect_1(bevd_0);
case 1112090867: return bem_ccCacheSetDirect_1(bevd_0);
case -802514914: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1703903046: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -996092370: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1625505230: return bem_classConfSetDirect_1(bevd_0);
case 1039180755: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2047027206: return bem_inClassSet_1(bevd_0);
case 1546990352: return bem_randSetDirect_1(bevd_0);
case 1069002684: return bem_nlSet_1(bevd_0);
case -474283486: return bem_constSetDirect_1(bevd_0);
case -105827489: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1706157484: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -389055345: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 405456764: return bem_methodCatchSet_1(bevd_0);
case -247570810: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 143964122: return bem_msynSet_1(bevd_0);
case -522336170: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1122974173: return bem_mnodeSetDirect_1(bevd_0);
case -1322944702: return bem_classesInDepthOrderSet_1(bevd_0);
case 1075106586: return bem_objectCcSetDirect_1(bevd_0);
case -1246086623: return bem_dynMethodsSet_1(bevd_0);
case -215710596: return bem_shlibeSetDirect_1(bevd_0);
case 505817994: return bem_classEmitsSet_1(bevd_0);
case 1714373942: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1861777358: return bem_floatNpSetDirect_1(bevd_0);
case -1846429143: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -327804541: return bem_sameClass_1(bevd_0);
case -1704365736: return bem_inFilePathedSetDirect_1(bevd_0);
case 132724474: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 2055336408: return bem_trueValueSet_1(bevd_0);
case -1357866619: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 67808698: return bem_objectCcSet_1(bevd_0);
case -539267871: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1012390097: return bem_randSet_1(bevd_0);
case -615350166: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 824971765: return bem_parentConfSet_1(bevd_0);
case 1268228847: return bem_lastMethodsSizeSet_1(bevd_0);
case 1621576845: return bem_gcMarksSet_1(bevd_0);
case 553606270: return bem_onceCountSetDirect_1(bevd_0);
case 545784370: return bem_instOfSetDirect_1(bevd_0);
case -1564495303: return bem_classCallsSetDirect_1(bevd_0);
case -62789474: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1370505311: return bem_ntypesSet_1(bevd_0);
case -1556993688: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 782862832: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1127120159: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1932865217: return bem_boolNpSet_1(bevd_0);
case 1416118972: return bem_lastMethodBodySizeSet_1(bevd_0);
case 179176223: return bem_classEmitsSetDirect_1(bevd_0);
case -942165513: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case 956362021: return bem_boolCcSet_1(bevd_0);
case -36170533: return bem_heowSetDirect_1(bevd_0);
case 581506878: return bem_constSet_1(bevd_0);
case -1475578133: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1651232842: return bem_maxDynArgsSet_1(bevd_0);
case -883889211: return bem_sameObject_1(bevd_0);
case 1805860734: return bem_begin_1(bevd_0);
case -833366957: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -470700470: return bem_lastMethodsLinesSet_1(bevd_0);
case 358261798: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 2086963771: return bem_idToNameSet_1(bevd_0);
case 563793854: return bem_onceDecRefsCountSetDirect_1(bevd_0);
case -1628869730: return bem_intNpSetDirect_1(bevd_0);
case 244252646: return bem_csynSet_1(bevd_0);
case 476693313: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -591380070: return bem_onceDecsSetDirect_1(bevd_0);
case 1995527400: return bem_scvpSet_1(bevd_0);
case -415670029: return bem_setOutputTimeSetDirect_1(bevd_0);
case -1288825320: return bem_deopSetDirect_1(bevd_0);
case 764885426: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1143294403: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1493716971: return bem_libEmitPathSet_1(bevd_0);
case 755887257: return bem_intNpSet_1(bevd_0);
case -1747720323: return bem_smnlecsSet_1(bevd_0);
case 1725086001: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 100163209: return bem_exceptDecSetDirect_1(bevd_0);
case -1694968514: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1495601791: return bem_csynSetDirect_1(bevd_0);
case -1807364215: return bem_parentConfSetDirect_1(bevd_0);
case -467393701: return bem_superCallsSetDirect_1(bevd_0);
case -409899450: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -726465964: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1000720093: return bem_fileExtSetDirect_1(bevd_0);
case 752789578: return bem_nullValueSet_1(bevd_0);
case 1300996026: return bem_smnlecsSetDirect_1(bevd_0);
case -1962509606: return bem_libEmitNameSet_1(bevd_0);
case -1486548250: return bem_cnodeSet_1(bevd_0);
case -43112724: return bem_lineCountSetDirect_1(bevd_0);
case 1936389329: return bem_msynSetDirect_1(bevd_0);
case -675740584: return bem_boolCcSetDirect_1(bevd_0);
case 1116577203: return bem_end_1(bevd_0);
case 1839126479: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -424219410: return bem_floatNpSet_1(bevd_0);
case -1050860724: return bem_setOutputTimeSet_1(bevd_0);
case -1153210986: return bem_classHeadBodySetDirect_1(bevd_0);
case 1152373374: return bem_synEmitPathSet_1(bevd_0);
case 525867578: return bem_qSetDirect_1(bevd_0);
case 445819062: return bem_transSet_1(bevd_0);
case -1551088579: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1289331095: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -1193521707: return bem_idToNamePathSetDirect_1(bevd_0);
case -455593465: return bem_propertyDecsSetDirect_1(bevd_0);
case 987201415: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2008233122: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1776809505: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1666962597: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1835923968: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1853281410: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2013844302: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -549233499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1507293234: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -586529345: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1426080127: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2062617509: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 916702235: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 660425451: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1998827071: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 992175762: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1731663629: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 2126382926: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -136430353: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1983260459: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 2082824503: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -238374165: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1819010281: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -920308147: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 611009316: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1498015255: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -251738564: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 1012354528: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
