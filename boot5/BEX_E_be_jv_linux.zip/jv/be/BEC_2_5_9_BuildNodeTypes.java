package be;
/* IO:File: source/build/NodeTypes.be */
public final class BEC_2_5_9_BuildNodeTypes extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildNodeTypes() { }
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;

public static BET_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_TRANSUNIT;
public BEC_2_4_3_MathInt bevp_VAR;
public BEC_2_4_3_MathInt bevp_NULL;
public BEC_2_4_3_MathInt bevp_CALL;
public BEC_2_4_3_MathInt bevp_NAMEPATH;
public BEC_2_4_3_MathInt bevp_CLASS;
public BEC_2_4_3_MathInt bevp_EMIT;
public BEC_2_4_3_MathInt bevp_IFEMIT;
public BEC_2_4_3_MathInt bevp_TRUE;
public BEC_2_4_3_MathInt bevp_FALSE;
public BEC_2_4_3_MathInt bevp_BRACES;
public BEC_2_4_3_MathInt bevp_RBRACES;
public BEC_2_4_3_MathInt bevp_RPARENS;
public BEC_2_4_3_MathInt bevp_LOOP;
public BEC_2_4_3_MathInt bevp_PROPERTIES;
public BEC_2_4_3_MathInt bevp_ELSE;
public BEC_2_4_3_MathInt bevp_FINALLY;
public BEC_2_4_3_MathInt bevp_TRY;
public BEC_2_4_3_MathInt bevp_CATCH;
public BEC_2_4_3_MathInt bevp_IF;
public BEC_2_4_3_MathInt bevp_SPACE;
public BEC_2_4_3_MathInt bevp_METHOD;
public BEC_2_4_3_MathInt bevp_DEFMOD;
public BEC_2_4_3_MathInt bevp_PARENS;
public BEC_2_4_3_MathInt bevp_FLOATL;
public BEC_2_4_3_MathInt bevp_INTL;
public BEC_2_4_3_MathInt bevp_DIVIDE;
public BEC_2_4_3_MathInt bevp_DIVIDE_ASSIGN;
public BEC_2_4_3_MathInt bevp_MULTIPLY;
public BEC_2_4_3_MathInt bevp_MULTIPLY_ASSIGN;
public BEC_2_4_3_MathInt bevp_STRQ;
public BEC_2_4_3_MathInt bevp_WSTRQ;
public BEC_2_4_3_MathInt bevp_STRINGL;
public BEC_2_4_3_MathInt bevp_WSTRINGL;
public BEC_2_4_3_MathInt bevp_NEWLINE;
public BEC_2_4_3_MathInt bevp_ASSIGN;
public BEC_2_4_3_MathInt bevp_EQUALS;
public BEC_2_4_3_MathInt bevp_NOT;
public BEC_2_4_3_MathInt bevp_ONCE;
public BEC_2_4_3_MathInt bevp_MANY;
public BEC_2_4_3_MathInt bevp_NOT_EQUALS;
public BEC_2_4_3_MathInt bevp_OR;
public BEC_2_4_3_MathInt bevp_AND;
public BEC_2_4_3_MathInt bevp_OR_ASSIGN;
public BEC_2_4_3_MathInt bevp_AND_ASSIGN;
public BEC_2_4_3_MathInt bevp_LOGICAL_OR;
public BEC_2_4_3_MathInt bevp_GET_METHOD;
public BEC_2_4_3_MathInt bevp_LOGICAL_AND;
public BEC_2_4_3_MathInt bevp_GREATER;
public BEC_2_4_3_MathInt bevp_GREATER_EQUALS;
public BEC_2_4_3_MathInt bevp_LESSER;
public BEC_2_4_3_MathInt bevp_LESSER_EQUALS;
public BEC_2_4_3_MathInt bevp_ADD;
public BEC_2_4_3_MathInt bevp_INCREMENT;
public BEC_2_4_3_MathInt bevp_ADD_ASSIGN;
public BEC_2_4_3_MathInt bevp_INCREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_SUBTRACT;
public BEC_2_4_3_MathInt bevp_DECREMENT;
public BEC_2_4_3_MathInt bevp_SUBTRACT_ASSIGN;
public BEC_2_4_3_MathInt bevp_DECREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_ID;
public BEC_2_4_3_MathInt bevp_COLON;
public BEC_2_4_3_MathInt bevp_WHILE;
public BEC_2_4_3_MathInt bevp_FOREACH;
public BEC_2_4_3_MathInt bevp_BLOCK;
public BEC_2_4_3_MathInt bevp_USE;
public BEC_2_4_3_MathInt bevp_AS;
public BEC_2_4_3_MathInt bevp_SEMI;
public BEC_2_4_3_MathInt bevp_EXPR;
public BEC_2_4_3_MathInt bevp_COMMA;
public BEC_2_4_3_MathInt bevp_ACCESSOR;
public BEC_2_4_3_MathInt bevp_DOT;
public BEC_2_4_3_MathInt bevp_BREAK;
public BEC_2_4_3_MathInt bevp_IDX;
public BEC_2_4_3_MathInt bevp_IDXACC;
public BEC_2_4_3_MathInt bevp_RIDX;
public BEC_2_4_3_MathInt bevp_TOKEN;
public BEC_2_4_3_MathInt bevp_MODULUS;
public BEC_2_4_3_MathInt bevp_MODULUS_ASSIGN;
public BEC_2_4_3_MathInt bevp_ELIF;
public BEC_2_4_3_MathInt bevp_FOR;
public BEC_2_4_3_MathInt bevp_IN;
public BEC_2_4_3_MathInt bevp_CONTINUE;
public BEC_2_4_3_MathInt bevp_ATYPE;
public BEC_2_4_3_MathInt bevp_FSLASH;
public BEC_2_5_9_BuildNodeTypes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_default_0() throws Throwable {
bevp_TRANSUNIT = (new BEC_2_4_3_MathInt(1));
bevp_VAR = (new BEC_2_4_3_MathInt(2));
bevp_NULL = (new BEC_2_4_3_MathInt(3));
bevp_CALL = (new BEC_2_4_3_MathInt(4));
bevp_NAMEPATH = (new BEC_2_4_3_MathInt(5));
bevp_CLASS = (new BEC_2_4_3_MathInt(6));
bevp_EMIT = (new BEC_2_4_3_MathInt(8));
bevp_IFEMIT = (new BEC_2_4_3_MathInt(9));
bevp_TRUE = (new BEC_2_4_3_MathInt(10));
bevp_FALSE = (new BEC_2_4_3_MathInt(11));
bevp_BRACES = (new BEC_2_4_3_MathInt(12));
bevp_RBRACES = (new BEC_2_4_3_MathInt(13));
bevp_RPARENS = (new BEC_2_4_3_MathInt(14));
bevp_LOOP = (new BEC_2_4_3_MathInt(15));
bevp_PROPERTIES = (new BEC_2_4_3_MathInt(23));
bevp_ELSE = (new BEC_2_4_3_MathInt(16));
bevp_FINALLY = (new BEC_2_4_3_MathInt(93));
bevp_TRY = (new BEC_2_4_3_MathInt(17));
bevp_CATCH = (new BEC_2_4_3_MathInt(18));
bevp_IF = (new BEC_2_4_3_MathInt(19));
bevp_SPACE = (new BEC_2_4_3_MathInt(20));
bevp_METHOD = (new BEC_2_4_3_MathInt(21));
bevp_DEFMOD = (new BEC_2_4_3_MathInt(74));
bevp_PARENS = (new BEC_2_4_3_MathInt(22));
bevp_FLOATL = (new BEC_2_4_3_MathInt(25));
bevp_INTL = (new BEC_2_4_3_MathInt(26));
bevp_DIVIDE = (new BEC_2_4_3_MathInt(27));
bevp_DIVIDE_ASSIGN = (new BEC_2_4_3_MathInt(86));
bevp_MULTIPLY = (new BEC_2_4_3_MathInt(28));
bevp_MULTIPLY_ASSIGN = (new BEC_2_4_3_MathInt(87));
bevp_STRQ = (new BEC_2_4_3_MathInt(29));
bevp_WSTRQ = (new BEC_2_4_3_MathInt(30));
bevp_STRINGL = (new BEC_2_4_3_MathInt(31));
bevp_WSTRINGL = (new BEC_2_4_3_MathInt(33));
bevp_NEWLINE = (new BEC_2_4_3_MathInt(32));
bevp_ASSIGN = (new BEC_2_4_3_MathInt(35));
bevp_EQUALS = (new BEC_2_4_3_MathInt(36));
bevp_NOT = (new BEC_2_4_3_MathInt(37));
bevp_ONCE = (new BEC_2_4_3_MathInt(81));
bevp_MANY = (new BEC_2_4_3_MathInt(82));
bevp_NOT_EQUALS = (new BEC_2_4_3_MathInt(38));
bevp_OR = (new BEC_2_4_3_MathInt(39));
bevp_AND = (new BEC_2_4_3_MathInt(40));
bevp_OR_ASSIGN = (new BEC_2_4_3_MathInt(92));
bevp_AND_ASSIGN = (new BEC_2_4_3_MathInt(91));
bevp_LOGICAL_OR = (new BEC_2_4_3_MathInt(89));
bevp_GET_METHOD = (new BEC_2_4_3_MathInt(94));
bevp_LOGICAL_AND = (new BEC_2_4_3_MathInt(90));
bevp_GREATER = (new BEC_2_4_3_MathInt(41));
bevp_GREATER_EQUALS = (new BEC_2_4_3_MathInt(42));
bevp_LESSER = (new BEC_2_4_3_MathInt(43));
bevp_LESSER_EQUALS = (new BEC_2_4_3_MathInt(44));
bevp_ADD = (new BEC_2_4_3_MathInt(45));
bevp_INCREMENT = (new BEC_2_4_3_MathInt(46));
bevp_ADD_ASSIGN = (new BEC_2_4_3_MathInt(47));
bevp_INCREMENT_ASSIGN = (new BEC_2_4_3_MathInt(84));
bevp_SUBTRACT = (new BEC_2_4_3_MathInt(48));
bevp_DECREMENT = (new BEC_2_4_3_MathInt(49));
bevp_SUBTRACT_ASSIGN = (new BEC_2_4_3_MathInt(83));
bevp_DECREMENT_ASSIGN = (new BEC_2_4_3_MathInt(85));
bevp_ID = (new BEC_2_4_3_MathInt(50));
bevp_COLON = (new BEC_2_4_3_MathInt(51));
bevp_WHILE = (new BEC_2_4_3_MathInt(52));
bevp_FOREACH = (new BEC_2_4_3_MathInt(53));
bevp_BLOCK = (new BEC_2_4_3_MathInt(72));
bevp_USE = (new BEC_2_4_3_MathInt(54));
bevp_AS = (new BEC_2_4_3_MathInt(55));
bevp_SEMI = (new BEC_2_4_3_MathInt(56));
bevp_EXPR = (new BEC_2_4_3_MathInt(57));
bevp_COMMA = (new BEC_2_4_3_MathInt(58));
bevp_ACCESSOR = (new BEC_2_4_3_MathInt(59));
bevp_DOT = (new BEC_2_4_3_MathInt(60));
bevp_BREAK = (new BEC_2_4_3_MathInt(61));
bevp_IDX = (new BEC_2_4_3_MathInt(62));
bevp_IDXACC = (new BEC_2_4_3_MathInt(73));
bevp_RIDX = (new BEC_2_4_3_MathInt(63));
bevp_TOKEN = (new BEC_2_4_3_MathInt(64));
bevp_MODULUS = (new BEC_2_4_3_MathInt(65));
bevp_MODULUS_ASSIGN = (new BEC_2_4_3_MathInt(88));
bevp_ELIF = (new BEC_2_4_3_MathInt(66));
bevp_FOR = (new BEC_2_4_3_MathInt(67));
bevp_IN = (new BEC_2_4_3_MathInt(68));
bevp_CONTINUE = (new BEC_2_4_3_MathInt(69));
bevp_ATYPE = (new BEC_2_4_3_MathInt(71));
bevp_FSLASH = (new BEC_2_4_3_MathInt(80));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRANSUNITGet_0() throws Throwable {
return bevp_TRANSUNIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRANSUNITGetDirect_0() throws Throwable {
return bevp_TRANSUNIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_VARGet_0() throws Throwable {
return bevp_VAR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_VARGetDirect_0() throws Throwable {
return bevp_VAR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_VARSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_VARSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NULLGet_0() throws Throwable {
return bevp_NULL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NULLGetDirect_0() throws Throwable {
return bevp_NULL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NULLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NULLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CALLGet_0() throws Throwable {
return bevp_CALL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CALLGetDirect_0() throws Throwable {
return bevp_CALL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CALLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CALLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NAMEPATHGet_0() throws Throwable {
return bevp_NAMEPATH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NAMEPATHGetDirect_0() throws Throwable {
return bevp_NAMEPATH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CLASSGet_0() throws Throwable {
return bevp_CLASS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CLASSGetDirect_0() throws Throwable {
return bevp_CLASS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CLASSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CLASSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EMITGet_0() throws Throwable {
return bevp_EMIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EMITGetDirect_0() throws Throwable {
return bevp_EMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EMITSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFEMITGet_0() throws Throwable {
return bevp_IFEMIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IFEMITGetDirect_0() throws Throwable {
return bevp_IFEMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFEMITSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IFEMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRUEGet_0() throws Throwable {
return bevp_TRUE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRUEGetDirect_0() throws Throwable {
return bevp_TRUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRUESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FALSEGet_0() throws Throwable {
return bevp_FALSE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FALSEGetDirect_0() throws Throwable {
return bevp_FALSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FALSESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FALSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BRACESGet_0() throws Throwable {
return bevp_BRACES;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BRACESGetDirect_0() throws Throwable {
return bevp_BRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BRACESSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RBRACESGet_0() throws Throwable {
return bevp_RBRACES;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RBRACESGetDirect_0() throws Throwable {
return bevp_RBRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RBRACESSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RBRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RPARENSGet_0() throws Throwable {
return bevp_RPARENS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RPARENSGetDirect_0() throws Throwable {
return bevp_RPARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RPARENSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RPARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOOPGet_0() throws Throwable {
return bevp_LOOP;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOOPGetDirect_0() throws Throwable {
return bevp_LOOP;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOOPSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOOPSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PROPERTIESGet_0() throws Throwable {
return bevp_PROPERTIES;
} /*method end*/
public final BEC_2_4_3_MathInt bem_PROPERTIESGetDirect_0() throws Throwable {
return bevp_PROPERTIES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PROPERTIESSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_PROPERTIES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_PROPERTIESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_PROPERTIES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELSEGet_0() throws Throwable {
return bevp_ELSE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ELSEGetDirect_0() throws Throwable {
return bevp_ELSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELSESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ELSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FINALLYGet_0() throws Throwable {
return bevp_FINALLY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FINALLYGetDirect_0() throws Throwable {
return bevp_FINALLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FINALLYSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FINALLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRYGet_0() throws Throwable {
return bevp_TRY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRYGetDirect_0() throws Throwable {
return bevp_TRY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRYSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CATCHGet_0() throws Throwable {
return bevp_CATCH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CATCHGetDirect_0() throws Throwable {
return bevp_CATCH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CATCHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CATCHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFGet_0() throws Throwable {
return bevp_IF;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IFGetDirect_0() throws Throwable {
return bevp_IF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SPACEGet_0() throws Throwable {
return bevp_SPACE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SPACEGetDirect_0() throws Throwable {
return bevp_SPACE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SPACESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SPACESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_METHODGet_0() throws Throwable {
return bevp_METHOD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_METHODGetDirect_0() throws Throwable {
return bevp_METHOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_METHODSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_METHODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DEFMODGet_0() throws Throwable {
return bevp_DEFMOD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DEFMODGetDirect_0() throws Throwable {
return bevp_DEFMOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DEFMODSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DEFMODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PARENSGet_0() throws Throwable {
return bevp_PARENS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_PARENSGetDirect_0() throws Throwable {
return bevp_PARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PARENSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_PARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FLOATLGet_0() throws Throwable {
return bevp_FLOATL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FLOATLGetDirect_0() throws Throwable {
return bevp_FLOATL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FLOATLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FLOATLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INTLGet_0() throws Throwable {
return bevp_INTL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INTLGetDirect_0() throws Throwable {
return bevp_INTL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INTLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INTLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDEGet_0() throws Throwable {
return bevp_DIVIDE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DIVIDEGetDirect_0() throws Throwable {
return bevp_DIVIDE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DIVIDESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGet_0() throws Throwable {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGetDirect_0() throws Throwable {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLYGet_0() throws Throwable {
return bevp_MULTIPLY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MULTIPLYGetDirect_0() throws Throwable {
return bevp_MULTIPLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGet_0() throws Throwable {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGetDirect_0() throws Throwable {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRQGet_0() throws Throwable {
return bevp_STRQ;
} /*method end*/
public final BEC_2_4_3_MathInt bem_STRQGetDirect_0() throws Throwable {
return bevp_STRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRQSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_STRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRQGet_0() throws Throwable {
return bevp_WSTRQ;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WSTRQGetDirect_0() throws Throwable {
return bevp_WSTRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRQSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WSTRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRINGLGet_0() throws Throwable {
return bevp_STRINGL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_STRINGLGetDirect_0() throws Throwable {
return bevp_STRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_STRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRINGLGet_0() throws Throwable {
return bevp_WSTRINGL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WSTRINGLGetDirect_0() throws Throwable {
return bevp_WSTRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NEWLINEGet_0() throws Throwable {
return bevp_NEWLINE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NEWLINEGetDirect_0() throws Throwable {
return bevp_NEWLINE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NEWLINESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NEWLINESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASSIGNGet_0() throws Throwable {
return bevp_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ASSIGNGetDirect_0() throws Throwable {
return bevp_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EQUALSGet_0() throws Throwable {
return bevp_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EQUALSGetDirect_0() throws Throwable {
return bevp_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOTGet_0() throws Throwable {
return bevp_NOT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NOTGetDirect_0() throws Throwable {
return bevp_NOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ONCEGet_0() throws Throwable {
return bevp_ONCE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ONCEGetDirect_0() throws Throwable {
return bevp_ONCE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ONCESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ONCE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ONCESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ONCE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MANYGet_0() throws Throwable {
return bevp_MANY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MANYGetDirect_0() throws Throwable {
return bevp_MANY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MANYSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MANY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MANYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MANY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOT_EQUALSGet_0() throws Throwable {
return bevp_NOT_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NOT_EQUALSGetDirect_0() throws Throwable {
return bevp_NOT_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ORGet_0() throws Throwable {
return bevp_OR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ORGetDirect_0() throws Throwable {
return bevp_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ORSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ANDGet_0() throws Throwable {
return bevp_AND;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ANDGetDirect_0() throws Throwable {
return bevp_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_OR_ASSIGNGet_0() throws Throwable {
return bevp_OR_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_OR_ASSIGNGetDirect_0() throws Throwable {
return bevp_OR_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_AND_ASSIGNGet_0() throws Throwable {
return bevp_AND_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_AND_ASSIGNGetDirect_0() throws Throwable {
return bevp_AND_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ORGet_0() throws Throwable {
return bevp_LOGICAL_OR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOGICAL_ORGetDirect_0() throws Throwable {
return bevp_LOGICAL_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GET_METHODGet_0() throws Throwable {
return bevp_GET_METHOD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_GET_METHODGetDirect_0() throws Throwable {
return bevp_GET_METHOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GET_METHODSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_GET_METHOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_GET_METHODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_GET_METHOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ANDGet_0() throws Throwable {
return bevp_LOGICAL_AND;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOGICAL_ANDGetDirect_0() throws Throwable {
return bevp_LOGICAL_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATERGet_0() throws Throwable {
return bevp_GREATER;
} /*method end*/
public final BEC_2_4_3_MathInt bem_GREATERGetDirect_0() throws Throwable {
return bevp_GREATER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATERSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_GREATERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATER_EQUALSGet_0() throws Throwable {
return bevp_GREATER_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_GREATER_EQUALSGetDirect_0() throws Throwable {
return bevp_GREATER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSERGet_0() throws Throwable {
return bevp_LESSER;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LESSERGetDirect_0() throws Throwable {
return bevp_LESSER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSERSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LESSERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSER_EQUALSGet_0() throws Throwable {
return bevp_LESSER_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LESSER_EQUALSGetDirect_0() throws Throwable {
return bevp_LESSER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADDGet_0() throws Throwable {
return bevp_ADD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ADDGetDirect_0() throws Throwable {
return bevp_ADD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADDSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ADDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENTGet_0() throws Throwable {
return bevp_INCREMENT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INCREMENTGetDirect_0() throws Throwable {
return bevp_INCREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INCREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADD_ASSIGNGet_0() throws Throwable {
return bevp_ADD_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ADD_ASSIGNGetDirect_0() throws Throwable {
return bevp_ADD_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGet_0() throws Throwable {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGetDirect_0() throws Throwable {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACTGet_0() throws Throwable {
return bevp_SUBTRACT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SUBTRACTGetDirect_0() throws Throwable {
return bevp_SUBTRACT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENTGet_0() throws Throwable {
return bevp_DECREMENT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DECREMENTGetDirect_0() throws Throwable {
return bevp_DECREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DECREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGet_0() throws Throwable {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGetDirect_0() throws Throwable {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGet_0() throws Throwable {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGetDirect_0() throws Throwable {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDGet_0() throws Throwable {
return bevp_ID;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDGetDirect_0() throws Throwable {
return bevp_ID;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COLONGet_0() throws Throwable {
return bevp_COLON;
} /*method end*/
public final BEC_2_4_3_MathInt bem_COLONGetDirect_0() throws Throwable {
return bevp_COLON;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COLONSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_COLONSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WHILEGet_0() throws Throwable {
return bevp_WHILE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WHILEGetDirect_0() throws Throwable {
return bevp_WHILE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WHILESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WHILESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FOREACHGet_0() throws Throwable {
return bevp_FOREACH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FOREACHGetDirect_0() throws Throwable {
return bevp_FOREACH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FOREACHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FOREACHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BLOCKGet_0() throws Throwable {
return bevp_BLOCK;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BLOCKGetDirect_0() throws Throwable {
return bevp_BLOCK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BLOCKSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BLOCKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_USEGet_0() throws Throwable {
return bevp_USE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_USEGetDirect_0() throws Throwable {
return bevp_USE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_USESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_USESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASGet_0() throws Throwable {
return bevp_AS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ASGetDirect_0() throws Throwable {
return bevp_AS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ASSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SEMIGet_0() throws Throwable {
return bevp_SEMI;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SEMIGetDirect_0() throws Throwable {
return bevp_SEMI;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SEMISet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SEMISetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EXPRGet_0() throws Throwable {
return bevp_EXPR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EXPRGetDirect_0() throws Throwable {
return bevp_EXPR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EXPRSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EXPRSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COMMAGet_0() throws Throwable {
return bevp_COMMA;
} /*method end*/
public final BEC_2_4_3_MathInt bem_COMMAGetDirect_0() throws Throwable {
return bevp_COMMA;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COMMASet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_COMMASetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ACCESSORGet_0() throws Throwable {
return bevp_ACCESSOR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ACCESSORGetDirect_0() throws Throwable {
return bevp_ACCESSOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ACCESSORSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ACCESSORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DOTGet_0() throws Throwable {
return bevp_DOT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DOTGetDirect_0() throws Throwable {
return bevp_DOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DOTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BREAKGet_0() throws Throwable {
return bevp_BREAK;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BREAKGetDirect_0() throws Throwable {
return bevp_BREAK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BREAKSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BREAKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXGet_0() throws Throwable {
return bevp_IDX;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDXGetDirect_0() throws Throwable {
return bevp_IDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXACCGet_0() throws Throwable {
return bevp_IDXACC;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDXACCGetDirect_0() throws Throwable {
return bevp_IDXACC;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXACCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDXACCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RIDXGet_0() throws Throwable {
return bevp_RIDX;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RIDXGetDirect_0() throws Throwable {
return bevp_RIDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RIDXSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RIDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TOKENGet_0() throws Throwable {
return bevp_TOKEN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TOKENGetDirect_0() throws Throwable {
return bevp_TOKEN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TOKENSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TOKENSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUSGet_0() throws Throwable {
return bevp_MODULUS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MODULUSGetDirect_0() throws Throwable {
return bevp_MODULUS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MODULUSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGet_0() throws Throwable {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGetDirect_0() throws Throwable {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELIFGet_0() throws Throwable {
return bevp_ELIF;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ELIFGetDirect_0() throws Throwable {
return bevp_ELIF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELIFSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ELIFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FORGet_0() throws Throwable {
return bevp_FOR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FORGetDirect_0() throws Throwable {
return bevp_FOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FORSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INGet_0() throws Throwable {
return bevp_IN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INGetDirect_0() throws Throwable {
return bevp_IN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CONTINUEGet_0() throws Throwable {
return bevp_CONTINUE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CONTINUEGetDirect_0() throws Throwable {
return bevp_CONTINUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CONTINUESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CONTINUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ATYPEGet_0() throws Throwable {
return bevp_ATYPE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ATYPEGetDirect_0() throws Throwable {
return bevp_ATYPE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ATYPESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ATYPESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FSLASHGet_0() throws Throwable {
return bevp_FSLASH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FSLASHGetDirect_0() throws Throwable {
return bevp_FSLASH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FSLASHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FSLASHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 188, 191, 194, 198, 202, 205, 208, 212, 216, 219, 222, 226, 230, 233, 236, 240, 244, 247, 250, 254, 258, 261, 264, 268, 272, 275, 278, 282, 286, 289, 292, 296, 300, 303, 306, 310, 314, 317, 320, 324, 328, 331, 334, 338, 342, 345, 348, 352, 356, 359, 362, 366, 370, 373, 376, 380, 384, 387, 390, 394, 398, 401, 404, 408, 412, 415, 418, 422, 426, 429, 432, 436, 440, 443, 446, 450, 454, 457, 460, 464, 468, 471, 474, 478, 482, 485, 488, 492, 496, 499, 502, 506, 510, 513, 516, 520, 524, 527, 530, 534, 538, 541, 544, 548, 552, 555, 558, 562, 566, 569, 572, 576, 580, 583, 586, 590, 594, 597, 600, 604, 608, 611, 614, 618, 622, 625, 628, 632, 636, 639, 642, 646, 650, 653, 656, 660, 664, 667, 670, 674, 678, 681, 684, 688, 692, 695, 698, 702, 706, 709, 712, 716, 720, 723, 726, 730, 734, 737, 740, 744, 748, 751, 754, 758, 762, 765, 768, 772, 776, 779, 782, 786, 790, 793, 796, 800, 804, 807, 810, 814, 818, 821, 824, 828, 832, 835, 838, 842, 846, 849, 852, 856, 860, 863, 866, 870, 874, 877, 880, 884, 888, 891, 894, 898, 902, 905, 908, 912, 916, 919, 922, 926, 930, 933, 936, 940, 944, 947, 950, 954, 958, 961, 964, 968, 972, 975, 978, 982, 986, 989, 992, 996, 1000, 1003, 1006, 1010, 1014, 1017, 1020, 1024, 1028, 1031, 1034, 1038, 1042, 1045, 1048, 1052, 1056, 1059, 1062, 1066, 1070, 1073, 1076, 1080, 1084, 1087, 1090, 1094, 1098, 1101, 1104, 1108, 1112, 1115, 1118, 1122, 1126, 1129, 1132, 1136, 1140, 1143, 1146, 1150, 1154, 1157, 1160, 1164, 1168, 1171, 1174, 1178, 1182, 1185, 1188, 1192, 1196, 1199, 1202, 1206, 1210, 1213, 1216, 1220, 1224, 1227, 1230, 1234, 1238, 1241, 1244, 1248, 1252, 1255, 1258, 1262, 1266, 1269, 1272, 1276, 1280, 1283, 1286, 1290, 1294, 1297, 1300, 1304, 1308, 1311, 1314, 1318, 1322, 1325, 1328, 1332, 1336, 1339, 1342, 1346, 1350, 1353, 1356, 1360, 1364, 1367, 1370, 1374};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 12 100
new 0 12 100
assign 1 13 101
new 0 13 101
assign 1 14 102
new 0 14 102
assign 1 15 103
new 0 15 103
assign 1 16 104
new 0 16 104
assign 1 17 105
new 0 17 105
assign 1 18 106
new 0 18 106
assign 1 19 107
new 0 19 107
assign 1 20 108
new 0 20 108
assign 1 21 109
new 0 21 109
assign 1 22 110
new 0 22 110
assign 1 23 111
new 0 23 111
assign 1 24 112
new 0 24 112
assign 1 25 113
new 0 25 113
assign 1 26 114
new 0 26 114
assign 1 27 115
new 0 27 115
assign 1 28 116
new 0 28 116
assign 1 29 117
new 0 29 117
assign 1 30 118
new 0 30 118
assign 1 31 119
new 0 31 119
assign 1 32 120
new 0 32 120
assign 1 33 121
new 0 33 121
assign 1 34 122
new 0 34 122
assign 1 35 123
new 0 35 123
assign 1 36 124
new 0 36 124
assign 1 37 125
new 0 37 125
assign 1 38 126
new 0 38 126
assign 1 39 127
new 0 39 127
assign 1 40 128
new 0 40 128
assign 1 41 129
new 0 41 129
assign 1 42 130
new 0 42 130
assign 1 43 131
new 0 43 131
assign 1 44 132
new 0 44 132
assign 1 45 133
new 0 45 133
assign 1 46 134
new 0 46 134
assign 1 47 135
new 0 47 135
assign 1 48 136
new 0 48 136
assign 1 49 137
new 0 49 137
assign 1 50 138
new 0 50 138
assign 1 51 139
new 0 51 139
assign 1 52 140
new 0 52 140
assign 1 53 141
new 0 53 141
assign 1 54 142
new 0 54 142
assign 1 55 143
new 0 55 143
assign 1 56 144
new 0 56 144
assign 1 57 145
new 0 57 145
assign 1 58 146
new 0 58 146
assign 1 59 147
new 0 59 147
assign 1 60 148
new 0 60 148
assign 1 61 149
new 0 61 149
assign 1 62 150
new 0 62 150
assign 1 63 151
new 0 63 151
assign 1 64 152
new 0 64 152
assign 1 65 153
new 0 65 153
assign 1 66 154
new 0 66 154
assign 1 67 155
new 0 67 155
assign 1 68 156
new 0 68 156
assign 1 69 157
new 0 69 157
assign 1 70 158
new 0 70 158
assign 1 71 159
new 0 71 159
assign 1 72 160
new 0 72 160
assign 1 73 161
new 0 73 161
assign 1 74 162
new 0 74 162
assign 1 75 163
new 0 75 163
assign 1 76 164
new 0 76 164
assign 1 77 165
new 0 77 165
assign 1 78 166
new 0 78 166
assign 1 79 167
new 0 79 167
assign 1 80 168
new 0 80 168
assign 1 81 169
new 0 81 169
assign 1 82 170
new 0 82 170
assign 1 83 171
new 0 83 171
assign 1 84 172
new 0 84 172
assign 1 85 173
new 0 85 173
assign 1 86 174
new 0 86 174
assign 1 87 175
new 0 87 175
assign 1 88 176
new 0 88 176
assign 1 89 177
new 0 89 177
assign 1 90 178
new 0 90 178
assign 1 91 179
new 0 91 179
assign 1 92 180
new 0 92 180
assign 1 93 181
new 0 93 181
assign 1 94 182
new 0 94 182
assign 1 95 183
new 0 95 183
assign 1 96 184
new 0 96 184
return 1 0 188
return 1 0 191
assign 1 0 194
assign 1 0 198
return 1 0 202
return 1 0 205
assign 1 0 208
assign 1 0 212
return 1 0 216
return 1 0 219
assign 1 0 222
assign 1 0 226
return 1 0 230
return 1 0 233
assign 1 0 236
assign 1 0 240
return 1 0 244
return 1 0 247
assign 1 0 250
assign 1 0 254
return 1 0 258
return 1 0 261
assign 1 0 264
assign 1 0 268
return 1 0 272
return 1 0 275
assign 1 0 278
assign 1 0 282
return 1 0 286
return 1 0 289
assign 1 0 292
assign 1 0 296
return 1 0 300
return 1 0 303
assign 1 0 306
assign 1 0 310
return 1 0 314
return 1 0 317
assign 1 0 320
assign 1 0 324
return 1 0 328
return 1 0 331
assign 1 0 334
assign 1 0 338
return 1 0 342
return 1 0 345
assign 1 0 348
assign 1 0 352
return 1 0 356
return 1 0 359
assign 1 0 362
assign 1 0 366
return 1 0 370
return 1 0 373
assign 1 0 376
assign 1 0 380
return 1 0 384
return 1 0 387
assign 1 0 390
assign 1 0 394
return 1 0 398
return 1 0 401
assign 1 0 404
assign 1 0 408
return 1 0 412
return 1 0 415
assign 1 0 418
assign 1 0 422
return 1 0 426
return 1 0 429
assign 1 0 432
assign 1 0 436
return 1 0 440
return 1 0 443
assign 1 0 446
assign 1 0 450
return 1 0 454
return 1 0 457
assign 1 0 460
assign 1 0 464
return 1 0 468
return 1 0 471
assign 1 0 474
assign 1 0 478
return 1 0 482
return 1 0 485
assign 1 0 488
assign 1 0 492
return 1 0 496
return 1 0 499
assign 1 0 502
assign 1 0 506
return 1 0 510
return 1 0 513
assign 1 0 516
assign 1 0 520
return 1 0 524
return 1 0 527
assign 1 0 530
assign 1 0 534
return 1 0 538
return 1 0 541
assign 1 0 544
assign 1 0 548
return 1 0 552
return 1 0 555
assign 1 0 558
assign 1 0 562
return 1 0 566
return 1 0 569
assign 1 0 572
assign 1 0 576
return 1 0 580
return 1 0 583
assign 1 0 586
assign 1 0 590
return 1 0 594
return 1 0 597
assign 1 0 600
assign 1 0 604
return 1 0 608
return 1 0 611
assign 1 0 614
assign 1 0 618
return 1 0 622
return 1 0 625
assign 1 0 628
assign 1 0 632
return 1 0 636
return 1 0 639
assign 1 0 642
assign 1 0 646
return 1 0 650
return 1 0 653
assign 1 0 656
assign 1 0 660
return 1 0 664
return 1 0 667
assign 1 0 670
assign 1 0 674
return 1 0 678
return 1 0 681
assign 1 0 684
assign 1 0 688
return 1 0 692
return 1 0 695
assign 1 0 698
assign 1 0 702
return 1 0 706
return 1 0 709
assign 1 0 712
assign 1 0 716
return 1 0 720
return 1 0 723
assign 1 0 726
assign 1 0 730
return 1 0 734
return 1 0 737
assign 1 0 740
assign 1 0 744
return 1 0 748
return 1 0 751
assign 1 0 754
assign 1 0 758
return 1 0 762
return 1 0 765
assign 1 0 768
assign 1 0 772
return 1 0 776
return 1 0 779
assign 1 0 782
assign 1 0 786
return 1 0 790
return 1 0 793
assign 1 0 796
assign 1 0 800
return 1 0 804
return 1 0 807
assign 1 0 810
assign 1 0 814
return 1 0 818
return 1 0 821
assign 1 0 824
assign 1 0 828
return 1 0 832
return 1 0 835
assign 1 0 838
assign 1 0 842
return 1 0 846
return 1 0 849
assign 1 0 852
assign 1 0 856
return 1 0 860
return 1 0 863
assign 1 0 866
assign 1 0 870
return 1 0 874
return 1 0 877
assign 1 0 880
assign 1 0 884
return 1 0 888
return 1 0 891
assign 1 0 894
assign 1 0 898
return 1 0 902
return 1 0 905
assign 1 0 908
assign 1 0 912
return 1 0 916
return 1 0 919
assign 1 0 922
assign 1 0 926
return 1 0 930
return 1 0 933
assign 1 0 936
assign 1 0 940
return 1 0 944
return 1 0 947
assign 1 0 950
assign 1 0 954
return 1 0 958
return 1 0 961
assign 1 0 964
assign 1 0 968
return 1 0 972
return 1 0 975
assign 1 0 978
assign 1 0 982
return 1 0 986
return 1 0 989
assign 1 0 992
assign 1 0 996
return 1 0 1000
return 1 0 1003
assign 1 0 1006
assign 1 0 1010
return 1 0 1014
return 1 0 1017
assign 1 0 1020
assign 1 0 1024
return 1 0 1028
return 1 0 1031
assign 1 0 1034
assign 1 0 1038
return 1 0 1042
return 1 0 1045
assign 1 0 1048
assign 1 0 1052
return 1 0 1056
return 1 0 1059
assign 1 0 1062
assign 1 0 1066
return 1 0 1070
return 1 0 1073
assign 1 0 1076
assign 1 0 1080
return 1 0 1084
return 1 0 1087
assign 1 0 1090
assign 1 0 1094
return 1 0 1098
return 1 0 1101
assign 1 0 1104
assign 1 0 1108
return 1 0 1112
return 1 0 1115
assign 1 0 1118
assign 1 0 1122
return 1 0 1126
return 1 0 1129
assign 1 0 1132
assign 1 0 1136
return 1 0 1140
return 1 0 1143
assign 1 0 1146
assign 1 0 1150
return 1 0 1154
return 1 0 1157
assign 1 0 1160
assign 1 0 1164
return 1 0 1168
return 1 0 1171
assign 1 0 1174
assign 1 0 1178
return 1 0 1182
return 1 0 1185
assign 1 0 1188
assign 1 0 1192
return 1 0 1196
return 1 0 1199
assign 1 0 1202
assign 1 0 1206
return 1 0 1210
return 1 0 1213
assign 1 0 1216
assign 1 0 1220
return 1 0 1224
return 1 0 1227
assign 1 0 1230
assign 1 0 1234
return 1 0 1238
return 1 0 1241
assign 1 0 1244
assign 1 0 1248
return 1 0 1252
return 1 0 1255
assign 1 0 1258
assign 1 0 1262
return 1 0 1266
return 1 0 1269
assign 1 0 1272
assign 1 0 1276
return 1 0 1280
return 1 0 1283
assign 1 0 1286
assign 1 0 1290
return 1 0 1294
return 1 0 1297
assign 1 0 1300
assign 1 0 1304
return 1 0 1308
return 1 0 1311
assign 1 0 1314
assign 1 0 1318
return 1 0 1322
return 1 0 1325
assign 1 0 1328
assign 1 0 1332
return 1 0 1336
return 1 0 1339
assign 1 0 1342
assign 1 0 1346
return 1 0 1350
return 1 0 1353
assign 1 0 1356
assign 1 0 1360
return 1 0 1364
return 1 0 1367
assign 1 0 1370
assign 1 0 1374
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 653341959: return bem_print_0();
case 2074849895: return bem_PARENSGet_0();
case 573647971: return bem_iteratorGet_0();
case 1162801923: return bem_ACCESSORGetDirect_0();
case -267707774: return bem_STRINGLGet_0();
case 746566319: return bem_ONCEGet_0();
case -1488051374: return bem_WSTRQGetDirect_0();
case -344997020: return bem_LESSER_EQUALSGet_0();
case -2018827103: return bem_INCREMENTGet_0();
case -309175552: return bem_BREAKGet_0();
case 169229504: return bem_INCREMENT_ASSIGNGetDirect_0();
case 403177812: return bem_BLOCKGet_0();
case -180308772: return bem_LESSER_EQUALSGetDirect_0();
case -1439875774: return bem_new_0();
case -1517168099: return bem_IDGetDirect_0();
case -496031743: return bem_IDXGetDirect_0();
case 1004087136: return bem_ASSIGNGet_0();
case -605777754: return bem_NOT_EQUALSGet_0();
case -1410416670: return bem_STRQGet_0();
case 492290406: return bem_COLONGetDirect_0();
case -1937895466: return bem_EXPRGetDirect_0();
case 106930974: return bem_ELSEGetDirect_0();
case 1568255040: return bem_CALLGetDirect_0();
case 1010903426: return bem_ANDGet_0();
case 1518298197: return bem_GREATER_EQUALSGet_0();
case -60653892: return bem_RPARENSGetDirect_0();
case -1388434405: return bem_CATCHGetDirect_0();
case -613365896: return bem_MULTIPLYGetDirect_0();
case -1677627670: return bem_SUBTRACT_ASSIGNGet_0();
case -561788347: return bem_ANDGetDirect_0();
case 1814764640: return bem_METHODGetDirect_0();
case 1428587117: return bem_TRYGet_0();
case -1748925107: return bem_echo_0();
case -831209399: return bem_MULTIPLY_ASSIGNGet_0();
case -1976480232: return bem_once_0();
case -675976525: return bem_ADD_ASSIGNGet_0();
case -23847782: return bem_NEWLINEGet_0();
case -338903991: return bem_LOGICAL_ORGetDirect_0();
case 2054507365: return bem_COLONGet_0();
case 1077416311: return bem_IFGet_0();
case 1077613880: return bem_NAMEPATHGet_0();
case -32960742: return bem_DIVIDE_ASSIGNGet_0();
case -1759630984: return bem_classNameGet_0();
case 853102572: return bem_NOT_EQUALSGetDirect_0();
case 526584410: return bem_CLASSGet_0();
case -918423514: return bem_ELIFGet_0();
case 1318338231: return bem_ELIFGetDirect_0();
case -1750728158: return bem_CATCHGet_0();
case -228929773: return bem_GET_METHODGet_0();
case -482483637: return bem_CALLGet_0();
case 1446204919: return bem_FINALLYGetDirect_0();
case 1430998361: return bem_serializationIteratorGet_0();
case 1906522941: return bem_MODULUSGet_0();
case 1250090938: return bem_RIDXGetDirect_0();
case -435974957: return bem_SUBTRACTGetDirect_0();
case -1599601128: return bem_DOTGetDirect_0();
case -1796598033: return bem_MANYGet_0();
case 2080577349: return bem_RPARENSGet_0();
case 1846434623: return bem_DIVIDEGetDirect_0();
case 1525639803: return bem_sourceFileNameGet_0();
case 262559804: return bem_ASGet_0();
case -911194085: return bem_SUBTRACT_ASSIGNGetDirect_0();
case -1456420026: return bem_SEMIGet_0();
case -2096771875: return bem_EQUALSGetDirect_0();
case 173916672: return bem_ADD_ASSIGNGetDirect_0();
case -1660625162: return bem_DECREMENTGet_0();
case -1737009900: return bem_many_0();
case -1473086866: return bem_MANYGetDirect_0();
case 1948577476: return bem_IDXGet_0();
case 1515483731: return bem_AND_ASSIGNGetDirect_0();
case -1837121355: return bem_BRACESGetDirect_0();
case 716787318: return bem_LESSERGet_0();
case 992175510: return bem_ELSEGet_0();
case 260392908: return bem_IDXACCGet_0();
case -1195111829: return bem_create_0();
case -764796382: return bem_DOTGet_0();
case 194349659: return bem_OR_ASSIGNGetDirect_0();
case 177383524: return bem_RBRACESGetDirect_0();
case 1521697938: return bem_DEFMODGet_0();
case -800389528: return bem_EMITGetDirect_0();
case -1207395048: return bem_FSLASHGetDirect_0();
case -662224724: return bem_FOREACHGet_0();
case -1161401902: return bem_LOGICAL_ORGet_0();
case -1066226610: return bem_fieldNamesGet_0();
case 1670550087: return bem_TRUEGetDirect_0();
case 1107456605: return bem_CONTINUEGet_0();
case 667139279: return bem_SPACEGetDirect_0();
case 179843997: return bem_COMMAGetDirect_0();
case 1704396002: return bem_DIVIDEGet_0();
case -488815746: return bem_INGet_0();
case 839397081: return bem_TOKENGetDirect_0();
case 461332232: return bem_IFGetDirect_0();
case -1893005690: return bem_FLOATLGetDirect_0();
case 1048902608: return bem_ASGetDirect_0();
case 1555686151: return bem_MODULUS_ASSIGNGetDirect_0();
case 222324417: return bem_ACCESSORGet_0();
case 1020187354: return bem_TOKENGet_0();
case -1325182957: return bem_GREATERGet_0();
case 1991743458: return bem_MULTIPLY_ASSIGNGetDirect_0();
case 1488343295: return bem_PROPERTIESGet_0();
case -1371969578: return bem_TRYGetDirect_0();
case -215042256: return bem_VARGetDirect_0();
case 640918603: return bem_LOGICAL_ANDGetDirect_0();
case 1121030458: return bem_BREAKGetDirect_0();
case 657894035: return bem_LOOPGet_0();
case 1784815737: return bem_RBRACESGet_0();
case 1969609761: return bem_WSTRQGet_0();
case -639115849: return bem_SUBTRACTGet_0();
case 1462937383: return bem_EXPRGet_0();
case -1980661255: return bem_IDXACCGetDirect_0();
case 72574220: return bem_MODULUS_ASSIGNGet_0();
case 2003548289: return bem_FINALLYGet_0();
case -145699093: return bem_WSTRINGLGetDirect_0();
case 1472658392: return bem_ORGet_0();
case -1338126957: return bem_NEWLINEGetDirect_0();
case -1220181962: return bem_TRUEGet_0();
case 1734346513: return bem_LOGICAL_ANDGet_0();
case 22200630: return bem_IFEMITGetDirect_0();
case 1863015777: return bem_NOTGetDirect_0();
case 878892538: return bem_VARGet_0();
case 525097651: return bem_NOTGet_0();
case 689248882: return bem_METHODGet_0();
case -1500978633: return bem_tagGet_0();
case -806187546: return bem_USEGetDirect_0();
case 1357454754: return bem_OR_ASSIGNGet_0();
case 1087388571: return bem_ONCEGetDirect_0();
case 323470299: return bem_EQUALSGet_0();
case -1769183402: return bem_IDGet_0();
case 418676474: return bem_NAMEPATHGetDirect_0();
case -245131513: return bem_GREATERGetDirect_0();
case 1044843588: return bem_SPACEGet_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case -2140049495: return bem_RIDXGet_0();
case -2060454288: return bem_BLOCKGetDirect_0();
case -2033575780: return bem_MODULUSGetDirect_0();
case -1177927308: return bem_FOREACHGetDirect_0();
case -749285011: return bem_INTLGet_0();
case -908506321: return bem_INCREMENT_ASSIGNGet_0();
case 219645405: return bem_LESSERGetDirect_0();
case 1606054160: return bem_NULLGet_0();
case -1473621861: return bem_STRQGetDirect_0();
case 1529444089: return bem_FALSEGetDirect_0();
case -1163350585: return bem_ADDGetDirect_0();
case -1900229840: return bem_SEMIGetDirect_0();
case -561225113: return bem_PROPERTIESGetDirect_0();
case -1956688063: return bem_INTLGetDirect_0();
case 1009451386: return bem_NULLGetDirect_0();
case 417905012: return bem_default_0();
case -1195365968: return bem_ADDGet_0();
case -330870157: return bem_IFEMITGet_0();
case 565127154: return bem_ATYPEGet_0();
case -561191234: return bem_ATYPEGetDirect_0();
case 386260218: return bem_DECREMENTGetDirect_0();
case -399580634: return bem_USEGet_0();
case -1271929801: return bem_DEFMODGetDirect_0();
case 798806923: return bem_AND_ASSIGNGet_0();
case 2067326231: return bem_INCREMENTGetDirect_0();
case 1653822589: return bem_FLOATLGet_0();
case -2072472298: return bem_hashGet_0();
case -815612608: return bem_GREATER_EQUALSGetDirect_0();
case 1821548604: return bem_BRACESGet_0();
case 191896611: return bem_copy_0();
case -117092508: return bem_DIVIDE_ASSIGNGetDirect_0();
case -426098140: return bem_FORGetDirect_0();
case 595759686: return bem_INGetDirect_0();
case 1811324618: return bem_FORGet_0();
case 397460108: return bem_DECREMENT_ASSIGNGet_0();
case -1610496777: return bem_FSLASHGet_0();
case -1148224702: return bem_TRANSUNITGetDirect_0();
case 845893186: return bem_TRANSUNITGet_0();
case -967622858: return bem_WSTRINGLGet_0();
case 2036147796: return bem_toString_0();
case 1741052207: return bem_COMMAGet_0();
case 539193635: return bem_WHILEGetDirect_0();
case -471538943: return bem_MULTIPLYGet_0();
case -1551806822: return bem_toAny_0();
case -1831881084: return bem_STRINGLGetDirect_0();
case 400497888: return bem_ASSIGNGetDirect_0();
case 2019419473: return bem_DECREMENT_ASSIGNGetDirect_0();
case -498087227: return bem_GET_METHODGetDirect_0();
case 839543436: return bem_PARENSGetDirect_0();
case 64990445: return bem_EMITGet_0();
case -114079936: return bem_serializeContents_0();
case -1041075178: return bem_FALSEGet_0();
case 1201799861: return bem_serializeToString_0();
case 2088096087: return bem_CLASSGetDirect_0();
case -986574256: return bem_CONTINUEGetDirect_0();
case 753264984: return bem_WHILEGet_0();
case 2102651338: return bem_fieldIteratorGet_0();
case 1021497515: return bem_ORGetDirect_0();
case 1441425241: return bem_LOOPGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -460805097: return bem_COMMASetDirect_1(bevd_0);
case 1250937315: return bem_BREAKSetDirect_1(bevd_0);
case 461094820: return bem_CATCHSetDirect_1(bevd_0);
case 847728630: return bem_NEWLINESet_1(bevd_0);
case 1442650031: return bem_GREATER_EQUALSSet_1(bevd_0);
case -160883621: return bem_NOTSetDirect_1(bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case 1121412652: return bem_DIVIDESet_1(bevd_0);
case -395957197: return bem_ORSet_1(bevd_0);
case -1304007786: return bem_LESSERSet_1(bevd_0);
case -1858748797: return bem_BLOCKSet_1(bevd_0);
case -1268269416: return bem_WHILESetDirect_1(bevd_0);
case 1091960420: return bem_SEMISet_1(bevd_0);
case 1612539281: return bem_ACCESSORSetDirect_1(bevd_0);
case 2108026767: return bem_IFSetDirect_1(bevd_0);
case 1998640429: return bem_COLONSet_1(bevd_0);
case 1445157891: return bem_SUBTRACTSetDirect_1(bevd_0);
case -1659557130: return bem_FINALLYSetDirect_1(bevd_0);
case 264373556: return bem_LOGICAL_ANDSetDirect_1(bevd_0);
case -879246526: return bem_VARSet_1(bevd_0);
case 740333101: return bem_FINALLYSet_1(bevd_0);
case 2034814993: return bem_USESet_1(bevd_0);
case 969126770: return bem_NEWLINESetDirect_1(bevd_0);
case 990679473: return bem_IDXSetDirect_1(bevd_0);
case 361035209: return bem_BRACESSet_1(bevd_0);
case 1231630995: return bem_TRUESetDirect_1(bevd_0);
case -1202365573: return bem_MODULUS_ASSIGNSet_1(bevd_0);
case -1076647289: return bem_INCREMENT_ASSIGNSetDirect_1(bevd_0);
case 1160067025: return bem_CALLSetDirect_1(bevd_0);
case -315528231: return bem_CONTINUESet_1(bevd_0);
case -1052403292: return bem_NAMEPATHSetDirect_1(bevd_0);
case 283041912: return bem_TRUESet_1(bevd_0);
case -1650922528: return bem_ADD_ASSIGNSetDirect_1(bevd_0);
case -1864490045: return bem_NOTSet_1(bevd_0);
case -1784384716: return bem_TOKENSet_1(bevd_0);
case 704753799: return bem_WSTRINGLSetDirect_1(bevd_0);
case -1167269010: return bem_LOGICAL_ORSet_1(bevd_0);
case -868338040: return bem_RIDXSetDirect_1(bevd_0);
case 705087130: return bem_ADDSetDirect_1(bevd_0);
case 1226089589: return bem_MANYSet_1(bevd_0);
case -2090118952: return bem_FORSet_1(bevd_0);
case 1011279206: return bem_RBRACESSetDirect_1(bevd_0);
case -1762034714: return bem_FALSESet_1(bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1213744880: return bem_INSetDirect_1(bevd_0);
case 460665619: return bem_SPACESet_1(bevd_0);
case -448915846: return bem_ONCESet_1(bevd_0);
case -1510211931: return bem_INCREMENTSetDirect_1(bevd_0);
case -2020604689: return bem_DECREMENT_ASSIGNSet_1(bevd_0);
case 1972886023: return bem_WSTRINGLSet_1(bevd_0);
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 98285317: return bem_GET_METHODSetDirect_1(bevd_0);
case -199647451: return bem_RPARENSSet_1(bevd_0);
case -360830029: return bem_ACCESSORSet_1(bevd_0);
case -573852437: return bem_WSTRQSet_1(bevd_0);
case -2076864860: return bem_METHODSet_1(bevd_0);
case 1734473406: return bem_NOT_EQUALSSetDirect_1(bevd_0);
case 170241894: return bem_INCREMENTSet_1(bevd_0);
case -1531833325: return bem_MANYSetDirect_1(bevd_0);
case 1590809639: return bem_MULTIPLY_ASSIGNSetDirect_1(bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case 1444470062: return bem_GET_METHODSet_1(bevd_0);
case 39268656: return bem_PROPERTIESSetDirect_1(bevd_0);
case 2044643365: return bem_ASSet_1(bevd_0);
case 860638130: return bem_MULTIPLY_ASSIGNSet_1(bevd_0);
case -670118511: return bem_RPARENSSetDirect_1(bevd_0);
case -1408183511: return bem_DECREMENTSetDirect_1(bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
case 189489642: return bem_SUBTRACT_ASSIGNSetDirect_1(bevd_0);
case -65908249: return bem_MULTIPLYSet_1(bevd_0);
case 1403741613: return bem_TRANSUNITSetDirect_1(bevd_0);
case -1925859227: return bem_COLONSetDirect_1(bevd_0);
case -338816577: return bem_PARENSSet_1(bevd_0);
case -1727938379: return bem_TRANSUNITSet_1(bevd_0);
case -1598008621: return bem_CONTINUESetDirect_1(bevd_0);
case 949696144: return bem_DIVIDE_ASSIGNSetDirect_1(bevd_0);
case -122539055: return bem_EQUALSSetDirect_1(bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
case 767097974: return bem_ASSIGNSetDirect_1(bevd_0);
case -1921255327: return bem_DEFMODSetDirect_1(bevd_0);
case 1882697865: return bem_IDXSet_1(bevd_0);
case 1877284002: return bem_EXPRSet_1(bevd_0);
case -582409657: return bem_BRACESSetDirect_1(bevd_0);
case 1597170756: return bem_FOREACHSet_1(bevd_0);
case -1492964682: return bem_FALSESetDirect_1(bevd_0);
case -2115179706: return bem_EQUALSSet_1(bevd_0);
case -1251985188: return bem_SPACESetDirect_1(bevd_0);
case 1550296283: return bem_BLOCKSetDirect_1(bevd_0);
case -963654570: return bem_EXPRSetDirect_1(bevd_0);
case 1587723027: return bem_NAMEPATHSet_1(bevd_0);
case 417632468: return bem_INTLSetDirect_1(bevd_0);
case 830665914: return bem_ONCESetDirect_1(bevd_0);
case -1056976928: return bem_ATYPESet_1(bevd_0);
case -440035610: return bem_SUBTRACTSet_1(bevd_0);
case 1959529508: return bem_ELSESetDirect_1(bevd_0);
case 376555040: return bem_LESSER_EQUALSSet_1(bevd_0);
case 1462260288: return bem_CLASSSet_1(bevd_0);
case 2085300783: return bem_RBRACESSet_1(bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1767735912: return bem_DECREMENTSet_1(bevd_0);
case -1844720052: return bem_USESetDirect_1(bevd_0);
case 1336514034: return bem_IFEMITSet_1(bevd_0);
case -109503086: return bem_IDSet_1(bevd_0);
case -627932548: return bem_LOGICAL_ORSetDirect_1(bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case 1585511618: return bem_EMITSetDirect_1(bevd_0);
case 270168619: return bem_ATYPESetDirect_1(bevd_0);
case -39337780: return bem_FLOATLSetDirect_1(bevd_0);
case 1981920352: return bem_DECREMENT_ASSIGNSetDirect_1(bevd_0);
case -198062660: return bem_STRINGLSetDirect_1(bevd_0);
case -219254013: return bem_LESSERSetDirect_1(bevd_0);
case -192271885: return bem_equals_1(bevd_0);
case 1206964451: return bem_VARSetDirect_1(bevd_0);
case -605429927: return bem_DIVIDESetDirect_1(bevd_0);
case -1171394282: return bem_LOGICAL_ANDSet_1(bevd_0);
case -2093013770: return bem_GREATER_EQUALSSetDirect_1(bevd_0);
case -1895613112: return bem_NOT_EQUALSSet_1(bevd_0);
case -1499142152: return bem_GREATERSet_1(bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case -1322833197: return bem_NULLSetDirect_1(bevd_0);
case -102295312: return bem_sameObject_1(bevd_0);
case -1124937363: return bem_MODULUSSetDirect_1(bevd_0);
case 884462515: return bem_def_1(bevd_0);
case -1126021432: return bem_ADD_ASSIGNSet_1(bevd_0);
case -1937696991: return bem_INTLSet_1(bevd_0);
case -1939460144: return bem_IFEMITSetDirect_1(bevd_0);
case -252915095: return bem_CATCHSet_1(bevd_0);
case 1313594462: return bem_ELSESet_1(bevd_0);
case -1182144640: return bem_IFSet_1(bevd_0);
case 354436190: return bem_ELIFSet_1(bevd_0);
case -363921378: return bem_IDSetDirect_1(bevd_0);
case -1679463753: return bem_PROPERTIESSet_1(bevd_0);
case 23022029: return bem_LOOPSet_1(bevd_0);
case 152322567: return bem_DOTSet_1(bevd_0);
case 1331957493: return bem_ADDSet_1(bevd_0);
case -958683940: return bem_METHODSetDirect_1(bevd_0);
case 1639311471: return bem_OR_ASSIGNSetDirect_1(bevd_0);
case -215656800: return bem_SUBTRACT_ASSIGNSet_1(bevd_0);
case -1833506834: return bem_ANDSetDirect_1(bevd_0);
case -296469306: return bem_ANDSet_1(bevd_0);
case -1082443015: return bem_RIDXSet_1(bevd_0);
case -1129227201: return bem_SEMISetDirect_1(bevd_0);
case -1103899180: return bem_ASSIGNSet_1(bevd_0);
case 1677165091: return bem_LESSER_EQUALSSetDirect_1(bevd_0);
case -2120597813: return bem_CALLSet_1(bevd_0);
case -613006405: return bem_TRYSetDirect_1(bevd_0);
case 102130839: return bem_DOTSetDirect_1(bevd_0);
case -23302664: return bem_WHILESet_1(bevd_0);
case -1165806809: return bem_LOOPSetDirect_1(bevd_0);
case -1995434122: return bem_OR_ASSIGNSet_1(bevd_0);
case -2053538247: return bem_IDXACCSetDirect_1(bevd_0);
case 451004702: return bem_TOKENSetDirect_1(bevd_0);
case 1934255621: return bem_AND_ASSIGNSet_1(bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case -765314531: return bem_COMMASet_1(bevd_0);
case -691545105: return bem_MULTIPLYSetDirect_1(bevd_0);
case -1773555931: return bem_STRQSetDirect_1(bevd_0);
case 1209245670: return bem_AND_ASSIGNSetDirect_1(bevd_0);
case -1953690178: return bem_MODULUSSet_1(bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
case -19228467: return bem_DIVIDE_ASSIGNSet_1(bevd_0);
case -305690108: return bem_FOREACHSetDirect_1(bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1660839733: return bem_ORSetDirect_1(bevd_0);
case -471373880: return bem_MODULUS_ASSIGNSetDirect_1(bevd_0);
case 1548070522: return bem_DEFMODSet_1(bevd_0);
case 837152793: return bem_FSLASHSet_1(bevd_0);
case -535536703: return bem_GREATERSetDirect_1(bevd_0);
case 867542750: return bem_FLOATLSet_1(bevd_0);
case 65517524: return bem_CLASSSetDirect_1(bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case 2110801622: return bem_EMITSet_1(bevd_0);
case 1873008758: return bem_WSTRQSetDirect_1(bevd_0);
case 1108472506: return bem_FSLASHSetDirect_1(bevd_0);
case 1054090843: return bem_STRINGLSet_1(bevd_0);
case 857269589: return bem_FORSetDirect_1(bevd_0);
case -928244878: return bem_TRYSet_1(bevd_0);
case -1853814208: return bem_INCREMENT_ASSIGNSet_1(bevd_0);
case -2021556964: return bem_ELIFSetDirect_1(bevd_0);
case 873287000: return bem_STRQSet_1(bevd_0);
case -930188724: return bem_INSet_1(bevd_0);
case 1268256568: return bem_NULLSet_1(bevd_0);
case -1150858484: return bem_IDXACCSet_1(bevd_0);
case 862456230: return bem_ASSetDirect_1(bevd_0);
case 358869766: return bem_PARENSSetDirect_1(bevd_0);
case -1785732913: return bem_BREAKSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildNodeTypes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildNodeTypes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildNodeTypes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst = (BEC_2_5_9_BuildNodeTypes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_type;
}
}
