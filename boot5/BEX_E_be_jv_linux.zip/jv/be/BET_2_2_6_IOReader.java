package be;
public class BET_2_2_6_IOReader extends BETS_Object {
public BET_2_2_6_IOReader() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "extOpen_0", "close_0", "vfileGet_0", "vfileSet_1", "byteReaderGet_0", "byteReader_1", "readIntoBuffer_1", "readIntoBuffer_2", "readIntoBuffer_3", "copyData_3", "copyData_1", "readBuffer_0", "readBuffer_1", "readDiscard_0", "readBufferLine_0", "readBufferLine_1", "readString_0", "readString_1", "readStringClose_0", "readDiscardClose_0", "isClosedGet_0", "isClosedSet_1", "blockSizeGet_0", "blockSizeSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "vfile", "isClosed", "blockSize" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_2_6_IOReader();
}
}
