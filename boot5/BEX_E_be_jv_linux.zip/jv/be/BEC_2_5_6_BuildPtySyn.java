package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildPtySyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildPtySyn() { }
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x74,0x79,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_0 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildPtySyn_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildPtySyn_bels_0, 8));
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildPtySyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildPtySyn_bels_1, 4));
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_2 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_3 = {0x6D,0x65,0x6D,0x54,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_4 = {0x61,0x6E,0x79};
public static BEC_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_inst;

public static BET_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_type;

public BEC_2_4_3_MathInt bevp_mpos;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_6_BuildVarSyn bevp_memSyn;
public BEC_2_5_6_BuildPtySyn bem_new_2(BEC_2_6_6_SystemObject beva_vnode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_5_3_BuildVar bevl_v = null;
bevl_v = (BEC_2_5_3_BuildVar) beva_vnode.bemd_0(662888175);
bevp_name = bevl_v.bem_nameGet_0();
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_memSyn = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1(bevl_v);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_0_ta_ph.bem_newlineGet_0();
bevt_5_ta_ph = bece_BEC_2_5_6_BuildPtySyn_bevo_0;
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_nl);
bevt_6_ta_ph = bece_BEC_2_5_6_BuildPtySyn_bevo_1;
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevl_nl);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_name);
bevl_toRet = bevt_1_ta_ph.bem_add_1(bevl_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildPtySyn_bels_2));
bevt_9_ta_ph = bevl_toRet.bemd_1(78930112, bevt_10_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_1(78930112, bevl_nl);
bevt_11_ta_ph = bevp_origin.bem_toString_0();
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(78930112, bevt_11_ta_ph);
bevl_toRet = bevt_7_ta_ph.bemd_1(78930112, bevl_nl);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildPtySyn_bels_3));
bevt_12_ta_ph = bevl_toRet.bemd_1(78930112, bevt_13_ta_ph);
bevl_toRet = bevt_12_ta_ph.bemd_1(78930112, bevl_nl);
bevt_14_ta_ph = bevp_memSyn.bem_isTypedGet_0();
if (bevt_14_ta_ph.bevi_bool)/* Line: 521*/ {
bevt_17_ta_ph = bevp_memSyn.bem_namepathGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bem_toString_0();
bevt_15_ta_ph = bevl_toRet.bemd_1(78930112, bevt_16_ta_ph);
bevl_toRet = bevt_15_ta_ph.bemd_1(78930112, bevl_nl);
} /* Line: 522*/
 else /* Line: 523*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildPtySyn_bels_4));
bevt_18_ta_ph = bevl_toRet.bemd_1(78930112, bevt_19_ta_ph);
bevl_toRet = bevt_18_ta_ph.bemd_1(78930112, bevl_nl);
} /* Line: 524*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_mposGet_0() throws Throwable {
return bevp_mpos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_mposGetDirect_0() throws Throwable {
return bevp_mpos;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_mposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildPtySyn bem_mposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildPtySyn bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_originGetDirect_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildPtySyn bem_originSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_memSynGet_0() throws Throwable {
return bevp_memSyn;
} /*method end*/
public final BEC_2_5_6_BuildVarSyn bem_memSynGetDirect_0() throws Throwable {
return bevp_memSyn;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_memSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildPtySyn bem_memSynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {506, 510, 511, 512, 517, 517, 518, 518, 518, 518, 518, 518, 518, 519, 519, 519, 519, 519, 519, 520, 520, 520, 521, 522, 522, 522, 522, 524, 524, 524, 526, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 25, 26, 27, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 73, 74, 75, 76, 79, 80, 81, 83, 86, 89, 92, 96, 100, 103, 106, 110, 114, 117, 120, 124, 128, 131, 134, 138};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 506 24
heldGet 0 506 24
assign 1 510 25
nameGet 0 510 25
assign 1 511 26
assign 1 512 27
anyNew 1 512 27
assign 1 517 53
new 0 517 53
assign 1 517 54
newlineGet 0 517 54
assign 1 518 55
new 0 518 55
assign 1 518 56
add 1 518 56
assign 1 518 57
new 0 518 57
assign 1 518 58
add 1 518 58
assign 1 518 59
add 1 518 59
assign 1 518 60
add 1 518 60
assign 1 518 61
add 1 518 61
assign 1 519 62
new 0 519 62
assign 1 519 63
add 1 519 63
assign 1 519 64
add 1 519 64
assign 1 519 65
toString 0 519 65
assign 1 519 66
add 1 519 66
assign 1 519 67
add 1 519 67
assign 1 520 68
new 0 520 68
assign 1 520 69
add 1 520 69
assign 1 520 70
add 1 520 70
assign 1 521 71
isTypedGet 0 521 71
assign 1 522 73
namepathGet 0 522 73
assign 1 522 74
toString 0 522 74
assign 1 522 75
add 1 522 75
assign 1 522 76
add 1 522 76
assign 1 524 79
new 0 524 79
assign 1 524 80
add 1 524 80
assign 1 524 81
add 1 524 81
return 1 526 83
return 1 0 86
return 1 0 89
assign 1 0 92
assign 1 0 96
return 1 0 100
return 1 0 103
assign 1 0 106
assign 1 0 110
return 1 0 114
return 1 0 117
assign 1 0 120
assign 1 0 124
return 1 0 128
return 1 0 131
assign 1 0 134
assign 1 0 138
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 221458969: return bem_serializeToString_0();
case -1238524057: return bem_print_0();
case 993286746: return bem_echo_0();
case 366497711: return bem_memSynGetDirect_0();
case -854269887: return bem_nameGetDirect_0();
case 137910263: return bem_create_0();
case -992634121: return bem_tagGet_0();
case -1426056679: return bem_hashGet_0();
case -1851472893: return bem_once_0();
case -1167649350: return bem_originGet_0();
case -1070373052: return bem_mposGet_0();
case -1714583788: return bem_classNameGet_0();
case 814015164: return bem_copy_0();
case -438289515: return bem_fieldIteratorGet_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -777537417: return bem_serializeContents_0();
case 217381802: return bem_serializationIteratorGet_0();
case 205150354: return bem_new_0();
case -188791018: return bem_memSynGet_0();
case -1331626162: return bem_iteratorGet_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 96025203: return bem_originGetDirect_0();
case -1079456517: return bem_many_0();
case 78412540: return bem_toAny_0();
case -1392846471: return bem_toString_0();
case 310047227: return bem_fieldNamesGet_0();
case -659624220: return bem_mposGetDirect_0();
case -1466994215: return bem_nameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 763343837: return bem_nameSet_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1501852638: return bem_mposSet_1(bevd_0);
case 2042665444: return bem_nameSetDirect_1(bevd_0);
case 318721777: return bem_memSynSet_1(bevd_0);
case -2124427442: return bem_memSynSetDirect_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case 1094584091: return bem_mposSetDirect_1(bevd_0);
case -805967429: return bem_originSet_1(bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case -302072225: return bem_originSetDirect_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -523562161: return bem_new_2(bevd_0, bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildPtySyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildPtySyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildPtySyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst = (BEC_2_5_6_BuildPtySyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_type;
}
}
