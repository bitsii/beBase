package be;
public class BET_2_5_6_BuildMtdSyn extends BETS_Object {
public BET_2_5_6_BuildMtdSyn() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_2", "getEmitReturnType_2", "hposGet_0", "hposSet_1", "mtdxGet_0", "mtdxSet_1", "numargsGet_0", "numargsSet_1", "nameGet_0", "nameSet_1", "orgNameGet_0", "orgNameSet_1", "isGenAccessorGet_0", "isGenAccessorSet_1", "argSynsGet_0", "argSynsSet_1", "originGet_0", "originSet_1", "declarationGet_0", "declarationSet_1", "lastDefGet_0", "lastDefSet_1", "isOverrideGet_0", "isOverrideSet_1", "isFinalGet_0", "isFinalSet_1", "propertyNameGet_0", "propertyNameSet_1", "rsynGet_0", "rsynSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "hpos", "mtdx", "numargs", "name", "orgName", "isGenAccessor", "argSyns", "origin", "declaration", "lastDef", "isOverride", "isFinal", "propertyName", "rsyn" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_6_BuildMtdSyn();
}
}
