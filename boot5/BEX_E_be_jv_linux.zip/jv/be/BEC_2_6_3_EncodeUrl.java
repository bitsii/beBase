package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeUrl extends BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_BEC_2_6_3_EncodeUrl_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_BEC_2_6_3_EncodeUrl_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_1 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_2 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_3 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_4 = (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_5 = (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_6 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_7 = (new BEC_2_4_3_MathInt(44));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_8 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_9 = (new BEC_2_4_3_MathInt(42));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_10 = (new BEC_2_4_3_MathInt(32));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_0 = {0x2B};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_1 = {0x25};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_1, 1));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_2 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_16 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_17 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_1, 1));
public static BEC_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_inst;

public static BET_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_type;

public BEC_2_6_3_EncodeUrl bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_EncodeUrl bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
bevt_6_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_7_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_0;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_multiply_1(bevt_7_tmpany_phold);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_tmpany_phold);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_tmpany_phold);
while (true)
 /* Line: 216 */ {
bevt_9_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_tmpany_phold);
bevt_12_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_1;
if (bevl_ac.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_2;
if (bevl_ac.bevi_int < bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
 else  /* Line: 219 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 219 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_16_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_3;
if (bevl_ac.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_18_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_4;
if (bevl_ac.bevi_int < bevt_18_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
 else  /* Line: 219 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 219 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 219 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_20_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_5;
if (bevl_ac.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_22_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_6;
if (bevl_ac.bevi_int < bevt_22_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
 else  /* Line: 219 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 219 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 219 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_7;
if (bevl_ac.bevi_int > bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_26_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_8;
if (bevl_ac.bevi_int < bevt_26_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
 else  /* Line: 219 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 219 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 219 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_28_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_9;
if (bevl_ac.bevi_int == bevt_28_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 219 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 220 */
 else  /* Line: 219 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_10;
if (bevl_ac.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_r.bem_addValue_1(bevt_31_tmpany_phold);
} /* Line: 222 */
 else  /* Line: 223 */ {
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_r.bem_addValue_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_tmpany_phold);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 226 */
} /* Line: 219 */
} /* Line: 219 */
 else  /* Line: 216 */ {
break;
} /* Line: 216 */
} /* Line: 216 */
bevt_34_tmpany_phold = bevl_r.bem_toString_0();
return bevt_34_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
bevt_2_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevl_last = (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_11;
bevl_npl = beva_str.bem_find_2(bevt_3_tmpany_phold, bevl_last);
bevt_4_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_12;
bevl_npe = beva_str.bem_find_2(bevt_4_tmpany_phold, bevl_last);
if (bevl_npe == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
if (bevl_npl == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 242 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevl_ispl = be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 244 */
 else  /* Line: 245 */ {
bevl_ispl = be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 247 */
bevl_len = beva_str.bem_sizeGet_0();
while (true)
 /* Line: 251 */ {
if (bevl_i == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 251 */ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevt_10_tmpany_phold = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_tmpany_phold);
bevl_last = bevl_i;
} /* Line: 254 */
if (bevl_ispl.bevi_bool) /* Line: 256 */ {
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_2));
bevl_r.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_13;
bevl_last = bevl_i.bem_add_1(bevt_12_tmpany_phold);
} /* Line: 258 */
 else  /* Line: 259 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_14;
bevt_14_tmpany_phold = bevl_i.bem_add_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_int < bevl_len.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_15;
bevt_18_tmpany_phold = bevl_i.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_16;
bevt_20_tmpany_phold = bevl_i.bem_add_1(bevt_21_tmpany_phold);
bevt_17_tmpany_phold = beva_str.bem_substring_2(bevt_18_tmpany_phold, bevt_20_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_tmpany_phold);
bevl_r.bem_addValue_1(bevt_16_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_17;
bevl_last = bevl_i.bem_add_1(bevt_22_tmpany_phold);
} /* Line: 262 */
} /* Line: 260 */
bevt_23_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_18;
bevl_npl = beva_str.bem_find_2(bevt_23_tmpany_phold, bevl_last);
bevt_24_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_19;
bevl_npe = beva_str.bem_find_2(bevt_24_tmpany_phold, bevl_last);
if (bevl_npe == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
if (bevl_npl == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 267 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 267 */
 else  /* Line: 267 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 267 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 267 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 267 */ {
bevl_ispl = be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 269 */
 else  /* Line: 270 */ {
bevl_ispl = be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 272 */
} /* Line: 267 */
 else  /* Line: 251 */ {
break;
} /* Line: 251 */
} /* Line: 251 */
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevt_29_tmpany_phold = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_tmpany_phold);
} /* Line: 276 */
bevt_30_tmpany_phold = bevl_r.bem_toString_0();
return bevt_30_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {213, 213, 213, 213, 214, 215, 215, 216, 217, 218, 218, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 0, 0, 220, 221, 221, 221, 222, 222, 224, 224, 225, 225, 226, 229, 229, 233, 233, 234, 240, 240, 241, 241, 242, 242, 0, 242, 242, 242, 242, 0, 0, 0, 0, 0, 243, 244, 246, 247, 250, 251, 251, 252, 252, 253, 253, 254, 257, 257, 258, 258, 260, 260, 260, 260, 261, 261, 261, 261, 261, 261, 261, 262, 262, 265, 265, 266, 266, 267, 267, 0, 267, 267, 267, 267, 0, 0, 0, 0, 0, 268, 269, 271, 272, 275, 275, 276, 276, 278, 278};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {83, 84, 85, 86, 87, 88, 89, 92, 94, 95, 96, 97, 98, 103, 104, 105, 110, 111, 114, 118, 121, 124, 125, 130, 131, 132, 137, 138, 141, 145, 148, 151, 155, 158, 159, 164, 165, 166, 171, 172, 175, 179, 182, 185, 189, 192, 193, 198, 199, 200, 205, 206, 209, 213, 216, 219, 223, 226, 227, 232, 233, 236, 240, 243, 244, 249, 250, 251, 254, 255, 256, 257, 258, 266, 267, 308, 309, 310, 311, 312, 313, 314, 315, 320, 321, 324, 329, 330, 335, 336, 339, 343, 346, 349, 353, 354, 357, 358, 360, 363, 368, 369, 374, 375, 376, 377, 380, 381, 382, 383, 386, 387, 388, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 405, 406, 407, 408, 409, 414, 415, 418, 423, 424, 429, 430, 433, 437, 440, 443, 447, 448, 451, 452, 459, 464, 465, 466, 468, 469};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 213 83
sizeGet 0 213 83
assign 1 213 84
new 0 213 84
assign 1 213 85
multiply 1 213 85
assign 1 213 86
new 1 213 86
assign 1 214 87
new 1 214 87
assign 1 215 88
new 0 215 88
assign 1 215 89
new 1 215 89
assign 1 216 92
hasNextGet 0 216 92
next 1 217 94
assign 1 218 95
new 0 218 95
assign 1 218 96
getCode 1 218 96
assign 1 219 97
new 0 219 97
assign 1 219 98
greater 1 219 103
assign 1 219 104
new 0 219 104
assign 1 219 105
lesser 1 219 110
assign 1 0 111
assign 1 0 114
assign 1 0 118
assign 1 0 121
assign 1 219 124
new 0 219 124
assign 1 219 125
greater 1 219 130
assign 1 219 131
new 0 219 131
assign 1 219 132
lesser 1 219 137
assign 1 0 138
assign 1 0 141
assign 1 0 145
assign 1 0 148
assign 1 0 151
assign 1 0 155
assign 1 219 158
new 0 219 158
assign 1 219 159
greater 1 219 164
assign 1 219 165
new 0 219 165
assign 1 219 166
lesser 1 219 171
assign 1 0 172
assign 1 0 175
assign 1 0 179
assign 1 0 182
assign 1 0 185
assign 1 0 189
assign 1 219 192
new 0 219 192
assign 1 219 193
greater 1 219 198
assign 1 219 199
new 0 219 199
assign 1 219 200
lesser 1 219 205
assign 1 0 206
assign 1 0 209
assign 1 0 213
assign 1 0 216
assign 1 0 219
assign 1 0 223
assign 1 219 226
new 0 219 226
assign 1 219 227
equals 1 219 232
assign 1 0 233
assign 1 0 236
addValue 1 220 240
assign 1 221 243
new 0 221 243
assign 1 221 244
equals 1 221 249
assign 1 222 250
new 0 222 250
addValue 1 222 251
assign 1 224 254
new 0 224 254
addValue 1 224 255
assign 1 225 256
new 0 225 256
assign 1 225 257
getHex 1 225 257
addValue 1 226 258
assign 1 229 266
toString 0 229 266
return 1 229 267
assign 1 233 308
sizeGet 0 233 308
assign 1 233 309
new 1 233 309
assign 1 234 310
new 0 234 310
assign 1 240 311
new 0 240 311
assign 1 240 312
find 2 240 312
assign 1 241 313
new 0 241 313
assign 1 241 314
find 2 241 314
assign 1 242 315
undef 1 242 320
assign 1 0 321
assign 1 242 324
def 1 242 329
assign 1 242 330
lesser 1 242 335
assign 1 0 336
assign 1 0 339
assign 1 0 343
assign 1 0 346
assign 1 0 349
assign 1 243 353
new 0 243 353
assign 1 244 354
assign 1 246 357
new 0 246 357
assign 1 247 358
assign 1 250 360
sizeGet 0 250 360
assign 1 251 363
def 1 251 368
assign 1 252 369
greater 1 252 374
assign 1 253 375
substring 2 253 375
addValue 1 253 376
assign 1 254 377
assign 1 257 380
new 0 257 380
addValue 1 257 381
assign 1 258 382
new 0 258 382
assign 1 258 383
add 1 258 383
assign 1 260 386
new 0 260 386
assign 1 260 387
add 1 260 387
assign 1 260 388
lesser 1 260 393
assign 1 261 394
new 0 261 394
assign 1 261 395
add 1 261 395
assign 1 261 396
new 0 261 396
assign 1 261 397
add 1 261 397
assign 1 261 398
substring 2 261 398
assign 1 261 399
hexNew 1 261 399
addValue 1 261 400
assign 1 262 401
new 0 262 401
assign 1 262 402
add 1 262 402
assign 1 265 405
new 0 265 405
assign 1 265 406
find 2 265 406
assign 1 266 407
new 0 266 407
assign 1 266 408
find 2 266 408
assign 1 267 409
undef 1 267 414
assign 1 0 415
assign 1 267 418
def 1 267 423
assign 1 267 424
lesser 1 267 429
assign 1 0 430
assign 1 0 433
assign 1 0 437
assign 1 0 440
assign 1 0 443
assign 1 268 447
new 0 268 447
assign 1 269 448
assign 1 271 451
new 0 271 451
assign 1 272 452
assign 1 275 459
lesser 1 275 464
assign 1 276 465
substring 2 276 465
addValue 1 276 466
assign 1 278 468
toString 0 278 468
return 1 278 469
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1890761825: return bem_hashGet_0();
case -1154985755: return bem_echo_0();
case -1155411626: return bem_classNameGet_0();
case -225078823: return bem_serializationIteratorGet_0();
case 285074277: return bem_deserializeClassNameGet_0();
case -1845402369: return bem_create_0();
case 1835904283: return bem_fieldIteratorGet_0();
case 944745844: return bem_iteratorGet_0();
case -858518329: return bem_many_0();
case -703952395: return bem_toAny_0();
case 745980876: return bem_serializeToString_0();
case -1581691779: return bem_default_0();
case -967525204: return bem_fieldNamesGet_0();
case 863596927: return bem_sourceFileNameGet_0();
case 1592801927: return bem_serializeContents_0();
case 232809271: return bem_copy_0();
case -1995804558: return bem_toString_0();
case 841207683: return bem_new_0();
case -513985458: return bem_once_0();
case -1247813666: return bem_tagGet_0();
case 1562045422: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1200297939: return bem_undef_1(bevd_0);
case 1175425352: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1434914609: return bem_defined_1(bevd_0);
case -101472629: return bem_undefined_1(bevd_0);
case 1711878001: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1230305150: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case -409603043: return bem_notEquals_1(bevd_0);
case 1610111542: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 12031225: return bem_def_1(bevd_0);
case -889830673: return bem_otherType_1(bevd_0);
case -1815546435: return bem_copyTo_1(bevd_0);
case 717943216: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 321841131: return bem_sameClass_1(bevd_0);
case -1928853523: return bem_equals_1(bevd_0);
case 664229508: return bem_otherClass_1(bevd_0);
case 924871251: return bem_sameType_1(bevd_0);
case 889966047: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 534285564: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1856372729: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1188590573: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1597169568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1167360045: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 539198382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310017806: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -987687744: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeUrl_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeUrl_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_EncodeUrl();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst = (BEC_2_6_3_EncodeUrl) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_type;
}
}
