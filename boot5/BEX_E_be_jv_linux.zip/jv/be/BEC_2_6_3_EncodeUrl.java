package be;
/* IO:File: source/base/EncodeUrl.be */
public class BEC_2_6_3_EncodeUrl extends BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_BEC_2_6_3_EncodeUrl_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_BEC_2_6_3_EncodeUrl_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x55,0x72,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_0 = {0x2B};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_1 = {0x25};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_2 = {0x20};
public static BEC_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_inst;

public static BET_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_type;

public BEC_2_6_3_EncodeUrl bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_EncodeUrl bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
bevt_6_ta_ph = beva_str.bem_sizeGet_0();
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = bevt_6_ta_ph.bem_multiply_1(bevt_7_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_ta_ph);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_ta_ph);
while (true)
/* Line: 22*/ {
bevt_9_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 22*/ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ac.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ac.bevi_int < bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 25*/
 else /* Line: 25*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 25*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ac.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(94));
if (bevl_ac.bevi_int < bevt_18_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 25*/
 else /* Line: 25*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 25*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 25*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 25*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(94));
if (bevl_ac.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ac.bevi_int < bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 25*/
 else /* Line: 25*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 25*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 25*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 25*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(44));
if (bevl_ac.bevi_int > bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ac.bevi_int < bevt_26_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 25*/
 else /* Line: 25*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 25*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 25*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 25*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_28_ta_ph = (new BEC_2_4_3_MathInt(42));
if (bevl_ac.bevi_int == bevt_28_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 25*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 25*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 25*/ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 26*/
 else /* Line: 25*/ {
bevt_30_ta_ph = (new BEC_2_4_3_MathInt(32));
if (bevl_ac.bevi_int == bevt_30_ta_ph.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 27*/ {
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_r.bem_addValue_1(bevt_31_ta_ph);
} /* Line: 28*/
 else /* Line: 29*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_r.bem_addValue_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_ta_ph);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 32*/
} /* Line: 25*/
} /* Line: 25*/
 else /* Line: 22*/ {
break;
} /* Line: 22*/
} /* Line: 22*/
bevt_34_ta_ph = bevl_r.bem_toString_0();
return bevt_34_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
bevt_2_ta_ph = beva_str.bem_sizeGet_0();
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevl_last = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_npl = beva_str.bem_find_2(bevt_3_ta_ph, bevl_last);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_npe = beva_str.bem_find_2(bevt_4_ta_ph, bevl_last);
if (bevl_npe == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 48*/ {
if (bevl_npl == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 48*/ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 48*/
 else /* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 48*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 48*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 48*/ {
bevl_ispl = be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 50*/
 else /* Line: 51*/ {
bevl_ispl = be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 53*/
bevl_len = beva_str.bem_sizeGet_0();
while (true)
/* Line: 57*/ {
if (bevl_i == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 57*/ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 58*/ {
bevt_10_ta_ph = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_ta_ph);
bevl_last = bevl_i;
} /* Line: 60*/
if (bevl_ispl.bevi_bool)/* Line: 62*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_2));
bevl_r.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_last = bevl_i.bem_add_1(bevt_12_ta_ph);
} /* Line: 64*/
 else /* Line: 65*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_14_ta_ph = bevl_i.bem_add_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_int < bevl_len.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 66*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_18_ta_ph = bevl_i.bem_add_1(bevt_19_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_20_ta_ph = bevl_i.bem_add_1(bevt_21_ta_ph);
bevt_17_ta_ph = beva_str.bem_substring_2(bevt_18_ta_ph, bevt_20_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_ta_ph);
bevl_r.bem_addValue_1(bevt_16_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(3));
bevl_last = bevl_i.bem_add_1(bevt_22_ta_ph);
} /* Line: 68*/
} /* Line: 66*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_npl = beva_str.bem_find_2(bevt_23_ta_ph, bevl_last);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_npe = beva_str.bem_find_2(bevt_24_ta_ph, bevl_last);
if (bevl_npe == null) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
if (bevl_npl == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 73*/ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 73*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 73*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 73*/ {
bevl_ispl = be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 75*/
 else /* Line: 76*/ {
bevl_ispl = be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 78*/
} /* Line: 73*/
 else /* Line: 57*/ {
break;
} /* Line: 57*/
} /* Line: 57*/
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 81*/ {
bevt_29_ta_ph = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_ta_ph);
} /* Line: 82*/
bevt_30_ta_ph = bevl_r.bem_toString_0();
return bevt_30_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {19, 19, 19, 19, 20, 21, 21, 22, 23, 24, 24, 25, 25, 25, 25, 25, 25, 0, 0, 0, 0, 25, 25, 25, 25, 25, 25, 0, 0, 0, 0, 0, 0, 25, 25, 25, 25, 25, 25, 0, 0, 0, 0, 0, 0, 25, 25, 25, 25, 25, 25, 0, 0, 0, 0, 0, 0, 25, 25, 25, 0, 0, 26, 27, 27, 27, 28, 28, 30, 30, 31, 31, 32, 35, 35, 39, 39, 40, 46, 46, 47, 47, 48, 48, 0, 48, 48, 48, 48, 0, 0, 0, 0, 0, 49, 50, 52, 53, 56, 57, 57, 58, 58, 59, 59, 60, 63, 63, 64, 64, 66, 66, 66, 66, 67, 67, 67, 67, 67, 67, 67, 68, 68, 71, 71, 72, 72, 73, 73, 0, 73, 73, 73, 73, 0, 0, 0, 0, 0, 74, 75, 77, 78, 81, 81, 82, 82, 84, 84};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {61, 62, 63, 64, 65, 66, 67, 70, 72, 73, 74, 75, 76, 81, 82, 83, 88, 89, 92, 96, 99, 102, 103, 108, 109, 110, 115, 116, 119, 123, 126, 129, 133, 136, 137, 142, 143, 144, 149, 150, 153, 157, 160, 163, 167, 170, 171, 176, 177, 178, 183, 184, 187, 191, 194, 197, 201, 204, 205, 210, 211, 214, 218, 221, 222, 227, 228, 229, 232, 233, 234, 235, 236, 244, 245, 286, 287, 288, 289, 290, 291, 292, 293, 298, 299, 302, 307, 308, 313, 314, 317, 321, 324, 327, 331, 332, 335, 336, 338, 341, 346, 347, 352, 353, 354, 355, 358, 359, 360, 361, 364, 365, 366, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 383, 384, 385, 386, 387, 392, 393, 396, 401, 402, 407, 408, 411, 415, 418, 421, 425, 426, 429, 430, 437, 442, 443, 444, 446, 447};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 19 61
sizeGet 0 19 61
assign 1 19 62
new 0 19 62
assign 1 19 63
multiply 1 19 63
assign 1 19 64
new 1 19 64
assign 1 20 65
new 1 20 65
assign 1 21 66
new 0 21 66
assign 1 21 67
new 1 21 67
assign 1 22 70
hasNextGet 0 22 70
next 1 23 72
assign 1 24 73
new 0 24 73
assign 1 24 74
getCode 1 24 74
assign 1 25 75
new 0 25 75
assign 1 25 76
greater 1 25 81
assign 1 25 82
new 0 25 82
assign 1 25 83
lesser 1 25 88
assign 1 0 89
assign 1 0 92
assign 1 0 96
assign 1 0 99
assign 1 25 102
new 0 25 102
assign 1 25 103
greater 1 25 108
assign 1 25 109
new 0 25 109
assign 1 25 110
lesser 1 25 115
assign 1 0 116
assign 1 0 119
assign 1 0 123
assign 1 0 126
assign 1 0 129
assign 1 0 133
assign 1 25 136
new 0 25 136
assign 1 25 137
greater 1 25 142
assign 1 25 143
new 0 25 143
assign 1 25 144
lesser 1 25 149
assign 1 0 150
assign 1 0 153
assign 1 0 157
assign 1 0 160
assign 1 0 163
assign 1 0 167
assign 1 25 170
new 0 25 170
assign 1 25 171
greater 1 25 176
assign 1 25 177
new 0 25 177
assign 1 25 178
lesser 1 25 183
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 0 194
assign 1 0 197
assign 1 0 201
assign 1 25 204
new 0 25 204
assign 1 25 205
equals 1 25 210
assign 1 0 211
assign 1 0 214
addValue 1 26 218
assign 1 27 221
new 0 27 221
assign 1 27 222
equals 1 27 227
assign 1 28 228
new 0 28 228
addValue 1 28 229
assign 1 30 232
new 0 30 232
addValue 1 30 233
assign 1 31 234
new 0 31 234
assign 1 31 235
getHex 1 31 235
addValue 1 32 236
assign 1 35 244
toString 0 35 244
return 1 35 245
assign 1 39 286
sizeGet 0 39 286
assign 1 39 287
new 1 39 287
assign 1 40 288
new 0 40 288
assign 1 46 289
new 0 46 289
assign 1 46 290
find 2 46 290
assign 1 47 291
new 0 47 291
assign 1 47 292
find 2 47 292
assign 1 48 293
undef 1 48 298
assign 1 0 299
assign 1 48 302
def 1 48 307
assign 1 48 308
lesser 1 48 313
assign 1 0 314
assign 1 0 317
assign 1 0 321
assign 1 0 324
assign 1 0 327
assign 1 49 331
new 0 49 331
assign 1 50 332
assign 1 52 335
new 0 52 335
assign 1 53 336
assign 1 56 338
sizeGet 0 56 338
assign 1 57 341
def 1 57 346
assign 1 58 347
greater 1 58 352
assign 1 59 353
substring 2 59 353
addValue 1 59 354
assign 1 60 355
assign 1 63 358
new 0 63 358
addValue 1 63 359
assign 1 64 360
new 0 64 360
assign 1 64 361
add 1 64 361
assign 1 66 364
new 0 66 364
assign 1 66 365
add 1 66 365
assign 1 66 366
lesser 1 66 371
assign 1 67 372
new 0 67 372
assign 1 67 373
add 1 67 373
assign 1 67 374
new 0 67 374
assign 1 67 375
add 1 67 375
assign 1 67 376
substring 2 67 376
assign 1 67 377
hexNew 1 67 377
addValue 1 67 378
assign 1 68 379
new 0 68 379
assign 1 68 380
add 1 68 380
assign 1 71 383
new 0 71 383
assign 1 71 384
find 2 71 384
assign 1 72 385
new 0 72 385
assign 1 72 386
find 2 72 386
assign 1 73 387
undef 1 73 392
assign 1 0 393
assign 1 73 396
def 1 73 401
assign 1 73 402
lesser 1 73 407
assign 1 0 408
assign 1 0 411
assign 1 0 415
assign 1 0 418
assign 1 0 421
assign 1 74 425
new 0 74 425
assign 1 75 426
assign 1 77 429
new 0 77 429
assign 1 78 430
assign 1 81 437
lesser 1 81 442
assign 1 82 443
substring 2 82 443
addValue 1 82 444
assign 1 84 446
toString 0 84 446
return 1 84 447
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1718188704: return bem_hashGet_0();
case 807655445: return bem_print_0();
case -677150073: return bem_toString_0();
case 1342623754: return bem_copy_0();
case 247576523: return bem_classNameGet_0();
case -2124354635: return bem_serializeToString_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case -543330026: return bem_fieldNamesGet_0();
case -225222698: return bem_create_0();
case 2066839134: return bem_iteratorGet_0();
case 498101216: return bem_echo_0();
case 556565361: return bem_serializationIteratorGet_0();
case -1749437314: return bem_tagGet_0();
case -313059782: return bem_default_0();
case 126387064: return bem_new_0();
case 409380620: return bem_fieldIteratorGet_0();
case -1794485421: return bem_serializeContents_0();
case 398187407: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -404194174: return bem_copyTo_1(bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case 1502842604: return bem_def_1(bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case -1071778724: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
case 88670244: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeUrl_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_3_EncodeUrl_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_EncodeUrl();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst = (BEC_2_6_3_EncodeUrl) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_type;
}
}
