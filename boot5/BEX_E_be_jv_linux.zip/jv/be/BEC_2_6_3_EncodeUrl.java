package be;
/* IO:File: source/base/EncodeUrl.be */
public class BEC_2_6_3_EncodeUrl extends BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_BEC_2_6_3_EncodeUrl_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_BEC_2_6_3_EncodeUrl_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x55,0x72,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_0 = {0x2B};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_1 = {0x25};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_2 = {0x20};
public static BEC_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_inst;

public static BET_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_type;

public BEC_2_6_3_EncodeUrl bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_EncodeUrl bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
bevt_6_ta_ph = beva_str.bem_lengthGet_0();
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = bevt_6_ta_ph.bem_multiply_1(bevt_7_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_ta_ph);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_ta_ph);
while (true)
/* Line: 28*/ {
bevt_9_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 28*/ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ac.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ac.bevi_int < bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
 else /* Line: 31*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ac.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(94));
if (bevl_ac.bevi_int < bevt_18_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
 else /* Line: 31*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(94));
if (bevl_ac.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ac.bevi_int < bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
 else /* Line: 31*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(44));
if (bevl_ac.bevi_int > bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ac.bevi_int < bevt_26_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
 else /* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_28_ta_ph = (new BEC_2_4_3_MathInt(42));
if (bevl_ac.bevi_int == bevt_28_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 31*/ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 32*/
 else /* Line: 31*/ {
bevt_30_ta_ph = (new BEC_2_4_3_MathInt(32));
if (bevl_ac.bevi_int == bevt_30_ta_ph.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 33*/ {
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_r.bem_addValue_1(bevt_31_ta_ph);
} /* Line: 34*/
 else /* Line: 35*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_r.bem_addValue_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_ta_ph);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 38*/
} /* Line: 31*/
} /* Line: 31*/
 else /* Line: 28*/ {
break;
} /* Line: 28*/
} /* Line: 28*/
bevt_34_ta_ph = bevl_r.bem_toString_0();
return bevt_34_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
bevt_2_ta_ph = beva_str.bem_lengthGet_0();
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevl_last = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_npl = beva_str.bem_find_2(bevt_3_ta_ph, bevl_last);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_npe = beva_str.bem_find_2(bevt_4_ta_ph, bevl_last);
if (bevl_npe == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 54*/ {
if (bevl_npl == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 54*/ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 54*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 54*/
 else /* Line: 54*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 54*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 54*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 54*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 54*/ {
bevl_ispl = be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 56*/
 else /* Line: 57*/ {
bevl_ispl = be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 59*/
bevl_len = beva_str.bem_lengthGet_0();
while (true)
/* Line: 63*/ {
if (bevl_i == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 63*/ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 64*/ {
bevt_10_ta_ph = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_ta_ph);
bevl_last = bevl_i;
} /* Line: 66*/
if (bevl_ispl.bevi_bool)/* Line: 68*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_2));
bevl_r.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_last = bevl_i.bem_add_1(bevt_12_ta_ph);
} /* Line: 70*/
 else /* Line: 71*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_14_ta_ph = bevl_i.bem_add_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_int < bevl_len.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_18_ta_ph = bevl_i.bem_add_1(bevt_19_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_20_ta_ph = bevl_i.bem_add_1(bevt_21_ta_ph);
bevt_17_ta_ph = beva_str.bem_substring_2(bevt_18_ta_ph, bevt_20_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_ta_ph);
bevl_r.bem_addValue_1(bevt_16_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(3));
bevl_last = bevl_i.bem_add_1(bevt_22_ta_ph);
} /* Line: 74*/
} /* Line: 72*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_npl = beva_str.bem_find_2(bevt_23_ta_ph, bevl_last);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_npe = beva_str.bem_find_2(bevt_24_ta_ph, bevl_last);
if (bevl_npe == null) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 79*/ {
if (bevl_npl == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 79*/ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 79*/
 else /* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 79*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 79*/ {
bevl_ispl = be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 81*/
 else /* Line: 82*/ {
bevl_ispl = be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 84*/
} /* Line: 79*/
 else /* Line: 63*/ {
break;
} /* Line: 63*/
} /* Line: 63*/
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 87*/ {
bevt_29_ta_ph = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_ta_ph);
} /* Line: 88*/
bevt_30_ta_ph = bevl_r.bem_toString_0();
return bevt_30_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {25, 25, 25, 25, 26, 27, 27, 28, 29, 30, 30, 31, 31, 31, 31, 31, 31, 0, 0, 0, 0, 31, 31, 31, 31, 31, 31, 0, 0, 0, 0, 0, 0, 31, 31, 31, 31, 31, 31, 0, 0, 0, 0, 0, 0, 31, 31, 31, 31, 31, 31, 0, 0, 0, 0, 0, 0, 31, 31, 31, 0, 0, 32, 33, 33, 33, 34, 34, 36, 36, 37, 37, 38, 41, 41, 45, 45, 46, 52, 52, 53, 53, 54, 54, 0, 54, 54, 54, 54, 0, 0, 0, 0, 0, 55, 56, 58, 59, 62, 63, 63, 64, 64, 65, 65, 66, 69, 69, 70, 70, 72, 72, 72, 72, 73, 73, 73, 73, 73, 73, 73, 74, 74, 77, 77, 78, 78, 79, 79, 0, 79, 79, 79, 79, 0, 0, 0, 0, 0, 80, 81, 83, 84, 87, 87, 88, 88, 90, 90};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {61, 62, 63, 64, 65, 66, 67, 70, 72, 73, 74, 75, 76, 81, 82, 83, 88, 89, 92, 96, 99, 102, 103, 108, 109, 110, 115, 116, 119, 123, 126, 129, 133, 136, 137, 142, 143, 144, 149, 150, 153, 157, 160, 163, 167, 170, 171, 176, 177, 178, 183, 184, 187, 191, 194, 197, 201, 204, 205, 210, 211, 214, 218, 221, 222, 227, 228, 229, 232, 233, 234, 235, 236, 244, 245, 286, 287, 288, 289, 290, 291, 292, 293, 298, 299, 302, 307, 308, 313, 314, 317, 321, 324, 327, 331, 332, 335, 336, 338, 341, 346, 347, 352, 353, 354, 355, 358, 359, 360, 361, 364, 365, 366, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 383, 384, 385, 386, 387, 392, 393, 396, 401, 402, 407, 408, 411, 415, 418, 421, 425, 426, 429, 430, 437, 442, 443, 444, 446, 447};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 25 61
lengthGet 0 25 61
assign 1 25 62
new 0 25 62
assign 1 25 63
multiply 1 25 63
assign 1 25 64
new 1 25 64
assign 1 26 65
new 1 26 65
assign 1 27 66
new 0 27 66
assign 1 27 67
new 1 27 67
assign 1 28 70
hasNextGet 0 28 70
next 1 29 72
assign 1 30 73
new 0 30 73
assign 1 30 74
getCode 1 30 74
assign 1 31 75
new 0 31 75
assign 1 31 76
greater 1 31 81
assign 1 31 82
new 0 31 82
assign 1 31 83
lesser 1 31 88
assign 1 0 89
assign 1 0 92
assign 1 0 96
assign 1 0 99
assign 1 31 102
new 0 31 102
assign 1 31 103
greater 1 31 108
assign 1 31 109
new 0 31 109
assign 1 31 110
lesser 1 31 115
assign 1 0 116
assign 1 0 119
assign 1 0 123
assign 1 0 126
assign 1 0 129
assign 1 0 133
assign 1 31 136
new 0 31 136
assign 1 31 137
greater 1 31 142
assign 1 31 143
new 0 31 143
assign 1 31 144
lesser 1 31 149
assign 1 0 150
assign 1 0 153
assign 1 0 157
assign 1 0 160
assign 1 0 163
assign 1 0 167
assign 1 31 170
new 0 31 170
assign 1 31 171
greater 1 31 176
assign 1 31 177
new 0 31 177
assign 1 31 178
lesser 1 31 183
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 0 194
assign 1 0 197
assign 1 0 201
assign 1 31 204
new 0 31 204
assign 1 31 205
equals 1 31 210
assign 1 0 211
assign 1 0 214
addValue 1 32 218
assign 1 33 221
new 0 33 221
assign 1 33 222
equals 1 33 227
assign 1 34 228
new 0 34 228
addValue 1 34 229
assign 1 36 232
new 0 36 232
addValue 1 36 233
assign 1 37 234
new 0 37 234
assign 1 37 235
getHex 1 37 235
addValue 1 38 236
assign 1 41 244
toString 0 41 244
return 1 41 245
assign 1 45 286
lengthGet 0 45 286
assign 1 45 287
new 1 45 287
assign 1 46 288
new 0 46 288
assign 1 52 289
new 0 52 289
assign 1 52 290
find 2 52 290
assign 1 53 291
new 0 53 291
assign 1 53 292
find 2 53 292
assign 1 54 293
undef 1 54 298
assign 1 0 299
assign 1 54 302
def 1 54 307
assign 1 54 308
lesser 1 54 313
assign 1 0 314
assign 1 0 317
assign 1 0 321
assign 1 0 324
assign 1 0 327
assign 1 55 331
new 0 55 331
assign 1 56 332
assign 1 58 335
new 0 58 335
assign 1 59 336
assign 1 62 338
lengthGet 0 62 338
assign 1 63 341
def 1 63 346
assign 1 64 347
greater 1 64 352
assign 1 65 353
substring 2 65 353
addValue 1 65 354
assign 1 66 355
assign 1 69 358
new 0 69 358
addValue 1 69 359
assign 1 70 360
new 0 70 360
assign 1 70 361
add 1 70 361
assign 1 72 364
new 0 72 364
assign 1 72 365
add 1 72 365
assign 1 72 366
lesser 1 72 371
assign 1 73 372
new 0 73 372
assign 1 73 373
add 1 73 373
assign 1 73 374
new 0 73 374
assign 1 73 375
add 1 73 375
assign 1 73 376
substring 2 73 376
assign 1 73 377
hexNew 1 73 377
addValue 1 73 378
assign 1 74 379
new 0 74 379
assign 1 74 380
add 1 74 380
assign 1 77 383
new 0 77 383
assign 1 77 384
find 2 77 384
assign 1 78 385
new 0 78 385
assign 1 78 386
find 2 78 386
assign 1 79 387
undef 1 79 392
assign 1 0 393
assign 1 79 396
def 1 79 401
assign 1 79 402
lesser 1 79 407
assign 1 0 408
assign 1 0 411
assign 1 0 415
assign 1 0 418
assign 1 0 421
assign 1 80 425
new 0 80 425
assign 1 81 426
assign 1 83 429
new 0 83 429
assign 1 84 430
assign 1 87 437
lesser 1 87 442
assign 1 88 443
substring 2 88 443
addValue 1 88 444
assign 1 90 446
toString 0 90 446
return 1 90 447
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1104558808: return bem_hashGet_0();
case 1300072126: return bem_default_0();
case 300385203: return bem_toString_0();
case 1106770102: return bem_iteratorGet_0();
case 949701: return bem_print_0();
case 1569412621: return bem_create_0();
case 1211194663: return bem_new_0();
case 577809605: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1742963115: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case -1650199959: return bem_copyTo_1(bevd_0);
case -1230932201: return bem_print_1(bevd_0);
case -756175634: return bem_undef_1(bevd_0);
case 1215096844: return bem_def_1(bevd_0);
case 326054246: return bem_notEquals_1(bevd_0);
case 110556482: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case -1016133256: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1847725704: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1753230616: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -753455512: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1204159569: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeUrl_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_3_EncodeUrl_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_EncodeUrl();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst = (BEC_2_6_3_EncodeUrl) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_type;
}
}
