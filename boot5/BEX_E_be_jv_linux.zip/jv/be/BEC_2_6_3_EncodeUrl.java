package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeUrl extends BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_BEC_2_6_3_EncodeUrl_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_BEC_2_6_3_EncodeUrl_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_0 = {0x2B};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_1 = {0x25};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_2 = {0x20};
public static BEC_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_inst;

public static BET_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_type;

public BEC_2_6_3_EncodeUrl bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_EncodeUrl bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
bevt_6_ta_ph = beva_str.bem_sizeGet_0();
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = bevt_6_ta_ph.bem_multiply_1(bevt_7_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_ta_ph);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_ta_ph);
while (true)
/* Line: 216*/ {
bevt_9_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 216*/ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ac.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(58));
if (bevl_ac.bevi_int < bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
 else /* Line: 219*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(64));
if (bevl_ac.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(94));
if (bevl_ac.bevi_int < bevt_18_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
 else /* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(94));
if (bevl_ac.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(123));
if (bevl_ac.bevi_int < bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
 else /* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(44));
if (bevl_ac.bevi_int > bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_26_ta_ph = (new BEC_2_4_3_MathInt(47));
if (bevl_ac.bevi_int < bevt_26_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
 else /* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_28_ta_ph = (new BEC_2_4_3_MathInt(42));
if (bevl_ac.bevi_int == bevt_28_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 219*/ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 220*/
 else /* Line: 219*/ {
bevt_30_ta_ph = (new BEC_2_4_3_MathInt(32));
if (bevl_ac.bevi_int == bevt_30_ta_ph.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_r.bem_addValue_1(bevt_31_ta_ph);
} /* Line: 222*/
 else /* Line: 223*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_r.bem_addValue_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_ta_ph);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 226*/
} /* Line: 219*/
} /* Line: 219*/
 else /* Line: 216*/ {
break;
} /* Line: 216*/
} /* Line: 216*/
bevt_34_ta_ph = bevl_r.bem_toString_0();
return bevt_34_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
bevt_2_ta_ph = beva_str.bem_sizeGet_0();
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevl_last = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_npl = beva_str.bem_find_2(bevt_3_ta_ph, bevl_last);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_npe = beva_str.bem_find_2(bevt_4_ta_ph, bevl_last);
if (bevl_npe == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
if (bevl_npl == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 242*/ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 242*/
 else /* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 242*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 242*/ {
bevl_ispl = be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 244*/
 else /* Line: 245*/ {
bevl_ispl = be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 247*/
bevl_len = beva_str.bem_sizeGet_0();
while (true)
/* Line: 251*/ {
if (bevl_i == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 251*/ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 252*/ {
bevt_10_ta_ph = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_ta_ph);
bevl_last = bevl_i;
} /* Line: 254*/
if (bevl_ispl.bevi_bool)/* Line: 256*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_2));
bevl_r.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_last = bevl_i.bem_add_1(bevt_12_ta_ph);
} /* Line: 258*/
 else /* Line: 259*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_14_ta_ph = bevl_i.bem_add_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_int < bevl_len.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_18_ta_ph = bevl_i.bem_add_1(bevt_19_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_20_ta_ph = bevl_i.bem_add_1(bevt_21_ta_ph);
bevt_17_ta_ph = beva_str.bem_substring_2(bevt_18_ta_ph, bevt_20_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_ta_ph);
bevl_r.bem_addValue_1(bevt_16_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(3));
bevl_last = bevl_i.bem_add_1(bevt_22_ta_ph);
} /* Line: 262*/
} /* Line: 260*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_npl = beva_str.bem_find_2(bevt_23_ta_ph, bevl_last);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_npe = beva_str.bem_find_2(bevt_24_ta_ph, bevl_last);
if (bevl_npe == null) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 267*/ {
if (bevl_npl == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 267*/ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 267*/
 else /* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 267*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 267*/ {
bevl_ispl = be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 269*/
 else /* Line: 270*/ {
bevl_ispl = be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 272*/
} /* Line: 267*/
 else /* Line: 251*/ {
break;
} /* Line: 251*/
} /* Line: 251*/
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_29_ta_ph = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_ta_ph);
} /* Line: 276*/
bevt_30_ta_ph = bevl_r.bem_toString_0();
return bevt_30_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {213, 213, 213, 213, 214, 215, 215, 216, 217, 218, 218, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 0, 0, 220, 221, 221, 221, 222, 222, 224, 224, 225, 225, 226, 229, 229, 233, 233, 234, 240, 240, 241, 241, 242, 242, 0, 242, 242, 242, 242, 0, 0, 0, 0, 0, 243, 244, 246, 247, 250, 251, 251, 252, 252, 253, 253, 254, 257, 257, 258, 258, 260, 260, 260, 260, 261, 261, 261, 261, 261, 261, 261, 262, 262, 265, 265, 266, 266, 267, 267, 0, 267, 267, 267, 267, 0, 0, 0, 0, 0, 268, 269, 271, 272, 275, 275, 276, 276, 278, 278};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {63, 64, 65, 66, 67, 68, 69, 72, 74, 75, 76, 77, 78, 83, 84, 85, 90, 91, 94, 98, 101, 104, 105, 110, 111, 112, 117, 118, 121, 125, 128, 131, 135, 138, 139, 144, 145, 146, 151, 152, 155, 159, 162, 165, 169, 172, 173, 178, 179, 180, 185, 186, 189, 193, 196, 199, 203, 206, 207, 212, 213, 216, 220, 223, 224, 229, 230, 231, 234, 235, 236, 237, 238, 246, 247, 288, 289, 290, 291, 292, 293, 294, 295, 300, 301, 304, 309, 310, 315, 316, 319, 323, 326, 329, 333, 334, 337, 338, 340, 343, 348, 349, 354, 355, 356, 357, 360, 361, 362, 363, 366, 367, 368, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 385, 386, 387, 388, 389, 394, 395, 398, 403, 404, 409, 410, 413, 417, 420, 423, 427, 428, 431, 432, 439, 444, 445, 446, 448, 449};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 213 63
sizeGet 0 213 63
assign 1 213 64
new 0 213 64
assign 1 213 65
multiply 1 213 65
assign 1 213 66
new 1 213 66
assign 1 214 67
new 1 214 67
assign 1 215 68
new 0 215 68
assign 1 215 69
new 1 215 69
assign 1 216 72
hasNextGet 0 216 72
next 1 217 74
assign 1 218 75
new 0 218 75
assign 1 218 76
getCode 1 218 76
assign 1 219 77
new 0 219 77
assign 1 219 78
greater 1 219 83
assign 1 219 84
new 0 219 84
assign 1 219 85
lesser 1 219 90
assign 1 0 91
assign 1 0 94
assign 1 0 98
assign 1 0 101
assign 1 219 104
new 0 219 104
assign 1 219 105
greater 1 219 110
assign 1 219 111
new 0 219 111
assign 1 219 112
lesser 1 219 117
assign 1 0 118
assign 1 0 121
assign 1 0 125
assign 1 0 128
assign 1 0 131
assign 1 0 135
assign 1 219 138
new 0 219 138
assign 1 219 139
greater 1 219 144
assign 1 219 145
new 0 219 145
assign 1 219 146
lesser 1 219 151
assign 1 0 152
assign 1 0 155
assign 1 0 159
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 219 172
new 0 219 172
assign 1 219 173
greater 1 219 178
assign 1 219 179
new 0 219 179
assign 1 219 180
lesser 1 219 185
assign 1 0 186
assign 1 0 189
assign 1 0 193
assign 1 0 196
assign 1 0 199
assign 1 0 203
assign 1 219 206
new 0 219 206
assign 1 219 207
equals 1 219 212
assign 1 0 213
assign 1 0 216
addValue 1 220 220
assign 1 221 223
new 0 221 223
assign 1 221 224
equals 1 221 229
assign 1 222 230
new 0 222 230
addValue 1 222 231
assign 1 224 234
new 0 224 234
addValue 1 224 235
assign 1 225 236
new 0 225 236
assign 1 225 237
getHex 1 225 237
addValue 1 226 238
assign 1 229 246
toString 0 229 246
return 1 229 247
assign 1 233 288
sizeGet 0 233 288
assign 1 233 289
new 1 233 289
assign 1 234 290
new 0 234 290
assign 1 240 291
new 0 240 291
assign 1 240 292
find 2 240 292
assign 1 241 293
new 0 241 293
assign 1 241 294
find 2 241 294
assign 1 242 295
undef 1 242 300
assign 1 0 301
assign 1 242 304
def 1 242 309
assign 1 242 310
lesser 1 242 315
assign 1 0 316
assign 1 0 319
assign 1 0 323
assign 1 0 326
assign 1 0 329
assign 1 243 333
new 0 243 333
assign 1 244 334
assign 1 246 337
new 0 246 337
assign 1 247 338
assign 1 250 340
sizeGet 0 250 340
assign 1 251 343
def 1 251 348
assign 1 252 349
greater 1 252 354
assign 1 253 355
substring 2 253 355
addValue 1 253 356
assign 1 254 357
assign 1 257 360
new 0 257 360
addValue 1 257 361
assign 1 258 362
new 0 258 362
assign 1 258 363
add 1 258 363
assign 1 260 366
new 0 260 366
assign 1 260 367
add 1 260 367
assign 1 260 368
lesser 1 260 373
assign 1 261 374
new 0 261 374
assign 1 261 375
add 1 261 375
assign 1 261 376
new 0 261 376
assign 1 261 377
add 1 261 377
assign 1 261 378
substring 2 261 378
assign 1 261 379
hexNew 1 261 379
addValue 1 261 380
assign 1 262 381
new 0 262 381
assign 1 262 382
add 1 262 382
assign 1 265 385
new 0 265 385
assign 1 265 386
find 2 265 386
assign 1 266 387
new 0 266 387
assign 1 266 388
find 2 266 388
assign 1 267 389
undef 1 267 394
assign 1 0 395
assign 1 267 398
def 1 267 403
assign 1 267 404
lesser 1 267 409
assign 1 0 410
assign 1 0 413
assign 1 0 417
assign 1 0 420
assign 1 0 423
assign 1 268 427
new 0 268 427
assign 1 269 428
assign 1 271 431
new 0 271 431
assign 1 272 432
assign 1 275 439
lesser 1 275 444
assign 1 276 445
substring 2 276 445
addValue 1 276 446
assign 1 278 448
toString 0 278 448
return 1 278 449
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 967234853: return bem_fieldIteratorGet_0();
case -119499799: return bem_serializationIteratorGet_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case -1724453868: return bem_serializeToString_0();
case -533443118: return bem_many_0();
case -194416815: return bem_tagGet_0();
case 1797865600: return bem_new_0();
case 1955915393: return bem_fieldNamesGet_0();
case -1034571137: return bem_default_0();
case 1777587047: return bem_hashGet_0();
case 1095297479: return bem_echo_0();
case -665649433: return bem_serializeContents_0();
case 766881626: return bem_print_0();
case 280712282: return bem_toString_0();
case 378307569: return bem_copy_0();
case -1715766851: return bem_toAny_0();
case -1455899172: return bem_create_0();
case 617445256: return bem_sourceFileNameGet_0();
case -180175097: return bem_classNameGet_0();
case 2011135674: return bem_iteratorGet_0();
case 509361355: return bem_once_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -445857610: return bem_notEquals_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1826809239: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 906320876: return bem_defined_1(bevd_0);
case -246138855: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeUrl_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeUrl_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_EncodeUrl();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst = (BEC_2_6_3_EncodeUrl) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_type;
}
}
