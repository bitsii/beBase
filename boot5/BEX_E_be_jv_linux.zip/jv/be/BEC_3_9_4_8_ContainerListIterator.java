package be;
/* IO:File: source/base/List.be */
public final class BEC_3_9_4_8_ContainerListIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_4_8_ContainerListIterator() { }
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;

public static BET_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_4_3_MathInt bevp_npos;
public BEC_3_9_4_8_ContainerListIterator bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_npos = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) throws Throwable {
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_4_ContainerList) beva_a;
bevp_npos = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_containerGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 34*/ {
bevt_4_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_pos.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 34*/
 else /* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 34*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 35*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_currentGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevp_npos.bevi_int = bevp_pos.bevi_int;
bevp_npos.bevi_int++;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(-1));
if (bevp_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_4_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_npos.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 51*/
 else /* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 51*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 52*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
bevp_pos.bevi_int += beva_multiNullCount.bevi_int;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 18, 19, 24, 25, 26, 30, 34, 34, 34, 34, 34, 34, 0, 0, 0, 35, 35, 37, 37, 41, 41, 45, 45, 49, 50, 51, 51, 51, 51, 51, 51, 0, 0, 0, 52, 52, 54, 54, 58, 59, 59, 63, 64, 64, 68};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 23, 24, 25, 29, 39, 40, 45, 46, 47, 52, 53, 56, 60, 63, 64, 66, 67, 71, 72, 76, 77, 87, 88, 89, 90, 95, 96, 97, 102, 103, 106, 110, 113, 114, 116, 117, 121, 122, 123, 127, 128, 129, 132};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 16
new 0 17 16
assign 1 18 17
new 0 18 17
assign 1 18 18
new 1 18 18
assign 1 19 19
new 0 19 19
assign 1 24 23
new 0 24 23
assign 1 25 24
assign 1 26 25
new 0 26 25
return 1 30 29
assign 1 34 39
new 0 34 39
assign 1 34 40
greater 1 34 45
assign 1 34 46
lengthGet 0 34 46
assign 1 34 47
lesser 1 34 52
assign 1 0 53
assign 1 0 56
assign 1 0 60
assign 1 35 63
new 0 35 63
return 1 35 64
assign 1 37 66
new 0 37 66
return 1 37 67
assign 1 41 71
get 1 41 71
return 1 41 72
assign 1 45 76
put 2 45 76
return 1 45 77
setValue 1 49 87
incrementValue 0 50 88
assign 1 51 89
new 0 51 89
assign 1 51 90
greaterEquals 1 51 95
assign 1 51 96
lengthGet 0 51 96
assign 1 51 97
lesser 1 51 102
assign 1 0 103
assign 1 0 106
assign 1 0 110
assign 1 52 113
new 0 52 113
return 1 52 114
assign 1 54 116
new 0 54 116
return 1 54 117
incrementValue 0 58 121
assign 1 59 122
get 1 59 122
return 1 59 123
incrementValue 0 63 127
assign 1 64 128
put 2 64 128
return 1 64 129
addValue 1 68 132
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1109690176: return bem_new_0();
case -1422519874: return bem_currentGet_0();
case -411013841: return bem_toString_0();
case -367225540: return bem_hasNextGet_0();
case 1669749747: return bem_nextGet_0();
case 348770951: return bem_iteratorGet_0();
case 1316969213: return bem_containerGet_0();
case -1840752256: return bem_copy_0();
case 542013902: return bem_print_0();
case 903906949: return bem_create_0();
case -1251037724: return bem_hasCurrentGet_0();
case 1629796718: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1557648392: return bem_notEquals_1(bevd_0);
case 2073212599: return bem_def_1(bevd_0);
case 885891470: return bem_new_1(bevd_0);
case -287914678: return bem_copyTo_1(bevd_0);
case 1394274272: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 667373602: return bem_undef_1(bevd_0);
case -1006629310: return bem_nextSet_1(bevd_0);
case -1361503993: return bem_currentSet_1(bevd_0);
case -847695240: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -325191768: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -748291392: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -365162461: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -604364030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_4_8_ContainerListIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_9_4_8_ContainerListIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_4_8_ContainerListIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst = (BEC_3_9_4_8_ContainerListIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;
}
}
