package be;
/* IO:File: source/build/Pass7.be */
public final class BEC_3_5_5_5_BuildVisitPass7 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_2 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_3 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_5 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_6 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_7 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_8 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_10 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_15 = {0x6E,0x65,0x77};
public static BEC_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_3_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_5_4_BuildNode bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_4_3_MathInt bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_6_6_SystemObject bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_5_4_LogicBool bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_4_3_MathInt bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_6_6_SystemObject bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
BEC_2_6_6_SystemObject bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_104_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_105_ta_ph = null;
BEC_2_6_6_SystemObject bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_4_3_MathInt bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_6_6_SystemObject bevt_110_ta_ph = null;
BEC_2_5_4_LogicBool bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_5_4_LogicBool bevt_113_ta_ph = null;
BEC_2_6_6_SystemObject bevt_114_ta_ph = null;
BEC_2_6_6_SystemObject bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_117_ta_ph = null;
BEC_2_4_6_TextString bevt_118_ta_ph = null;
BEC_2_6_6_SystemObject bevt_119_ta_ph = null;
BEC_2_6_6_SystemObject bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_122_ta_ph = null;
BEC_2_4_6_TextString bevt_123_ta_ph = null;
BEC_2_5_4_LogicBool bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_5_4_LogicBool bevt_126_ta_ph = null;
BEC_2_4_3_MathInt bevt_127_ta_ph = null;
BEC_2_4_3_MathInt bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_130_ta_ph = null;
BEC_2_4_6_TextString bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_4_3_MathInt bevt_134_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_135_ta_ph = null;
BEC_2_4_6_TextString bevt_136_ta_ph = null;
BEC_2_4_3_MathInt bevt_137_ta_ph = null;
BEC_2_5_4_LogicBool bevt_138_ta_ph = null;
BEC_2_4_3_MathInt bevt_139_ta_ph = null;
BEC_2_4_3_MathInt bevt_140_ta_ph = null;
BEC_2_5_4_LogicBool bevt_141_ta_ph = null;
BEC_2_5_4_LogicBool bevt_142_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_143_ta_ph = null;
BEC_2_4_6_TextString bevt_144_ta_ph = null;
BEC_2_6_6_SystemObject bevt_145_ta_ph = null;
BEC_2_6_6_SystemObject bevt_146_ta_ph = null;
BEC_2_4_3_MathInt bevt_147_ta_ph = null;
BEC_2_5_4_LogicBool bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_6_6_SystemObject bevt_150_ta_ph = null;
BEC_2_4_3_MathInt bevt_151_ta_ph = null;
BEC_2_4_3_MathInt bevt_152_ta_ph = null;
BEC_2_6_6_SystemObject bevt_153_ta_ph = null;
BEC_2_5_4_LogicBool bevt_154_ta_ph = null;
BEC_2_4_3_MathInt bevt_155_ta_ph = null;
BEC_2_4_3_MathInt bevt_156_ta_ph = null;
BEC_2_5_4_LogicBool bevt_157_ta_ph = null;
BEC_2_4_3_MathInt bevt_158_ta_ph = null;
BEC_2_4_3_MathInt bevt_159_ta_ph = null;
BEC_2_6_6_SystemObject bevt_160_ta_ph = null;
BEC_2_6_6_SystemObject bevt_161_ta_ph = null;
BEC_2_6_6_SystemObject bevt_162_ta_ph = null;
BEC_2_6_6_SystemObject bevt_163_ta_ph = null;
BEC_2_6_6_SystemObject bevt_164_ta_ph = null;
BEC_2_5_4_LogicBool bevt_165_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_166_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_167_ta_ph = null;
BEC_2_6_6_SystemObject bevt_168_ta_ph = null;
BEC_2_6_6_SystemObject bevt_169_ta_ph = null;
BEC_2_4_3_MathInt bevt_170_ta_ph = null;
BEC_2_5_4_BuildNode bevt_171_ta_ph = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_ta_ph.bemd_0(-958568153);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-1397529110);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_ta_ph.bemd_0(1469284867);
} /* Line: 46*/
if (bevp_inClassNp == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 48*/ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 50*/
bevt_16_ta_ph = beva_node.bem_typenameGet_0();
bevt_17_ta_ph = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 52*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass7_bels_0));
bevp_build.bem_buildLiteral_2(beva_node, bevt_18_ta_ph);
} /* Line: 53*/
bevt_20_ta_ph = beva_node.bem_typenameGet_0();
bevt_21_ta_ph = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_ta_ph.bevi_int == bevt_21_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_22_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_1));
bevp_build.bem_buildLiteral_2(beva_node, bevt_22_ta_ph);
} /* Line: 56*/
bevt_24_ta_ph = beva_node.bem_typenameGet_0();
bevt_25_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_ta_ph.bevi_int == bevt_25_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 58*/ {
bevt_26_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_26_ta_ph);
} /* Line: 59*/
bevt_28_ta_ph = beva_node.bem_typenameGet_0();
bevt_29_ta_ph = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_ta_ph.bevi_int == bevt_29_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 61*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_30_ta_ph);
bevt_31_ta_ph = be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_ta_ph);
} /* Line: 64*/
bevt_33_ta_ph = beva_node.bem_typenameGet_0();
bevt_34_ta_ph = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_ta_ph.bevi_int == bevt_34_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 66*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass7_bels_3));
beva_node.bem_heldSet_1(bevt_35_ta_ph);
bevt_36_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
bevp_build.bem_buildLiteral_2(beva_node, bevt_36_ta_ph);
} /* Line: 68*/
bevt_38_ta_ph = beva_node.bem_typenameGet_0();
bevt_39_ta_ph = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_ta_ph.bevi_int == bevt_39_ta_ph.bevi_int) {
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 74*/ {
bevt_40_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_5));
beva_node.bem_heldSet_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
bevp_build.bem_buildLiteral_2(beva_node, bevt_41_ta_ph);
} /* Line: 76*/
 else /* Line: 74*/ {
bevt_43_ta_ph = beva_node.bem_typenameGet_0();
bevt_44_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_43_ta_ph.bevi_int == bevt_44_ta_ph.bevi_int) {
bevt_42_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_42_ta_ph.bevi_bool)/* Line: 78*/ {
bevt_47_ta_ph = beva_node.bem_heldGet_0();
bevt_46_ta_ph = bevt_47_ta_ph.bemd_0(-267801049);
bevt_45_ta_ph = bevt_46_ta_ph.bemd_0(1933121079);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 78*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 78*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 78*/
 else /* Line: 78*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 78*/ {
bevt_50_ta_ph = beva_node.bem_heldGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bemd_0(-77102636);
if (bevt_49_ta_ph == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 79*/ {
if (bevl_nnode == null) {
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 79*/ {
bevt_53_ta_ph = bevl_nnode.bemd_0(-780796651);
bevt_54_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bemd_1(-39729582, bevt_54_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_52_ta_ph).bevi_bool)/* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 79*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 79*/
 else /* Line: 79*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 79*/ {
bevt_57_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_3_5_5_5_BuildVisitPass7_bels_6));
bevt_59_ta_ph = beva_node.bem_heldGet_0();
bevt_58_ta_ph = bevt_59_ta_ph.bemd_0(-77102636);
bevt_56_ta_ph = bevt_57_ta_ph.bem_add_1(bevt_58_ta_ph);
bevt_55_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_55_ta_ph);
} /* Line: 80*/
 else /* Line: 81*/ {
bevt_60_ta_ph = beva_node.bem_heldGet_0();
bevt_61_ta_ph = bevl_nnode.bemd_0(1900289494);
bevt_60_ta_ph.bemd_1(-1530278924, bevt_61_ta_ph);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(1766635801);
bevt_62_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_62_ta_ph;
} /* Line: 88*/
} /* Line: 79*/
 else /* Line: 74*/ {
bevt_64_ta_ph = beva_node.bem_typenameGet_0();
bevt_65_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_64_ta_ph.bevi_int == bevt_65_ta_ph.bevi_int) {
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 90*/ {
if (bevl_nnode == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 91*/ {
bevt_68_ta_ph = bevl_nnode.bemd_0(-780796651);
bevt_69_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bemd_1(935360108, bevt_69_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_67_ta_ph).bevi_bool)/* Line: 91*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 91*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 91*/
 else /* Line: 91*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 91*/ {
bevt_71_ta_ph = bevl_nnode.bemd_0(-630208788);
if (bevt_71_ta_ph == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 92*/ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_ta_ph = bevl_nnode.bemd_0(-630208788);
bevl_ii = bevt_72_ta_ph.bemd_0(422595331);
while (true)
/* Line: 94*/ {
bevt_73_ta_ph = bevl_ii.bemd_0(-510070775);
if (((BEC_2_5_4_LogicBool) bevt_73_ta_ph).bevi_bool)/* Line: 94*/ {
bevl_i = bevl_ii.bemd_0(1460352520);
bevt_75_ta_ph = bevl_i.bemd_0(-780796651);
bevt_76_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_74_ta_ph = bevt_75_ta_ph.bemd_1(935360108, bevt_76_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 96*/ {
bevl_toremove.bemd_1(-1235621429, bevl_i);
} /* Line: 97*/
} /* Line: 96*/
 else /* Line: 94*/ {
break;
} /* Line: 94*/
} /* Line: 94*/
bevl_ii = bevl_toremove.bemd_0(422595331);
while (true)
/* Line: 100*/ {
bevt_77_ta_ph = bevl_ii.bemd_0(-510070775);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 100*/ {
bevl_i = bevl_ii.bemd_0(1460352520);
bevl_i.bemd_0(1766635801);
} /* Line: 102*/
 else /* Line: 100*/ {
break;
} /* Line: 100*/
} /* Line: 100*/
} /* Line: 100*/
bevl_pc = bevl_nnode;
bevt_78_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(-841252073, bevt_78_ta_ph);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_ta_ph = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(-1530278924, bevt_79_ta_ph);
bevl_pc.bemd_1(-2135686795, bevl_gc);
beva_node.bem_remove_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 113*/ {
bevt_82_ta_ph = bevl_dnode.bemd_0(-780796651);
bevt_83_ta_ph = bevp_ntypes.bem_DOTGet_0();
bevt_81_ta_ph = bevt_82_ta_ph.bemd_1(935360108, bevt_83_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_81_ta_ph).bevi_bool)/* Line: 113*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 113*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 113*/
 else /* Line: 113*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 113*/ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(303247231);
if (bevl_onode == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_86_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_3_5_5_5_BuildVisitPass7_bels_7));
bevt_85_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_85_ta_ph);
} /* Line: 116*/
 else /* Line: 115*/ {
bevt_88_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_89_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_ta_ph.bevi_int == bevt_89_ta_ph.bevi_int) {
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 117*/ {
bevt_91_ta_ph = bevl_gc.bemd_0(-77102636);
bevt_90_ta_ph = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_ta_ph );
if (bevt_90_ta_ph.bevi_bool)/* Line: 118*/ {
bevt_92_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1427881929, bevt_92_ta_ph);
bevt_93_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(492461842, bevt_93_ta_ph);
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(994783788, bevt_94_ta_ph);
} /* Line: 121*/
 else /* Line: 122*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 123*/
} /* Line: 118*/
 else /* Line: 115*/ {
bevt_96_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_97_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_96_ta_ph.bevi_int == bevt_97_ta_ph.bevi_int) {
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_101_ta_ph = beva_node.bem_transUnitGet_0();
bevt_100_ta_ph = bevt_101_ta_ph.bemd_0(1900289494);
bevt_99_ta_ph = bevt_100_ta_ph.bemd_0(-2029493582);
bevt_102_ta_ph = bevl_onode.bem_heldGet_0();
bevt_98_ta_ph = bevt_99_ta_ph.bemd_1(1348236304, bevt_102_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_98_ta_ph).bevi_bool)/* Line: 125*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 125*/ {
bevt_105_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_104_ta_ph = bevt_105_ta_ph.bem_aliasedGet_0();
bevt_106_ta_ph = bevl_onode.bem_heldGet_0();
bevt_103_ta_ph = bevt_104_ta_ph.bem_contains_1(bevt_106_ta_ph);
if (bevt_103_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 125*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 125*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 125*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 125*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 125*/
 else /* Line: 125*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 125*/ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_ta_ph = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_ta_ph);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_ta_ph);
bevl_onode.bem_resolveNp_0();
bevt_110_ta_ph = bevl_gc.bemd_0(-77102636);
bevt_109_ta_ph = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_ta_ph );
if (bevt_109_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_111_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1427881929, bevt_111_ta_ph);
bevt_112_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(492461842, bevt_112_ta_ph);
bevt_113_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(994783788, bevt_113_ta_ph);
} /* Line: 134*/
 else /* Line: 135*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 136*/
} /* Line: 131*/
 else /* Line: 115*/ {
bevt_115_ta_ph = bevl_gc.bemd_0(-77102636);
bevt_116_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass7_bels_8));
bevt_114_ta_ph = bevt_115_ta_ph.bemd_1(935360108, bevt_116_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_114_ta_ph).bevi_bool)/* Line: 138*/ {
bevt_118_ta_ph = (new BEC_2_4_6_TextString(70, bece_BEC_3_5_5_5_BuildVisitPass7_bels_9));
bevt_117_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_117_ta_ph);
} /* Line: 139*/
 else /* Line: 115*/ {
bevt_120_ta_ph = bevl_gc.bemd_0(-77102636);
bevt_121_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_10));
bevt_119_ta_ph = bevt_120_ta_ph.bemd_1(935360108, bevt_121_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_119_ta_ph).bevi_bool)/* Line: 140*/ {
bevt_123_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_3_5_5_5_BuildVisitPass7_bels_11));
bevt_122_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_122_ta_ph);
} /* Line: 141*/
} /* Line: 115*/
} /* Line: 115*/
} /* Line: 115*/
} /* Line: 115*/
bevl_onode.bem_remove_0();
bevl_pc.bemd_1(1764797166, bevl_onode);
bevl_dnode.bemd_0(1766635801);
} /* Line: 146*/
 else /* Line: 147*/ {
bevt_124_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(492461842, bevt_124_ta_ph);
bevt_125_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1427881929, bevt_125_ta_ph);
} /* Line: 149*/
} /* Line: 113*/
} /* Line: 91*/
 else /* Line: 74*/ {
bevt_127_ta_ph = beva_node.bem_typenameGet_0();
bevt_128_ta_ph = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_ta_ph.bevi_int == bevt_128_ta_ph.bevi_int) {
bevt_126_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_126_ta_ph.bevi_bool)/* Line: 153*/ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 157*/ {
bevt_131_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_12));
bevt_130_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_130_ta_ph);
} /* Line: 158*/
bevl_onode.bem_remove_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_134_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_ta_ph.bevi_int == bevt_134_ta_ph.bevi_int) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 162*/ {
bevt_136_ta_ph = (new BEC_2_4_6_TextString(84, bece_BEC_3_5_5_5_BuildVisitPass7_bels_13));
bevt_135_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_135_ta_ph);
} /* Line: 163*/
bevt_137_ta_ph = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_ta_ph);
} /* Line: 165*/
 else /* Line: 74*/ {
bevt_139_ta_ph = beva_node.bem_typenameGet_0();
bevt_140_ta_ph = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_ta_ph.bevi_int == bevt_140_ta_ph.bevi_int) {
bevt_138_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_138_ta_ph.bevi_bool)/* Line: 166*/ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_141_ta_ph.bevi_bool)/* Line: 171*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 171*/ {
if (bevl_onode == null) {
bevt_142_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_142_ta_ph.bevi_bool)/* Line: 171*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 171*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 171*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 171*/ {
bevt_144_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_14));
bevt_143_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_143_ta_ph);
} /* Line: 172*/
bevt_146_ta_ph = bevl_nnode.bemd_0(-780796651);
bevt_147_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_145_ta_ph = bevt_146_ta_ph.bemd_1(935360108, bevt_147_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_145_ta_ph).bevi_bool)/* Line: 174*/ {
bevl_pnode = bevl_nnode.bemd_0(-1002945870);
if (bevl_pnode == null) {
bevt_148_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_148_ta_ph.bevi_bool)/* Line: 176*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 176*/ {
bevt_150_ta_ph = bevl_pnode.bemd_0(-780796651);
bevt_151_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_149_ta_ph = bevt_150_ta_ph.bemd_1(-39729582, bevt_151_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_149_ta_ph).bevi_bool)/* Line: 176*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 176*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 176*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 176*/ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_ta_ph);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_ta_ph = bevl_nnode.bemd_0(1900289494);
bevl_ga.bemd_1(-1530278924, bevt_153_ta_ph);
bevl_nnode.bemd_0(1766635801);
bevl_onode.bem_remove_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_156_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_ta_ph.bevi_int == bevt_156_ta_ph.bevi_int) {
bevt_154_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_154_ta_ph.bevi_bool)/* Line: 185*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 186*/
 else /* Line: 185*/ {
bevt_158_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_159_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_158_ta_ph.bevi_int == bevt_159_ta_ph.bevi_int) {
bevt_157_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_157_ta_ph.bevi_bool)/* Line: 187*/ {
bevt_163_ta_ph = beva_node.bem_transUnitGet_0();
bevt_162_ta_ph = bevt_163_ta_ph.bemd_0(1900289494);
bevt_161_ta_ph = bevt_162_ta_ph.bemd_0(-2029493582);
bevt_164_ta_ph = bevl_onode.bem_heldGet_0();
bevt_160_ta_ph = bevt_161_ta_ph.bemd_1(1348236304, bevt_164_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_160_ta_ph).bevi_bool)/* Line: 187*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 187*/ {
bevt_167_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_166_ta_ph = bevt_167_ta_ph.bem_aliasedGet_0();
bevt_168_ta_ph = bevl_onode.bem_heldGet_0();
bevt_165_ta_ph = bevt_166_ta_ph.bem_contains_1(bevt_168_ta_ph);
if (bevt_165_ta_ph.bevi_bool)/* Line: 187*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 187*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 187*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 187*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 187*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 187*/
 else /* Line: 187*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 187*/ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_ta_ph = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_ta_ph);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_ta_ph);
bevl_onode.bem_resolveNp_0();
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 193*/
} /* Line: 185*/
} /* Line: 185*/
} /* Line: 176*/
} /* Line: 174*/
} /* Line: 74*/
} /* Line: 74*/
} /* Line: 74*/
} /* Line: 74*/
bevt_171_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_171_ta_ph;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) throws Throwable {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_ta_ph);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass7_bels_15));
bevl_gnc.bem_nameSet_1(bevt_2_ta_ph);
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_ta_ph);
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_ta_ph);
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_ta_ph);
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_ta_ph);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {41, 44, 44, 44, 44, 45, 45, 46, 46, 46, 48, 48, 49, 50, 52, 52, 52, 52, 53, 53, 55, 55, 55, 55, 56, 56, 58, 58, 58, 58, 59, 59, 61, 61, 61, 61, 63, 63, 64, 64, 66, 66, 66, 66, 67, 67, 68, 68, 74, 74, 74, 74, 75, 75, 76, 76, 78, 78, 78, 78, 78, 78, 78, 0, 0, 0, 79, 79, 79, 79, 79, 79, 0, 79, 79, 79, 0, 0, 0, 0, 0, 80, 80, 80, 80, 80, 80, 82, 82, 82, 83, 84, 88, 88, 90, 90, 90, 90, 91, 91, 91, 91, 91, 0, 0, 0, 92, 92, 92, 93, 94, 94, 94, 95, 96, 96, 96, 97, 100, 100, 101, 102, 105, 106, 106, 107, 108, 108, 109, 110, 111, 112, 113, 113, 113, 113, 113, 0, 0, 0, 114, 115, 115, 116, 116, 116, 117, 117, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 123, 125, 125, 125, 125, 125, 125, 125, 125, 125, 0, 125, 125, 125, 125, 0, 0, 0, 0, 0, 126, 127, 127, 128, 129, 129, 130, 131, 131, 132, 132, 133, 133, 134, 134, 136, 138, 138, 138, 139, 139, 139, 140, 140, 140, 141, 141, 141, 144, 145, 146, 148, 148, 149, 149, 153, 153, 153, 153, 156, 157, 157, 158, 158, 158, 160, 161, 162, 162, 162, 162, 163, 163, 163, 165, 165, 166, 166, 166, 166, 168, 171, 171, 0, 171, 171, 0, 0, 172, 172, 172, 174, 174, 174, 175, 176, 176, 0, 176, 176, 176, 0, 0, 177, 178, 178, 179, 180, 180, 181, 182, 183, 184, 185, 185, 185, 185, 186, 187, 187, 187, 187, 187, 187, 187, 187, 187, 0, 187, 187, 187, 187, 0, 0, 0, 0, 0, 188, 189, 189, 190, 191, 191, 192, 193, 198, 198, 202, 203, 204, 204, 205, 205, 206, 208, 209, 209, 210, 210, 211, 211, 212, 212, 213, 213, 214, 215, 215, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {219, 220, 221, 222, 227, 228, 229, 230, 231, 232, 234, 239, 240, 241, 243, 244, 245, 250, 251, 252, 254, 255, 256, 261, 262, 263, 265, 266, 267, 272, 273, 274, 276, 277, 278, 283, 284, 285, 286, 287, 289, 290, 291, 296, 297, 298, 299, 300, 302, 303, 304, 309, 310, 311, 312, 313, 316, 317, 318, 323, 324, 325, 326, 328, 331, 335, 338, 339, 340, 345, 346, 351, 352, 355, 356, 357, 359, 362, 366, 369, 373, 376, 377, 378, 379, 380, 381, 384, 385, 386, 387, 388, 389, 390, 394, 395, 396, 401, 402, 407, 408, 409, 410, 412, 415, 419, 422, 423, 428, 429, 430, 431, 434, 436, 437, 438, 439, 441, 448, 451, 453, 454, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 476, 477, 478, 479, 481, 484, 488, 491, 492, 497, 498, 499, 500, 503, 504, 505, 510, 511, 512, 514, 515, 516, 517, 518, 519, 522, 526, 527, 528, 533, 534, 535, 536, 537, 538, 540, 543, 544, 545, 546, 548, 551, 555, 558, 562, 565, 566, 567, 568, 569, 570, 571, 572, 573, 575, 576, 577, 578, 579, 580, 583, 587, 588, 589, 591, 592, 593, 596, 597, 598, 600, 601, 602, 608, 609, 610, 613, 614, 615, 616, 621, 622, 623, 628, 629, 630, 635, 636, 637, 638, 640, 641, 642, 643, 644, 649, 650, 651, 652, 654, 655, 658, 659, 660, 665, 666, 667, 672, 673, 676, 681, 682, 685, 689, 690, 691, 693, 694, 695, 697, 698, 703, 704, 707, 708, 709, 711, 714, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 735, 736, 739, 740, 741, 746, 747, 748, 749, 750, 751, 753, 756, 757, 758, 759, 761, 764, 768, 771, 775, 778, 779, 780, 781, 782, 783, 784, 785, 795, 796, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 833, 836, 840, 843};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 41 219
nextPeerGet 0 41 219
assign 1 44 220
typenameGet 0 44 220
assign 1 44 221
CLASSGet 0 44 221
assign 1 44 222
equals 1 44 227
assign 1 45 228
heldGet 0 45 228
assign 1 45 229
namepathGet 0 45 229
assign 1 46 230
heldGet 0 46 230
assign 1 46 231
fromFileGet 0 46 231
assign 1 46 232
toString 0 46 232
assign 1 48 234
def 1 48 239
inClassNpSet 1 49 240
inFileSet 1 50 241
assign 1 52 243
typenameGet 0 52 243
assign 1 52 244
INTLGet 0 52 244
assign 1 52 245
equals 1 52 250
assign 1 53 251
new 0 53 251
buildLiteral 2 53 252
assign 1 55 254
typenameGet 0 55 254
assign 1 55 255
FLOATLGet 0 55 255
assign 1 55 256
equals 1 55 261
assign 1 56 262
new 0 56 262
buildLiteral 2 56 263
assign 1 58 265
typenameGet 0 58 265
assign 1 58 266
STRINGLGet 0 58 266
assign 1 58 267
equals 1 58 272
assign 1 59 273
new 0 59 273
buildLiteral 2 59 274
assign 1 61 276
typenameGet 0 61 276
assign 1 61 277
WSTRINGLGet 0 61 277
assign 1 61 278
equals 1 61 283
assign 1 63 284
new 0 63 284
buildLiteral 2 63 285
assign 1 64 286
new 0 64 286
wideStringSet 1 64 287
assign 1 66 289
typenameGet 0 66 289
assign 1 66 290
TRUEGet 0 66 290
assign 1 66 291
equals 1 66 296
assign 1 67 297
new 0 67 297
heldSet 1 67 298
assign 1 68 299
new 0 68 299
buildLiteral 2 68 300
assign 1 74 302
typenameGet 0 74 302
assign 1 74 303
FALSEGet 0 74 303
assign 1 74 304
equals 1 74 309
assign 1 75 310
new 0 75 310
heldSet 1 75 311
assign 1 76 312
new 0 76 312
buildLiteral 2 76 313
assign 1 78 316
typenameGet 0 78 316
assign 1 78 317
VARGet 0 78 317
assign 1 78 318
equals 1 78 323
assign 1 78 324
heldGet 0 78 324
assign 1 78 325
isArgGet 0 78 325
assign 1 78 326
not 0 78 326
assign 1 0 328
assign 1 0 331
assign 1 0 335
assign 1 79 338
heldGet 0 79 338
assign 1 79 339
nameGet 0 79 339
assign 1 79 340
undef 1 79 345
assign 1 79 346
undef 1 79 351
assign 1 0 352
assign 1 79 355
typenameGet 0 79 355
assign 1 79 356
IDGet 0 79 356
assign 1 79 357
notEquals 1 79 357
assign 1 0 359
assign 1 0 362
assign 1 0 366
assign 1 0 369
assign 1 0 373
assign 1 80 376
new 0 80 376
assign 1 80 377
heldGet 0 80 377
assign 1 80 378
nameGet 0 80 378
assign 1 80 379
add 1 80 379
assign 1 80 380
new 2 80 380
throw 1 80 381
assign 1 82 384
heldGet 0 82 384
assign 1 82 385
heldGet 0 82 385
nameSet 1 82 386
addVariable 0 83 387
remove 0 84 388
assign 1 88 389
nextDescendGet 0 88 389
return 1 88 390
assign 1 90 394
typenameGet 0 90 394
assign 1 90 395
IDGet 0 90 395
assign 1 90 396
equals 1 90 401
assign 1 91 402
def 1 91 407
assign 1 91 408
typenameGet 0 91 408
assign 1 91 409
PARENSGet 0 91 409
assign 1 91 410
equals 1 91 410
assign 1 0 412
assign 1 0 415
assign 1 0 419
assign 1 92 422
containedGet 0 92 422
assign 1 92 423
def 1 92 428
assign 1 93 429
new 0 93 429
assign 1 94 430
containedGet 0 94 430
assign 1 94 431
iteratorGet 0 94 431
assign 1 94 434
hasNextGet 0 94 434
assign 1 95 436
nextGet 0 95 436
assign 1 96 437
typenameGet 0 96 437
assign 1 96 438
COMMAGet 0 96 438
assign 1 96 439
equals 1 96 439
addValue 1 97 441
assign 1 100 448
iteratorGet 0 100 448
assign 1 100 451
hasNextGet 0 100 451
assign 1 101 453
nextGet 0 101 453
remove 0 102 454
assign 1 105 461
assign 1 106 462
CALLGet 0 106 462
typenameSet 1 106 463
assign 1 107 464
new 0 107 464
assign 1 108 465
heldGet 0 108 465
nameSet 1 108 466
heldSet 1 109 467
remove 0 110 468
assign 1 111 469
assign 1 112 470
priorPeerGet 0 112 470
assign 1 113 471
def 1 113 476
assign 1 113 477
typenameGet 0 113 477
assign 1 113 478
DOTGet 0 113 478
assign 1 113 479
equals 1 113 479
assign 1 0 481
assign 1 0 484
assign 1 0 488
assign 1 114 491
priorPeerGet 0 114 491
assign 1 115 492
undef 1 115 497
assign 1 116 498
new 0 116 498
assign 1 116 499
new 2 116 499
throw 1 116 500
assign 1 117 503
typenameGet 0 117 503
assign 1 117 504
NAMEPATHGet 0 117 504
assign 1 117 505
equals 1 117 510
assign 1 118 511
nameGet 0 118 511
assign 1 118 512
isNewish 1 118 512
assign 1 119 514
new 0 119 514
wasBoundSet 1 119 515
assign 1 120 516
new 0 120 516
boundSet 1 120 517
assign 1 121 518
new 0 121 518
isConstructSet 1 121 519
createImpliedConstruct 2 123 522
assign 1 125 526
typenameGet 0 125 526
assign 1 125 527
IDGet 0 125 527
assign 1 125 528
equals 1 125 533
assign 1 125 534
transUnitGet 0 125 534
assign 1 125 535
heldGet 0 125 535
assign 1 125 536
aliasedGet 0 125 536
assign 1 125 537
heldGet 0 125 537
assign 1 125 538
contains 1 125 538
assign 1 0 540
assign 1 125 543
emitDataGet 0 125 543
assign 1 125 544
aliasedGet 0 125 544
assign 1 125 545
heldGet 0 125 545
assign 1 125 546
contains 1 125 546
assign 1 0 548
assign 1 0 551
assign 1 0 555
assign 1 0 558
assign 1 0 562
assign 1 126 565
new 0 126 565
assign 1 127 566
heldGet 0 127 566
addStep 1 127 567
heldSet 1 128 568
assign 1 129 569
NAMEPATHGet 0 129 569
typenameSet 1 129 570
resolveNp 0 130 571
assign 1 131 572
nameGet 0 131 572
assign 1 131 573
isNewish 1 131 573
assign 1 132 575
new 0 132 575
wasBoundSet 1 132 576
assign 1 133 577
new 0 133 577
boundSet 1 133 578
assign 1 134 579
new 0 134 579
isConstructSet 1 134 580
createImpliedConstruct 2 136 583
assign 1 138 587
nameGet 0 138 587
assign 1 138 588
new 0 138 588
assign 1 138 589
equals 1 138 589
assign 1 139 591
new 0 139 591
assign 1 139 592
new 2 139 592
throw 1 139 593
assign 1 140 596
nameGet 0 140 596
assign 1 140 597
new 0 140 597
assign 1 140 598
equals 1 140 598
assign 1 141 600
new 0 141 600
assign 1 141 601
new 2 141 601
throw 1 141 602
remove 0 144 608
prepend 1 145 609
remove 0 146 610
assign 1 148 613
new 0 148 613
boundSet 1 148 614
assign 1 149 615
new 0 149 615
wasBoundSet 1 149 616
assign 1 153 621
typenameGet 0 153 621
assign 1 153 622
IDXGet 0 153 622
assign 1 153 623
equals 1 153 628
assign 1 156 629
priorPeerGet 0 156 629
assign 1 157 630
undef 1 157 635
assign 1 158 636
new 0 158 636
assign 1 158 637
new 2 158 637
throw 1 158 638
remove 0 160 640
prepend 1 161 641
assign 1 162 642
typenameGet 0 162 642
assign 1 162 643
NAMEPATHGet 0 162 643
assign 1 162 644
equals 1 162 649
assign 1 163 650
new 0 163 650
assign 1 163 651
new 2 163 651
throw 1 163 652
assign 1 165 654
IDXACCGet 0 165 654
typenameSet 1 165 655
assign 1 166 658
typenameGet 0 166 658
assign 1 166 659
DOTGet 0 166 659
assign 1 166 660
equals 1 166 665
assign 1 168 666
priorPeerGet 0 168 666
assign 1 171 667
undef 1 171 672
assign 1 0 673
assign 1 171 676
undef 1 171 681
assign 1 0 682
assign 1 0 685
assign 1 172 689
new 0 172 689
assign 1 172 690
new 2 172 690
throw 1 172 691
assign 1 174 693
typenameGet 0 174 693
assign 1 174 694
IDGet 0 174 694
assign 1 174 695
equals 1 174 695
assign 1 175 697
nextPeerGet 0 175 697
assign 1 176 698
undef 1 176 703
assign 1 0 704
assign 1 176 707
typenameGet 0 176 707
assign 1 176 708
PARENSGet 0 176 708
assign 1 176 709
notEquals 1 176 709
assign 1 0 711
assign 1 0 714
assign 1 177 718
priorPeerGet 0 177 718
assign 1 178 719
ACCESSORGet 0 178 719
typenameSet 1 178 720
assign 1 179 721
new 0 179 721
assign 1 180 722
heldGet 0 180 722
nameSet 1 180 723
remove 0 181 724
remove 0 182 725
heldSet 1 183 726
addValue 1 184 727
assign 1 185 728
typenameGet 0 185 728
assign 1 185 729
NAMEPATHGet 0 185 729
assign 1 185 730
equals 1 185 735
createImpliedConstruct 2 186 736
assign 1 187 739
typenameGet 0 187 739
assign 1 187 740
IDGet 0 187 740
assign 1 187 741
equals 1 187 746
assign 1 187 747
transUnitGet 0 187 747
assign 1 187 748
heldGet 0 187 748
assign 1 187 749
aliasedGet 0 187 749
assign 1 187 750
heldGet 0 187 750
assign 1 187 751
contains 1 187 751
assign 1 0 753
assign 1 187 756
emitDataGet 0 187 756
assign 1 187 757
aliasedGet 0 187 757
assign 1 187 758
heldGet 0 187 758
assign 1 187 759
contains 1 187 759
assign 1 0 761
assign 1 0 764
assign 1 0 768
assign 1 0 771
assign 1 0 775
assign 1 188 778
new 0 188 778
assign 1 189 779
heldGet 0 189 779
addStep 1 189 780
heldSet 1 190 781
assign 1 191 782
NAMEPATHGet 0 191 782
typenameSet 1 191 783
resolveNp 0 192 784
createImpliedConstruct 2 193 785
assign 1 198 795
nextDescendGet 0 198 795
return 1 198 796
assign 1 202 809
new 0 202 809
heldSet 1 203 810
assign 1 204 811
NAMEPATHGet 0 204 811
typenameSet 1 204 812
assign 1 205 813
heldGet 0 205 813
heldSet 1 205 814
prepend 1 206 815
assign 1 208 816
new 0 208 816
assign 1 209 817
new 0 209 817
nameSet 1 209 818
assign 1 210 819
new 0 210 819
wasBoundSet 1 210 820
assign 1 211 821
new 0 211 821
boundSet 1 211 822
assign 1 212 823
new 0 212 823
isConstructSet 1 212 824
assign 1 213 825
new 0 213 825
wasImpliedConstructSet 1 213 826
heldSet 1 214 827
assign 1 215 828
CALLGet 0 215 828
typenameSet 1 215 829
return 1 0 833
assign 1 0 836
return 1 0 840
assign 1 0 843
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1777405298: return bem_inFileGet_0();
case 422595331: return bem_iteratorGet_0();
case 298359009: return bem_buildGet_0();
case -675794816: return bem_print_0();
case 1469284867: return bem_toString_0();
case 514903302: return bem_inClassNpGet_0();
case 92270569: return bem_create_0();
case 723928103: return bem_transGet_0();
case -1221115541: return bem_new_0();
case -1089367539: return bem_ntypesGet_0();
case 1171022339: return bem_copy_0();
case -2042469503: return bem_constGet_0();
case -618327675: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1373736759: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1698144248: return bem_end_1(bevd_0);
case 1514747685: return bem_inFileSet_1(bevd_0);
case 701760907: return bem_def_1(bevd_0);
case 477322925: return bem_transSet_1(bevd_0);
case -1565824606: return bem_inClassNpSet_1(bevd_0);
case 1584223821: return bem_begin_1(bevd_0);
case -1089103671: return bem_undef_1(bevd_0);
case -1515236141: return bem_print_1(bevd_0);
case -31768941: return bem_ntypesSet_1(bevd_0);
case -39729582: return bem_notEquals_1(bevd_0);
case 935360108: return bem_equals_1(bevd_0);
case -1468466490: return bem_buildSet_1(bevd_0);
case 192400507: return bem_copyTo_1(bevd_0);
case -1974317505: return bem_constSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 847187004: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 218804328: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1274504073: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1010736438: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1082406137: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass7_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass7_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst = (BEC_3_5_5_5_BuildVisitPass7) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;
}
}
