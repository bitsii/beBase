package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_4_SystemMain extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_SystemMain() { }
private static byte[] becc_BEC_2_6_4_SystemMain_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x61,0x69,0x6E};
private static byte[] becc_BEC_2_6_4_SystemMain_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_4_SystemMain bece_BEC_2_6_4_SystemMain_bevs_inst;

public static BET_2_6_4_SystemMain bece_BEC_2_6_4_SystemMain_bevs_type;

public BEC_2_6_4_SystemMain bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_SystemMain bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_SystemMain bem_main_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1718188704: return bem_hashGet_0();
case 807655445: return bem_print_0();
case -677150073: return bem_toString_0();
case 1342623754: return bem_copy_0();
case 247576523: return bem_classNameGet_0();
case -2124354635: return bem_serializeToString_0();
case 2003717966: return bem_main_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case -543330026: return bem_fieldNamesGet_0();
case -225222698: return bem_create_0();
case 2066839134: return bem_iteratorGet_0();
case 498101216: return bem_echo_0();
case 556565361: return bem_serializationIteratorGet_0();
case -1749437314: return bem_tagGet_0();
case -313059782: return bem_default_0();
case 126387064: return bem_new_0();
case 409380620: return bem_fieldIteratorGet_0();
case -1794485421: return bem_serializeContents_0();
case 398187407: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -404194174: return bem_copyTo_1(bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case 1502842604: return bem_def_1(bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_SystemMain_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_4_SystemMain_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_SystemMain();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_SystemMain.bece_BEC_2_6_4_SystemMain_bevs_inst = (BEC_2_6_4_SystemMain) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_SystemMain.bece_BEC_2_6_4_SystemMain_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_4_SystemMain.bece_BEC_2_6_4_SystemMain_bevs_type;
}
}
