package be;
/* IO:File: source/build/Library.be */
public final class BEC_2_5_7_BuildLibrary extends BEC_2_6_6_SystemObject {
public BEC_2_5_7_BuildLibrary() { }
private static byte[] becc_BEC_2_5_7_BuildLibrary_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] becc_BEC_2_5_7_BuildLibrary_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x2E,0x62,0x65};
public static BEC_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_inst;

public static BET_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_type;

public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_5_9_BuildClassInfo bevp_libnameInfo;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_5_7_BuildLibrary bem_new_2(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_libPath = null;
BEC_2_6_6_SystemObject bevl_libnameNp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevp_build = beva__build;
if (bevp_libName == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 22*/ {
bevl_libPath = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_basePath = bevl_libPath.bem_parentGet_0();
bevp_emitPath = bevp_basePath.bem_copy_0();
bevt_1_ta_ph = bevl_libPath.bem_stepsGet_0();
bevp_libName = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lastGet_0();
} /* Line: 26*/
 else /* Line: 27*/ {
bevp_basePath = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_emitPath = bevp_basePath.bem_copy_0();
} /* Line: 29*/
if (bevp_libName == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 31*/ {
bevl_libnameNp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_libnameNp.bemd_1(-1918980031, bevp_libName);
if (bevp_exeName == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 34*/ {
bevp_exeName = bevp_libName;
} /* Line: 34*/
bevt_4_ta_ph = bevp_build.bem_emitterGet_0();
bevp_libnameInfo = (new BEC_2_5_9_BuildClassInfo()).bem_new_5((BEC_2_5_8_BuildNamePath) bevl_libnameNp , bevt_4_ta_ph, bevp_emitPath, bevp_libName, bevp_exeName);
} /* Line: 35*/
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_new_4(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) throws Throwable {
bevp_libName = beva__libName;
bevp_exeName = beva__exeName;
bem_new_2(beva_spath, beva__build);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInfoGet_0() throws Throwable {
return bevp_libnameInfo;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libnameInfoSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 22, 22, 23, 24, 25, 26, 26, 28, 29, 31, 31, 32, 33, 34, 34, 34, 35, 35, 40, 41, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 31, 32, 33, 34, 35, 36, 39, 40, 42, 47, 48, 49, 50, 55, 56, 58, 59, 64, 65, 66, 70, 73, 77, 80, 84, 87, 91, 94, 98, 101, 105, 108};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 25
assign 1 22 26
undef 1 22 31
assign 1 23 32
new 1 23 32
assign 1 24 33
parentGet 0 24 33
assign 1 25 34
copy 0 25 34
assign 1 26 35
stepsGet 0 26 35
assign 1 26 36
lastGet 0 26 36
assign 1 28 39
new 1 28 39
assign 1 29 40
copy 0 29 40
assign 1 31 42
def 1 31 47
assign 1 32 48
new 0 32 48
fromString 1 33 49
assign 1 34 50
undef 1 34 55
assign 1 34 56
assign 1 35 58
emitterGet 0 35 58
assign 1 35 59
new 5 35 59
assign 1 40 64
assign 1 41 65
new 2 42 66
return 1 0 70
assign 1 0 73
return 1 0 77
assign 1 0 80
return 1 0 84
assign 1 0 87
return 1 0 91
assign 1 0 94
return 1 0 98
assign 1 0 101
return 1 0 105
assign 1 0 108
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 298359009: return bem_buildGet_0();
case 92270569: return bem_create_0();
case 725242182: return bem_emitPathGet_0();
case -2035589254: return bem_libNameGet_0();
case -618327675: return bem_hashGet_0();
case 1469284867: return bem_toString_0();
case 1255209599: return bem_libnameInfoGet_0();
case -675794816: return bem_print_0();
case -1221115541: return bem_new_0();
case -680843899: return bem_basePathGet_0();
case 422595331: return bem_iteratorGet_0();
case 1171022339: return bem_copy_0();
case -1052538151: return bem_exeNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -39729582: return bem_notEquals_1(bevd_0);
case -1468466490: return bem_buildSet_1(bevd_0);
case -1515236141: return bem_print_1(bevd_0);
case -582165770: return bem_emitPathSet_1(bevd_0);
case 192400507: return bem_copyTo_1(bevd_0);
case 1743418089: return bem_libnameInfoSet_1(bevd_0);
case -1089103671: return bem_undef_1(bevd_0);
case -1676614797: return bem_libNameSet_1(bevd_0);
case 1294900175: return bem_basePathSet_1(bevd_0);
case 701760907: return bem_def_1(bevd_0);
case 935360108: return bem_equals_1(bevd_0);
case -375572495: return bem_exeNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -60015904: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case 218804328: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1274504073: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1010736438: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1082406137: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 554981742: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_5_7_BuildLibrary_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_5_7_BuildLibrary_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_7_BuildLibrary();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst = (BEC_2_5_7_BuildLibrary) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_type;
}
}
