package be;
public class BET_2_3_11_XmlTagIterator extends BETS_Object {
public BET_2_3_11_XmlTagIterator() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "stringNew_1", "restart_0", "start_0", "nextGet_0", "hasNextGet_0", "xmlStringGet_0", "xmlStringSet_1", "startedGet_0", "startedSet_1", "xtGet_0", "xtSet_1", "resGet_0", "resSet_1", "iterGet_0", "iterSet_1", "textNodeGet_0", "textNodeSet_1", "lineGet_0", "lineSet_1", "skipGet_0", "skipSet_1", "debugGet_0", "debugSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "xmlString", "started", "xt", "res", "iter", "textNode", "line", "skip", "debug" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_3_11_XmlTagIterator();
}
}
