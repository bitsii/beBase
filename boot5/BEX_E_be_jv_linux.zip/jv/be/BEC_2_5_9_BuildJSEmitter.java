package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x65,0x6D,0x62,0x50,0x6C,0x61,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x6E,0x6F,0x63,0x6F,0x70,0x79,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x3A,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x62,0x65,0x76,0x6F,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_82 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_83 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildJSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_formTarg_1(beva_node);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_invp);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_7));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_8));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_11));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1243490739);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-2087991173);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_14));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_15));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = beva_sdec.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_belsName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_1_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1843396272);
bevt_9_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_ta_ph );
bevt_12_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_12_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_14_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(2142334966);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_5_ta_ph = bevt_6_ta_ph.bem_has_1(bevt_7_ta_ph);
if (!(bevt_5_ta_ph.bevi_bool))/* Line: 85*/ {
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 87*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 87*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(-645349501);
if (bevl_first.bevi_bool)/* Line: 88*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 89*/
 else /* Line: 90*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevp_ccMethods.bem_addValue_1(bevt_9_ta_ph);
} /* Line: 91*/
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_10_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 93*/
 else /* Line: 87*/ {
break;
} /* Line: 87*/
} /* Line: 87*/
} /* Line: 87*/
bevt_16_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_15_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_16_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1843396272);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_13_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevl_stinst);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_20_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_21_ta_ph);
bevt_20_ta_ph.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEndCi_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_0_ta_ph = beva_sdec.bem_addValue_1(bevt_1_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevp_onceDecs.bem_addValue_1(beva_sdec);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 143*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_3_ta_ph = beva_v.bem_nameGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 144*/
bevt_4_ta_ph = super.bem_nameForVar_1(beva_v);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_writeBET_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_7_TextStrings bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_7_TextStrings bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_7_TextStrings bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_7_TextStrings bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_5_4_LogicBool bevt_79_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_5_4_LogicBool bevt_100_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_6_6_SystemObject bevt_109_ta_ph = null;
BEC_2_6_6_SystemObject bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_5_4_LogicBool bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_5_4_LogicBool bevt_119_ta_ph = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
/* Line: 160*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 160*/ {
bevl_clnode = bevl_ci.bemd_0(-645349501);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (!(bevt_2_ta_ph.bevi_bool))/* Line: 164*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_11_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_12_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevp_q);
bevt_15_ta_ph = bevl_clnode.bemd_0(-2094503992);
bevt_14_ta_ph = bevt_15_ta_ph.bemd_0(-1843396272);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(-1744447963);
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevp_q);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_20_ta_ph = bevl_clnode.bemd_0(-2094503992);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-1843396272);
bevt_18_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_19_ta_ph );
bevt_21_ta_ph = bevp_build.bem_libNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_relEmitName_1(bevt_21_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 165*/
bevt_25_ta_ph = bevl_clnode.bemd_0(-2094503992);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(2142334966);
bevt_23_ta_ph = bevt_24_ta_ph.bemd_0(406531788);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 167*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_ta_ph = bevl_clnode.bemd_0(-2094503992);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-1843396272);
bevt_29_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_30_ta_ph );
bevt_32_ta_ph = bevp_build.bem_libNameGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_relEmitName_1(bevt_32_ta_ph);
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevl_nc = bevt_26_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_36_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevl_nc);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_nl);
bevt_41_ta_ph = bevl_clnode.bemd_0(-2094503992);
bevt_40_ta_ph = bevt_41_ta_ph.bemd_0(2142334966);
bevt_39_ta_ph = bevt_40_ta_ph.bemd_0(406531788);
if (((BEC_2_5_4_LogicBool) bevt_39_ta_ph).bevi_bool)/* Line: 176*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_44_ta_ph = bevl_notNullInitDefault.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevl_nc);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 177*/
} /* Line: 176*/
} /* Line: 167*/
 else /* Line: 160*/ {
break;
} /* Line: 160*/
} /* Line: 160*/
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_47_ta_ph = bevp_smnlcs.bem_keysGet_0();
bevt_0_ta_loop = bevt_47_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 185*/ {
bevt_48_ta_ph = bevt_0_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 185*/ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-645349501);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_55_ta_ph = bevl_smap.bem_addValue_1(bevt_56_ta_ph);
bevt_58_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_57_ta_ph = bevt_58_ta_ph.bem_quoteGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevl_smk);
bevt_60_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_59_ta_ph = bevt_60_ta_ph.bem_quoteGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_61_ta_ph);
bevt_62_ta_ph = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_62_ta_ph);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_63_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_71_ta_ph = (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_70_ta_ph = bevl_smap.bem_addValue_1(bevt_71_ta_ph);
bevt_73_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_72_ta_ph = bevt_73_ta_ph.bem_quoteGet_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_addValue_1(bevt_72_ta_ph);
bevt_68_ta_ph = bevt_69_ta_ph.bem_addValue_1(bevl_smk);
bevt_75_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_74_ta_ph = bevt_75_ta_ph.bem_quoteGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bem_addValue_1(bevt_74_ta_ph);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_66_ta_ph = bevt_67_ta_ph.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_65_ta_ph = bevt_66_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_64_ta_ph = bevt_65_ta_ph.bem_addValue_1(bevt_78_ta_ph);
bevt_64_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 188*/
 else /* Line: 185*/ {
break;
} /* Line: 185*/
} /* Line: 185*/
bevt_80_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_81_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_79_ta_ph = bevt_80_ta_ph.bem_has_1(bevt_81_ta_ph);
if (!(bevt_79_ta_ph.bevi_bool))/* Line: 192*/ {
bevl_libe.bem_write_1(bevl_smap);
} /* Line: 193*/
bevt_84_ta_ph = bevp_build.bem_usedLibrarysGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bem_sizeGet_0();
bevt_85_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_83_ta_ph.bevi_int == bevt_85_ta_ph.bevi_int) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_87_ta_ph = (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_86_ta_ph = bevl_libInit.bem_addValue_1(bevt_87_ta_ph);
bevt_86_ta_ph.bem_addValue_1(bevp_nl);
bevt_89_ta_ph = (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_88_ta_ph = bevl_libInit.bem_addValue_1(bevt_89_ta_ph);
bevt_88_ta_ph.bem_addValue_1(bevp_nl);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_90_ta_ph = bevl_libInit.bem_addValue_1(bevt_91_ta_ph);
bevt_90_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 200*/
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_92_ta_ph = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_92_ta_ph);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_96_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_95_ta_ph = bevl_main.bem_addValue_1(bevt_96_ta_ph);
bevt_97_ta_ph = bevl_maincc.bem_fullEmitNameGet_0();
bevt_94_ta_ph = bevt_95_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_98_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_93_ta_ph = bevt_94_ta_ph.bem_addValue_1(bevt_98_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_99_ta_ph.bevi_bool)/* Line: 213*/ {
bevt_101_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_102_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_100_ta_ph = bevt_101_ta_ph.bem_has_1(bevt_102_ta_ph);
if (!(bevt_100_ta_ph.bevi_bool))/* Line: 214*/ {
bevt_104_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_103_ta_ph = bevl_main.bem_addValue_1(bevt_104_ta_ph);
bevt_103_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 215*/
} /* Line: 214*/
bevt_108_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_107_ta_ph = bevl_main.bem_addValue_1(bevt_108_ta_ph);
bevt_110_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_109_ta_ph = bevt_110_ta_ph.bemd_0(1176098110);
bevt_106_ta_ph = bevt_107_ta_ph.bem_addValue_1(bevt_109_ta_ph);
bevt_111_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_105_ta_ph = bevt_106_ta_ph.bem_addValue_1(bevt_111_ta_ph);
bevt_105_ta_ph.bem_addValue_1(bevp_nl);
bevt_112_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_112_ta_ph.bevi_bool)/* Line: 219*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 220*/
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_113_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_113_ta_ph.bevi_bool)/* Line: 225*/ {
bevt_115_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
bevt_114_ta_ph = bevl_main.bem_addValue_1(bevt_115_ta_ph);
bevt_114_ta_ph.bem_addValue_1(bevp_nl);
bevt_117_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_116_ta_ph = bevl_main.bem_addValue_1(bevt_117_ta_ph);
bevt_116_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 227*/
bevt_118_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_118_ta_ph.bevi_bool)/* Line: 229*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 230*/
bem_finishLibOutput_1(bevl_libe);
bevt_119_ta_ph = bevp_build.bem_saveSynsGet_0();
if (bevt_119_ta_ph.bevi_bool)/* Line: 235*/ {
bem_saveSyns_0();
} /* Line: 236*/
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 242*/ {
} /* Line: 242*/
 else /* Line: 244*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 245*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
beva_b.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 246*/
bevt_4_ta_ph = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 248*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_exceptDec);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_parent);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
bevl_extstr = bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_7_ta_ph = bevl_extstr.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevl_extstr = bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-635948859);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-635948859);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_8_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = beva_newcc.bem_relEmitName_1(bevt_8_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_sdec);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_10_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 284*/
 else /* Line: 285*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_67));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 286*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_6_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_68));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_8_ta_ph = bevl_begin.bem_addValue_1(bevt_9_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-504809841);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 302*/ {
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(beva_callArgs);
if (bevt_2_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_69));
beva_callArgs = bevt_4_ta_ph.bem_add_1(beva_callArgs);
} /* Line: 304*/
 else /* Line: 305*/ {
beva_callArgs = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
} /* Line: 306*/
bevt_10_ta_ph = bevp_parentConf.bem_emitNameGet_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(1176098110);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_71));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_callArgs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_5_ta_ph;
} /* Line: 308*/
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_20_ta_ph = beva_callTarget.bem_add_1(bevt_21_ta_ph);
bevt_23_ta_ph = beva_node.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(1176098110);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_73));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_callArgs);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_25_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_allOnceDecs == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 322*/ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 323*/
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getLibOutput_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_13_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
if (bevp_shlibe == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 339*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 341*/ {
bevt_7_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 342*/
bevt_9_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_ta_ph.bemd_0(566256852);
bevt_11_ta_ph = bevp_build.bem_paramsGet_0();
bevt_12_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_74));
bevt_10_ta_ph = bevt_11_ta_ph.bem_has_1(bevt_12_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 346*/ {
bevt_14_ta_ph = bevp_build.bem_paramsGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_74));
bevt_13_ta_ph = bevt_14_ta_ph.bem_get_1(bevt_15_ta_ph);
bevt_0_ta_loop = bevt_13_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 347*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bemd_0(-1039631171);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 347*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-645349501);
bevt_17_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(566256852);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_ta_ph.bemd_0(1638235897);
bevt_20_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph.bemd_0(1731603151);
bevt_21_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 352*/
 else /* Line: 347*/ {
break;
} /* Line: 347*/
} /* Line: 347*/
} /* Line: 347*/
} /* Line: 346*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_75));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_anyName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_77));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_typeName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = beva_newcc.bem_relEmitName_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_78));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_count);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_methods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_80));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_81));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_ta_ph = bevp_methods.bem_addValue_1(bevt_7_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_82));
bevt_1_ta_ph = beva_nameSpace.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_emitName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_83));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 68, 68, 68, 68, 68, 68, 68, 72, 72, 72, 72, 72, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 75, 75, 75, 80, 80, 81, 83, 83, 83, 83, 85, 85, 85, 86, 87, 0, 87, 87, 89, 91, 91, 93, 93, 93, 93, 93, 93, 97, 97, 97, 102, 102, 102, 103, 105, 105, 105, 105, 105, 108, 108, 108, 108, 110, 110, 110, 112, 112, 112, 112, 112, 115, 115, 115, 115, 115, 115, 117, 117, 117, 119, 124, 125, 126, 132, 132, 137, 137, 137, 138, 143, 144, 144, 144, 144, 146, 146, 155, 157, 158, 159, 160, 160, 162, 164, 164, 164, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 167, 167, 167, 169, 169, 169, 169, 169, 169, 169, 169, 169, 175, 175, 175, 175, 175, 175, 176, 176, 176, 177, 177, 177, 177, 177, 177, 183, 185, 185, 0, 185, 185, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 187, 188, 188, 188, 188, 188, 188, 188, 188, 188, 188, 188, 188, 188, 188, 188, 188, 192, 192, 192, 193, 197, 197, 197, 197, 197, 198, 198, 198, 199, 199, 199, 200, 200, 200, 203, 204, 207, 208, 208, 209, 211, 212, 212, 212, 212, 212, 212, 212, 213, 214, 214, 214, 215, 215, 215, 218, 218, 218, 218, 218, 218, 218, 218, 219, 220, 222, 223, 224, 225, 226, 226, 226, 227, 227, 227, 229, 230, 233, 235, 236, 242, 245, 245, 245, 246, 246, 248, 248, 253, 253, 257, 257, 257, 257, 257, 257, 261, 261, 265, 265, 265, 265, 265, 265, 265, 266, 266, 266, 266, 266, 267, 271, 271, 271, 271, 271, 271, 271, 271, 271, 271, 271, 271, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 279, 279, 279, 279, 279, 279, 279, 279, 279, 279, 279, 279, 279, 283, 283, 284, 284, 284, 286, 286, 288, 288, 288, 288, 288, 296, 296, 296, 297, 298, 302, 302, 303, 303, 304, 304, 306, 308, 308, 308, 308, 308, 308, 308, 308, 308, 308, 308, 308, 310, 310, 310, 310, 310, 310, 310, 310, 310, 310, 310, 314, 315, 322, 322, 323, 325, 326, 326, 331, 331, 339, 339, 340, 341, 341, 341, 341, 341, 342, 342, 342, 344, 344, 344, 346, 346, 346, 347, 347, 347, 347, 0, 347, 347, 348, 348, 349, 349, 349, 350, 350, 351, 351, 352, 358, 362, 363, 368, 368, 372, 372, 376, 376, 380, 380, 384, 384, 388, 388, 392, 392, 397, 397, 403, 403, 408, 408, 412, 412, 412, 412, 412, 412, 416, 416, 416, 416, 416, 421, 421, 421, 421, 421, 421, 421, 426, 426, 426, 426, 426, 426, 426, 428, 430, 430, 430, 435, 435, 439, 439, 443, 443, 443, 443, 448, 448, 452, 453, 453, 454, 458, 459, 459, 460, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {98, 99, 100, 101, 102, 103, 104, 105, 111, 112, 113, 119, 120, 121, 122, 128, 129, 130, 131, 141, 142, 143, 144, 145, 146, 147, 148, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 196, 197, 207, 208, 209, 210, 211, 212, 213, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 287, 288, 288, 291, 293, 295, 298, 299, 301, 302, 303, 304, 305, 306, 313, 314, 315, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 378, 379, 380, 385, 386, 392, 393, 394, 395, 404, 406, 407, 408, 409, 411, 412, 550, 551, 552, 553, 554, 557, 559, 560, 561, 562, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 584, 585, 586, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 607, 608, 609, 610, 611, 612, 620, 621, 622, 622, 625, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 665, 666, 667, 669, 671, 672, 673, 674, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 706, 707, 708, 710, 711, 712, 715, 716, 717, 718, 719, 720, 721, 722, 723, 725, 727, 728, 729, 730, 732, 733, 734, 735, 736, 737, 739, 741, 743, 744, 746, 756, 760, 761, 766, 767, 768, 770, 771, 777, 778, 786, 787, 788, 789, 790, 791, 795, 796, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 914, 919, 920, 921, 922, 925, 926, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 966, 967, 969, 970, 972, 973, 976, 978, 979, 980, 981, 982, 983, 984, 985, 986, 987, 988, 989, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1005, 1006, 1011, 1016, 1017, 1019, 1020, 1021, 1025, 1026, 1057, 1062, 1063, 1064, 1065, 1066, 1067, 1072, 1073, 1074, 1075, 1077, 1078, 1079, 1080, 1081, 1082, 1084, 1085, 1086, 1087, 1087, 1090, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1110, 1113, 1114, 1119, 1120, 1124, 1125, 1129, 1130, 1134, 1135, 1139, 1140, 1144, 1145, 1149, 1150, 1154, 1155, 1159, 1160, 1164, 1165, 1173, 1174, 1175, 1176, 1177, 1178, 1185, 1186, 1187, 1188, 1189, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1230, 1231, 1235, 1236, 1242, 1243, 1244, 1245, 1249, 1250, 1255, 1256, 1257, 1258, 1263, 1264, 1265, 1266, 1269, 1272, 1276, 1279};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 98
new 0 16 98
assign 1 17 99
new 0 17 99
assign 1 18 100
new 0 18 100
new 1 22 101
assign 1 24 102
new 0 24 102
assign 1 25 103
new 0 25 103
assign 1 27 104
new 0 27 104
assign 1 28 105
new 0 28 105
assign 1 32 111
formTarg 1 32 111
assign 1 32 112
add 1 32 112
return 1 32 113
assign 1 36 119
formCallTarg 1 36 119
assign 1 36 120
new 0 36 120
assign 1 36 121
add 1 36 121
return 1 36 122
assign 1 40 128
formCallTarg 1 40 128
assign 1 40 129
new 0 40 129
assign 1 40 130
add 1 40 130
return 1 40 131
assign 1 44 141
new 0 44 141
assign 1 44 142
addValue 1 44 142
assign 1 44 143
secondGet 0 44 143
assign 1 44 144
formTarg 1 44 144
assign 1 44 145
addValue 1 44 145
assign 1 44 146
new 0 44 146
assign 1 44 147
addValue 1 44 147
addValue 1 44 148
assign 1 48 169
new 0 48 169
assign 1 48 170
toString 0 48 170
assign 1 48 171
add 1 48 171
incrementValue 0 49 172
assign 1 50 173
new 0 50 173
assign 1 50 174
addValue 1 50 174
assign 1 50 175
addValue 1 50 175
assign 1 50 176
new 0 50 176
assign 1 50 177
addValue 1 50 177
addValue 1 50 178
assign 1 55 179
containedGet 0 55 179
assign 1 55 180
firstGet 0 55 180
assign 1 55 181
containedGet 0 55 181
assign 1 55 182
firstGet 0 55 182
assign 1 55 183
new 0 55 183
assign 1 55 184
add 1 55 184
assign 1 55 185
new 0 55 185
assign 1 55 186
add 1 55 186
assign 1 55 187
finalAssign 4 55 187
addValue 1 55 188
assign 1 63 196
new 0 63 196
addValue 1 63 197
assign 1 68 207
emitNameGet 0 68 207
assign 1 68 208
addValue 1 68 208
assign 1 68 209
new 0 68 209
assign 1 68 210
addValue 1 68 210
assign 1 68 211
addValue 1 68 211
assign 1 68 212
new 0 68 212
addValue 1 68 213
assign 1 72 233
emitNameGet 0 72 233
assign 1 72 234
addValue 1 72 234
assign 1 72 235
new 0 72 235
assign 1 72 236
addValue 1 72 236
addValue 1 72 237
assign 1 73 238
new 0 73 238
assign 1 73 239
addValue 1 73 239
assign 1 73 240
heldGet 0 73 240
assign 1 73 241
namepathGet 0 73 241
assign 1 73 242
getClassConfig 1 73 242
assign 1 73 243
libNameGet 0 73 243
assign 1 73 244
relEmitName 1 73 244
assign 1 73 245
addValue 1 73 245
assign 1 73 246
new 0 73 246
assign 1 73 247
addValue 1 73 247
addValue 1 73 248
assign 1 75 249
new 0 75 249
assign 1 75 250
addValue 1 75 250
addValue 1 75 251
assign 1 80 276
heldGet 0 80 276
assign 1 80 277
synGet 0 80 277
assign 1 81 278
ptyListGet 0 81 278
assign 1 83 279
emitNameGet 0 83 279
assign 1 83 280
addValue 1 83 280
assign 1 83 281
new 0 83 281
addValue 1 83 282
assign 1 85 283
emitChecksGet 0 85 283
assign 1 85 284
new 0 85 284
assign 1 85 285
has 1 85 285
assign 1 86 287
new 0 86 287
assign 1 87 288
iteratorGet 0 0 288
assign 1 87 291
hasNextGet 0 87 291
assign 1 87 293
nextGet 0 87 293
assign 1 89 295
new 0 89 295
assign 1 91 298
new 0 91 298
addValue 1 91 299
assign 1 93 301
addValue 1 93 301
assign 1 93 302
new 0 93 302
assign 1 93 303
addValue 1 93 303
assign 1 93 304
nameGet 0 93 304
assign 1 93 305
addValue 1 93 305
addValue 1 93 306
assign 1 97 313
new 0 97 313
assign 1 97 314
addValue 1 97 314
addValue 1 97 315
assign 1 102 343
heldGet 0 102 343
assign 1 102 344
namepathGet 0 102 344
assign 1 102 345
getClassConfig 1 102 345
assign 1 103 346
getInitialInst 1 103 346
assign 1 105 347
emitNameGet 0 105 347
assign 1 105 348
addValue 1 105 348
assign 1 105 349
new 0 105 349
assign 1 105 350
addValue 1 105 350
addValue 1 105 351
assign 1 108 352
addValue 1 108 352
assign 1 108 353
new 0 108 353
assign 1 108 354
addValue 1 108 354
addValue 1 108 355
assign 1 110 356
new 0 110 356
assign 1 110 357
addValue 1 110 357
addValue 1 110 358
assign 1 112 359
emitNameGet 0 112 359
assign 1 112 360
addValue 1 112 360
assign 1 112 361
new 0 112 361
assign 1 112 362
addValue 1 112 362
addValue 1 112 363
assign 1 115 364
new 0 115 364
assign 1 115 365
addValue 1 115 365
assign 1 115 366
addValue 1 115 366
assign 1 115 367
new 0 115 367
assign 1 115 368
addValue 1 115 368
addValue 1 115 369
assign 1 117 370
new 0 117 370
assign 1 117 371
addValue 1 117 371
addValue 1 117 372
buildPropList 0 119 373
getCode 2 124 378
assign 1 125 379
toString 0 125 379
addValue 1 126 380
assign 1 132 385
new 0 132 385
addValue 1 132 386
assign 1 137 392
new 0 137 392
assign 1 137 393
addValue 1 137 393
addValue 1 137 394
addValue 1 138 395
assign 1 143 404
isPropertyGet 0 143 404
assign 1 144 406
new 0 144 406
assign 1 144 407
nameGet 0 144 407
assign 1 144 408
add 1 144 408
return 1 144 409
assign 1 146 411
nameForVar 1 146 411
return 1 146 412
assign 1 155 550
getLibOutput 0 155 550
assign 1 157 551
new 0 157 551
assign 1 158 552
new 0 158 552
assign 1 159 553
new 0 159 553
assign 1 160 554
iteratorGet 0 160 554
assign 1 160 557
hasNextGet 0 160 557
assign 1 162 559
nextGet 0 162 559
assign 1 164 560
emitChecksGet 0 164 560
assign 1 164 561
new 0 164 561
assign 1 164 562
has 1 164 562
assign 1 165 564
new 0 165 564
assign 1 165 565
addValue 1 165 565
assign 1 165 566
addValue 1 165 566
assign 1 165 567
heldGet 0 165 567
assign 1 165 568
namepathGet 0 165 568
assign 1 165 569
toString 0 165 569
assign 1 165 570
addValue 1 165 570
assign 1 165 571
addValue 1 165 571
assign 1 165 572
new 0 165 572
assign 1 165 573
addValue 1 165 573
assign 1 165 574
heldGet 0 165 574
assign 1 165 575
namepathGet 0 165 575
assign 1 165 576
getClassConfig 1 165 576
assign 1 165 577
libNameGet 0 165 577
assign 1 165 578
relEmitName 1 165 578
assign 1 165 579
addValue 1 165 579
assign 1 165 580
new 0 165 580
assign 1 165 581
addValue 1 165 581
addValue 1 165 582
assign 1 167 584
heldGet 0 167 584
assign 1 167 585
synGet 0 167 585
assign 1 167 586
hasDefaultGet 0 167 586
assign 1 169 588
new 0 169 588
assign 1 169 589
heldGet 0 169 589
assign 1 169 590
namepathGet 0 169 590
assign 1 169 591
getClassConfig 1 169 591
assign 1 169 592
libNameGet 0 169 592
assign 1 169 593
relEmitName 1 169 593
assign 1 169 594
add 1 169 594
assign 1 169 595
new 0 169 595
assign 1 169 596
add 1 169 596
assign 1 175 597
new 0 175 597
assign 1 175 598
addValue 1 175 598
assign 1 175 599
addValue 1 175 599
assign 1 175 600
new 0 175 600
assign 1 175 601
addValue 1 175 601
addValue 1 175 602
assign 1 176 603
heldGet 0 176 603
assign 1 176 604
synGet 0 176 604
assign 1 176 605
hasDefaultGet 0 176 605
assign 1 177 607
new 0 177 607
assign 1 177 608
addValue 1 177 608
assign 1 177 609
addValue 1 177 609
assign 1 177 610
new 0 177 610
assign 1 177 611
addValue 1 177 611
addValue 1 177 612
assign 1 183 620
new 0 183 620
assign 1 185 621
keysGet 0 185 621
assign 1 185 622
iteratorGet 0 0 622
assign 1 185 625
hasNextGet 0 185 625
assign 1 185 627
nextGet 0 185 627
assign 1 187 628
new 0 187 628
assign 1 187 629
addValue 1 187 629
assign 1 187 630
new 0 187 630
assign 1 187 631
quoteGet 0 187 631
assign 1 187 632
addValue 1 187 632
assign 1 187 633
addValue 1 187 633
assign 1 187 634
new 0 187 634
assign 1 187 635
quoteGet 0 187 635
assign 1 187 636
addValue 1 187 636
assign 1 187 637
new 0 187 637
assign 1 187 638
addValue 1 187 638
assign 1 187 639
get 1 187 639
assign 1 187 640
addValue 1 187 640
assign 1 187 641
new 0 187 641
assign 1 187 642
addValue 1 187 642
addValue 1 187 643
assign 1 188 644
new 0 188 644
assign 1 188 645
addValue 1 188 645
assign 1 188 646
new 0 188 646
assign 1 188 647
quoteGet 0 188 647
assign 1 188 648
addValue 1 188 648
assign 1 188 649
addValue 1 188 649
assign 1 188 650
new 0 188 650
assign 1 188 651
quoteGet 0 188 651
assign 1 188 652
addValue 1 188 652
assign 1 188 653
new 0 188 653
assign 1 188 654
addValue 1 188 654
assign 1 188 655
get 1 188 655
assign 1 188 656
addValue 1 188 656
assign 1 188 657
new 0 188 657
assign 1 188 658
addValue 1 188 658
addValue 1 188 659
assign 1 192 665
emitChecksGet 0 192 665
assign 1 192 666
new 0 192 666
assign 1 192 667
has 1 192 667
write 1 193 669
assign 1 197 671
usedLibrarysGet 0 197 671
assign 1 197 672
sizeGet 0 197 672
assign 1 197 673
new 0 197 673
assign 1 197 674
equals 1 197 679
assign 1 198 680
new 0 198 680
assign 1 198 681
addValue 1 198 681
addValue 1 198 682
assign 1 199 683
new 0 199 683
assign 1 199 684
addValue 1 199 684
addValue 1 199 685
assign 1 200 686
new 0 200 686
assign 1 200 687
addValue 1 200 687
addValue 1 200 688
write 1 203 690
write 1 204 691
assign 1 207 692
new 0 207 692
assign 1 208 693
mainNameGet 0 208 693
fromString 1 208 694
assign 1 209 695
getClassConfig 1 209 695
assign 1 211 696
new 0 211 696
assign 1 212 697
new 0 212 697
assign 1 212 698
addValue 1 212 698
assign 1 212 699
fullEmitNameGet 0 212 699
assign 1 212 700
addValue 1 212 700
assign 1 212 701
new 0 212 701
assign 1 212 702
addValue 1 212 702
addValue 1 212 703
assign 1 213 704
ownProcessGet 0 213 704
assign 1 214 706
emitChecksGet 0 214 706
assign 1 214 707
new 0 214 707
assign 1 214 708
has 1 214 708
assign 1 215 710
new 0 215 710
assign 1 215 711
addValue 1 215 711
addValue 1 215 712
assign 1 218 715
new 0 218 715
assign 1 218 716
addValue 1 218 716
assign 1 218 717
outputPlatformGet 0 218 717
assign 1 218 718
nameGet 0 218 718
assign 1 218 719
addValue 1 218 719
assign 1 218 720
new 0 218 720
assign 1 218 721
addValue 1 218 721
addValue 1 218 722
assign 1 219 723
doMainGet 0 219 723
write 1 220 725
assign 1 222 727
new 0 222 727
write 1 223 728
write 1 224 729
assign 1 225 730
ownProcessGet 0 225 730
assign 1 226 732
new 0 226 732
assign 1 226 733
addValue 1 226 733
addValue 1 226 734
assign 1 227 735
new 0 227 735
assign 1 227 736
addValue 1 227 736
addValue 1 227 737
assign 1 229 739
doMainGet 0 229 739
write 1 230 741
finishLibOutput 1 233 743
assign 1 235 744
saveSynsGet 0 235 744
saveSyns 0 236 746
assign 1 242 756
isPropertyGet 0 242 756
assign 1 245 760
isArgGet 0 245 760
assign 1 245 761
not 0 245 766
assign 1 246 767
new 0 246 767
addValue 1 246 768
assign 1 248 770
nameForVar 1 248 770
addValue 1 248 771
assign 1 253 777
new 0 253 777
return 1 253 778
assign 1 257 786
new 0 257 786
assign 1 257 787
add 1 257 787
assign 1 257 788
new 0 257 788
assign 1 257 789
add 1 257 789
assign 1 257 790
add 1 257 790
return 1 257 791
assign 1 261 795
new 0 261 795
return 1 261 796
assign 1 265 810
emitNameGet 0 265 810
assign 1 265 811
new 0 265 811
assign 1 265 812
add 1 265 812
assign 1 265 813
add 1 265 813
assign 1 265 814
new 0 265 814
assign 1 265 815
add 1 265 815
assign 1 265 816
addValue 1 265 816
assign 1 266 817
emitNameGet 0 266 817
assign 1 266 818
add 1 266 818
assign 1 266 819
new 0 266 819
assign 1 266 820
add 1 266 820
assign 1 266 821
addValue 1 266 821
return 1 267 822
assign 1 271 836
new 0 271 836
assign 1 271 837
libNameGet 0 271 837
assign 1 271 838
relEmitName 1 271 838
assign 1 271 839
add 1 271 839
assign 1 271 840
new 0 271 840
assign 1 271 841
add 1 271 841
assign 1 271 842
heldGet 0 271 842
assign 1 271 843
literalValueGet 0 271 843
assign 1 271 844
add 1 271 844
assign 1 271 845
new 0 271 845
assign 1 271 846
add 1 271 846
return 1 271 847
assign 1 275 861
new 0 275 861
assign 1 275 862
libNameGet 0 275 862
assign 1 275 863
relEmitName 1 275 863
assign 1 275 864
add 1 275 864
assign 1 275 865
new 0 275 865
assign 1 275 866
add 1 275 866
assign 1 275 867
heldGet 0 275 867
assign 1 275 868
literalValueGet 0 275 868
assign 1 275 869
add 1 275 869
assign 1 275 870
new 0 275 870
assign 1 275 871
add 1 275 871
return 1 275 872
assign 1 279 887
new 0 279 887
assign 1 279 888
libNameGet 0 279 888
assign 1 279 889
relEmitName 1 279 889
assign 1 279 890
add 1 279 890
assign 1 279 891
new 0 279 891
assign 1 279 892
add 1 279 892
assign 1 279 893
add 1 279 893
assign 1 279 894
new 0 279 894
assign 1 279 895
add 1 279 895
assign 1 279 896
add 1 279 896
assign 1 279 897
new 0 279 897
assign 1 279 898
add 1 279 898
return 1 279 899
assign 1 283 914
def 1 283 919
assign 1 284 920
libNameGet 0 284 920
assign 1 284 921
relEmitName 1 284 921
assign 1 284 922
extend 1 284 922
assign 1 286 925
new 0 286 925
assign 1 286 926
extend 1 286 926
assign 1 288 928
new 0 288 928
assign 1 288 929
emitNameGet 0 288 929
assign 1 288 930
addValue 1 288 930
assign 1 288 931
new 0 288 931
assign 1 288 932
addValue 1 288 932
assign 1 296 933
new 0 296 933
assign 1 296 934
addValue 1 296 934
addValue 1 296 935
addValue 1 297 936
return 1 298 937
assign 1 302 966
heldGet 0 302 966
assign 1 302 967
superCallGet 0 302 967
assign 1 303 969
new 0 303 969
assign 1 303 970
notEmpty 1 303 970
assign 1 304 972
new 0 304 972
assign 1 304 973
add 1 304 973
assign 1 306 976
new 0 306 976
assign 1 308 978
emitNameGet 0 308 978
assign 1 308 979
new 0 308 979
assign 1 308 980
add 1 308 980
assign 1 308 981
heldGet 0 308 981
assign 1 308 982
nameGet 0 308 982
assign 1 308 983
add 1 308 983
assign 1 308 984
new 0 308 984
assign 1 308 985
add 1 308 985
assign 1 308 986
add 1 308 986
assign 1 308 987
new 0 308 987
assign 1 308 988
add 1 308 988
return 1 308 989
assign 1 310 991
new 0 310 991
assign 1 310 992
add 1 310 992
assign 1 310 993
heldGet 0 310 993
assign 1 310 994
nameGet 0 310 994
assign 1 310 995
add 1 310 995
assign 1 310 996
new 0 310 996
assign 1 310 997
add 1 310 997
assign 1 310 998
add 1 310 998
assign 1 310 999
new 0 310 999
assign 1 310 1000
add 1 310 1000
return 1 310 1001
assign 1 314 1005
new 0 314 1005
return 1 315 1006
assign 1 322 1011
undef 1 322 1016
assign 1 323 1017
new 0 323 1017
addValue 1 325 1019
assign 1 326 1020
new 0 326 1020
return 1 326 1021
assign 1 331 1025
getLibOutput 0 331 1025
return 1 331 1026
assign 1 339 1057
undef 1 339 1062
assign 1 340 1063
new 0 340 1063
assign 1 341 1064
parentGet 0 341 1064
assign 1 341 1065
fileGet 0 341 1065
assign 1 341 1066
existsGet 0 341 1066
assign 1 341 1067
not 0 341 1072
assign 1 342 1073
parentGet 0 342 1073
assign 1 342 1074
fileGet 0 342 1074
makeDirs 0 342 1075
assign 1 344 1077
fileGet 0 344 1077
assign 1 344 1078
writerGet 0 344 1078
assign 1 344 1079
open 0 344 1079
assign 1 346 1080
paramsGet 0 346 1080
assign 1 346 1081
new 0 346 1081
assign 1 346 1082
has 1 346 1082
assign 1 347 1084
paramsGet 0 347 1084
assign 1 347 1085
new 0 347 1085
assign 1 347 1086
get 1 347 1086
assign 1 347 1087
iteratorGet 0 0 1087
assign 1 347 1090
hasNextGet 0 347 1090
assign 1 347 1092
nextGet 0 347 1092
assign 1 348 1093
apNew 1 348 1093
assign 1 348 1094
fileGet 0 348 1094
assign 1 349 1095
readerGet 0 349 1095
assign 1 349 1096
open 0 349 1096
assign 1 349 1097
readString 0 349 1097
assign 1 350 1098
readerGet 0 350 1098
close 0 350 1099
assign 1 351 1100
countLines 1 351 1100
addValue 1 351 1101
write 1 352 1102
return 1 358 1110
close 0 362 1113
assign 1 363 1114
assign 1 368 1119
new 0 368 1119
return 1 368 1120
assign 1 372 1124
new 0 372 1124
return 1 372 1125
assign 1 376 1129
new 0 376 1129
return 1 376 1130
assign 1 380 1134
new 0 380 1134
return 1 380 1135
assign 1 384 1139
new 0 384 1139
return 1 384 1140
assign 1 388 1144
new 0 388 1144
return 1 388 1145
assign 1 392 1149
new 0 392 1149
return 1 392 1150
assign 1 397 1154
new 0 397 1154
return 1 397 1155
assign 1 403 1159
new 0 403 1159
return 1 403 1160
assign 1 408 1164
new 0 408 1164
return 1 408 1165
assign 1 412 1173
new 0 412 1173
assign 1 412 1174
add 1 412 1174
assign 1 412 1175
new 0 412 1175
assign 1 412 1176
add 1 412 1176
assign 1 412 1177
add 1 412 1177
return 1 412 1178
assign 1 416 1185
libNameGet 0 416 1185
assign 1 416 1186
relEmitName 1 416 1186
assign 1 416 1187
new 0 416 1187
assign 1 416 1188
add 1 416 1188
return 1 416 1189
assign 1 421 1198
emitNameGet 0 421 1198
assign 1 421 1199
new 0 421 1199
assign 1 421 1200
add 1 421 1200
assign 1 421 1201
new 0 421 1201
assign 1 421 1202
add 1 421 1202
assign 1 421 1203
add 1 421 1203
return 1 421 1204
assign 1 426 1215
emitNameGet 0 426 1215
assign 1 426 1216
addValue 1 426 1216
assign 1 426 1217
new 0 426 1217
assign 1 426 1218
addValue 1 426 1218
assign 1 426 1219
addValue 1 426 1219
assign 1 426 1220
new 0 426 1220
addValue 1 426 1221
addValue 1 428 1222
assign 1 430 1223
new 0 430 1223
assign 1 430 1224
addValue 1 430 1224
addValue 1 430 1225
assign 1 435 1230
new 0 435 1230
return 1 435 1231
assign 1 439 1235
new 0 439 1235
return 1 439 1236
assign 1 443 1242
new 0 443 1242
assign 1 443 1243
add 1 443 1243
assign 1 443 1244
add 1 443 1244
return 1 443 1245
assign 1 448 1249
new 0 448 1249
return 1 448 1250
assign 1 452 1255
getClassConfig 1 452 1255
assign 1 453 1256
fullEmitNameGet 0 453 1256
emitNameSet 1 453 1257
return 1 454 1258
assign 1 458 1263
getLocalClassConfig 1 458 1263
assign 1 459 1264
fullEmitNameGet 0 459 1264
emitNameSet 1 459 1265
return 1 460 1266
return 1 0 1269
assign 1 0 1272
return 1 0 1276
assign 1 0 1279
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 323068348: return bem_inFilePathedGet_0();
case -1742872288: return bem_ntypesGet_0();
case 1139291279: return bem_ccMethodsGet_0();
case 1837821584: return bem_scvpGet_0();
case -1847862474: return bem_idToNamePathGet_0();
case 1373485542: return bem_dynMethodsGet_0();
case -697615483: return bem_fileExtGet_0();
case -817816717: return bem_preClassGet_0();
case 2062134685: return bem_ccCacheGet_0();
case -1850181517: return bem_lastMethodBodyLinesGet_0();
case 168865628: return bem_cnodeGet_0();
case -1470497874: return bem_buildInitial_0();
case 172705043: return bem_propDecGet_0();
case -1571276036: return bem_libEmitNameGet_0();
case -1048960358: return bem_randGet_0();
case -191146645: return bem_classCallsGet_0();
case -1869109136: return bem_classNameGet_0();
case -1408678963: return bem_qGet_0();
case 1145147302: return bem_intNpGet_0();
case -1848481770: return bem_getLibOutput_0();
case 1904654942: return bem_fullLibEmitNameGet_0();
case -1334177629: return bem_buildClassInfo_0();
case -1709553061: return bem_classConfGet_0();
case 881000385: return bem_parentConfGet_0();
case 795779294: return bem_emitLangGet_0();
case 642171726: return bem_mainEndGet_0();
case -175001067: return bem_exceptDecGet_0();
case 1834691664: return bem_methodCatchGet_0();
case -66437749: return bem_msynGet_0();
case 56470103: return bem_allOnceDecsGet_0();
case 989314328: return bem_shlibeGet_0();
case 345869211: return bem_belslitsGet_0();
case -1546872974: return bem_loadIds_0();
case -1650622151: return bem_iteratorGet_0();
case 1588167742: return bem_emitLib_0();
case -1544307906: return bem_tagGet_0();
case 635923837: return bem_idToNameGet_0();
case -89687002: return bem_synEmitPathGet_0();
case -1758257394: return bem_useDynMethodsGet_0();
case -1406793129: return bem_print_0();
case -1339651028: return bem_onceDecsGet_0();
case 278188316: return bem_writeBET_0();
case -833760748: return bem_inClassGet_0();
case -1251096321: return bem_libEmitPathGet_0();
case -1728344528: return bem_superNameGet_0();
case -403978956: return bem_typeDecGet_0();
case -515852788: return bem_methodCallsGet_0();
case 240137651: return bem_lastMethodsLinesGet_0();
case 851437340: return bem_buildPropList_0();
case -1473642952: return bem_instanceEqualGet_0();
case -456848568: return bem_spropDecGet_0();
case 1932389725: return bem_lastMethodBodySizeGet_0();
case 878283040: return bem_lastMethodsSizeGet_0();
case -310164539: return bem_endNs_0();
case -33118629: return bem_newDecGet_0();
case -1745199484: return bem_stringNpGet_0();
case -1702560668: return bem_nameToIdPathGet_0();
case 448161942: return bem_nlGet_0();
case 1674227993: return bem_smnlecsGet_0();
case -1612099627: return bem_nativeCSlotsGet_0();
case -1086420345: return bem_baseMtdDecGet_0();
case -1687589351: return bem_preClassOutput_0();
case 1989627728: return bem_objectNpGet_0();
case 158540098: return bem_boolTypeGet_0();
case 1592590251: return bem_invpGet_0();
case 695970418: return bem_methodsGet_0();
case 1505629153: return bem_gcMarksGet_0();
case -1964316072: return bem_lineCountGet_0();
case -1744447963: return bem_toString_0();
case 1549133114: return bem_mainInClassGet_0();
case -472030254: return bem_classEndGet_0();
case -425701808: return bem_overrideMtdDecGet_0();
case -1063105140: return bem_create_0();
case -17851578: return bem_new_0();
case -46543645: return bem_trueValueGet_0();
case 1242623472: return bem_transGet_0();
case -1433140825: return bem_returnTypeGet_0();
case 1593325911: return bem_baseSmtdDecGet_0();
case -1862849517: return bem_hashGet_0();
case -1363440214: return bem_mainOutsideNsGet_0();
case 929443055: return bem_covariantReturnsGet_0();
case -199935101: return bem_buildCreate_0();
case -964376567: return bem_copy_0();
case -213682365: return bem_afterCast_0();
case 482577178: return bem_boolCcGet_0();
case 1818128155: return bem_superCallsGet_0();
case 2116713115: return bem_objectCcGet_0();
case 14288677: return bem_falseValueGet_0();
case -1454184378: return bem_classesInDepthOrderGet_0();
case -1109746780: return bem_beginNs_0();
case 1062040967: return bem_propertyDecsGet_0();
case 288293896: return bem_mainStartGet_0();
case 1825933510: return bem_smnlcsGet_0();
case -107128798: return bem_maxSpillArgsLenGet_0();
case 422595026: return bem_classEmitsGet_0();
case 1090480344: return bem_nameToIdGet_0();
case -311875845: return bem_buildGet_0();
case 2093337972: return bem_instanceNotEqualGet_0();
case 906633671: return bem_nullValueGet_0();
case -1749801974: return bem_initialDecGet_0();
case -1723014: return bem_lastCallGet_0();
case 2101865165: return bem_boolNpGet_0();
case 53354778: return bem_runtimeInitGet_0();
case 321238180: return bem_saveSyns_0();
case -1022686241: return bem_instOfGet_0();
case 1475747178: return bem_doEmit_0();
case 1608567712: return bem_getClassOutput_0();
case 242112293: return bem_saveIds_0();
case 596301414: return bem_csynGet_0();
case -852344027: return bem_callNamesGet_0();
case 115446801: return bem_methodBodyGet_0();
case 1406718718: return bem_floatNpGet_0();
case 343642447: return bem_maxDynArgsGet_0();
case -1648781300: return bem_constGet_0();
case -601711211: return bem_mnodeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1416367906: return bem_classCallsSet_1(bevd_0);
case 1395141126: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -37992639: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1654561022: return bem_ccMethodsSet_1(bevd_0);
case 348006120: return bem_idToNameSet_1(bevd_0);
case -1608144688: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -795508194: return bem_ccCacheSet_1(bevd_0);
case 1276879168: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -656704030: return bem_boolNpSet_1(bevd_0);
case -1392314400: return bem_preClassSet_1(bevd_0);
case 1388679866: return bem_falseValueSet_1(bevd_0);
case -54815286: return bem_def_1(bevd_0);
case 1353899175: return bem_nameToIdSet_1(bevd_0);
case -1264751514: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -468123532: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1247985902: return bem_msynSet_1(bevd_0);
case -2030517412: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1050214746: return bem_inClassSet_1(bevd_0);
case -832567076: return bem_instanceEqualSet_1(bevd_0);
case 1772791794: return bem_scvpSet_1(bevd_0);
case -36191473: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1823618978: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -885602778: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1879509831: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1228336767: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 282846398: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1144148799: return bem_objectNpSet_1(bevd_0);
case -165218561: return bem_inFilePathedSet_1(bevd_0);
case -1639849794: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1476310369: return bem_methodCallsSet_1(bevd_0);
case -530409840: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 675470434: return bem_libEmitNameSet_1(bevd_0);
case 1700457382: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1024867767: return bem_buildSet_1(bevd_0);
case -24622357: return bem_mnodeSet_1(bevd_0);
case 689573322: return bem_equals_1(bevd_0);
case -662153228: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 240885009: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1957741454: return bem_propertyDecsSet_1(bevd_0);
case -1136750515: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 143433474: return bem_superCallsSet_1(bevd_0);
case -1217606941: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1063668189: return bem_begin_1(bevd_0);
case 827390257: return bem_smnlcsSet_1(bevd_0);
case 576817025: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 537818088: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1067539483: return bem_nativeCSlotsSet_1(bevd_0);
case 581833555: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1564316354: return bem_methodBodySet_1(bevd_0);
case 265532230: return bem_fileExtSet_1(bevd_0);
case -1159185985: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1832844782: return bem_sameObject_1(bevd_0);
case 295466991: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1687355188: return bem_nullValueSet_1(bevd_0);
case 371048183: return bem_notEquals_1(bevd_0);
case -1473913152: return bem_intNpSet_1(bevd_0);
case -1275993696: return bem_trueValueSet_1(bevd_0);
case 21543626: return bem_allOnceDecsSet_1(bevd_0);
case 788808081: return bem_dynMethodsSet_1(bevd_0);
case 937061535: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -68581565: return bem_emitLangSet_1(bevd_0);
case 1497537928: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 2104045665: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -976779970: return bem_objectCcSet_1(bevd_0);
case 1260834106: return bem_classesInDepthOrderSet_1(bevd_0);
case -1219175542: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1635872230: return bem_fullLibEmitNameSet_1(bevd_0);
case -1185669536: return bem_shlibeSet_1(bevd_0);
case 904022707: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -518194617: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1113331744: return bem_end_1(bevd_0);
case 1344889814: return bem_belslitsSet_1(bevd_0);
case 979424094: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 202653656: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -255357934: return bem_libEmitPathSet_1(bevd_0);
case -1492086420: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 896469763: return bem_lineCountSet_1(bevd_0);
case 1675893608: return bem_stringNpSet_1(bevd_0);
case 1563061447: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1864225131: return bem_lastMethodsSizeSet_1(bevd_0);
case -2063195266: return bem_lastMethodsLinesSet_1(bevd_0);
case -669953607: return bem_boolCcSet_1(bevd_0);
case -2026467957: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -144466290: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1779131762: return bem_classEmitsSet_1(bevd_0);
case 516456619: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -634103428: return bem_constSet_1(bevd_0);
case -1949852077: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1720843255: return bem_onceDecsSet_1(bevd_0);
case 951565983: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1854460739: return bem_exceptDecSet_1(bevd_0);
case -1364615440: return bem_maxDynArgsSet_1(bevd_0);
case -1472683674: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1427097082: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -18932262: return bem_callNamesSet_1(bevd_0);
case -248628898: return bem_idToNamePathSet_1(bevd_0);
case -233049509: return bem_gcMarksSet_1(bevd_0);
case 763307205: return bem_cnodeSet_1(bevd_0);
case -446873327: return bem_csynSet_1(bevd_0);
case -489749780: return bem_instanceNotEqualSet_1(bevd_0);
case -1368388934: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -2137312933: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -423813550: return bem_classConfSet_1(bevd_0);
case 891037512: return bem_methodsSet_1(bevd_0);
case -2118367234: return bem_synEmitPathSet_1(bevd_0);
case 1823194930: return bem_returnTypeSet_1(bevd_0);
case 1965712615: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1552025867: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1229613272: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 849009869: return bem_nlSet_1(bevd_0);
case 865270744: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -648945031: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1238330634: return bem_methodCatchSet_1(bevd_0);
case -1167175972: return bem_ntypesSet_1(bevd_0);
case 1276828005: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 612766762: return bem_smnlecsSet_1(bevd_0);
case -2048436917: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1498151318: return bem_parentConfSet_1(bevd_0);
case -708773480: return bem_transSet_1(bevd_0);
case -1151830135: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 77846106: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1420308135: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1150315870: return bem_invpSet_1(bevd_0);
case -1110515547: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -522694891: return bem_floatNpSet_1(bevd_0);
case -1700904402: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -790762626: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -1288094758: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1891229802: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 2064436185: return bem_instOfSet_1(bevd_0);
case -1968666168: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1214965065: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -695475400: return bem_qSet_1(bevd_0);
case -1108957080: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1199291070: return bem_nameToIdPathSet_1(bevd_0);
case 938508311: return bem_lastCallSet_1(bevd_0);
case 1764708193: return bem_copyTo_1(bevd_0);
case -505487772: return bem_randSet_1(bevd_0);
case -1472504739: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 596089581: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1228807813: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -984363126: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1854901638: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -511862352: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1596076075: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1269110753: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -114648207: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -905239156: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1135788730: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523546720: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1650827610: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 655992945: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1121134228: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1178647801: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 144934315: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1426012566: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1682120256: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1164282049: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -617085642: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -934065273: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1823097484: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1779956490: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -87313812: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1450027329: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1556441013: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
