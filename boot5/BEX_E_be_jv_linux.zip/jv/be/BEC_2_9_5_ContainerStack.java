package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
private static byte[] becc_BEC_2_9_5_ContainerStack_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_BEC_2_9_5_ContainerStack_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_inst;

public static BET_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_5_ContainerStack bem_new_0() throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_push_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
if (bevp_holder == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 41 */
 else  /* Line: 42 */ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 44 */
} /* Line: 40 */
 else  /* Line: 39 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_4_tmpany_phold = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 49 */
 else  /* Line: 50 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 51 */
} /* Line: 39 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_pop_0() throws Throwable {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
return bevp_top;
} /* Line: 59 */
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 63 */ {
bevp_holder = bevl_last;
} /* Line: 64 */
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
return null;
} /* Line: 67 */
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_2_6_6_SystemObject bem_peek_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 76 */ {
return bevp_top;
} /* Line: 77 */
bevt_1_tmpany_phold = bevp_top.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_pop_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_pop.bevi_bool) /* Line: 95 */ {
bevt_0_tmpany_phold = bem_pop_0();
return bevt_0_tmpany_phold;
} /* Line: 96 */
bevt_1_tmpany_phold = bem_peek_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_push_1(beva_item);
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_topGetDirect_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerStack bem_topSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() throws Throwable {
return bevp_holder;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_holderGetDirect_0() throws Throwable {
return bevp_holder;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerStack bem_holderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ContainerStack bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {33, 39, 39, 40, 40, 41, 43, 44, 46, 46, 46, 47, 47, 48, 48, 49, 51, 53, 54, 58, 58, 59, 61, 62, 63, 63, 64, 66, 66, 67, 69, 70, 71, 72, 76, 76, 77, 79, 79, 83, 83, 87, 91, 91, 96, 96, 98, 98, 102, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 25, 30, 31, 36, 37, 40, 41, 45, 46, 51, 52, 53, 54, 55, 56, 59, 62, 63, 72, 77, 78, 80, 81, 82, 87, 88, 90, 95, 96, 98, 99, 100, 101, 106, 111, 112, 114, 115, 119, 124, 127, 132, 133, 139, 140, 142, 143, 146, 150, 153, 156, 160, 164, 167, 170, 174, 178, 181, 184, 188};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 33 15
new 0 33 15
assign 1 39 25
undef 1 39 30
assign 1 40 31
undef 1 40 36
assign 1 41 37
new 0 41 37
assign 1 43 40
assign 1 44 41
assign 1 46 45
nextGet 0 46 45
assign 1 46 46
undef 1 46 51
assign 1 47 52
new 0 47 52
nextSet 1 47 53
assign 1 48 54
nextGet 0 48 54
priorSet 1 48 55
assign 1 49 56
nextGet 0 49 56
assign 1 51 59
nextGet 0 51 59
heldSet 1 53 62
assign 1 54 63
increment 0 54 63
assign 1 58 72
undef 1 58 77
return 1 59 78
assign 1 61 80
assign 1 62 81
priorGet 0 62 81
assign 1 63 82
undef 1 63 87
assign 1 64 88
assign 1 66 90
undef 1 66 95
return 1 67 96
assign 1 69 98
heldGet 0 69 98
heldSet 1 70 99
assign 1 71 100
decrement 0 71 100
return 1 72 101
assign 1 76 106
undef 1 76 111
return 1 77 112
assign 1 79 114
heldGet 0 79 114
return 1 79 115
assign 1 83 119
undef 1 83 124
return 1 83 124
push 1 87 127
assign 1 91 132
pop 0 91 132
return 1 91 133
assign 1 96 139
pop 0 96 139
return 1 96 140
assign 1 98 142
peek 0 98 142
return 1 98 143
push 1 102 146
return 1 0 150
return 1 0 153
assign 1 0 156
assign 1 0 160
return 1 0 164
return 1 0 167
assign 1 0 170
assign 1 0 174
return 1 0 178
return 1 0 181
assign 1 0 184
assign 1 0 188
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1737862711: return bem_print_0();
case -2036442591: return bem_toAny_0();
case -1698643956: return bem_serializationIteratorGet_0();
case -178992645: return bem_deserializeClassNameGet_0();
case 239325412: return bem_copy_0();
case -99764025: return bem_sizeGet_0();
case -1187132797: return bem_hashGet_0();
case 1236768538: return bem_iteratorGet_0();
case 48520421: return bem_topGet_0();
case 396059776: return bem_tagGet_0();
case 592593417: return bem_peek_0();
case -1798562413: return bem_isEmptyGet_0();
case -1166158549: return bem_topGetDirect_0();
case 1319933824: return bem_classNameGet_0();
case 1616240746: return bem_toString_0();
case -980484092: return bem_new_0();
case -795764953: return bem_fieldIteratorGet_0();
case 1697432405: return bem_once_0();
case -324733615: return bem_serializeToString_0();
case 2077314506: return bem_many_0();
case 190062466: return bem_holderGetDirect_0();
case 854837664: return bem_create_0();
case -490858780: return bem_get_0();
case -761077510: return bem_sizeGetDirect_0();
case 1329439356: return bem_pop_0();
case 1486098436: return bem_fieldNamesGet_0();
case -803122581: return bem_holderGet_0();
case -760211542: return bem_sourceFileNameGet_0();
case -1159943693: return bem_echo_0();
case -604973932: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 286314538: return bem_holderSetDirect_1(bevd_0);
case 1021147088: return bem_otherClass_1(bevd_0);
case 1109276399: return bem_sameObject_1(bevd_0);
case 1784508277: return bem_undefined_1(bevd_0);
case -1716718522: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case -354650091: return bem_undef_1(bevd_0);
case -58601680: return bem_sameType_1(bevd_0);
case 1075750255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2132050261: return bem_sizeSetDirect_1(bevd_0);
case 1479379696: return bem_sameClass_1(bevd_0);
case 1311084563: return bem_push_1(bevd_0);
case -41663701: return bem_addValue_1(bevd_0);
case -373910674: return bem_holderSet_1(bevd_0);
case 486594455: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1097624238: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 962423408: return bem_def_1(bevd_0);
case -1754732193: return bem_notEquals_1(bevd_0);
case 215737112: return bem_otherType_1(bevd_0);
case -1022249919: return bem_sizeSet_1(bevd_0);
case 1747231477: return bem_topSet_1(bevd_0);
case -822613948: return bem_put_1(bevd_0);
case 1356068030: return bem_topSetDirect_1(bevd_0);
case -1120436550: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1229731165: return bem_copyTo_1(bevd_0);
case 850683733: return bem_equals_1(bevd_0);
case 395717057: return bem_defined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 602921151: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1012334348: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 661390803: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -434648658: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 192635884: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 103255187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 834345030: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerStack_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerStack_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerStack();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst = (BEC_2_9_5_ContainerStack) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_type;
}
}
