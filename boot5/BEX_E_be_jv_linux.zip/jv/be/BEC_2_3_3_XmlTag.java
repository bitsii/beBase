package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_3_XmlTag extends BEC_2_6_6_SystemObject {
public BEC_2_3_3_XmlTag() { }
private static byte[] becc_BEC_2_3_3_XmlTag_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67};
private static byte[] becc_BEC_2_3_3_XmlTag_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_3_XmlTag bece_BEC_2_3_3_XmlTag_bevs_inst;

public static BET_2_3_3_XmlTag bece_BEC_2_3_3_XmlTag_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 854837664: return bem_create_0();
case 239325412: return bem_copy_0();
case 1486098436: return bem_fieldNamesGet_0();
case 1616240746: return bem_toString_0();
case -760211542: return bem_sourceFileNameGet_0();
case -795764953: return bem_fieldIteratorGet_0();
case 1697432405: return bem_once_0();
case 1737862711: return bem_print_0();
case 1236768538: return bem_iteratorGet_0();
case -1187132797: return bem_hashGet_0();
case -2036442591: return bem_toAny_0();
case 1319933824: return bem_classNameGet_0();
case 396059776: return bem_tagGet_0();
case -178992645: return bem_deserializeClassNameGet_0();
case 2077314506: return bem_many_0();
case -604973932: return bem_serializeContents_0();
case -1159943693: return bem_echo_0();
case -324733615: return bem_serializeToString_0();
case -1698643956: return bem_serializationIteratorGet_0();
case -980484092: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 962423408: return bem_def_1(bevd_0);
case -1120436550: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1754732193: return bem_notEquals_1(bevd_0);
case 486594455: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 215737112: return bem_otherType_1(bevd_0);
case 1784508277: return bem_undefined_1(bevd_0);
case 395717057: return bem_defined_1(bevd_0);
case 1479379696: return bem_sameClass_1(bevd_0);
case 1229731165: return bem_copyTo_1(bevd_0);
case 1021147088: return bem_otherClass_1(bevd_0);
case 850683733: return bem_equals_1(bevd_0);
case -1097624238: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -58601680: return bem_sameType_1(bevd_0);
case 1075750255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1109276399: return bem_sameObject_1(bevd_0);
case -354650091: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 602921151: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1012334348: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 661390803: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -434648658: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 192635884: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 103255187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 834345030: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_3_3_XmlTag_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_3_XmlTag_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_3_XmlTag();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_3_XmlTag.bece_BEC_2_3_3_XmlTag_bevs_inst = (BEC_2_3_3_XmlTag) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_3_XmlTag.bece_BEC_2_3_3_XmlTag_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_3_XmlTag.bece_BEC_2_3_3_XmlTag_bevs_type;
}
}
