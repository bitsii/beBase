package be;
/* IO:File: source/extended/IdentityMap.be */
public class BEC_2_9_11_ContainerIdentitySet extends BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public BEC_2_9_11_ContainerIdentitySet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentitySet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {47, 47, 51, 52, 53, 54, 55, 56};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 47 13
new 0 47 13
new 1 47 14
assign 1 51 18
new 1 51 18
assign 1 52 19
assign 1 53 20
new 0 53 20
assign 1 54 21
new 0 54 21
assign 1 55 22
new 0 55 22
assign 1 56 23
new 0 56 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1800342769: return bem_nodesGet_0();
case -1893176165: return bem_multiGet_0();
case -1063105140: return bem_create_0();
case 1540145526: return bem_notEmptyGet_0();
case -994078049: return bem_moduGet_0();
case -484851105: return bem_setIteratorGet_0();
case -964376567: return bem_copy_0();
case -17851578: return bem_new_0();
case -430707096: return bem_bucketsGet_0();
case 1048216827: return bem_serializeToString_0();
case -816770678: return bem_relGet_0();
case 1703160154: return bem_isEmptyGet_0();
case 1397235532: return bem_clear_0();
case -673460716: return bem_innerPutAddedGet_0();
case 963265744: return bem_sizeGet_0();
case -1862849517: return bem_hashGet_0();
case -1544307906: return bem_tagGet_0();
case -1869109136: return bem_classNameGet_0();
case -1646180884: return bem_baseNodeGet_0();
case -279188987: return bem_serializationIteratorGet_0();
case -1406793129: return bem_print_0();
case 420705948: return bem_nodeIteratorGet_0();
case -1650622151: return bem_iteratorGet_0();
case 179660003: return bem_keysGet_0();
case -2087675581: return bem_keyIteratorGet_0();
case -1744447963: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -537465080: return bem_put_1(bevd_0);
case -699734903: return bem_innerPutAddedSet_1(bevd_0);
case -1175115655: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -431602363: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -716178647: return bem_bucketsSet_1(bevd_0);
case -1263350843: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 1764708193: return bem_copyTo_1(bevd_0);
case 371048183: return bem_notEquals_1(bevd_0);
case 1277442242: return bem_baseNodeSet_1(bevd_0);
case 725514738: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1561077498: return bem_has_1(bevd_0);
case -1463956748: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -153063440: return bem_relSet_1(bevd_0);
case 1522448151: return bem_moduSet_1(bevd_0);
case 336982361: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1832844782: return bem_sameObject_1(bevd_0);
case 689573322: return bem_equals_1(bevd_0);
case -637809794: return bem_multiSet_1(bevd_0);
case 1615283662: return bem_get_1(bevd_0);
case -495207452: return bem_sizeSet_1(bevd_0);
case -54815286: return bem_def_1(bevd_0);
case 1552025867: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1472504739: return bem_undef_1(bevd_0);
case -295442331: return bem_addValue_1(bevd_0);
case -1978736929: return bem_delete_1(bevd_0);
case -1492086420: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 988724429: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1178647801: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1650827610: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523546720: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1121134228: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1135788730: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1998052232: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(30, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_11_ContainerIdentitySet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
