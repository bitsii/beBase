package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerMapSerializationIterator extends BEC_3_9_3_16_ContainerMapKeyValueIterator {
public BEC_3_9_3_21_ContainerMapSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
public BEC_2_9_4_ContainerList bevp_contents;
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_contents = (new BEC_2_9_4_ContainerList()).bem_new_0();
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 579 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 579 */ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 579 */
 else  /* Line: 579 */ {
break;
} /* Line: 579 */
} /* Line: 579 */
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_postDeserialize_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_key = null;
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_map = (BEC_2_9_3_ContainerMap) bevp_set;
bevl_iter = bevp_contents.bem_iteratorGet_0();
while (true)
 /* Line: 587 */ {
bevt_0_tmpany_phold = bevl_iter.bemd_0(-1064390311);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 587 */ {
bevl_key = bevl_iter.bemd_0(-898026233);
bevl_value = bevl_iter.bemd_0(-898026233);
bevl_map.bem_put_2(bevl_key, bevl_value);
} /* Line: 590 */
 else  /* Line: 587 */ {
break;
} /* Line: 587 */
} /* Line: 587 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {569, 571, 575, 579, 579, 579, 580, 579, 585, 586, 587, 588, 589, 590, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 11, 15, 21, 24, 29, 30, 31, 45, 46, 49, 51, 52, 53, 62, 65};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 569 10
new 0 569 10
new 1 571 11
addValue 1 575 15
assign 1 579 21
new 0 579 21
assign 1 579 24
lesser 1 579 29
nextSet 1 580 30
assign 1 579 31
increment 0 579 31
assign 1 585 45
assign 1 586 46
iteratorGet 0 586 46
assign 1 587 49
hasNextGet 0 587 49
assign 1 588 51
nextGet 0 588 51
assign 1 589 52
nextGet 0 589 52
put 2 590 53
return 1 0 62
assign 1 0 65
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1823731495: return bem_fieldIteratorGet_0();
case 380917179: return bem_deserializeClassNameGet_0();
case 2007419844: return bem_sourceFileNameGet_0();
case -1997732490: return bem_serializeToString_0();
case -288603233: return bem_serializationIteratorGet_0();
case -486730947: return bem_tagGet_0();
case -495176641: return bem_slotsGet_0();
case -97188452: return bem_onNodeGet_0();
case -383401659: return bem_contentsGet_0();
case -953564551: return bem_containerGet_0();
case 89921707: return bem_echo_0();
case -898026233: return bem_nextGet_0();
case -200230494: return bem_postDeserialize_0();
case -2002314890: return bem_serializeContents_0();
case -706394436: return bem_classNameGet_0();
case -145517521: return bem_iteratorGet_0();
case -1064390311: return bem_hasNextGet_0();
case 991850509: return bem_hashGet_0();
case -438931987: return bem_many_0();
case -123202585: return bem_setGet_0();
case 903380622: return bem_copy_0();
case 192353495: return bem_toString_0();
case 221879372: return bem_nodeIteratorIteratorGet_0();
case -583561712: return bem_delete_0();
case -1727040626: return bem_currentGet_0();
case 1939405925: return bem_moduGet_0();
case 1071338406: return bem_once_0();
case 150815360: return bem_new_0();
case -610207516: return bem_print_0();
case 1733022581: return bem_create_0();
case 1222559837: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 568764092: return bem_equals_1(bevd_0);
case 220102166: return bem_nextSet_1(bevd_0);
case 1234343289: return bem_def_1(bevd_0);
case -174280441: return bem_otherClass_1(bevd_0);
case 571097192: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -2087149042: return bem_undefined_1(bevd_0);
case 698316509: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -177732522: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1027324025: return bem_setSet_1(bevd_0);
case 1519855800: return bem_contentsSet_1(bevd_0);
case 264973749: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1839028328: return bem_slotsSet_1(bevd_0);
case 754254864: return bem_sameType_1(bevd_0);
case 1641860349: return bem_onNodeSet_1(bevd_0);
case -226295549: return bem_sameClass_1(bevd_0);
case -907803894: return bem_otherType_1(bevd_0);
case -1587661946: return bem_sameObject_1(bevd_0);
case -43817363: return bem_currentSet_1(bevd_0);
case 1702402169: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2038181641: return bem_copyTo_1(bevd_0);
case -1886873191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1951248711: return bem_defined_1(bevd_0);
case -1794454226: return bem_undef_1(bevd_0);
case 1286019779: return bem_moduSet_1(bevd_0);
case -1812425724: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -862992684: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 608937217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1346377346: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1911273797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1789964230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2066895296: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1538374916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_21_ContainerMapSerializationIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerMapSerializationIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
}
}
