package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerMapSerializationIterator extends BEC_3_9_3_16_ContainerMapKeyValueIterator {
public BEC_3_9_3_21_ContainerMapSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;

public static BET_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_contents;
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_contents = (new BEC_2_9_4_ContainerList()).bem_new_0();
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 533*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 533*/ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 533*/
 else /* Line: 533*/ {
break;
} /* Line: 533*/
} /* Line: 533*/
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_postDeserialize_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_key = null;
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevl_map = (BEC_2_9_3_ContainerMap) bevp_set;
bevl_iter = bevp_contents.bem_iteratorGet_0();
while (true)
/* Line: 541*/ {
bevt_0_ta_ph = bevl_iter.bemd_0(-2042589148);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 541*/ {
bevl_key = bevl_iter.bemd_0(1451773420);
bevl_value = bevl_iter.bemd_0(1451773420);
bevl_map.bem_put_2(bevl_key, bevl_value);
} /* Line: 544*/
 else /* Line: 541*/ {
break;
} /* Line: 541*/
} /* Line: 541*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_contentsGetDirect_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {523, 525, 529, 533, 533, 533, 534, 533, 539, 540, 541, 542, 543, 544, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 24, 27, 32, 33, 34, 48, 49, 52, 54, 55, 56, 65, 68, 71, 75};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 523 13
new 0 523 13
new 1 525 14
addValue 1 529 18
assign 1 533 24
new 0 533 24
assign 1 533 27
lesser 1 533 32
nextSet 1 534 33
assign 1 533 34
increment 0 533 34
assign 1 539 48
assign 1 540 49
iteratorGet 0 540 49
assign 1 541 52
hasNextGet 0 541 52
assign 1 542 54
nextGet 0 542 54
assign 1 543 55
nextGet 0 543 55
put 2 544 56
return 1 0 65
return 1 0 68
assign 1 0 71
assign 1 0 75
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2042589148: return bem_hasNextGet_0();
case 1812616799: return bem_create_0();
case -281318932: return bem_delete_0();
case -688179613: return bem_moduGet_0();
case 2140998184: return bem_fieldNamesGet_0();
case 1451773420: return bem_nextGet_0();
case -1136648067: return bem_sourceFileNameGet_0();
case 1926375313: return bem_contentsGet_0();
case -1060683296: return bem_bucketsGetDirect_0();
case 2097612523: return bem_nodeIteratorIteratorGet_0();
case 780410149: return bem_containerGet_0();
case -362215698: return bem_toString_0();
case -705268334: return bem_currentGetDirect_0();
case 1773293529: return bem_hashGet_0();
case 1073013382: return bem_iteratorGet_0();
case 1129421696: return bem_onNodeGetDirect_0();
case -1910071780: return bem_setGet_0();
case 989732871: return bem_new_0();
case 1450956329: return bem_currentGet_0();
case 1617403869: return bem_onNodeGet_0();
case -1786334802: return bem_classNameGet_0();
case -1099552495: return bem_moduGetDirect_0();
case -433611414: return bem_postDeserialize_0();
case 436891861: return bem_contentsGetDirect_0();
case -2000436513: return bem_setGetDirect_0();
case 1298637733: return bem_bucketsGet_0();
case -777055641: return bem_copy_0();
case 1648346602: return bem_tagGet_0();
case 889719110: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1295257783: return bem_otherClass_1(bevd_0);
case -1190349180: return bem_contentsSetDirect_1(bevd_0);
case 319814146: return bem_sameClass_1(bevd_0);
case 1113058712: return bem_moduSet_1(bevd_0);
case 347835614: return bem_contentsSet_1(bevd_0);
case 754161535: return bem_equals_1(bevd_0);
case -897240707: return bem_currentSet_1(bevd_0);
case -514564367: return bem_onNodeSetDirect_1(bevd_0);
case -735593709: return bem_onNodeSet_1(bevd_0);
case -1652197750: return bem_currentSetDirect_1(bevd_0);
case 137331971: return bem_undef_1(bevd_0);
case -1764717463: return bem_notEquals_1(bevd_0);
case -1875172918: return bem_sameObject_1(bevd_0);
case -1910312720: return bem_nextSet_1(bevd_0);
case -42885212: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1978132891: return bem_copyTo_1(bevd_0);
case -1197299386: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 980301665: return bem_sameType_1(bevd_0);
case -930132980: return bem_def_1(bevd_0);
case -1326653655: return bem_bucketsSetDirect_1(bevd_0);
case -284342095: return bem_bucketsSet_1(bevd_0);
case 670840345: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -921303466: return bem_moduSetDirect_1(bevd_0);
case 1362742518: return bem_setSet_1(bevd_0);
case -583708652: return bem_otherType_1(bevd_0);
case -2027833110: return bem_setSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1681451114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450498968: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 831817632: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1805853509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1679839886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_21_ContainerMapSerializationIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerMapSerializationIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;
}
}
