package be;
/* IO:File: source/build/Pass9.be */
public final class BEC_3_5_5_5_BuildVisitPass9 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass9_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass9_bels_0, 44));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_2 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_3 = {0x47,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_4 = {0x70,0x75,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_5 = {0x67,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_6 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_7 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_8 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_9 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_10 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_11 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_12 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static BEC_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;

public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_5_4_BuildNode bevl_linn = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lany = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_23_ta_ph = null;
BEC_2_5_4_BuildNode bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_5_4_BuildNode bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_5_4_BuildNode bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_5_4_BuildNode bevt_45_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_5_4_BuildNode bevt_50_ta_ph = null;
BEC_2_5_4_BuildNode bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_5_4_BuildNode bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_5_4_LogicBool bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_5_4_BuildNode bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_5_4_BuildNode bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_BuildNode bevt_68_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_5_4_BuildNode bevt_73_ta_ph = null;
BEC_2_5_4_BuildNode bevt_74_ta_ph = null;
BEC_2_5_4_BuildNode bevt_75_ta_ph = null;
BEC_2_5_4_BuildNode bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_5_4_BuildNode bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_3_MathInt bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_6_6_SystemObject bevt_84_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_4_3_MathInt bevt_93_ta_ph = null;
BEC_2_4_3_MathInt bevt_94_ta_ph = null;
BEC_2_4_3_MathInt bevt_95_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_3_MathInt bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_3_MathInt bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_4_3_MathInt bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_4_3_MathInt bevt_109_ta_ph = null;
BEC_2_4_3_MathInt bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_3_MathInt bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_4_3_MathInt bevt_115_ta_ph = null;
BEC_2_4_3_MathInt bevt_116_ta_ph = null;
BEC_2_4_3_MathInt bevt_117_ta_ph = null;
BEC_2_4_3_MathInt bevt_118_ta_ph = null;
BEC_2_4_3_MathInt bevt_119_ta_ph = null;
BEC_2_5_4_LogicBool bevt_120_ta_ph = null;
BEC_2_6_6_SystemObject bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_6_6_SystemObject bevt_123_ta_ph = null;
BEC_2_4_6_TextString bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_3_MathInt bevt_126_ta_ph = null;
BEC_2_4_3_MathInt bevt_127_ta_ph = null;
BEC_2_4_3_MathInt bevt_128_ta_ph = null;
BEC_2_6_6_SystemObject bevt_129_ta_ph = null;
BEC_2_5_4_LogicBool bevt_130_ta_ph = null;
BEC_2_4_3_MathInt bevt_131_ta_ph = null;
BEC_2_4_3_MathInt bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_134_ta_ph = null;
BEC_2_6_6_SystemObject bevt_135_ta_ph = null;
BEC_2_6_6_SystemObject bevt_136_ta_ph = null;
BEC_2_6_6_SystemObject bevt_137_ta_ph = null;
BEC_2_4_3_MathInt bevt_138_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_139_ta_ph = null;
BEC_2_4_6_TextString bevt_140_ta_ph = null;
BEC_2_6_6_SystemObject bevt_141_ta_ph = null;
BEC_2_6_6_SystemObject bevt_142_ta_ph = null;
BEC_2_6_6_SystemObject bevt_143_ta_ph = null;
BEC_2_6_6_SystemObject bevt_144_ta_ph = null;
BEC_2_4_3_MathInt bevt_145_ta_ph = null;
BEC_2_4_3_MathInt bevt_146_ta_ph = null;
BEC_2_4_3_MathInt bevt_147_ta_ph = null;
BEC_2_5_4_LogicBool bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_6_6_SystemObject bevt_150_ta_ph = null;
BEC_2_4_3_MathInt bevt_151_ta_ph = null;
BEC_2_4_3_MathInt bevt_152_ta_ph = null;
BEC_2_4_3_MathInt bevt_153_ta_ph = null;
BEC_2_5_4_BuildNode bevt_154_ta_ph = null;
bevt_7_ta_ph = beva_node.bem_typenameGet_0();
bevt_8_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_7_ta_ph.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 30*/ {
beva_node.bem_initContained_0();
bevt_9_ta_ph = beva_node.bem_containedGet_0();
bevl_it = bevt_9_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 35*/ {
bevt_10_ta_ph = bevl_it.bemd_0(1590161492);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 35*/ {
bevl_i = bevl_it.bemd_0(-920607504);
bevt_12_ta_ph = bevl_i.bemd_0(1211584890);
bevt_13_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(1070255022, bevt_13_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 38*/ {
bevt_16_ta_ph = bevl_i.bemd_0(-1438444622);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-1025597706);
if (bevt_15_ta_ph == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 39*/ {
bevt_18_ta_ph = bevl_i.bemd_0(-1438444622);
bevt_17_ta_ph = bevt_18_ta_ph.bemd_0(554933596);
bevl_i.bemd_1(1075938230, bevt_17_ta_ph);
bevl_i.bemd_0(932712436);
} /* Line: 41*/
 else /* Line: 42*/ {
bevt_19_ta_ph = bece_BEC_3_5_5_5_BuildVisitPass9_bevo_0;
bevt_22_ta_ph = bevl_i.bemd_0(-1438444622);
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-741479880);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(-1392846471);
bevl_estr = bevt_19_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_23_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BECS_ThrowBack(bevt_23_ta_ph);
} /* Line: 44*/
} /* Line: 39*/
} /* Line: 38*/
 else /* Line: 35*/ {
break;
} /* Line: 35*/
} /* Line: 35*/
bevt_24_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_24_ta_ph;
} /* Line: 48*/
 else /* Line: 30*/ {
bevt_26_ta_ph = beva_node.bem_typenameGet_0();
bevt_27_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
if (bevt_26_ta_ph.bevi_int == bevt_27_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 49*/ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
bevl_c.bemd_1(1979239131, bevt_28_ta_ph);
bevt_31_ta_ph = beva_node.bem_containerGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_typenameGet_0();
bevt_32_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_ta_ph.bevi_int == bevt_32_ta_ph.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 56*/ {
bevt_36_ta_ph = beva_node.bem_containerGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_heldGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bemd_0(-1466994215);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevt_33_ta_ph = bevt_34_ta_ph.bemd_1(1070255022, bevt_37_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 56*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 56*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 56*/
 else /* Line: 56*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 56*/ {
bevt_38_ta_ph = beva_node.bem_isFirstGet_0();
if (bevt_38_ta_ph.bevi_bool)/* Line: 56*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 56*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 56*/
 else /* Line: 56*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 56*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_2));
bevl_c.bemd_1(2067755266, bevt_39_ta_ph);
} /* Line: 57*/
 else /* Line: 58*/ {
bevt_40_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_3));
bevl_c.bemd_1(2067755266, bevt_40_ta_ph);
} /* Line: 59*/
bevt_41_ta_ph = bevl_ac.bemd_0(-1466994215);
bevl_c.bemd_1(763343837, bevt_41_ta_ph);
bevl_c.bemd_0(-1302589878);
bevt_43_ta_ph = bevl_c.bemd_0(579067036);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_2));
bevt_42_ta_ph = bevt_43_ta_ph.bemd_1(1070255022, bevt_44_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 63*/ {
bevt_45_ta_ph = beva_node.bem_containerGet_0();
bevt_45_ta_ph.bem_heldSet_1(bevl_c);
bevt_46_ta_ph = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_46_ta_ph.bem_firstGet_0();
bevt_47_ta_ph = bevl_ntarg.bemd_0(1211584890);
beva_node.bem_typenameSet_1(bevt_47_ta_ph);
bevt_48_ta_ph = bevl_ntarg.bemd_0(662888175);
beva_node.bem_heldSet_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevl_ntarg.bemd_0(-1438444622);
beva_node.bem_containedSet_1(bevt_49_ta_ph);
bevt_51_ta_ph = beva_node.bem_containerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bem_nextDescendGet_0();
return bevt_50_ta_ph;
} /* Line: 70*/
 else /* Line: 71*/ {
bevt_52_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_52_ta_ph);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 73*/
bevt_53_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_53_ta_ph;
} /* Line: 75*/
 else /* Line: 30*/ {
bevt_55_ta_ph = beva_node.bem_typenameGet_0();
bevt_56_ta_ph = bevp_ntypes.bem_IDXACCGet_0();
if (bevt_55_ta_ph.bevi_int == bevt_56_ta_ph.bevi_int) {
bevt_54_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_54_ta_ph.bevi_bool)/* Line: 76*/ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_59_ta_ph = beva_node.bem_containerGet_0();
bevt_58_ta_ph = bevt_59_ta_ph.bem_typenameGet_0();
bevt_60_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_58_ta_ph.bevi_int == bevt_60_ta_ph.bevi_int) {
bevt_57_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_57_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_64_ta_ph = beva_node.bem_containerGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bem_heldGet_0();
bevt_62_ta_ph = bevt_63_ta_ph.bemd_0(-1466994215);
bevt_65_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevt_61_ta_ph = bevt_62_ta_ph.bemd_1(1070255022, bevt_65_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 80*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 80*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 80*/
 else /* Line: 80*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 80*/ {
bevt_66_ta_ph = beva_node.bem_isFirstGet_0();
if (bevt_66_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 80*/
 else /* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 80*/ {
bevl_isPut = be.BECS_Runtime.boolTrue;
} /* Line: 82*/
 else /* Line: 83*/ {
bevl_isPut = be.BECS_Runtime.boolFalse;
} /* Line: 85*/
if (((BEC_2_5_4_LogicBool) bevl_isPut).bevi_bool)/* Line: 87*/ {
bevt_67_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_4));
bevl_c.bemd_1(763343837, bevt_67_ta_ph);
bevt_68_ta_ph = beva_node.bem_containerGet_0();
bevt_68_ta_ph.bem_heldSet_1(bevl_c);
bevt_69_ta_ph = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_69_ta_ph.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(56981621);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_70_ta_ph = bevl_ntarg.bemd_0(1211584890);
beva_node.bem_typenameSet_1(bevt_70_ta_ph);
bevt_71_ta_ph = bevl_ntarg.bemd_0(662888175);
beva_node.bem_heldSet_1(bevt_71_ta_ph);
bevt_72_ta_ph = bevl_ntarg.bemd_0(-1438444622);
beva_node.bem_containedSet_1(bevt_72_ta_ph);
bevt_73_ta_ph = beva_node.bem_containerGet_0();
bevt_73_ta_ph.bem_addValue_1(bevl_narg2);
bevt_74_ta_ph = beva_node.bem_containerGet_0();
bevt_74_ta_ph.bem_addValue_1(bevl_narg3);
bevt_76_ta_ph = beva_node.bem_containerGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bem_nextDescendGet_0();
return bevt_75_ta_ph;
} /* Line: 105*/
 else /* Line: 106*/ {
bevt_77_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_5));
bevl_c.bemd_1(763343837, bevt_77_ta_ph);
bevt_78_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_78_ta_ph);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 113*/
bevt_79_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_79_ta_ph;
} /* Line: 115*/
} /* Line: 30*/
} /* Line: 30*/
bevt_81_ta_ph = beva_node.bem_typenameGet_0();
bevt_82_ta_ph = bevp_ntypes.bem_FORGet_0();
if (bevt_81_ta_ph.bevi_int == bevt_82_ta_ph.bevi_int) {
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 117*/ {
bevt_85_ta_ph = beva_node.bem_containedGet_0();
bevt_84_ta_ph = bevt_85_ta_ph.bem_firstGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bemd_0(-1438444622);
bevl_linn = (BEC_2_5_4_BuildNode) bevt_83_ta_ph.bemd_0(554933596);
bevt_87_ta_ph = bevl_linn.bem_typenameGet_0();
bevt_88_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_87_ta_ph.bevi_int == bevt_88_ta_ph.bevi_int) {
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 120*/ {
bevt_90_ta_ph = bevl_linn.bem_heldGet_0();
bevt_89_ta_ph = bevt_90_ta_ph.bemd_0(1644963333);
if (((BEC_2_5_4_LogicBool) bevt_89_ta_ph).bevi_bool)/* Line: 120*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 120*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 120*/
 else /* Line: 120*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 120*/ {
bevt_91_ta_ph = bevp_ntypes.bem_FOREACHGet_0();
beva_node.bem_typenameSet_1(bevt_91_ta_ph);
} /* Line: 122*/
} /* Line: 120*/
bevt_93_ta_ph = beva_node.bem_typenameGet_0();
bevt_94_ta_ph = bevp_ntypes.bem_FOREACHGet_0();
if (bevt_93_ta_ph.bevi_int == bevt_94_ta_ph.bevi_int) {
bevt_92_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_92_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_95_ta_ph = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_95_ta_ph);
bevt_96_ta_ph = beva_node.bem_containedGet_0();
bevl_pnode = bevt_96_ta_ph.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_97_ta_ph = bevl_pnode.bemd_0(-1438444622);
bevl_lin = bevt_97_ta_ph.bemd_0(554933596);
bevt_98_ta_ph = bevl_lin.bemd_0(-1438444622);
bevl_lany = bevt_98_ta_ph.bemd_0(554933596);
bevl_toit = bevl_lin.bemd_0(186274490);
bevl_pnode.bemd_1(-1851850205, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(482439382, beva_node);
bevt_99_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(244320927, bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass9_bels_6));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_100_ta_ph, bevp_build);
bevl_tmpn.bemd_1(799775502, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_101_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(244320927, bevt_101_ta_ph);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(799775502, bevl_gic);
bevt_102_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass9_bels_7));
bevl_gic.bemd_1(763343837, bevt_102_ta_ph);
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(716550668, bevt_103_ta_ph);
bevl_gin.bemd_1(-281877258, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(482439382, beva_node);
bevt_104_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(244320927, bevt_104_ta_ph);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(799775502, bevl_asc);
bevt_105_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevl_asc.bemd_1(763343837, bevt_105_ta_ph);
bevl_asn.bemd_1(-281877258, bevl_tmpn);
bevl_asn.bemd_1(-281877258, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn );
bevl_tmpn.bemd_0(-1467287139);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(482439382, beva_node);
bevt_106_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(244320927, bevt_106_ta_ph);
bevl_tmpnt.bemd_1(799775502, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(482439382, beva_node);
bevt_107_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(244320927, bevt_107_ta_ph);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(799775502, bevl_tcc);
bevt_108_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass9_bels_8));
bevl_tcc.bemd_1(763343837, bevt_108_ta_ph);
bevl_tcn.bemd_1(-281877258, bevl_tmpnt);
bevl_pnode.bemd_1(-281877258, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(482439382, beva_node);
bevt_109_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(244320927, bevt_109_ta_ph);
bevl_tmpng.bemd_1(799775502, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(482439382, beva_node);
bevt_110_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(244320927, bevt_110_ta_ph);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(799775502, bevl_iagc);
bevt_111_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass9_bels_9));
bevl_iagc.bemd_1(763343837, bevt_111_ta_ph);
bevl_iagn.bemd_1(-281877258, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(482439382, beva_node);
bevt_112_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(244320927, bevt_112_ta_ph);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(799775502, bevl_iasc);
bevt_113_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevl_iasc.bemd_1(763343837, bevt_113_ta_ph);
bevl_iasn.bemd_1(-281877258, bevl_lany);
bevl_iasn.bemd_1(-281877258, bevl_iagn);
bevl_brnode.bemd_1(-1749429796, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 215*/
bevt_115_ta_ph = beva_node.bem_typenameGet_0();
bevt_116_ta_ph = bevp_ntypes.bem_WHILEGet_0();
if (bevt_115_ta_ph.bevi_int == bevt_116_ta_ph.bevi_int) {
bevt_114_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_114_ta_ph.bevi_bool)/* Line: 217*/ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(482439382, beva_node);
bevt_117_ta_ph = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(244320927, bevt_117_ta_ph);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(482439382, beva_node);
bevt_118_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(244320927, bevt_118_ta_ph);
bevl_lnode.bemd_1(-281877258, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_119_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(244320927, bevt_119_ta_ph);
bevl_lbrnode.bemd_1(-281877258, bevl_loopif);
bevt_121_ta_ph = beva_node.bem_heldGet_0();
if (bevt_121_ta_ph == null) {
bevt_120_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_120_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_120_ta_ph.bevi_bool)/* Line: 229*/ {
bevt_123_ta_ph = beva_node.bem_heldGet_0();
bevt_124_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass9_bels_10));
bevt_122_ta_ph = bevt_123_ta_ph.bemd_1(1070255022, bevt_124_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_122_ta_ph).bevi_bool)/* Line: 229*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 229*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 229*/
 else /* Line: 229*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 229*/ {
bevt_125_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_11));
bevl_loopif.bemd_1(799775502, bevt_125_ta_ph);
} /* Line: 230*/
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(482439382, beva_node);
bevt_126_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(244320927, bevt_126_ta_ph);
bevl_loopif.bemd_1(-281877258, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(482439382, beva_node);
bevt_127_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(244320927, bevt_127_ta_ph);
bevl_enode.bemd_1(-281877258, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(482439382, beva_node);
bevt_128_ta_ph = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(244320927, bevt_128_ta_ph);
bevl_brnode.bemd_1(-281877258, bevl_bnode);
bevt_129_ta_ph = bevl_lnode.bemd_0(1049202990);
return (BEC_2_5_4_BuildNode) bevt_129_ta_ph;
} /* Line: 244*/
 else /* Line: 217*/ {
bevt_131_ta_ph = beva_node.bem_typenameGet_0();
bevt_132_ta_ph = bevp_ntypes.bem_FORGet_0();
if (bevt_131_ta_ph.bevi_int == bevt_132_ta_ph.bevi_int) {
bevt_130_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_130_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_130_ta_ph.bevi_bool)/* Line: 245*/ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(482439382, beva_node);
bevt_133_ta_ph = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(244320927, bevt_133_ta_ph);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevt_134_ta_ph = beva_node.bem_containedGet_0();
bevl_pnode = bevt_134_ta_ph.bem_firstGet_0();
bevl_pnode.bemd_0(932712436);
bevt_137_ta_ph = bevl_pnode.bemd_0(-1438444622);
bevt_136_ta_ph = bevt_137_ta_ph.bemd_0(-741479880);
bevt_138_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_135_ta_ph = bevt_136_ta_ph.bemd_1(-233635020, bevt_138_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_135_ta_ph).bevi_bool)/* Line: 252*/ {
bevt_140_ta_ph = (new BEC_2_4_6_TextString(55, bece_BEC_3_5_5_5_BuildVisitPass9_bels_12));
bevt_139_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_140_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_139_ta_ph);
} /* Line: 253*/
bevt_141_ta_ph = bevl_pnode.bemd_0(-1438444622);
bevl_init = bevt_141_ta_ph.bemd_0(554933596);
bevl_cond = bevl_pnode.bemd_0(186274490);
bevl_atStep = null;
bevt_144_ta_ph = bevl_pnode.bemd_0(-1438444622);
bevt_143_ta_ph = bevt_144_ta_ph.bemd_0(-741479880);
bevt_145_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_142_ta_ph = bevt_143_ta_ph.bemd_1(1251406995, bevt_145_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_142_ta_ph).bevi_bool)/* Line: 258*/ {
bevl_atStep = bevl_pnode.bemd_0(-578752618);
bevl_atStep.bemd_0(932712436);
} /* Line: 260*/
bevl_init.bemd_0(932712436);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lnode.bemd_1(1075938230, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(482439382, beva_node);
bevt_146_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(244320927, bevt_146_ta_ph);
bevl_lnode.bemd_1(-281877258, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(482439382, beva_node);
bevt_147_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(244320927, bevt_147_ta_ph);
bevl_loopif.bemd_1(-703881874, beva_node);
if (bevl_atStep == null) {
bevt_148_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_148_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_148_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_150_ta_ph = bevl_loopif.bemd_0(-1438444622);
bevt_149_ta_ph = bevt_150_ta_ph.bemd_0(554933596);
bevt_149_ta_ph.bemd_1(-281877258, bevl_atStep);
} /* Line: 276*/
bevl_loopif.bemd_1(-1749429796, bevl_pnode);
bevl_lbrnode.bemd_1(-281877258, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(482439382, beva_node);
bevt_151_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(244320927, bevt_151_ta_ph);
bevl_loopif.bemd_1(-281877258, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(482439382, beva_node);
bevt_152_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(244320927, bevt_152_ta_ph);
bevl_enode.bemd_1(-281877258, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(482439382, beva_node);
bevt_153_ta_ph = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(244320927, bevt_153_ta_ph);
bevl_brnode.bemd_1(-281877258, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 293*/
} /* Line: 217*/
bevt_154_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_154_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {30, 30, 30, 30, 34, 35, 35, 35, 37, 38, 38, 38, 39, 39, 39, 39, 40, 40, 40, 41, 43, 43, 43, 43, 43, 44, 44, 48, 48, 49, 49, 49, 49, 53, 54, 55, 55, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 0, 0, 0, 56, 0, 0, 0, 57, 57, 59, 59, 61, 61, 62, 63, 63, 63, 64, 64, 65, 65, 67, 67, 68, 68, 69, 69, 70, 70, 70, 72, 72, 73, 75, 75, 76, 76, 76, 76, 78, 79, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 0, 0, 0, 80, 0, 0, 0, 82, 85, 88, 88, 89, 89, 90, 90, 93, 94, 96, 97, 99, 99, 100, 100, 101, 101, 103, 103, 104, 104, 105, 105, 105, 111, 111, 112, 112, 113, 115, 115, 117, 117, 117, 117, 119, 119, 119, 119, 120, 120, 120, 120, 120, 120, 0, 0, 0, 122, 122, 125, 125, 125, 125, 126, 126, 127, 127, 128, 129, 129, 130, 130, 131, 132, 151, 152, 153, 153, 154, 154, 155, 157, 158, 158, 159, 160, 161, 161, 162, 162, 163, 165, 166, 167, 167, 168, 169, 170, 170, 171, 172, 174, 175, 177, 178, 179, 179, 180, 182, 183, 184, 184, 185, 186, 187, 187, 188, 190, 192, 193, 194, 194, 195, 197, 198, 199, 199, 200, 201, 202, 202, 203, 205, 206, 207, 207, 208, 209, 210, 210, 211, 212, 214, 215, 217, 217, 217, 217, 218, 219, 220, 220, 221, 222, 223, 224, 224, 225, 226, 227, 227, 228, 229, 229, 229, 229, 229, 229, 0, 0, 0, 230, 230, 232, 233, 234, 234, 235, 236, 237, 238, 238, 239, 240, 241, 242, 242, 243, 244, 244, 245, 245, 245, 245, 246, 247, 248, 248, 249, 250, 250, 251, 252, 252, 252, 252, 253, 253, 253, 255, 255, 256, 257, 258, 258, 258, 258, 259, 260, 262, 264, 265, 267, 268, 269, 269, 270, 271, 272, 273, 273, 274, 275, 275, 276, 276, 276, 278, 279, 280, 281, 282, 282, 283, 284, 285, 286, 286, 287, 288, 289, 290, 290, 291, 293, 295, 295};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {219, 220, 221, 226, 227, 228, 229, 232, 234, 235, 236, 237, 239, 240, 241, 246, 247, 248, 249, 250, 253, 254, 255, 256, 257, 258, 259, 267, 268, 271, 272, 273, 278, 279, 280, 281, 282, 283, 284, 285, 286, 291, 292, 293, 294, 295, 296, 298, 301, 305, 308, 310, 313, 317, 320, 321, 324, 325, 327, 328, 329, 330, 331, 332, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 349, 350, 351, 353, 354, 357, 358, 359, 364, 365, 366, 367, 368, 369, 370, 375, 376, 377, 378, 379, 380, 382, 385, 389, 392, 394, 397, 401, 404, 407, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 435, 436, 437, 438, 439, 441, 442, 446, 447, 448, 453, 454, 455, 456, 457, 458, 459, 460, 465, 466, 467, 469, 472, 476, 479, 480, 483, 484, 485, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 573, 574, 575, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 601, 602, 603, 604, 606, 609, 613, 616, 617, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 638, 639, 640, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 659, 660, 661, 663, 664, 665, 666, 667, 668, 669, 670, 672, 673, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 693, 694, 695, 696, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 718, 719};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 30 219
typenameGet 0 30 219
assign 1 30 220
CALLGet 0 30 220
assign 1 30 221
equals 1 30 226
initContained 0 34 227
assign 1 35 228
containedGet 0 35 228
assign 1 35 229
iteratorGet 0 35 229
assign 1 35 232
hasNextGet 0 35 232
assign 1 37 234
nextGet 0 37 234
assign 1 38 235
typenameGet 0 38 235
assign 1 38 236
PARENSGet 0 38 236
assign 1 38 237
equals 1 38 237
assign 1 39 239
containedGet 0 39 239
assign 1 39 240
firstNodeGet 0 39 240
assign 1 39 241
def 1 39 246
assign 1 40 247
containedGet 0 40 247
assign 1 40 248
firstGet 0 40 248
beforeInsert 1 40 249
delete 0 41 250
assign 1 43 253
new 0 43 253
assign 1 43 254
containedGet 0 43 254
assign 1 43 255
lengthGet 0 43 255
assign 1 43 256
toString 0 43 256
assign 1 43 257
add 1 43 257
assign 1 44 258
new 2 44 258
throw 1 44 259
assign 1 48 267
nextDescendGet 0 48 267
return 1 48 268
assign 1 49 271
typenameGet 0 49 271
assign 1 49 272
ACCESSORGet 0 49 272
assign 1 49 273
equals 1 49 278
assign 1 53 279
heldGet 0 53 279
assign 1 54 280
new 0 54 280
assign 1 55 281
new 0 55 281
wasAccessorSet 1 55 282
assign 1 56 283
containerGet 0 56 283
assign 1 56 284
typenameGet 0 56 284
assign 1 56 285
CALLGet 0 56 285
assign 1 56 286
equals 1 56 291
assign 1 56 292
containerGet 0 56 292
assign 1 56 293
heldGet 0 56 293
assign 1 56 294
nameGet 0 56 294
assign 1 56 295
new 0 56 295
assign 1 56 296
equals 1 56 296
assign 1 0 298
assign 1 0 301
assign 1 0 305
assign 1 56 308
isFirstGet 0 56 308
assign 1 0 310
assign 1 0 313
assign 1 0 317
assign 1 57 320
new 0 57 320
accessorTypeSet 1 57 321
assign 1 59 324
new 0 59 324
accessorTypeSet 1 59 325
assign 1 61 327
nameGet 0 61 327
nameSet 1 61 328
toAccessorName 0 62 329
assign 1 63 330
accessorTypeGet 0 63 330
assign 1 63 331
new 0 63 331
assign 1 63 332
equals 1 63 332
assign 1 64 334
containerGet 0 64 334
heldSet 1 64 335
assign 1 65 336
containedGet 0 65 336
assign 1 65 337
firstGet 0 65 337
assign 1 67 338
typenameGet 0 67 338
typenameSet 1 67 339
assign 1 68 340
heldGet 0 68 340
heldSet 1 68 341
assign 1 69 342
containedGet 0 69 342
containedSet 1 69 343
assign 1 70 344
containerGet 0 70 344
assign 1 70 345
nextDescendGet 0 70 345
return 1 70 346
assign 1 72 349
CALLGet 0 72 349
typenameSet 1 72 350
heldSet 1 73 351
assign 1 75 353
nextDescendGet 0 75 353
return 1 75 354
assign 1 76 357
typenameGet 0 76 357
assign 1 76 358
IDXACCGet 0 76 358
assign 1 76 359
equals 1 76 364
assign 1 78 365
heldGet 0 78 365
assign 1 79 366
new 0 79 366
assign 1 80 367
containerGet 0 80 367
assign 1 80 368
typenameGet 0 80 368
assign 1 80 369
CALLGet 0 80 369
assign 1 80 370
equals 1 80 375
assign 1 80 376
containerGet 0 80 376
assign 1 80 377
heldGet 0 80 377
assign 1 80 378
nameGet 0 80 378
assign 1 80 379
new 0 80 379
assign 1 80 380
equals 1 80 380
assign 1 0 382
assign 1 0 385
assign 1 0 389
assign 1 80 392
isFirstGet 0 80 392
assign 1 0 394
assign 1 0 397
assign 1 0 401
assign 1 82 404
new 0 82 404
assign 1 85 407
new 0 85 407
assign 1 88 410
new 0 88 410
nameSet 1 88 411
assign 1 89 412
containerGet 0 89 412
heldSet 1 89 413
assign 1 90 414
containedGet 0 90 414
assign 1 90 415
firstGet 0 90 415
assign 1 93 416
nextPeerGet 0 93 416
assign 1 94 417
nextPeerGet 0 94 417
delete 0 96 418
delete 0 97 419
assign 1 99 420
typenameGet 0 99 420
typenameSet 1 99 421
assign 1 100 422
heldGet 0 100 422
heldSet 1 100 423
assign 1 101 424
containedGet 0 101 424
containedSet 1 101 425
assign 1 103 426
containerGet 0 103 426
addValue 1 103 427
assign 1 104 428
containerGet 0 104 428
addValue 1 104 429
assign 1 105 430
containerGet 0 105 430
assign 1 105 431
nextDescendGet 0 105 431
return 1 105 432
assign 1 111 435
new 0 111 435
nameSet 1 111 436
assign 1 112 437
CALLGet 0 112 437
typenameSet 1 112 438
heldSet 1 113 439
assign 1 115 441
nextDescendGet 0 115 441
return 1 115 442
assign 1 117 446
typenameGet 0 117 446
assign 1 117 447
FORGet 0 117 447
assign 1 117 448
equals 1 117 453
assign 1 119 454
containedGet 0 119 454
assign 1 119 455
firstGet 0 119 455
assign 1 119 456
containedGet 0 119 456
assign 1 119 457
firstGet 0 119 457
assign 1 120 458
typenameGet 0 120 458
assign 1 120 459
CALLGet 0 120 459
assign 1 120 460
equals 1 120 465
assign 1 120 466
heldGet 0 120 466
assign 1 120 467
wasOperGet 0 120 467
assign 1 0 469
assign 1 0 472
assign 1 0 476
assign 1 122 479
FOREACHGet 0 122 479
typenameSet 1 122 480
assign 1 125 483
typenameGet 0 125 483
assign 1 125 484
FOREACHGet 0 125 484
assign 1 125 485
equals 1 125 490
assign 1 126 491
WHILEGet 0 126 491
typenameSet 1 126 492
assign 1 127 493
containedGet 0 127 493
assign 1 127 494
firstGet 0 127 494
assign 1 128 495
secondGet 0 128 495
assign 1 129 496
containedGet 0 129 496
assign 1 129 497
firstGet 0 129 497
assign 1 130 498
containedGet 0 130 498
assign 1 130 499
firstGet 0 130 499
assign 1 131 500
secondGet 0 131 500
containedSet 1 132 501
assign 1 151 502
new 1 151 502
copyLoc 1 152 503
assign 1 153 504
VARGet 0 153 504
typenameSet 1 153 505
assign 1 154 506
new 0 154 506
assign 1 154 507
tmpVar 2 154 507
heldSet 1 155 508
assign 1 157 509
new 1 157 509
assign 1 158 510
CALLGet 0 158 510
typenameSet 1 158 511
assign 1 159 512
new 0 159 512
heldSet 1 160 513
assign 1 161 514
new 0 161 514
nameSet 1 161 515
assign 1 162 516
new 0 162 516
wasForeachGennedSet 1 162 517
addValue 1 163 518
assign 1 165 519
new 1 165 519
copyLoc 1 166 520
assign 1 167 521
CALLGet 0 167 521
typenameSet 1 167 522
assign 1 168 523
new 0 168 523
heldSet 1 169 524
assign 1 170 525
new 0 170 525
nameSet 1 170 526
addValue 1 171 527
addValue 1 172 528
beforeInsert 1 174 529
addVariable 0 175 530
assign 1 177 531
new 1 177 531
copyLoc 1 178 532
assign 1 179 533
VARGet 0 179 533
typenameSet 1 179 534
heldSet 1 180 535
assign 1 182 536
new 1 182 536
copyLoc 1 183 537
assign 1 184 538
CALLGet 0 184 538
typenameSet 1 184 539
assign 1 185 540
new 0 185 540
heldSet 1 186 541
assign 1 187 542
new 0 187 542
nameSet 1 187 543
addValue 1 188 544
addValue 1 190 545
assign 1 192 546
new 1 192 546
copyLoc 1 193 547
assign 1 194 548
VARGet 0 194 548
typenameSet 1 194 549
heldSet 1 195 550
assign 1 197 551
new 1 197 551
copyLoc 1 198 552
assign 1 199 553
CALLGet 0 199 553
typenameSet 1 199 554
assign 1 200 555
new 0 200 555
heldSet 1 201 556
assign 1 202 557
new 0 202 557
nameSet 1 202 558
addValue 1 203 559
assign 1 205 560
new 1 205 560
copyLoc 1 206 561
assign 1 207 562
CALLGet 0 207 562
typenameSet 1 207 563
assign 1 208 564
new 0 208 564
heldSet 1 209 565
assign 1 210 566
new 0 210 566
nameSet 1 210 567
addValue 1 211 568
addValue 1 212 569
prepend 1 214 570
return 1 215 571
assign 1 217 573
typenameGet 0 217 573
assign 1 217 574
WHILEGet 0 217 574
assign 1 217 575
equals 1 217 580
assign 1 218 581
new 1 218 581
copyLoc 1 219 582
assign 1 220 583
LOOPGet 0 220 583
typenameSet 1 220 584
replaceWith 1 221 585
assign 1 222 586
new 1 222 586
copyLoc 1 223 587
assign 1 224 588
BRACESGet 0 224 588
typenameSet 1 224 589
addValue 1 225 590
assign 1 226 591
assign 1 227 592
IFGet 0 227 592
typenameSet 1 227 593
addValue 1 228 594
assign 1 229 595
heldGet 0 229 595
assign 1 229 596
def 1 229 601
assign 1 229 602
heldGet 0 229 602
assign 1 229 603
new 0 229 603
assign 1 229 604
equals 1 229 604
assign 1 0 606
assign 1 0 609
assign 1 0 613
assign 1 230 616
new 0 230 616
heldSet 1 230 617
assign 1 232 619
new 1 232 619
copyLoc 1 233 620
assign 1 234 621
ELSEGet 0 234 621
typenameSet 1 234 622
addValue 1 235 623
assign 1 236 624
new 1 236 624
copyLoc 1 237 625
assign 1 238 626
BRACESGet 0 238 626
typenameSet 1 238 627
addValue 1 239 628
assign 1 240 629
new 1 240 629
copyLoc 1 241 630
assign 1 242 631
BREAKGet 0 242 631
typenameSet 1 242 632
addValue 1 243 633
assign 1 244 634
nextDescendGet 0 244 634
return 1 244 635
assign 1 245 638
typenameGet 0 245 638
assign 1 245 639
FORGet 0 245 639
assign 1 245 640
equals 1 245 645
assign 1 246 646
new 1 246 646
copyLoc 1 247 647
assign 1 248 648
LOOPGet 0 248 648
typenameSet 1 248 649
replaceWith 1 249 650
assign 1 250 651
containedGet 0 250 651
assign 1 250 652
firstGet 0 250 652
delete 0 251 653
assign 1 252 654
containedGet 0 252 654
assign 1 252 655
lengthGet 0 252 655
assign 1 252 656
new 0 252 656
assign 1 252 657
lesser 1 252 657
assign 1 253 659
new 0 253 659
assign 1 253 660
new 2 253 660
throw 1 253 661
assign 1 255 663
containedGet 0 255 663
assign 1 255 664
firstGet 0 255 664
assign 1 256 665
secondGet 0 256 665
assign 1 257 666
assign 1 258 667
containedGet 0 258 667
assign 1 258 668
lengthGet 0 258 668
assign 1 258 669
new 0 258 669
assign 1 258 670
greater 1 258 670
assign 1 259 672
thirdGet 0 259 672
delete 0 260 673
delete 0 262 675
replaceWith 1 264 676
beforeInsert 1 265 677
assign 1 267 678
new 1 267 678
copyLoc 1 268 679
assign 1 269 680
BRACESGet 0 269 680
typenameSet 1 269 681
addValue 1 270 682
assign 1 271 683
new 1 271 683
copyLoc 1 272 684
assign 1 273 685
IFGet 0 273 685
typenameSet 1 273 686
takeContents 1 274 687
assign 1 275 688
def 1 275 693
assign 1 276 694
containedGet 0 276 694
assign 1 276 695
firstGet 0 276 695
addValue 1 276 696
prepend 1 278 698
addValue 1 279 699
assign 1 280 700
new 1 280 700
copyLoc 1 281 701
assign 1 282 702
ELSEGet 0 282 702
typenameSet 1 282 703
addValue 1 283 704
assign 1 284 705
new 1 284 705
copyLoc 1 285 706
assign 1 286 707
BRACESGet 0 286 707
typenameSet 1 286 708
addValue 1 287 709
assign 1 288 710
new 1 288 710
copyLoc 1 289 711
assign 1 290 712
BREAKGet 0 290 712
typenameSet 1 290 713
addValue 1 291 714
return 1 293 715
assign 1 295 718
nextDescendGet 0 295 718
return 1 295 719
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 310047227: return bem_fieldNamesGet_0();
case 221458969: return bem_serializeToString_0();
case 1970107535: return bem_buildGet_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 78412540: return bem_toAny_0();
case -1079456517: return bem_many_0();
case -992634121: return bem_tagGet_0();
case -1089967893: return bem_constGetDirect_0();
case -1238524057: return bem_print_0();
case -1851472893: return bem_once_0();
case -777537417: return bem_serializeContents_0();
case -1714583788: return bem_classNameGet_0();
case 205150354: return bem_new_0();
case 510614876: return bem_transGet_0();
case 672276188: return bem_ntypesGetDirect_0();
case -1331626162: return bem_iteratorGet_0();
case 217381802: return bem_serializationIteratorGet_0();
case 937983694: return bem_constGet_0();
case 814015164: return bem_copy_0();
case -153654110: return bem_buildGetDirect_0();
case -1395149456: return bem_transGetDirect_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -1392846471: return bem_toString_0();
case -438289515: return bem_fieldIteratorGet_0();
case -326464737: return bem_ntypesGet_0();
case -1426056679: return bem_hashGet_0();
case 993286746: return bem_echo_0();
case 137910263: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1940868841: return bem_end_1(bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case 1201355195: return bem_transSet_1(bevd_0);
case -2082250551: return bem_buildSetDirect_1(bevd_0);
case -1937725837: return bem_ntypesSetDirect_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 825562062: return bem_begin_1(bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 605643232: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 2028409201: return bem_transSetDirect_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case -2000955315: return bem_ntypesSet_1(bevd_0);
case -338272228: return bem_constSetDirect_1(bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case -330800921: return bem_constSet_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1951745260: return bem_buildSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass9_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass9_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst = (BEC_3_5_5_5_BuildVisitPass9) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;
}
}
