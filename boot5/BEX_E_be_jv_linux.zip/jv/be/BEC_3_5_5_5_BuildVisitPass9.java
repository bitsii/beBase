package be;
/* IO:File: source/build/Pass9.be */
public final class BEC_3_5_5_5_BuildVisitPass9 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass9_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass9_bels_0, 44));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_2 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_3 = {0x47,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_4 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_6 = {0x70,0x75,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_7 = {0x67,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_8 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_9 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_11 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_12 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_13 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_14 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_15 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_16 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static BEC_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;

public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_5_4_BuildNode bevl_linn = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lany = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_23_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_45_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_50_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_68_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_73_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_74_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_145_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_153_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_154_tmpany_phold = null;
bevt_7_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_8_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_7_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 31 */ {
beva_node.bem_initContained_0();
bevt_9_tmpany_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_9_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 36 */ {
bevt_10_tmpany_phold = bevl_it.bemd_0(1476711456);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 36 */ {
bevl_i = bevl_it.bemd_0(1759131101);
bevt_12_tmpany_phold = bevl_i.bemd_0(307810370);
bevt_13_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(-39094467, bevt_13_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 39 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(1327301284);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(605828515);
if (bevt_15_tmpany_phold == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(1327301284);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(-1473587806);
bevl_i.bemd_1(-377867458, bevt_17_tmpany_phold);
bevl_i.bemd_0(1174441688);
} /* Line: 42 */
 else  /* Line: 43 */ {
bevt_19_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass9_bevo_0;
bevt_22_tmpany_phold = bevl_i.bemd_0(1327301284);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(445133569);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-169510412);
bevl_estr = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BECS_ThrowBack(bevt_23_tmpany_phold);
} /* Line: 45 */
} /* Line: 40 */
} /* Line: 39 */
 else  /* Line: 36 */ {
break;
} /* Line: 36 */
} /* Line: 36 */
bevt_24_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_24_tmpany_phold;
} /* Line: 49 */
 else  /* Line: 31 */ {
bevt_26_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
if (bevt_26_tmpany_phold.bevi_int == bevt_27_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_c.bemd_1(1696079460, bevt_28_tmpany_phold);
bevt_31_tmpany_phold = beva_node.bem_containerGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_typenameGet_0();
bevt_32_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_tmpany_phold.bevi_int == bevt_32_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_36_tmpany_phold = beva_node.bem_containerGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_heldGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(-391498004);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_1(-39094467, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_38_tmpany_phold = beva_node.bem_isFirstGet_0();
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_2));
bevl_c.bemd_1(1673496547, bevt_39_tmpany_phold);
} /* Line: 58 */
 else  /* Line: 59 */ {
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_3));
bevl_c.bemd_1(1673496547, bevt_40_tmpany_phold);
} /* Line: 60 */
bevt_41_tmpany_phold = bevl_ac.bemd_0(-391498004);
bevl_c.bemd_1(-1708488168, bevt_41_tmpany_phold);
bevl_c.bemd_0(-1130663370);
bevt_43_tmpany_phold = bevl_c.bemd_0(1820701182);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_4));
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_1(-39094467, bevt_44_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 64 */ {
bevt_45_tmpany_phold = beva_node.bem_containerGet_0();
bevt_45_tmpany_phold.bem_heldSet_1(bevl_c);
bevt_46_tmpany_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_46_tmpany_phold.bem_firstGet_0();
bevt_47_tmpany_phold = bevl_ntarg.bemd_0(307810370);
beva_node.bem_typenameSet_1(bevt_47_tmpany_phold);
bevt_48_tmpany_phold = bevl_ntarg.bemd_0(45432222);
beva_node.bem_heldSet_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevl_ntarg.bemd_0(1327301284);
beva_node.bem_containedSet_1(bevt_49_tmpany_phold);
bevt_51_tmpany_phold = beva_node.bem_containerGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_nextDescendGet_0();
return bevt_50_tmpany_phold;
} /* Line: 71 */
 else  /* Line: 72 */ {
bevt_52_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_52_tmpany_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 74 */
bevt_53_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_53_tmpany_phold;
} /* Line: 76 */
 else  /* Line: 31 */ {
bevt_55_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_56_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
if (bevt_55_tmpany_phold.bevi_int == bevt_56_tmpany_phold.bevi_int) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_59_tmpany_phold = beva_node.bem_containerGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bem_typenameGet_0();
bevt_60_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_60_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_64_tmpany_phold = beva_node.bem_containerGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_heldGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(-391498004);
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_5));
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_1(-39094467, bevt_65_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_66_tmpany_phold = beva_node.bem_isFirstGet_0();
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevl_isPut = be.BECS_Runtime.boolTrue;
} /* Line: 83 */
 else  /* Line: 84 */ {
bevl_isPut = be.BECS_Runtime.boolFalse;
} /* Line: 86 */
if (((BEC_2_5_4_LogicBool) bevl_isPut).bevi_bool) /* Line: 88 */ {
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_6));
bevl_c.bemd_1(-1708488168, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = beva_node.bem_containerGet_0();
bevt_68_tmpany_phold.bem_heldSet_1(bevl_c);
bevt_69_tmpany_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_69_tmpany_phold.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(1158886910);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_70_tmpany_phold = bevl_ntarg.bemd_0(307810370);
beva_node.bem_typenameSet_1(bevt_70_tmpany_phold);
bevt_71_tmpany_phold = bevl_ntarg.bemd_0(45432222);
beva_node.bem_heldSet_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevl_ntarg.bemd_0(1327301284);
beva_node.bem_containedSet_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = beva_node.bem_containerGet_0();
bevt_73_tmpany_phold.bem_addValue_1(bevl_narg2);
bevt_74_tmpany_phold = beva_node.bem_containerGet_0();
bevt_74_tmpany_phold.bem_addValue_1(bevl_narg3);
bevt_76_tmpany_phold = beva_node.bem_containerGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_nextDescendGet_0();
return bevt_75_tmpany_phold;
} /* Line: 106 */
 else  /* Line: 107 */ {
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_7));
bevl_c.bemd_1(-1708488168, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_78_tmpany_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 114 */
bevt_79_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_79_tmpany_phold;
} /* Line: 116 */
} /* Line: 31 */
} /* Line: 31 */
bevt_81_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_82_tmpany_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_81_tmpany_phold.bevi_int == bevt_82_tmpany_phold.bevi_int) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_85_tmpany_phold = beva_node.bem_containedGet_0();
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bem_firstGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(1327301284);
bevl_linn = (BEC_2_5_4_BuildNode) bevt_83_tmpany_phold.bemd_0(-1473587806);
bevt_87_tmpany_phold = bevl_linn.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevt_90_tmpany_phold = bevl_linn.bem_heldGet_0();
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_0(2054902192);
if (((BEC_2_5_4_LogicBool) bevt_89_tmpany_phold).bevi_bool) /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 121 */ {
bevt_91_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
beva_node.bem_typenameSet_1(bevt_91_tmpany_phold);
} /* Line: 123 */
} /* Line: 121 */
bevt_93_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_94_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
if (bevt_93_tmpany_phold.bevi_int == bevt_94_tmpany_phold.bevi_int) {
bevt_92_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_95_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_96_tmpany_phold.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_97_tmpany_phold = bevl_pnode.bemd_0(1327301284);
bevl_lin = bevt_97_tmpany_phold.bemd_0(-1473587806);
bevt_98_tmpany_phold = bevl_lin.bemd_0(1327301284);
bevl_lany = bevt_98_tmpany_phold.bemd_0(-1473587806);
bevl_toit = bevl_lin.bemd_0(-22719834);
bevl_pnode.bemd_1(46727144, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(-1046948064, beva_node);
bevt_99_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(-2050682739, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass9_bels_8));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_100_tmpany_phold, bevp_build);
bevl_tmpn.bemd_1(963131562, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_101_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(-2050682739, bevt_101_tmpany_phold);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(963131562, bevl_gic);
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass9_bels_9));
bevl_gic.bemd_1(-1708488168, bevt_102_tmpany_phold);
bevt_103_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(2023437688, bevt_103_tmpany_phold);
bevl_gin.bemd_1(2043146996, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(-1046948064, beva_node);
bevt_104_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(-2050682739, bevt_104_tmpany_phold);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(963131562, bevl_asc);
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_10));
bevl_asc.bemd_1(-1708488168, bevt_105_tmpany_phold);
bevl_asn.bemd_1(2043146996, bevl_tmpn);
bevl_asn.bemd_1(2043146996, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn );
bevl_tmpn.bemd_0(-970389821);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(-1046948064, beva_node);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(-2050682739, bevt_106_tmpany_phold);
bevl_tmpnt.bemd_1(963131562, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(-1046948064, beva_node);
bevt_107_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(-2050682739, bevt_107_tmpany_phold);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(963131562, bevl_tcc);
bevt_108_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass9_bels_11));
bevl_tcc.bemd_1(-1708488168, bevt_108_tmpany_phold);
bevl_tcn.bemd_1(2043146996, bevl_tmpnt);
bevl_pnode.bemd_1(2043146996, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(-1046948064, beva_node);
bevt_109_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(-2050682739, bevt_109_tmpany_phold);
bevl_tmpng.bemd_1(963131562, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(-1046948064, beva_node);
bevt_110_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(-2050682739, bevt_110_tmpany_phold);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(963131562, bevl_iagc);
bevt_111_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass9_bels_12));
bevl_iagc.bemd_1(-1708488168, bevt_111_tmpany_phold);
bevl_iagn.bemd_1(2043146996, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(-1046948064, beva_node);
bevt_112_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(-2050682739, bevt_112_tmpany_phold);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(963131562, bevl_iasc);
bevt_113_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_13));
bevl_iasc.bemd_1(-1708488168, bevt_113_tmpany_phold);
bevl_iasn.bemd_1(2043146996, bevl_lany);
bevl_iasn.bemd_1(2043146996, bevl_iagn);
bevl_brnode.bemd_1(-797176517, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 216 */
bevt_115_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_116_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
if (bevt_115_tmpany_phold.bevi_int == bevt_116_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(-1046948064, beva_node);
bevt_117_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-2050682739, bevt_117_tmpany_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(-1046948064, beva_node);
bevt_118_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-2050682739, bevt_118_tmpany_phold);
bevl_lnode.bemd_1(2043146996, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_119_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-2050682739, bevt_119_tmpany_phold);
bevl_lbrnode.bemd_1(2043146996, bevl_loopif);
bevt_121_tmpany_phold = beva_node.bem_heldGet_0();
if (bevt_121_tmpany_phold == null) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_123_tmpany_phold = beva_node.bem_heldGet_0();
bevt_124_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass9_bels_14));
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(-39094467, bevt_124_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 230 */
 else  /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 230 */ {
bevt_125_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_15));
bevl_loopif.bemd_1(963131562, bevt_125_tmpany_phold);
} /* Line: 231 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(-1046948064, beva_node);
bevt_126_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2050682739, bevt_126_tmpany_phold);
bevl_loopif.bemd_1(2043146996, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(-1046948064, beva_node);
bevt_127_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2050682739, bevt_127_tmpany_phold);
bevl_enode.bemd_1(2043146996, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-1046948064, beva_node);
bevt_128_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-2050682739, bevt_128_tmpany_phold);
bevl_brnode.bemd_1(2043146996, bevl_bnode);
bevt_129_tmpany_phold = bevl_lnode.bemd_0(-1885871289);
return (BEC_2_5_4_BuildNode) bevt_129_tmpany_phold;
} /* Line: 245 */
 else  /* Line: 218 */ {
bevt_131_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_132_tmpany_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_131_tmpany_phold.bevi_int == bevt_132_tmpany_phold.bevi_int) {
bevt_130_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_130_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(-1046948064, beva_node);
bevt_133_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-2050682739, bevt_133_tmpany_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevt_134_tmpany_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_134_tmpany_phold.bem_firstGet_0();
bevl_pnode.bemd_0(1174441688);
bevt_137_tmpany_phold = bevl_pnode.bemd_0(1327301284);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(445133569);
bevt_138_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(-2109949123, bevt_138_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_135_tmpany_phold).bevi_bool) /* Line: 253 */ {
bevt_140_tmpany_phold = (new BEC_2_4_6_TextString(55, bece_BEC_3_5_5_5_BuildVisitPass9_bels_16));
bevt_139_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_140_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_139_tmpany_phold);
} /* Line: 254 */
bevt_141_tmpany_phold = bevl_pnode.bemd_0(1327301284);
bevl_init = bevt_141_tmpany_phold.bemd_0(-1473587806);
bevl_cond = bevl_pnode.bemd_0(-22719834);
bevl_atStep = null;
bevt_144_tmpany_phold = bevl_pnode.bemd_0(1327301284);
bevt_143_tmpany_phold = bevt_144_tmpany_phold.bemd_0(445133569);
bevt_145_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bemd_1(-1035913729, bevt_145_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_142_tmpany_phold).bevi_bool) /* Line: 259 */ {
bevl_atStep = bevl_pnode.bemd_0(-115068098);
bevl_atStep.bemd_0(1174441688);
} /* Line: 261 */
bevl_init.bemd_0(1174441688);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lnode.bemd_1(-377867458, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(-1046948064, beva_node);
bevt_146_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-2050682739, bevt_146_tmpany_phold);
bevl_lnode.bemd_1(2043146996, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(-1046948064, beva_node);
bevt_147_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-2050682739, bevt_147_tmpany_phold);
bevl_loopif.bemd_1(-1248382618, beva_node);
if (bevl_atStep == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_150_tmpany_phold = bevl_loopif.bemd_0(1327301284);
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_0(-1473587806);
bevt_149_tmpany_phold.bemd_1(2043146996, bevl_atStep);
} /* Line: 277 */
bevl_loopif.bemd_1(-797176517, bevl_pnode);
bevl_lbrnode.bemd_1(2043146996, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(-1046948064, beva_node);
bevt_151_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2050682739, bevt_151_tmpany_phold);
bevl_loopif.bemd_1(2043146996, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(-1046948064, beva_node);
bevt_152_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2050682739, bevt_152_tmpany_phold);
bevl_enode.bemd_1(2043146996, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-1046948064, beva_node);
bevt_153_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-2050682739, bevt_153_tmpany_phold);
bevl_brnode.bemd_1(2043146996, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 294 */
} /* Line: 218 */
bevt_154_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_154_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {31, 31, 31, 31, 35, 36, 36, 36, 38, 39, 39, 39, 40, 40, 40, 40, 41, 41, 41, 42, 44, 44, 44, 44, 44, 45, 45, 49, 49, 50, 50, 50, 50, 54, 55, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 0, 0, 0, 57, 0, 0, 0, 58, 58, 60, 60, 62, 62, 63, 64, 64, 64, 65, 65, 66, 66, 68, 68, 69, 69, 70, 70, 71, 71, 71, 73, 73, 74, 76, 76, 77, 77, 77, 77, 79, 80, 81, 81, 81, 81, 81, 81, 81, 81, 81, 81, 0, 0, 0, 81, 0, 0, 0, 83, 86, 89, 89, 90, 90, 91, 91, 94, 95, 97, 98, 100, 100, 101, 101, 102, 102, 104, 104, 105, 105, 106, 106, 106, 112, 112, 113, 113, 114, 116, 116, 118, 118, 118, 118, 120, 120, 120, 120, 121, 121, 121, 121, 121, 121, 0, 0, 0, 123, 123, 126, 126, 126, 126, 127, 127, 128, 128, 129, 130, 130, 131, 131, 132, 133, 152, 153, 154, 154, 155, 155, 156, 158, 159, 159, 160, 161, 162, 162, 163, 163, 164, 166, 167, 168, 168, 169, 170, 171, 171, 172, 173, 175, 176, 178, 179, 180, 180, 181, 183, 184, 185, 185, 186, 187, 188, 188, 189, 191, 193, 194, 195, 195, 196, 198, 199, 200, 200, 201, 202, 203, 203, 204, 206, 207, 208, 208, 209, 210, 211, 211, 212, 213, 215, 216, 218, 218, 218, 218, 219, 220, 221, 221, 222, 223, 224, 225, 225, 226, 227, 228, 228, 229, 230, 230, 230, 230, 230, 230, 0, 0, 0, 231, 231, 233, 234, 235, 235, 236, 237, 238, 239, 239, 240, 241, 242, 243, 243, 244, 245, 245, 246, 246, 246, 246, 247, 248, 249, 249, 250, 251, 251, 252, 253, 253, 253, 253, 254, 254, 254, 256, 256, 257, 258, 259, 259, 259, 259, 260, 261, 263, 265, 266, 268, 269, 270, 270, 271, 272, 273, 274, 274, 275, 276, 276, 277, 277, 277, 279, 280, 281, 282, 283, 283, 284, 285, 286, 287, 287, 288, 289, 290, 291, 291, 292, 294, 296, 296};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {223, 224, 225, 230, 231, 232, 233, 236, 238, 239, 240, 241, 243, 244, 245, 250, 251, 252, 253, 254, 257, 258, 259, 260, 261, 262, 263, 271, 272, 275, 276, 277, 282, 283, 284, 285, 286, 287, 288, 289, 290, 295, 296, 297, 298, 299, 300, 302, 305, 309, 312, 314, 317, 321, 324, 325, 328, 329, 331, 332, 333, 334, 335, 336, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 353, 354, 355, 357, 358, 361, 362, 363, 368, 369, 370, 371, 372, 373, 374, 379, 380, 381, 382, 383, 384, 386, 389, 393, 396, 398, 401, 405, 408, 411, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 439, 440, 441, 442, 443, 445, 446, 450, 451, 452, 457, 458, 459, 460, 461, 462, 463, 464, 469, 470, 471, 473, 476, 480, 483, 484, 487, 488, 489, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 577, 578, 579, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 605, 606, 607, 608, 610, 613, 617, 620, 621, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 642, 643, 644, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 663, 664, 665, 667, 668, 669, 670, 671, 672, 673, 674, 676, 677, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 697, 698, 699, 700, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 722, 723};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 31 223
typenameGet 0 31 223
assign 1 31 224
CALLGet 0 31 224
assign 1 31 225
equals 1 31 230
initContained 0 35 231
assign 1 36 232
containedGet 0 36 232
assign 1 36 233
iteratorGet 0 36 233
assign 1 36 236
hasNextGet 0 36 236
assign 1 38 238
nextGet 0 38 238
assign 1 39 239
typenameGet 0 39 239
assign 1 39 240
PARENSGet 0 39 240
assign 1 39 241
equals 1 39 241
assign 1 40 243
containedGet 0 40 243
assign 1 40 244
firstNodeGet 0 40 244
assign 1 40 245
def 1 40 250
assign 1 41 251
containedGet 0 41 251
assign 1 41 252
firstGet 0 41 252
beforeInsert 1 41 253
delete 0 42 254
assign 1 44 257
new 0 44 257
assign 1 44 258
containedGet 0 44 258
assign 1 44 259
lengthGet 0 44 259
assign 1 44 260
toString 0 44 260
assign 1 44 261
add 1 44 261
assign 1 45 262
new 2 45 262
throw 1 45 263
assign 1 49 271
nextDescendGet 0 49 271
return 1 49 272
assign 1 50 275
typenameGet 0 50 275
assign 1 50 276
ACCESSORGet 0 50 276
assign 1 50 277
equals 1 50 282
assign 1 54 283
heldGet 0 54 283
assign 1 55 284
new 0 55 284
assign 1 56 285
new 0 56 285
wasAccessorSet 1 56 286
assign 1 57 287
containerGet 0 57 287
assign 1 57 288
typenameGet 0 57 288
assign 1 57 289
CALLGet 0 57 289
assign 1 57 290
equals 1 57 295
assign 1 57 296
containerGet 0 57 296
assign 1 57 297
heldGet 0 57 297
assign 1 57 298
nameGet 0 57 298
assign 1 57 299
new 0 57 299
assign 1 57 300
equals 1 57 300
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 57 312
isFirstGet 0 57 312
assign 1 0 314
assign 1 0 317
assign 1 0 321
assign 1 58 324
new 0 58 324
accessorTypeSet 1 58 325
assign 1 60 328
new 0 60 328
accessorTypeSet 1 60 329
assign 1 62 331
nameGet 0 62 331
nameSet 1 62 332
toAccessorName 0 63 333
assign 1 64 334
accessorTypeGet 0 64 334
assign 1 64 335
new 0 64 335
assign 1 64 336
equals 1 64 336
assign 1 65 338
containerGet 0 65 338
heldSet 1 65 339
assign 1 66 340
containedGet 0 66 340
assign 1 66 341
firstGet 0 66 341
assign 1 68 342
typenameGet 0 68 342
typenameSet 1 68 343
assign 1 69 344
heldGet 0 69 344
heldSet 1 69 345
assign 1 70 346
containedGet 0 70 346
containedSet 1 70 347
assign 1 71 348
containerGet 0 71 348
assign 1 71 349
nextDescendGet 0 71 349
return 1 71 350
assign 1 73 353
CALLGet 0 73 353
typenameSet 1 73 354
heldSet 1 74 355
assign 1 76 357
nextDescendGet 0 76 357
return 1 76 358
assign 1 77 361
typenameGet 0 77 361
assign 1 77 362
IDXACCGet 0 77 362
assign 1 77 363
equals 1 77 368
assign 1 79 369
heldGet 0 79 369
assign 1 80 370
new 0 80 370
assign 1 81 371
containerGet 0 81 371
assign 1 81 372
typenameGet 0 81 372
assign 1 81 373
CALLGet 0 81 373
assign 1 81 374
equals 1 81 379
assign 1 81 380
containerGet 0 81 380
assign 1 81 381
heldGet 0 81 381
assign 1 81 382
nameGet 0 81 382
assign 1 81 383
new 0 81 383
assign 1 81 384
equals 1 81 384
assign 1 0 386
assign 1 0 389
assign 1 0 393
assign 1 81 396
isFirstGet 0 81 396
assign 1 0 398
assign 1 0 401
assign 1 0 405
assign 1 83 408
new 0 83 408
assign 1 86 411
new 0 86 411
assign 1 89 414
new 0 89 414
nameSet 1 89 415
assign 1 90 416
containerGet 0 90 416
heldSet 1 90 417
assign 1 91 418
containedGet 0 91 418
assign 1 91 419
firstGet 0 91 419
assign 1 94 420
nextPeerGet 0 94 420
assign 1 95 421
nextPeerGet 0 95 421
delete 0 97 422
delete 0 98 423
assign 1 100 424
typenameGet 0 100 424
typenameSet 1 100 425
assign 1 101 426
heldGet 0 101 426
heldSet 1 101 427
assign 1 102 428
containedGet 0 102 428
containedSet 1 102 429
assign 1 104 430
containerGet 0 104 430
addValue 1 104 431
assign 1 105 432
containerGet 0 105 432
addValue 1 105 433
assign 1 106 434
containerGet 0 106 434
assign 1 106 435
nextDescendGet 0 106 435
return 1 106 436
assign 1 112 439
new 0 112 439
nameSet 1 112 440
assign 1 113 441
CALLGet 0 113 441
typenameSet 1 113 442
heldSet 1 114 443
assign 1 116 445
nextDescendGet 0 116 445
return 1 116 446
assign 1 118 450
typenameGet 0 118 450
assign 1 118 451
FORGet 0 118 451
assign 1 118 452
equals 1 118 457
assign 1 120 458
containedGet 0 120 458
assign 1 120 459
firstGet 0 120 459
assign 1 120 460
containedGet 0 120 460
assign 1 120 461
firstGet 0 120 461
assign 1 121 462
typenameGet 0 121 462
assign 1 121 463
CALLGet 0 121 463
assign 1 121 464
equals 1 121 469
assign 1 121 470
heldGet 0 121 470
assign 1 121 471
wasOperGet 0 121 471
assign 1 0 473
assign 1 0 476
assign 1 0 480
assign 1 123 483
FOREACHGet 0 123 483
typenameSet 1 123 484
assign 1 126 487
typenameGet 0 126 487
assign 1 126 488
FOREACHGet 0 126 488
assign 1 126 489
equals 1 126 494
assign 1 127 495
WHILEGet 0 127 495
typenameSet 1 127 496
assign 1 128 497
containedGet 0 128 497
assign 1 128 498
firstGet 0 128 498
assign 1 129 499
secondGet 0 129 499
assign 1 130 500
containedGet 0 130 500
assign 1 130 501
firstGet 0 130 501
assign 1 131 502
containedGet 0 131 502
assign 1 131 503
firstGet 0 131 503
assign 1 132 504
secondGet 0 132 504
containedSet 1 133 505
assign 1 152 506
new 1 152 506
copyLoc 1 153 507
assign 1 154 508
VARGet 0 154 508
typenameSet 1 154 509
assign 1 155 510
new 0 155 510
assign 1 155 511
tmpVar 2 155 511
heldSet 1 156 512
assign 1 158 513
new 1 158 513
assign 1 159 514
CALLGet 0 159 514
typenameSet 1 159 515
assign 1 160 516
new 0 160 516
heldSet 1 161 517
assign 1 162 518
new 0 162 518
nameSet 1 162 519
assign 1 163 520
new 0 163 520
wasForeachGennedSet 1 163 521
addValue 1 164 522
assign 1 166 523
new 1 166 523
copyLoc 1 167 524
assign 1 168 525
CALLGet 0 168 525
typenameSet 1 168 526
assign 1 169 527
new 0 169 527
heldSet 1 170 528
assign 1 171 529
new 0 171 529
nameSet 1 171 530
addValue 1 172 531
addValue 1 173 532
beforeInsert 1 175 533
addVariable 0 176 534
assign 1 178 535
new 1 178 535
copyLoc 1 179 536
assign 1 180 537
VARGet 0 180 537
typenameSet 1 180 538
heldSet 1 181 539
assign 1 183 540
new 1 183 540
copyLoc 1 184 541
assign 1 185 542
CALLGet 0 185 542
typenameSet 1 185 543
assign 1 186 544
new 0 186 544
heldSet 1 187 545
assign 1 188 546
new 0 188 546
nameSet 1 188 547
addValue 1 189 548
addValue 1 191 549
assign 1 193 550
new 1 193 550
copyLoc 1 194 551
assign 1 195 552
VARGet 0 195 552
typenameSet 1 195 553
heldSet 1 196 554
assign 1 198 555
new 1 198 555
copyLoc 1 199 556
assign 1 200 557
CALLGet 0 200 557
typenameSet 1 200 558
assign 1 201 559
new 0 201 559
heldSet 1 202 560
assign 1 203 561
new 0 203 561
nameSet 1 203 562
addValue 1 204 563
assign 1 206 564
new 1 206 564
copyLoc 1 207 565
assign 1 208 566
CALLGet 0 208 566
typenameSet 1 208 567
assign 1 209 568
new 0 209 568
heldSet 1 210 569
assign 1 211 570
new 0 211 570
nameSet 1 211 571
addValue 1 212 572
addValue 1 213 573
prepend 1 215 574
return 1 216 575
assign 1 218 577
typenameGet 0 218 577
assign 1 218 578
WHILEGet 0 218 578
assign 1 218 579
equals 1 218 584
assign 1 219 585
new 1 219 585
copyLoc 1 220 586
assign 1 221 587
LOOPGet 0 221 587
typenameSet 1 221 588
replaceWith 1 222 589
assign 1 223 590
new 1 223 590
copyLoc 1 224 591
assign 1 225 592
BRACESGet 0 225 592
typenameSet 1 225 593
addValue 1 226 594
assign 1 227 595
assign 1 228 596
IFGet 0 228 596
typenameSet 1 228 597
addValue 1 229 598
assign 1 230 599
heldGet 0 230 599
assign 1 230 600
def 1 230 605
assign 1 230 606
heldGet 0 230 606
assign 1 230 607
new 0 230 607
assign 1 230 608
equals 1 230 608
assign 1 0 610
assign 1 0 613
assign 1 0 617
assign 1 231 620
new 0 231 620
heldSet 1 231 621
assign 1 233 623
new 1 233 623
copyLoc 1 234 624
assign 1 235 625
ELSEGet 0 235 625
typenameSet 1 235 626
addValue 1 236 627
assign 1 237 628
new 1 237 628
copyLoc 1 238 629
assign 1 239 630
BRACESGet 0 239 630
typenameSet 1 239 631
addValue 1 240 632
assign 1 241 633
new 1 241 633
copyLoc 1 242 634
assign 1 243 635
BREAKGet 0 243 635
typenameSet 1 243 636
addValue 1 244 637
assign 1 245 638
nextDescendGet 0 245 638
return 1 245 639
assign 1 246 642
typenameGet 0 246 642
assign 1 246 643
FORGet 0 246 643
assign 1 246 644
equals 1 246 649
assign 1 247 650
new 1 247 650
copyLoc 1 248 651
assign 1 249 652
LOOPGet 0 249 652
typenameSet 1 249 653
replaceWith 1 250 654
assign 1 251 655
containedGet 0 251 655
assign 1 251 656
firstGet 0 251 656
delete 0 252 657
assign 1 253 658
containedGet 0 253 658
assign 1 253 659
lengthGet 0 253 659
assign 1 253 660
new 0 253 660
assign 1 253 661
lesser 1 253 661
assign 1 254 663
new 0 254 663
assign 1 254 664
new 2 254 664
throw 1 254 665
assign 1 256 667
containedGet 0 256 667
assign 1 256 668
firstGet 0 256 668
assign 1 257 669
secondGet 0 257 669
assign 1 258 670
assign 1 259 671
containedGet 0 259 671
assign 1 259 672
lengthGet 0 259 672
assign 1 259 673
new 0 259 673
assign 1 259 674
greater 1 259 674
assign 1 260 676
thirdGet 0 260 676
delete 0 261 677
delete 0 263 679
replaceWith 1 265 680
beforeInsert 1 266 681
assign 1 268 682
new 1 268 682
copyLoc 1 269 683
assign 1 270 684
BRACESGet 0 270 684
typenameSet 1 270 685
addValue 1 271 686
assign 1 272 687
new 1 272 687
copyLoc 1 273 688
assign 1 274 689
IFGet 0 274 689
typenameSet 1 274 690
takeContents 1 275 691
assign 1 276 692
def 1 276 697
assign 1 277 698
containedGet 0 277 698
assign 1 277 699
firstGet 0 277 699
addValue 1 277 700
prepend 1 279 702
addValue 1 280 703
assign 1 281 704
new 1 281 704
copyLoc 1 282 705
assign 1 283 706
ELSEGet 0 283 706
typenameSet 1 283 707
addValue 1 284 708
assign 1 285 709
new 1 285 709
copyLoc 1 286 710
assign 1 287 711
BRACESGet 0 287 711
typenameSet 1 287 712
addValue 1 288 713
assign 1 289 714
new 1 289 714
copyLoc 1 290 715
assign 1 291 716
BREAKGet 0 291 716
typenameSet 1 291 717
addValue 1 292 718
return 1 294 719
assign 1 296 722
nextDescendGet 0 296 722
return 1 296 723
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1202859281: return bem_fieldIteratorGet_0();
case 1800213309: return bem_serializeContents_0();
case -169510412: return bem_toString_0();
case -458279913: return bem_serializationIteratorGet_0();
case 1166902012: return bem_print_0();
case 221369236: return bem_echo_0();
case -653168993: return bem_constGetDirect_0();
case 939185730: return bem_buildGet_0();
case -100814457: return bem_ntypesGetDirect_0();
case 1246209306: return bem_buildGetDirect_0();
case 737627600: return bem_classNameGet_0();
case -137209775: return bem_transGetDirect_0();
case -1627101286: return bem_many_0();
case -1721224705: return bem_copy_0();
case -1588608331: return bem_iteratorGet_0();
case -1760283647: return bem_sourceFileNameGet_0();
case -165877765: return bem_create_0();
case 586787044: return bem_toAny_0();
case 419402773: return bem_fieldNamesGet_0();
case -1145946037: return bem_serializeToString_0();
case -1200024888: return bem_tagGet_0();
case 1662643176: return bem_new_0();
case -353694220: return bem_constGet_0();
case -1855742442: return bem_deserializeClassNameGet_0();
case -2059713661: return bem_transGet_0();
case -4634496: return bem_once_0();
case -12708128: return bem_hashGet_0();
case 1054621592: return bem_ntypesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -39094467: return bem_equals_1(bevd_0);
case -327804541: return bem_sameClass_1(bevd_0);
case -883889211: return bem_sameObject_1(bevd_0);
case 445819062: return bem_transSet_1(bevd_0);
case -1058481552: return bem_undef_1(bevd_0);
case 1805860734: return bem_begin_1(bevd_0);
case -1166090576: return bem_transSetDirect_1(bevd_0);
case -1880368515: return bem_notEquals_1(bevd_0);
case -1617140536: return bem_defined_1(bevd_0);
case 1174135522: return bem_sameType_1(bevd_0);
case -2038137777: return bem_otherType_1(bevd_0);
case -409899450: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1370505311: return bem_ntypesSet_1(bevd_0);
case -1143294403: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -474283486: return bem_constSetDirect_1(bevd_0);
case 581506878: return bem_constSet_1(bevd_0);
case -2050626933: return bem_def_1(bevd_0);
case 286179063: return bem_copyTo_1(bevd_0);
case -1694968514: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -306633068: return bem_undefined_1(bevd_0);
case 192526423: return bem_ntypesSetDirect_1(bevd_0);
case 1209838081: return bem_buildSet_1(bevd_0);
case 1396328003: return bem_otherClass_1(bevd_0);
case 1725008072: return bem_buildSetDirect_1(bevd_0);
case 1039180755: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1116577203: return bem_end_1(bevd_0);
case -1475578133: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -549233499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853281410: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666962597: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1983260459: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -136430353: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2126382926: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1776809505: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass9_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass9_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst = (BEC_3_5_5_5_BuildVisitPass9) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;
}
}
