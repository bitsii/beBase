package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_12_XmlStartElement extends BEC_2_3_3_XmlTag {
public BEC_2_3_12_XmlStartElement() { }
private static byte[] becc_BEC_2_3_12_XmlStartElement_clname = {0x58,0x6D,0x6C,0x3A,0x53,0x74,0x61,0x72,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_12_XmlStartElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_1 = {0x20};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_2 = {0x3D};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_3 = {0x2F,0x3E};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_4 = {0x3E};
public static BEC_2_3_12_XmlStartElement bece_BEC_2_3_12_XmlStartElement_bevs_inst;

public static BET_2_3_12_XmlStartElement bece_BEC_2_3_12_XmlStartElement_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_6_TextString bevp_attName;
public BEC_2_9_3_ContainerMap bevp_attributes;
public BEC_2_3_12_XmlStartElement bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_addAttributeName_1(BEC_2_4_6_TextString beva_pname) throws Throwable {
bevp_attName = beva_pname;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_addAttributeValue_1(BEC_2_4_6_TextString beva_pval) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_attributes == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevp_attributes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 44 */
bevp_attributes.bem_put_2(bevp_attName, beva_pval);
bevp_attName = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_6_6_SystemObject bevl_entry = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_0));
bevt_1_tmpany_phold = bevl_accum.bem_addValue_1(bevt_2_tmpany_phold);
bevt_1_tmpany_phold.bem_addValue_1(bevp_name);
if (bevp_attributes == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_4_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_4_tmpany_phold.bem_quoteGet_0();
bevt_0_tmpany_loop = bevp_attributes.bem_mapIteratorGet_0();
while (true)
 /* Line: 55 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevl_entry = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_1));
bevt_10_tmpany_phold = bevl_accum.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevl_entry.bemd_0(-346134503);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_2));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevl_q);
bevt_14_tmpany_phold = bevl_entry.bemd_0(1341518531);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevl_q);
} /* Line: 56 */
 else  /* Line: 55 */ {
break;
} /* Line: 55 */
} /* Line: 55 */
} /* Line: 55 */
if (bevp_isClosed.bevi_bool) /* Line: 59 */ {
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_12_XmlStartElement_bels_3));
bevl_accum.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 60 */
 else  /* Line: 61 */ {
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_4));
bevl_accum.bem_addValue_1(bevt_16_tmpany_phold);
} /* Line: 62 */
bevt_17_tmpany_phold = bevl_accum.bem_extractString_0();
return bevt_17_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_12_XmlStartElement bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isClosedGetDirect_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_12_XmlStartElement bem_isClosedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_attNameGet_0() throws Throwable {
return bevp_attName;
} /*method end*/
public final BEC_2_4_6_TextString bem_attNameGetDirect_0() throws Throwable {
return bevp_attName;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_attNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_attName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_12_XmlStartElement bem_attNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_attName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_attributesGet_0() throws Throwable {
return bevp_attributes;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_attributesGetDirect_0() throws Throwable {
return bevp_attributes;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_attributesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_attributes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_12_XmlStartElement bem_attributesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_attributes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 43, 43, 44, 46, 47, 51, 52, 52, 52, 53, 53, 54, 54, 55, 0, 55, 55, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 60, 60, 62, 62, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 29, 34, 35, 37, 38, 63, 64, 65, 66, 67, 72, 73, 74, 75, 75, 78, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 98, 99, 102, 103, 105, 106, 109, 112, 115, 119, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 38 24
assign 1 43 29
undef 1 43 34
assign 1 44 35
new 0 44 35
put 2 46 37
assign 1 47 38
assign 1 51 63
new 0 51 63
assign 1 52 64
new 0 52 64
assign 1 52 65
addValue 1 52 65
addValue 1 52 66
assign 1 53 67
def 1 53 72
assign 1 54 73
new 0 54 73
assign 1 54 74
quoteGet 0 54 74
assign 1 55 75
mapIteratorGet 0 0 75
assign 1 55 78
hasNextGet 0 55 78
assign 1 55 80
nextGet 0 55 80
assign 1 56 81
new 0 56 81
assign 1 56 82
addValue 1 56 82
assign 1 56 83
keyGet 0 56 83
assign 1 56 84
addValue 1 56 84
assign 1 56 85
new 0 56 85
assign 1 56 86
addValue 1 56 86
assign 1 56 87
addValue 1 56 87
assign 1 56 88
valueGet 0 56 88
assign 1 56 89
addValue 1 56 89
addValue 1 56 90
assign 1 60 98
new 0 60 98
addValue 1 60 99
assign 1 62 102
new 0 62 102
addValue 1 62 103
assign 1 64 105
extractString 0 64 105
return 1 64 106
return 1 0 109
return 1 0 112
assign 1 0 115
assign 1 0 119
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1714302458: return bem_tagGet_0();
case 2087395772: return bem_print_0();
case 1780712404: return bem_toAny_0();
case 1309277187: return bem_serializationIteratorGet_0();
case 216516509: return bem_copy_0();
case -1792637857: return bem_isClosedGet_0();
case 1983730931: return bem_nameGet_0();
case 643429711: return bem_many_0();
case 1743479933: return bem_attributesGetDirect_0();
case -743672203: return bem_toString_0();
case 1466941499: return bem_fieldIteratorGet_0();
case -730850057: return bem_new_0();
case 535585918: return bem_echo_0();
case 1016157954: return bem_deserializeClassNameGet_0();
case -333666649: return bem_iteratorGet_0();
case -452381319: return bem_hashGet_0();
case 764172461: return bem_sourceFileNameGet_0();
case -1903112833: return bem_serializeContents_0();
case -184894195: return bem_create_0();
case -329859542: return bem_attributesGet_0();
case -1002865577: return bem_classNameGet_0();
case -1299412830: return bem_isClosedGetDirect_0();
case 1240742065: return bem_attNameGet_0();
case -749676617: return bem_serializeToString_0();
case 1951393559: return bem_once_0();
case -1650303600: return bem_nameGetDirect_0();
case 1810328254: return bem_fieldNamesGet_0();
case -676138749: return bem_attNameGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1190344604: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1938939824: return bem_sameType_1(bevd_0);
case 217750778: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1676656765: return bem_attNameSetDirect_1(bevd_0);
case 1522004802: return bem_otherClass_1(bevd_0);
case 842198181: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2034558972: return bem_attributesSetDirect_1(bevd_0);
case -1645106897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1637165965: return bem_nameSet_1(bevd_0);
case 871064141: return bem_attributesSet_1(bevd_0);
case 674985673: return bem_equals_1(bevd_0);
case -736784492: return bem_nameSetDirect_1(bevd_0);
case -557613368: return bem_sameClass_1(bevd_0);
case -536421745: return bem_def_1(bevd_0);
case 275261050: return bem_sameObject_1(bevd_0);
case -755558602: return bem_addAttributeValue_1((BEC_2_4_6_TextString) bevd_0);
case -1327170073: return bem_copyTo_1(bevd_0);
case -934538275: return bem_attNameSet_1(bevd_0);
case -1402559688: return bem_addAttributeName_1((BEC_2_4_6_TextString) bevd_0);
case 1803949676: return bem_isClosedSet_1(bevd_0);
case -1763815494: return bem_undef_1(bevd_0);
case 1426897534: return bem_notEquals_1(bevd_0);
case 732303652: return bem_undefined_1(bevd_0);
case 254544143: return bem_defined_1(bevd_0);
case 221919936: return bem_otherType_1(bevd_0);
case -2067184384: return bem_isClosedSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1213162260: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1183971462: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1639843562: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 758918507: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -36988574: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1804891568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1644786359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_3_12_XmlStartElement_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_12_XmlStartElement_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_12_XmlStartElement();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_inst = (BEC_2_3_12_XmlStartElement) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_type;
}
}
