package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_7_10_ReplaceStringStep extends BEC_2_6_6_SystemObject {
public BEC_2_7_10_ReplaceStringStep() { }
private static byte[] becc_BEC_2_7_10_ReplaceStringStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_10_ReplaceStringStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_7_10_ReplaceStringStep bece_BEC_2_7_10_ReplaceStringStep_bevs_inst;

public static BET_2_7_10_ReplaceStringStep bece_BEC_2_7_10_ReplaceStringStep_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_7_10_ReplaceStringStep bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_str = beva__str;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_7_10_ReplaceStringStep bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {46, 52, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 17, 20, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 46 13
return 1 52 17
return 1 0 20
assign 1 0 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1854351103: return bem_print_0();
case -1182108874: return bem_create_0();
case 1818335248: return bem_toString_0();
case 1704927424: return bem_new_0();
case 84237329: return bem_hashGet_0();
case -468392899: return bem_strGet_0();
case 1145598418: return bem_copy_0();
case 764459509: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1697701048: return bem_equals_1(bevd_0);
case 1782625331: return bem_notEquals_1(bevd_0);
case -1890824624: return bem_handle_1(bevd_0);
case 775180462: return bem_def_1(bevd_0);
case 1168283697: return bem_strSet_1(bevd_0);
case 854124491: return bem_print_1(bevd_0);
case -1601489182: return bem_copyTo_1(bevd_0);
case 1780152727: return bem_undef_1(bevd_0);
case -756911966: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1638131121: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 294957256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -997677553: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 91726751: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_7_10_ReplaceStringStep_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_10_ReplaceStringStep_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_7_10_ReplaceStringStep();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_inst = (BEC_2_7_10_ReplaceStringStep) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_type;
}
}
