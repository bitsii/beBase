package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerSetSerializationIterator extends BEC_3_9_3_11_ContainerSetKeyIterator {
public BEC_3_9_3_21_ContainerSetSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_21_ContainerSetSerializationIterator bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst;

public static BET_3_9_3_21_ContainerSetSerializationIterator bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_contents;
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_contents = (new BEC_2_9_4_ContainerList()).bem_new_0();
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 518*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 518*/ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 518*/
 else /* Line: 518*/ {
break;
} /* Line: 518*/
} /* Line: 518*/
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_postDeserialize_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_0_ta_loop = bevp_contents.bem_iteratorGet_0();
while (true)
/* Line: 524*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-510070775);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 524*/ {
bevl_value = bevt_0_ta_loop.bemd_0(1460352520);
bevp_set.bem_put_1(bevl_value);
} /* Line: 525*/
 else /* Line: 524*/ {
break;
} /* Line: 524*/
} /* Line: 524*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {508, 510, 514, 518, 518, 518, 519, 518, 524, 0, 524, 524, 525, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 24, 27, 32, 33, 34, 46, 46, 49, 51, 52, 61, 64};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 508 13
new 0 508 13
new 1 510 14
addValue 1 514 18
assign 1 518 24
new 0 518 24
assign 1 518 27
lesser 1 518 32
nextSet 1 519 33
incrementValue 0 518 34
assign 1 524 46
iteratorGet 0 0 46
assign 1 524 49
hasNextGet 0 524 49
assign 1 524 51
nextGet 0 524 51
put 1 525 52
return 1 0 61
assign 1 0 64
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 422595331: return bem_iteratorGet_0();
case -675794816: return bem_print_0();
case 1469284867: return bem_toString_0();
case 1460352520: return bem_nextGet_0();
case -76207973: return bem_postDeserialize_0();
case 2143908962: return bem_nodeIteratorIteratorGet_0();
case -2068980764: return bem_containerGet_0();
case 1781840756: return bem_contentsGet_0();
case 92270569: return bem_create_0();
case -510070775: return bem_hasNextGet_0();
case -1221115541: return bem_new_0();
case 1766635801: return bem_remove_0();
case 1171022339: return bem_copy_0();
case -618327675: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -39729582: return bem_notEquals_1(bevd_0);
case -1515236141: return bem_print_1(bevd_0);
case 188734671: return bem_nextSet_1(bevd_0);
case 737598852: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 192400507: return bem_copyTo_1(bevd_0);
case 1788132320: return bem_contentsSet_1(bevd_0);
case -1089103671: return bem_undef_1(bevd_0);
case 701760907: return bem_def_1(bevd_0);
case 935360108: return bem_equals_1(bevd_0);
case 1254674148: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 218804328: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1274504073: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1010736438: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1082406137: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_21_ContainerSetSerializationIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerSetSerializationIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_type;
}
}
