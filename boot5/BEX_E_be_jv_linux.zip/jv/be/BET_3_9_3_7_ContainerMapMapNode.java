package be;
public class BET_3_9_3_7_ContainerMapMapNode extends BETS_Object {
public BET_3_9_3_7_ContainerMapMapNode() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_3", "putTo_2", "getFrom_0", "hvalGet_0", "hvalSet_1", "keyGet_0", "keySet_1", "valueGet_0", "valueSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "hval", "key", "value" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_9_3_7_ContainerMapMapNode();
}
}
