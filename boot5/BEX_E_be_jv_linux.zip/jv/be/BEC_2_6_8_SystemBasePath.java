package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_ta_ph.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_split_1(bevp_separator);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_8_SystemBasePath bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_7_TextStrings bevt_9_ta_ph = null;
bevt_1_ta_ph = beva_other.bemd_0(931398777);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-92769717, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 103*/ {
bevt_4_ta_ph = bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_ta_ph;
} /* Line: 104*/
bevt_5_ta_ph = beva_other.bemd_0(1244609442);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 106*/ {
bevt_6_ta_ph = beva_other.bemd_0(-1174607422);
return (BEC_2_6_8_SystemBasePath) bevt_6_ta_ph;
} /* Line: 107*/
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_ta_ph = beva_other.bemd_0(931398777);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_ta_ph.bemd_1(993775820, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 111*/ {
bevt_8_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 111*/ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 113*/
 else /* Line: 111*/ {
break;
} /* Line: 111*/
} /* Line: 111*/
bevt_9_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_ta_ph.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = bem_copy_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_ta_ph);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 129*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 129*/ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_3_ta_ph = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_ta_ph);
} /* Line: 131*/
 else /* Line: 132*/ {
bevl_i.bem_nextGet_0();
} /* Line: 133*/
bevl_c = bevl_c.bem_increment_0();
} /* Line: 135*/
 else /* Line: 129*/ {
break;
} /* Line: 129*/
} /* Line: 129*/
bevt_4_ta_ph = bem_isAbsoluteGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 137*/ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 138*/
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (bevp_path == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_4_ta_ph = bevp_path.bem_toString_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_sizeGet_0();
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 144*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 144*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 144*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bevp_path.bem_getPoint_1(bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_equals_1(bevp_separator);
if (bevt_7_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 146*/
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 153*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_isAbsoluteGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 158*/ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 159*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_howMany.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 164*/ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 169*/ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 169*/ {
if (bevl_next == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 170*/ {
break;
} /* Line: 170*/
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 169*/
 else /* Line: 169*/ {
break;
} /* Line: 169*/
} /* Line: 169*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 175*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 187*/ {
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_ta_ph.bem_emptyGet_0();
} /* Line: 188*/
 else /* Line: 189*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevl_fp.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_ta_ph, bevt_4_ta_ph);
} /* Line: 190*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
/* Line: 196*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 196*/ {
bevt_1_ta_ph = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_ta_ph);
} /* Line: 197*/
 else /* Line: 196*/ {
break;
} /* Line: 196*/
} /* Line: 196*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_addStep_1(beva_step);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_split_1(bevp_separator);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_hashGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_x == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_3_ta_ph = beva_x.bemd_1(-1221623252, this);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_5_ta_ph = beva_x.bemd_0(931398777);
bevt_4_ta_ph = bevp_path.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 237*/
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_subPath_2(beva_start, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 248*/ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 249*/
 else /* Line: 250*/ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 251*/
bevl_res = bem_create_0();
bevl_res.bemd_1(993000101, bevp_separator);
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(1798820492, bevt_1_ta_ph);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public final BEC_2_4_6_TextString bem_separatorGetDirect_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_2_4_6_TextString bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {64, 64, 68, 69, 73, 77, 81, 81, 85, 86, 86, 87, 91, 91, 95, 95, 95, 99, 99, 99, 103, 103, 103, 103, 104, 104, 106, 107, 107, 109, 110, 110, 111, 111, 112, 113, 115, 115, 116, 117, 119, 123, 124, 125, 125, 126, 127, 128, 129, 129, 130, 130, 131, 131, 133, 135, 137, 138, 140, 144, 144, 0, 144, 144, 144, 144, 144, 0, 0, 144, 144, 145, 145, 145, 146, 146, 148, 148, 152, 153, 153, 153, 158, 158, 158, 159, 164, 164, 164, 165, 166, 168, 169, 169, 169, 170, 170, 171, 172, 173, 169, 175, 180, 181, 182, 186, 187, 187, 188, 188, 190, 190, 190, 190, 195, 196, 196, 197, 197, 199, 203, 203, 207, 208, 209, 210, 214, 215, 216, 216, 217, 221, 221, 225, 225, 229, 229, 229, 236, 236, 0, 236, 0, 0, 0, 236, 236, 0, 0, 237, 237, 239, 239, 243, 243, 247, 248, 248, 249, 251, 253, 254, 255, 255, 255, 256, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 23, 24, 28, 32, 36, 37, 43, 44, 45, 46, 50, 51, 56, 57, 58, 63, 64, 65, 84, 85, 86, 87, 89, 90, 92, 94, 95, 97, 98, 99, 100, 103, 105, 106, 112, 113, 114, 115, 116, 129, 130, 131, 132, 133, 134, 135, 136, 139, 141, 146, 147, 148, 151, 153, 159, 161, 163, 178, 183, 184, 187, 188, 189, 190, 195, 196, 199, 203, 204, 206, 207, 208, 210, 211, 213, 214, 220, 222, 223, 224, 231, 232, 237, 238, 251, 252, 257, 258, 259, 260, 261, 264, 269, 270, 275, 278, 279, 280, 281, 287, 293, 294, 295, 305, 306, 311, 312, 313, 316, 317, 318, 319, 328, 329, 332, 334, 335, 341, 346, 347, 351, 352, 353, 354, 360, 361, 362, 363, 364, 368, 369, 373, 374, 379, 380, 385, 396, 401, 402, 405, 407, 410, 414, 417, 418, 420, 423, 427, 428, 430, 431, 435, 436, 445, 446, 451, 452, 455, 457, 458, 459, 460, 461, 462, 465, 468, 471, 475, 479, 482, 485, 489};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 64 18
new 0 64 18
new 1 64 19
assign 1 68 23
new 0 68 23
fromString 1 69 24
assign 1 73 28
return 1 77 32
assign 1 81 36
toStringWithSeparator 1 81 36
return 1 81 37
assign 1 85 43
split 1 85 43
assign 1 86 44
new 0 86 44
assign 1 86 45
join 2 86 45
return 1 87 46
assign 1 91 50
split 1 91 50
return 1 91 51
assign 1 95 56
split 1 95 56
assign 1 95 57
firstGet 0 95 57
return 1 95 58
assign 1 99 63
split 1 99 63
assign 1 99 64
lastGet 0 99 64
return 1 99 65
assign 1 103 84
pathGet 0 103 84
assign 1 103 85
new 0 103 85
assign 1 103 86
emptyGet 0 103 86
assign 1 103 87
equals 1 103 87
assign 1 104 89
copy 0 104 89
return 1 104 90
assign 1 106 92
isAbsoluteGet 0 106 92
assign 1 107 94
copy 0 107 94
return 1 107 95
assign 1 109 97
split 1 109 97
assign 1 110 98
pathGet 0 110 98
assign 1 110 99
split 1 110 99
assign 1 111 100
linkedListIteratorGet 0 111 100
assign 1 111 103
hasNextGet 0 111 103
assign 1 112 105
nextGet 0 112 105
addValue 1 113 106
assign 1 115 112
new 0 115 112
assign 1 115 113
join 2 115 113
assign 1 116 114
copy 0 116 114
assign 1 117 115
fromString 1 117 115
return 1 119 116
assign 1 123 129
split 1 123 129
assign 1 124 130
copy 0 124 130
assign 1 125 131
new 0 125 131
pathSet 1 125 132
assign 1 126 133
lengthGet 0 126 133
assign 1 127 134
decrement 0 127 134
assign 1 128 135
new 0 128 135
assign 1 129 136
linkedListIteratorGet 0 129 136
assign 1 129 139
hasNextGet 0 129 139
assign 1 130 141
lesser 1 130 146
assign 1 131 147
nextGet 0 131 147
addStep 1 131 148
nextGet 0 133 151
assign 1 135 153
increment 0 135 153
assign 1 137 159
isAbsoluteGet 0 137 159
makeAbsolute 0 138 161
return 1 140 163
assign 1 144 178
undef 1 144 183
assign 1 0 184
assign 1 144 187
toString 0 144 187
assign 1 144 188
sizeGet 0 144 188
assign 1 144 189
new 0 144 189
assign 1 144 190
lesser 1 144 195
assign 1 0 196
assign 1 0 199
assign 1 144 203
new 0 144 203
return 1 144 204
assign 1 145 206
new 0 145 206
assign 1 145 207
getPoint 1 145 207
assign 1 145 208
equals 1 145 208
assign 1 146 210
new 0 146 210
return 1 146 211
assign 1 148 213
new 0 148 213
return 1 148 214
assign 1 152 220
isAbsoluteGet 0 152 220
assign 1 153 222
new 0 153 222
assign 1 153 223
sizeGet 0 153 223
assign 1 153 224
substring 2 153 224
assign 1 158 231
isAbsoluteGet 0 158 231
assign 1 158 232
not 0 158 237
assign 1 159 238
add 1 159 238
assign 1 164 251
new 0 164 251
assign 1 164 252
greater 1 164 257
makeNonAbsolute 0 165 258
assign 1 166 259
split 1 166 259
assign 1 168 260
firstNodeGet 0 168 260
assign 1 169 261
new 0 169 261
assign 1 169 264
lesser 1 169 269
assign 1 170 270
undef 1 170 275
assign 1 171 278
assign 1 172 279
nextGet 0 172 279
delete 0 173 280
assign 1 169 281
increment 0 169 281
assign 1 175 287
join 2 175 287
assign 1 180 293
split 1 180 293
addValue 1 181 294
assign 1 182 295
join 2 182 295
assign 1 186 305
find 1 186 305
assign 1 187 306
undef 1 187 311
assign 1 188 312
new 0 188 312
assign 1 188 313
emptyGet 0 188 313
assign 1 190 316
new 0 190 316
assign 1 190 317
add 1 190 317
assign 1 190 318
sizeGet 0 190 318
assign 1 190 319
substring 2 190 319
assign 1 195 328
split 1 195 328
assign 1 196 329
linkedListIteratorGet 0 196 329
assign 1 196 332
hasNextGet 0 196 332
assign 1 197 334
nextGet 0 197 334
addValue 1 197 335
assign 1 199 341
join 2 199 341
assign 1 203 346
addStep 1 203 346
return 1 203 347
assign 1 207 351
split 1 207 351
addValue 1 208 352
addValue 1 209 353
assign 1 210 354
join 2 210 354
assign 1 214 360
create 0 214 360
copyTo 1 215 361
assign 1 216 362
copy 0 216 362
pathSet 1 216 363
return 1 217 364
assign 1 221 368
split 1 221 368
return 1 221 369
assign 1 225 373
hashGet 0 225 373
return 1 225 374
assign 1 229 379
equals 1 229 379
assign 1 229 380
not 0 229 385
return 1 229 385
assign 1 236 396
undef 1 236 401
assign 1 0 402
assign 1 236 405
otherType 1 236 405
assign 1 0 407
assign 1 0 410
assign 1 0 414
assign 1 236 417
pathGet 0 236 417
assign 1 236 418
notEquals 1 236 418
assign 1 0 420
assign 1 0 423
assign 1 237 427
new 0 237 427
return 1 237 428
assign 1 239 430
new 0 239 430
return 1 239 431
assign 1 243 435
subPath 2 243 435
return 1 243 436
assign 1 247 445
stepsGet 0 247 445
assign 1 248 446
undef 1 248 451
assign 1 249 452
subList 1 249 452
assign 1 251 455
subList 2 251 455
assign 1 253 457
create 0 253 457
separatorSet 1 254 458
assign 1 255 459
new 0 255 459
assign 1 255 460
join 2 255 460
pathSet 1 255 461
return 1 256 462
return 1 0 465
return 1 0 468
assign 1 0 471
assign 1 0 475
return 1 0 479
return 1 0 482
assign 1 0 485
assign 1 0 489
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -309871334: return bem_stepsGet_0();
case 994310293: return bem_iteratorGet_0();
case -756746213: return bem_pathGetDirect_0();
case -1174607422: return bem_copy_0();
case -1745414938: return bem_create_0();
case -1707189732: return bem_firstStepGet_0();
case 793604836: return bem_lastStepGet_0();
case 496320790: return bem_separatorGetDirect_0();
case -1486280670: return bem_makeAbsolute_0();
case 1746766090: return bem_serializationIteratorGet_0();
case 1585982298: return bem_tagGet_0();
case 1525877846: return bem_print_0();
case 908835933: return bem_toString_0();
case 931398777: return bem_pathGet_0();
case 244887287: return bem_serializeContents_0();
case -694931040: return bem_new_0();
case 319006371: return bem_separatorGet_0();
case 2097107507: return bem_echo_0();
case 1849592327: return bem_hashGet_0();
case 1146130352: return bem_makeNonAbsolute_0();
case 331407827: return bem_stepListGet_0();
case 2139031452: return bem_fieldNamesGet_0();
case -2097292819: return bem_parentGet_0();
case -94649607: return bem_sourceFileNameGet_0();
case 525516580: return bem_classNameGet_0();
case 1244609442: return bem_isAbsoluteGet_0();
case 580970970: return bem_fieldIteratorGet_0();
case -1643625075: return bem_serializeToString_0();
case -120024387: return bem_deserializeClassNameGet_0();
case 1252830882: return bem_deleteFirstStep_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -237678495: return bem_copyTo_1(bevd_0);
case -1356856758: return bem_undef_1(bevd_0);
case -2131838887: return bem_otherClass_1(bevd_0);
case -1075838088: return bem_sameObject_1(bevd_0);
case 1924034709: return bem_addSteps_1(bevd_0);
case -1074890546: return bem_separatorSetDirect_1(bevd_0);
case 966148526: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1221623252: return bem_otherType_1(bevd_0);
case 1000772828: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1447476752: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -92769717: return bem_equals_1(bevd_0);
case 1798820492: return bem_pathSet_1(bevd_0);
case 714969984: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 475662844: return bem_pathSetDirect_1(bevd_0);
case 993000101: return bem_separatorSet_1(bevd_0);
case 276874254: return bem_add_1(bevd_0);
case -1547762287: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -267664827: return bem_def_1(bevd_0);
case -2072722375: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -427170859: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1492742291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 123587069: return bem_addStep_1(bevd_0);
case -822340900: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1007949557: return bem_sameType_1(bevd_0);
case 1023057084: return bem_notEquals_1(bevd_0);
case 124163544: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1631589040: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 305981104: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 358183541: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2075056348: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1364361583: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1189693355: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 202466082: return bem_addSteps_2(bevd_0, bevd_1);
case -1510805532: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
