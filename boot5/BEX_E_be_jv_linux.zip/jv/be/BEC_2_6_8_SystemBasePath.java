package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(1003383289);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-537932837, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 385 */ {
bevt_4_tmpany_phold = bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 386 */
bevt_5_tmpany_phold = beva_other.bemd_0(1077159770);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 388 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-245363326);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 389 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(1003383289);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(1301158157, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 393 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 395 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = bem_copy_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 411 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 411 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 413 */
 else  /* Line: 414 */ {
bevl_i.bem_nextGet_0();
} /* Line: 415 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 417 */
 else  /* Line: 411 */ {
break;
} /* Line: 411 */
} /* Line: 411 */
bevt_4_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 420 */
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 426 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 426 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 426 */
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 427 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 428 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 434 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 435 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 440 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 441 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 446 */ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 451 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 451 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 452 */ {
break;
} /* Line: 452 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 451 */
 else  /* Line: 451 */ {
break;
} /* Line: 451 */
} /* Line: 451 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 457 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 470 */
 else  /* Line: 471 */ {
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 472 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 478 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 479 */
 else  /* Line: 478 */ {
break;
} /* Line: 478 */
} /* Line: 478 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(-1674802050, this);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 518 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(1003383289);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 518 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 518 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 519 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 530 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 531 */
 else  /* Line: 532 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 533 */
bevl_res = bem_create_0();
bevl_res.bemd_1(-870454136, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(174296526, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public final BEC_2_4_6_TextString bem_separatorGetDirect_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_2_4_6_TextString bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {346, 346, 350, 351, 355, 359, 363, 363, 367, 368, 368, 369, 373, 373, 377, 377, 377, 381, 381, 381, 385, 385, 385, 385, 386, 386, 388, 389, 389, 391, 392, 392, 393, 393, 394, 395, 397, 397, 398, 399, 401, 405, 406, 407, 407, 408, 409, 410, 411, 411, 412, 412, 413, 413, 415, 417, 419, 420, 422, 426, 426, 0, 426, 426, 426, 426, 426, 0, 0, 426, 426, 427, 427, 427, 428, 428, 430, 430, 434, 435, 435, 435, 440, 440, 440, 441, 446, 446, 446, 447, 448, 450, 451, 451, 451, 452, 452, 453, 454, 455, 451, 457, 462, 463, 464, 468, 469, 469, 470, 470, 472, 472, 472, 472, 477, 478, 478, 479, 479, 481, 485, 485, 489, 490, 491, 492, 496, 497, 498, 498, 499, 503, 503, 507, 507, 511, 511, 511, 518, 518, 0, 518, 0, 0, 0, 518, 518, 0, 0, 519, 519, 521, 521, 525, 525, 529, 530, 530, 531, 533, 535, 536, 537, 537, 537, 538, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 28, 29, 33, 37, 41, 42, 48, 49, 50, 51, 55, 56, 61, 62, 63, 68, 69, 70, 89, 90, 91, 92, 94, 95, 97, 99, 100, 102, 103, 104, 105, 108, 110, 111, 117, 118, 119, 120, 121, 134, 135, 136, 137, 138, 139, 140, 141, 144, 146, 151, 152, 153, 156, 158, 164, 166, 168, 183, 188, 189, 192, 193, 194, 195, 200, 201, 204, 208, 209, 211, 212, 213, 215, 216, 218, 219, 225, 227, 228, 229, 236, 237, 242, 243, 256, 257, 262, 263, 264, 265, 266, 269, 274, 275, 280, 283, 284, 285, 286, 292, 298, 299, 300, 310, 311, 316, 317, 318, 321, 322, 323, 324, 333, 334, 337, 339, 340, 346, 351, 352, 356, 357, 358, 359, 365, 366, 367, 368, 369, 373, 374, 378, 379, 384, 385, 390, 401, 406, 407, 410, 412, 415, 419, 422, 423, 425, 428, 432, 433, 435, 436, 440, 441, 450, 451, 456, 457, 460, 462, 463, 464, 465, 466, 467, 470, 473, 476, 480, 484, 487, 490, 494};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 346 23
new 0 346 23
new 1 346 24
assign 1 350 28
new 0 350 28
fromString 1 351 29
assign 1 355 33
return 1 359 37
assign 1 363 41
toStringWithSeparator 1 363 41
return 1 363 42
assign 1 367 48
split 1 367 48
assign 1 368 49
new 0 368 49
assign 1 368 50
join 2 368 50
return 1 369 51
assign 1 373 55
split 1 373 55
return 1 373 56
assign 1 377 61
split 1 377 61
assign 1 377 62
firstGet 0 377 62
return 1 377 63
assign 1 381 68
split 1 381 68
assign 1 381 69
lastGet 0 381 69
return 1 381 70
assign 1 385 89
pathGet 0 385 89
assign 1 385 90
new 0 385 90
assign 1 385 91
emptyGet 0 385 91
assign 1 385 92
equals 1 385 92
assign 1 386 94
copy 0 386 94
return 1 386 95
assign 1 388 97
isAbsoluteGet 0 388 97
assign 1 389 99
copy 0 389 99
return 1 389 100
assign 1 391 102
split 1 391 102
assign 1 392 103
pathGet 0 392 103
assign 1 392 104
split 1 392 104
assign 1 393 105
linkedListIteratorGet 0 393 105
assign 1 393 108
hasNextGet 0 393 108
assign 1 394 110
nextGet 0 394 110
addValue 1 395 111
assign 1 397 117
new 0 397 117
assign 1 397 118
join 2 397 118
assign 1 398 119
copy 0 398 119
assign 1 399 120
fromString 1 399 120
return 1 401 121
assign 1 405 134
split 1 405 134
assign 1 406 135
copy 0 406 135
assign 1 407 136
new 0 407 136
pathSet 1 407 137
assign 1 408 138
lengthGet 0 408 138
assign 1 409 139
decrement 0 409 139
assign 1 410 140
new 0 410 140
assign 1 411 141
linkedListIteratorGet 0 411 141
assign 1 411 144
hasNextGet 0 411 144
assign 1 412 146
lesser 1 412 151
assign 1 413 152
nextGet 0 413 152
addStep 1 413 153
nextGet 0 415 156
assign 1 417 158
increment 0 417 158
assign 1 419 164
isAbsoluteGet 0 419 164
makeAbsolute 0 420 166
return 1 422 168
assign 1 426 183
undef 1 426 188
assign 1 0 189
assign 1 426 192
toString 0 426 192
assign 1 426 193
sizeGet 0 426 193
assign 1 426 194
new 0 426 194
assign 1 426 195
lesser 1 426 200
assign 1 0 201
assign 1 0 204
assign 1 426 208
new 0 426 208
return 1 426 209
assign 1 427 211
new 0 427 211
assign 1 427 212
getPoint 1 427 212
assign 1 427 213
equals 1 427 213
assign 1 428 215
new 0 428 215
return 1 428 216
assign 1 430 218
new 0 430 218
return 1 430 219
assign 1 434 225
isAbsoluteGet 0 434 225
assign 1 435 227
new 0 435 227
assign 1 435 228
sizeGet 0 435 228
assign 1 435 229
substring 2 435 229
assign 1 440 236
isAbsoluteGet 0 440 236
assign 1 440 237
not 0 440 242
assign 1 441 243
add 1 441 243
assign 1 446 256
new 0 446 256
assign 1 446 257
greater 1 446 262
makeNonAbsolute 0 447 263
assign 1 448 264
split 1 448 264
assign 1 450 265
firstNodeGet 0 450 265
assign 1 451 266
new 0 451 266
assign 1 451 269
lesser 1 451 274
assign 1 452 275
undef 1 452 280
assign 1 453 283
assign 1 454 284
nextGet 0 454 284
delete 0 455 285
assign 1 451 286
increment 0 451 286
assign 1 457 292
join 2 457 292
assign 1 462 298
split 1 462 298
addValue 1 463 299
assign 1 464 300
join 2 464 300
assign 1 468 310
find 1 468 310
assign 1 469 311
undef 1 469 316
assign 1 470 317
new 0 470 317
assign 1 470 318
emptyGet 0 470 318
assign 1 472 321
new 0 472 321
assign 1 472 322
add 1 472 322
assign 1 472 323
sizeGet 0 472 323
assign 1 472 324
substring 2 472 324
assign 1 477 333
split 1 477 333
assign 1 478 334
linkedListIteratorGet 0 478 334
assign 1 478 337
hasNextGet 0 478 337
assign 1 479 339
nextGet 0 479 339
addValue 1 479 340
assign 1 481 346
join 2 481 346
assign 1 485 351
addStep 1 485 351
return 1 485 352
assign 1 489 356
split 1 489 356
addValue 1 490 357
addValue 1 491 358
assign 1 492 359
join 2 492 359
assign 1 496 365
create 0 496 365
copyTo 1 497 366
assign 1 498 367
copy 0 498 367
pathSet 1 498 368
return 1 499 369
assign 1 503 373
split 1 503 373
return 1 503 374
assign 1 507 378
hashGet 0 507 378
return 1 507 379
assign 1 511 384
equals 1 511 384
assign 1 511 385
not 0 511 390
return 1 511 390
assign 1 518 401
undef 1 518 406
assign 1 0 407
assign 1 518 410
otherType 1 518 410
assign 1 0 412
assign 1 0 415
assign 1 0 419
assign 1 518 422
pathGet 0 518 422
assign 1 518 423
notEquals 1 518 423
assign 1 0 425
assign 1 0 428
assign 1 519 432
new 0 519 432
return 1 519 433
assign 1 521 435
new 0 521 435
return 1 521 436
assign 1 525 440
subPath 2 525 440
return 1 525 441
assign 1 529 450
stepsGet 0 529 450
assign 1 530 451
undef 1 530 456
assign 1 531 457
subList 1 531 457
assign 1 533 460
subList 2 533 460
assign 1 535 462
create 0 535 462
separatorSet 1 536 463
assign 1 537 464
new 0 537 464
assign 1 537 465
join 2 537 465
pathSet 1 537 466
return 1 538 467
return 1 0 470
return 1 0 473
assign 1 0 476
assign 1 0 480
return 1 0 484
return 1 0 487
assign 1 0 490
assign 1 0 494
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 212158951: return bem_separatorGet_0();
case 1299144778: return bem_parentGet_0();
case 1493113642: return bem_makeAbsolute_0();
case 695524618: return bem_pathGetDirect_0();
case -1400770094: return bem_many_0();
case -518710385: return bem_fieldNamesGet_0();
case -512236724: return bem_deserializeClassNameGet_0();
case 1496946357: return bem_stepsGet_0();
case 1003383289: return bem_pathGet_0();
case 1077159770: return bem_isAbsoluteGet_0();
case 245764926: return bem_separatorGetDirect_0();
case -2091241279: return bem_create_0();
case 1349866592: return bem_toString_0();
case 773968544: return bem_stepListGet_0();
case 1957608515: return bem_fieldIteratorGet_0();
case -1423578661: return bem_print_0();
case -923057320: return bem_serializationIteratorGet_0();
case -203445064: return bem_deleteFirstStep_0();
case 993759307: return bem_iteratorGet_0();
case -35248652: return bem_toAny_0();
case 1611526222: return bem_lastStepGet_0();
case 1299948053: return bem_serializeContents_0();
case 518862870: return bem_tagGet_0();
case -914347833: return bem_new_0();
case 646589914: return bem_sourceFileNameGet_0();
case -2035208893: return bem_echo_0();
case -943503141: return bem_makeNonAbsolute_0();
case 1052263558: return bem_serializeToString_0();
case 675566088: return bem_classNameGet_0();
case 13807179: return bem_hashGet_0();
case -1980748110: return bem_firstStepGet_0();
case 758802515: return bem_once_0();
case -245363326: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case -537932837: return bem_equals_1(bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 495742460: return bem_add_1(bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case 1487873090: return bem_pathSetDirect_1(bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -514817633: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case -1249666727: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case 1164916619: return bem_separatorSetDirect_1(bevd_0);
case -870454136: return bem_separatorSet_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case 2096866289: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 1024933686: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 1449061805: return bem_addSteps_1(bevd_0);
case -340377293: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1671925906: return bem_addStep_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case 543791744: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 174296526: return bem_pathSet_1(bevd_0);
case -1207319860: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -194294618: return bem_addSteps_2(bevd_0, bevd_1);
case -448458373: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
