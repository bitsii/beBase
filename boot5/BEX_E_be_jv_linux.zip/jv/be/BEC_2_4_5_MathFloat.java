package be;
/* IO:File: source/base/Float.be */
public final class BEC_2_4_5_MathFloat extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_3 = (new BEC_2_4_3_MathInt(10));
private static byte[] bece_BEC_2_4_5_MathFloat_bels_2 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_4_5_MathFloat_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_4_5_MathFloat_bels_2, 1));
public static BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) throws Throwable {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_21_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_22_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_tmpany_phold = beva_si.bemd_1(-1942107417, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevl_neg = be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(1378510035, bevt_2_tmpany_phold);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_neg = be.BECS_Runtime.boolFalse;
} /* Line: 61 */
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(229705627, bevt_3_tmpany_phold);
if (bevl_dec == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 64 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_0;
if (bevl_dec.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 65 */ {
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_7_tmpany_phold = beva_si.bemd_2(1384070262, bevt_8_tmpany_phold, bevl_dec);
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_tmpany_phold);
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_lhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 68 */
bevt_11_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_1;
bevt_10_tmpany_phold = bevl_dec.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = beva_si.bemd_0(1524018105);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_tmpany_phold );
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 70 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_2;
bevt_14_tmpany_phold = bevl_dec.bem_add_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = beva_si.bemd_1(1378510035, bevt_14_tmpany_phold);
bevl_rhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_tmpany_phold);
} /* Line: 71 */
 else  /* Line: 72 */ {
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 73 */
} /* Line: 70 */
 else  /* Line: 75 */ {
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 77 */
bevt_16_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_3;
bevt_18_tmpany_phold = bevl_rhs.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_sizeGet_0();
bevl_divby = bevt_16_tmpany_phold.bem_power_1(bevt_17_tmpany_phold);
if (bevl_neg.bevi_bool) /* Line: 80 */ {
bevt_19_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_tmpany_phold);
} /* Line: 82 */
bevt_21_tmpany_phold = bevl_rhs.bem_toFloat_0();
bevt_22_tmpany_phold = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_tmpany_phold.bem_divide_1(bevt_22_tmpany_phold);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_create_0() throws Throwable {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_4_5_MathFloat) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toInt_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_lhi = bem_toInt_0();
bevt_0_tmpany_phold = bevl_lhi.bem_toFloat_0();
bevl_rh = bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_tmpany_phold);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_tmpany_phold = bevl_lhi.bem_toString_0();
bevt_5_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_4;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevl_rhi.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 137 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 144 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 152 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 159 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 167 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 174 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 182 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 189 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 197 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 204 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 212 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 219 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float == ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float != ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {57, 57, 58, 59, 59, 61, 63, 63, 64, 64, 65, 65, 65, 66, 66, 66, 68, 70, 70, 70, 70, 71, 71, 71, 71, 73, 76, 77, 79, 79, 79, 79, 81, 81, 82, 82, 84, 84, 84, 85, 86, 87, 90, 90, 93, 93, 97, 101, 101, 112, 120, 125, 125, 129, 130, 130, 131, 131, 132, 133, 133, 133, 133, 133, 133, 138, 144, 153, 159, 168, 174, 183, 189, 198, 204, 213, 219, 227, 227, 256, 256, 285, 285, 306, 306, 327, 327, 348, 348, 369, 369};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {65, 66, 68, 69, 70, 73, 75, 76, 77, 82, 83, 84, 89, 90, 91, 92, 95, 97, 98, 99, 100, 102, 103, 104, 105, 108, 112, 113, 115, 116, 117, 118, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 134, 135, 139, 140, 143, 148, 149, 153, 154, 158, 159, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 189, 192, 199, 202, 209, 212, 219, 222, 229, 232, 239, 242, 247, 248, 257, 258, 267, 268, 277, 278, 287, 288, 297, 298, 307, 308};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 57 65
new 0 57 65
assign 1 57 66
begins 1 57 66
assign 1 58 68
new 0 58 68
assign 1 59 69
new 0 59 69
assign 1 59 70
substring 1 59 70
assign 1 61 73
new 0 61 73
assign 1 63 75
new 0 63 75
assign 1 63 76
find 1 63 76
assign 1 64 77
def 1 64 82
assign 1 65 83
new 0 65 83
assign 1 65 84
greater 1 65 89
assign 1 66 90
new 0 66 90
assign 1 66 91
substring 2 66 91
assign 1 66 92
new 1 66 92
assign 1 68 95
new 0 68 95
assign 1 70 97
new 0 70 97
assign 1 70 98
add 1 70 98
assign 1 70 99
sizeGet 0 70 99
assign 1 70 100
lesser 1 70 100
assign 1 71 102
new 0 71 102
assign 1 71 103
add 1 71 103
assign 1 71 104
substring 1 71 104
assign 1 71 105
new 1 71 105
assign 1 73 108
new 0 73 108
assign 1 76 112
new 1 76 112
assign 1 77 113
new 0 77 113
assign 1 79 115
new 0 79 115
assign 1 79 116
toString 0 79 116
assign 1 79 117
sizeGet 0 79 117
assign 1 79 118
power 1 79 118
assign 1 81 120
new 0 81 120
multiplyValue 1 81 121
assign 1 82 122
new 0 82 122
multiplyValue 1 82 123
assign 1 84 125
toFloat 0 84 125
assign 1 84 126
toFloat 0 84 126
assign 1 84 127
divide 1 84 127
assign 1 85 128
toFloat 0 85 128
assign 1 86 129
add 1 86 129
return 1 87 130
assign 1 90 134
new 0 90 134
return 1 90 135
assign 1 93 139
toString 0 93 139
return 1 93 140
new 1 97 143
assign 1 101 148
new 0 101 148
return 1 101 149
assign 1 112 153
new 0 112 153
return 1 120 154
assign 1 125 158
toInt 0 125 158
return 1 125 159
assign 1 129 172
toInt 0 129 172
assign 1 130 173
toFloat 0 130 173
assign 1 130 174
subtract 1 130 174
assign 1 131 175
new 0 131 175
assign 1 131 176
multiply 1 131 176
assign 1 132 177
toInt 0 132 177
assign 1 133 178
toString 0 133 178
assign 1 133 179
new 0 133 179
assign 1 133 180
add 1 133 180
assign 1 133 181
toString 0 133 181
assign 1 133 182
add 1 133 182
return 1 133 183
assign 1 138 189
new 0 138 189
return 1 144 192
assign 1 153 199
new 0 153 199
return 1 159 202
assign 1 168 209
new 0 168 209
return 1 174 212
assign 1 183 219
new 0 183 219
return 1 189 222
assign 1 198 229
new 0 198 229
return 1 204 232
assign 1 213 239
new 0 213 239
return 1 219 242
assign 1 227 247
new 0 227 247
return 1 227 248
assign 1 256 257
new 0 256 257
return 1 256 258
assign 1 285 267
new 0 285 267
return 1 285 268
assign 1 306 277
new 0 306 277
return 1 306 278
assign 1 327 287
new 0 327 287
return 1 327 288
assign 1 348 297
new 0 348 297
return 1 348 298
assign 1 369 307
new 0 369 307
return 1 369 308
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -888585885: return bem_toInt_0();
case -41023079: return bem_iteratorGet_0();
case 1043984390: return bem_once_0();
case 761778979: return bem_create_0();
case 169398438: return bem_hashGet_0();
case 2027783493: return bem_vfloatGet_0();
case 512670579: return bem_deserializeClassNameGet_0();
case 2090767709: return bem_many_0();
case -1662177650: return bem_classNameGet_0();
case -1120421430: return bem_print_0();
case 605404858: return bem_tagGet_0();
case -1203575848: return bem_vfloatSet_0();
case 751706402: return bem_copy_0();
case 2079084965: return bem_toString_0();
case 1518858873: return bem_increment_0();
case 1387818040: return bem_new_0();
case 1315558702: return bem_sourceFileNameGet_0();
case -1165063866: return bem_serializeContents_0();
case -1032373300: return bem_echo_0();
case 1284609591: return bem_decrement_0();
case 2033350872: return bem_serializeToString_0();
case -364109840: return bem_serializationIteratorGet_0();
case 763461621: return bem_toAny_0();
case -268528295: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1127695585: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case -2078493800: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case -496868168: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case 1492422826: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case -550476304: return bem_sameType_1(bevd_0);
case 1646725461: return bem_copyTo_1(bevd_0);
case -132994488: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2103269595: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
case -347928415: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case 327020484: return bem_sameObject_1(bevd_0);
case 945358895: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1628072592: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -95156212: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -173923543: return bem_def_1(bevd_0);
case 932249623: return bem_sameClass_1(bevd_0);
case -1095756156: return bem_new_1(bevd_0);
case 611966660: return bem_equals_1(bevd_0);
case -1179778534: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1132113958: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case 1953673516: return bem_undef_1(bevd_0);
case -46023056: return bem_notEquals_1(bevd_0);
case -535852400: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case -400783475: return bem_undefined_1(bevd_0);
case 1296533558: return bem_otherClass_1(bevd_0);
case -1578179895: return bem_defined_1(bevd_0);
case 1479785081: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -501684028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1815708233: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1424200790: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1920722583: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1806507047: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1733811664: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1465498474: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_MathFloat();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
