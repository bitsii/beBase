package be;
/* IO:File: source/base/Float.be */
public final class BEC_2_4_5_MathFloat extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
public static BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) throws Throwable {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_5_MathFloat bevt_21_ta_ph = null;
BEC_2_4_5_MathFloat bevt_22_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_ta_ph = beva_si.bemd_1(-1701302488, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 76*/ {
bevl_neg = be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(177246148, bevt_2_ta_ph);
} /* Line: 78*/
 else /* Line: 79*/ {
bevl_neg = be.BECS_Runtime.boolFalse;
} /* Line: 80*/
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(619396637, bevt_3_ta_ph);
if (bevl_dec == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_dec.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 84*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_7_ta_ph = beva_si.bemd_2(-920868668, bevt_8_ta_ph, bevl_dec);
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_ta_ph);
} /* Line: 85*/
 else /* Line: 86*/ {
bevl_lhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 87*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_10_ta_ph = bevl_dec.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = beva_si.bemd_0(459282369);
bevt_9_ta_ph = bevt_10_ta_ph.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_ta_ph );
if (bevt_9_ta_ph.bevi_bool)/* Line: 89*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_14_ta_ph = bevl_dec.bem_add_1(bevt_15_ta_ph);
bevt_13_ta_ph = beva_si.bemd_1(177246148, bevt_14_ta_ph);
bevl_rhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_ta_ph);
} /* Line: 90*/
 else /* Line: 91*/ {
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 92*/
} /* Line: 89*/
 else /* Line: 94*/ {
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 96*/
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(10));
bevt_18_ta_ph = bevl_rhs.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_sizeGet_0();
bevl_divby = bevt_16_ta_ph.bem_power_1(bevt_17_ta_ph);
if (bevl_neg.bevi_bool)/* Line: 99*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_ta_ph);
} /* Line: 101*/
bevt_21_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_rhs);
bevt_22_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_divby);
bevl_rhsf = bevt_21_ta_ph.bem_divide_1(bevt_22_ta_ph);
bevl_lhsf = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_lhs);
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_intNew_1(BEC_2_4_3_MathInt beva_int) throws Throwable {

      bevi_float = (float) beva_int.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_create_0() throws Throwable {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_4_5_MathFloat) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toInt_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
BEC_2_4_5_MathFloat bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_lhi = bem_toInt_0();
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat()).bem_intNew_1(bevl_lhi);
bevl_rh = bem_subtract_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_ta_ph);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_ta_ph = bevl_lhi.bem_toString_0();
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = bevl_rhi.bem_toString_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 175*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 187*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 195*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 207*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 215*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 227*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 235*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 247*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 255*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 267*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 275*/ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 287*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float == ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float != ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {76, 76, 77, 78, 78, 80, 82, 82, 83, 83, 84, 84, 84, 85, 85, 85, 87, 89, 89, 89, 89, 90, 90, 90, 90, 92, 95, 96, 98, 98, 98, 98, 100, 100, 101, 101, 103, 103, 103, 104, 105, 106, 128, 128, 131, 131, 135, 139, 139, 150, 158, 163, 163, 167, 168, 168, 169, 169, 170, 171, 171, 171, 171, 171, 171, 176, 187, 196, 207, 216, 227, 236, 247, 256, 267, 276, 287, 295, 295, 337, 337, 379, 379, 407, 407, 435, 435, 463, 463, 491, 491};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {59, 60, 62, 63, 64, 67, 69, 70, 71, 76, 77, 78, 83, 84, 85, 86, 89, 91, 92, 93, 94, 96, 97, 98, 99, 102, 106, 107, 109, 110, 111, 112, 114, 115, 116, 117, 119, 120, 121, 122, 123, 124, 133, 134, 138, 139, 142, 147, 148, 152, 153, 157, 158, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 188, 191, 198, 201, 208, 211, 218, 221, 228, 231, 238, 241, 246, 247, 256, 257, 266, 267, 276, 277, 286, 287, 296, 297, 306, 307};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 76 59
new 0 76 59
assign 1 76 60
begins 1 76 60
assign 1 77 62
new 0 77 62
assign 1 78 63
new 0 78 63
assign 1 78 64
substring 1 78 64
assign 1 80 67
new 0 80 67
assign 1 82 69
new 0 82 69
assign 1 82 70
find 1 82 70
assign 1 83 71
def 1 83 76
assign 1 84 77
new 0 84 77
assign 1 84 78
greater 1 84 83
assign 1 85 84
new 0 85 84
assign 1 85 85
substring 2 85 85
assign 1 85 86
new 1 85 86
assign 1 87 89
new 0 87 89
assign 1 89 91
new 0 89 91
assign 1 89 92
add 1 89 92
assign 1 89 93
sizeGet 0 89 93
assign 1 89 94
lesser 1 89 94
assign 1 90 96
new 0 90 96
assign 1 90 97
add 1 90 97
assign 1 90 98
substring 1 90 98
assign 1 90 99
new 1 90 99
assign 1 92 102
new 0 92 102
assign 1 95 106
new 1 95 106
assign 1 96 107
new 0 96 107
assign 1 98 109
new 0 98 109
assign 1 98 110
toString 0 98 110
assign 1 98 111
sizeGet 0 98 111
assign 1 98 112
power 1 98 112
assign 1 100 114
new 0 100 114
multiplyValue 1 100 115
assign 1 101 116
new 0 101 116
multiplyValue 1 101 117
assign 1 103 119
intNew 1 103 119
assign 1 103 120
intNew 1 103 120
assign 1 103 121
divide 1 103 121
assign 1 104 122
intNew 1 104 122
assign 1 105 123
add 1 105 123
return 1 106 124
assign 1 128 133
new 0 128 133
return 1 128 134
assign 1 131 138
toString 0 131 138
return 1 131 139
new 1 135 142
assign 1 139 147
new 0 139 147
return 1 139 148
assign 1 150 152
new 0 150 152
return 1 158 153
assign 1 163 157
toInt 0 163 157
return 1 163 158
assign 1 167 171
toInt 0 167 171
assign 1 168 172
intNew 1 168 172
assign 1 168 173
subtract 1 168 173
assign 1 169 174
new 0 169 174
assign 1 169 175
multiply 1 169 175
assign 1 170 176
toInt 0 170 176
assign 1 171 177
toString 0 171 177
assign 1 171 178
new 0 171 178
assign 1 171 179
add 1 171 179
assign 1 171 180
toString 0 171 180
assign 1 171 181
add 1 171 181
return 1 171 182
assign 1 176 188
new 0 176 188
return 1 187 191
assign 1 196 198
new 0 196 198
return 1 207 201
assign 1 216 208
new 0 216 208
return 1 227 211
assign 1 236 218
new 0 236 218
return 1 247 221
assign 1 256 228
new 0 256 228
return 1 267 231
assign 1 276 238
new 0 276 238
return 1 287 241
assign 1 295 246
new 0 295 246
return 1 295 247
assign 1 337 256
new 0 337 256
return 1 337 257
assign 1 379 266
new 0 379 266
return 1 379 267
assign 1 407 276
new 0 407 276
return 1 407 277
assign 1 435 286
new 0 435 286
return 1 435 287
assign 1 463 296
new 0 463 296
return 1 463 297
assign 1 491 306
new 0 491 306
return 1 491 307
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2139846672: return bem_print_0();
case 1890623763: return bem_copy_0();
case -836936979: return bem_serializeContentsGet_0();
case 326611308: return bem_toInt_0();
case 1515047198: return bem_create_0();
case 1711237749: return bem_vfloatGet_0();
case -1735840103: return bem_serializeToString_0();
case -1554780033: return bem_increment_0();
case -1967481250: return bem_hashGet_0();
case -974792390: return bem_vfloatSet_0();
case -643744552: return bem_iteratorGet_0();
case 670650041: return bem_new_0();
case 1293836537: return bem_decrement_0();
case 186551951: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1567418567: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case 951741113: return bem_notEquals_1(bevd_0);
case 7869303: return bem_equals_1(bevd_0);
case -284778740: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1876852691: return bem_def_1(bevd_0);
case 1090791656: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case -127217387: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
case -1727576995: return bem_intNew_1((BEC_2_4_3_MathInt) bevd_0);
case 1882156513: return bem_copyTo_1(bevd_0);
case -124018583: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case -586691189: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case -1583823897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 950311376: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case 1376974663: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case 1594978261: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1041331381: return bem_undef_1(bevd_0);
case 2066712441: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -485935447: return bem_new_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1779285405: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 582832509: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -881314990: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1602342275: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1686414234: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_MathFloat();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
