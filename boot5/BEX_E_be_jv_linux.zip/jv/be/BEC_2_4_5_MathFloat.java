package be;
/* IO:File: source/base/Float.be */
public final class BEC_2_4_5_MathFloat extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_3 = (new BEC_2_4_3_MathInt(10));
private static byte[] bece_BEC_2_4_5_MathFloat_bels_2 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_4_5_MathFloat_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_4_5_MathFloat_bels_2, 1));
public static BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) throws Throwable {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_21_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_22_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_tmpany_phold = beva_si.bemd_1(-1110730333, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 65 */ {
bevl_neg = be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(-342692019, bevt_2_tmpany_phold);
} /* Line: 67 */
 else  /* Line: 68 */ {
bevl_neg = be.BECS_Runtime.boolFalse;
} /* Line: 69 */
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(466003047, bevt_3_tmpany_phold);
if (bevl_dec == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_0;
if (bevl_dec.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_7_tmpany_phold = beva_si.bemd_2(548561082, bevt_8_tmpany_phold, bevl_dec);
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_tmpany_phold);
} /* Line: 74 */
 else  /* Line: 75 */ {
bevl_lhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 76 */
bevt_11_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_1;
bevt_10_tmpany_phold = bevl_dec.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = beva_si.bemd_0(-99764025);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_tmpany_phold );
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 78 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_2;
bevt_14_tmpany_phold = bevl_dec.bem_add_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = beva_si.bemd_1(-342692019, bevt_14_tmpany_phold);
bevl_rhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_tmpany_phold);
} /* Line: 79 */
 else  /* Line: 80 */ {
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 81 */
} /* Line: 78 */
 else  /* Line: 83 */ {
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 85 */
bevt_16_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_3;
bevt_18_tmpany_phold = bevl_rhs.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_sizeGet_0();
bevl_divby = bevt_16_tmpany_phold.bem_power_1(bevt_17_tmpany_phold);
if (bevl_neg.bevi_bool) /* Line: 88 */ {
bevt_19_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_tmpany_phold);
} /* Line: 90 */
bevt_21_tmpany_phold = bevl_rhs.bem_toFloat_0();
bevt_22_tmpany_phold = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_tmpany_phold.bem_divide_1(bevt_22_tmpany_phold);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_create_0() throws Throwable {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_4_5_MathFloat) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toInt_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_lhi = bem_toInt_0();
bevt_0_tmpany_phold = bevl_lhi.bem_toFloat_0();
bevl_rh = bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_tmpany_phold);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_tmpany_phold = bevl_lhi.bem_toString_0();
bevt_5_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_4;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevl_rhi.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 145 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 152 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 160 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 167 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 175 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 182 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 190 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 197 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 205 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 212 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 220 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 227 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float == ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float != ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {65, 65, 66, 67, 67, 69, 71, 71, 72, 72, 73, 73, 73, 74, 74, 74, 76, 78, 78, 78, 78, 79, 79, 79, 79, 81, 84, 85, 87, 87, 87, 87, 89, 89, 90, 90, 92, 92, 92, 93, 94, 95, 98, 98, 101, 101, 105, 109, 109, 120, 128, 133, 133, 137, 138, 138, 139, 139, 140, 141, 141, 141, 141, 141, 141, 146, 152, 161, 167, 176, 182, 191, 197, 206, 212, 221, 227, 235, 235, 264, 264, 293, 293, 314, 314, 335, 335, 356, 356, 377, 377};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {65, 66, 68, 69, 70, 73, 75, 76, 77, 82, 83, 84, 89, 90, 91, 92, 95, 97, 98, 99, 100, 102, 103, 104, 105, 108, 112, 113, 115, 116, 117, 118, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 134, 135, 139, 140, 143, 148, 149, 153, 154, 158, 159, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 189, 192, 199, 202, 209, 212, 219, 222, 229, 232, 239, 242, 247, 248, 257, 258, 267, 268, 277, 278, 287, 288, 297, 298, 307, 308};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 65 65
new 0 65 65
assign 1 65 66
begins 1 65 66
assign 1 66 68
new 0 66 68
assign 1 67 69
new 0 67 69
assign 1 67 70
substring 1 67 70
assign 1 69 73
new 0 69 73
assign 1 71 75
new 0 71 75
assign 1 71 76
find 1 71 76
assign 1 72 77
def 1 72 82
assign 1 73 83
new 0 73 83
assign 1 73 84
greater 1 73 89
assign 1 74 90
new 0 74 90
assign 1 74 91
substring 2 74 91
assign 1 74 92
new 1 74 92
assign 1 76 95
new 0 76 95
assign 1 78 97
new 0 78 97
assign 1 78 98
add 1 78 98
assign 1 78 99
sizeGet 0 78 99
assign 1 78 100
lesser 1 78 100
assign 1 79 102
new 0 79 102
assign 1 79 103
add 1 79 103
assign 1 79 104
substring 1 79 104
assign 1 79 105
new 1 79 105
assign 1 81 108
new 0 81 108
assign 1 84 112
new 1 84 112
assign 1 85 113
new 0 85 113
assign 1 87 115
new 0 87 115
assign 1 87 116
toString 0 87 116
assign 1 87 117
sizeGet 0 87 117
assign 1 87 118
power 1 87 118
assign 1 89 120
new 0 89 120
multiplyValue 1 89 121
assign 1 90 122
new 0 90 122
multiplyValue 1 90 123
assign 1 92 125
toFloat 0 92 125
assign 1 92 126
toFloat 0 92 126
assign 1 92 127
divide 1 92 127
assign 1 93 128
toFloat 0 93 128
assign 1 94 129
add 1 94 129
return 1 95 130
assign 1 98 134
new 0 98 134
return 1 98 135
assign 1 101 139
toString 0 101 139
return 1 101 140
new 1 105 143
assign 1 109 148
new 0 109 148
return 1 109 149
assign 1 120 153
new 0 120 153
return 1 128 154
assign 1 133 158
toInt 0 133 158
return 1 133 159
assign 1 137 172
toInt 0 137 172
assign 1 138 173
toFloat 0 138 173
assign 1 138 174
subtract 1 138 174
assign 1 139 175
new 0 139 175
assign 1 139 176
multiply 1 139 176
assign 1 140 177
toInt 0 140 177
assign 1 141 178
toString 0 141 178
assign 1 141 179
new 0 141 179
assign 1 141 180
add 1 141 180
assign 1 141 181
toString 0 141 181
assign 1 141 182
add 1 141 182
return 1 141 183
assign 1 146 189
new 0 146 189
return 1 152 192
assign 1 161 199
new 0 161 199
return 1 167 202
assign 1 176 209
new 0 176 209
return 1 182 212
assign 1 191 219
new 0 191 219
return 1 197 222
assign 1 206 229
new 0 206 229
return 1 212 232
assign 1 221 239
new 0 221 239
return 1 227 242
assign 1 235 247
new 0 235 247
return 1 235 248
assign 1 264 257
new 0 264 257
return 1 264 258
assign 1 293 267
new 0 293 267
return 1 293 268
assign 1 314 277
new 0 314 277
return 1 314 278
assign 1 335 287
new 0 335 287
return 1 335 288
assign 1 356 297
new 0 356 297
return 1 356 298
assign 1 377 307
new 0 377 307
return 1 377 308
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 854837664: return bem_create_0();
case 239325412: return bem_copy_0();
case 1486098436: return bem_fieldNamesGet_0();
case 1616240746: return bem_toString_0();
case 1415084274: return bem_vfloatSet_0();
case -760211542: return bem_sourceFileNameGet_0();
case -795764953: return bem_fieldIteratorGet_0();
case 417125603: return bem_increment_0();
case 2018099954: return bem_vfloatGet_0();
case 1697432405: return bem_once_0();
case 1737862711: return bem_print_0();
case 1236768538: return bem_iteratorGet_0();
case -911579003: return bem_decrement_0();
case -1187132797: return bem_hashGet_0();
case -2036442591: return bem_toAny_0();
case 1319933824: return bem_classNameGet_0();
case 396059776: return bem_tagGet_0();
case -619633984: return bem_toInt_0();
case -178992645: return bem_deserializeClassNameGet_0();
case 2077314506: return bem_many_0();
case -604973932: return bem_serializeContents_0();
case -1159943693: return bem_echo_0();
case -324733615: return bem_serializeToString_0();
case -1698643956: return bem_serializationIteratorGet_0();
case -980484092: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 291577686: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case 962423408: return bem_def_1(bevd_0);
case -1120436550: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1754732193: return bem_notEquals_1(bevd_0);
case 486594455: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 215737112: return bem_otherType_1(bevd_0);
case -492919920: return bem_new_1(bevd_0);
case -1207277298: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case 1784508277: return bem_undefined_1(bevd_0);
case -629299566: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case 395717057: return bem_defined_1(bevd_0);
case 1479379696: return bem_sameClass_1(bevd_0);
case 1229731165: return bem_copyTo_1(bevd_0);
case 365732050: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case 1021147088: return bem_otherClass_1(bevd_0);
case 850683733: return bem_equals_1(bevd_0);
case -1097624238: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -58601680: return bem_sameType_1(bevd_0);
case 1310668304: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case 887061934: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case 1085172513: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case 1075750255: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1109276399: return bem_sameObject_1(bevd_0);
case -949915761: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case -354650091: return bem_undef_1(bevd_0);
case -757417596: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 602921151: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1012334348: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 661390803: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -434648658: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 192635884: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 103255187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 834345030: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_MathFloat();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
