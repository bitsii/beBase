package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_BEC_2_4_8_TimeInterval_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_BEC_2_4_8_TimeInterval_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_3 = {0x3A};
public static BEC_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_inst;

public static BET_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_type;

public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt());
bevp_millis = (new BEC_2_4_3_MathInt());

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(60));
bevt_0_ta_ph = bevp_secs.bem_modulus_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(60));
bevt_0_ta_ph = bevp_secs.bem_divide_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(3600));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(86400));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(3600));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(86400));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_ta_ph);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 256*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevt_4_ta_ph = bevp_millis.bem_divide_1(bevt_5_ta_ph);
bevp_secs = bevp_secs.bem_add_1(bevt_4_ta_ph);
bevp_millis = bevl_mmod;
} /* Line: 258*/
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_millis.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_secs.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 260*/
 else /* Line: 260*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 260*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevp_millis = bevt_11_ta_ph.bem_add_1(bevp_millis);
} /* Line: 262*/
 else /* Line: 260*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_millis.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_secs.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 263*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_secs = bevp_secs.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevt_17_ta_ph = bevt_18_ta_ph.bem_subtract_1(bevt_19_ta_ph);
bevp_millis = bevt_17_ta_ph.bem_add_1(bevp_millis);
} /* Line: 265*/
} /* Line: 260*/
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 295*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 295*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 295*/
 else /* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 295*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 295*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 295*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 296*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 302*/
 else /* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 302*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 302*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 303*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 309*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 309*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 309*/
 else /* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 309*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 309*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 310*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 316*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 316*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 316*/
 else /* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 316*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 316*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 317*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 323*/
bevt_5_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_4_ta_ph = bevt_5_ta_ph.bem_sameClass_2(this, beva_other);
if (bevt_4_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_7_ta_ph = beva_other.bemd_0(-937727201);
bevt_6_ta_ph = bevp_secs.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 324*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 324*/
 else /* Line: 324*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 324*/ {
bevt_9_ta_ph = beva_other.bemd_0(-2006481404);
bevt_8_ta_ph = bevp_millis.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 324*/
 else /* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 324*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 325*/
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 331*/
bevt_6_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_5_ta_ph = bevt_6_ta_ph.bem_sameClass_2(this, beva_other);
if (bevt_5_ta_ph.bevi_bool) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 332*/ {
bevt_8_ta_ph = beva_other.bemd_0(-937727201);
bevt_7_ta_ph = bevp_secs.bem_notEquals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 332*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 332*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 332*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 332*/ {
bevt_10_ta_ph = beva_other.bemd_0(-2006481404);
bevt_9_ta_ph = bevp_millis.bem_notEquals_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 332*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 332*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 332*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /* Line: 333*/
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
if (beva_other == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 340*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 340*/
bevt_3_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 341*/ {
bevt_7_ta_ph = beva_other.bem_secsGet_0();
bevt_6_ta_ph = bevp_secs.bem_subtract_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_abs_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(3600));
if (bevt_5_ta_ph.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_9_ta_ph;
} /* Line: 343*/
} /* Line: 342*/
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_6_ta_ph = bem_minutesGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_toString_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_4_8_TimeInterval_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bem_secondInMinuteGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_millis);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_2));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_2_ta_ph = bevp_secs.bem_toString_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_8_TimeInterval_bels_3));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_millis.bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_4_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_secs.bem_toString_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_millis);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_2));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {136, 137, 183, 184, 190, 191, 192, 196, 196, 200, 200, 200, 204, 208, 208, 208, 212, 216, 220, 224, 225, 229, 229, 229, 233, 233, 233, 237, 237, 237, 241, 241, 241, 246, 250, 251, 255, 255, 256, 256, 257, 257, 257, 258, 260, 260, 260, 260, 260, 260, 0, 0, 0, 261, 261, 262, 262, 263, 263, 263, 263, 263, 263, 0, 0, 0, 264, 264, 265, 265, 265, 265, 270, 274, 275, 279, 279, 280, 280, 281, 282, 283, 287, 287, 288, 288, 289, 290, 291, 295, 295, 295, 0, 295, 295, 295, 295, 295, 295, 0, 0, 0, 0, 0, 296, 296, 298, 298, 302, 302, 302, 0, 302, 302, 302, 302, 302, 302, 0, 0, 0, 0, 0, 303, 303, 305, 305, 309, 309, 309, 0, 309, 309, 309, 309, 309, 309, 0, 0, 0, 0, 0, 310, 310, 312, 312, 316, 316, 316, 0, 316, 316, 316, 316, 316, 316, 0, 0, 0, 0, 0, 317, 317, 319, 319, 323, 323, 323, 323, 324, 324, 324, 324, 0, 0, 0, 324, 324, 0, 0, 0, 325, 325, 327, 327, 331, 331, 331, 331, 332, 332, 332, 332, 0, 332, 332, 0, 0, 0, 332, 332, 0, 0, 333, 333, 335, 335, 340, 340, 340, 340, 341, 341, 341, 342, 342, 342, 342, 342, 342, 343, 343, 346, 346, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 354, 354, 354, 354, 354, 354, 358, 358, 358, 358, 358, 358, 358, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 27, 28, 32, 33, 34, 39, 40, 45, 46, 47, 50, 55, 56, 57, 60, 63, 67, 70, 71, 77, 78, 79, 85, 86, 87, 93, 94, 95, 101, 102, 103, 107, 111, 112, 137, 138, 139, 144, 145, 146, 147, 148, 150, 151, 156, 157, 158, 163, 164, 167, 171, 174, 175, 176, 177, 180, 181, 186, 187, 188, 193, 194, 197, 201, 204, 205, 206, 207, 208, 209, 215, 219, 220, 229, 230, 231, 232, 233, 234, 235, 243, 244, 245, 246, 247, 248, 249, 261, 262, 267, 268, 271, 272, 277, 278, 279, 284, 285, 288, 292, 295, 298, 302, 303, 305, 306, 318, 319, 324, 325, 328, 329, 334, 335, 336, 341, 342, 345, 349, 352, 355, 359, 360, 362, 363, 375, 376, 381, 382, 385, 386, 391, 392, 393, 398, 399, 402, 406, 409, 412, 416, 417, 419, 420, 432, 433, 438, 439, 442, 443, 448, 449, 450, 455, 456, 459, 463, 466, 469, 473, 474, 476, 477, 492, 497, 498, 499, 501, 502, 504, 505, 507, 510, 514, 517, 518, 520, 523, 527, 530, 531, 533, 534, 550, 555, 556, 557, 559, 560, 561, 566, 567, 570, 571, 573, 576, 580, 583, 584, 586, 589, 593, 594, 596, 597, 611, 616, 617, 618, 620, 621, 626, 627, 628, 629, 630, 631, 636, 637, 638, 641, 642, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 675, 676, 677, 678, 679, 680, 689, 690, 691, 692, 693, 694, 695, 698, 701, 705, 708};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 136 18
new 0 136 18
assign 1 137 19
new 0 137 19
assign 1 183 27
new 0 183 27
assign 1 184 28
new 0 184 28
assign 1 190 32
assign 1 191 33
carryMillis 0 192 34
assign 1 196 39
new 2 196 39
return 1 196 40
assign 1 200 45
new 0 200 45
assign 1 200 46
modulus 1 200 46
return 1 200 47
return 1 204 50
assign 1 208 55
new 0 208 55
assign 1 208 56
divide 1 208 56
return 1 208 57
return 1 212 60
assign 1 216 63
return 1 220 67
assign 1 224 70
carryMillis 0 225 71
assign 1 229 77
new 0 229 77
assign 1 229 78
multiply 1 229 78
assign 1 229 79
add 1 229 79
assign 1 233 85
new 0 233 85
assign 1 233 86
multiply 1 233 86
assign 1 233 87
add 1 233 87
assign 1 237 93
new 0 237 93
assign 1 237 94
multiply 1 237 94
assign 1 237 95
subtract 1 237 95
assign 1 241 101
new 0 241 101
assign 1 241 102
multiply 1 241 102
assign 1 241 103
subtract 1 241 103
assign 1 246 107
add 1 246 107
assign 1 250 111
add 1 250 111
carryMillis 0 251 112
assign 1 255 137
new 0 255 137
assign 1 255 138
modulus 1 255 138
assign 1 256 139
notEquals 1 256 144
assign 1 257 145
new 0 257 145
assign 1 257 146
divide 1 257 146
assign 1 257 147
add 1 257 147
assign 1 258 148
assign 1 260 150
new 0 260 150
assign 1 260 151
lesser 1 260 156
assign 1 260 157
new 0 260 157
assign 1 260 158
greater 1 260 163
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 261 174
new 0 261 174
assign 1 261 175
subtract 1 261 175
assign 1 262 176
new 0 262 176
assign 1 262 177
add 1 262 177
assign 1 263 180
new 0 263 180
assign 1 263 181
greater 1 263 186
assign 1 263 187
new 0 263 187
assign 1 263 188
lesser 1 263 193
assign 1 0 194
assign 1 0 197
assign 1 0 201
assign 1 264 204
new 0 264 204
assign 1 264 205
add 1 264 205
assign 1 265 206
new 0 265 206
assign 1 265 207
new 0 265 207
assign 1 265 208
subtract 1 265 208
assign 1 265 209
add 1 265 209
assign 1 270 215
subtract 1 270 215
assign 1 274 219
subtract 1 274 219
carryMillis 0 275 220
assign 1 279 229
secsGet 0 279 229
assign 1 279 230
add 1 279 230
assign 1 280 231
millisGet 0 280 231
assign 1 280 232
add 1 280 232
assign 1 281 233
new 2 281 233
carryMillis 0 282 234
return 1 283 235
assign 1 287 243
secsGet 0 287 243
assign 1 287 244
subtract 1 287 244
assign 1 288 245
millisGet 0 288 245
assign 1 288 246
subtract 1 288 246
assign 1 289 247
new 2 289 247
carryMillis 0 290 248
return 1 291 249
assign 1 295 261
secsGet 0 295 261
assign 1 295 262
greater 1 295 267
assign 1 0 268
assign 1 295 271
secsGet 0 295 271
assign 1 295 272
equals 1 295 277
assign 1 295 278
millisGet 0 295 278
assign 1 295 279
greater 1 295 284
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 0 295
assign 1 0 298
assign 1 296 302
new 0 296 302
return 1 296 303
assign 1 298 305
new 0 298 305
return 1 298 306
assign 1 302 318
secsGet 0 302 318
assign 1 302 319
lesser 1 302 324
assign 1 0 325
assign 1 302 328
secsGet 0 302 328
assign 1 302 329
equals 1 302 334
assign 1 302 335
millisGet 0 302 335
assign 1 302 336
lesser 1 302 341
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 0 352
assign 1 0 355
assign 1 303 359
new 0 303 359
return 1 303 360
assign 1 305 362
new 0 305 362
return 1 305 363
assign 1 309 375
secsGet 0 309 375
assign 1 309 376
greaterEquals 1 309 381
assign 1 0 382
assign 1 309 385
secsGet 0 309 385
assign 1 309 386
equals 1 309 391
assign 1 309 392
millisGet 0 309 392
assign 1 309 393
greaterEquals 1 309 398
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 0 409
assign 1 0 412
assign 1 310 416
new 0 310 416
return 1 310 417
assign 1 312 419
new 0 312 419
return 1 312 420
assign 1 316 432
secsGet 0 316 432
assign 1 316 433
lesserEquals 1 316 438
assign 1 0 439
assign 1 316 442
secsGet 0 316 442
assign 1 316 443
equals 1 316 448
assign 1 316 449
millisGet 0 316 449
assign 1 316 450
lesserEquals 1 316 455
assign 1 0 456
assign 1 0 459
assign 1 0 463
assign 1 0 466
assign 1 0 469
assign 1 317 473
new 0 317 473
return 1 317 474
assign 1 319 476
new 0 319 476
return 1 319 477
assign 1 323 492
undef 1 323 497
assign 1 323 498
new 0 323 498
return 1 323 499
assign 1 324 501
new 0 324 501
assign 1 324 502
sameClass 2 324 502
assign 1 324 504
secsGet 0 324 504
assign 1 324 505
equals 1 324 505
assign 1 0 507
assign 1 0 510
assign 1 0 514
assign 1 324 517
millisGet 0 324 517
assign 1 324 518
equals 1 324 518
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 325 530
new 0 325 530
return 1 325 531
assign 1 327 533
new 0 327 533
return 1 327 534
assign 1 331 550
undef 1 331 555
assign 1 331 556
new 0 331 556
return 1 331 557
assign 1 332 559
new 0 332 559
assign 1 332 560
sameClass 2 332 560
assign 1 332 561
not 0 332 566
assign 1 0 567
assign 1 332 570
secsGet 0 332 570
assign 1 332 571
notEquals 1 332 571
assign 1 0 573
assign 1 0 576
assign 1 0 580
assign 1 332 583
millisGet 0 332 583
assign 1 332 584
notEquals 1 332 584
assign 1 0 586
assign 1 0 589
assign 1 333 593
new 0 333 593
return 1 333 594
assign 1 335 596
new 0 335 596
return 1 335 597
assign 1 340 611
undef 1 340 616
assign 1 340 617
new 0 340 617
return 1 340 618
assign 1 341 620
millisGet 0 341 620
assign 1 341 621
equals 1 341 626
assign 1 342 627
secsGet 0 342 627
assign 1 342 628
subtract 1 342 628
assign 1 342 629
abs 0 342 629
assign 1 342 630
new 0 342 630
assign 1 342 631
equals 1 342 636
assign 1 343 637
new 0 343 637
return 1 343 638
assign 1 346 641
new 0 346 641
return 1 346 642
assign 1 350 656
minutesGet 0 350 656
assign 1 350 657
toString 0 350 657
assign 1 350 658
new 0 350 658
assign 1 350 659
add 1 350 659
assign 1 350 660
secondInMinuteGet 0 350 660
assign 1 350 661
add 1 350 661
assign 1 350 662
new 0 350 662
assign 1 350 663
add 1 350 663
assign 1 350 664
add 1 350 664
assign 1 350 665
new 0 350 665
assign 1 350 666
add 1 350 666
return 1 350 667
assign 1 354 675
toString 0 354 675
assign 1 354 676
new 0 354 676
assign 1 354 677
add 1 354 677
assign 1 354 678
toString 0 354 678
assign 1 354 679
add 1 354 679
return 1 354 680
assign 1 358 689
toString 0 358 689
assign 1 358 690
new 0 358 690
assign 1 358 691
add 1 358 691
assign 1 358 692
add 1 358 692
assign 1 358 693
new 0 358 693
assign 1 358 694
add 1 358 694
return 1 358 695
return 1 0 698
assign 1 0 701
return 1 0 705
assign 1 0 708
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1301883703: return bem_hashGet_0();
case 1848168152: return bem_millisecondInSecondGet_0();
case 1408609733: return bem_iteratorGet_0();
case 1806064504: return bem_new_0();
case -1326317200: return bem_millisecondsGet_0();
case -251163692: return bem_toStringMinutes_0();
case -2006481404: return bem_millisGet_0();
case -612950183: return bem_secondInMinuteGet_0();
case -1008787576: return bem_create_0();
case 880564320: return bem_carryMillis_0();
case -1130901721: return bem_now_0();
case -978033728: return bem_print_0();
case -937727201: return bem_secsGet_0();
case -484298169: return bem_secondsGet_0();
case -1275315701: return bem_copy_0();
case 1712538602: return bem_toString_0();
case 786051887: return bem_toShortString_0();
case -1327105045: return bem_minutesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 879834780: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 562626708: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case 1278698361: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 72517212: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -14743784: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1362516419: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 271554345: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -887186144: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 532044635: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case -1605447486: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case 2047989084: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1162939778: return bem_def_1(bevd_0);
case 1213441759: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1234820220: return bem_copyTo_1(bevd_0);
case 711942615: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1217552554: return bem_print_1(bevd_0);
case -740780340: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case -148010615: return bem_undef_1(bevd_0);
case -938921517: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case 65288010: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case -360857661: return bem_secsSet_1(bevd_0);
case -2044648377: return bem_millisSet_1(bevd_0);
case -526829482: return bem_equals_1(bevd_0);
case 2105889386: return bem_notEquals_1(bevd_0);
case -2143383854: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -960117370: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1422586587: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 596327003: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -554972801: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 415995996: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_TimeInterval_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_8_TimeInterval_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst = (BEC_2_4_8_TimeInterval) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_type;
}
}
