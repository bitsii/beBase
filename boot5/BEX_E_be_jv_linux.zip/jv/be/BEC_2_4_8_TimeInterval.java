package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_BEC_2_4_8_TimeInterval_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_BEC_2_4_8_TimeInterval_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_0 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_1 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_2 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_3 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_4 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_5 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_6 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_7 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_11 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_14 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_15 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_16 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_17 = (new BEC_2_4_3_MathInt(3600));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_0, 10));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_1, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_2, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_3 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_3, 1));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_4 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_4, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_5 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_5, 13));
public static BEC_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_inst;
public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt());
bevp_millis = (new BEC_2_4_3_MathInt());

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_0;
bevt_0_tmpany_phold = bevp_secs.bem_modulus_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_1;
bevt_0_tmpany_phold = bevp_secs.bem_divide_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_2;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_3;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_5;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_6;
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_tmpany_phold);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_7;
bevt_4_tmpany_phold = bevp_millis.bem_divide_1(bevt_5_tmpany_phold);
bevp_secs = bevp_secs.bem_add_1(bevt_4_tmpany_phold);
bevp_millis = bevl_mmod;
} /* Line: 226 */
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_8;
if (bevp_millis.bevi_int < bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_9;
if (bevp_secs.bevi_int > bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 228 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_10;
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_11;
bevp_millis = bevt_11_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 230 */
 else  /* Line: 228 */ {
bevt_13_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_12;
if (bevp_millis.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_13;
if (bevp_secs.bevi_int < bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 231 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 231 */
 else  /* Line: 231 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 231 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_14;
bevp_secs = bevp_secs.bem_add_1(bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_15;
bevt_19_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_16;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_subtract_1(bevt_19_tmpany_phold);
bevp_millis = bevt_17_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 233 */
} /* Line: 228 */
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
 else  /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 264 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 270 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 271 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 278 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 285 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_4_tmpany_phold = beva_other.bemd_0(2032294801);
bevt_3_tmpany_phold = bevp_secs.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 291 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 291 */
 else  /* Line: 291 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 291 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-958900708);
bevt_5_tmpany_phold = bevp_millis.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 291 */
 else  /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 291 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 292 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(2032294801);
bevt_4_tmpany_phold = bevp_secs.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 298 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(-958900708);
bevt_6_tmpany_phold = bevp_millis.bem_notEquals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 298 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 298 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_8_tmpany_phold;
} /* Line: 299 */
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
if (beva_other == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 306 */
bevt_3_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevt_7_tmpany_phold = beva_other.bem_secsGet_0();
bevt_6_tmpany_phold = bevp_secs.bem_subtract_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_abs_0();
bevt_8_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_17;
if (bevt_5_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 308 */ {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_9_tmpany_phold;
} /* Line: 309 */
} /* Line: 308 */
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_6_tmpany_phold = bem_minutesGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_toString_0();
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_18;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bem_secondInMinuteGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_19;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_20;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_secs.bem_toString_0();
bevt_3_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_21;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_millis.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_secs.bem_toString_0();
bevt_4_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {113, 114, 151, 152, 158, 159, 160, 164, 164, 168, 168, 168, 172, 176, 176, 176, 180, 184, 188, 192, 193, 197, 197, 197, 201, 201, 201, 205, 205, 205, 209, 209, 209, 214, 218, 219, 223, 223, 224, 224, 225, 225, 225, 226, 228, 228, 228, 228, 228, 228, 0, 0, 0, 229, 229, 230, 230, 231, 231, 231, 231, 231, 231, 0, 0, 0, 232, 232, 233, 233, 233, 233, 238, 242, 243, 247, 247, 248, 248, 249, 250, 251, 255, 255, 256, 256, 257, 258, 259, 263, 263, 263, 0, 263, 263, 263, 263, 263, 263, 0, 0, 0, 0, 0, 264, 264, 266, 266, 270, 270, 270, 0, 270, 270, 270, 270, 270, 270, 0, 0, 0, 0, 0, 271, 271, 273, 273, 277, 277, 277, 0, 277, 277, 277, 277, 277, 277, 0, 0, 0, 0, 0, 278, 278, 280, 280, 284, 284, 284, 0, 284, 284, 284, 284, 284, 284, 0, 0, 0, 0, 0, 285, 285, 287, 287, 291, 291, 291, 0, 0, 0, 291, 291, 0, 0, 0, 292, 292, 294, 294, 298, 298, 298, 0, 298, 298, 0, 0, 0, 298, 298, 0, 0, 299, 299, 301, 301, 306, 306, 306, 306, 307, 307, 307, 308, 308, 308, 308, 308, 308, 309, 309, 312, 312, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 320, 320, 320, 320, 320, 320, 324, 324, 324, 324, 324, 324, 324, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 50, 51, 55, 56, 57, 62, 63, 68, 69, 70, 73, 78, 79, 80, 83, 86, 90, 93, 94, 100, 101, 102, 108, 109, 110, 116, 117, 118, 124, 125, 126, 130, 134, 135, 160, 161, 162, 167, 168, 169, 170, 171, 173, 174, 179, 180, 181, 186, 187, 190, 194, 197, 198, 199, 200, 203, 204, 209, 210, 211, 216, 217, 220, 224, 227, 228, 229, 230, 231, 232, 238, 242, 243, 252, 253, 254, 255, 256, 257, 258, 266, 267, 268, 269, 270, 271, 272, 284, 285, 290, 291, 294, 295, 300, 301, 302, 307, 308, 311, 315, 318, 321, 325, 326, 328, 329, 341, 342, 347, 348, 351, 352, 357, 358, 359, 364, 365, 368, 372, 375, 378, 382, 383, 385, 386, 398, 399, 404, 405, 408, 409, 414, 415, 416, 421, 422, 425, 429, 432, 435, 439, 440, 442, 443, 455, 456, 461, 462, 465, 466, 471, 472, 473, 478, 479, 482, 486, 489, 492, 496, 497, 499, 500, 512, 514, 515, 517, 520, 524, 527, 528, 530, 533, 537, 540, 541, 543, 544, 557, 558, 563, 564, 567, 568, 570, 573, 577, 580, 581, 583, 586, 590, 591, 593, 594, 608, 613, 614, 615, 617, 618, 623, 624, 625, 626, 627, 628, 633, 634, 635, 638, 639, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 672, 673, 674, 675, 676, 677, 686, 687, 688, 689, 690, 691, 692, 695, 698, 702, 705};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 113 41
new 0 113 41
assign 1 114 42
new 0 114 42
assign 1 151 50
new 0 151 50
assign 1 152 51
new 0 152 51
assign 1 158 55
assign 1 159 56
carryMillis 0 160 57
assign 1 164 62
new 2 164 62
return 1 164 63
assign 1 168 68
new 0 168 68
assign 1 168 69
modulus 1 168 69
return 1 168 70
return 1 172 73
assign 1 176 78
new 0 176 78
assign 1 176 79
divide 1 176 79
return 1 176 80
return 1 180 83
assign 1 184 86
return 1 188 90
assign 1 192 93
carryMillis 0 193 94
assign 1 197 100
new 0 197 100
assign 1 197 101
multiply 1 197 101
assign 1 197 102
add 1 197 102
assign 1 201 108
new 0 201 108
assign 1 201 109
multiply 1 201 109
assign 1 201 110
add 1 201 110
assign 1 205 116
new 0 205 116
assign 1 205 117
multiply 1 205 117
assign 1 205 118
subtract 1 205 118
assign 1 209 124
new 0 209 124
assign 1 209 125
multiply 1 209 125
assign 1 209 126
subtract 1 209 126
assign 1 214 130
add 1 214 130
assign 1 218 134
add 1 218 134
carryMillis 0 219 135
assign 1 223 160
new 0 223 160
assign 1 223 161
modulus 1 223 161
assign 1 224 162
notEquals 1 224 167
assign 1 225 168
new 0 225 168
assign 1 225 169
divide 1 225 169
assign 1 225 170
add 1 225 170
assign 1 226 171
assign 1 228 173
new 0 228 173
assign 1 228 174
lesser 1 228 179
assign 1 228 180
new 0 228 180
assign 1 228 181
greater 1 228 186
assign 1 0 187
assign 1 0 190
assign 1 0 194
assign 1 229 197
new 0 229 197
assign 1 229 198
subtract 1 229 198
assign 1 230 199
new 0 230 199
assign 1 230 200
add 1 230 200
assign 1 231 203
new 0 231 203
assign 1 231 204
greater 1 231 209
assign 1 231 210
new 0 231 210
assign 1 231 211
lesser 1 231 216
assign 1 0 217
assign 1 0 220
assign 1 0 224
assign 1 232 227
new 0 232 227
assign 1 232 228
add 1 232 228
assign 1 233 229
new 0 233 229
assign 1 233 230
new 0 233 230
assign 1 233 231
subtract 1 233 231
assign 1 233 232
add 1 233 232
assign 1 238 238
subtract 1 238 238
assign 1 242 242
subtract 1 242 242
carryMillis 0 243 243
assign 1 247 252
secsGet 0 247 252
assign 1 247 253
add 1 247 253
assign 1 248 254
millisGet 0 248 254
assign 1 248 255
add 1 248 255
assign 1 249 256
new 2 249 256
carryMillis 0 250 257
return 1 251 258
assign 1 255 266
secsGet 0 255 266
assign 1 255 267
subtract 1 255 267
assign 1 256 268
millisGet 0 256 268
assign 1 256 269
subtract 1 256 269
assign 1 257 270
new 2 257 270
carryMillis 0 258 271
return 1 259 272
assign 1 263 284
secsGet 0 263 284
assign 1 263 285
greater 1 263 290
assign 1 0 291
assign 1 263 294
secsGet 0 263 294
assign 1 263 295
equals 1 263 300
assign 1 263 301
millisGet 0 263 301
assign 1 263 302
greater 1 263 307
assign 1 0 308
assign 1 0 311
assign 1 0 315
assign 1 0 318
assign 1 0 321
assign 1 264 325
new 0 264 325
return 1 264 326
assign 1 266 328
new 0 266 328
return 1 266 329
assign 1 270 341
secsGet 0 270 341
assign 1 270 342
lesser 1 270 347
assign 1 0 348
assign 1 270 351
secsGet 0 270 351
assign 1 270 352
equals 1 270 357
assign 1 270 358
millisGet 0 270 358
assign 1 270 359
lesser 1 270 364
assign 1 0 365
assign 1 0 368
assign 1 0 372
assign 1 0 375
assign 1 0 378
assign 1 271 382
new 0 271 382
return 1 271 383
assign 1 273 385
new 0 273 385
return 1 273 386
assign 1 277 398
secsGet 0 277 398
assign 1 277 399
greaterEquals 1 277 404
assign 1 0 405
assign 1 277 408
secsGet 0 277 408
assign 1 277 409
equals 1 277 414
assign 1 277 415
millisGet 0 277 415
assign 1 277 416
greaterEquals 1 277 421
assign 1 0 422
assign 1 0 425
assign 1 0 429
assign 1 0 432
assign 1 0 435
assign 1 278 439
new 0 278 439
return 1 278 440
assign 1 280 442
new 0 280 442
return 1 280 443
assign 1 284 455
secsGet 0 284 455
assign 1 284 456
lesserEquals 1 284 461
assign 1 0 462
assign 1 284 465
secsGet 0 284 465
assign 1 284 466
equals 1 284 471
assign 1 284 472
millisGet 0 284 472
assign 1 284 473
lesserEquals 1 284 478
assign 1 0 479
assign 1 0 482
assign 1 0 486
assign 1 0 489
assign 1 0 492
assign 1 285 496
new 0 285 496
return 1 285 497
assign 1 287 499
new 0 287 499
return 1 287 500
assign 1 291 512
sameClass 1 291 512
assign 1 291 514
secsGet 0 291 514
assign 1 291 515
equals 1 291 515
assign 1 0 517
assign 1 0 520
assign 1 0 524
assign 1 291 527
millisGet 0 291 527
assign 1 291 528
equals 1 291 528
assign 1 0 530
assign 1 0 533
assign 1 0 537
assign 1 292 540
new 0 292 540
return 1 292 541
assign 1 294 543
new 0 294 543
return 1 294 544
assign 1 298 557
sameClass 1 298 557
assign 1 298 558
not 0 298 563
assign 1 0 564
assign 1 298 567
secsGet 0 298 567
assign 1 298 568
notEquals 1 298 568
assign 1 0 570
assign 1 0 573
assign 1 0 577
assign 1 298 580
millisGet 0 298 580
assign 1 298 581
notEquals 1 298 581
assign 1 0 583
assign 1 0 586
assign 1 299 590
new 0 299 590
return 1 299 591
assign 1 301 593
new 0 301 593
return 1 301 594
assign 1 306 608
undef 1 306 613
assign 1 306 614
new 0 306 614
return 1 306 615
assign 1 307 617
millisGet 0 307 617
assign 1 307 618
equals 1 307 623
assign 1 308 624
secsGet 0 308 624
assign 1 308 625
subtract 1 308 625
assign 1 308 626
abs 0 308 626
assign 1 308 627
new 0 308 627
assign 1 308 628
equals 1 308 633
assign 1 309 634
new 0 309 634
return 1 309 635
assign 1 312 638
new 0 312 638
return 1 312 639
assign 1 316 653
minutesGet 0 316 653
assign 1 316 654
toString 0 316 654
assign 1 316 655
new 0 316 655
assign 1 316 656
add 1 316 656
assign 1 316 657
secondInMinuteGet 0 316 657
assign 1 316 658
add 1 316 658
assign 1 316 659
new 0 316 659
assign 1 316 660
add 1 316 660
assign 1 316 661
add 1 316 661
assign 1 316 662
new 0 316 662
assign 1 316 663
add 1 316 663
return 1 316 664
assign 1 320 672
toString 0 320 672
assign 1 320 673
new 0 320 673
assign 1 320 674
add 1 320 674
assign 1 320 675
toString 0 320 675
assign 1 320 676
add 1 320 676
return 1 320 677
assign 1 324 686
toString 0 324 686
assign 1 324 687
new 0 324 687
assign 1 324 688
add 1 324 688
assign 1 324 689
add 1 324 689
assign 1 324 690
new 0 324 690
assign 1 324 691
add 1 324 691
return 1 324 692
return 1 0 695
assign 1 0 698
return 1 0 702
assign 1 0 705
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1417093983: return bem_secondsGet_0();
case 1823731495: return bem_fieldIteratorGet_0();
case 204512374: return bem_millisecondInSecondGet_0();
case 380917179: return bem_deserializeClassNameGet_0();
case 281324317: return bem_secondInMinuteGet_0();
case 2007419844: return bem_sourceFileNameGet_0();
case -1997732490: return bem_serializeToString_0();
case -288603233: return bem_serializationIteratorGet_0();
case -638967212: return bem_toStringMinutes_0();
case -486730947: return bem_tagGet_0();
case 626595477: return bem_now_0();
case 89921707: return bem_echo_0();
case -514090031: return bem_millisecondsGet_0();
case -2002314890: return bem_serializeContents_0();
case -706394436: return bem_classNameGet_0();
case 1488914380: return bem_toShortString_0();
case 386556779: return bem_minutesGet_0();
case -145517521: return bem_iteratorGet_0();
case 2032294801: return bem_secsGet_0();
case 991850509: return bem_hashGet_0();
case -438931987: return bem_many_0();
case -958900708: return bem_millisGet_0();
case 903380622: return bem_copy_0();
case 192353495: return bem_toString_0();
case -1418631127: return bem_carryMillis_0();
case 1071338406: return bem_once_0();
case 150815360: return bem_new_0();
case -610207516: return bem_print_0();
case 1733022581: return bem_create_0();
case 1222559837: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 568764092: return bem_equals_1(bevd_0);
case 2105286284: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1679724785: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1234343289: return bem_def_1(bevd_0);
case -174280441: return bem_otherClass_1(bevd_0);
case -2087149042: return bem_undefined_1(bevd_0);
case 698316509: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -177732522: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -636205640: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1042190914: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1653674736: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case -161041009: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case 1666513028: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 754254864: return bem_sameType_1(bevd_0);
case 1979056090: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1005524811: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1481781369: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 2089301310: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -226295549: return bem_sameClass_1(bevd_0);
case 270119730: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1885375667: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case -1328902619: return bem_secsSet_1(bevd_0);
case -907803894: return bem_otherType_1(bevd_0);
case 703194688: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case 438182014: return bem_millisSet_1(bevd_0);
case -1587661946: return bem_sameObject_1(bevd_0);
case 1702402169: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1326831061: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case -2038181641: return bem_copyTo_1(bevd_0);
case -2012166175: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1886873191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1951248711: return bem_defined_1(bevd_0);
case -1794454226: return bem_undef_1(bevd_0);
case -1741414758: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case -1812425724: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -862992684: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 608937217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 882374743: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1346377346: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1911273797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1789964230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2066895296: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1538374916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_TimeInterval_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_8_TimeInterval_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst = (BEC_2_4_8_TimeInterval) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst;
}
}
