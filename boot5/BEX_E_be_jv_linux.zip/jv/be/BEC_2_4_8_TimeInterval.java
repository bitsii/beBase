package be;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_BEC_2_4_8_TimeInterval_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_BEC_2_4_8_TimeInterval_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_3 = {0x3A};
public static BEC_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_inst;

public static BET_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_type;

public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt());
bevp_millis = (new BEC_2_4_3_MathInt());

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(60));
bevt_0_ta_ph = bevp_secs.bem_modulus_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(60));
bevt_0_ta_ph = bevp_secs.bem_divide_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(3600));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(86400));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(3600));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(86400));
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_ta_ph);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 250*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevt_4_ta_ph = bevp_millis.bem_divide_1(bevt_5_ta_ph);
bevp_secs = bevp_secs.bem_add_1(bevt_4_ta_ph);
bevp_millis = bevl_mmod;
} /* Line: 252*/
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_millis.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_secs.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 254*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 254*/
 else /* Line: 254*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 254*/ {
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevp_millis = bevt_11_ta_ph.bem_add_1(bevp_millis);
} /* Line: 256*/
 else /* Line: 254*/ {
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_millis.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 257*/ {
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_secs.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 257*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 257*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 257*/
 else /* Line: 257*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 257*/ {
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_secs = bevp_secs.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(1000));
bevt_17_ta_ph = bevt_18_ta_ph.bem_subtract_1(bevt_19_ta_ph);
bevp_millis = bevt_17_ta_ph.bem_add_1(bevp_millis);
} /* Line: 259*/
} /* Line: 254*/
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_ta_ph);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 289*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 289*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 289*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 289*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 289*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 289*/
 else /* Line: 289*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 289*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 289*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 289*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 289*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 290*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 296*/
 else /* Line: 296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 296*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 296*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 297*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 303*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 303*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 303*/
 else /* Line: 303*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 303*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 303*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 303*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 303*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 304*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_2_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 310*/ {
bevt_4_ta_ph = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 310*/ {
bevt_6_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 310*/
 else /* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 310*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 310*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 311*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevt_3_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameClass_2(this, beva_other);
if (bevt_2_ta_ph.bevi_bool)/* Line: 317*/ {
bevt_5_ta_ph = beva_other.bemd_0(-1172572823);
bevt_4_ta_ph = bevp_secs.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 317*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 317*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 317*/
 else /* Line: 317*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 317*/ {
bevt_7_ta_ph = beva_other.bemd_0(-1662126340);
bevt_6_ta_ph = bevp_millis.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 317*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 317*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 317*/
 else /* Line: 317*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 317*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_8_ta_ph;
} /* Line: 318*/
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevt_4_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_3_ta_ph = bevt_4_ta_ph.bem_sameClass_2(this, beva_other);
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 324*/ {
bevt_6_ta_ph = beva_other.bemd_0(-1172572823);
bevt_5_ta_ph = bevp_secs.bem_notEquals_1(bevt_6_ta_ph);
if (bevt_5_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 324*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 324*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 324*/ {
bevt_8_ta_ph = beva_other.bemd_0(-1662126340);
bevt_7_ta_ph = bevp_millis.bem_notEquals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 324*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 324*/ {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_9_ta_ph;
} /* Line: 325*/
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
if (beva_other == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 332*/
bevt_3_ta_ph = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_7_ta_ph = beva_other.bem_secsGet_0();
bevt_6_ta_ph = bevp_secs.bem_subtract_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_abs_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(3600));
if (bevt_5_ta_ph.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 334*/ {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_9_ta_ph;
} /* Line: 335*/
} /* Line: 334*/
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_6_ta_ph = bem_minutesGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_toString_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_4_8_TimeInterval_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bem_secondInMinuteGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_millis);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_2));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_2_ta_ph = bevp_secs.bem_toString_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_8_TimeInterval_bels_3));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_millis.bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_4_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_secs.bem_toString_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_1));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_millis);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_TimeInterval_bels_2));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {130, 131, 177, 178, 184, 185, 186, 190, 190, 194, 194, 194, 198, 202, 202, 202, 206, 210, 214, 218, 219, 223, 223, 223, 227, 227, 227, 231, 231, 231, 235, 235, 235, 240, 244, 245, 249, 249, 250, 250, 251, 251, 251, 252, 254, 254, 254, 254, 254, 254, 0, 0, 0, 255, 255, 256, 256, 257, 257, 257, 257, 257, 257, 0, 0, 0, 258, 258, 259, 259, 259, 259, 264, 268, 269, 273, 273, 274, 274, 275, 276, 277, 281, 281, 282, 282, 283, 284, 285, 289, 289, 289, 0, 289, 289, 289, 289, 289, 289, 0, 0, 0, 0, 0, 290, 290, 292, 292, 296, 296, 296, 0, 296, 296, 296, 296, 296, 296, 0, 0, 0, 0, 0, 297, 297, 299, 299, 303, 303, 303, 0, 303, 303, 303, 303, 303, 303, 0, 0, 0, 0, 0, 304, 304, 306, 306, 310, 310, 310, 0, 310, 310, 310, 310, 310, 310, 0, 0, 0, 0, 0, 311, 311, 313, 313, 317, 317, 317, 317, 0, 0, 0, 317, 317, 0, 0, 0, 318, 318, 320, 320, 324, 324, 324, 324, 0, 324, 324, 0, 0, 0, 324, 324, 0, 0, 325, 325, 327, 327, 332, 332, 332, 332, 333, 333, 333, 334, 334, 334, 334, 334, 334, 335, 335, 338, 338, 342, 342, 342, 342, 342, 342, 342, 342, 342, 342, 342, 342, 346, 346, 346, 346, 346, 346, 350, 350, 350, 350, 350, 350, 350, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 27, 28, 32, 33, 34, 39, 40, 45, 46, 47, 50, 55, 56, 57, 60, 63, 67, 70, 71, 77, 78, 79, 85, 86, 87, 93, 94, 95, 101, 102, 103, 107, 111, 112, 137, 138, 139, 144, 145, 146, 147, 148, 150, 151, 156, 157, 158, 163, 164, 167, 171, 174, 175, 176, 177, 180, 181, 186, 187, 188, 193, 194, 197, 201, 204, 205, 206, 207, 208, 209, 215, 219, 220, 229, 230, 231, 232, 233, 234, 235, 243, 244, 245, 246, 247, 248, 249, 261, 262, 267, 268, 271, 272, 277, 278, 279, 284, 285, 288, 292, 295, 298, 302, 303, 305, 306, 318, 319, 324, 325, 328, 329, 334, 335, 336, 341, 342, 345, 349, 352, 355, 359, 360, 362, 363, 375, 376, 381, 382, 385, 386, 391, 392, 393, 398, 399, 402, 406, 409, 412, 416, 417, 419, 420, 432, 433, 438, 439, 442, 443, 448, 449, 450, 455, 456, 459, 463, 466, 469, 473, 474, 476, 477, 490, 491, 493, 494, 496, 499, 503, 506, 507, 509, 512, 516, 519, 520, 522, 523, 537, 538, 539, 544, 545, 548, 549, 551, 554, 558, 561, 562, 564, 567, 571, 572, 574, 575, 589, 594, 595, 596, 598, 599, 604, 605, 606, 607, 608, 609, 614, 615, 616, 619, 620, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 653, 654, 655, 656, 657, 658, 667, 668, 669, 670, 671, 672, 673, 676, 679, 683, 686};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 130 18
new 0 130 18
assign 1 131 19
new 0 131 19
assign 1 177 27
new 0 177 27
assign 1 178 28
new 0 178 28
assign 1 184 32
assign 1 185 33
carryMillis 0 186 34
assign 1 190 39
new 2 190 39
return 1 190 40
assign 1 194 45
new 0 194 45
assign 1 194 46
modulus 1 194 46
return 1 194 47
return 1 198 50
assign 1 202 55
new 0 202 55
assign 1 202 56
divide 1 202 56
return 1 202 57
return 1 206 60
assign 1 210 63
return 1 214 67
assign 1 218 70
carryMillis 0 219 71
assign 1 223 77
new 0 223 77
assign 1 223 78
multiply 1 223 78
assign 1 223 79
add 1 223 79
assign 1 227 85
new 0 227 85
assign 1 227 86
multiply 1 227 86
assign 1 227 87
add 1 227 87
assign 1 231 93
new 0 231 93
assign 1 231 94
multiply 1 231 94
assign 1 231 95
subtract 1 231 95
assign 1 235 101
new 0 235 101
assign 1 235 102
multiply 1 235 102
assign 1 235 103
subtract 1 235 103
assign 1 240 107
add 1 240 107
assign 1 244 111
add 1 244 111
carryMillis 0 245 112
assign 1 249 137
new 0 249 137
assign 1 249 138
modulus 1 249 138
assign 1 250 139
notEquals 1 250 144
assign 1 251 145
new 0 251 145
assign 1 251 146
divide 1 251 146
assign 1 251 147
add 1 251 147
assign 1 252 148
assign 1 254 150
new 0 254 150
assign 1 254 151
lesser 1 254 156
assign 1 254 157
new 0 254 157
assign 1 254 158
greater 1 254 163
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 255 174
new 0 255 174
assign 1 255 175
subtract 1 255 175
assign 1 256 176
new 0 256 176
assign 1 256 177
add 1 256 177
assign 1 257 180
new 0 257 180
assign 1 257 181
greater 1 257 186
assign 1 257 187
new 0 257 187
assign 1 257 188
lesser 1 257 193
assign 1 0 194
assign 1 0 197
assign 1 0 201
assign 1 258 204
new 0 258 204
assign 1 258 205
add 1 258 205
assign 1 259 206
new 0 259 206
assign 1 259 207
new 0 259 207
assign 1 259 208
subtract 1 259 208
assign 1 259 209
add 1 259 209
assign 1 264 215
subtract 1 264 215
assign 1 268 219
subtract 1 268 219
carryMillis 0 269 220
assign 1 273 229
secsGet 0 273 229
assign 1 273 230
add 1 273 230
assign 1 274 231
millisGet 0 274 231
assign 1 274 232
add 1 274 232
assign 1 275 233
new 2 275 233
carryMillis 0 276 234
return 1 277 235
assign 1 281 243
secsGet 0 281 243
assign 1 281 244
subtract 1 281 244
assign 1 282 245
millisGet 0 282 245
assign 1 282 246
subtract 1 282 246
assign 1 283 247
new 2 283 247
carryMillis 0 284 248
return 1 285 249
assign 1 289 261
secsGet 0 289 261
assign 1 289 262
greater 1 289 267
assign 1 0 268
assign 1 289 271
secsGet 0 289 271
assign 1 289 272
equals 1 289 277
assign 1 289 278
millisGet 0 289 278
assign 1 289 279
greater 1 289 284
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 0 295
assign 1 0 298
assign 1 290 302
new 0 290 302
return 1 290 303
assign 1 292 305
new 0 292 305
return 1 292 306
assign 1 296 318
secsGet 0 296 318
assign 1 296 319
lesser 1 296 324
assign 1 0 325
assign 1 296 328
secsGet 0 296 328
assign 1 296 329
equals 1 296 334
assign 1 296 335
millisGet 0 296 335
assign 1 296 336
lesser 1 296 341
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 0 352
assign 1 0 355
assign 1 297 359
new 0 297 359
return 1 297 360
assign 1 299 362
new 0 299 362
return 1 299 363
assign 1 303 375
secsGet 0 303 375
assign 1 303 376
greaterEquals 1 303 381
assign 1 0 382
assign 1 303 385
secsGet 0 303 385
assign 1 303 386
equals 1 303 391
assign 1 303 392
millisGet 0 303 392
assign 1 303 393
greaterEquals 1 303 398
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 0 409
assign 1 0 412
assign 1 304 416
new 0 304 416
return 1 304 417
assign 1 306 419
new 0 306 419
return 1 306 420
assign 1 310 432
secsGet 0 310 432
assign 1 310 433
lesserEquals 1 310 438
assign 1 0 439
assign 1 310 442
secsGet 0 310 442
assign 1 310 443
equals 1 310 448
assign 1 310 449
millisGet 0 310 449
assign 1 310 450
lesserEquals 1 310 455
assign 1 0 456
assign 1 0 459
assign 1 0 463
assign 1 0 466
assign 1 0 469
assign 1 311 473
new 0 311 473
return 1 311 474
assign 1 313 476
new 0 313 476
return 1 313 477
assign 1 317 490
new 0 317 490
assign 1 317 491
sameClass 2 317 491
assign 1 317 493
secsGet 0 317 493
assign 1 317 494
equals 1 317 494
assign 1 0 496
assign 1 0 499
assign 1 0 503
assign 1 317 506
millisGet 0 317 506
assign 1 317 507
equals 1 317 507
assign 1 0 509
assign 1 0 512
assign 1 0 516
assign 1 318 519
new 0 318 519
return 1 318 520
assign 1 320 522
new 0 320 522
return 1 320 523
assign 1 324 537
new 0 324 537
assign 1 324 538
sameClass 2 324 538
assign 1 324 539
not 0 324 544
assign 1 0 545
assign 1 324 548
secsGet 0 324 548
assign 1 324 549
notEquals 1 324 549
assign 1 0 551
assign 1 0 554
assign 1 0 558
assign 1 324 561
millisGet 0 324 561
assign 1 324 562
notEquals 1 324 562
assign 1 0 564
assign 1 0 567
assign 1 325 571
new 0 325 571
return 1 325 572
assign 1 327 574
new 0 327 574
return 1 327 575
assign 1 332 589
undef 1 332 594
assign 1 332 595
new 0 332 595
return 1 332 596
assign 1 333 598
millisGet 0 333 598
assign 1 333 599
equals 1 333 604
assign 1 334 605
secsGet 0 334 605
assign 1 334 606
subtract 1 334 606
assign 1 334 607
abs 0 334 607
assign 1 334 608
new 0 334 608
assign 1 334 609
equals 1 334 614
assign 1 335 615
new 0 335 615
return 1 335 616
assign 1 338 619
new 0 338 619
return 1 338 620
assign 1 342 634
minutesGet 0 342 634
assign 1 342 635
toString 0 342 635
assign 1 342 636
new 0 342 636
assign 1 342 637
add 1 342 637
assign 1 342 638
secondInMinuteGet 0 342 638
assign 1 342 639
add 1 342 639
assign 1 342 640
new 0 342 640
assign 1 342 641
add 1 342 641
assign 1 342 642
add 1 342 642
assign 1 342 643
new 0 342 643
assign 1 342 644
add 1 342 644
return 1 342 645
assign 1 346 653
toString 0 346 653
assign 1 346 654
new 0 346 654
assign 1 346 655
add 1 346 655
assign 1 346 656
toString 0 346 656
assign 1 346 657
add 1 346 657
return 1 346 658
assign 1 350 667
toString 0 350 667
assign 1 350 668
new 0 350 668
assign 1 350 669
add 1 350 669
assign 1 350 670
add 1 350 670
assign 1 350 671
new 0 350 671
assign 1 350 672
add 1 350 672
return 1 350 673
return 1 0 676
assign 1 0 679
return 1 0 683
assign 1 0 686
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 912871340: return bem_toString_0();
case 1448984271: return bem_create_0();
case 633682209: return bem_print_0();
case -87056108: return bem_new_0();
case -1166859559: return bem_iteratorGet_0();
case 464153971: return bem_millisecondsGet_0();
case 42959886: return bem_millisecondInSecondGet_0();
case 1498858737: return bem_secondInMinuteGet_0();
case 1411912267: return bem_toShortString_0();
case 561351745: return bem_secondsGet_0();
case -1662126340: return bem_millisGet_0();
case 476934751: return bem_copy_0();
case -1214473047: return bem_now_0();
case -1334690418: return bem_minutesGet_0();
case -1172572823: return bem_secsGet_0();
case 282508897: return bem_toStringMinutes_0();
case 240608295: return bem_carryMillis_0();
case -1450568577: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -275300217: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1486086431: return bem_equals_1(bevd_0);
case 381130981: return bem_copyTo_1(bevd_0);
case 2106618550: return bem_def_1(bevd_0);
case 106716749: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case -889777051: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 1486899938: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 632393370: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1368220437: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1689435007: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1382954464: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case 559926438: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -162318286: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -290342100: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1666157183: return bem_millisSet_1(bevd_0);
case -92118812: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1089041118: return bem_undef_1(bevd_0);
case 911847688: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case -1896596601: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case 1822740278: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case -1076047891: return bem_notEquals_1(bevd_0);
case -647439812: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 514358492: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1707461692: return bem_secsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1900258780: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 551846529: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1341903525: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -658194391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -64978042: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_TimeInterval_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_8_TimeInterval_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst = (BEC_2_4_8_TimeInterval) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_type;
}
}
