package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileReader extends BEC_2_2_6_IOReader {
public BEC_3_2_4_6_IOFileReader() { }
private static byte[] becc_BEC_3_2_4_6_IOFileReader_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileReader_bels_0 = {0x46,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileReader_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileReader_bels_0, 5));
private static byte[] bece_BEC_3_2_4_6_IOFileReader_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileReader_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileReader_bels_1, 30));
public static BEC_3_2_4_6_IOFileReader bece_BEC_3_2_4_6_IOFileReader_bevs_inst;
public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bem_new_0();
bevp_blockSize = (new BEC_2_4_3_MathInt(1024));
bevt_0_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_open_0() throws Throwable {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_fhpatha = bevp_path.bem_toString_0();

      if (this.bevi_is == null) {
        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        this.bevi_is = new java.io.FileInputStream(bevls_f);
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      if (bevp_isClosed == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
if (bevp_isClosed.bevi_bool) /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 129 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 129 */ {
bevt_5_tmpany_phold = bece_BEC_3_2_4_6_IOFileReader_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_fhpatha);
bevt_6_tmpany_phold = bece_BEC_3_2_4_6_IOFileReader_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 130 */
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {64, 65, 69, 69, 84, 129, 129, 0, 0, 0, 130, 130, 130, 130, 130, 130, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 18, 31, 38, 43, 44, 48, 51, 55, 56, 57, 58, 59, 60, 65, 68};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 64 15
assign 1 65 16
new 0 65 16
assign 1 69 17
new 1 69 17
pathSet 1 69 18
assign 1 84 31
toString 0 84 31
assign 1 129 38
undef 1 129 43
assign 1 0 44
assign 1 0 48
assign 1 0 51
assign 1 130 55
new 0 130 55
assign 1 130 56
add 1 130 56
assign 1 130 57
new 0 130 57
assign 1 130 58
add 1 130 58
assign 1 130 59
new 1 130 59
throw 1 130 60
return 1 0 65
assign 1 0 68
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -145312000: return bem_serializationIteratorGet_0();
case -471069010: return bem_byteReaderGet_0();
case 1994019235: return bem_readString_0();
case -176876439: return bem_fieldIteratorGet_0();
case 904467476: return bem_create_0();
case -536392639: return bem_readBuffer_0();
case -629628110: return bem_toAny_0();
case 714053375: return bem_many_0();
case -820547047: return bem_new_0();
case -1934799675: return bem_blockSizeGet_0();
case -131080468: return bem_print_0();
case -164764904: return bem_close_0();
case -1239151636: return bem_sourceFileNameGet_0();
case -863935940: return bem_copy_0();
case 1030499827: return bem_iteratorGet_0();
case 250853259: return bem_readStringClose_0();
case 865364657: return bem_serializeContents_0();
case -1098281100: return bem_open_0();
case -1895992021: return bem_deserializeClassNameGet_0();
case -209199098: return bem_pathGet_0();
case 1021615634: return bem_classNameGet_0();
case 618874537: return bem_extOpen_0();
case -316245103: return bem_echo_0();
case 521055509: return bem_serializeToString_0();
case -1196329855: return bem_tagGet_0();
case -1382553323: return bem_readBufferLine_0();
case 1797341089: return bem_once_0();
case -1245364015: return bem_vfileGet_0();
case -1987686796: return bem_isClosedGet_0();
case 269723613: return bem_hashGet_0();
case 657801083: return bem_toString_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 824474007: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 1808338509: return bem_def_1(bevd_0);
case 681555470: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -395912199: return bem_blockSizeSet_1(bevd_0);
case 544484580: return bem_defined_1(bevd_0);
case -455244874: return bem_undefined_1(bevd_0);
case 1354444477: return bem_undef_1(bevd_0);
case 779198300: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2063004658: return bem_sameType_1(bevd_0);
case 218874128: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1584774500: return bem_sameClass_1(bevd_0);
case 566034428: return bem_new_1(bevd_0);
case 893848745: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -2077589897: return bem_pathSet_1(bevd_0);
case 16358816: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1074673344: return bem_copyTo_1(bevd_0);
case 153472398: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1693196376: return bem_otherType_1(bevd_0);
case -357900787: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 788271940: return bem_sameObject_1(bevd_0);
case -560471223: return bem_otherClass_1(bevd_0);
case -638948011: return bem_isClosedSet_1(bevd_0);
case -1121832638: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 80790810: return bem_notEquals_1(bevd_0);
case 2094019215: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 2016817692: return bem_equals_1(bevd_0);
case -1488698672: return bem_vfileSet_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 1717153666: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 423661912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 338963035: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -236631668: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -539434931: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 901264448: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 883042907: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -884026318: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callCase) {
case 451594861: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1263856480: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callCase, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_6_IOFileReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_6_IOFileReader.bece_BEC_3_2_4_6_IOFileReader_bevs_inst = (BEC_3_2_4_6_IOFileReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_6_IOFileReader.bece_BEC_3_2_4_6_IOFileReader_bevs_inst;
}
}
