package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_6_BuildVisitRewind extends BEC_3_5_5_9_BuildVisitChkIfEmit {
public BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
public static BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;

public static BET_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;

public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_3_5_5_6_BuildVisitRewind bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_BuildNode bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_5_4_BuildNode bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_38_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_5_4_LogicBool bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_5_4_LogicBool bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_5_4_BuildNode bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_5_4_BuildNode bevt_83_ta_ph = null;
BEC_2_5_4_BuildNode bevt_84_ta_ph = null;
BEC_2_5_4_LogicBool bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_5_4_BuildNode bevt_87_ta_ph = null;
BEC_2_5_4_BuildNode bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_5_4_BuildNode bevt_90_ta_ph = null;
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 301*/ {
bevt_11_ta_ph = bem_acceptIfEmit_1(beva_node);
return (BEC_2_5_4_BuildNode) bevt_11_ta_ph;
} /* Line: 302*/
bevt_13_ta_ph = beva_node.bem_typenameGet_0();
bevt_14_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_13_ta_ph.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 304*/ {
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-658618520);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 304*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 304*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 304*/
 else /* Line: 304*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 304*/ {
bevt_19_ta_ph = beva_node.bem_containerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bem_typenameGet_0();
bevt_20_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_18_ta_ph.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_24_ta_ph = beva_node.bem_containerGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(1705233059);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1697701048, bevt_25_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 306*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 306*/ {
bevt_26_ta_ph = beva_node.bem_isSecondGet_0();
if (bevt_26_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 306*/ {
bevt_30_ta_ph = beva_node.bem_containedGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bem_firstGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-242105057);
bevt_31_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_27_ta_ph = bevt_28_ta_ph.bemd_1(1697701048, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_27_ta_ph).bevi_bool)/* Line: 308*/ {
bevt_35_ta_ph = beva_node.bem_containedGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_firstGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bemd_0(-1267820640);
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(-1244949784);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 308*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 308*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 308*/
 else /* Line: 308*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 308*/ {
bevt_38_ta_ph = beva_node.bem_containedGet_0();
bevt_37_ta_ph = bevt_38_ta_ph.bem_firstGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(-1267820640);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_36_ta_ph.bemd_0(-2098903205);
bevt_39_ta_ph = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_39_ta_ph.bem_lastGet_0();
bevt_43_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_44_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_42_ta_ph = bevl_fgcn.bem_substring_2(bevt_43_ta_ph, bevt_44_ta_ph);
bevt_41_ta_ph = bevt_42_ta_ph.bem_lowerValue_0();
bevt_46_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_45_ta_ph = bevl_fgcn.bem_substring_1(bevt_46_ta_ph);
bevt_40_ta_ph = bevt_41_ta_ph.bem_add_1(bevt_45_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_6_BuildVisitRewind_bels_1));
bevl_fgin = bevt_40_ta_ph.bem_add_1(bevt_47_ta_ph);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_48_ta_ph = bevl_fgsy.bem_mtdMapGet_0();
bevt_50_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitRewind_bels_2));
bevt_49_ta_ph = bevl_fgin.bem_add_1(bevt_50_ta_ph);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_48_ta_ph.bem_get_1(bevt_49_ta_ph);
if (bevl_fgms == null) {
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 315*/ {
bevt_52_ta_ph = beva_node.bem_heldGet_0();
bevt_52_ta_ph.bemd_1(663448890, bevl_fgin);
bevt_53_ta_ph = beva_node.bem_heldGet_0();
bevt_55_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitRewind_bels_2));
bevt_54_ta_ph = bevl_fgin.bem_add_1(bevt_55_ta_ph);
bevt_53_ta_ph.bemd_1(-8200109, bevt_54_ta_ph);
} /* Line: 318*/
} /* Line: 315*/
} /* Line: 308*/
} /* Line: 306*/
bevt_57_ta_ph = beva_node.bem_typenameGet_0();
bevt_58_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_57_ta_ph.bevi_int == bevt_58_ta_ph.bevi_int) {
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 323*/ {
bevp_inClass = beva_node;
bevt_59_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_59_ta_ph.bemd_0(-2098903205);
bevt_60_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_60_ta_ph.bemd_0(1606718878);
} /* Line: 326*/
bevt_62_ta_ph = beva_node.bem_typenameGet_0();
bevt_63_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_62_ta_ph.bevi_int == bevt_63_ta_ph.bevi_int) {
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_61_ta_ph.bevi_bool)/* Line: 328*/ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 330*/
 else /* Line: 328*/ {
bevt_65_ta_ph = beva_node.bem_typenameGet_0();
bevt_66_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_65_ta_ph.bevi_int == bevt_66_ta_ph.bevi_int) {
bevt_64_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_64_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_68_ta_ph = beva_node.bem_heldGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bemd_0(1017538510);
if (((BEC_2_5_4_LogicBool) bevt_67_ta_ph).bevi_bool)/* Line: 331*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 331*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 331*/
 else /* Line: 331*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 331*/ {
bevt_70_ta_ph = beva_node.bem_heldGet_0();
bevt_69_ta_ph = bevt_70_ta_ph.bemd_0(-1091310538);
bevt_71_ta_ph = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(-1515485282, bevt_69_ta_ph, bevt_71_ta_ph);
bevt_73_ta_ph = beva_node.bem_heldGet_0();
bevt_72_ta_ph = bevt_73_ta_ph.bemd_0(-1091310538);
bevl_ll = bevp_rmap.bemd_1(-1790237460, bevt_72_ta_ph);
if (bevl_ll == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 334*/ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_76_ta_ph = beva_node.bem_heldGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bemd_0(-1091310538);
bevp_rmap.bemd_2(-1515485282, bevt_75_ta_ph, bevl_ll);
} /* Line: 336*/
bevl_ll.bemd_1(26739735, beva_node);
} /* Line: 338*/
 else /* Line: 328*/ {
bevt_78_ta_ph = beva_node.bem_typenameGet_0();
bevt_79_ta_ph = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_78_ta_ph.bevi_int == bevt_79_ta_ph.bevi_int) {
bevt_77_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_77_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_77_ta_ph.bevi_bool)/* Line: 339*/ {
bevt_81_ta_ph = beva_node.bem_containerGet_0();
if (bevt_81_ta_ph == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 339*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 339*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 339*/
 else /* Line: 339*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 339*/ {
bevt_84_ta_ph = beva_node.bem_containerGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bem_containerGet_0();
if (bevt_83_ta_ph == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 339*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 339*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 339*/
 else /* Line: 339*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 339*/ {
bevt_88_ta_ph = beva_node.bem_containerGet_0();
bevt_87_ta_ph = bevt_88_ta_ph.bem_containerGet_0();
bevt_86_ta_ph = bevt_87_ta_ph.bem_typenameGet_0();
bevt_89_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_86_ta_ph.bevi_int == bevt_89_ta_ph.bevi_int) {
bevt_85_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_85_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_85_ta_ph.bevi_bool)/* Line: 339*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 339*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 339*/
 else /* Line: 339*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 339*/ {
bem_processTmps_0();
} /* Line: 341*/
} /* Line: 328*/
} /* Line: 328*/
bevt_90_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_90_ta_ph;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_5_4_LogicBool bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_6_6_SystemObject bevt_84_ta_ph = null;
BEC_2_6_6_SystemObject bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_6_6_SystemObject bevt_87_ta_ph = null;
BEC_2_6_6_SystemObject bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_6_6_SystemObject bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
/* Line: 355*/ {
if (((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool)/* Line: 355*/ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(-1320980689);
while (true)
/* Line: 357*/ {
bevt_9_ta_ph = bevl_i.bemd_0(-762739989);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 357*/ {
bevl_nv = bevl_i.bemd_0(-1609028545);
bevt_11_ta_ph = bevl_nv.bemd_0(-1244949784);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(599156039);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 360*/ {
bevl_nvname = bevl_nv.bemd_0(-1091310538);
bevl_ll = bevp_rmap.bemd_1(-1790237460, bevl_nvname);
bevt_0_ta_loop = bevl_ll.bemd_0(764459509);
while (true)
/* Line: 365*/ {
bevt_12_ta_ph = bevt_0_ta_loop.bemd_0(-762739989);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 365*/ {
bevl_k = bevt_0_ta_loop.bemd_0(-1609028545);
bevt_13_ta_ph = bevl_k.bemd_0(-1486583691);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 366*/ {
bevt_16_ta_ph = bevl_k.bemd_0(927489489);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-242105057);
bevt_17_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bemd_1(1697701048, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 366*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 366*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 366*/
 else /* Line: 366*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 366*/ {
bevt_21_ta_ph = bevl_k.bemd_0(927489489);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(-1267820640);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(1705233059);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(1697701048, bevt_22_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 366*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 366*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 366*/
 else /* Line: 366*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 366*/ {
bevt_26_ta_ph = bevl_k.bemd_0(927489489);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(1876299022);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(-242105057);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(1697701048, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 366*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 366*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 366*/
 else /* Line: 366*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 366*/ {
bevt_28_ta_ph = bevl_k.bemd_0(927489489);
bevl_tcall = bevt_28_ta_ph.bemd_0(1876299022);
bevl_targNp = null;
bevt_31_ta_ph = bevl_tcall.bemd_0(-1267820640);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(421881896);
if (bevt_30_ta_ph == null) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 370*/ {
bevt_32_ta_ph = bevl_tcall.bemd_0(-1267820640);
bevl_targNp = bevt_32_ta_ph.bemd_0(421881896);
} /* Line: 371*/
 else /* Line: 372*/ {
bevt_33_ta_ph = bevl_tcall.bemd_0(-650290602);
bevl_targ = bevt_33_ta_ph.bemd_0(-1362641624);
bevt_35_ta_ph = bevl_targ.bemd_0(-1267820640);
bevt_34_ta_ph = bevt_35_ta_ph.bemd_0(-219921053);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 374*/ {
bevl_tany = bevl_targ.bemd_0(-1267820640);
} /* Line: 375*/
 else /* Line: 376*/ {
bevt_37_ta_ph = bevp_inClassSyn.bemd_0(-1905982645);
bevt_39_ta_ph = bevl_targ.bemd_0(-1267820640);
bevt_38_ta_ph = bevt_39_ta_ph.bemd_0(-1091310538);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_1(-1790237460, bevt_38_ta_ph);
bevl_tany = bevt_36_ta_ph.bemd_0(-1408087566);
} /* Line: 377*/
bevt_40_ta_ph = bevl_tany.bemd_0(-1244949784);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 380*/ {
bevl_targNp = bevl_tany.bemd_0(-2098903205);
} /* Line: 381*/
} /* Line: 380*/
if (bevl_targNp == null) {
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 384*/ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_44_ta_ph = bevl_tcall.bemd_0(-1267820640);
bevt_43_ta_ph = bevt_44_ta_ph.bemd_0(-1091310538);
bevl_mtdc = bevt_42_ta_ph.bem_get_1(bevt_43_ta_ph);
if (bevl_mtdc == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 388*/ {
bevl_oany = bevl_mtdc.bemd_0(-458353448);
if (bevl_oany == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 391*/ {
bevt_47_ta_ph = bevl_oany.bemd_0(-1244949784);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 391*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 391*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 391*/
 else /* Line: 391*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 391*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_ta_ph = bevl_oany.bemd_0(1884923778);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 394*/ {
bevl_nv.bemd_1(-1952979513, bevl_targNp);
} /* Line: 395*/
 else /* Line: 396*/ {
bevt_49_ta_ph = bevl_oany.bemd_0(-2098903205);
bevl_nv.bemd_1(-1952979513, bevt_49_ta_ph);
} /* Line: 397*/
bevt_50_ta_ph = bevl_oany.bemd_0(-1244949784);
bevl_nv.bemd_1(1330095856, bevt_50_ta_ph);
bevt_51_ta_ph = bevp_inClass.bemd_0(-1267820640);
bevt_52_ta_ph = bevl_nv.bemd_0(-2098903205);
bevt_51_ta_ph.bemd_1(597146770, bevt_52_ta_ph);
bevt_55_ta_ph = bevl_nv.bemd_0(-2098903205);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(1818335248);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_3));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(1697701048, bevt_56_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 401*/ {
bevt_58_ta_ph = (new BEC_2_4_6_TextString(27, bece_BEC_3_5_5_6_BuildVisitRewind_bels_4));
bevt_59_ta_ph = bevl_oany.bemd_0(1884923778);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevt_59_ta_ph);
bevt_57_ta_ph.bem_print_0();
} /* Line: 401*/
} /* Line: 401*/
} /* Line: 391*/
 else /* Line: 388*/ {
bevt_62_ta_ph = bevl_tcall.bemd_0(-1267820640);
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(1705233059);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_60_ta_ph = bevt_61_ta_ph.bemd_1(1782625331, bevt_63_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_60_ta_ph).bevi_bool)/* Line: 403*/ {
bevt_64_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_6_BuildVisitRewind_bels_6));
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_ta_ph.bem_get_1(bevt_65_ta_ph);
if (bevl_fcms == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 405*/ {
bevt_69_ta_ph = bevl_fcms.bem_originGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_toString_0();
bevt_70_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_6_BuildVisitRewind_bels_7));
bevt_67_ta_ph = bevt_68_ta_ph.bem_notEquals_1(bevt_70_ta_ph);
if (bevt_67_ta_ph.bevi_bool)/* Line: 405*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 405*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 405*/
 else /* Line: 405*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 405*/ {
bevt_71_ta_ph = bevl_tcall.bemd_0(-1267820640);
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
bevt_71_ta_ph.bemd_1(-996141531, bevt_72_ta_ph);
} /* Line: 406*/
 else /* Line: 407*/ {
bevt_77_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_3_5_5_6_BuildVisitRewind_bels_8));
bevt_79_ta_ph = bevl_tcall.bemd_0(-1267820640);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(-1091310538);
bevt_76_ta_ph = bevt_77_ta_ph.bem_add_1(bevt_78_ta_ph);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitRewind_bels_9));
bevt_75_ta_ph = bevt_76_ta_ph.bem_add_1(bevt_80_ta_ph);
bevt_81_ta_ph = bevl_targNp.bemd_0(1818335248);
bevt_74_ta_ph = bevt_75_ta_ph.bem_add_1(bevt_81_ta_ph);
bevt_73_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_ta_ph, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_ta_ph);
} /* Line: 408*/
} /* Line: 405*/
} /* Line: 388*/
} /* Line: 388*/
} /* Line: 384*/
 else /* Line: 366*/ {
bevt_82_ta_ph = bevl_k.bemd_0(-1486583691);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 414*/ {
bevt_85_ta_ph = bevl_k.bemd_0(927489489);
bevt_84_ta_ph = bevt_85_ta_ph.bemd_0(-242105057);
bevt_86_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bemd_1(1697701048, bevt_86_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_83_ta_ph).bevi_bool)/* Line: 414*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 414*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 414*/
 else /* Line: 414*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 414*/ {
bevt_90_ta_ph = bevl_k.bemd_0(927489489);
bevt_89_ta_ph = bevt_90_ta_ph.bemd_0(-1267820640);
bevt_88_ta_ph = bevt_89_ta_ph.bemd_0(1705233059);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_87_ta_ph = bevt_88_ta_ph.bemd_1(1697701048, bevt_91_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_87_ta_ph).bevi_bool)/* Line: 414*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 414*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 414*/
 else /* Line: 414*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 414*/ {
bevt_95_ta_ph = bevl_k.bemd_0(927489489);
bevt_94_ta_ph = bevt_95_ta_ph.bemd_0(1876299022);
bevt_93_ta_ph = bevt_94_ta_ph.bemd_0(-242105057);
bevt_96_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_92_ta_ph = bevt_93_ta_ph.bemd_1(1697701048, bevt_96_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_92_ta_ph).bevi_bool)/* Line: 414*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 414*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 414*/
 else /* Line: 414*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 414*/ {
bevt_98_ta_ph = bevl_k.bemd_0(927489489);
bevt_97_ta_ph = bevt_98_ta_ph.bemd_0(1876299022);
bevl_targ = bevt_97_ta_ph.bemd_0(-1267820640);
bevt_99_ta_ph = bevl_targ.bemd_0(-1244949784);
if (((BEC_2_5_4_LogicBool) bevt_99_ta_ph).bevi_bool)/* Line: 417*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_ta_ph = bevl_targ.bemd_0(-1244949784);
bevl_nv.bemd_1(1330095856, bevt_100_ta_ph);
bevt_101_ta_ph = bevl_targ.bemd_0(-2098903205);
bevl_nv.bemd_1(-1952979513, bevt_101_ta_ph);
} /* Line: 422*/
} /* Line: 417*/
} /* Line: 366*/
} /* Line: 366*/
 else /* Line: 365*/ {
break;
} /* Line: 365*/
} /* Line: 365*/
} /* Line: 365*/
} /* Line: 360*/
 else /* Line: 357*/ {
break;
} /* Line: 357*/
} /* Line: 357*/
} /* Line: 357*/
 else /* Line: 355*/ {
break;
} /* Line: 355*/
} /* Line: 355*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tvmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClass = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nl = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {301, 301, 301, 301, 302, 302, 304, 304, 304, 304, 304, 304, 0, 0, 0, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 0, 0, 0, 306, 0, 0, 0, 308, 308, 308, 308, 308, 308, 308, 308, 308, 0, 0, 0, 309, 309, 309, 309, 310, 310, 311, 311, 311, 311, 311, 311, 311, 311, 311, 313, 314, 314, 314, 314, 315, 315, 317, 317, 318, 318, 318, 318, 323, 323, 323, 323, 324, 325, 325, 326, 326, 328, 328, 328, 328, 329, 330, 331, 331, 331, 331, 331, 331, 0, 0, 0, 332, 332, 332, 332, 333, 333, 333, 334, 334, 335, 336, 336, 336, 338, 339, 339, 339, 339, 339, 339, 339, 0, 0, 0, 339, 339, 339, 339, 0, 0, 0, 339, 339, 339, 339, 339, 339, 0, 0, 0, 341, 343, 343, 347, 356, 357, 357, 358, 360, 360, 363, 364, 365, 0, 365, 365, 366, 366, 366, 366, 366, 0, 0, 0, 366, 366, 366, 366, 366, 0, 0, 0, 366, 366, 366, 366, 366, 0, 0, 0, 368, 368, 369, 370, 370, 370, 370, 371, 371, 373, 373, 374, 374, 375, 377, 377, 377, 377, 377, 380, 381, 384, 384, 386, 387, 387, 387, 387, 388, 388, 390, 391, 391, 391, 0, 0, 0, 392, 394, 395, 397, 397, 399, 399, 400, 400, 400, 401, 401, 401, 401, 401, 401, 401, 401, 403, 403, 403, 403, 404, 404, 404, 405, 405, 405, 405, 405, 405, 0, 0, 0, 406, 406, 406, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 414, 414, 414, 414, 414, 0, 0, 0, 414, 414, 414, 414, 414, 0, 0, 0, 414, 414, 414, 414, 414, 0, 0, 0, 415, 415, 415, 417, 419, 421, 421, 422, 422, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {129, 130, 131, 136, 137, 138, 140, 141, 142, 147, 148, 149, 151, 154, 158, 161, 162, 163, 164, 169, 170, 171, 172, 173, 174, 176, 179, 183, 186, 188, 191, 195, 198, 199, 200, 201, 202, 204, 205, 206, 207, 209, 212, 216, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 244, 245, 246, 247, 248, 249, 250, 255, 256, 257, 262, 263, 264, 265, 266, 267, 269, 270, 271, 276, 277, 278, 281, 282, 283, 288, 289, 290, 292, 295, 299, 302, 303, 304, 305, 306, 307, 308, 309, 314, 315, 316, 317, 318, 320, 323, 324, 325, 330, 331, 332, 337, 338, 341, 345, 348, 349, 350, 355, 356, 359, 363, 366, 367, 368, 369, 370, 375, 376, 379, 383, 386, 390, 391, 510, 514, 515, 518, 520, 521, 522, 524, 525, 526, 526, 529, 531, 532, 534, 535, 536, 537, 539, 542, 546, 549, 550, 551, 552, 553, 555, 558, 562, 565, 566, 567, 568, 569, 571, 574, 578, 581, 582, 583, 584, 585, 586, 591, 592, 593, 596, 597, 598, 599, 601, 604, 605, 606, 607, 608, 610, 612, 615, 620, 621, 622, 623, 624, 625, 626, 631, 632, 633, 638, 639, 641, 644, 648, 651, 652, 654, 657, 658, 660, 661, 662, 663, 664, 665, 666, 667, 668, 670, 671, 672, 673, 678, 679, 680, 681, 683, 684, 685, 686, 691, 692, 693, 694, 695, 697, 700, 704, 707, 708, 709, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 728, 730, 731, 732, 733, 735, 738, 742, 745, 746, 747, 748, 749, 751, 754, 758, 761, 762, 763, 764, 765, 767, 770, 774, 777, 778, 779, 780, 782, 783, 784, 785, 786, 809, 812, 816, 819, 823, 826, 830, 833, 837, 840, 844, 847, 851, 854};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 301 129
typenameGet 0 301 129
assign 1 301 130
IFEMITGet 0 301 130
assign 1 301 131
equals 1 301 136
assign 1 302 137
acceptIfEmit 1 302 137
return 1 302 138
assign 1 304 140
typenameGet 0 304 140
assign 1 304 141
CALLGet 0 304 141
assign 1 304 142
equals 1 304 147
assign 1 304 148
heldGet 0 304 148
assign 1 304 149
wasForeachGennedGet 0 304 149
assign 1 0 151
assign 1 0 154
assign 1 0 158
assign 1 306 161
containerGet 0 306 161
assign 1 306 162
typenameGet 0 306 162
assign 1 306 163
CALLGet 0 306 163
assign 1 306 164
equals 1 306 169
assign 1 306 170
containerGet 0 306 170
assign 1 306 171
heldGet 0 306 171
assign 1 306 172
orgNameGet 0 306 172
assign 1 306 173
new 0 306 173
assign 1 306 174
equals 1 306 174
assign 1 0 176
assign 1 0 179
assign 1 0 183
assign 1 306 186
isSecondGet 0 306 186
assign 1 0 188
assign 1 0 191
assign 1 0 195
assign 1 308 198
containedGet 0 308 198
assign 1 308 199
firstGet 0 308 199
assign 1 308 200
typenameGet 0 308 200
assign 1 308 201
VARGet 0 308 201
assign 1 308 202
equals 1 308 202
assign 1 308 204
containedGet 0 308 204
assign 1 308 205
firstGet 0 308 205
assign 1 308 206
heldGet 0 308 206
assign 1 308 207
isTypedGet 0 308 207
assign 1 0 209
assign 1 0 212
assign 1 0 216
assign 1 309 219
containedGet 0 309 219
assign 1 309 220
firstGet 0 309 220
assign 1 309 221
heldGet 0 309 221
assign 1 309 222
namepathGet 0 309 222
assign 1 310 223
stepsGet 0 310 223
assign 1 310 224
lastGet 0 310 224
assign 1 311 225
new 0 311 225
assign 1 311 226
new 0 311 226
assign 1 311 227
substring 2 311 227
assign 1 311 228
lowerValue 0 311 228
assign 1 311 229
new 0 311 229
assign 1 311 230
substring 1 311 230
assign 1 311 231
add 1 311 231
assign 1 311 232
new 0 311 232
assign 1 311 233
add 1 311 233
assign 1 313 234
getSynNp 1 313 234
assign 1 314 235
mtdMapGet 0 314 235
assign 1 314 236
new 0 314 236
assign 1 314 237
add 1 314 237
assign 1 314 238
get 1 314 238
assign 1 315 239
def 1 315 244
assign 1 317 245
heldGet 0 317 245
orgNameSet 1 317 246
assign 1 318 247
heldGet 0 318 247
assign 1 318 248
new 0 318 248
assign 1 318 249
add 1 318 249
nameSet 1 318 250
assign 1 323 255
typenameGet 0 323 255
assign 1 323 256
CLASSGet 0 323 256
assign 1 323 257
equals 1 323 262
assign 1 324 263
assign 1 325 264
heldGet 0 325 264
assign 1 325 265
namepathGet 0 325 265
assign 1 326 266
heldGet 0 326 266
assign 1 326 267
synGet 0 326 267
assign 1 328 269
typenameGet 0 328 269
assign 1 328 270
METHODGet 0 328 270
assign 1 328 271
equals 1 328 276
assign 1 329 277
new 0 329 277
assign 1 330 278
new 0 330 278
assign 1 331 281
typenameGet 0 331 281
assign 1 331 282
VARGet 0 331 282
assign 1 331 283
equals 1 331 288
assign 1 331 289
heldGet 0 331 289
assign 1 331 290
autoTypeGet 0 331 290
assign 1 0 292
assign 1 0 295
assign 1 0 299
assign 1 332 302
heldGet 0 332 302
assign 1 332 303
nameGet 0 332 303
assign 1 332 304
heldGet 0 332 304
put 2 332 305
assign 1 333 306
heldGet 0 333 306
assign 1 333 307
nameGet 0 333 307
assign 1 333 308
get 1 333 308
assign 1 334 309
undef 1 334 314
assign 1 335 315
new 0 335 315
assign 1 336 316
heldGet 0 336 316
assign 1 336 317
nameGet 0 336 317
put 2 336 318
addValue 1 338 320
assign 1 339 323
typenameGet 0 339 323
assign 1 339 324
RBRACESGet 0 339 324
assign 1 339 325
equals 1 339 330
assign 1 339 331
containerGet 0 339 331
assign 1 339 332
def 1 339 337
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 339 348
containerGet 0 339 348
assign 1 339 349
containerGet 0 339 349
assign 1 339 350
def 1 339 355
assign 1 0 356
assign 1 0 359
assign 1 0 363
assign 1 339 366
containerGet 0 339 366
assign 1 339 367
containerGet 0 339 367
assign 1 339 368
typenameGet 0 339 368
assign 1 339 369
METHODGet 0 339 369
assign 1 339 370
equals 1 339 375
assign 1 0 376
assign 1 0 379
assign 1 0 383
processTmps 0 341 386
assign 1 343 390
nextDescendGet 0 343 390
return 1 343 391
assign 1 347 510
new 0 347 510
assign 1 356 514
new 0 356 514
assign 1 357 515
valueIteratorGet 0 357 515
assign 1 357 518
hasNextGet 0 357 518
assign 1 358 520
nextGet 0 358 520
assign 1 360 521
isTypedGet 0 360 521
assign 1 360 522
not 0 360 522
assign 1 363 524
nameGet 0 363 524
assign 1 364 525
get 1 364 525
assign 1 365 526
iteratorGet 0 0 526
assign 1 365 529
hasNextGet 0 365 529
assign 1 365 531
nextGet 0 365 531
assign 1 366 532
isFirstGet 0 366 532
assign 1 366 534
containerGet 0 366 534
assign 1 366 535
typenameGet 0 366 535
assign 1 366 536
CALLGet 0 366 536
assign 1 366 537
equals 1 366 537
assign 1 0 539
assign 1 0 542
assign 1 0 546
assign 1 366 549
containerGet 0 366 549
assign 1 366 550
heldGet 0 366 550
assign 1 366 551
orgNameGet 0 366 551
assign 1 366 552
new 0 366 552
assign 1 366 553
equals 1 366 553
assign 1 0 555
assign 1 0 558
assign 1 0 562
assign 1 366 565
containerGet 0 366 565
assign 1 366 566
secondGet 0 366 566
assign 1 366 567
typenameGet 0 366 567
assign 1 366 568
CALLGet 0 366 568
assign 1 366 569
equals 1 366 569
assign 1 0 571
assign 1 0 574
assign 1 0 578
assign 1 368 581
containerGet 0 368 581
assign 1 368 582
secondGet 0 368 582
assign 1 369 583
assign 1 370 584
heldGet 0 370 584
assign 1 370 585
newNpGet 0 370 585
assign 1 370 586
def 1 370 591
assign 1 371 592
heldGet 0 371 592
assign 1 371 593
newNpGet 0 371 593
assign 1 373 596
containedGet 0 373 596
assign 1 373 597
firstGet 0 373 597
assign 1 374 598
heldGet 0 374 598
assign 1 374 599
isDeclaredGet 0 374 599
assign 1 375 601
heldGet 0 375 601
assign 1 377 604
ptyMapGet 0 377 604
assign 1 377 605
heldGet 0 377 605
assign 1 377 606
nameGet 0 377 606
assign 1 377 607
get 1 377 607
assign 1 377 608
memSynGet 0 377 608
assign 1 380 610
isTypedGet 0 380 610
assign 1 381 612
namepathGet 0 381 612
assign 1 384 615
def 1 384 620
assign 1 386 621
getSynNp 1 386 621
assign 1 387 622
mtdMapGet 0 387 622
assign 1 387 623
heldGet 0 387 623
assign 1 387 624
nameGet 0 387 624
assign 1 387 625
get 1 387 625
assign 1 388 626
def 1 388 631
assign 1 390 632
rsynGet 0 390 632
assign 1 391 633
def 1 391 638
assign 1 391 639
isTypedGet 0 391 639
assign 1 0 641
assign 1 0 644
assign 1 0 648
assign 1 392 651
new 0 392 651
assign 1 394 652
isSelfGet 0 394 652
namepathSet 1 395 654
assign 1 397 657
namepathGet 0 397 657
namepathSet 1 397 658
assign 1 399 660
isTypedGet 0 399 660
isTypedSet 1 399 661
assign 1 400 662
heldGet 0 400 662
assign 1 400 663
namepathGet 0 400 663
addUsed 1 400 664
assign 1 401 665
namepathGet 0 401 665
assign 1 401 666
toString 0 401 666
assign 1 401 667
new 0 401 667
assign 1 401 668
equals 1 401 668
assign 1 401 670
new 0 401 670
assign 1 401 671
isSelfGet 0 401 671
assign 1 401 672
add 1 401 672
print 0 401 673
assign 1 403 678
heldGet 0 403 678
assign 1 403 679
orgNameGet 0 403 679
assign 1 403 680
new 0 403 680
assign 1 403 681
notEquals 1 403 681
assign 1 404 683
mtdMapGet 0 404 683
assign 1 404 684
new 0 404 684
assign 1 404 685
get 1 404 685
assign 1 405 686
def 1 405 691
assign 1 405 692
originGet 0 405 692
assign 1 405 693
toString 0 405 693
assign 1 405 694
new 0 405 694
assign 1 405 695
notEquals 1 405 695
assign 1 0 697
assign 1 0 700
assign 1 0 704
assign 1 406 707
heldGet 0 406 707
assign 1 406 708
new 0 406 708
isForwardSet 1 406 709
assign 1 408 712
new 0 408 712
assign 1 408 713
heldGet 0 408 713
assign 1 408 714
nameGet 0 408 714
assign 1 408 715
add 1 408 715
assign 1 408 716
new 0 408 716
assign 1 408 717
add 1 408 717
assign 1 408 718
toString 0 408 718
assign 1 408 719
add 1 408 719
assign 1 408 720
new 2 408 720
throw 1 408 721
assign 1 414 728
isFirstGet 0 414 728
assign 1 414 730
containerGet 0 414 730
assign 1 414 731
typenameGet 0 414 731
assign 1 414 732
CALLGet 0 414 732
assign 1 414 733
equals 1 414 733
assign 1 0 735
assign 1 0 738
assign 1 0 742
assign 1 414 745
containerGet 0 414 745
assign 1 414 746
heldGet 0 414 746
assign 1 414 747
orgNameGet 0 414 747
assign 1 414 748
new 0 414 748
assign 1 414 749
equals 1 414 749
assign 1 0 751
assign 1 0 754
assign 1 0 758
assign 1 414 761
containerGet 0 414 761
assign 1 414 762
secondGet 0 414 762
assign 1 414 763
typenameGet 0 414 763
assign 1 414 764
VARGet 0 414 764
assign 1 414 765
equals 1 414 765
assign 1 0 767
assign 1 0 770
assign 1 0 774
assign 1 415 777
containerGet 0 415 777
assign 1 415 778
secondGet 0 415 778
assign 1 415 779
heldGet 0 415 779
assign 1 417 780
isTypedGet 0 417 780
assign 1 419 782
new 0 419 782
assign 1 421 783
isTypedGet 0 421 783
isTypedSet 1 421 784
assign 1 422 785
namepathGet 0 422 785
namepathSet 1 422 786
return 1 0 809
assign 1 0 812
return 1 0 816
assign 1 0 819
return 1 0 823
assign 1 0 826
return 1 0 830
assign 1 0 833
return 1 0 837
assign 1 0 840
return 1 0 844
assign 1 0 847
return 1 0 851
assign 1 0 854
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1818335248: return bem_toString_0();
case -380315870: return bem_buildGet_0();
case -1237682444: return bem_rmapGet_0();
case 85678745: return bem_nlGet_0();
case 322724057: return bem_emitterGet_0();
case 1145598418: return bem_copy_0();
case -1118374518: return bem_transGet_0();
case 112562958: return bem_inClassSynGet_0();
case 1704927424: return bem_new_0();
case 84237329: return bem_hashGet_0();
case 1134489647: return bem_processTmps_0();
case -1182108874: return bem_create_0();
case -558929861: return bem_constGet_0();
case -1854351103: return bem_print_0();
case 1858145789: return bem_ntypesGet_0();
case 1291588945: return bem_tvmapGet_0();
case -355490415: return bem_inClassGet_0();
case 336575594: return bem_inClassNpGet_0();
case 764459509: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 886284834: return bem_inClassSynSet_1(bevd_0);
case -1456870992: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -457456225: return bem_transSet_1(bevd_0);
case 159081191: return bem_tvmapSet_1(bevd_0);
case 2070810849: return bem_inClassNpSet_1(bevd_0);
case 775180462: return bem_def_1(bevd_0);
case -2099273957: return bem_end_1(bevd_0);
case 1306869518: return bem_constSet_1(bevd_0);
case -686870288: return bem_ntypesSet_1(bevd_0);
case -1807901457: return bem_inClassSet_1(bevd_0);
case 818795859: return bem_rmapSet_1(bevd_0);
case 854124491: return bem_print_1(bevd_0);
case 1782625331: return bem_notEquals_1(bevd_0);
case 1546663149: return bem_buildSet_1(bevd_0);
case -474126023: return bem_begin_1(bevd_0);
case -1581291957: return bem_nlSet_1(bevd_0);
case 1309442131: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1697701048: return bem_equals_1(bevd_0);
case -1601489182: return bem_copyTo_1(bevd_0);
case 1780152727: return bem_undef_1(bevd_0);
case -749439485: return bem_emitterSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1638131121: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 294957256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -997677553: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 91726751: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;
}
}
