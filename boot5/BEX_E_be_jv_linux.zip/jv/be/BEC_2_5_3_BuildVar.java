package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_3_BuildVar extends BEC_2_6_6_SystemObject {
public BEC_2_5_3_BuildVar() { }
private static byte[] becc_BEC_2_5_3_BuildVar_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72};
private static byte[] becc_BEC_2_5_3_BuildVar_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_5_3_BuildVar_bevo_0 = (new BEC_2_4_3_MathInt(-1));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_0, 7));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_1 = {0x20,0x69,0x73,0x41,0x72,0x67};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_1, 6));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_2 = {0x20,0x69,0x73,0x54,0x6D,0x70,0x56,0x61,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_2, 9));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_3 = {0x20,0x6E,0x6F,0x74,0x44,0x65,0x63,0x6C,0x61,0x72,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_3, 12));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_4 = {0x20,0x69,0x73,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_4, 11));
public static BEC_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_6_6_SystemObject bevp_refs;
public BEC_2_9_3_ContainerSet bevp_allCalls;
public BEC_2_4_6_TextString bevp_suffix;
public BEC_2_5_4_LogicBool bevp_isArg;
public BEC_2_5_4_LogicBool bevp_isAdded;
public BEC_2_5_4_LogicBool bevp_isTmpVar;
public BEC_2_5_4_LogicBool bevp_autoType;
public BEC_2_5_4_LogicBool bevp_isDeclared;
public BEC_2_5_4_LogicBool bevp_isProperty;
public BEC_2_4_3_MathInt bevp_numAssigns;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_4_3_MathInt bevp_vpos;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public BEC_2_5_4_LogicBool bevp_implied;
public BEC_2_4_3_MathInt bevp_maxCpos;
public BEC_2_4_3_MathInt bevp_minCpos;
public BEC_2_4_6_TextString bevp_nativeName;
public BEC_2_5_3_BuildVar bem_new_0() throws Throwable {
BEC_2_4_4_MathInts bevt_0_tmpany_phold = null;
bevp_isArg = be.BECS_Runtime.boolFalse;
bevp_isAdded = be.BECS_Runtime.boolFalse;
bevp_isTmpVar = be.BECS_Runtime.boolFalse;
bevp_autoType = be.BECS_Runtime.boolFalse;
bevp_isDeclared = be.BECS_Runtime.boolTrue;
bevp_isProperty = be.BECS_Runtime.boolFalse;
bevp_numAssigns = (new BEC_2_4_3_MathInt(0));
bevp_isTyped = be.BECS_Runtime.boolFalse;
bevp_vpos = (new BEC_2_4_3_MathInt(-1));
bevp_isSelf = be.BECS_Runtime.boolFalse;
bevp_isThis = be.BECS_Runtime.boolFalse;
bevp_implied = be.BECS_Runtime.boolFalse;
bevp_maxCpos = (new BEC_2_4_3_MathInt(-1));
bevt_0_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevp_minCpos = bevt_0_tmpany_phold.bem_maxGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_synNew_1(BEC_2_5_3_BuildVar beva_full) throws Throwable {
bevp_isArg = beva_full.bem_isArgGet_0();
bevp_name = beva_full.bem_nameGet_0();
bevp_isAdded = beva_full.bem_isAddedGet_0();
bevp_isTmpVar = beva_full.bem_isTmpVarGet_0();
bevp_isProperty = beva_full.bem_isPropertyGet_0();
bevp_numAssigns = (new BEC_2_4_3_MathInt(0));
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_vpos = beva_full.bem_vposGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
bevp_implied = beva_full.bem_impliedGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_addCall_1(BEC_2_5_4_BuildNode beva_call) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_allCalls == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevp_allCalls = (new BEC_2_9_3_ContainerSet()).bem_new_0();
} /* Line: 239 */
bevp_allCalls.bem_addValue_1(beva_call);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_0;
if (bevp_maxCpos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 245 */ {
return bevp_maxCpos;
} /* Line: 245 */
bevt_0_tmpany_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
 /* Line: 246 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevl_n = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_6_tmpany_phold = bevl_n.bemd_0(-82076223);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-711696029);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1611541980, bevp_maxCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 247 */ {
bevt_7_tmpany_phold = bevl_n.bemd_0(-82076223);
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bemd_0(-711696029);
} /* Line: 248 */
} /* Line: 247 */
 else  /* Line: 246 */ {
break;
} /* Line: 246 */
} /* Line: 246 */
return bevp_maxCpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_bigun = null;
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_4_4_MathInts bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevl_bigun = bevt_1_tmpany_phold.bem_maxGet_0();
if (bevp_minCpos.bevi_int < bevl_bigun.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 257 */ {
return bevp_minCpos;
} /* Line: 257 */
bevt_0_tmpany_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
 /* Line: 258 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevl_n = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_6_tmpany_phold = bevl_n.bemd_0(-82076223);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-711696029);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(39618973, bevp_minCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 259 */ {
bevt_7_tmpany_phold = bevl_n.bemd_0(-82076223);
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bemd_0(-711696029);
} /* Line: 260 */
} /* Line: 259 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
return bevp_minCpos;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_1;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 269 */
if (bevp_isArg.bevi_bool) /* Line: 271 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_2;
bevl_ret = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
} /* Line: 272 */
if (bevp_isTmpVar.bevi_bool) /* Line: 274 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 275 */
if (bevp_isDeclared.bevi_bool) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 278 */
if (bevp_isProperty.bevi_bool) /* Line: 280 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_5;
bevl_ret = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 281 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_3_BuildVar bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGet_0() throws Throwable {
return bevp_refs;
} /*method end*/
public BEC_2_5_3_BuildVar bem_refsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_refs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGet_0() throws Throwable {
return bevp_allCalls;
} /*method end*/
public BEC_2_5_3_BuildVar bem_allCallsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGet_0() throws Throwable {
return bevp_suffix;
} /*method end*/
public BEC_2_5_3_BuildVar bem_suffixSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGet_0() throws Throwable {
return bevp_isArg;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isArgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGet_0() throws Throwable {
return bevp_isAdded;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGet_0() throws Throwable {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTmpVarSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_autoTypeGet_0() throws Throwable {
return bevp_autoType;
} /*method end*/
public BEC_2_5_3_BuildVar bem_autoTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_autoType = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGet_0() throws Throwable {
return bevp_isDeclared;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isDeclaredSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGet_0() throws Throwable {
return bevp_isProperty;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isPropertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGet_0() throws Throwable {
return bevp_numAssigns;
} /*method end*/
public BEC_2_5_3_BuildVar bem_numAssignsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() throws Throwable {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGet_0() throws Throwable {
return bevp_vpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_vposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() throws Throwable {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() throws Throwable {
return bevp_isThis;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_impliedGet_0() throws Throwable {
return bevp_implied;
} /*method end*/
public BEC_2_5_3_BuildVar bem_impliedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_implied = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_maxCposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_minCposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGet_0() throws Throwable {
return bevp_nativeName;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nativeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 216, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 238, 238, 239, 241, 245, 245, 245, 245, 246, 0, 246, 246, 247, 247, 247, 248, 248, 251, 255, 255, 257, 257, 257, 258, 0, 258, 258, 259, 259, 259, 260, 260, 263, 267, 268, 268, 269, 269, 269, 269, 272, 272, 275, 275, 277, 277, 278, 278, 281, 281, 283, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 75, 80, 81, 83, 96, 97, 102, 103, 105, 105, 108, 110, 111, 112, 113, 115, 116, 123, 136, 137, 138, 143, 144, 146, 146, 149, 151, 152, 153, 154, 156, 157, 164, 177, 178, 183, 184, 185, 186, 187, 190, 191, 194, 195, 197, 202, 203, 204, 207, 208, 210, 213, 216, 220, 223, 227, 230, 234, 237, 241, 244, 248, 251, 255, 258, 262, 265, 269, 272, 276, 279, 283, 286, 290, 293, 297, 300, 304, 307, 311, 314, 318, 321, 325, 328, 332, 336, 340, 343};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 203 41
new 0 203 41
assign 1 204 42
new 0 204 42
assign 1 205 43
new 0 205 43
assign 1 206 44
new 0 206 44
assign 1 207 45
new 0 207 45
assign 1 208 46
new 0 208 46
assign 1 209 47
new 0 209 47
assign 1 210 48
new 0 210 48
assign 1 211 49
new 0 211 49
assign 1 212 50
new 0 212 50
assign 1 213 51
new 0 213 51
assign 1 214 52
new 0 214 52
assign 1 215 53
new 0 215 53
assign 1 216 54
new 0 216 54
assign 1 216 55
maxGet 0 216 55
assign 1 223 59
isArgGet 0 223 59
assign 1 224 60
nameGet 0 224 60
assign 1 225 61
isAddedGet 0 225 61
assign 1 226 62
isTmpVarGet 0 226 62
assign 1 227 63
isPropertyGet 0 227 63
assign 1 228 64
new 0 228 64
assign 1 229 65
namepathGet 0 229 65
assign 1 230 66
isTypedGet 0 230 66
assign 1 231 67
vposGet 0 231 67
assign 1 232 68
isSelfGet 0 232 68
assign 1 233 69
isThisGet 0 233 69
assign 1 234 70
impliedGet 0 234 70
assign 1 238 75
undef 1 238 80
assign 1 239 81
new 0 239 81
addValue 1 241 83
assign 1 245 96
new 0 245 96
assign 1 245 97
greater 1 245 102
return 1 245 103
assign 1 246 105
setIteratorGet 0 0 105
assign 1 246 108
hasNextGet 0 246 108
assign 1 246 110
nextGet 0 246 110
assign 1 247 111
heldGet 0 247 111
assign 1 247 112
cposGet 0 247 112
assign 1 247 113
greater 1 247 113
assign 1 248 115
heldGet 0 248 115
assign 1 248 116
cposGet 0 248 116
return 1 251 123
assign 1 255 136
new 0 255 136
assign 1 255 137
maxGet 0 255 137
assign 1 257 138
lesser 1 257 143
return 1 257 144
assign 1 258 146
setIteratorGet 0 0 146
assign 1 258 149
hasNextGet 0 258 149
assign 1 258 151
nextGet 0 258 151
assign 1 259 152
heldGet 0 259 152
assign 1 259 153
cposGet 0 259 153
assign 1 259 154
lesser 1 259 154
assign 1 260 156
heldGet 0 260 156
assign 1 260 157
cposGet 0 260 157
return 1 263 164
assign 1 267 177
classNameGet 0 267 177
assign 1 268 178
def 1 268 183
assign 1 269 184
new 0 269 184
assign 1 269 185
add 1 269 185
assign 1 269 186
toString 0 269 186
assign 1 269 187
add 1 269 187
assign 1 272 190
new 0 272 190
assign 1 272 191
add 1 272 191
assign 1 275 194
new 0 275 194
assign 1 275 195
add 1 275 195
assign 1 277 197
not 0 277 202
assign 1 278 203
new 0 278 203
assign 1 278 204
add 1 278 204
assign 1 281 207
new 0 281 207
assign 1 281 208
add 1 281 208
return 1 283 210
return 1 0 213
assign 1 0 216
return 1 0 220
assign 1 0 223
return 1 0 227
assign 1 0 230
return 1 0 234
assign 1 0 237
return 1 0 241
assign 1 0 244
return 1 0 248
assign 1 0 251
return 1 0 255
assign 1 0 258
return 1 0 262
assign 1 0 265
return 1 0 269
assign 1 0 272
return 1 0 276
assign 1 0 279
return 1 0 283
assign 1 0 286
return 1 0 290
assign 1 0 293
return 1 0 297
assign 1 0 300
return 1 0 304
assign 1 0 307
return 1 0 311
assign 1 0 314
return 1 0 318
assign 1 0 321
return 1 0 325
assign 1 0 328
assign 1 0 332
assign 1 0 336
return 1 0 340
assign 1 0 343
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 823137342: return bem_autoTypeGet_0();
case 721298840: return bem_serializationIteratorGet_0();
case 1782125853: return bem_hashGet_0();
case -703538866: return bem_allCallsGet_0();
case -1693411633: return bem_fieldIteratorGet_0();
case 1684405247: return bem_isArgGet_0();
case -907223016: return bem_iteratorGet_0();
case 394710523: return bem_toAny_0();
case -1508470700: return bem_isPropertyGet_0();
case 844193671: return bem_isTypedGet_0();
case -67323485: return bem_create_0();
case 370647566: return bem_isSelfGet_0();
case -1256903143: return bem_print_0();
case 595944113: return bem_isThisGet_0();
case 1740583826: return bem_serializeToString_0();
case 648643859: return bem_sourceFileNameGet_0();
case 640391526: return bem_nativeNameGet_0();
case 895906767: return bem_toString_0();
case 1577232787: return bem_refsGet_0();
case 19655765: return bem_tagGet_0();
case -395145931: return bem_nameGet_0();
case 1781926555: return bem_copy_0();
case 753590668: return bem_isDeclaredGet_0();
case -748130189: return bem_echo_0();
case 978873391: return bem_deserializeClassNameGet_0();
case 482841480: return bem_vposGet_0();
case 1650720207: return bem_maxCposGet_0();
case -1277028889: return bem_suffixGet_0();
case -1755437106: return bem_serializeContents_0();
case -132934720: return bem_isTmpVarGet_0();
case 692855132: return bem_namepathGet_0();
case 1330053746: return bem_classNameGet_0();
case 29354299: return bem_isAddedGet_0();
case 1747192728: return bem_numAssignsGet_0();
case -2089883321: return bem_new_0();
case -266150550: return bem_many_0();
case -1666892068: return bem_once_0();
case 947198916: return bem_minCposGet_0();
case -291655359: return bem_impliedGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1177150950: return bem_namepathSet_1(bevd_0);
case -2097315666: return bem_sameClass_1(bevd_0);
case 2119054446: return bem_otherType_1(bevd_0);
case -1725122194: return bem_isArgSet_1(bevd_0);
case -63430507: return bem_nativeNameSet_1(bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1530255064: return bem_maxCposSet_1(bevd_0);
case 599757908: return bem_nameSet_1(bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -349420021: return bem_refsSet_1(bevd_0);
case 803845413: return bem_def_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1268267167: return bem_isThisSet_1(bevd_0);
case -2108013810: return bem_addCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -374034464: return bem_isTypedSet_1(bevd_0);
case -333086513: return bem_allCallsSet_1(bevd_0);
case -1913725852: return bem_vposSet_1(bevd_0);
case -1433012599: return bem_isSelfSet_1(bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case 1527044191: return bem_synNew_1((BEC_2_5_3_BuildVar) bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 549138919: return bem_autoTypeSet_1(bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case 689855980: return bem_isTmpVarSet_1(bevd_0);
case 438869289: return bem_isDeclaredSet_1(bevd_0);
case 2125147591: return bem_isPropertySet_1(bevd_0);
case -88288397: return bem_suffixSet_1(bevd_0);
case 730732048: return bem_numAssignsSet_1(bevd_0);
case 1964376646: return bem_isAddedSet_1(bevd_0);
case -1404929571: return bem_impliedSet_1(bevd_0);
case 1440694160: return bem_minCposSet_1(bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_5_3_BuildVar_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_3_BuildVar_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_3_BuildVar();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst = (BEC_2_5_3_BuildVar) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst;
}
}
