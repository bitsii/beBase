package be;
public class BET_2_6_10_SystemCallOnNull extends BETS_Object {
public BET_2_6_10_SystemCallOnNull() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "framesGet_0", "getFrameText_0", "klassNameGet_0", "addFrame_1", "addFrame_4", "methodNameGet_0", "methodNameSet_1", "klassNameSet_1", "descriptionGet_0", "descriptionSet_1", "fileNameGet_0", "fileNameSet_1", "lineNumberGet_0", "lineNumberSet_1", "langGet_0", "langSet_1", "emitLangGet_0", "emitLangSet_1", "framesSet_1", "framesTextGet_0", "framesTextSet_1", "translatedGet_0", "translatedSet_1", "vvGet_0", "vvSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "methodName", "klassName", "description", "fileName", "lineNumber", "lang", "emitLang", "frames", "framesText", "translated", "vv" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_10_SystemCallOnNull();
}
}
