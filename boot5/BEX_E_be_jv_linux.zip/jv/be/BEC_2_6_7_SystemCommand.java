package be;
/* IO:File: source/extended/Command.be */
public final class BEC_2_6_7_SystemCommand extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_0 = {};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_1 = {0x20};
public static BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;

public static BET_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_2_9_4_ContainerList bevp_commands;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) throws Throwable {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_listNew_1(BEC_2_9_4_ContainerList beva__commands) throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevp_commands = beva__commands;
bevp_command = (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_0));
bevt_0_tmpany_loop = bevp_commands.bem_iteratorGet_0();
while (true)
 /* Line: 47 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-505537007);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 47 */ {
bevl_c = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(844391958);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(bevp_command);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_7_SystemCommand_bels_1));
bevp_command.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 49 */
bevp_command.bem_addValue_1(bevl_c);
} /* Line: 51 */
 else  /* Line: 47 */ {
break;
} /* Line: 47 */
} /* Line: 47 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bem_new_1(beva__command);
bevt_0_tmpany_phold = bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_3_MathInt bevl_cl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_cmdi = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (bevp_commands == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 90 */ {
bevl_cl = bevp_commands.bem_sizeGet_0();

        String[] cmds = new String[bevl_cl.bevi_int]; 
        bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 97 */ {
if (bevl_i.bevi_int < bevl_cl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevl_cmdi = (BEC_2_4_6_TextString) bevp_commands.bem_get_1(bevl_i);

          cmds[bevl_i.bevi_int] = bevl_cmdi.bems_toJvString();
          bevl_i.bevi_int++;
} /* Line: 97 */
 else  /* Line: 97 */ {
break;
} /* Line: 97 */
} /* Line: 97 */

        bevi_p = Runtime.getRuntime().exec(cmds);
        } /* Line: 106 */
 else  /* Line: 112 */ {

        bevi_p = Runtime.getRuntime().exec(bevp_command.bems_toJvString());
        } /* Line: 114 */
return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() throws Throwable {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 133 */ {
return bevp_outputReader;
} /* Line: 134 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.getInputStream();
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 152 */ {
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 155 */
} /* Line: 153 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 157 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() throws Throwable {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_outputContentGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_ee = null;
BEC_3_2_4_6_IOFileReader bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemCommand bevt_1_tmpany_phold = null;
try  /* Line: 176 */ {
bevt_1_tmpany_phold = bem_open_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_outputGet_0();
bevl_res = bevt_0_tmpany_phold.bem_readString_0();
bem_close_0();
} /* Line: 178 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
try  /* Line: 180 */ {
bem_close_0();
} /* Line: 181 */
 catch (Throwable beve_1) {
bevl_ee = (be.BECS_ThrowBack.handleThrow(beve_1));
} /* Line: 182 */
} /* Line: 182 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public final BEC_2_4_6_TextString bem_commandGetDirect_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGet_0() throws Throwable {
return bevp_commands;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_commandsGetDirect_0() throws Throwable {
return bevp_commands;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemCommand bem_commandsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public final BEC_3_2_4_6_IOFileReader bem_outputReaderGetDirect_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemCommand bem_outputReaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 44, 46, 47, 0, 47, 47, 48, 48, 49, 49, 51, 56, 57, 57, 90, 90, 91, 97, 97, 97, 98, 97, 122, 126, 133, 133, 134, 136, 147, 148, 153, 153, 154, 155, 161, 177, 177, 177, 178, 181, 184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 29, 30, 31, 31, 34, 36, 37, 38, 40, 41, 43, 53, 54, 55, 72, 77, 78, 81, 84, 89, 90, 93, 106, 109, 114, 119, 120, 122, 125, 126, 132, 137, 138, 139, 148, 160, 161, 162, 163, 168, 174, 177, 180, 183, 187, 191, 194, 197, 201, 205, 208, 211, 215};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 38 19
assign 1 44 29
assign 1 46 30
new 0 46 30
assign 1 47 31
iteratorGet 0 0 31
assign 1 47 34
hasNextGet 0 47 34
assign 1 47 36
nextGet 0 47 36
assign 1 48 37
new 0 48 37
assign 1 48 38
notEmpty 1 48 38
assign 1 49 40
new 0 49 40
addValue 1 49 41
addValue 1 51 43
new 1 56 53
assign 1 57 54
run 0 57 54
return 1 57 55
assign 1 90 72
def 1 90 77
assign 1 91 78
sizeGet 0 91 78
assign 1 97 81
new 0 97 81
assign 1 97 84
lesser 1 97 89
assign 1 98 90
get 1 98 90
incrementValue 0 97 93
return 1 122 106
run 0 126 109
assign 1 133 114
def 1 133 119
return 1 134 120
assign 1 136 122
new 0 136 122
extOpen 0 147 125
return 1 148 126
assign 1 153 132
def 1 153 137
close 0 154 138
assign 1 155 139
closeOutput 0 161 148
assign 1 177 160
open 0 177 160
assign 1 177 161
outputGet 0 177 161
assign 1 177 162
readString 0 177 162
close 0 178 163
close 0 181 168
return 1 184 174
return 1 0 177
return 1 0 180
assign 1 0 183
assign 1 0 187
return 1 0 191
return 1 0 194
assign 1 0 197
assign 1 0 201
return 1 0 205
return 1 0 208
assign 1 0 211
assign 1 0 215
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1551817007: return bem_open_0();
case 823459209: return bem_outputReaderGetDirect_0();
case 1770146810: return bem_serializeToString_0();
case 279572313: return bem_outputGet_0();
case 1361603917: return bem_create_0();
case -1368481720: return bem_run_0();
case 573894722: return bem_commandsGet_0();
case -512745226: return bem_tagGet_0();
case -1578603026: return bem_close_0();
case 150594226: return bem_toAny_0();
case 1276009426: return bem_commandsGetDirect_0();
case 450959931: return bem_commandGet_0();
case 475849232: return bem_fieldNamesGet_0();
case -481458436: return bem_once_0();
case 518030741: return bem_closeOutput_0();
case 970559243: return bem_hashGet_0();
case -232339846: return bem_classNameGet_0();
case 189063253: return bem_serializeContents_0();
case -696933955: return bem_toString_0();
case -791198660: return bem_serializationIteratorGet_0();
case 734719264: return bem_copy_0();
case 865626065: return bem_many_0();
case -1010395565: return bem_deserializeClassNameGet_0();
case 1994733667: return bem_outputReaderGet_0();
case 641115868: return bem_commandGetDirect_0();
case 15052169: return bem_iteratorGet_0();
case -866769073: return bem_new_0();
case -1238312381: return bem_print_0();
case 800117087: return bem_outputContentGet_0();
case 1064240293: return bem_sourceFileNameGet_0();
case -96306095: return bem_echo_0();
case 1703076999: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1689607871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2018144381: return bem_sameType_1(bevd_0);
case -1258943525: return bem_equals_1(bevd_0);
case -1555556152: return bem_defined_1(bevd_0);
case -1378821005: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1072196917: return bem_listNew_1((BEC_2_9_4_ContainerList) bevd_0);
case -984588490: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case 789848846: return bem_copyTo_1(bevd_0);
case -1814510964: return bem_notEquals_1(bevd_0);
case -1973562246: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -37721510: return bem_outputReaderSet_1(bevd_0);
case 721379891: return bem_otherType_1(bevd_0);
case -1657467808: return bem_def_1(bevd_0);
case -798295698: return bem_commandSetDirect_1(bevd_0);
case 954777710: return bem_undefined_1(bevd_0);
case 1719547470: return bem_commandsSetDirect_1(bevd_0);
case -256855558: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1120668425: return bem_sameClass_1(bevd_0);
case -1696224976: return bem_otherClass_1(bevd_0);
case 952631001: return bem_undef_1(bevd_0);
case -304012900: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1411547316: return bem_sameObject_1(bevd_0);
case 1866375688: return bem_outputReaderSetDirect_1(bevd_0);
case -117099556: return bem_commandSet_1(bevd_0);
case 2034982737: return bem_commandsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -133579010: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -750254672: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1191848195: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 514912045: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2072659817: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1041788971: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 84003596: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_type;
}
}
