package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_5_LogicBools extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_LogicBools() { }
private static byte[] becc_BEC_2_5_5_LogicBools_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] becc_BEC_2_5_5_LogicBools_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_1 = {0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_LogicBools_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_LogicBools_bels_1, 1));
public static BEC_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_inst;

public static BET_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_type;

public BEC_2_5_5_LogicBools bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_5_LogicBools bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_forString_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_0_ta_ph = beva_str.bemd_1(1070255022, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 122*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 123*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_fromString_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 129*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_2_ta_ph = beva_str.bemd_1(1070255022, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 129*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 129*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 129*/
 else /* Line: 129*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 129*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 130*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_5_5_LogicBools_bevo_0;
bevt_0_ta_ph = beva_str.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 136*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 137*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isTrue_1(BEC_2_5_4_LogicBool beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
if (beva_val == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 143*/ {
if (beva_val.bevi_bool)/* Line: 143*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 143*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 143*/
 else /* Line: 143*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 143*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 144*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {122, 122, 123, 123, 125, 125, 129, 129, 129, 129, 0, 0, 0, 130, 130, 132, 132, 136, 136, 137, 137, 139, 139, 143, 143, 0, 0, 0, 144, 144, 146, 146};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 28, 29, 31, 32, 41, 46, 47, 48, 50, 53, 57, 60, 61, 63, 64, 71, 72, 74, 75, 77, 78, 85, 90, 92, 95, 99, 102, 103, 105, 106};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 122 25
new 0 122 25
assign 1 122 26
equals 1 122 26
assign 1 123 28
new 0 123 28
return 1 123 29
assign 1 125 31
new 0 125 31
return 1 125 32
assign 1 129 41
def 1 129 46
assign 1 129 47
new 0 129 47
assign 1 129 48
equals 1 129 48
assign 1 0 50
assign 1 0 53
assign 1 0 57
assign 1 130 60
new 0 130 60
return 1 130 61
assign 1 132 63
new 0 132 63
return 1 132 64
assign 1 136 71
new 0 136 71
assign 1 136 72
equals 1 136 72
assign 1 137 74
new 0 137 74
return 1 137 75
assign 1 139 77
new 0 139 77
return 1 139 78
assign 1 143 85
def 1 143 90
assign 1 0 92
assign 1 0 95
assign 1 0 99
assign 1 144 102
new 0 144 102
return 1 144 103
assign 1 146 105
new 0 146 105
return 1 146 106
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 310047227: return bem_fieldNamesGet_0();
case 221458969: return bem_serializeToString_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 78412540: return bem_toAny_0();
case -1079456517: return bem_many_0();
case -992634121: return bem_tagGet_0();
case -1238524057: return bem_print_0();
case -1851472893: return bem_once_0();
case -777537417: return bem_serializeContents_0();
case -1714583788: return bem_classNameGet_0();
case 205150354: return bem_new_0();
case -1331626162: return bem_iteratorGet_0();
case 217381802: return bem_serializationIteratorGet_0();
case 814015164: return bem_copy_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -1392846471: return bem_toString_0();
case -438289515: return bem_fieldIteratorGet_0();
case -1426056679: return bem_hashGet_0();
case 993286746: return bem_echo_0();
case 137910263: return bem_create_0();
case -1201862288: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 945769885: return bem_sameClass_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 529702663: return bem_isTrue_1((BEC_2_5_4_LogicBool) bevd_0);
case 236257392: return bem_fromString_1(bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case -863560143: return bem_forString_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_LogicBools_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_5_LogicBools_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_LogicBools();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst = (BEC_2_5_5_LogicBools) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_type;
}
}
