package be;
/* IO:File: source/build/Transport.be */
public final class BEC_2_5_9_BuildTransport extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
private static byte[] becc_BEC_2_5_9_BuildTransport_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransport_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_1, 37));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_2, 10));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_3 = {0x4E,0x6F,0x64,0x65,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_4 = {0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x62,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_4, 12));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_5 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_5, 44));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_2, 10));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_6 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_7 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_8 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static BEC_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_inst;

public static BET_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_type;

public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildTransport_bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) throws Throwable {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
try  /* Line: 34 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 39 */ {
if (bevl_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 40 */
 else  /* Line: 39 */ {
break;
} /* Line: 39 */
} /* Line: 39 */
beva_visitor.bem_end_1(this);
} /* Line: 43 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_0;
bevt_2_tmpany_phold.bem_print_0();
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_1;
bevt_3_tmpany_phold.bem_print_0();
bevl_e.bemd_0(2087395772);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_2;
bevt_4_tmpany_phold.bem_print_0();
bevl_node.bem_print_0();
bevl_nc = bevl_node.bem_containerGet_0();
while (true)
 /* Line: 52 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_3;
bevt_6_tmpany_phold.bem_print_0();
bevl_nc.bemd_0(2087395772);
bevl_nc = bevl_nc.bemd_0(-2046411697);
} /* Line: 55 */
 else  /* Line: 52 */ {
break;
} /* Line: 52 */
} /* Line: 52 */
} /* Line: 52 */
 else  /* Line: 57 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_4;
bevt_7_tmpany_phold.bem_print_0();
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_5;
bevt_8_tmpany_phold.bem_print_0();
bevl_e.bemd_0(2087395772);
} /* Line: 60 */
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 62 */
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_contain_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
bevt_7_tmpany_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpany_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 71 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 71 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_tmpany_phold.bevi_bool) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 75 */ {
bevt_12_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_tmpany_phold.bevi_int == bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevt_15_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_15_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 76 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 76 */
 else  /* Line: 76 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 76 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 80 */ {
if (bevl_wf == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_19_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_19_tmpany_phold.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_22_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_25_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_tmpany_phold.bevi_int == bevt_26_tmpany_phold.bevi_int) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 80 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
 else  /* Line: 80 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 82 */
 else  /* Line: 80 */ {
break;
} /* Line: 80 */
} /* Line: 80 */
if (bevl_wf == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_29_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_tmpany_phold.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_32_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 84 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 84 */ {
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildTransport_bels_6));
bevl_cnode.bem_heldSet_1(bevt_35_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 91 */
} /* Line: 84 */
bevt_37_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_tmpany_phold.bevi_int == bevt_38_tmpany_phold.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_41_tmpany_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_typenameGet_0();
bevt_42_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_tmpany_phold.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
 else  /* Line: 94 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevt_44_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_44_tmpany_phold.bevi_int == bevt_45_tmpany_phold.bevi_int) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
 else  /* Line: 94 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevl_mnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_7));
bevl_mnode.bem_heldSet_1(bevt_47_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 100 */
bevt_49_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_tmpany_phold.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_52_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_tmpany_phold.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 103 */ {
bevl_mnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_8));
bevl_mnode.bem_heldSet_1(bevt_55_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 109 */
bevt_57_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_tmpany_phold.bevi_int == bevt_58_tmpany_phold.bevi_int) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 113 */
 else  /* Line: 112 */ {
bevt_60_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_tmpany_phold.bevi_int == bevt_61_tmpany_phold.bevi_int) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 115 */
 else  /* Line: 112 */ {
bevt_63_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_tmpany_phold.bevi_int == bevt_64_tmpany_phold.bevi_int) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_9));
bevt_66_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_66_tmpany_phold);
} /* Line: 119 */
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 122 */ {
bevt_70_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_9));
bevt_69_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_69_tmpany_phold);
} /* Line: 123 */
} /* Line: 122 */
 else  /* Line: 125 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 126 */
} /* Line: 112 */
} /* Line: 112 */
bevt_72_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpany_phold = bevl_conTypes.bem_has_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevl_curr = bevl_node;
} /* Line: 129 */
} /* Line: 128 */
} /* Line: 75 */
 else  /* Line: 71 */ {
break;
} /* Line: 71 */
} /* Line: 71 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) throws Throwable {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_9));
bevt_1_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpany_phold, beva_curr);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 138 */
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildGetDirect_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_outermostGetDirect_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_outermostSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_currentGetDirect_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 17, 18, 19, 21, 21, 22, 22, 26, 27, 27, 28, 29, 35, 37, 39, 39, 40, 43, 45, 45, 46, 46, 47, 47, 48, 49, 49, 50, 51, 52, 52, 53, 53, 54, 55, 58, 58, 59, 59, 60, 62, 67, 67, 68, 69, 70, 71, 71, 74, 75, 75, 75, 76, 76, 76, 76, 76, 76, 76, 76, 0, 0, 0, 79, 80, 80, 80, 80, 80, 80, 0, 80, 80, 80, 80, 0, 0, 0, 81, 81, 81, 81, 0, 0, 0, 0, 0, 82, 84, 84, 84, 84, 84, 84, 0, 84, 84, 84, 84, 0, 0, 0, 0, 0, 87, 88, 88, 89, 89, 90, 91, 94, 94, 94, 94, 94, 94, 94, 94, 94, 0, 0, 0, 94, 94, 94, 94, 0, 0, 0, 96, 97, 97, 98, 98, 99, 100, 103, 103, 103, 103, 103, 103, 103, 103, 0, 0, 0, 105, 106, 106, 107, 107, 108, 109, 112, 112, 112, 112, 113, 114, 114, 114, 114, 115, 116, 116, 116, 116, 117, 118, 118, 119, 119, 119, 121, 122, 122, 123, 123, 123, 126, 128, 128, 129, 136, 137, 137, 138, 138, 138, 140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 43, 48, 49, 50, 51, 52, 69, 70, 73, 78, 79, 85, 89, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 106, 111, 112, 113, 114, 115, 123, 124, 125, 126, 127, 129, 215, 216, 217, 218, 219, 220, 223, 225, 226, 227, 232, 233, 234, 235, 240, 241, 242, 243, 248, 249, 252, 256, 259, 262, 267, 268, 269, 270, 275, 276, 279, 280, 281, 286, 287, 290, 294, 297, 298, 299, 304, 305, 308, 312, 315, 319, 322, 328, 333, 334, 335, 336, 341, 342, 345, 346, 347, 352, 353, 356, 360, 363, 367, 370, 371, 372, 373, 374, 375, 376, 379, 380, 381, 386, 387, 388, 389, 390, 395, 396, 399, 403, 406, 407, 408, 413, 414, 417, 421, 424, 425, 426, 427, 428, 429, 430, 432, 433, 434, 439, 440, 441, 442, 447, 448, 451, 455, 458, 459, 460, 461, 462, 463, 464, 466, 467, 468, 473, 474, 477, 478, 479, 484, 485, 488, 489, 490, 495, 496, 497, 502, 503, 504, 505, 507, 508, 513, 514, 515, 516, 520, 524, 525, 527, 542, 543, 548, 549, 550, 551, 553, 556, 559, 562, 566, 570, 573, 576, 580, 584, 587, 590, 594, 598, 601, 604, 608};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 35
assign 1 17 36
constantsGet 0 17 36
assign 1 17 37
ntypesGet 0 17 37
assign 1 18 38
new 1 18 38
assign 1 19 39
assign 1 21 40
TRANSUNITGet 0 21 40
typenameSet 1 21 41
assign 1 22 42
new 0 22 42
heldSet 1 22 43
assign 1 26 48
assign 1 27 49
constantsGet 0 27 49
assign 1 27 50
ntypesGet 0 27 50
assign 1 28 51
assign 1 29 52
begin 1 35 69
assign 1 37 70
accept 1 37 70
assign 1 39 73
def 1 39 78
assign 1 40 79
accept 1 40 79
end 1 43 85
assign 1 45 89
def 1 45 94
assign 1 46 95
new 0 46 95
print 0 46 96
assign 1 47 97
new 0 47 97
print 0 47 98
print 0 48 99
assign 1 49 100
new 0 49 100
print 0 49 101
print 0 50 102
assign 1 51 103
containerGet 0 51 103
assign 1 52 106
def 1 52 111
assign 1 53 112
new 0 53 112
print 0 53 113
print 0 54 114
assign 1 55 115
containerGet 0 55 115
assign 1 58 123
new 0 58 123
print 0 58 124
assign 1 59 125
new 0 59 125
print 0 59 126
print 0 60 127
throw 1 62 129
assign 1 67 215
constantsGet 0 67 215
assign 1 67 216
conTypesGet 0 67 216
assign 1 68 217
assign 1 69 218
containedGet 0 69 218
containedSet 1 70 219
assign 1 71 220
linkedListIteratorGet 0 71 220
assign 1 71 223
hasNextGet 0 71 223
assign 1 74 225
nextGet 0 74 225
assign 1 75 226
delayDeleteGet 0 75 226
assign 1 75 227
not 0 75 232
assign 1 76 233
typenameGet 0 76 233
assign 1 76 234
TRANSUNITGet 0 76 234
assign 1 76 235
equals 1 76 240
assign 1 76 241
typenameGet 0 76 241
assign 1 76 242
IDGet 0 76 242
assign 1 76 243
equals 1 76 248
assign 1 0 249
assign 1 0 252
assign 1 0 256
assign 1 79 259
assign 1 80 262
def 1 80 267
assign 1 80 268
typenameGet 0 80 268
assign 1 80 269
IDGet 0 80 269
assign 1 80 270
equals 1 80 275
assign 1 0 276
assign 1 80 279
typenameGet 0 80 279
assign 1 80 280
COLONGet 0 80 280
assign 1 80 281
equals 1 80 286
assign 1 0 287
assign 1 0 290
assign 1 0 294
assign 1 81 297
typenameGet 0 81 297
assign 1 81 298
SPACEGet 0 81 298
assign 1 81 299
equals 1 81 304
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 0 315
assign 1 0 319
assign 1 82 322
nextPeerGet 0 82 322
assign 1 84 328
def 1 84 333
assign 1 84 334
typenameGet 0 84 334
assign 1 84 335
PARENSGet 0 84 335
assign 1 84 336
equals 1 84 341
assign 1 0 342
assign 1 84 345
typenameGet 0 84 345
assign 1 84 346
BRACESGet 0 84 346
assign 1 84 347
equals 1 84 352
assign 1 0 353
assign 1 0 356
assign 1 0 360
assign 1 0 363
assign 1 0 367
assign 1 87 370
new 1 87 370
assign 1 88 371
CLASSGet 0 88 371
typenameSet 1 88 372
assign 1 89 373
new 0 89 373
heldSet 1 89 374
addValue 1 90 375
assign 1 91 376
assign 1 94 379
typenameGet 0 94 379
assign 1 94 380
BRACESGet 0 94 380
assign 1 94 381
equals 1 94 386
assign 1 94 387
containerGet 0 94 387
assign 1 94 388
typenameGet 0 94 388
assign 1 94 389
CLASSGet 0 94 389
assign 1 94 390
equals 1 94 395
assign 1 0 396
assign 1 0 399
assign 1 0 403
assign 1 94 406
typenameGet 0 94 406
assign 1 94 407
IDGet 0 94 407
assign 1 94 408
equals 1 94 413
assign 1 0 414
assign 1 0 417
assign 1 0 421
assign 1 96 424
new 1 96 424
assign 1 97 425
METHODGet 0 97 425
typenameSet 1 97 426
assign 1 98 427
new 0 98 427
heldSet 1 98 428
addValue 1 99 429
assign 1 100 430
assign 1 103 432
typenameGet 0 103 432
assign 1 103 433
BRACESGet 0 103 433
assign 1 103 434
equals 1 103 439
assign 1 103 440
typenameGet 0 103 440
assign 1 103 441
BRACESGet 0 103 441
assign 1 103 442
equals 1 103 447
assign 1 0 448
assign 1 0 451
assign 1 0 455
assign 1 105 458
new 1 105 458
assign 1 106 459
PROPERTIESGet 0 106 459
typenameSet 1 106 460
assign 1 107 461
new 0 107 461
heldSet 1 107 462
addValue 1 108 463
assign 1 109 464
assign 1 112 466
typenameGet 0 112 466
assign 1 112 467
RPARENSGet 0 112 467
assign 1 112 468
equals 1 112 473
assign 1 113 474
stepBack 1 113 474
assign 1 114 477
typenameGet 0 114 477
assign 1 114 478
RIDXGet 0 114 478
assign 1 114 479
equals 1 114 484
assign 1 115 485
stepBack 1 115 485
assign 1 116 488
typenameGet 0 116 488
assign 1 116 489
RBRACESGet 0 116 489
assign 1 116 490
equals 1 116 495
assign 1 117 496
stepBack 1 117 496
assign 1 118 497
undef 1 118 502
assign 1 119 503
new 0 119 503
assign 1 119 504
new 2 119 504
throw 1 119 505
assign 1 121 507
stepBack 1 121 507
assign 1 122 508
undef 1 122 513
assign 1 123 514
new 0 123 514
assign 1 123 515
new 2 123 515
throw 1 123 516
addValue 1 126 520
assign 1 128 524
typenameGet 0 128 524
assign 1 128 525
has 1 128 525
assign 1 129 527
assign 1 136 542
containerGet 0 136 542
assign 1 137 543
undef 1 137 548
assign 1 138 549
new 0 138 549
assign 1 138 550
new 2 138 550
throw 1 138 551
return 1 140 553
return 1 0 556
return 1 0 559
assign 1 0 562
assign 1 0 566
return 1 0 570
return 1 0 573
assign 1 0 576
assign 1 0 580
return 1 0 584
return 1 0 587
assign 1 0 590
assign 1 0 594
return 1 0 598
return 1 0 601
assign 1 0 604
assign 1 0 608
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1714302458: return bem_tagGet_0();
case 2087395772: return bem_print_0();
case 1780712404: return bem_toAny_0();
case 1777633931: return bem_outermostGetDirect_0();
case 1309277187: return bem_serializationIteratorGet_0();
case 216516509: return bem_copy_0();
case 643429711: return bem_many_0();
case 1195107726: return bem_ntypesGet_0();
case -743672203: return bem_toString_0();
case 1466941499: return bem_fieldIteratorGet_0();
case 1892936415: return bem_currentGet_0();
case -730850057: return bem_new_0();
case 535585918: return bem_echo_0();
case 1016157954: return bem_deserializeClassNameGet_0();
case -333666649: return bem_iteratorGet_0();
case 1002268292: return bem_buildGetDirect_0();
case -452381319: return bem_hashGet_0();
case 764172461: return bem_sourceFileNameGet_0();
case -1903112833: return bem_serializeContents_0();
case -184894195: return bem_create_0();
case -835560691: return bem_contain_0();
case -1002865577: return bem_classNameGet_0();
case -749676617: return bem_serializeToString_0();
case 757251538: return bem_currentGetDirect_0();
case 1951393559: return bem_once_0();
case -986534609: return bem_ntypesGetDirect_0();
case 1810328254: return bem_fieldNamesGet_0();
case -1520976877: return bem_buildGet_0();
case 1631460649: return bem_outermostGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -557613368: return bem_sameClass_1(bevd_0);
case 498648141: return bem_buildSet_1(bevd_0);
case -536421745: return bem_def_1(bevd_0);
case 1426897534: return bem_notEquals_1(bevd_0);
case 732303652: return bem_undefined_1(bevd_0);
case 217750778: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1551570806: return bem_outermostSetDirect_1(bevd_0);
case -1763815494: return bem_undef_1(bevd_0);
case -591733073: return bem_ntypesSet_1(bevd_0);
case 1044009063: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case -1327170073: return bem_copyTo_1(bevd_0);
case 254544143: return bem_defined_1(bevd_0);
case 842198181: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 275261050: return bem_sameObject_1(bevd_0);
case 160355701: return bem_ntypesSetDirect_1(bevd_0);
case 221919936: return bem_otherType_1(bevd_0);
case -1938939824: return bem_sameType_1(bevd_0);
case -101998890: return bem_currentSetDirect_1(bevd_0);
case 380153281: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1137381066: return bem_buildSetDirect_1(bevd_0);
case -1645106897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1522004802: return bem_otherClass_1(bevd_0);
case 1190344604: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 705847969: return bem_currentSet_1(bevd_0);
case 1172649842: return bem_outermostSet_1(bevd_0);
case 2081699415: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case 674985673: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1213162260: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1183971462: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1639843562: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 758918507: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -36988574: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1804891568: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1644786359: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -675903939: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransport_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildTransport_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildTransport();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst = (BEC_2_5_9_BuildTransport) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_type;
}
}
