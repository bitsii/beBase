package be;
/* IO:File: source/build/Transport.be */
public final class BEC_2_5_9_BuildTransport extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
private static byte[] becc_BEC_2_5_9_BuildTransport_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransport_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_1, 37));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_2, 10));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_3 = {0x4E,0x6F,0x64,0x65,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_4 = {0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x62,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_4, 12));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_5 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_5, 44));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_6 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_6, 10));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_7 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_8 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_9 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_11 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_12 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static BEC_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_inst;

public static BET_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_type;

public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildTransport_bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) throws Throwable {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
try  /* Line: 35 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 40 */ {
if (bevl_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 41 */
 else  /* Line: 40 */ {
break;
} /* Line: 40 */
} /* Line: 40 */
beva_visitor.bem_end_1(this);
} /* Line: 44 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_0;
bevt_2_tmpany_phold.bem_print_0();
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_1;
bevt_3_tmpany_phold.bem_print_0();
bevl_e.bemd_0(520256150);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_2;
bevt_4_tmpany_phold.bem_print_0();
bevl_node.bem_print_0();
bevl_nc = bevl_node.bem_containerGet_0();
while (true)
 /* Line: 53 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_3;
bevt_6_tmpany_phold.bem_print_0();
bevl_nc.bemd_0(520256150);
bevl_nc = bevl_nc.bemd_0(-1670320540);
} /* Line: 56 */
 else  /* Line: 53 */ {
break;
} /* Line: 53 */
} /* Line: 53 */
} /* Line: 53 */
 else  /* Line: 58 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_4;
bevt_7_tmpany_phold.bem_print_0();
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_5;
bevt_8_tmpany_phold.bem_print_0();
bevl_e.bemd_0(520256150);
} /* Line: 61 */
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 63 */
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_contain_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
bevt_7_tmpany_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpany_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 72 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 72 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_tmpany_phold.bevi_bool) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevt_12_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_tmpany_phold.bevi_int == bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_15_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_15_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
 else  /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 77 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 81 */ {
if (bevl_wf == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_19_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_19_tmpany_phold.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_22_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_25_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_tmpany_phold.bevi_int == bevt_26_tmpany_phold.bevi_int) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 83 */
 else  /* Line: 81 */ {
break;
} /* Line: 81 */
} /* Line: 81 */
if (bevl_wf == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_29_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_tmpany_phold.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_32_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildTransport_bels_7));
bevl_cnode.bem_heldSet_1(bevt_35_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 92 */
} /* Line: 85 */
bevt_37_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_tmpany_phold.bevi_int == bevt_38_tmpany_phold.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_41_tmpany_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_typenameGet_0();
bevt_42_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_tmpany_phold.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 95 */ {
bevt_44_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_44_tmpany_phold.bevi_int == bevt_45_tmpany_phold.bevi_int) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 95 */ {
bevl_mnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_8));
bevl_mnode.bem_heldSet_1(bevt_47_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 101 */
bevt_49_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_tmpany_phold.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_52_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_tmpany_phold.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
 else  /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 104 */ {
bevl_mnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_9));
bevl_mnode.bem_heldSet_1(bevt_55_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 110 */
bevt_57_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_tmpany_phold.bevi_int == bevt_58_tmpany_phold.bevi_int) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 114 */
 else  /* Line: 113 */ {
bevt_60_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_tmpany_phold.bevi_int == bevt_61_tmpany_phold.bevi_int) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 116 */
 else  /* Line: 113 */ {
bevt_63_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_tmpany_phold.bevi_int == bevt_64_tmpany_phold.bevi_int) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_10));
bevt_66_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_66_tmpany_phold);
} /* Line: 120 */
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_70_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_11));
bevt_69_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_69_tmpany_phold);
} /* Line: 124 */
} /* Line: 123 */
 else  /* Line: 126 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 127 */
} /* Line: 113 */
} /* Line: 113 */
bevt_72_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpany_phold = bevl_conTypes.bem_has_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevl_curr = bevl_node;
} /* Line: 130 */
} /* Line: 129 */
} /* Line: 76 */
 else  /* Line: 72 */ {
break;
} /* Line: 72 */
} /* Line: 72 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) throws Throwable {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_12));
bevt_1_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpany_phold, beva_curr);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 139 */
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildGetDirect_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_outermostGetDirect_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_outermostSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_currentGetDirect_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 18, 19, 20, 22, 22, 23, 23, 27, 28, 28, 29, 30, 36, 38, 40, 40, 41, 44, 46, 46, 47, 47, 48, 48, 49, 50, 50, 51, 52, 53, 53, 54, 54, 55, 56, 59, 59, 60, 60, 61, 63, 68, 68, 69, 70, 71, 72, 72, 75, 76, 76, 76, 77, 77, 77, 77, 77, 77, 77, 77, 0, 0, 0, 80, 81, 81, 81, 81, 81, 81, 0, 81, 81, 81, 81, 0, 0, 0, 82, 82, 82, 82, 0, 0, 0, 0, 0, 83, 85, 85, 85, 85, 85, 85, 0, 85, 85, 85, 85, 0, 0, 0, 0, 0, 88, 89, 89, 90, 90, 91, 92, 95, 95, 95, 95, 95, 95, 95, 95, 95, 0, 0, 0, 95, 95, 95, 95, 0, 0, 0, 97, 98, 98, 99, 99, 100, 101, 104, 104, 104, 104, 104, 104, 104, 104, 0, 0, 0, 106, 107, 107, 108, 108, 109, 110, 113, 113, 113, 113, 114, 115, 115, 115, 115, 116, 117, 117, 117, 117, 118, 119, 119, 120, 120, 120, 122, 123, 123, 124, 124, 124, 127, 129, 129, 130, 137, 138, 138, 139, 139, 139, 141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {38, 39, 40, 41, 42, 43, 44, 45, 46, 51, 52, 53, 54, 55, 72, 73, 76, 81, 82, 88, 92, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 109, 114, 115, 116, 117, 118, 126, 127, 128, 129, 130, 132, 218, 219, 220, 221, 222, 223, 226, 228, 229, 230, 235, 236, 237, 238, 243, 244, 245, 246, 251, 252, 255, 259, 262, 265, 270, 271, 272, 273, 278, 279, 282, 283, 284, 289, 290, 293, 297, 300, 301, 302, 307, 308, 311, 315, 318, 322, 325, 331, 336, 337, 338, 339, 344, 345, 348, 349, 350, 355, 356, 359, 363, 366, 370, 373, 374, 375, 376, 377, 378, 379, 382, 383, 384, 389, 390, 391, 392, 393, 398, 399, 402, 406, 409, 410, 411, 416, 417, 420, 424, 427, 428, 429, 430, 431, 432, 433, 435, 436, 437, 442, 443, 444, 445, 450, 451, 454, 458, 461, 462, 463, 464, 465, 466, 467, 469, 470, 471, 476, 477, 480, 481, 482, 487, 488, 491, 492, 493, 498, 499, 500, 505, 506, 507, 508, 510, 511, 516, 517, 518, 519, 523, 527, 528, 530, 545, 546, 551, 552, 553, 554, 556, 559, 562, 565, 569, 573, 576, 579, 583, 587, 590, 593, 597, 601, 604, 607, 611};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 38
assign 1 18 39
constantsGet 0 18 39
assign 1 18 40
ntypesGet 0 18 40
assign 1 19 41
new 1 19 41
assign 1 20 42
assign 1 22 43
TRANSUNITGet 0 22 43
typenameSet 1 22 44
assign 1 23 45
new 0 23 45
heldSet 1 23 46
assign 1 27 51
assign 1 28 52
constantsGet 0 28 52
assign 1 28 53
ntypesGet 0 28 53
assign 1 29 54
assign 1 30 55
begin 1 36 72
assign 1 38 73
accept 1 38 73
assign 1 40 76
def 1 40 81
assign 1 41 82
accept 1 41 82
end 1 44 88
assign 1 46 92
def 1 46 97
assign 1 47 98
new 0 47 98
print 0 47 99
assign 1 48 100
new 0 48 100
print 0 48 101
print 0 49 102
assign 1 50 103
new 0 50 103
print 0 50 104
print 0 51 105
assign 1 52 106
containerGet 0 52 106
assign 1 53 109
def 1 53 114
assign 1 54 115
new 0 54 115
print 0 54 116
print 0 55 117
assign 1 56 118
containerGet 0 56 118
assign 1 59 126
new 0 59 126
print 0 59 127
assign 1 60 128
new 0 60 128
print 0 60 129
print 0 61 130
throw 1 63 132
assign 1 68 218
constantsGet 0 68 218
assign 1 68 219
conTypesGet 0 68 219
assign 1 69 220
assign 1 70 221
containedGet 0 70 221
containedSet 1 71 222
assign 1 72 223
linkedListIteratorGet 0 72 223
assign 1 72 226
hasNextGet 0 72 226
assign 1 75 228
nextGet 0 75 228
assign 1 76 229
delayDeleteGet 0 76 229
assign 1 76 230
not 0 76 235
assign 1 77 236
typenameGet 0 77 236
assign 1 77 237
TRANSUNITGet 0 77 237
assign 1 77 238
equals 1 77 243
assign 1 77 244
typenameGet 0 77 244
assign 1 77 245
IDGet 0 77 245
assign 1 77 246
equals 1 77 251
assign 1 0 252
assign 1 0 255
assign 1 0 259
assign 1 80 262
assign 1 81 265
def 1 81 270
assign 1 81 271
typenameGet 0 81 271
assign 1 81 272
IDGet 0 81 272
assign 1 81 273
equals 1 81 278
assign 1 0 279
assign 1 81 282
typenameGet 0 81 282
assign 1 81 283
COLONGet 0 81 283
assign 1 81 284
equals 1 81 289
assign 1 0 290
assign 1 0 293
assign 1 0 297
assign 1 82 300
typenameGet 0 82 300
assign 1 82 301
SPACEGet 0 82 301
assign 1 82 302
equals 1 82 307
assign 1 0 308
assign 1 0 311
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 83 325
nextPeerGet 0 83 325
assign 1 85 331
def 1 85 336
assign 1 85 337
typenameGet 0 85 337
assign 1 85 338
PARENSGet 0 85 338
assign 1 85 339
equals 1 85 344
assign 1 0 345
assign 1 85 348
typenameGet 0 85 348
assign 1 85 349
BRACESGet 0 85 349
assign 1 85 350
equals 1 85 355
assign 1 0 356
assign 1 0 359
assign 1 0 363
assign 1 0 366
assign 1 0 370
assign 1 88 373
new 1 88 373
assign 1 89 374
CLASSGet 0 89 374
typenameSet 1 89 375
assign 1 90 376
new 0 90 376
heldSet 1 90 377
addValue 1 91 378
assign 1 92 379
assign 1 95 382
typenameGet 0 95 382
assign 1 95 383
BRACESGet 0 95 383
assign 1 95 384
equals 1 95 389
assign 1 95 390
containerGet 0 95 390
assign 1 95 391
typenameGet 0 95 391
assign 1 95 392
CLASSGet 0 95 392
assign 1 95 393
equals 1 95 398
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 95 409
typenameGet 0 95 409
assign 1 95 410
IDGet 0 95 410
assign 1 95 411
equals 1 95 416
assign 1 0 417
assign 1 0 420
assign 1 0 424
assign 1 97 427
new 1 97 427
assign 1 98 428
METHODGet 0 98 428
typenameSet 1 98 429
assign 1 99 430
new 0 99 430
heldSet 1 99 431
addValue 1 100 432
assign 1 101 433
assign 1 104 435
typenameGet 0 104 435
assign 1 104 436
BRACESGet 0 104 436
assign 1 104 437
equals 1 104 442
assign 1 104 443
typenameGet 0 104 443
assign 1 104 444
BRACESGet 0 104 444
assign 1 104 445
equals 1 104 450
assign 1 0 451
assign 1 0 454
assign 1 0 458
assign 1 106 461
new 1 106 461
assign 1 107 462
PROPERTIESGet 0 107 462
typenameSet 1 107 463
assign 1 108 464
new 0 108 464
heldSet 1 108 465
addValue 1 109 466
assign 1 110 467
assign 1 113 469
typenameGet 0 113 469
assign 1 113 470
RPARENSGet 0 113 470
assign 1 113 471
equals 1 113 476
assign 1 114 477
stepBack 1 114 477
assign 1 115 480
typenameGet 0 115 480
assign 1 115 481
RIDXGet 0 115 481
assign 1 115 482
equals 1 115 487
assign 1 116 488
stepBack 1 116 488
assign 1 117 491
typenameGet 0 117 491
assign 1 117 492
RBRACESGet 0 117 492
assign 1 117 493
equals 1 117 498
assign 1 118 499
stepBack 1 118 499
assign 1 119 500
undef 1 119 505
assign 1 120 506
new 0 120 506
assign 1 120 507
new 2 120 507
throw 1 120 508
assign 1 122 510
stepBack 1 122 510
assign 1 123 511
undef 1 123 516
assign 1 124 517
new 0 124 517
assign 1 124 518
new 2 124 518
throw 1 124 519
addValue 1 127 523
assign 1 129 527
typenameGet 0 129 527
assign 1 129 528
has 1 129 528
assign 1 130 530
assign 1 137 545
containerGet 0 137 545
assign 1 138 546
undef 1 138 551
assign 1 139 552
new 0 139 552
assign 1 139 553
new 2 139 553
throw 1 139 554
return 1 141 556
return 1 0 559
return 1 0 562
assign 1 0 565
assign 1 0 569
return 1 0 573
return 1 0 576
assign 1 0 579
assign 1 0 583
return 1 0 587
return 1 0 590
assign 1 0 593
assign 1 0 597
return 1 0 601
return 1 0 604
assign 1 0 607
assign 1 0 611
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2022113180: return bem_toAny_0();
case -1002223418: return bem_deserializeClassNameGet_0();
case 1226301190: return bem_create_0();
case 2128158896: return bem_iteratorGet_0();
case 520256150: return bem_print_0();
case -402973175: return bem_toString_0();
case 1170279007: return bem_contain_0();
case 304205171: return bem_sourceFileNameGet_0();
case 541730298: return bem_ntypesGet_0();
case -728251540: return bem_echo_0();
case -1347713072: return bem_many_0();
case 1971636542: return bem_fieldIteratorGet_0();
case -2037126438: return bem_buildGetDirect_0();
case -1400618946: return bem_ntypesGetDirect_0();
case 1545963265: return bem_tagGet_0();
case 502686321: return bem_serializeToString_0();
case -92297996: return bem_serializeContents_0();
case 1362114893: return bem_hashGet_0();
case 592499503: return bem_serializationIteratorGet_0();
case -1541237194: return bem_once_0();
case 2082915487: return bem_copy_0();
case -111187352: return bem_currentGet_0();
case 1618856360: return bem_outermostGetDirect_0();
case 911105100: return bem_outermostGet_0();
case 580957788: return bem_fieldNamesGet_0();
case -1211485847: return bem_buildGet_0();
case -302299890: return bem_new_0();
case -1350719137: return bem_currentGetDirect_0();
case -1909928939: return bem_classNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 14285247: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1896863293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -398880875: return bem_ntypesSet_1(bevd_0);
case 225439950: return bem_def_1(bevd_0);
case 456193338: return bem_equals_1(bevd_0);
case -1362962832: return bem_outermostSet_1(bevd_0);
case 52206223: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 363456632: return bem_buildSet_1(bevd_0);
case 843456674: return bem_undef_1(bevd_0);
case -1543668236: return bem_sameObject_1(bevd_0);
case -1265978299: return bem_otherType_1(bevd_0);
case 1026320185: return bem_currentSetDirect_1(bevd_0);
case -1675072243: return bem_sameType_1(bevd_0);
case 1314987666: return bem_outermostSetDirect_1(bevd_0);
case -536131782: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case -1241317639: return bem_sameClass_1(bevd_0);
case -1990059666: return bem_notEquals_1(bevd_0);
case 1175369972: return bem_currentSet_1(bevd_0);
case -1133289250: return bem_copyTo_1(bevd_0);
case -285449688: return bem_buildSetDirect_1(bevd_0);
case 1848239305: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -799657616: return bem_defined_1(bevd_0);
case 616945071: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 1493068135: return bem_ntypesSetDirect_1(bevd_0);
case 468336390: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1104827466: return bem_undefined_1(bevd_0);
case 294741010: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -541558230: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1221867320: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -679395862: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1478248032: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2109649093: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -602636079: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1942858685: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1297550285: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransport_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildTransport_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildTransport();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst = (BEC_2_5_9_BuildTransport) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_type;
}
}
