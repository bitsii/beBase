package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_EncodeHtml extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_EncodeHtml() { }
private static byte[] becc_BEC_2_6_4_EncodeHtml_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x74,0x6D,0x6C};
private static byte[] becc_BEC_2_6_4_EncodeHtml_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_0 = {0x22};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_1 = {0x3C};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_2 = {0x3E};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_3 = {0x26};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_4 = {0x26,0x23};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_5 = {0x3B};
public static BEC_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_inst;

public static BET_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_type;

public BEC_2_6_4_EncodeHtml bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_EncodeHtml bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
bevt_5_ta_ph = beva_str.bem_sizeGet_0();
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_4_ta_ph = bevt_5_ta_ph.bem_multiply_1(bevt_6_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_ta_ph);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_7_ta_ph);
while (true)
/* Line: 139*/ {
bevt_8_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_8_ta_ph.bevi_bool)/* Line: 139*/ {
bevl_tb.bem_next_1(bevl_pt);
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(127));
if (bevl_ac.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 142*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_0));
bevt_12_ta_ph = bevl_pt.bem_equals_1(bevt_13_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 142*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 142*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 142*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_1));
bevt_14_ta_ph = bevl_pt.bem_equals_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_bool)/* Line: 142*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 142*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 142*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_2));
bevt_16_ta_ph = bevl_pt.bem_equals_1(bevt_17_ta_ph);
if (bevt_16_ta_ph.bevi_bool)/* Line: 142*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 142*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 142*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_3));
bevt_18_ta_ph = bevl_pt.bem_equals_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 142*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 142*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 142*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 142*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_4_EncodeHtml_bels_4));
bevl_r.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = bevl_ac.bem_toString_0();
bevl_r.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_5));
bevl_r.bem_addValue_1(bevt_22_ta_ph);
} /* Line: 145*/
 else /* Line: 146*/ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 147*/
} /* Line: 142*/
 else /* Line: 139*/ {
break;
} /* Line: 139*/
} /* Line: 139*/
return bevl_r;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {136, 136, 136, 136, 137, 138, 138, 139, 140, 141, 141, 142, 142, 142, 0, 142, 142, 0, 0, 0, 142, 142, 0, 0, 0, 142, 142, 0, 0, 0, 142, 142, 0, 0, 143, 143, 144, 144, 145, 145, 147, 150};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {53, 54, 55, 56, 57, 58, 59, 62, 64, 65, 66, 67, 68, 73, 74, 77, 78, 80, 83, 87, 90, 91, 93, 96, 100, 103, 104, 106, 109, 113, 116, 117, 119, 122, 126, 127, 128, 129, 130, 131, 134, 141};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 136 53
sizeGet 0 136 53
assign 1 136 54
new 0 136 54
assign 1 136 55
multiply 1 136 55
assign 1 136 56
new 1 136 56
assign 1 137 57
new 1 137 57
assign 1 138 58
new 0 138 58
assign 1 138 59
new 1 138 59
assign 1 139 62
hasNextGet 0 139 62
next 1 140 64
assign 1 141 65
new 0 141 65
assign 1 141 66
getCode 1 141 66
assign 1 142 67
new 0 142 67
assign 1 142 68
greater 1 142 73
assign 1 0 74
assign 1 142 77
new 0 142 77
assign 1 142 78
equals 1 142 78
assign 1 0 80
assign 1 0 83
assign 1 0 87
assign 1 142 90
new 0 142 90
assign 1 142 91
equals 1 142 91
assign 1 0 93
assign 1 0 96
assign 1 0 100
assign 1 142 103
new 0 142 103
assign 1 142 104
equals 1 142 104
assign 1 0 106
assign 1 0 109
assign 1 0 113
assign 1 142 116
new 0 142 116
assign 1 142 117
equals 1 142 117
assign 1 0 119
assign 1 0 122
assign 1 143 126
new 0 143 126
addValue 1 143 127
assign 1 144 128
toString 0 144 128
addValue 1 144 129
assign 1 145 130
new 0 145 130
addValue 1 145 131
addValue 1 147 134
return 1 150 141
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -538472806: return bem_toString_0();
case -913633167: return bem_create_0();
case 705768714: return bem_hashGet_0();
case 1214951712: return bem_copy_0();
case 1592655621: return bem_iteratorGet_0();
case 1237286351: return bem_new_0();
case 1743441213: return bem_print_0();
case -369370936: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1447238914: return bem_undef_1(bevd_0);
case 2063097426: return bem_copyTo_1(bevd_0);
case 1250588228: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 1117275607: return bem_equals_1(bevd_0);
case -92722830: return bem_notEquals_1(bevd_0);
case -1873180946: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2117068130: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 105174404: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -77288097: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -828010984: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_EncodeHtml_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_4_EncodeHtml_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_EncodeHtml();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst = (BEC_2_6_4_EncodeHtml) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_type;
}
}
