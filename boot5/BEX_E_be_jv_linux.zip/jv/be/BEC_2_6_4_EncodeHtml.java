package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_EncodeHtml extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_EncodeHtml() { }
private static byte[] becc_BEC_2_6_4_EncodeHtml_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x74,0x6D,0x6C};
private static byte[] becc_BEC_2_6_4_EncodeHtml_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_4_EncodeHtml_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_4_EncodeHtml_bevo_1 = (new BEC_2_4_3_MathInt(127));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_0 = {0x22};
private static BEC_2_4_6_TextString bece_BEC_2_6_4_EncodeHtml_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_4_EncodeHtml_bels_0, 1));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_1 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_6_4_EncodeHtml_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_4_EncodeHtml_bels_1, 1));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_2 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_6_4_EncodeHtml_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_4_EncodeHtml_bels_2, 1));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_3 = {0x26};
private static BEC_2_4_6_TextString bece_BEC_2_6_4_EncodeHtml_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_4_EncodeHtml_bels_3, 1));
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_4 = {0x26,0x23};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_5 = {0x3B};
public static BEC_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_inst;

public static BET_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_type;

public BEC_2_6_4_EncodeHtml bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_4_EncodeHtml bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
bevt_5_ta_ph = beva_str.bem_sizeGet_0();
bevt_6_ta_ph = bece_BEC_2_6_4_EncodeHtml_bevo_0;
bevt_4_ta_ph = bevt_5_ta_ph.bem_multiply_1(bevt_6_ta_ph);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_ta_ph);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_7_ta_ph);
while (true)
/* Line: 185*/ {
bevt_8_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_8_ta_ph.bevi_bool)/* Line: 185*/ {
bevl_tb.bem_next_1(bevl_pt);
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_9_ta_ph);
bevt_11_ta_ph = bece_BEC_2_6_4_EncodeHtml_bevo_1;
if (bevl_ac.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_13_ta_ph = bece_BEC_2_6_4_EncodeHtml_bevo_2;
bevt_12_ta_ph = bevl_pt.bem_equals_1(bevt_13_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 188*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 188*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_15_ta_ph = bece_BEC_2_6_4_EncodeHtml_bevo_3;
bevt_14_ta_ph = bevl_pt.bem_equals_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 188*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 188*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_17_ta_ph = bece_BEC_2_6_4_EncodeHtml_bevo_4;
bevt_16_ta_ph = bevl_pt.bem_equals_1(bevt_17_ta_ph);
if (bevt_16_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 188*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 188*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_19_ta_ph = bece_BEC_2_6_4_EncodeHtml_bevo_5;
bevt_18_ta_ph = bevl_pt.bem_equals_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 188*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 188*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_4_EncodeHtml_bels_4));
bevl_r.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = bevl_ac.bem_toString_0();
bevl_r.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_5));
bevl_r.bem_addValue_1(bevt_22_ta_ph);
} /* Line: 191*/
 else /* Line: 192*/ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 193*/
} /* Line: 188*/
 else /* Line: 185*/ {
break;
} /* Line: 185*/
} /* Line: 185*/
return bevl_r;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {182, 182, 182, 182, 183, 184, 184, 185, 186, 187, 187, 188, 188, 188, 0, 188, 188, 0, 0, 0, 188, 188, 0, 0, 0, 188, 188, 0, 0, 0, 188, 188, 0, 0, 189, 189, 190, 190, 191, 191, 193, 196};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {59, 60, 61, 62, 63, 64, 65, 68, 70, 71, 72, 73, 74, 79, 80, 83, 84, 86, 89, 93, 96, 97, 99, 102, 106, 109, 110, 112, 115, 119, 122, 123, 125, 128, 132, 133, 134, 135, 136, 137, 140, 147};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 182 59
sizeGet 0 182 59
assign 1 182 60
new 0 182 60
assign 1 182 61
multiply 1 182 61
assign 1 182 62
new 1 182 62
assign 1 183 63
new 1 183 63
assign 1 184 64
new 0 184 64
assign 1 184 65
new 1 184 65
assign 1 185 68
hasNextGet 0 185 68
next 1 186 70
assign 1 187 71
new 0 187 71
assign 1 187 72
getCode 1 187 72
assign 1 188 73
new 0 188 73
assign 1 188 74
greater 1 188 79
assign 1 0 80
assign 1 188 83
new 0 188 83
assign 1 188 84
equals 1 188 84
assign 1 0 86
assign 1 0 89
assign 1 0 93
assign 1 188 96
new 0 188 96
assign 1 188 97
equals 1 188 97
assign 1 0 99
assign 1 0 102
assign 1 0 106
assign 1 188 109
new 0 188 109
assign 1 188 110
equals 1 188 110
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 188 122
new 0 188 122
assign 1 188 123
equals 1 188 123
assign 1 0 125
assign 1 0 128
assign 1 189 132
new 0 189 132
addValue 1 189 133
assign 1 190 134
toString 0 190 134
addValue 1 190 135
assign 1 191 136
new 0 191 136
addValue 1 191 137
addValue 1 193 140
return 1 196 147
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 310047227: return bem_fieldNamesGet_0();
case 221458969: return bem_serializeToString_0();
case -912342775: return bem_deserializeClassNameGet_0();
case 78412540: return bem_toAny_0();
case -1079456517: return bem_many_0();
case -992634121: return bem_tagGet_0();
case -1238524057: return bem_print_0();
case -1851472893: return bem_once_0();
case -777537417: return bem_serializeContents_0();
case -1714583788: return bem_classNameGet_0();
case 205150354: return bem_new_0();
case -1331626162: return bem_iteratorGet_0();
case 217381802: return bem_serializationIteratorGet_0();
case 814015164: return bem_copy_0();
case 2071247075: return bem_sourceFileNameGet_0();
case -1392846471: return bem_toString_0();
case -438289515: return bem_fieldIteratorGet_0();
case -1426056679: return bem_hashGet_0();
case 993286746: return bem_echo_0();
case 137910263: return bem_create_0();
case -1201862288: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1485528301: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1321313051: return bem_sameType_1(bevd_0);
case 960896697: return bem_notEquals_1(bevd_0);
case 1458084809: return bem_def_1(bevd_0);
case 355291595: return bem_copyTo_1(bevd_0);
case 1899558954: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -453643441: return bem_defined_1(bevd_0);
case 1023055799: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 564793899: return bem_undefined_1(bevd_0);
case 945769885: return bem_sameClass_1(bevd_0);
case 2082903087: return bem_undef_1(bevd_0);
case 253322083: return bem_otherType_1(bevd_0);
case 817159411: return bem_otherClass_1(bevd_0);
case -1415567029: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case -856387066: return bem_sameObject_1(bevd_0);
case 1070255022: return bem_equals_1(bevd_0);
case 1172823997: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1902427897: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1195418117: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 300622109: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1518416217: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804526598: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -396108307: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1914950638: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_EncodeHtml_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_4_EncodeHtml_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_EncodeHtml();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst = (BEC_2_6_4_EncodeHtml) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_type;
}
}
