package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog extends BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x6C,0x6F,0x67,0x67,0x65,0x64,0x20};
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x20};
public static BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public BEC_2_6_6_SystemObject bevp_sink;
public BEC_2_2_3_IOLog bem_new_3(BEC_2_6_6_SystemObject beva__sink, BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
bevp_sink = beva__sink;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 146*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 153*/
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_2_3_IOLog bem_out_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 159*/ {
beva_msg = (new BEC_2_4_6_TextString(4, bece_BEC_2_2_3_IOLog_bels_0));
} /* Line: 160*/
if (bevp_sink == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 162*/ {
bevp_sink.bemd_1(1120778688, beva_msg);
} /* Line: 163*/
 else /* Line: 164*/ {
beva_msg.bem_print_0();
} /* Line: 165*/
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_1(BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_2_3_IOLog_bels_1));
bem_elog_2(bevt_0_ta_ph, beva_e);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_2(BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_10_SystemExceptions bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_2_3_IOLog_bels_2));
bevt_1_ta_ph = beva_msg.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_ta_ph = bevt_4_ta_ph.bem_tS_1(beva_e);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_log_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 178*/ {
bem_out_1(beva_msg);
} /* Line: 179*/
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_3(BEC_2_4_3_MathInt beva_level, BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_10_SystemExceptions bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_2_3_IOLog_bels_2));
bevt_1_ta_ph = beva_msg.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_ta_ph = bevt_4_ta_ph.bem_tS_1(beva_e);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_log_2(beva_level, bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 188*/ {
bem_out_1(beva_msg);
} /* Line: 189*/
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_debug_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(400));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_info_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(300));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_warn_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(200));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_error_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(100));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_fatal_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (new BEC_2_4_3_MathInt(0));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
bem_out_1(beva_msg);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGet_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public final BEC_2_4_3_MathInt bem_outputLevelGetDirect_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_outputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGet_0() throws Throwable {
return bevp_level;
} /*method end*/
public final BEC_2_4_3_MathInt bem_levelGetDirect_0() throws Throwable {
return bevp_level;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_levelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGet_0() throws Throwable {
return bevp_sink;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_sinkGetDirect_0() throws Throwable {
return bevp_sink;
} /*method end*/
public BEC_2_2_3_IOLog bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_sinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {138, 139, 140, 145, 145, 146, 146, 148, 148, 152, 152, 153, 153, 155, 155, 159, 159, 160, 162, 162, 163, 165, 170, 170, 174, 174, 174, 174, 174, 174, 178, 178, 179, 184, 184, 184, 184, 184, 184, 188, 188, 189, 194, 195, 199, 200, 204, 205, 209, 210, 214, 215, 219, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 27, 32, 33, 34, 36, 37, 43, 48, 49, 50, 52, 53, 58, 63, 64, 66, 71, 72, 75, 81, 82, 91, 92, 93, 94, 95, 96, 101, 106, 107, 117, 118, 119, 120, 121, 122, 127, 132, 133, 139, 140, 145, 146, 151, 152, 157, 158, 163, 164, 168, 172, 175, 178, 182, 186, 189, 192, 196, 200, 203, 206, 210};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 138 18
assign 1 139 19
assign 1 140 20
assign 1 145 27
lesserEquals 1 145 32
assign 1 146 33
new 0 146 33
return 1 146 34
assign 1 148 36
new 0 148 36
return 1 148 37
assign 1 152 43
lesserEquals 1 152 48
assign 1 153 49
new 0 153 49
return 1 153 50
assign 1 155 52
new 0 155 52
return 1 155 53
assign 1 159 58
undef 1 159 63
assign 1 160 64
new 0 160 64
assign 1 162 66
def 1 162 71
out 1 163 72
print 0 165 75
assign 1 170 81
new 0 170 81
elog 2 170 82
assign 1 174 91
new 0 174 91
assign 1 174 92
add 1 174 92
assign 1 174 93
new 0 174 93
assign 1 174 94
tS 1 174 94
assign 1 174 95
add 1 174 95
log 1 174 96
assign 1 178 101
lesserEquals 1 178 106
out 1 179 107
assign 1 184 117
new 0 184 117
assign 1 184 118
add 1 184 118
assign 1 184 119
new 0 184 119
assign 1 184 120
tS 1 184 120
assign 1 184 121
add 1 184 121
log 2 184 122
assign 1 188 127
lesserEquals 1 188 132
out 1 189 133
assign 1 194 139
new 0 194 139
log 2 195 140
assign 1 199 145
new 0 199 145
log 2 200 146
assign 1 204 151
new 0 204 151
log 2 205 152
assign 1 209 157
new 0 209 157
log 2 210 158
assign 1 214 163
new 0 214 163
log 2 215 164
out 1 219 168
return 1 0 172
return 1 0 175
assign 1 0 178
assign 1 0 182
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 994310293: return bem_iteratorGet_0();
case -1174607422: return bem_copy_0();
case -1745414938: return bem_create_0();
case -1601962676: return bem_sinkGet_0();
case 1746766090: return bem_serializationIteratorGet_0();
case 1585982298: return bem_tagGet_0();
case 1525877846: return bem_print_0();
case 1963200806: return bem_outputLevelGetDirect_0();
case 908835933: return bem_toString_0();
case 1072893100: return bem_will_0();
case 244887287: return bem_serializeContents_0();
case -1313092033: return bem_sinkGetDirect_0();
case -694931040: return bem_new_0();
case 2097107507: return bem_echo_0();
case 1849592327: return bem_hashGet_0();
case 2139031452: return bem_fieldNamesGet_0();
case -916069928: return bem_outputLevelGet_0();
case -94649607: return bem_sourceFileNameGet_0();
case 525516580: return bem_classNameGet_0();
case 1076926532: return bem_levelGetDirect_0();
case 580970970: return bem_fieldIteratorGet_0();
case -464129971: return bem_levelGet_0();
case -1643625075: return bem_serializeToString_0();
case -120024387: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -237678495: return bem_copyTo_1(bevd_0);
case -1356856758: return bem_undef_1(bevd_0);
case -371307080: return bem_sinkSetDirect_1(bevd_0);
case -2131838887: return bem_otherClass_1(bevd_0);
case -1075838088: return bem_sameObject_1(bevd_0);
case 802861470: return bem_levelSet_1(bevd_0);
case 315286609: return bem_levelSetDirect_1(bevd_0);
case 1120778688: return bem_out_1((BEC_2_4_6_TextString) bevd_0);
case -1221623252: return bem_otherType_1(bevd_0);
case -92769717: return bem_equals_1(bevd_0);
case 1036012335: return bem_outputLevelSetDirect_1(bevd_0);
case 563264225: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case 49923840: return bem_elog_1(bevd_0);
case 659596810: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case -1547762287: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 385229334: return bem_outputLevelSet_1(bevd_0);
case -267664827: return bem_def_1(bevd_0);
case -1333001724: return bem_sinkSet_1(bevd_0);
case -1631000313: return bem_warn_1((BEC_2_4_6_TextString) bevd_0);
case 1492742291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1149386561: return bem_error_1((BEC_2_4_6_TextString) bevd_0);
case -551320303: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case -1428682054: return bem_debug_1((BEC_2_4_6_TextString) bevd_0);
case 714860432: return bem_fatal_1((BEC_2_4_6_TextString) bevd_0);
case -1007949557: return bem_sameType_1(bevd_0);
case 1023057084: return bem_notEquals_1(bevd_0);
case 124163544: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 560590343: return bem_info_1((BEC_2_4_6_TextString) bevd_0);
case -1631589040: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1189693355: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2075056348: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 305981104: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 358183541: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 665469662: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1364361583: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1190401913: return bem_elog_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1286985096: return bem_elog_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1, bevd_2);
case -947140812: return bem_new_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_3_IOLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
