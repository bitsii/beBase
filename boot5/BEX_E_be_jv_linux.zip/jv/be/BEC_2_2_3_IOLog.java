package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog extends BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_0, 4));
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_1, 4));
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 4));
public static BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public BEC_2_2_3_IOLog bem_new_2(BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 137 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 144 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 150 */ {
if (beva_msg == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 151 */ {
beva_msg.bem_print_0();
} /* Line: 152 */
 else  /* Line: 153 */ {
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_0;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 154 */
} /* Line: 151 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 160 */ {
if (beva_msg == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_msg.bem_print_0();
} /* Line: 162 */
 else  /* Line: 163 */ {
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 164 */
} /* Line: 161 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (beva_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 170 */ {
beva_msg.bem_print_0();
} /* Line: 171 */
 else  /* Line: 172 */ {
bevt_1_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_2;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 173 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGet_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGet_0() throws Throwable {
return bevp_level;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {130, 131, 136, 136, 137, 137, 139, 139, 143, 143, 144, 144, 146, 146, 150, 150, 151, 151, 152, 154, 154, 160, 160, 161, 161, 162, 164, 164, 170, 170, 171, 173, 173, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 28, 33, 34, 35, 37, 38, 44, 49, 50, 51, 53, 54, 60, 65, 66, 71, 72, 75, 76, 85, 90, 91, 96, 97, 100, 101, 109, 114, 115, 118, 119, 124, 127, 131, 134};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 130 20
assign 1 131 21
assign 1 136 28
lesserEquals 1 136 33
assign 1 137 34
new 0 137 34
return 1 137 35
assign 1 139 37
new 0 139 37
return 1 139 38
assign 1 143 44
lesserEquals 1 143 49
assign 1 144 50
new 0 144 50
return 1 144 51
assign 1 146 53
new 0 146 53
return 1 146 54
assign 1 150 60
lesserEquals 1 150 65
assign 1 151 66
def 1 151 71
print 0 152 72
assign 1 154 75
new 0 154 75
print 0 154 76
assign 1 160 85
lesserEquals 1 160 90
assign 1 161 91
def 1 161 96
print 0 162 97
assign 1 164 100
new 0 164 100
print 0 164 101
assign 1 170 109
def 1 170 114
print 0 171 115
assign 1 173 118
new 0 173 118
print 0 173 119
return 1 0 124
assign 1 0 127
return 1 0 131
assign 1 0 134
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 847900593: return bem_serializeContents_0();
case -1099311989: return bem_once_0();
case -1220916727: return bem_many_0();
case 2080907218: return bem_echo_0();
case 295680270: return bem_will_0();
case 1059907561: return bem_classNameGet_0();
case 774012273: return bem_new_0();
case -1228227275: return bem_deserializeClassNameGet_0();
case 1975956372: return bem_hashGet_0();
case -389943560: return bem_outputLevelGet_0();
case -1131153280: return bem_copy_0();
case 827292547: return bem_create_0();
case 677808118: return bem_toString_0();
case 1287257037: return bem_levelGet_0();
case -362294474: return bem_sourceFileNameGet_0();
case 1616854488: return bem_print_0();
case -497405976: return bem_tagGet_0();
case 887158094: return bem_fieldIteratorGet_0();
case -1571656834: return bem_toAny_0();
case 585989692: return bem_serializeToString_0();
case 988563641: return bem_iteratorGet_0();
case -1707345921: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 197557310: return bem_undef_1(bevd_0);
case -1133393159: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1450003490: return bem_outputLevelSet_1(bevd_0);
case 410232788: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1353901329: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case -970121374: return bem_equals_1(bevd_0);
case -1649058984: return bem_sameType_1(bevd_0);
case -2138387969: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case 1998346117: return bem_undefined_1(bevd_0);
case -1542443673: return bem_copyTo_1(bevd_0);
case 1434568333: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1727272588: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1013351049: return bem_otherClass_1(bevd_0);
case 1910844205: return bem_defined_1(bevd_0);
case 1730126997: return bem_def_1(bevd_0);
case 400038136: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case -1599156894: return bem_sameClass_1(bevd_0);
case -248970787: return bem_sameObject_1(bevd_0);
case 1530043726: return bem_levelSet_1(bevd_0);
case 1248878306: return bem_notEquals_1(bevd_0);
case -1883746791: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 755484682: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -831651783: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1440576715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 119055549: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1239513525: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383341402: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1754203643: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126803346: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1576726865: return bem_new_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_3_IOLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
