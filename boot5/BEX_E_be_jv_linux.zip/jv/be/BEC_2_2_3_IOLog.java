package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog extends BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x6C,0x6F,0x67,0x67,0x65,0x64,0x20};
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 1));
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_2 = (new BEC_2_4_3_MathInt(400));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_3 = (new BEC_2_4_3_MathInt(300));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_4 = (new BEC_2_4_3_MathInt(200));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_5 = (new BEC_2_4_3_MathInt(100));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_6 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public BEC_2_6_6_SystemObject bevp_sink;
public BEC_2_2_3_IOLog bem_new_3(BEC_2_6_6_SystemObject beva__sink, BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
bevp_sink = beva__sink;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 145 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 146 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 153 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_3_IOLog bem_out_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 159 */ {
beva_msg = (new BEC_2_4_6_TextString(4, bece_BEC_2_2_3_IOLog_bels_0));
} /* Line: 160 */
if (bevp_sink == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 162 */ {
bevp_sink.bemd_1(1617083092, beva_msg);
} /* Line: 163 */
 else  /* Line: 164 */ {
beva_msg.bem_print_0();
} /* Line: 165 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_1(BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_2_3_IOLog_bels_1));
bem_elog_2(bevt_0_tmpany_phold, beva_e);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_2(BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_10_SystemExceptions bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_0;
bevt_1_tmpany_phold = beva_msg.bem_add_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_tS_1(beva_e);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bem_log_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 178 */ {
bem_out_1(beva_msg);
} /* Line: 179 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_elog_3(BEC_2_4_3_MathInt beva_level, BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_10_SystemExceptions bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_1;
bevt_1_tmpany_phold = beva_msg.bem_add_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_tS_1(beva_e);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bem_log_2(beva_level, bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 188 */ {
bem_out_1(beva_msg);
} /* Line: 189 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_debug_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_2;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_info_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_3;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_warn_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_4;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_error_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_5;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_fatal_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_6;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
bem_out_1(beva_msg);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGet_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public final BEC_2_4_3_MathInt bem_outputLevelGetDirect_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_outputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGet_0() throws Throwable {
return bevp_level;
} /*method end*/
public final BEC_2_4_3_MathInt bem_levelGetDirect_0() throws Throwable {
return bevp_level;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_levelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGet_0() throws Throwable {
return bevp_sink;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_sinkGetDirect_0() throws Throwable {
return bevp_sink;
} /*method end*/
public BEC_2_2_3_IOLog bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sink = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_sinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sink = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {138, 139, 140, 145, 145, 146, 146, 148, 148, 152, 152, 153, 153, 155, 155, 159, 159, 160, 162, 162, 163, 165, 170, 170, 174, 174, 174, 174, 174, 174, 178, 178, 179, 184, 184, 184, 184, 184, 184, 188, 188, 189, 194, 195, 199, 200, 204, 205, 209, 210, 214, 215, 219, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 34, 39, 40, 41, 43, 44, 50, 55, 56, 57, 59, 60, 65, 70, 71, 73, 78, 79, 82, 88, 89, 98, 99, 100, 101, 102, 103, 108, 113, 114, 124, 125, 126, 127, 128, 129, 134, 139, 140, 146, 147, 152, 153, 158, 159, 164, 165, 170, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203, 207, 210, 213, 217};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 138 25
assign 1 139 26
assign 1 140 27
assign 1 145 34
lesserEquals 1 145 39
assign 1 146 40
new 0 146 40
return 1 146 41
assign 1 148 43
new 0 148 43
return 1 148 44
assign 1 152 50
lesserEquals 1 152 55
assign 1 153 56
new 0 153 56
return 1 153 57
assign 1 155 59
new 0 155 59
return 1 155 60
assign 1 159 65
undef 1 159 70
assign 1 160 71
new 0 160 71
assign 1 162 73
def 1 162 78
out 1 163 79
print 0 165 82
assign 1 170 88
new 0 170 88
elog 2 170 89
assign 1 174 98
new 0 174 98
assign 1 174 99
add 1 174 99
assign 1 174 100
new 0 174 100
assign 1 174 101
tS 1 174 101
assign 1 174 102
add 1 174 102
log 1 174 103
assign 1 178 108
lesserEquals 1 178 113
out 1 179 114
assign 1 184 124
new 0 184 124
assign 1 184 125
add 1 184 125
assign 1 184 126
new 0 184 126
assign 1 184 127
tS 1 184 127
assign 1 184 128
add 1 184 128
log 2 184 129
assign 1 188 134
lesserEquals 1 188 139
out 1 189 140
assign 1 194 146
new 0 194 146
log 2 195 147
assign 1 199 152
new 0 199 152
log 2 200 153
assign 1 204 158
new 0 204 158
log 2 205 159
assign 1 209 164
new 0 209 164
log 2 210 165
assign 1 214 170
new 0 214 170
log 2 215 171
out 1 219 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 653341959: return bem_print_0();
case -1439875774: return bem_new_0();
case -408758606: return bem_levelGet_0();
case 2036147796: return bem_toString_0();
case 1430998361: return bem_serializationIteratorGet_0();
case -1551806822: return bem_toAny_0();
case -1195111829: return bem_create_0();
case -1500978633: return bem_tagGet_0();
case -1737009900: return bem_many_0();
case 573647971: return bem_iteratorGet_0();
case 724234088: return bem_outputLevelGetDirect_0();
case -1976480232: return bem_once_0();
case -1066226610: return bem_fieldNamesGet_0();
case -993292120: return bem_sinkGet_0();
case 1740048373: return bem_deserializeClassNameGet_0();
case 1201799861: return bem_serializeToString_0();
case 1525639803: return bem_sourceFileNameGet_0();
case -1337106729: return bem_levelGetDirect_0();
case 191896611: return bem_copy_0();
case -1185560539: return bem_outputLevelGet_0();
case -1759630984: return bem_classNameGet_0();
case -1748925107: return bem_echo_0();
case -1416653937: return bem_will_0();
case 985414053: return bem_sinkGetDirect_0();
case -2072472298: return bem_hashGet_0();
case -114079936: return bem_serializeContents_0();
case 2102651338: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 386393575: return bem_levelSet_1(bevd_0);
case -691871726: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case -880035762: return bem_sameType_1(bevd_0);
case -192271885: return bem_equals_1(bevd_0);
case 41576335: return bem_sinkSet_1(bevd_0);
case 460255410: return bem_elog_1(bevd_0);
case 1667191105: return bem_defined_1(bevd_0);
case -1602181776: return bem_fatal_1((BEC_2_4_6_TextString) bevd_0);
case 647304594: return bem_error_1((BEC_2_4_6_TextString) bevd_0);
case -1619315249: return bem_copyTo_1(bevd_0);
case 1364531564: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 597774296: return bem_outputLevelSet_1(bevd_0);
case -815124660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1034891559: return bem_debug_1((BEC_2_4_6_TextString) bevd_0);
case -1901491794: return bem_info_1((BEC_2_4_6_TextString) bevd_0);
case -1756981201: return bem_warn_1((BEC_2_4_6_TextString) bevd_0);
case 1629878535: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case 1648756607: return bem_otherType_1(bevd_0);
case -102295312: return bem_sameObject_1(bevd_0);
case 2076051885: return bem_otherClass_1(bevd_0);
case 1617083092: return bem_out_1((BEC_2_4_6_TextString) bevd_0);
case 1414877315: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 445097763: return bem_outputLevelSetDirect_1(bevd_0);
case 884462515: return bem_def_1(bevd_0);
case -1161602371: return bem_undef_1(bevd_0);
case 1252987088: return bem_levelSetDirect_1(bevd_0);
case 1712734594: return bem_undefined_1(bevd_0);
case 981275838: return bem_sinkSetDirect_1(bevd_0);
case 488339994: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1822592461: return bem_notEquals_1(bevd_0);
case 812284028: return bem_sameClass_1(bevd_0);
case 311590519: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 267712556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1429642677: return bem_elog_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1479117885: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1237995917: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -701073356: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1384629550: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 882168889: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2057180188: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1138175882: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -547823840: return bem_new_3(bevd_0, bevd_1, bevd_2);
case -459345442: return bem_elog_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_3_IOLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
