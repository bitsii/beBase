package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog extends BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_0, 4));
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_1, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_2 = (new BEC_2_4_3_MathInt(400));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_3 = (new BEC_2_4_3_MathInt(300));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_4 = (new BEC_2_4_3_MathInt(200));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_5 = (new BEC_2_4_3_MathInt(100));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 4));
public static BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public BEC_2_2_3_IOLog bem_new_2(BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 137 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 144 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 150 */ {
if (beva_msg == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 151 */ {
beva_msg.bem_print_0();
} /* Line: 152 */
 else  /* Line: 153 */ {
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_0;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 154 */
} /* Line: 151 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 160 */ {
if (beva_msg == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_msg.bem_print_0();
} /* Line: 162 */
 else  /* Line: 163 */ {
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 164 */
} /* Line: 161 */
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_debug_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_2;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_info_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_3;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_warn_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_4;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_error_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_5;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_fatal_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_6;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (beva_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 195 */ {
beva_msg.bem_print_0();
} /* Line: 196 */
 else  /* Line: 197 */ {
bevt_1_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_7;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 198 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGet_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public final BEC_2_4_3_MathInt bem_outputLevelGetDirect_0() throws Throwable {
return bevp_outputLevel;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_outputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGet_0() throws Throwable {
return bevp_level;
} /*method end*/
public final BEC_2_4_3_MathInt bem_levelGetDirect_0() throws Throwable {
return bevp_level;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_3_IOLog bem_levelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {130, 131, 136, 136, 137, 137, 139, 139, 143, 143, 144, 144, 146, 146, 150, 150, 151, 151, 152, 154, 154, 160, 160, 161, 161, 162, 164, 164, 170, 171, 175, 176, 180, 181, 185, 186, 190, 191, 195, 195, 196, 198, 198, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 33, 38, 39, 40, 42, 43, 49, 54, 55, 56, 58, 59, 65, 70, 71, 76, 77, 80, 81, 90, 95, 96, 101, 102, 105, 106, 113, 114, 119, 120, 125, 126, 131, 132, 137, 138, 144, 149, 150, 153, 154, 159, 162, 165, 169, 173, 176, 179, 183};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 130 25
assign 1 131 26
assign 1 136 33
lesserEquals 1 136 38
assign 1 137 39
new 0 137 39
return 1 137 40
assign 1 139 42
new 0 139 42
return 1 139 43
assign 1 143 49
lesserEquals 1 143 54
assign 1 144 55
new 0 144 55
return 1 144 56
assign 1 146 58
new 0 146 58
return 1 146 59
assign 1 150 65
lesserEquals 1 150 70
assign 1 151 71
def 1 151 76
print 0 152 77
assign 1 154 80
new 0 154 80
print 0 154 81
assign 1 160 90
lesserEquals 1 160 95
assign 1 161 96
def 1 161 101
print 0 162 102
assign 1 164 105
new 0 164 105
print 0 164 106
assign 1 170 113
new 0 170 113
log 2 171 114
assign 1 175 119
new 0 175 119
log 2 176 120
assign 1 180 125
new 0 180 125
log 2 181 126
assign 1 185 131
new 0 185 131
log 2 186 132
assign 1 190 137
new 0 190 137
log 2 191 138
assign 1 195 144
def 1 195 149
print 0 196 150
assign 1 198 153
new 0 198 153
print 0 198 154
return 1 0 159
return 1 0 162
assign 1 0 165
assign 1 0 169
return 1 0 173
return 1 0 176
assign 1 0 179
assign 1 0 183
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1323832128: return bem_outputLevelGet_0();
case -1400770094: return bem_many_0();
case -518710385: return bem_fieldNamesGet_0();
case -512236724: return bem_deserializeClassNameGet_0();
case -2091241279: return bem_create_0();
case 1349866592: return bem_toString_0();
case 1957608515: return bem_fieldIteratorGet_0();
case -1423578661: return bem_print_0();
case 835741765: return bem_outputLevelGetDirect_0();
case -923057320: return bem_serializationIteratorGet_0();
case 993759307: return bem_iteratorGet_0();
case -35248652: return bem_toAny_0();
case 923849998: return bem_levelGet_0();
case 1299948053: return bem_serializeContents_0();
case 518862870: return bem_tagGet_0();
case -914347833: return bem_new_0();
case 646589914: return bem_sourceFileNameGet_0();
case -2035208893: return bem_echo_0();
case -370608447: return bem_levelGetDirect_0();
case 1052263558: return bem_serializeToString_0();
case 675566088: return bem_classNameGet_0();
case 13807179: return bem_hashGet_0();
case 307385745: return bem_will_0();
case 758802515: return bem_once_0();
case -245363326: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 227903544: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case -537932837: return bem_equals_1(bevd_0);
case -1833161027: return bem_sameObject_1(bevd_0);
case 1810314104: return bem_fatal_1((BEC_2_4_6_TextString) bevd_0);
case -2005653387: return bem_notEquals_1(bevd_0);
case -926723473: return bem_warn_1((BEC_2_4_6_TextString) bevd_0);
case -171953712: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2014394601: return bem_outputLevelSetDirect_1(bevd_0);
case 2001974262: return bem_levelSetDirect_1(bevd_0);
case 402407801: return bem_undef_1(bevd_0);
case 588618984: return bem_levelSet_1(bevd_0);
case -547950579: return bem_copyTo_1(bevd_0);
case -1592826387: return bem_def_1(bevd_0);
case -1674802050: return bem_otherType_1(bevd_0);
case -587129343: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 812053486: return bem_sameType_1(bevd_0);
case -1717365629: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case 952140: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case -1216185952: return bem_otherClass_1(bevd_0);
case -1693162418: return bem_info_1((BEC_2_4_6_TextString) bevd_0);
case 827865695: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1973560620: return bem_sameClass_1(bevd_0);
case -641692836: return bem_outputLevelSet_1(bevd_0);
case 1105273012: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 933377729: return bem_undefined_1(bevd_0);
case -55187933: return bem_defined_1(bevd_0);
case -1243303172: return bem_debug_1((BEC_2_4_6_TextString) bevd_0);
case -1530190825: return bem_error_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1690552798: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1892518177: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1959387256: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -442347184: return bem_new_2(bevd_0, bevd_1);
case 1806992676: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039595343: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1961028109: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1977574168: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389396425: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_3_IOLog();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
