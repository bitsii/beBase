package be;
/* IO:File: source/build/Pass10.be */
public final class BEC_3_5_5_6_BuildVisitPass10 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass10() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x30};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x30,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_1 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_2 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_3 = {0x61,0x6E,0x63,0x68,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
public static BEC_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;

public static BET_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;

public BEC_2_6_6_SystemObject bem_condCall_2(BEC_2_6_6_SystemObject beva_condany, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_acc = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_5_4_BuildCall bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_ta_ph = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_cnode.bemd_1(892677962, bevt_0_ta_ph);
bevt_1_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_cnode.bemd_1(291003598, bevt_1_ta_ph);
bevl_acc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_acc.bemd_1(291003598, bevt_2_ta_ph);
bevl_acc.bemd_1(892677962, beva_condany);
bevl_cnode.bemd_1(1928436967, bevl_acc);
bevt_3_ta_ph = bevl_cnode.bemd_0(2138055363);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_0));
bevt_3_ta_ph.bemd_1(-1979954879, bevt_4_ta_ph);
bevl_nnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nnode.bemd_1(291003598, beva_value);
bevl_cnode.bemd_1(1928436967, bevl_nnode);
return bevl_cnode;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_anchor = null;
BEC_2_6_6_SystemObject bevl_condany = null;
BEC_2_6_6_SystemObject bevl_cvnp = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_rinode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_BuildNode bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_5_4_BuildNode bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_5_4_BuildNode bevt_77_ta_ph = null;
bevt_4_ta_ph = beva_node.bem_typenameGet_0();
bevt_5_ta_ph = bevp_ntypes.bem_PARENSGet_0();
if (bevt_4_ta_ph.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_8_ta_ph = beva_node.bem_containedGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_lengthGet_0();
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_7_ta_ph.bevi_int == bevt_9_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
 else /* Line: 31*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_13_ta_ph = beva_node.bem_containedGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_firstGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-514091623);
bevt_14_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(7869303, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 31*/
 else /* Line: 31*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 31*/ {
bevt_16_ta_ph = beva_node.bem_containedGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bem_firstGet_0();
beva_node.bem_takeContents_1((BEC_2_5_4_BuildNode) bevt_15_ta_ph );
return beva_node;
} /* Line: 33*/
bevt_18_ta_ph = beva_node.bem_typenameGet_0();
bevt_19_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_18_ta_ph.bevi_int == bevt_19_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_20_ta_ph = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_20_ta_ph);
beva_node.bem_syncVariable_1(this);
} /* Line: 38*/
bevt_22_ta_ph = beva_node.bem_typenameGet_0();
bevt_23_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_22_ta_ph.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 41*/ {
bevt_26_ta_ph = beva_node.bem_heldGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(-1934031533);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(7869303, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 41*/ {
bevt_30_ta_ph = beva_node.bem_heldGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(-1934031533);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_2));
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(7869303, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 41*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 41*/
 else /* Line: 41*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 41*/ {
bevl_anchor = beva_node.bem_anchorGet_0();
bevl_condany = bevl_anchor.bemd_0(210747550);
if (bevl_condany == null) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 46*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_3));
bevl_condany = bevl_anchor.bemd_2(-1170227829, bevt_33_ta_ph, bevp_build);
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
bevl_condany.bemd_1(-1386152558, bevt_34_ta_ph);
bevl_cvnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_4));
bevl_cvnp.bemd_1(962410459, bevt_35_ta_ph);
bevl_condany.bemd_1(-31489957, bevl_cvnp);
bevl_anchor.bemd_1(-1393555669, bevl_condany);
} /* Line: 52*/
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_36_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(291003598, bevt_36_ta_ph);
bevl_inode.bemd_1(-656411610, beva_node);
bevl_rinode = bevl_inode;
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(-656411610, beva_node);
bevt_37_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(291003598, bevt_37_ta_ph);
bevl_inode.bemd_1(1928436967, bevl_pnode);
bevt_39_ta_ph = beva_node.bem_containedGet_0();
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevl_pnode.bemd_1(1928436967, bevt_38_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-656411610, beva_node);
bevt_40_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(291003598, bevt_40_ta_ph);
bevl_inode.bemd_1(1928436967, bevl_bnode);
bevt_43_ta_ph = beva_node.bem_heldGet_0();
bevt_42_ta_ph = bevt_43_ta_ph.bemd_0(-1934031533);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(7869303, bevt_44_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 73*/ {
bevt_46_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_45_ta_ph = bem_condCall_2(bevl_condany, bevt_46_ta_ph);
bevl_bnode.bemd_1(1928436967, bevt_45_ta_ph);
} /* Line: 74*/
 else /* Line: 76*/ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(-656411610, beva_node);
bevt_47_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(291003598, bevt_47_ta_ph);
bevl_inode.bemd_1(-1393555669, bevl_condany);
bevl_bnode.bemd_1(1928436967, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(-656411610, beva_node);
bevt_48_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(291003598, bevt_48_ta_ph);
bevl_inode.bemd_1(1928436967, bevl_pnode);
bevt_49_ta_ph = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(1928436967, bevt_49_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-656411610, beva_node);
bevt_50_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(291003598, bevt_50_ta_ph);
bevl_inode.bemd_1(1928436967, bevl_bnode);
bevt_52_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_51_ta_ph = bem_condCall_2(bevl_condany, bevt_52_ta_ph);
bevl_bnode.bemd_1(1928436967, bevt_51_ta_ph);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(-656411610, beva_node);
bevt_53_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(291003598, bevt_53_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-656411610, beva_node);
bevt_54_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(291003598, bevt_54_ta_ph);
bevt_56_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_55_ta_ph = bem_condCall_2(bevl_condany, bevt_56_ta_ph);
bevl_bnode.bemd_1(1928436967, bevt_55_ta_ph);
bevl_enode.bemd_1(1928436967, bevl_bnode);
bevl_inode.bemd_1(1928436967, bevl_enode);
} /* Line: 103*/
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(-656411610, beva_node);
bevt_57_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(291003598, bevt_57_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-656411610, beva_node);
bevt_58_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(291003598, bevt_58_ta_ph);
bevl_rinode.bemd_1(1928436967, bevl_enode);
bevl_enode.bemd_1(1928436967, bevl_bnode);
bevt_61_ta_ph = beva_node.bem_heldGet_0();
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(-1934031533);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_59_ta_ph = bevt_60_ta_ph.bemd_1(7869303, bevt_62_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 115*/ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(-656411610, beva_node);
bevt_63_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(291003598, bevt_63_ta_ph);
bevl_inode.bemd_1(-1393555669, bevl_condany);
bevl_bnode.bemd_1(1928436967, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(-656411610, beva_node);
bevt_64_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(291003598, bevt_64_ta_ph);
bevl_inode.bemd_1(1928436967, bevl_pnode);
bevt_65_ta_ph = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(1928436967, bevt_65_ta_ph);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-656411610, beva_node);
bevt_66_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(291003598, bevt_66_ta_ph);
bevl_inode.bemd_1(1928436967, bevl_bnode);
bevt_68_ta_ph = bevp_ntypes.bem_TRUEGet_0();
bevt_67_ta_ph = bem_condCall_2(bevl_condany, bevt_68_ta_ph);
bevl_bnode.bemd_1(1928436967, bevt_67_ta_ph);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(-656411610, beva_node);
bevt_69_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(291003598, bevt_69_ta_ph);
bevl_inode.bemd_1(1928436967, bevl_enode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-656411610, beva_node);
bevt_70_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(291003598, bevt_70_ta_ph);
bevt_72_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_71_ta_ph = bem_condCall_2(bevl_condany, bevt_72_ta_ph);
bevl_bnode.bemd_1(1928436967, bevt_71_ta_ph);
bevl_enode.bemd_1(1928436967, bevl_bnode);
} /* Line: 141*/
 else /* Line: 142*/ {
bevt_74_ta_ph = bevp_ntypes.bem_FALSEGet_0();
bevt_73_ta_ph = bem_condCall_2(bevl_condany, bevt_74_ta_ph);
bevl_bnode.bemd_1(1928436967, bevt_73_ta_ph);
} /* Line: 143*/
bevl_anchor.bemd_1(-1939768824, bevl_rinode);
beva_node.bem_containedSet_1(null);
bevt_75_ta_ph = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_75_ta_ph);
beva_node.bem_heldSet_1(bevl_condany);
beva_node.bem_syncAddVariable_0();
bevt_76_ta_ph = bevl_rinode.bemd_0(1243170140);
return (BEC_2_5_4_BuildNode) bevt_76_ta_ph;
} /* Line: 152*/
bevt_77_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_77_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 17, 18, 18, 19, 20, 20, 21, 22, 23, 23, 23, 24, 25, 26, 27, 31, 31, 31, 31, 31, 31, 31, 31, 31, 0, 0, 0, 31, 31, 31, 31, 31, 0, 0, 0, 32, 32, 32, 33, 36, 36, 36, 36, 37, 37, 38, 41, 41, 41, 41, 41, 41, 41, 41, 0, 41, 41, 41, 41, 0, 0, 0, 0, 0, 43, 44, 46, 46, 47, 47, 48, 48, 49, 50, 50, 51, 52, 55, 56, 56, 57, 59, 61, 62, 63, 63, 64, 66, 66, 66, 68, 69, 70, 70, 71, 73, 73, 73, 73, 74, 74, 74, 78, 79, 80, 80, 81, 82, 84, 85, 86, 86, 87, 88, 88, 89, 90, 91, 91, 92, 93, 93, 93, 95, 96, 97, 97, 98, 99, 100, 100, 101, 101, 101, 102, 103, 106, 107, 108, 108, 109, 110, 111, 111, 112, 113, 115, 115, 115, 115, 116, 117, 118, 118, 119, 120, 122, 123, 124, 124, 125, 126, 126, 127, 128, 129, 129, 130, 131, 131, 131, 133, 134, 135, 135, 136, 137, 138, 139, 139, 140, 140, 140, 141, 143, 143, 143, 147, 148, 149, 149, 150, 151, 152, 152, 155, 155};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 130, 131, 132, 137, 138, 139, 140, 141, 146, 147, 150, 154, 157, 158, 159, 160, 161, 163, 166, 170, 173, 174, 175, 176, 178, 179, 180, 185, 186, 187, 188, 190, 191, 192, 197, 198, 199, 200, 201, 203, 206, 207, 208, 209, 211, 214, 218, 221, 225, 228, 229, 230, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 269, 270, 271, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 360, 361, 362, 364, 365, 366, 367, 368, 369, 370, 371, 373, 374};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 25
new 1 16 25
assign 1 17 26
new 0 17 26
heldSet 1 17 27
assign 1 18 28
CALLGet 0 18 28
typenameSet 1 18 29
assign 1 19 30
new 1 19 30
assign 1 20 31
VARGet 0 20 31
typenameSet 1 20 32
heldSet 1 21 33
addValue 1 22 34
assign 1 23 35
heldGet 0 23 35
assign 1 23 36
new 0 23 36
nameSet 1 23 37
assign 1 24 38
new 1 24 38
typenameSet 1 25 39
addValue 1 26 40
return 1 27 41
assign 1 31 130
typenameGet 0 31 130
assign 1 31 131
PARENSGet 0 31 131
assign 1 31 132
equals 1 31 137
assign 1 31 138
containedGet 0 31 138
assign 1 31 139
lengthGet 0 31 139
assign 1 31 140
new 0 31 140
assign 1 31 141
equals 1 31 146
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 31 157
containedGet 0 31 157
assign 1 31 158
firstGet 0 31 158
assign 1 31 159
typenameGet 0 31 159
assign 1 31 160
PARENSGet 0 31 160
assign 1 31 161
equals 1 31 161
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 32 173
containedGet 0 32 173
assign 1 32 174
firstGet 0 32 174
takeContents 1 32 175
return 1 33 176
assign 1 36 178
typenameGet 0 36 178
assign 1 36 179
IDGet 0 36 179
assign 1 36 180
equals 1 36 185
assign 1 37 186
VARGet 0 37 186
typenameSet 1 37 187
syncVariable 1 38 188
assign 1 41 190
typenameGet 0 41 190
assign 1 41 191
CALLGet 0 41 191
assign 1 41 192
equals 1 41 197
assign 1 41 198
heldGet 0 41 198
assign 1 41 199
nameGet 0 41 199
assign 1 41 200
new 0 41 200
assign 1 41 201
equals 1 41 201
assign 1 0 203
assign 1 41 206
heldGet 0 41 206
assign 1 41 207
nameGet 0 41 207
assign 1 41 208
new 0 41 208
assign 1 41 209
equals 1 41 209
assign 1 0 211
assign 1 0 214
assign 1 0 218
assign 1 0 221
assign 1 0 225
assign 1 43 228
anchorGet 0 43 228
assign 1 44 229
condanyGet 0 44 229
assign 1 46 230
undef 1 46 235
assign 1 47 236
new 0 47 236
assign 1 47 237
tmpVar 2 47 237
assign 1 48 238
new 0 48 238
isTypedSet 1 48 239
assign 1 49 240
new 0 49 240
assign 1 50 241
new 0 50 241
fromString 1 50 242
namepathSet 1 51 243
condanySet 1 52 244
assign 1 55 246
new 1 55 246
assign 1 56 247
IFGet 0 56 247
typenameSet 1 56 248
copyLoc 1 57 249
assign 1 59 250
assign 1 61 251
new 1 61 251
copyLoc 1 62 252
assign 1 63 253
PARENSGet 0 63 253
typenameSet 1 63 254
addValue 1 64 255
assign 1 66 256
containedGet 0 66 256
assign 1 66 257
firstGet 0 66 257
addValue 1 66 258
assign 1 68 259
new 1 68 259
copyLoc 1 69 260
assign 1 70 261
BRACESGet 0 70 261
typenameSet 1 70 262
addValue 1 71 263
assign 1 73 264
heldGet 0 73 264
assign 1 73 265
nameGet 0 73 265
assign 1 73 266
new 0 73 266
assign 1 73 267
equals 1 73 267
assign 1 74 269
TRUEGet 0 74 269
assign 1 74 270
condCall 2 74 270
addValue 1 74 271
assign 1 78 274
new 1 78 274
copyLoc 1 79 275
assign 1 80 276
IFGet 0 80 276
typenameSet 1 80 277
condanySet 1 81 278
addValue 1 82 279
assign 1 84 280
new 1 84 280
copyLoc 1 85 281
assign 1 86 282
PARENSGet 0 86 282
typenameSet 1 86 283
addValue 1 87 284
assign 1 88 285
secondGet 0 88 285
addValue 1 88 286
assign 1 89 287
new 1 89 287
copyLoc 1 90 288
assign 1 91 289
BRACESGet 0 91 289
typenameSet 1 91 290
addValue 1 92 291
assign 1 93 292
TRUEGet 0 93 292
assign 1 93 293
condCall 2 93 293
addValue 1 93 294
assign 1 95 295
new 1 95 295
copyLoc 1 96 296
assign 1 97 297
ELSEGet 0 97 297
typenameSet 1 97 298
assign 1 98 299
new 1 98 299
copyLoc 1 99 300
assign 1 100 301
BRACESGet 0 100 301
typenameSet 1 100 302
assign 1 101 303
FALSEGet 0 101 303
assign 1 101 304
condCall 2 101 304
addValue 1 101 305
addValue 1 102 306
addValue 1 103 307
assign 1 106 309
new 1 106 309
copyLoc 1 107 310
assign 1 108 311
ELSEGet 0 108 311
typenameSet 1 108 312
assign 1 109 313
new 1 109 313
copyLoc 1 110 314
assign 1 111 315
BRACESGet 0 111 315
typenameSet 1 111 316
addValue 1 112 317
addValue 1 113 318
assign 1 115 319
heldGet 0 115 319
assign 1 115 320
nameGet 0 115 320
assign 1 115 321
new 0 115 321
assign 1 115 322
equals 1 115 322
assign 1 116 324
new 1 116 324
copyLoc 1 117 325
assign 1 118 326
IFGet 0 118 326
typenameSet 1 118 327
condanySet 1 119 328
addValue 1 120 329
assign 1 122 330
new 1 122 330
copyLoc 1 123 331
assign 1 124 332
PARENSGet 0 124 332
typenameSet 1 124 333
addValue 1 125 334
assign 1 126 335
secondGet 0 126 335
addValue 1 126 336
assign 1 127 337
new 1 127 337
copyLoc 1 128 338
assign 1 129 339
BRACESGet 0 129 339
typenameSet 1 129 340
addValue 1 130 341
assign 1 131 342
TRUEGet 0 131 342
assign 1 131 343
condCall 2 131 343
addValue 1 131 344
assign 1 133 345
new 1 133 345
copyLoc 1 134 346
assign 1 135 347
ELSEGet 0 135 347
typenameSet 1 135 348
addValue 1 136 349
assign 1 137 350
new 1 137 350
copyLoc 1 138 351
assign 1 139 352
BRACESGet 0 139 352
typenameSet 1 139 353
assign 1 140 354
FALSEGet 0 140 354
assign 1 140 355
condCall 2 140 355
addValue 1 140 356
addValue 1 141 357
assign 1 143 360
FALSEGet 0 143 360
assign 1 143 361
condCall 2 143 361
addValue 1 143 362
beforeInsert 1 147 364
containedSet 1 148 365
assign 1 149 366
VARGet 0 149 366
typenameSet 1 149 367
heldSet 1 150 368
syncAddVariable 0 151 369
assign 1 152 370
nextDescendGet 0 152 370
return 1 152 371
assign 1 155 373
nextDescendGet 0 155 373
return 1 155 374
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1967481250: return bem_hashGet_0();
case 1890623763: return bem_copy_0();
case -1545451149: return bem_ntypesGet_0();
case 1515047198: return bem_create_0();
case 186551951: return bem_toString_0();
case 670650041: return bem_new_0();
case -643744552: return bem_iteratorGet_0();
case -712351806: return bem_buildGet_0();
case 2139846672: return bem_print_0();
case -382723170: return bem_transGet_0();
case 1179078689: return bem_constGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -924354049: return bem_transSet_1(bevd_0);
case 1882156513: return bem_copyTo_1(bevd_0);
case -874794247: return bem_buildSet_1(bevd_0);
case -1583823897: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1846677851: return bem_constSet_1(bevd_0);
case -44126037: return bem_ntypesSet_1(bevd_0);
case 754787161: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -233548354: return bem_begin_1(bevd_0);
case -1876852691: return bem_def_1(bevd_0);
case 1041331381: return bem_undef_1(bevd_0);
case 7869303: return bem_equals_1(bevd_0);
case 951741113: return bem_notEquals_1(bevd_0);
case 1380966042: return bem_end_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1779285405: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -82913763: return bem_condCall_2(bevd_0, bevd_1);
case 582832509: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -881314990: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1602342275: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1686414234: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass10_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass10_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass10();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst = (BEC_3_5_5_6_BuildVisitPass10) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;
}
}
