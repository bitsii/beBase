package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator extends BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_2, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_4, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_5, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_7, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_9, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_10, 2));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_11, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_13, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_14 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_14, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_15 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_16 = {0x21};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_16, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_17 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_18 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_18, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_19 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_19, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_20 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_20, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_21 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_21, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_22 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_22, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_23 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_23, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_24 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_24, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_25 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_25, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_26 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_26, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_27 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_27, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_28 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_28, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_29 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_29, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_30 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_30, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_31 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_31, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_32 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_32, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_33 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_33, 51));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_34 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_34, 51));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_35 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_35, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_36 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_36, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_37 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_38 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_38, 35));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_39 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_39, 1));
public static BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;

public static BET_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_type;

public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public BEC_2_3_11_XmlTagIterator bem_new_0() throws Throwable {
bevp_started = be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_line = (new BEC_2_4_3_MathInt(1));
bevp_skip = be.BECS_Runtime.boolFalse;
bevp_debug = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) throws Throwable {
bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_restart_0() throws Throwable {
bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_start_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
while (true)
 /* Line: 168 */ {
if (bevl_nxt == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_5_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_0;
bevt_4_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 168 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 169 */
 else  /* Line: 168 */ {
break;
} /* Line: 168 */
} /* Line: 168 */
if (bevl_nxt == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_8_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_1;
bevt_7_tmpany_phold = bevl_nxt.bem_equals_1(bevt_8_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
 else  /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 171 */ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 172 */
return this;
} /*method end*/
public BEC_2_3_3_XmlTag bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_3_8_XmlTextNode bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_3_7_XmlComment bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_116_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_tmpany_phold = null;
BEC_2_4_6_TextString bevt_134_tmpany_phold = null;
BEC_2_4_6_TextString bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
if (bevp_started.bevi_bool) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 177 */ {
bem_start_0();
} /* Line: 178 */
bevt_21_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_tmpany_phold.bem_quoteGet_0();
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_tmpany_phold.bem_newlineGet_0();
if (bevp_skip.bevi_bool) /* Line: 183 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(598546179);
bevp_skip = be.BECS_Runtime.boolFalse;
} /* Line: 185 */
 else  /* Line: 186 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 187 */
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 190 */ {
if (bevp_textNode.bevi_bool) /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 190 */
 else  /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 190 */ {
while (true)
 /* Line: 191 */ {
bevt_25_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_2;
bevt_24_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_25_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 193 */
 else  /* Line: 191 */ {
break;
} /* Line: 191 */
} /* Line: 191 */
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_27_tmpany_phold = bevl_accum.bem_extractString_0();
bevt_26_tmpany_phold = (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_tmpany_phold);
return bevt_26_tmpany_phold;
} /* Line: 197 */
 else  /* Line: 190 */ {
if (bevl_nxt == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_30_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_3;
bevt_29_tmpany_phold = bevl_nxt.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevl_tagName = be.BECS_Runtime.boolTrue;
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolFalse;
bevl_isStart = be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 206 */ {
bevt_32_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_4;
bevt_31_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_32_tmpany_phold);
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 206 */ {
if (bevl_pinstruct.bevi_bool) /* Line: 207 */ {
bevl_instr = be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 209 */ {
if (bevl_instr.bevi_bool) /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 209 */ {
bevt_34_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_5;
bevt_33_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_34_tmpany_phold);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 209 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 209 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_tmpany_phold = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 211 */ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 212 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 214 */
 else  /* Line: 209 */ {
break;
} /* Line: 209 */
} /* Line: 209 */
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_6));
bevl_accum.bem_addValue_1(bevt_36_tmpany_phold);
bevl_pinstruct = be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 218 */ {
if (bevl_nxt == null) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_39_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_6;
bevt_38_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_39_tmpany_phold);
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
 else  /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 218 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 219 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_41_tmpany_phold = bevl_accum.bem_toString_0();
bevt_40_tmpany_phold = (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_tmpany_phold);
return bevt_40_tmpany_phold;
} /* Line: 222 */
if (bevl_comment.bevi_bool) /* Line: 224 */ {
while (true)
 /* Line: 225 */ {
bevt_43_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_7;
bevt_42_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_43_tmpany_phold);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
bevt_45_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_8;
bevt_44_tmpany_phold = bevl_nxt.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_48_tmpany_phold = bevl_accum.bem_toString_0();
bevt_49_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_9;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_ends_1(bevt_49_tmpany_phold);
if (bevt_47_tmpany_phold.bevi_bool) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 228 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 230 */
} /* Line: 228 */
 else  /* Line: 225 */ {
break;
} /* Line: 225 */
} /* Line: 225 */
bevl_comment = be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 234 */ {
if (bevl_nxt == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_52_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_10;
bevt_51_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_52_tmpany_phold);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 234 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 235 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_12));
bevl_accum.bem_addValue_1(bevt_53_tmpany_phold);
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_55_tmpany_phold = bevl_accum.bem_extractString_0();
bevt_54_tmpany_phold = (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_tmpany_phold);
return bevt_54_tmpany_phold;
} /* Line: 239 */
if (bevl_tagName.bevi_bool) /* Line: 241 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
while (true)
 /* Line: 243 */ {
bevt_57_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_11;
bevt_56_tmpany_phold = bevl_nxt.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_58_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevt_59_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 244 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 244 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 245 */
 else  /* Line: 243 */ {
break;
} /* Line: 243 */
} /* Line: 243 */
bevt_61_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_12;
bevt_60_tmpany_phold = bevl_nxt.bem_equals_1(bevt_61_tmpany_phold);
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
bevl_accum.bem_extractString_0();
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_15));
bevl_accum.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 252 */
 else  /* Line: 247 */ {
bevt_64_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_13;
bevt_63_tmpany_phold = bevl_nxt.bem_equals_1(bevt_64_tmpany_phold);
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
bevl_accum.bem_extractString_0();
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_17));
bevl_accum.bem_addValue_1(bevt_65_tmpany_phold);
} /* Line: 258 */
 else  /* Line: 259 */ {
bevt_67_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_14;
bevt_66_tmpany_phold = bevl_nxt.bem_equals_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 262 */
while (true)
 /* Line: 264 */ {
bevt_69_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_15;
bevt_68_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_69_tmpany_phold);
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_70_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevt_72_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_16;
bevt_71_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevt_74_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_17;
bevt_73_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_74_tmpany_phold);
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 266 */
 else  /* Line: 264 */ {
break;
} /* Line: 264 */
} /* Line: 264 */
bevt_75_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 268 */
bevl_tagName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 270 */ {
bevl_myElement = (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_tmpany_phold);
} /* Line: 273 */
 else  /* Line: 274 */ {
bevl_myEndElement = (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_tmpany_phold);
bevl_myTag = bevl_myEndElement;
} /* Line: 277 */
bevt_79_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_18;
bevt_78_tmpany_phold = bevl_nxt.bem_equals_1(bevt_79_tmpany_phold);
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 279 */ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 281 */ {
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 282 */
} /* Line: 281 */
 else  /* Line: 279 */ {
bevt_81_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_19;
bevt_80_tmpany_phold = bevl_nxt.bem_equals_1(bevt_81_tmpany_phold);
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 284 */ {
if (bevl_isStart.bevi_bool) /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_tmpany_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 287 */
 else  /* Line: 279 */ {
if (bevl_isStart.bevi_bool) /* Line: 288 */ {
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 289 */
 else  /* Line: 290 */ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
} /* Line: 291 */
} /* Line: 279 */
} /* Line: 279 */
} /* Line: 279 */
} /* Line: 247 */
} /* Line: 247 */
if (bevl_attributeName.bevi_bool) /* Line: 295 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
while (true)
 /* Line: 297 */ {
bevt_84_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_20;
bevt_83_tmpany_phold = bevl_nxt.bem_equals_1(bevt_84_tmpany_phold);
if (bevt_83_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_85_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 297 */ {
bevt_86_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 298 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 299 */
 else  /* Line: 297 */ {
break;
} /* Line: 297 */
} /* Line: 297 */
while (true)
 /* Line: 301 */ {
bevt_88_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_21;
bevt_87_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_88_tmpany_phold);
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_89_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_91_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_22;
bevt_90_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_91_tmpany_phold);
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_93_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_23;
bevt_92_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_93_tmpany_phold);
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_95_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_24;
bevt_94_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_95_tmpany_phold);
if (bevt_94_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 303 */
 else  /* Line: 301 */ {
break;
} /* Line: 301 */
} /* Line: 301 */
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_96_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 306 */
bevt_98_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_25;
bevt_97_tmpany_phold = bevl_nxt.bem_equals_1(bevt_98_tmpany_phold);
if (bevt_97_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 309 */
 else  /* Line: 307 */ {
bevt_100_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_26;
bevt_99_tmpany_phold = bevl_nxt.bem_equals_1(bevt_100_tmpany_phold);
if (bevt_99_tmpany_phold.bevi_bool) /* Line: 310 */ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_tmpany_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 313 */
 else  /* Line: 314 */ {
bevt_102_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_tmpany_phold);
bevl_attributeValue = be.BECS_Runtime.boolTrue;
} /* Line: 316 */
} /* Line: 307 */
} /* Line: 307 */
if (bevl_attributeValue.bevi_bool) /* Line: 319 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
while (true)
 /* Line: 321 */ {
bevt_104_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_27;
bevt_103_tmpany_phold = bevl_nxt.bem_equals_1(bevt_104_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_105_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 321 */
if (bevt_16_tmpany_anchor.bevi_bool) /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_107_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_28;
bevt_106_tmpany_phold = bevl_nxt.bem_equals_1(bevt_107_tmpany_phold);
if (bevt_106_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 321 */
if (bevt_15_tmpany_anchor.bevi_bool) /* Line: 321 */ {
bevt_108_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 323 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 324 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
bevt_109_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 326 */ {
bevt_112_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_29;
bevt_113_tmpany_phold = bevp_line.bem_toString_0();
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_113_tmpany_phold);
bevt_110_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_110_tmpany_phold);
} /* Line: 327 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
while (true)
 /* Line: 330 */ {
bevt_114_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_115_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 331 */
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 333 */
 else  /* Line: 330 */ {
break;
} /* Line: 330 */
} /* Line: 330 */
bevt_116_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_tmpany_phold.bevi_bool) /* Line: 335 */ {
bevt_119_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_30;
bevt_120_tmpany_phold = bevp_line.bem_toString_0();
bevt_118_tmpany_phold = bevt_119_tmpany_phold.bem_add_1(bevt_120_tmpany_phold);
bevt_117_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 336 */
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_121_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_tmpany_phold);
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 340 */
} /* Line: 319 */
 else  /* Line: 206 */ {
break;
} /* Line: 206 */
} /* Line: 206 */
if (bevl_myEndElement == null) {
bevt_122_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_122_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
if (bevl_myElement == null) {
bevt_123_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_124_tmpany_phold = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 343 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 343 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 343 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
while (true)
 /* Line: 345 */ {
if (bevl_nxt == null) {
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_125_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_127_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_31;
bevt_126_tmpany_phold = bevl_nxt.bem_equals_1(bevt_127_tmpany_phold);
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_128_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 345 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 345 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 345 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(415427106);
} /* Line: 345 */
 else  /* Line: 345 */ {
break;
} /* Line: 345 */
} /* Line: 345 */
if (bevl_nxt == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_131_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_32;
bevt_130_tmpany_phold = bevl_nxt.bem_equals_1(bevt_131_tmpany_phold);
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 346 */
 else  /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_19_tmpany_anchor.bevi_bool) /* Line: 346 */ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 346 */
} /* Line: 346 */
} /* Line: 343 */
 else  /* Line: 348 */ {
if (bevl_nxt == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevl_nxt = (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_37));
} /* Line: 349 */
bevt_136_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_33;
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bem_add_1(bevl_nxt);
bevt_137_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_34;
bevt_134_tmpany_phold = bevt_135_tmpany_phold.bem_add_1(bevt_137_tmpany_phold);
bevt_133_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_133_tmpany_phold);
} /* Line: 350 */
} /* Line: 199 */
} /* Line: 190 */
return bevl_myTag;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_started.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 357 */
bevt_2_tmpany_phold = bevp_iter.bemd_0(791593169);
return (BEC_2_5_4_LogicBool) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_xmlStringGet_0() throws Throwable {
return bevp_xmlString;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startedGet_0() throws Throwable {
return bevp_started;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_xtGet_0() throws Throwable {
return bevp_xt;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_resGet_0() throws Throwable {
return bevp_res;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_textNodeGet_0() throws Throwable {
return bevp_textNode;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipGet_0() throws Throwable {
return bevp_skip;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {138, 139, 140, 141, 142, 143, 144, 145, 150, 151, 155, 159, 163, 163, 164, 165, 167, 168, 168, 168, 168, 0, 0, 0, 169, 171, 171, 171, 171, 0, 0, 0, 172, 177, 177, 178, 181, 181, 182, 182, 184, 185, 187, 189, 190, 190, 0, 0, 0, 191, 191, 192, 193, 195, 196, 197, 197, 197, 198, 198, 199, 199, 200, 201, 202, 203, 204, 205, 206, 206, 208, 0, 209, 209, 0, 0, 210, 211, 212, 212, 214, 216, 216, 217, 218, 218, 218, 218, 0, 0, 0, 219, 221, 222, 222, 222, 225, 225, 226, 227, 228, 228, 228, 228, 228, 228, 228, 0, 0, 0, 229, 230, 233, 234, 234, 234, 234, 0, 0, 0, 235, 237, 237, 238, 239, 239, 239, 242, 243, 243, 0, 243, 0, 0, 244, 244, 245, 247, 247, 248, 249, 250, 251, 252, 252, 253, 253, 254, 255, 256, 257, 258, 258, 260, 260, 261, 262, 264, 264, 264, 0, 0, 0, 264, 264, 0, 0, 0, 264, 264, 0, 0, 0, 265, 266, 268, 268, 269, 271, 272, 273, 273, 275, 276, 276, 277, 279, 279, 280, 282, 284, 284, 0, 0, 0, 285, 286, 286, 287, 289, 291, 296, 297, 297, 0, 297, 0, 0, 298, 298, 299, 301, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 302, 303, 305, 306, 306, 307, 307, 308, 309, 310, 310, 311, 312, 312, 313, 315, 315, 316, 320, 321, 321, 0, 321, 0, 0, 0, 321, 321, 0, 0, 323, 323, 324, 326, 327, 327, 327, 327, 327, 329, 330, 331, 331, 332, 333, 335, 336, 336, 336, 336, 336, 338, 339, 339, 340, 343, 343, 0, 343, 343, 343, 0, 0, 0, 0, 0, 344, 345, 345, 345, 345, 0, 345, 0, 0, 0, 0, 0, 345, 346, 346, 346, 346, 0, 0, 0, 346, 349, 349, 349, 350, 350, 350, 350, 350, 350, 353, 357, 357, 357, 357, 358, 358, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {96, 97, 98, 99, 100, 101, 102, 103, 107, 108, 112, 116, 129, 130, 131, 132, 133, 136, 141, 142, 143, 145, 148, 152, 155, 161, 166, 167, 168, 170, 173, 177, 180, 337, 342, 343, 345, 346, 347, 348, 350, 351, 354, 356, 357, 362, 364, 367, 371, 376, 377, 379, 380, 386, 387, 388, 389, 390, 393, 398, 399, 400, 402, 403, 404, 405, 406, 407, 410, 411, 414, 418, 421, 422, 424, 427, 431, 432, 434, 439, 440, 446, 447, 448, 451, 456, 457, 458, 460, 463, 467, 470, 476, 477, 478, 479, 484, 485, 487, 488, 489, 490, 492, 493, 494, 495, 500, 501, 504, 508, 511, 512, 519, 522, 527, 528, 529, 531, 534, 538, 541, 547, 548, 549, 550, 551, 552, 555, 558, 559, 561, 564, 566, 569, 573, 575, 577, 583, 584, 586, 587, 588, 589, 590, 591, 594, 595, 597, 598, 599, 600, 601, 602, 605, 606, 608, 609, 613, 614, 616, 618, 621, 625, 628, 629, 631, 634, 638, 641, 642, 644, 647, 651, 654, 655, 661, 663, 665, 667, 668, 669, 670, 673, 674, 675, 676, 678, 679, 681, 683, 687, 688, 691, 694, 698, 701, 702, 703, 704, 708, 711, 719, 722, 723, 725, 728, 730, 733, 737, 739, 741, 749, 750, 752, 754, 757, 761, 764, 765, 767, 770, 774, 777, 778, 780, 783, 787, 790, 791, 793, 796, 800, 803, 804, 810, 811, 813, 815, 816, 818, 819, 822, 823, 825, 826, 827, 828, 831, 832, 833, 838, 841, 842, 844, 847, 849, 852, 856, 859, 860, 862, 865, 869, 871, 873, 879, 881, 882, 883, 884, 885, 887, 890, 892, 894, 896, 897, 903, 905, 906, 907, 908, 909, 911, 912, 913, 914, 921, 926, 927, 930, 935, 936, 938, 941, 945, 948, 951, 955, 958, 963, 964, 965, 967, 970, 972, 975, 979, 982, 986, 989, 995, 1000, 1001, 1002, 1004, 1007, 1011, 1014, 1019, 1024, 1025, 1027, 1028, 1029, 1030, 1031, 1032, 1036, 1042, 1047, 1048, 1049, 1051, 1052, 1055, 1058, 1062, 1065, 1069, 1072, 1076, 1079, 1083, 1086, 1090, 1093, 1097, 1100, 1104, 1107, 1111, 1114};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 138 96
new 0 138 96
assign 1 139 97
new 0 139 97
assign 1 140 98
assign 1 141 99
assign 1 142 100
new 0 142 100
assign 1 143 101
new 0 143 101
assign 1 144 102
new 0 144 102
assign 1 145 103
new 0 145 103
new 0 150 107
assign 1 151 108
new 0 155 112
return 1 159 116
assign 1 163 129
tokGet 0 163 129
assign 1 163 130
tokenize 1 163 130
assign 1 164 131
iteratorGet 0 164 131
assign 1 165 132
new 0 165 132
assign 1 167 133
nextGet 0 167 133
assign 1 168 136
def 1 168 141
assign 1 168 142
new 0 168 142
assign 1 168 143
notEquals 1 168 143
assign 1 0 145
assign 1 0 148
assign 1 0 152
assign 1 169 155
nextGet 0 169 155
assign 1 171 161
def 1 171 166
assign 1 171 167
new 0 171 167
assign 1 171 168
equals 1 171 168
assign 1 0 170
assign 1 0 173
assign 1 0 177
assign 1 172 180
new 0 172 180
assign 1 177 337
not 0 177 342
start 0 178 343
assign 1 181 345
new 0 181 345
assign 1 181 346
quoteGet 0 181 346
assign 1 182 347
new 0 182 347
assign 1 182 348
newlineGet 0 182 348
assign 1 184 350
currentGet 0 184 350
assign 1 185 351
new 0 185 351
assign 1 187 354
nextGet 0 187 354
assign 1 189 356
new 0 189 356
assign 1 190 357
def 1 190 362
assign 1 0 364
assign 1 0 367
assign 1 0 371
assign 1 191 376
new 0 191 376
assign 1 191 377
notEquals 1 191 377
addValue 1 192 379
assign 1 193 380
nextGet 0 193 380
assign 1 195 386
new 0 195 386
assign 1 196 387
new 0 196 387
assign 1 197 388
extractString 0 197 388
assign 1 197 389
new 1 197 389
return 1 197 390
assign 1 198 393
def 1 198 398
assign 1 199 399
new 0 199 399
assign 1 199 400
equals 1 199 400
assign 1 200 402
new 0 200 402
assign 1 201 403
new 0 201 403
assign 1 202 404
new 0 202 404
assign 1 203 405
new 0 203 405
assign 1 204 406
new 0 204 406
assign 1 205 407
new 0 205 407
assign 1 206 410
new 0 206 410
assign 1 206 411
notEquals 1 206 411
assign 1 208 414
new 0 208 414
assign 1 0 418
assign 1 209 421
new 0 209 421
assign 1 209 422
notEquals 1 209 422
assign 1 0 424
assign 1 0 427
addValue 1 210 431
assign 1 211 432
equals 1 211 432
assign 1 212 434
not 0 212 439
assign 1 214 440
nextGet 0 214 440
assign 1 216 446
new 0 216 446
addValue 1 216 447
assign 1 217 448
new 0 217 448
assign 1 218 451
def 1 218 456
assign 1 218 457
new 0 218 457
assign 1 218 458
notEquals 1 218 458
assign 1 0 460
assign 1 0 463
assign 1 0 467
assign 1 219 470
nextGet 0 219 470
assign 1 221 476
new 0 221 476
assign 1 222 477
toString 0 222 477
assign 1 222 478
new 1 222 478
return 1 222 479
assign 1 225 484
new 0 225 484
assign 1 225 485
notEquals 1 225 485
addValue 1 226 487
assign 1 227 488
nextGet 0 227 488
assign 1 228 489
new 0 228 489
assign 1 228 490
equals 1 228 490
assign 1 228 492
toString 0 228 492
assign 1 228 493
new 0 228 493
assign 1 228 494
ends 1 228 494
assign 1 228 495
not 0 228 500
assign 1 0 501
assign 1 0 504
assign 1 0 508
addValue 1 229 511
assign 1 230 512
nextGet 0 230 512
assign 1 233 519
new 0 233 519
assign 1 234 522
def 1 234 527
assign 1 234 528
new 0 234 528
assign 1 234 529
notEquals 1 234 529
assign 1 0 531
assign 1 0 534
assign 1 0 538
assign 1 235 541
nextGet 0 235 541
assign 1 237 547
new 0 237 547
addValue 1 237 548
assign 1 238 549
new 0 238 549
assign 1 239 550
extractString 0 239 550
assign 1 239 551
new 1 239 551
return 1 239 552
assign 1 242 555
nextGet 0 242 555
assign 1 243 558
new 0 243 558
assign 1 243 559
equals 1 243 559
assign 1 0 561
assign 1 243 564
equals 1 243 564
assign 1 0 566
assign 1 0 569
assign 1 244 573
equals 1 244 573
assign 1 244 575
increment 0 244 575
assign 1 245 577
nextGet 0 245 577
assign 1 247 583
new 0 247 583
assign 1 247 584
equals 1 247 584
assign 1 248 586
new 0 248 586
assign 1 249 587
new 0 249 587
assign 1 250 588
nextGet 0 250 588
extractString 0 251 589
assign 1 252 590
new 0 252 590
addValue 1 252 591
assign 1 253 594
new 0 253 594
assign 1 253 595
equals 1 253 595
assign 1 254 597
new 0 254 597
assign 1 255 598
new 0 255 598
assign 1 256 599
nextGet 0 256 599
extractString 0 257 600
assign 1 258 601
new 0 258 601
addValue 1 258 602
assign 1 260 605
new 0 260 605
assign 1 260 606
equals 1 260 606
assign 1 261 608
new 0 261 608
assign 1 262 609
nextGet 0 262 609
assign 1 264 613
new 0 264 613
assign 1 264 614
notEquals 1 264 614
assign 1 264 616
notEquals 1 264 616
assign 1 0 618
assign 1 0 621
assign 1 0 625
assign 1 264 628
new 0 264 628
assign 1 264 629
notEquals 1 264 629
assign 1 0 631
assign 1 0 634
assign 1 0 638
assign 1 264 641
new 0 264 641
assign 1 264 642
notEquals 1 264 642
assign 1 0 644
assign 1 0 647
assign 1 0 651
addValue 1 265 654
assign 1 266 655
nextGet 0 266 655
assign 1 268 661
equals 1 268 661
assign 1 268 663
increment 0 268 663
assign 1 269 665
new 0 269 665
assign 1 271 667
new 0 271 667
assign 1 272 668
assign 1 273 669
extractString 0 273 669
nameSet 1 273 670
assign 1 275 673
new 0 275 673
assign 1 276 674
extractString 0 276 674
nameSet 1 276 675
assign 1 277 676
assign 1 279 678
new 0 279 678
assign 1 279 679
equals 1 279 679
assign 1 280 681
new 0 280 681
assign 1 282 683
new 0 282 683
assign 1 284 687
new 0 284 687
assign 1 284 688
equals 1 284 688
assign 1 0 691
assign 1 0 694
assign 1 0 698
assign 1 285 701
new 0 285 701
assign 1 286 702
new 0 286 702
isClosedSet 1 286 703
assign 1 287 704
nextGet 0 287 704
assign 1 289 708
new 0 289 708
assign 1 291 711
new 0 291 711
assign 1 296 719
nextGet 0 296 719
assign 1 297 722
new 0 297 722
assign 1 297 723
equals 1 297 723
assign 1 0 725
assign 1 297 728
equals 1 297 728
assign 1 0 730
assign 1 0 733
assign 1 298 737
equals 1 298 737
assign 1 298 739
increment 0 298 739
assign 1 299 741
nextGet 0 299 741
assign 1 301 749
new 0 301 749
assign 1 301 750
notEquals 1 301 750
assign 1 301 752
notEquals 1 301 752
assign 1 0 754
assign 1 0 757
assign 1 0 761
assign 1 301 764
new 0 301 764
assign 1 301 765
notEquals 1 301 765
assign 1 0 767
assign 1 0 770
assign 1 0 774
assign 1 301 777
new 0 301 777
assign 1 301 778
notEquals 1 301 778
assign 1 0 780
assign 1 0 783
assign 1 0 787
assign 1 301 790
new 0 301 790
assign 1 301 791
notEquals 1 301 791
assign 1 0 793
assign 1 0 796
assign 1 0 800
addValue 1 302 803
assign 1 303 804
nextGet 0 303 804
assign 1 305 810
new 0 305 810
assign 1 306 811
equals 1 306 811
assign 1 306 813
increment 0 306 813
assign 1 307 815
new 0 307 815
assign 1 307 816
equals 1 307 816
assign 1 308 818
new 0 308 818
assign 1 309 819
new 0 309 819
assign 1 310 822
new 0 310 822
assign 1 310 823
equals 1 310 823
assign 1 311 825
new 0 311 825
assign 1 312 826
new 0 312 826
isClosedSet 1 312 827
assign 1 313 828
nextGet 0 313 828
assign 1 315 831
extractString 0 315 831
addAttributeName 1 315 832
assign 1 316 833
new 0 316 833
assign 1 320 838
nextGet 0 320 838
assign 1 321 841
new 0 321 841
assign 1 321 842
equals 1 321 842
assign 1 0 844
assign 1 321 847
equals 1 321 847
assign 1 0 849
assign 1 0 852
assign 1 0 856
assign 1 321 859
new 0 321 859
assign 1 321 860
equals 1 321 860
assign 1 0 862
assign 1 0 865
assign 1 323 869
equals 1 323 869
assign 1 323 871
increment 0 323 871
assign 1 324 873
nextGet 0 324 873
assign 1 326 879
notEquals 1 326 879
assign 1 327 881
new 0 327 881
assign 1 327 882
toString 0 327 882
assign 1 327 883
add 1 327 883
assign 1 327 884
new 1 327 884
throw 1 327 885
assign 1 329 887
nextGet 0 329 887
assign 1 330 890
notEquals 1 330 890
assign 1 331 892
equals 1 331 892
assign 1 331 894
increment 0 331 894
addValue 1 332 896
assign 1 333 897
nextGet 0 333 897
assign 1 335 903
notEquals 1 335 903
assign 1 336 905
new 0 336 905
assign 1 336 906
toString 0 336 906
assign 1 336 907
add 1 336 907
assign 1 336 908
new 1 336 908
throw 1 336 909
assign 1 338 911
new 0 338 911
assign 1 339 912
extractString 0 339 912
addAttributeValue 1 339 913
assign 1 340 914
new 0 340 914
assign 1 343 921
def 1 343 926
assign 1 0 927
assign 1 343 930
def 1 343 935
assign 1 343 936
isClosedGet 0 343 936
assign 1 0 938
assign 1 0 941
assign 1 0 945
assign 1 0 948
assign 1 0 951
assign 1 344 955
nextGet 0 344 955
assign 1 345 958
def 1 345 963
assign 1 345 964
new 0 345 964
assign 1 345 965
equals 1 345 965
assign 1 0 967
assign 1 345 970
equals 1 345 970
assign 1 0 972
assign 1 0 975
assign 1 0 979
assign 1 0 982
assign 1 0 986
assign 1 345 989
nextGet 0 345 989
assign 1 346 995
def 1 346 1000
assign 1 346 1001
new 0 346 1001
assign 1 346 1002
equals 1 346 1002
assign 1 0 1004
assign 1 0 1007
assign 1 0 1011
assign 1 346 1014
new 0 346 1014
assign 1 349 1019
undef 1 349 1024
assign 1 349 1025
new 0 349 1025
assign 1 350 1027
new 0 350 1027
assign 1 350 1028
add 1 350 1028
assign 1 350 1029
new 0 350 1029
assign 1 350 1030
add 1 350 1030
assign 1 350 1031
new 1 350 1031
throw 1 350 1032
return 1 353 1036
assign 1 357 1042
not 0 357 1047
assign 1 357 1048
new 0 357 1048
return 1 357 1049
assign 1 358 1051
hasNextGet 0 358 1051
return 1 358 1052
return 1 0 1055
assign 1 0 1058
return 1 0 1062
assign 1 0 1065
return 1 0 1069
assign 1 0 1072
return 1 0 1076
assign 1 0 1079
return 1 0 1083
assign 1 0 1086
return 1 0 1090
assign 1 0 1093
return 1 0 1097
assign 1 0 1100
return 1 0 1104
assign 1 0 1107
return 1 0 1111
assign 1 0 1114
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1116073548: return bem_skipGet_0();
case 415427106: return bem_nextGet_0();
case 261159668: return bem_start_0();
case 1761568190: return bem_textNodeGet_0();
case 847900593: return bem_serializeContents_0();
case -1099311989: return bem_once_0();
case -1220916727: return bem_many_0();
case 2080907218: return bem_echo_0();
case 1059907561: return bem_classNameGet_0();
case 774012273: return bem_new_0();
case -1158108691: return bem_xtGet_0();
case -1228227275: return bem_deserializeClassNameGet_0();
case 1429926716: return bem_resGet_0();
case 806808889: return bem_lineGet_0();
case 1975956372: return bem_hashGet_0();
case 377037700: return bem_restart_0();
case 834675612: return bem_xmlStringGet_0();
case -1762512940: return bem_iterGet_0();
case -39025588: return bem_startedGet_0();
case -1131153280: return bem_copy_0();
case 827292547: return bem_create_0();
case 677808118: return bem_toString_0();
case -362294474: return bem_sourceFileNameGet_0();
case 1616854488: return bem_print_0();
case -497405976: return bem_tagGet_0();
case 887158094: return bem_fieldIteratorGet_0();
case -1571656834: return bem_toAny_0();
case -2064554684: return bem_debugGet_0();
case 791593169: return bem_hasNextGet_0();
case 585989692: return bem_serializeToString_0();
case 988563641: return bem_iteratorGet_0();
case -1707345921: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -874746036: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case -479657092: return bem_lineSet_1(bevd_0);
case 1588309089: return bem_startedSet_1(bevd_0);
case 350937889: return bem_iterSet_1(bevd_0);
case 1049601047: return bem_xmlStringSet_1(bevd_0);
case 1730126997: return bem_def_1(bevd_0);
case -248970787: return bem_sameObject_1(bevd_0);
case -1851868169: return bem_resSet_1(bevd_0);
case -1013351049: return bem_otherClass_1(bevd_0);
case -1542443673: return bem_copyTo_1(bevd_0);
case 1998346117: return bem_undefined_1(bevd_0);
case 1434568333: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1133393159: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -244827855: return bem_debugSet_1(bevd_0);
case 1962922336: return bem_xtSet_1(bevd_0);
case 1248878306: return bem_notEquals_1(bevd_0);
case -1599156894: return bem_sameClass_1(bevd_0);
case 1910844205: return bem_defined_1(bevd_0);
case 1813376011: return bem_textNodeSet_1(bevd_0);
case -1883746791: return bem_otherType_1(bevd_0);
case -1649058984: return bem_sameType_1(bevd_0);
case 197557310: return bem_undef_1(bevd_0);
case -1727272588: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -729616599: return bem_skipSet_1(bevd_0);
case 410232788: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -970121374: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 755484682: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -831651783: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1440576715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1239513525: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383341402: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1754203643: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126803346: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_11_XmlTagIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_type;
}
}
