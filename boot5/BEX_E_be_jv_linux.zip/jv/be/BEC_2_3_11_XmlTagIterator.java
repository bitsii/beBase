package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator extends BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x2D,0x2D};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x20};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x2F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3D};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x3A};
public static BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;

public static BET_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_type;

public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public BEC_2_3_11_XmlTagIterator bem_new_0() throws Throwable {
bevp_started = be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_line = (new BEC_2_4_3_MathInt(1));
bevp_skip = be.BECS_Runtime.boolFalse;
bevp_debug = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) throws Throwable {
bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_restart_0() throws Throwable {
bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_start_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_2_ta_ph = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_ta_ph.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
while (true)
/* Line: 173*/ {
if (bevl_nxt == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_4_ta_ph = bevl_nxt.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 173*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 173*/
 else /* Line: 173*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 173*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 174*/
 else /* Line: 173*/ {
break;
} /* Line: 173*/
} /* Line: 173*/
if (bevl_nxt == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 176*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_7_ta_ph = bevl_nxt.bem_equals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 176*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 176*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 176*/
 else /* Line: 176*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 176*/ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 177*/
return this;
} /*method end*/
public BEC_2_3_3_XmlTag bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_12_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_13_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_14_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_15_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_16_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_17_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_18_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_19_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_4_7_TextStrings bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_3_8_XmlTextNode bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_3_7_XmlComment bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_5_4_LogicBool bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_5_4_LogicBool bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_5_4_LogicBool bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_5_4_LogicBool bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_5_4_LogicBool bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_5_4_LogicBool bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_5_4_LogicBool bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_5_4_LogicBool bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_4_LogicBool bevt_116_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_ta_ph = null;
BEC_2_4_6_TextString bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_5_4_LogicBool bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_5_4_LogicBool bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_5_4_LogicBool bevt_126_ta_ph = null;
BEC_2_4_6_TextString bevt_127_ta_ph = null;
BEC_2_5_4_LogicBool bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_5_4_LogicBool bevt_130_ta_ph = null;
BEC_2_4_6_TextString bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_ta_ph = null;
BEC_2_4_6_TextString bevt_134_ta_ph = null;
BEC_2_4_6_TextString bevt_135_ta_ph = null;
BEC_2_4_6_TextString bevt_136_ta_ph = null;
BEC_2_4_6_TextString bevt_137_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 182*/ {
bem_start_0();
} /* Line: 183*/
bevt_21_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_ta_ph.bem_quoteGet_0();
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_ta_ph.bem_newlineGet_0();
if (bevp_skip.bevi_bool)/* Line: 188*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(253834629);
bevp_skip = be.BECS_Runtime.boolFalse;
} /* Line: 190*/
 else /* Line: 191*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 192*/
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 195*/ {
if (bevp_textNode.bevi_bool)/* Line: 195*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 195*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 195*/
 else /* Line: 195*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 195*/ {
while (true)
/* Line: 196*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_24_ta_ph = bevl_nxt.bem_notEquals_1(bevt_25_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 196*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 198*/
 else /* Line: 196*/ {
break;
} /* Line: 196*/
} /* Line: 196*/
bevp_textNode = be.BECS_Runtime.boolFalse;
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_27_ta_ph = bevl_accum.bem_extractString_0();
bevt_26_ta_ph = (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_ta_ph);
return bevt_26_ta_ph;
} /* Line: 202*/
 else /* Line: 195*/ {
if (bevl_nxt == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 203*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_29_ta_ph = bevl_nxt.bem_equals_1(bevt_30_ta_ph);
if (bevt_29_ta_ph.bevi_bool)/* Line: 204*/ {
bevl_tagName = be.BECS_Runtime.boolTrue;
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolFalse;
bevl_isStart = be.BECS_Runtime.boolTrue;
while (true)
/* Line: 211*/ {
bevt_32_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_31_ta_ph = bevl_nxt.bem_notEquals_1(bevt_32_ta_ph);
if (bevt_31_ta_ph.bevi_bool)/* Line: 211*/ {
if (bevl_pinstruct.bevi_bool)/* Line: 212*/ {
bevl_instr = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 214*/ {
if (bevl_instr.bevi_bool)/* Line: 214*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 214*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_33_ta_ph = bevl_nxt.bem_notEquals_1(bevt_34_ta_ph);
if (bevt_33_ta_ph.bevi_bool)/* Line: 214*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 214*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 214*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 214*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_ta_ph = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_ta_ph.bevi_bool)/* Line: 216*/ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 217*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 219*/
 else /* Line: 214*/ {
break;
} /* Line: 214*/
} /* Line: 214*/
bevt_36_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_36_ta_ph);
bevl_pinstruct = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 223*/ {
if (bevl_nxt == null) {
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 223*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_38_ta_ph = bevl_nxt.bem_notEquals_1(bevt_39_ta_ph);
if (bevt_38_ta_ph.bevi_bool)/* Line: 223*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 223*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 223*/
 else /* Line: 223*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 223*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 224*/
 else /* Line: 223*/ {
break;
} /* Line: 223*/
} /* Line: 223*/
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_41_ta_ph = bevl_accum.bem_toString_0();
bevt_40_ta_ph = (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_ta_ph);
return bevt_40_ta_ph;
} /* Line: 227*/
if (bevl_comment.bevi_bool)/* Line: 229*/ {
while (true)
/* Line: 230*/ {
bevt_43_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_42_ta_ph = bevl_nxt.bem_notEquals_1(bevt_43_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 230*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_44_ta_ph = bevl_nxt.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_48_ta_ph = bevl_accum.bem_toString_0();
bevt_49_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_2));
bevt_47_ta_ph = bevt_48_ta_ph.bem_ends_1(bevt_49_ta_ph);
if (bevt_47_ta_ph.bevi_bool) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 233*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 233*/
 else /* Line: 233*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 233*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 235*/
} /* Line: 233*/
 else /* Line: 230*/ {
break;
} /* Line: 230*/
} /* Line: 230*/
bevl_comment = be.BECS_Runtime.boolFalse;
while (true)
/* Line: 239*/ {
if (bevl_nxt == null) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_51_ta_ph = bevl_nxt.bem_notEquals_1(bevt_52_ta_ph);
if (bevt_51_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 239*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 239*/
 else /* Line: 239*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 239*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 240*/
 else /* Line: 239*/ {
break;
} /* Line: 239*/
} /* Line: 239*/
bevt_53_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_53_ta_ph);
bevp_skip = be.BECS_Runtime.boolTrue;
bevt_55_ta_ph = bevl_accum.bem_extractString_0();
bevt_54_ta_ph = (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_ta_ph);
return bevt_54_ta_ph;
} /* Line: 244*/
if (bevl_tagName.bevi_bool)/* Line: 246*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
while (true)
/* Line: 248*/ {
bevt_57_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_56_ta_ph = bevl_nxt.bem_equals_1(bevt_57_ta_ph);
if (bevt_56_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 248*/ {
bevt_58_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 248*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 248*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 248*/ {
bevt_59_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_ta_ph.bevi_bool)/* Line: 249*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 249*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 250*/
 else /* Line: 248*/ {
break;
} /* Line: 248*/
} /* Line: 248*/
bevt_61_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_4));
bevt_60_ta_ph = bevl_nxt.bem_equals_1(bevt_61_ta_ph);
if (bevt_60_ta_ph.bevi_bool)/* Line: 252*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_pinstruct = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
bevl_accum.bem_extractString_0();
bevt_62_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_5));
bevl_accum.bem_addValue_1(bevt_62_ta_ph);
} /* Line: 257*/
 else /* Line: 252*/ {
bevt_64_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_6));
bevt_63_ta_ph = bevl_nxt.bem_equals_1(bevt_64_ta_ph);
if (bevt_63_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_comment = be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
bevl_accum.bem_extractString_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_7));
bevl_accum.bem_addValue_1(bevt_65_ta_ph);
} /* Line: 263*/
 else /* Line: 264*/ {
bevt_67_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_66_ta_ph = bevl_nxt.bem_equals_1(bevt_67_ta_ph);
if (bevt_66_ta_ph.bevi_bool)/* Line: 265*/ {
bevl_isStart = be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 267*/
while (true)
/* Line: 269*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_68_ta_ph = bevl_nxt.bem_notEquals_1(bevt_69_ta_ph);
if (bevt_68_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_70_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 269*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 269*/
 else /* Line: 269*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 269*/ {
bevt_72_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_71_ta_ph = bevl_nxt.bem_notEquals_1(bevt_72_ta_ph);
if (bevt_71_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 269*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 269*/
 else /* Line: 269*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 269*/ {
bevt_74_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_73_ta_ph = bevl_nxt.bem_notEquals_1(bevt_74_ta_ph);
if (bevt_73_ta_ph.bevi_bool)/* Line: 269*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 269*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 269*/
 else /* Line: 269*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 269*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 271*/
 else /* Line: 269*/ {
break;
} /* Line: 269*/
} /* Line: 269*/
bevt_75_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_ta_ph.bevi_bool)/* Line: 273*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 273*/
bevl_tagName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 275*/ {
bevl_myElement = (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_ta_ph);
} /* Line: 278*/
 else /* Line: 279*/ {
bevl_myEndElement = (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_ta_ph = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_ta_ph);
bevl_myTag = bevl_myEndElement;
} /* Line: 282*/
bevt_79_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_78_ta_ph = bevl_nxt.bem_equals_1(bevt_79_ta_ph);
if (bevt_78_ta_ph.bevi_bool)/* Line: 284*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 286*/ {
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 287*/
} /* Line: 286*/
 else /* Line: 284*/ {
bevt_81_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_80_ta_ph = bevl_nxt.bem_equals_1(bevt_81_ta_ph);
if (bevt_80_ta_ph.bevi_bool)/* Line: 289*/ {
if (bevl_isStart.bevi_bool)/* Line: 289*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 289*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 289*/
 else /* Line: 289*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 289*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 292*/
 else /* Line: 284*/ {
if (bevl_isStart.bevi_bool)/* Line: 293*/ {
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 294*/
 else /* Line: 295*/ {
bevl_attributeName = be.BECS_Runtime.boolFalse;
} /* Line: 296*/
} /* Line: 284*/
} /* Line: 284*/
} /* Line: 284*/
} /* Line: 252*/
} /* Line: 252*/
if (bevl_attributeName.bevi_bool)/* Line: 300*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
while (true)
/* Line: 302*/ {
bevt_84_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_83_ta_ph = bevl_nxt.bem_equals_1(bevt_84_ta_ph);
if (bevt_83_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_85_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_ta_ph.bevi_bool)/* Line: 302*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 302*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 302*/ {
bevt_86_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_ta_ph.bevi_bool)/* Line: 303*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 303*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 304*/
 else /* Line: 302*/ {
break;
} /* Line: 302*/
} /* Line: 302*/
while (true)
/* Line: 306*/ {
bevt_88_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_87_ta_ph = bevl_nxt.bem_notEquals_1(bevt_88_ta_ph);
if (bevt_87_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_89_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_14_ta_anchor.bevi_bool)/* Line: 306*/ {
bevt_91_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_90_ta_ph = bevl_nxt.bem_notEquals_1(bevt_91_ta_ph);
if (bevt_90_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_13_ta_anchor.bevi_bool)/* Line: 306*/ {
bevt_93_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_92_ta_ph = bevl_nxt.bem_notEquals_1(bevt_93_ta_ph);
if (bevt_92_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_12_ta_anchor.bevi_bool)/* Line: 306*/ {
bevt_95_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_9));
bevt_94_ta_ph = bevl_nxt.bem_notEquals_1(bevt_95_ta_ph);
if (bevt_94_ta_ph.bevi_bool)/* Line: 306*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 306*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 306*/
 else /* Line: 306*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_11_ta_anchor.bevi_bool)/* Line: 306*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 308*/
 else /* Line: 306*/ {
break;
} /* Line: 306*/
} /* Line: 306*/
bevl_attributeName = be.BECS_Runtime.boolFalse;
bevt_96_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_ta_ph.bevi_bool)/* Line: 311*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 311*/
bevt_98_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_97_ta_ph = bevl_nxt.bem_equals_1(bevt_98_ta_ph);
if (bevt_97_ta_ph.bevi_bool)/* Line: 312*/ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevp_textNode = be.BECS_Runtime.boolTrue;
} /* Line: 314*/
 else /* Line: 312*/ {
bevt_100_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_99_ta_ph = bevl_nxt.bem_equals_1(bevt_100_ta_ph);
if (bevt_99_ta_ph.bevi_bool)/* Line: 315*/ {
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_101_ta_ph = be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 318*/
 else /* Line: 319*/ {
bevt_102_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_ta_ph);
bevl_attributeValue = be.BECS_Runtime.boolTrue;
} /* Line: 321*/
} /* Line: 312*/
} /* Line: 312*/
if (bevl_attributeValue.bevi_bool)/* Line: 324*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
while (true)
/* Line: 326*/ {
bevt_104_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_103_ta_ph = bevl_nxt.bem_equals_1(bevt_104_ta_ph);
if (bevt_103_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 326*/ {
bevt_105_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 326*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 326*/
if (bevt_16_ta_anchor.bevi_bool)/* Line: 326*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 326*/ {
bevt_107_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_9));
bevt_106_ta_ph = bevl_nxt.bem_equals_1(bevt_107_ta_ph);
if (bevt_106_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 326*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 326*/
if (bevt_15_ta_anchor.bevi_bool)/* Line: 326*/ {
bevt_108_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_ta_ph.bevi_bool)/* Line: 328*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 328*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 329*/
 else /* Line: 326*/ {
break;
} /* Line: 326*/
} /* Line: 326*/
bevt_109_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_112_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_3_11_XmlTagIterator_bels_10));
bevt_113_ta_ph = bevp_line.bem_toString_0();
bevt_111_ta_ph = bevt_112_ta_ph.bem_add_1(bevt_113_ta_ph);
bevt_110_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_ta_ph);
throw new be.BECS_ThrowBack(bevt_110_ta_ph);
} /* Line: 332*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
while (true)
/* Line: 335*/ {
bevt_114_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_ta_ph.bevi_bool)/* Line: 335*/ {
bevt_115_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_ta_ph.bevi_bool)/* Line: 336*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 336*/
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 338*/
 else /* Line: 335*/ {
break;
} /* Line: 335*/
} /* Line: 335*/
bevt_116_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_ta_ph.bevi_bool)/* Line: 340*/ {
bevt_119_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_3_11_XmlTagIterator_bels_10));
bevt_120_ta_ph = bevp_line.bem_toString_0();
bevt_118_ta_ph = bevt_119_ta_ph.bem_add_1(bevt_120_ta_ph);
bevt_117_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_ta_ph);
throw new be.BECS_ThrowBack(bevt_117_ta_ph);
} /* Line: 341*/
bevl_attributeValue = be.BECS_Runtime.boolFalse;
bevt_121_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_ta_ph);
bevl_attributeName = be.BECS_Runtime.boolTrue;
} /* Line: 345*/
} /* Line: 324*/
 else /* Line: 211*/ {
break;
} /* Line: 211*/
} /* Line: 211*/
if (bevl_myEndElement == null) {
bevt_122_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_122_ta_ph.bevi_bool)/* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 348*/ {
if (bevl_myElement == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 348*/ {
bevt_124_ta_ph = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_ta_ph.bevi_bool)/* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 348*/
 else /* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 348*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 348*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 348*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
while (true)
/* Line: 350*/ {
if (bevl_nxt == null) {
bevt_125_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_125_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_127_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_126_ta_ph = bevl_nxt.bem_equals_1(bevt_127_ta_ph);
if (bevt_126_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 350*/ {
bevt_128_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 350*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 350*/
 else /* Line: 350*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 350*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1576658686);
} /* Line: 350*/
 else /* Line: 350*/ {
break;
} /* Line: 350*/
} /* Line: 350*/
if (bevl_nxt == null) {
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_131_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_130_ta_ph = bevl_nxt.bem_equals_1(bevt_131_ta_ph);
if (bevt_130_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 351*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 351*/
 else /* Line: 351*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_19_ta_anchor.bevi_bool)/* Line: 351*/ {
bevp_skip = be.BECS_Runtime.boolTrue;
} /* Line: 351*/
} /* Line: 351*/
} /* Line: 348*/
 else /* Line: 353*/ {
if (bevl_nxt == null) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 354*/ {
bevl_nxt = (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_11));
} /* Line: 354*/
bevt_136_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_3_11_XmlTagIterator_bels_12));
bevt_135_ta_ph = bevt_136_ta_ph.bem_add_1(bevl_nxt);
bevt_137_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_13));
bevt_134_ta_ph = bevt_135_ta_ph.bem_add_1(bevt_137_ta_ph);
bevt_133_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_ta_ph);
throw new be.BECS_ThrowBack(bevt_133_ta_ph);
} /* Line: 355*/
} /* Line: 204*/
} /* Line: 195*/
return bevl_myTag;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 362*/ {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 362*/
bevt_2_ta_ph = bevp_iter.bemd_0(1852223219);
return (BEC_2_5_4_LogicBool) bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_xmlStringGet_0() throws Throwable {
return bevp_xmlString;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startedGet_0() throws Throwable {
return bevp_started;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_xtGet_0() throws Throwable {
return bevp_xt;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_resGet_0() throws Throwable {
return bevp_res;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_iter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_textNodeGet_0() throws Throwable {
return bevp_textNode;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipGet_0() throws Throwable {
return bevp_skip;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {143, 144, 145, 146, 147, 148, 149, 150, 155, 156, 160, 164, 168, 168, 169, 170, 172, 173, 173, 173, 173, 0, 0, 0, 174, 176, 176, 176, 176, 0, 0, 0, 177, 182, 182, 183, 186, 186, 187, 187, 189, 190, 192, 194, 195, 195, 0, 0, 0, 196, 196, 197, 198, 200, 201, 202, 202, 202, 203, 203, 204, 204, 205, 206, 207, 208, 209, 210, 211, 211, 213, 0, 214, 214, 0, 0, 215, 216, 217, 217, 219, 221, 221, 222, 223, 223, 223, 223, 0, 0, 0, 224, 226, 227, 227, 227, 230, 230, 231, 232, 233, 233, 233, 233, 233, 233, 233, 0, 0, 0, 234, 235, 238, 239, 239, 239, 239, 0, 0, 0, 240, 242, 242, 243, 244, 244, 244, 247, 248, 248, 0, 248, 0, 0, 249, 249, 250, 252, 252, 253, 254, 255, 256, 257, 257, 258, 258, 259, 260, 261, 262, 263, 263, 265, 265, 266, 267, 269, 269, 269, 0, 0, 0, 269, 269, 0, 0, 0, 269, 269, 0, 0, 0, 270, 271, 273, 273, 274, 276, 277, 278, 278, 280, 281, 281, 282, 284, 284, 285, 287, 289, 289, 0, 0, 0, 290, 291, 291, 292, 294, 296, 301, 302, 302, 0, 302, 0, 0, 303, 303, 304, 306, 306, 306, 0, 0, 0, 306, 306, 0, 0, 0, 306, 306, 0, 0, 0, 306, 306, 0, 0, 0, 307, 308, 310, 311, 311, 312, 312, 313, 314, 315, 315, 316, 317, 317, 318, 320, 320, 321, 325, 326, 326, 0, 326, 0, 0, 0, 326, 326, 0, 0, 328, 328, 329, 331, 332, 332, 332, 332, 332, 334, 335, 336, 336, 337, 338, 340, 341, 341, 341, 341, 341, 343, 344, 344, 345, 348, 348, 0, 348, 348, 348, 0, 0, 0, 0, 0, 349, 350, 350, 350, 350, 0, 350, 0, 0, 0, 0, 0, 350, 351, 351, 351, 351, 0, 0, 0, 351, 354, 354, 354, 355, 355, 355, 355, 355, 355, 358, 362, 362, 362, 362, 363, 363, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 46, 47, 51, 55, 68, 69, 70, 71, 72, 75, 80, 81, 82, 84, 87, 91, 94, 100, 105, 106, 107, 109, 112, 116, 119, 276, 281, 282, 284, 285, 286, 287, 289, 290, 293, 295, 296, 301, 303, 306, 310, 315, 316, 318, 319, 325, 326, 327, 328, 329, 332, 337, 338, 339, 341, 342, 343, 344, 345, 346, 349, 350, 353, 357, 360, 361, 363, 366, 370, 371, 373, 378, 379, 385, 386, 387, 390, 395, 396, 397, 399, 402, 406, 409, 415, 416, 417, 418, 423, 424, 426, 427, 428, 429, 431, 432, 433, 434, 439, 440, 443, 447, 450, 451, 458, 461, 466, 467, 468, 470, 473, 477, 480, 486, 487, 488, 489, 490, 491, 494, 497, 498, 500, 503, 505, 508, 512, 514, 516, 522, 523, 525, 526, 527, 528, 529, 530, 533, 534, 536, 537, 538, 539, 540, 541, 544, 545, 547, 548, 552, 553, 555, 557, 560, 564, 567, 568, 570, 573, 577, 580, 581, 583, 586, 590, 593, 594, 600, 602, 604, 606, 607, 608, 609, 612, 613, 614, 615, 617, 618, 620, 622, 626, 627, 630, 633, 637, 640, 641, 642, 643, 647, 650, 658, 661, 662, 664, 667, 669, 672, 676, 678, 680, 688, 689, 691, 693, 696, 700, 703, 704, 706, 709, 713, 716, 717, 719, 722, 726, 729, 730, 732, 735, 739, 742, 743, 749, 750, 752, 754, 755, 757, 758, 761, 762, 764, 765, 766, 767, 770, 771, 772, 777, 780, 781, 783, 786, 788, 791, 795, 798, 799, 801, 804, 808, 810, 812, 818, 820, 821, 822, 823, 824, 826, 829, 831, 833, 835, 836, 842, 844, 845, 846, 847, 848, 850, 851, 852, 853, 860, 865, 866, 869, 874, 875, 877, 880, 884, 887, 890, 894, 897, 902, 903, 904, 906, 909, 911, 914, 918, 921, 925, 928, 934, 939, 940, 941, 943, 946, 950, 953, 958, 963, 964, 966, 967, 968, 969, 970, 971, 975, 981, 986, 987, 988, 990, 991, 994, 997, 1001, 1004, 1008, 1011, 1015, 1018, 1022, 1025, 1029, 1032, 1036, 1039, 1043, 1046, 1050, 1053};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 143 35
new 0 143 35
assign 1 144 36
new 0 144 36
assign 1 145 37
assign 1 146 38
assign 1 147 39
new 0 147 39
assign 1 148 40
new 0 148 40
assign 1 149 41
new 0 149 41
assign 1 150 42
new 0 150 42
new 0 155 46
assign 1 156 47
new 0 160 51
return 1 164 55
assign 1 168 68
tokGet 0 168 68
assign 1 168 69
tokenize 1 168 69
assign 1 169 70
iteratorGet 0 169 70
assign 1 170 71
new 0 170 71
assign 1 172 72
nextGet 0 172 72
assign 1 173 75
def 1 173 80
assign 1 173 81
new 0 173 81
assign 1 173 82
notEquals 1 173 82
assign 1 0 84
assign 1 0 87
assign 1 0 91
assign 1 174 94
nextGet 0 174 94
assign 1 176 100
def 1 176 105
assign 1 176 106
new 0 176 106
assign 1 176 107
equals 1 176 107
assign 1 0 109
assign 1 0 112
assign 1 0 116
assign 1 177 119
new 0 177 119
assign 1 182 276
not 0 182 281
start 0 183 282
assign 1 186 284
new 0 186 284
assign 1 186 285
quoteGet 0 186 285
assign 1 187 286
new 0 187 286
assign 1 187 287
newlineGet 0 187 287
assign 1 189 289
currentGet 0 189 289
assign 1 190 290
new 0 190 290
assign 1 192 293
nextGet 0 192 293
assign 1 194 295
new 0 194 295
assign 1 195 296
def 1 195 301
assign 1 0 303
assign 1 0 306
assign 1 0 310
assign 1 196 315
new 0 196 315
assign 1 196 316
notEquals 1 196 316
addValue 1 197 318
assign 1 198 319
nextGet 0 198 319
assign 1 200 325
new 0 200 325
assign 1 201 326
new 0 201 326
assign 1 202 327
extractString 0 202 327
assign 1 202 328
new 1 202 328
return 1 202 329
assign 1 203 332
def 1 203 337
assign 1 204 338
new 0 204 338
assign 1 204 339
equals 1 204 339
assign 1 205 341
new 0 205 341
assign 1 206 342
new 0 206 342
assign 1 207 343
new 0 207 343
assign 1 208 344
new 0 208 344
assign 1 209 345
new 0 209 345
assign 1 210 346
new 0 210 346
assign 1 211 349
new 0 211 349
assign 1 211 350
notEquals 1 211 350
assign 1 213 353
new 0 213 353
assign 1 0 357
assign 1 214 360
new 0 214 360
assign 1 214 361
notEquals 1 214 361
assign 1 0 363
assign 1 0 366
addValue 1 215 370
assign 1 216 371
equals 1 216 371
assign 1 217 373
not 0 217 378
assign 1 219 379
nextGet 0 219 379
assign 1 221 385
new 0 221 385
addValue 1 221 386
assign 1 222 387
new 0 222 387
assign 1 223 390
def 1 223 395
assign 1 223 396
new 0 223 396
assign 1 223 397
notEquals 1 223 397
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 224 409
nextGet 0 224 409
assign 1 226 415
new 0 226 415
assign 1 227 416
toString 0 227 416
assign 1 227 417
new 1 227 417
return 1 227 418
assign 1 230 423
new 0 230 423
assign 1 230 424
notEquals 1 230 424
addValue 1 231 426
assign 1 232 427
nextGet 0 232 427
assign 1 233 428
new 0 233 428
assign 1 233 429
equals 1 233 429
assign 1 233 431
toString 0 233 431
assign 1 233 432
new 0 233 432
assign 1 233 433
ends 1 233 433
assign 1 233 434
not 0 233 439
assign 1 0 440
assign 1 0 443
assign 1 0 447
addValue 1 234 450
assign 1 235 451
nextGet 0 235 451
assign 1 238 458
new 0 238 458
assign 1 239 461
def 1 239 466
assign 1 239 467
new 0 239 467
assign 1 239 468
notEquals 1 239 468
assign 1 0 470
assign 1 0 473
assign 1 0 477
assign 1 240 480
nextGet 0 240 480
assign 1 242 486
new 0 242 486
addValue 1 242 487
assign 1 243 488
new 0 243 488
assign 1 244 489
extractString 0 244 489
assign 1 244 490
new 1 244 490
return 1 244 491
assign 1 247 494
nextGet 0 247 494
assign 1 248 497
new 0 248 497
assign 1 248 498
equals 1 248 498
assign 1 0 500
assign 1 248 503
equals 1 248 503
assign 1 0 505
assign 1 0 508
assign 1 249 512
equals 1 249 512
assign 1 249 514
increment 0 249 514
assign 1 250 516
nextGet 0 250 516
assign 1 252 522
new 0 252 522
assign 1 252 523
equals 1 252 523
assign 1 253 525
new 0 253 525
assign 1 254 526
new 0 254 526
assign 1 255 527
nextGet 0 255 527
extractString 0 256 528
assign 1 257 529
new 0 257 529
addValue 1 257 530
assign 1 258 533
new 0 258 533
assign 1 258 534
equals 1 258 534
assign 1 259 536
new 0 259 536
assign 1 260 537
new 0 260 537
assign 1 261 538
nextGet 0 261 538
extractString 0 262 539
assign 1 263 540
new 0 263 540
addValue 1 263 541
assign 1 265 544
new 0 265 544
assign 1 265 545
equals 1 265 545
assign 1 266 547
new 0 266 547
assign 1 267 548
nextGet 0 267 548
assign 1 269 552
new 0 269 552
assign 1 269 553
notEquals 1 269 553
assign 1 269 555
notEquals 1 269 555
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 269 567
new 0 269 567
assign 1 269 568
notEquals 1 269 568
assign 1 0 570
assign 1 0 573
assign 1 0 577
assign 1 269 580
new 0 269 580
assign 1 269 581
notEquals 1 269 581
assign 1 0 583
assign 1 0 586
assign 1 0 590
addValue 1 270 593
assign 1 271 594
nextGet 0 271 594
assign 1 273 600
equals 1 273 600
assign 1 273 602
increment 0 273 602
assign 1 274 604
new 0 274 604
assign 1 276 606
new 0 276 606
assign 1 277 607
assign 1 278 608
extractString 0 278 608
nameSet 1 278 609
assign 1 280 612
new 0 280 612
assign 1 281 613
extractString 0 281 613
nameSet 1 281 614
assign 1 282 615
assign 1 284 617
new 0 284 617
assign 1 284 618
equals 1 284 618
assign 1 285 620
new 0 285 620
assign 1 287 622
new 0 287 622
assign 1 289 626
new 0 289 626
assign 1 289 627
equals 1 289 627
assign 1 0 630
assign 1 0 633
assign 1 0 637
assign 1 290 640
new 0 290 640
assign 1 291 641
new 0 291 641
isClosedSet 1 291 642
assign 1 292 643
nextGet 0 292 643
assign 1 294 647
new 0 294 647
assign 1 296 650
new 0 296 650
assign 1 301 658
nextGet 0 301 658
assign 1 302 661
new 0 302 661
assign 1 302 662
equals 1 302 662
assign 1 0 664
assign 1 302 667
equals 1 302 667
assign 1 0 669
assign 1 0 672
assign 1 303 676
equals 1 303 676
assign 1 303 678
increment 0 303 678
assign 1 304 680
nextGet 0 304 680
assign 1 306 688
new 0 306 688
assign 1 306 689
notEquals 1 306 689
assign 1 306 691
notEquals 1 306 691
assign 1 0 693
assign 1 0 696
assign 1 0 700
assign 1 306 703
new 0 306 703
assign 1 306 704
notEquals 1 306 704
assign 1 0 706
assign 1 0 709
assign 1 0 713
assign 1 306 716
new 0 306 716
assign 1 306 717
notEquals 1 306 717
assign 1 0 719
assign 1 0 722
assign 1 0 726
assign 1 306 729
new 0 306 729
assign 1 306 730
notEquals 1 306 730
assign 1 0 732
assign 1 0 735
assign 1 0 739
addValue 1 307 742
assign 1 308 743
nextGet 0 308 743
assign 1 310 749
new 0 310 749
assign 1 311 750
equals 1 311 750
assign 1 311 752
increment 0 311 752
assign 1 312 754
new 0 312 754
assign 1 312 755
equals 1 312 755
assign 1 313 757
new 0 313 757
assign 1 314 758
new 0 314 758
assign 1 315 761
new 0 315 761
assign 1 315 762
equals 1 315 762
assign 1 316 764
new 0 316 764
assign 1 317 765
new 0 317 765
isClosedSet 1 317 766
assign 1 318 767
nextGet 0 318 767
assign 1 320 770
extractString 0 320 770
addAttributeName 1 320 771
assign 1 321 772
new 0 321 772
assign 1 325 777
nextGet 0 325 777
assign 1 326 780
new 0 326 780
assign 1 326 781
equals 1 326 781
assign 1 0 783
assign 1 326 786
equals 1 326 786
assign 1 0 788
assign 1 0 791
assign 1 0 795
assign 1 326 798
new 0 326 798
assign 1 326 799
equals 1 326 799
assign 1 0 801
assign 1 0 804
assign 1 328 808
equals 1 328 808
assign 1 328 810
increment 0 328 810
assign 1 329 812
nextGet 0 329 812
assign 1 331 818
notEquals 1 331 818
assign 1 332 820
new 0 332 820
assign 1 332 821
toString 0 332 821
assign 1 332 822
add 1 332 822
assign 1 332 823
new 1 332 823
throw 1 332 824
assign 1 334 826
nextGet 0 334 826
assign 1 335 829
notEquals 1 335 829
assign 1 336 831
equals 1 336 831
assign 1 336 833
increment 0 336 833
addValue 1 337 835
assign 1 338 836
nextGet 0 338 836
assign 1 340 842
notEquals 1 340 842
assign 1 341 844
new 0 341 844
assign 1 341 845
toString 0 341 845
assign 1 341 846
add 1 341 846
assign 1 341 847
new 1 341 847
throw 1 341 848
assign 1 343 850
new 0 343 850
assign 1 344 851
extractString 0 344 851
addAttributeValue 1 344 852
assign 1 345 853
new 0 345 853
assign 1 348 860
def 1 348 865
assign 1 0 866
assign 1 348 869
def 1 348 874
assign 1 348 875
isClosedGet 0 348 875
assign 1 0 877
assign 1 0 880
assign 1 0 884
assign 1 0 887
assign 1 0 890
assign 1 349 894
nextGet 0 349 894
assign 1 350 897
def 1 350 902
assign 1 350 903
new 0 350 903
assign 1 350 904
equals 1 350 904
assign 1 0 906
assign 1 350 909
equals 1 350 909
assign 1 0 911
assign 1 0 914
assign 1 0 918
assign 1 0 921
assign 1 0 925
assign 1 350 928
nextGet 0 350 928
assign 1 351 934
def 1 351 939
assign 1 351 940
new 0 351 940
assign 1 351 941
equals 1 351 941
assign 1 0 943
assign 1 0 946
assign 1 0 950
assign 1 351 953
new 0 351 953
assign 1 354 958
undef 1 354 963
assign 1 354 964
new 0 354 964
assign 1 355 966
new 0 355 966
assign 1 355 967
add 1 355 967
assign 1 355 968
new 0 355 968
assign 1 355 969
add 1 355 969
assign 1 355 970
new 1 355 970
throw 1 355 971
return 1 358 975
assign 1 362 981
not 0 362 986
assign 1 362 987
new 0 362 987
return 1 362 988
assign 1 363 990
hasNextGet 0 363 990
return 1 363 991
return 1 0 994
assign 1 0 997
return 1 0 1001
assign 1 0 1004
return 1 0 1008
assign 1 0 1011
return 1 0 1015
assign 1 0 1018
return 1 0 1022
assign 1 0 1025
return 1 0 1029
assign 1 0 1032
return 1 0 1036
assign 1 0 1039
return 1 0 1043
assign 1 0 1046
return 1 0 1050
assign 1 0 1053
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1613872813: return bem_toString_0();
case -302306326: return bem_print_0();
case -1334228416: return bem_copy_0();
case -516513089: return bem_start_0();
case 237223512: return bem_skipGet_0();
case 1576658686: return bem_nextGet_0();
case 278754943: return bem_iterGet_0();
case -1553579298: return bem_create_0();
case -1687589551: return bem_xtGet_0();
case -508115048: return bem_resGet_0();
case -592419494: return bem_debugGet_0();
case -623084206: return bem_hashGet_0();
case -668031687: return bem_new_0();
case 2047896854: return bem_startedGet_0();
case 1816901152: return bem_xmlStringGet_0();
case 1852223219: return bem_hasNextGet_0();
case -879452611: return bem_iteratorGet_0();
case 1561884292: return bem_restart_0();
case 485649795: return bem_lineGet_0();
case -258211281: return bem_textNodeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -164601120: return bem_xmlStringSet_1(bevd_0);
case 183226086: return bem_equals_1(bevd_0);
case -1303564329: return bem_debugSet_1(bevd_0);
case 273390925: return bem_skipSet_1(bevd_0);
case 1208442783: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2034494418: return bem_startedSet_1(bevd_0);
case -2083179763: return bem_def_1(bevd_0);
case -106068549: return bem_undef_1(bevd_0);
case 445167199: return bem_lineSet_1(bevd_0);
case 1810189577: return bem_iterSet_1(bevd_0);
case 800005530: return bem_xtSet_1(bevd_0);
case 26892331: return bem_textNodeSet_1(bevd_0);
case 1553693181: return bem_copyTo_1(bevd_0);
case -1595922574: return bem_notEquals_1(bevd_0);
case 161481550: return bem_resSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -529409169: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1780160067: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1663342083: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -123507493: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_11_XmlTagIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_type;
}
}
