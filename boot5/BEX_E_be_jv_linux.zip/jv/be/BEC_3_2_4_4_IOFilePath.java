package be;
/* IO:File: source/extended/FilePath.be */
public class BEC_3_2_4_4_IOFilePath extends BEC_2_6_8_SystemBasePath {
public BEC_3_2_4_4_IOFilePath() { }
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x50,0x61,0x74,0x68,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_4_IOFilePath_bels_0 = {0x3A};
public static BEC_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_inst;

public static BET_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_type;

public BEC_2_2_4_IOFile bevp_file;
public BEC_2_4_6_TextString bevp_driveLetter;
public BEC_3_2_4_4_IOFilePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevp_separator = bevt_0_ta_ph.bem_separatorGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_apNew_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_6_8_SystemPlatform bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_15_ta_ph = null;
bevt_2_ta_ph = beva_spath.bem_lengthGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 30*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_spath.bem_getPoint_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_2_4_4_IOFilePath_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_equals_1(bevt_7_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 30*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 30*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 30*/
 else /* Line: 30*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 30*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevp_driveLetter = beva_spath.bem_substring_2(bevt_8_ta_ph, bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_11_ta_ph = beva_spath.bem_lengthGet_0();
beva_spath = beva_spath.bem_substring_2(bevt_10_ta_ph, bevt_11_ta_ph);
} /* Line: 32*/
bevt_12_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl_p = bevt_12_ta_ph.bem_platformGet_0();
bevt_13_ta_ph = bevl_p.bem_otherSeparatorGet_0();
bevt_14_ta_ph = bevl_p.bem_separatorGet_0();
beva_spath = (BEC_2_4_6_TextString) beva_spath.bem_swap_2(bevt_13_ta_ph, bevt_14_ta_ph);
bevt_15_ta_ph = bem_new_1(beva_spath);
return (BEC_3_2_4_4_IOFilePath) bevt_15_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = super.bem_isAbsoluteGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_apNew_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_2_4_IOFile bem_fileGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_file == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 61*/ {
bevp_file = (new BEC_2_2_4_IOFile()).bem_new_0();
bevp_file.bem_pathSet_1(this);
} /* Line: 63*/
return bevp_file;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_copy_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_3_2_4_4_IOFilePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
bevl_other.bem_fileSet_1(null);
return (BEC_3_2_4_4_IOFilePath) bevl_other;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_driveLetter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 77*/ {
bevt_1_ta_ph = bevp_driveLetter.bem_add_1(bevp_path);
return bevt_1_ta_ph;
} /* Line: 78*/
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_parentGet_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = super.bem_parentGet_0();
return (BEC_3_2_4_4_IOFilePath) bevt_0_ta_ph;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 88*/ {
bevp_driveLetter = null;
super.bem_makeNonAbsolute_0();
} /* Line: 90*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_matchesGlob_1(BEC_2_4_6_TextString beva_glob) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_4_TextGlob bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_4_TextGlob()).bem_new_1(beva_glob);
bevt_2_ta_ph = bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_match_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_6_6_SystemObject bevl_res = null;
bevl_res = super.bem_subPath_2(beva_start, beva_end);
bevl_res.bemd_1(-951310864, bevp_driveLetter);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_lastStepGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_driveLetterGet_0() throws Throwable {
return bevp_driveLetter;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_driveLetterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 24, 25, 30, 30, 30, 30, 30, 30, 30, 30, 0, 0, 0, 31, 31, 31, 32, 32, 32, 34, 34, 35, 35, 35, 36, 36, 43, 43, 47, 47, 51, 55, 55, 61, 61, 62, 63, 65, 69, 70, 71, 71, 72, 73, 77, 77, 78, 78, 80, 84, 84, 88, 89, 90, 95, 95, 95, 95, 99, 100, 101, 105, 105, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 39, 40, 41, 46, 47, 48, 49, 50, 52, 55, 59, 62, 63, 64, 65, 66, 67, 69, 70, 71, 72, 73, 74, 75, 79, 80, 84, 85, 88, 93, 94, 98, 103, 104, 105, 107, 112, 113, 114, 115, 116, 117, 122, 127, 128, 129, 131, 135, 136, 140, 142, 143, 151, 152, 153, 154, 158, 159, 160, 164, 165, 168, 172, 175};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 16
new 0 24 16
assign 1 24 17
separatorGet 0 24 17
fromString 1 25 18
assign 1 30 39
lengthGet 0 30 39
assign 1 30 40
new 0 30 40
assign 1 30 41
greater 1 30 46
assign 1 30 47
new 0 30 47
assign 1 30 48
getPoint 1 30 48
assign 1 30 49
new 0 30 49
assign 1 30 50
equals 1 30 50
assign 1 0 52
assign 1 0 55
assign 1 0 59
assign 1 31 62
new 0 31 62
assign 1 31 63
new 0 31 63
assign 1 31 64
substring 2 31 64
assign 1 32 65
new 0 32 65
assign 1 32 66
lengthGet 0 32 66
assign 1 32 67
substring 2 32 67
assign 1 34 69
new 0 34 69
assign 1 34 70
platformGet 0 34 70
assign 1 35 71
otherSeparatorGet 0 35 71
assign 1 35 72
separatorGet 0 35 72
assign 1 35 73
swap 2 35 73
assign 1 36 74
new 1 36 74
return 1 36 75
assign 1 43 79
isAbsoluteGet 0 43 79
return 1 43 80
assign 1 47 84
toString 0 47 84
return 1 47 85
apNew 1 51 88
assign 1 55 93
new 0 55 93
return 1 55 94
assign 1 61 98
undef 1 61 103
assign 1 62 104
new 0 62 104
pathSet 1 63 105
return 1 65 107
assign 1 69 112
create 0 69 112
copyTo 1 70 113
assign 1 71 114
copy 0 71 114
pathSet 1 71 115
fileSet 1 72 116
return 1 73 117
assign 1 77 122
def 1 77 127
assign 1 78 128
add 1 78 128
return 1 78 129
return 1 80 131
assign 1 84 135
parentGet 0 84 135
return 1 84 136
assign 1 88 140
isAbsoluteGet 0 88 140
assign 1 89 142
makeNonAbsolute 0 90 143
assign 1 95 151
new 1 95 151
assign 1 95 152
toString 0 95 152
assign 1 95 153
match 1 95 153
return 1 95 154
assign 1 99 158
subPath 2 99 158
driveLetterSet 1 100 159
return 1 101 160
assign 1 105 164
lastStepGet 0 105 164
return 1 105 165
assign 1 0 168
return 1 0 172
assign 1 0 175
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -791696426: return bem_separatorGet_0();
case -1198275152: return bem_lastStepGet_0();
case -978033728: return bem_print_0();
case 498065749: return bem_isAbsoluteGet_0();
case -1968763629: return bem_stepsGet_0();
case 1408609733: return bem_iteratorGet_0();
case -1301883703: return bem_hashGet_0();
case -368862190: return bem_nameGet_0();
case 336279764: return bem_serializeToString_0();
case 403958228: return bem_serializeContentsGet_0();
case 1806064504: return bem_new_0();
case -1008787576: return bem_create_0();
case -915128946: return bem_makeNonAbsolute_0();
case -1566227088: return bem_makeAbsolute_0();
case -1908076536: return bem_driveLetterGet_0();
case -1166711725: return bem_stepListGet_0();
case 779880849: return bem_parentGet_0();
case 367137885: return bem_deleteFirstStep_0();
case 1712538602: return bem_toString_0();
case -1275315701: return bem_copy_0();
case 1974258625: return bem_pathGet_0();
case -479215131: return bem_fileGet_0();
case 461921047: return bem_firstStepGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1296782685: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1947466569: return bem_apNew_1((BEC_2_4_6_TextString) bevd_0);
case 1522961350: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -865451170: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1162939778: return bem_def_1(bevd_0);
case 526313429: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -938921517: return bem_add_1(bevd_0);
case -1033942990: return bem_matchesGlob_1((BEC_2_4_6_TextString) bevd_0);
case 1440179332: return bem_addSteps_1(bevd_0);
case -1590504672: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -148010615: return bem_undef_1(bevd_0);
case -526829482: return bem_equals_1(bevd_0);
case -951310864: return bem_driveLetterSet_1(bevd_0);
case -1234820220: return bem_copyTo_1(bevd_0);
case -1784930552: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 182521093: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1217552554: return bem_print_1(bevd_0);
case 2105889386: return bem_notEquals_1(bevd_0);
case 195946122: return bem_pathSet_1(bevd_0);
case 1628984642: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -1691002834: return bem_separatorSet_1(bevd_0);
case 72243792: return bem_fileSet_1(bevd_0);
case -2109398999: return bem_addStep_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -960117370: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 596327003: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 415995996: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1290842442: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -476884790: return bem_addSteps_2(bevd_0, bevd_1);
case -554972801: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_3_2_4_4_IOFilePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_3_2_4_4_IOFilePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_4_IOFilePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst = (BEC_3_2_4_4_IOFilePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_type;
}
}
