package be;
/* IO:File: source/extended/FilePath.be */
public class BEC_3_2_4_4_IOFilePath extends BEC_2_6_8_SystemBasePath {
public BEC_3_2_4_4_IOFilePath() { }
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x50,0x61,0x74,0x68,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_4_IOFilePath_bels_0 = {0x3A};
public static BEC_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_inst;

public static BET_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_type;

public BEC_2_2_4_IOFile bevp_file;
public BEC_2_4_6_TextString bevp_driveLetter;
public BEC_3_2_4_4_IOFilePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevp_separator = bevt_0_ta_ph.bem_separatorGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_apNew_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_6_8_SystemPlatform bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_15_ta_ph = null;
bevt_2_ta_ph = beva_spath.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 24*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_spath.bem_getPoint_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_2_4_4_IOFilePath_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_equals_1(bevt_7_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 24*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 24*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 24*/
 else /* Line: 24*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 24*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevp_driveLetter = beva_spath.bem_substring_2(bevt_8_ta_ph, bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_11_ta_ph = beva_spath.bem_sizeGet_0();
beva_spath = beva_spath.bem_substring_2(bevt_10_ta_ph, bevt_11_ta_ph);
} /* Line: 26*/
bevt_12_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl_p = bevt_12_ta_ph.bem_platformGet_0();
bevt_13_ta_ph = bevl_p.bem_otherSeparatorGet_0();
bevt_14_ta_ph = bevl_p.bem_separatorGet_0();
beva_spath = (BEC_2_4_6_TextString) beva_spath.bem_swap_2(bevt_13_ta_ph, bevt_14_ta_ph);
bevt_15_ta_ph = bem_new_1(beva_spath);
return (BEC_3_2_4_4_IOFilePath) bevt_15_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = super.bem_isAbsoluteGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
bem_apNew_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_2_4_IOFile bem_fileGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_file == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 55*/ {
bevp_file = (new BEC_2_2_4_IOFile()).bem_new_0();
bevp_file.bem_pathSet_1(this);
} /* Line: 57*/
return bevp_file;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_copy_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_3_2_4_4_IOFilePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
bevl_other.bem_fileSet_1(null);
return (BEC_3_2_4_4_IOFilePath) bevl_other;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_driveLetter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_1_ta_ph = bevp_driveLetter.bem_add_1(bevp_path);
return bevt_1_ta_ph;
} /* Line: 72*/
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_parentGet_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = super.bem_parentGet_0();
return (BEC_3_2_4_4_IOFilePath) bevt_0_ta_ph;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 82*/ {
bevp_driveLetter = null;
super.bem_makeNonAbsolute_0();
} /* Line: 84*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_matchesGlob_1(BEC_2_4_6_TextString beva_glob) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_4_TextGlob bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_4_TextGlob()).bem_new_1(beva_glob);
bevt_2_ta_ph = bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_match_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_6_6_SystemObject bevl_res = null;
bevl_res = super.bem_subPath_2(beva_start, beva_end);
bevl_res.bemd_1(1448996769, bevp_driveLetter);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_lastStepGet_0();
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_2_4_IOFile bem_fileGetDirect_0() throws Throwable {
return bevp_file;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_fileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_driveLetterGet_0() throws Throwable {
return bevp_driveLetter;
} /*method end*/
public final BEC_2_4_6_TextString bem_driveLetterGetDirect_0() throws Throwable {
return bevp_driveLetter;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_driveLetterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_driveLetterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 18, 19, 24, 24, 24, 24, 24, 24, 24, 24, 0, 0, 0, 25, 25, 25, 26, 26, 26, 28, 28, 29, 29, 29, 30, 30, 37, 37, 41, 41, 45, 49, 49, 55, 55, 56, 57, 59, 63, 64, 65, 65, 66, 67, 71, 71, 72, 72, 74, 78, 78, 82, 83, 84, 89, 89, 89, 89, 93, 94, 95, 99, 99, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 39, 40, 41, 46, 47, 48, 49, 50, 52, 55, 59, 62, 63, 64, 65, 66, 67, 69, 70, 71, 72, 73, 74, 75, 79, 80, 84, 85, 88, 93, 94, 98, 103, 104, 105, 107, 112, 113, 114, 115, 116, 117, 122, 127, 128, 129, 131, 135, 136, 140, 142, 143, 151, 152, 153, 154, 158, 159, 160, 164, 165, 168, 171, 175, 179, 182, 185, 189};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 16
new 0 18 16
assign 1 18 17
separatorGet 0 18 17
fromString 1 19 18
assign 1 24 39
sizeGet 0 24 39
assign 1 24 40
new 0 24 40
assign 1 24 41
greater 1 24 46
assign 1 24 47
new 0 24 47
assign 1 24 48
getPoint 1 24 48
assign 1 24 49
new 0 24 49
assign 1 24 50
equals 1 24 50
assign 1 0 52
assign 1 0 55
assign 1 0 59
assign 1 25 62
new 0 25 62
assign 1 25 63
new 0 25 63
assign 1 25 64
substring 2 25 64
assign 1 26 65
new 0 26 65
assign 1 26 66
sizeGet 0 26 66
assign 1 26 67
substring 2 26 67
assign 1 28 69
new 0 28 69
assign 1 28 70
platformGet 0 28 70
assign 1 29 71
otherSeparatorGet 0 29 71
assign 1 29 72
separatorGet 0 29 72
assign 1 29 73
swap 2 29 73
assign 1 30 74
new 1 30 74
return 1 30 75
assign 1 37 79
isAbsoluteGet 0 37 79
return 1 37 80
assign 1 41 84
toString 0 41 84
return 1 41 85
apNew 1 45 88
assign 1 49 93
new 0 49 93
return 1 49 94
assign 1 55 98
undef 1 55 103
assign 1 56 104
new 0 56 104
pathSet 1 57 105
return 1 59 107
assign 1 63 112
create 0 63 112
copyTo 1 64 113
assign 1 65 114
copy 0 65 114
pathSet 1 65 115
fileSet 1 66 116
return 1 67 117
assign 1 71 122
def 1 71 127
assign 1 72 128
add 1 72 128
return 1 72 129
return 1 74 131
assign 1 78 135
parentGet 0 78 135
return 1 78 136
assign 1 82 140
isAbsoluteGet 0 82 140
assign 1 83 142
makeNonAbsolute 0 84 143
assign 1 89 151
new 1 89 151
assign 1 89 152
toString 0 89 152
assign 1 89 153
match 1 89 153
return 1 89 154
assign 1 93 158
subPath 2 93 158
driveLetterSet 1 94 159
return 1 95 160
assign 1 99 164
lastStepGet 0 99 164
return 1 99 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 126387064: return bem_new_0();
case 398187407: return bem_sourceFileNameGet_0();
case -694691619: return bem_driveLetterGetDirect_0();
case -543330026: return bem_fieldNamesGet_0();
case 1342623754: return bem_copy_0();
case 1684634507: return bem_isAbsoluteGet_0();
case 1592308006: return bem_stepListGet_0();
case 1008129501: return bem_fileGetDirect_0();
case 556565361: return bem_serializationIteratorGet_0();
case -1794485421: return bem_serializeContents_0();
case 498101216: return bem_echo_0();
case 1776443866: return bem_separatorGet_0();
case -1718188704: return bem_hashGet_0();
case -1091108153: return bem_pathGet_0();
case -1542987516: return bem_driveLetterGet_0();
case 1850430731: return bem_makeNonAbsolute_0();
case 335452842: return bem_parentGet_0();
case -1164372221: return bem_firstStepGet_0();
case -331678272: return bem_pathGetDirect_0();
case -2124354635: return bem_serializeToString_0();
case 1285480115: return bem_makeAbsolute_0();
case 1975556945: return bem_deserializeClassNameGet_0();
case 1520083289: return bem_lastStepGet_0();
case -677150073: return bem_toString_0();
case -225222698: return bem_create_0();
case -403892256: return bem_stepsGet_0();
case 409380620: return bem_fieldIteratorGet_0();
case 807655445: return bem_print_0();
case -197178777: return bem_deleteFirstStep_0();
case -1553805086: return bem_fileGet_0();
case -223920170: return bem_separatorGetDirect_0();
case 247576523: return bem_classNameGet_0();
case 2066839134: return bem_iteratorGet_0();
case -1749437314: return bem_tagGet_0();
case 749770559: return bem_nameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1300116873: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1070406932: return bem_otherClass_1(bevd_0);
case 1135458261: return bem_separatorSet_1(bevd_0);
case 1648088469: return bem_sameType_1(bevd_0);
case 1375967259: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -399101598: return bem_undef_1(bevd_0);
case 1448996769: return bem_driveLetterSet_1(bevd_0);
case 1502842604: return bem_def_1(bevd_0);
case -853584814: return bem_addStep_1(bevd_0);
case -91816367: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -1033160881: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -208595003: return bem_apNew_1((BEC_2_4_6_TextString) bevd_0);
case -268524541: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 1748833599: return bem_notEquals_1(bevd_0);
case -1238532746: return bem_pathSetDirect_1(bevd_0);
case -152824010: return bem_matchesGlob_1((BEC_2_4_6_TextString) bevd_0);
case 1551985998: return bem_sameObject_1(bevd_0);
case 1812729488: return bem_equals_1(bevd_0);
case -2041632081: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1584364126: return bem_add_1(bevd_0);
case -427214688: return bem_separatorSetDirect_1(bevd_0);
case -466500774: return bem_fileSetDirect_1(bevd_0);
case 1946916396: return bem_fileSet_1(bevd_0);
case 1385005000: return bem_otherType_1(bevd_0);
case -1228776140: return bem_pathSet_1(bevd_0);
case 1765599119: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -307261206: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1943993629: return bem_sameClass_1(bevd_0);
case 1596916579: return bem_addSteps_1(bevd_0);
case -1180006819: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 2034606323: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -266406516: return bem_driveLetterSetDirect_1(bevd_0);
case -404194174: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1332727395: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1484550604: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -596575039: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1882447524: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -899497068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1669181512: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 318732453: return bem_addSteps_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_3_2_4_4_IOFilePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_3_2_4_4_IOFilePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_4_IOFilePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst = (BEC_3_2_4_4_IOFilePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_type;
}
}
