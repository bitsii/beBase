package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap extends BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
private static byte[] becc_BEC_2_9_3_ContainerMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_3_ContainerMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_inst;

public static BET_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_type;

public BEC_2_9_3_ContainerMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
bevt_6_ta_ph = bevl_other.bem_sizeGet_0();
bevt_7_ta_ph = bem_sizeGet_0();
if (bevt_6_ta_ph.bevi_int != bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 94*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 94*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 95*/
bevt_0_ta_loop = bem_mapIteratorGet_0();
while (true)
/* Line: 97*/ {
bevt_9_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 97*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_10_ta_ph = bevl_i.bemd_0(-1940138964);
bevl_v = bevl_other.bem_get_1(bevt_10_ta_ph);
if (bevl_v == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_13_ta_ph = bevl_i.bemd_0(301548013);
if (bevt_13_ta_ph == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 99*/ {
if (bevl_v == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 99*/
 else /* Line: 99*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 99*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 99*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 99*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_16_ta_ph = bevl_i.bemd_0(301548013);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(371048183, bevl_v);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 99*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 99*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 99*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_17_ta_ph;
} /* Line: 99*/
} /* Line: 99*/
 else /* Line: 97*/ {
break;
} /* Line: 97*/
} /* Line: 97*/
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_18_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_v, null, bevp_buckets);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-216446112);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 105*/ {
bevl_slt = bevp_buckets;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 108*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-216446112);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 108*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 109*/
 else /* Line: 108*/ {
break;
} /* Line: 108*/
} /* Line: 108*/
bevp_buckets = bevl_slt;
} /* Line: 111*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 113*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 114*/
return this;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_valueIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 139*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_other, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 140*/ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_ta_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
/* Line: 142*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 142*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_5_ta_ph = bevl_x.bemd_0(-1940138964);
bevt_6_ta_ph = bevl_x.bemd_0(301548013);
bem_put_2(bevt_5_ta_ph, bevt_6_ta_ph);
} /* Line: 143*/
 else /* Line: 142*/ {
break;
} /* Line: 142*/
} /* Line: 142*/
} /* Line: 142*/
 else /* Line: 140*/ {
bevt_8_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_7_ta_ph = bevt_8_ta_ph.bem_sameType_2(beva_other, bevp_baseNode);
if (bevt_7_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_9_ta_ph = beva_other.bemd_0(-1940138964);
bevt_10_ta_ph = beva_other.bemd_0(301548013);
bem_put_2(bevt_9_ta_ph, bevt_10_ta_ph);
} /* Line: 146*/
 else /* Line: 147*/ {
bem_put_2(beva_other, beva_other);
} /* Line: 148*/
} /* Line: 140*/
} /* Line: 140*/
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_toRet = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_ta_loop = bem_mapIteratorGet_0();
while (true)
/* Line: 155*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 155*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = bevl_x.bemd_0(-1940138964);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(-1842773488, beva_prefix);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 156*/ {
bevt_4_ta_ph = bevl_x.bemd_0(-1940138964);
bevt_5_ta_ph = bevl_x.bemd_0(301548013);
bevl_toRet.bem_put_2(bevt_4_ta_ph, bevt_5_ta_ph);
} /* Line: 157*/
} /* Line: 156*/
 else /* Line: 155*/ {
break;
} /* Line: 155*/
} /* Line: 155*/
return bevl_toRet;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {76, 76, 80, 81, 82, 83, 84, 85, 89, 89, 93, 94, 94, 0, 94, 94, 94, 94, 0, 0, 95, 95, 97, 0, 97, 97, 98, 98, 99, 99, 0, 99, 99, 99, 99, 99, 0, 0, 0, 0, 0, 0, 99, 99, 0, 0, 99, 99, 101, 101, 105, 105, 106, 107, 108, 108, 109, 111, 114, 119, 119, 123, 123, 127, 127, 131, 131, 135, 135, 139, 139, 140, 140, 141, 142, 0, 142, 142, 143, 143, 143, 145, 145, 146, 146, 146, 148, 154, 155, 0, 155, 155, 156, 156, 157, 157, 157, 160};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23, 28, 29, 54, 55, 60, 61, 64, 65, 66, 71, 72, 75, 79, 80, 82, 82, 85, 87, 88, 89, 90, 95, 96, 99, 100, 105, 106, 111, 112, 115, 119, 122, 125, 129, 132, 133, 135, 138, 142, 143, 150, 151, 159, 160, 162, 163, 166, 167, 169, 175, 178, 184, 185, 189, 190, 194, 195, 199, 200, 204, 205, 221, 226, 227, 228, 230, 231, 231, 234, 236, 237, 238, 239, 247, 248, 250, 251, 252, 255, 270, 271, 271, 274, 276, 277, 278, 280, 281, 282, 289};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 76 13
new 0 76 13
new 1 76 14
assign 1 80 18
new 1 80 18
assign 1 81 19
assign 1 82 20
new 0 82 20
assign 1 83 21
new 0 83 21
assign 1 84 22
new 0 84 22
assign 1 85 23
new 0 85 23
assign 1 89 28
new 1 89 28
return 1 89 29
assign 1 93 54
assign 1 94 55
undef 1 94 60
assign 1 0 61
assign 1 94 64
sizeGet 0 94 64
assign 1 94 65
sizeGet 0 94 65
assign 1 94 66
notEquals 1 94 71
assign 1 0 72
assign 1 0 75
assign 1 95 79
new 0 95 79
return 1 95 80
assign 1 97 82
mapIteratorGet 0 0 82
assign 1 97 85
hasNextGet 0 97 85
assign 1 97 87
nextGet 0 97 87
assign 1 98 88
keyGet 0 98 88
assign 1 98 89
get 1 98 89
assign 1 99 90
undef 1 99 95
assign 1 0 96
assign 1 99 99
valueGet 0 99 99
assign 1 99 100
undef 1 99 105
assign 1 99 106
def 1 99 111
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 0 122
assign 1 0 125
assign 1 0 129
assign 1 99 132
valueGet 0 99 132
assign 1 99 133
notEquals 1 99 133
assign 1 0 135
assign 1 0 138
assign 1 99 142
new 0 99 142
return 1 99 143
assign 1 101 150
new 0 101 150
return 1 101 151
assign 1 105 159
innerPut 4 105 159
assign 1 105 160
not 0 105 160
assign 1 106 162
assign 1 107 163
rehash 1 107 163
assign 1 108 166
innerPut 4 108 166
assign 1 108 167
not 0 108 167
assign 1 109 169
rehash 1 109 169
assign 1 111 175
assign 1 114 178
increment 0 114 178
assign 1 119 184
new 1 119 184
return 1 119 185
assign 1 123 189
valueIteratorGet 0 123 189
return 1 123 190
assign 1 127 194
new 1 127 194
return 1 127 195
assign 1 131 199
new 1 131 199
return 1 131 200
assign 1 135 204
new 1 135 204
return 1 135 205
assign 1 139 221
def 1 139 226
assign 1 140 227
new 0 140 227
assign 1 140 228
sameType 2 140 228
assign 1 141 230
assign 1 142 231
mapIteratorGet 0 0 231
assign 1 142 234
hasNextGet 0 142 234
assign 1 142 236
nextGet 0 142 236
assign 1 143 237
keyGet 0 143 237
assign 1 143 238
valueGet 0 143 238
put 2 143 239
assign 1 145 247
new 0 145 247
assign 1 145 248
sameType 2 145 248
assign 1 146 250
keyGet 0 146 250
assign 1 146 251
valueGet 0 146 251
put 2 146 252
put 2 148 255
assign 1 154 270
new 0 154 270
assign 1 155 271
mapIteratorGet 0 0 271
assign 1 155 274
hasNextGet 0 155 274
assign 1 155 276
nextGet 0 155 276
assign 1 156 277
keyGet 0 156 277
assign 1 156 278
begins 1 156 278
assign 1 157 280
keyGet 0 157 280
assign 1 157 281
valueGet 0 157 281
put 2 157 282
return 1 160 289
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1800342769: return bem_nodesGet_0();
case -1893176165: return bem_multiGet_0();
case -1063105140: return bem_create_0();
case 1540145526: return bem_notEmptyGet_0();
case -994078049: return bem_moduGet_0();
case 2033168833: return bem_mapIteratorGet_0();
case 273182187: return bem_valueIteratorGet_0();
case -484851105: return bem_setIteratorGet_0();
case -964376567: return bem_copy_0();
case -17851578: return bem_new_0();
case -430707096: return bem_bucketsGet_0();
case 1048216827: return bem_serializeToString_0();
case -816770678: return bem_relGet_0();
case 1703160154: return bem_isEmptyGet_0();
case 1397235532: return bem_clear_0();
case -1295207340: return bem_valuesGet_0();
case -673460716: return bem_innerPutAddedGet_0();
case 963265744: return bem_sizeGet_0();
case -1862849517: return bem_hashGet_0();
case -1544307906: return bem_tagGet_0();
case -1869109136: return bem_classNameGet_0();
case -1646180884: return bem_baseNodeGet_0();
case -279188987: return bem_serializationIteratorGet_0();
case -1406793129: return bem_print_0();
case 420705948: return bem_nodeIteratorGet_0();
case -1650622151: return bem_iteratorGet_0();
case 120871922: return bem_keyValueIteratorGet_0();
case 179660003: return bem_keysGet_0();
case -2087675581: return bem_keyIteratorGet_0();
case -1744447963: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -537465080: return bem_put_1(bevd_0);
case -699734903: return bem_innerPutAddedSet_1(bevd_0);
case -1175115655: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -431602363: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -716178647: return bem_bucketsSet_1(bevd_0);
case -1263350843: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 1764708193: return bem_copyTo_1(bevd_0);
case 371048183: return bem_notEquals_1(bevd_0);
case 1277442242: return bem_baseNodeSet_1(bevd_0);
case 87387326: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 725514738: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1561077498: return bem_has_1(bevd_0);
case -1463956748: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -153063440: return bem_relSet_1(bevd_0);
case 1522448151: return bem_moduSet_1(bevd_0);
case 336982361: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1832844782: return bem_sameObject_1(bevd_0);
case 689573322: return bem_equals_1(bevd_0);
case -637809794: return bem_multiSet_1(bevd_0);
case 1615283662: return bem_get_1(bevd_0);
case -495207452: return bem_sizeSet_1(bevd_0);
case -54815286: return bem_def_1(bevd_0);
case 1552025867: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1472504739: return bem_undef_1(bevd_0);
case -295442331: return bem_addValue_1(bevd_0);
case -1978736929: return bem_delete_1(bevd_0);
case -1492086420: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 988724429: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1178647801: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1650827610: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523546720: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1121134228: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2040603163: return bem_put_2(bevd_0, bevd_1);
case -1135788730: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1998052232: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst = (BEC_2_9_3_ContainerMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_type;
}
}
