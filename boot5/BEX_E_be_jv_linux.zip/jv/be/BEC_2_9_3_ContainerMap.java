package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap extends BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
private static byte[] becc_BEC_2_9_3_ContainerMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_3_ContainerMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_inst;

public static BET_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_type;

public BEC_2_9_3_ContainerMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_8_ta_ph = bevl_other.bem_lengthGet_0();
bevt_9_ta_ph = bem_lengthGet_0();
if (bevt_8_ta_ph.bevi_int != bevt_9_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 100*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 100*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 101*/
bevt_0_ta_loop = bem_mapIteratorGet_0();
while (true)
/* Line: 103*/ {
bevt_11_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_11_ta_ph.bevi_bool)/* Line: 103*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_12_ta_ph = bevl_i.bemd_0(-1666270187);
bevl_v = bevl_other.bem_get_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevl_i.bemd_0(1783229144);
if (bevt_14_ta_ph == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 105*/ {
if (bevl_v == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 105*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 105*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 105*/
 else /* Line: 105*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 105*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 105*/
if (bevl_v == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_19_ta_ph = bevl_i.bemd_0(1783229144);
if (bevt_19_ta_ph == null) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 106*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 106*/
 else /* Line: 106*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 106*/ {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_20_ta_ph;
} /* Line: 106*/
if (bevl_v == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_23_ta_ph = bevl_i.bemd_0(1783229144);
if (bevt_23_ta_ph == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 107*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 107*/
 else /* Line: 107*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 107*/ {
bevt_25_ta_ph = bevl_i.bemd_0(1783229144);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(-2069842105, bevl_v);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 107*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 107*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 107*/
 else /* Line: 107*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 107*/ {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_26_ta_ph;
} /* Line: 107*/
} /* Line: 107*/
 else /* Line: 103*/ {
break;
} /* Line: 103*/
} /* Line: 103*/
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_27_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_v, null, bevp_buckets);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1210698451);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 113*/ {
bevl_slt = bevp_buckets;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 116*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(1210698451);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 116*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 117*/
 else /* Line: 116*/ {
break;
} /* Line: 116*/
} /* Line: 116*/
bevp_buckets = bevl_slt;
} /* Line: 119*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 121*/ {
bevp_length = bevp_length.bem_increment_0();
} /* Line: 122*/
return this;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_valueIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_other, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 148*/ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_ta_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
/* Line: 150*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 150*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_5_ta_ph = bevl_x.bemd_0(-1666270187);
bevt_6_ta_ph = bevl_x.bemd_0(1783229144);
bem_put_2(bevt_5_ta_ph, bevt_6_ta_ph);
} /* Line: 151*/
 else /* Line: 150*/ {
break;
} /* Line: 150*/
} /* Line: 150*/
} /* Line: 150*/
 else /* Line: 148*/ {
bevt_8_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_7_ta_ph = bevt_8_ta_ph.bem_sameType_2(beva_other, bevp_baseNode);
if (bevt_7_ta_ph.bevi_bool)/* Line: 153*/ {
bevt_9_ta_ph = beva_other.bemd_0(-1666270187);
bevt_10_ta_ph = beva_other.bemd_0(1783229144);
bem_put_2(bevt_9_ta_ph, bevt_10_ta_ph);
} /* Line: 154*/
 else /* Line: 155*/ {
bem_put_2(beva_other, beva_other);
} /* Line: 156*/
} /* Line: 148*/
} /* Line: 148*/
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_toRet = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_ta_loop = bem_mapIteratorGet_0();
while (true)
/* Line: 163*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 163*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = bevl_x.bemd_0(-1666270187);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(-933604924, beva_prefix);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 164*/ {
bevt_4_ta_ph = bevl_x.bemd_0(-1666270187);
bevt_5_ta_ph = bevl_x.bemd_0(1783229144);
bevl_toRet.bem_put_2(bevt_4_ta_ph, bevt_5_ta_ph);
} /* Line: 165*/
} /* Line: 164*/
 else /* Line: 163*/ {
break;
} /* Line: 163*/
} /* Line: 163*/
return bevl_toRet;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {82, 82, 86, 87, 88, 89, 90, 91, 95, 95, 99, 100, 100, 0, 100, 100, 100, 100, 0, 0, 101, 101, 103, 0, 103, 103, 104, 104, 105, 105, 105, 105, 105, 0, 0, 0, 105, 105, 106, 106, 106, 106, 106, 0, 0, 0, 106, 106, 107, 107, 107, 107, 107, 0, 0, 0, 107, 107, 0, 0, 0, 107, 107, 109, 109, 113, 113, 114, 115, 116, 116, 117, 119, 122, 127, 127, 131, 131, 135, 135, 139, 139, 143, 143, 147, 147, 148, 148, 149, 150, 0, 150, 150, 151, 151, 151, 153, 153, 154, 154, 154, 156, 162, 163, 0, 163, 163, 164, 164, 165, 165, 165, 168};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23, 28, 29, 63, 64, 69, 70, 73, 74, 75, 80, 81, 84, 88, 89, 91, 91, 94, 96, 97, 98, 99, 100, 105, 106, 111, 112, 115, 119, 122, 123, 125, 130, 131, 132, 137, 138, 141, 145, 148, 149, 151, 156, 157, 158, 163, 164, 167, 171, 174, 175, 177, 180, 184, 187, 188, 195, 196, 204, 205, 207, 208, 211, 212, 214, 220, 223, 229, 230, 234, 235, 239, 240, 244, 245, 249, 250, 266, 271, 272, 273, 275, 276, 276, 279, 281, 282, 283, 284, 292, 293, 295, 296, 297, 300, 315, 316, 316, 319, 321, 322, 323, 325, 326, 327, 334};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 82 13
new 0 82 13
new 1 82 14
assign 1 86 18
new 1 86 18
assign 1 87 19
assign 1 88 20
new 0 88 20
assign 1 89 21
new 0 89 21
assign 1 90 22
new 0 90 22
assign 1 91 23
new 0 91 23
assign 1 95 28
new 1 95 28
return 1 95 29
assign 1 99 63
assign 1 100 64
undef 1 100 69
assign 1 0 70
assign 1 100 73
lengthGet 0 100 73
assign 1 100 74
lengthGet 0 100 74
assign 1 100 75
notEquals 1 100 80
assign 1 0 81
assign 1 0 84
assign 1 101 88
new 0 101 88
return 1 101 89
assign 1 103 91
mapIteratorGet 0 0 91
assign 1 103 94
hasNextGet 0 103 94
assign 1 103 96
nextGet 0 103 96
assign 1 104 97
keyGet 0 104 97
assign 1 104 98
get 1 104 98
assign 1 105 99
valueGet 0 105 99
assign 1 105 100
def 1 105 105
assign 1 105 106
undef 1 105 111
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 105 122
new 0 105 122
return 1 105 123
assign 1 106 125
def 1 106 130
assign 1 106 131
valueGet 0 106 131
assign 1 106 132
undef 1 106 137
assign 1 0 138
assign 1 0 141
assign 1 0 145
assign 1 106 148
new 0 106 148
return 1 106 149
assign 1 107 151
def 1 107 156
assign 1 107 157
valueGet 0 107 157
assign 1 107 158
def 1 107 163
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 107 174
valueGet 0 107 174
assign 1 107 175
notEquals 1 107 175
assign 1 0 177
assign 1 0 180
assign 1 0 184
assign 1 107 187
new 0 107 187
return 1 107 188
assign 1 109 195
new 0 109 195
return 1 109 196
assign 1 113 204
innerPut 4 113 204
assign 1 113 205
not 0 113 205
assign 1 114 207
assign 1 115 208
rehash 1 115 208
assign 1 116 211
innerPut 4 116 211
assign 1 116 212
not 0 116 212
assign 1 117 214
rehash 1 117 214
assign 1 119 220
assign 1 122 223
increment 0 122 223
assign 1 127 229
new 1 127 229
return 1 127 230
assign 1 131 234
valueIteratorGet 0 131 234
return 1 131 235
assign 1 135 239
new 1 135 239
return 1 135 240
assign 1 139 244
new 1 139 244
return 1 139 245
assign 1 143 249
new 1 143 249
return 1 143 250
assign 1 147 266
def 1 147 271
assign 1 148 272
new 0 148 272
assign 1 148 273
sameType 2 148 273
assign 1 149 275
assign 1 150 276
mapIteratorGet 0 0 276
assign 1 150 279
hasNextGet 0 150 279
assign 1 150 281
nextGet 0 150 281
assign 1 151 282
keyGet 0 151 282
assign 1 151 283
valueGet 0 151 283
put 2 151 284
assign 1 153 292
new 0 153 292
assign 1 153 293
sameType 2 153 293
assign 1 154 295
keyGet 0 154 295
assign 1 154 296
valueGet 0 154 296
put 2 154 297
put 2 156 300
assign 1 162 315
new 0 162 315
assign 1 163 316
mapIteratorGet 0 0 316
assign 1 163 319
hasNextGet 0 163 319
assign 1 163 321
nextGet 0 163 321
assign 1 164 322
keyGet 0 164 322
assign 1 164 323
begins 1 164 323
assign 1 165 325
keyGet 0 165 325
assign 1 165 326
valueGet 0 165 326
put 2 165 327
return 1 168 334
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -451680896: return bem_print_0();
case 1875115206: return bem_notEmptyGet_0();
case -253890174: return bem_keysGet_0();
case 104166968: return bem_serializeToString_0();
case 940631698: return bem_copy_0();
case 1033905511: return bem_new_0();
case 1900819227: return bem_nodeIteratorGet_0();
case 1152896855: return bem_keyValueIteratorGet_0();
case -1098312521: return bem_serializationIteratorGet_0();
case 1297296473: return bem_toString_0();
case 424949979: return bem_lengthGet_0();
case -2002088013: return bem_isEmptyGet_0();
case 1332556390: return bem_create_0();
case -1540878689: return bem_keyIteratorGet_0();
case -294050052: return bem_bucketsGet_0();
case 355565519: return bem_iteratorGet_0();
case -1321059769: return bem_mapIteratorGet_0();
case -607626678: return bem_setIteratorGet_0();
case 643928605: return bem_nodesGet_0();
case 281812000: return bem_valueIteratorGet_0();
case -1765013773: return bem_clear_0();
case -1989712623: return bem_hashGet_0();
case 530576330: return bem_valuesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1182201371: return bem_lengthSet_1(bevd_0);
case 1953847240: return bem_print_1(bevd_0);
case 968880155: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 2023408578: return bem_put_1(bevd_0);
case -746031682: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -618247473: return bem_undef_1(bevd_0);
case -276774206: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -244534609: return bem_bucketsSet_1(bevd_0);
case 1110937156: return bem_copyTo_1(bevd_0);
case -2069842105: return bem_notEquals_1(bevd_0);
case -1933288223: return bem_addValue_1(bevd_0);
case 1161478433: return bem_equals_1(bevd_0);
case 126842681: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1478767767: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -364336809: return bem_delete_1(bevd_0);
case 159582032: return bem_def_1(bevd_0);
case -1410634691: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 473176354: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1453226628: return bem_get_1(bevd_0);
case -782071312: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -425870544: return bem_contains_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1744432305: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 681643689: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -50819770: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2066906383: return bem_put_2(bevd_0, bevd_1);
case 1355956619: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142010341: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1870809944: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst = (BEC_2_9_3_ContainerMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_type;
}
}
