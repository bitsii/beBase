package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap extends BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
private static byte[] becc_BEC_2_9_3_ContainerMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_3_ContainerMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_inst;

public static BET_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_type;

public BEC_2_9_3_ContainerMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_6_tmpany_phold = bevl_other.bem_sizeGet_0();
bevt_7_tmpany_phold = bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 126 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 127 */
bevt_0_tmpany_loop = bem_mapIteratorGet_0();
while (true)
 /* Line: 129 */ {
bevt_9_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_0(-1387857009);
bevl_v = bevl_other.bem_get_1(bevt_10_tmpany_phold);
if (bevl_v == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_13_tmpany_phold = bevl_i.bemd_0(-2133686389);
if (bevt_13_tmpany_phold == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 131 */ {
if (bevl_v == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(-2133686389);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-1814510964, bevl_v);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_17_tmpany_phold;
} /* Line: 131 */
} /* Line: 131 */
 else  /* Line: 129 */ {
break;
} /* Line: 129 */
} /* Line: 129 */
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1577581367);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 137 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
 /* Line: 140 */ {
bevt_3_tmpany_phold = bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-1577581367);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 141 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
bevp_slots = bevl_slt;
} /* Line: 143 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 145 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 146 */
return this;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_valueIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(-2018144381, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_tmpany_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
 /* Line: 174 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_4_tmpany_phold = bevl_x.bemd_0(-1387857009);
bevt_5_tmpany_phold = bevl_x.bemd_0(-2133686389);
bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 175 */
 else  /* Line: 174 */ {
break;
} /* Line: 174 */
} /* Line: 174 */
} /* Line: 174 */
 else  /* Line: 172 */ {
bevt_6_tmpany_phold = beva_other.bemd_1(-2018144381, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 177 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(-1387857009);
bevt_8_tmpany_phold = beva_other.bemd_0(-2133686389);
bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
} /* Line: 178 */
 else  /* Line: 179 */ {
bem_put_2(beva_other, beva_other);
} /* Line: 180 */
} /* Line: 172 */
} /* Line: 172 */
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_toRet = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = bem_mapIteratorGet_0();
while (true)
 /* Line: 187 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_x.bemd_0(-1387857009);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-54407607, beva_prefix);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 188 */ {
bevt_4_tmpany_phold = bevl_x.bemd_0(-1387857009);
bevt_5_tmpany_phold = bevl_x.bemd_0(-2133686389);
bevl_toRet.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 189 */
} /* Line: 188 */
 else  /* Line: 187 */ {
break;
} /* Line: 187 */
} /* Line: 187 */
return bevl_toRet;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {108, 108, 112, 113, 114, 115, 116, 117, 121, 121, 125, 126, 126, 0, 126, 126, 126, 126, 0, 0, 127, 127, 129, 0, 129, 129, 130, 130, 131, 131, 0, 131, 131, 131, 131, 131, 0, 0, 0, 0, 0, 0, 131, 131, 0, 0, 131, 131, 133, 133, 137, 137, 138, 139, 140, 140, 141, 143, 146, 151, 151, 155, 155, 159, 159, 163, 163, 167, 167, 171, 171, 172, 173, 174, 0, 174, 174, 175, 175, 175, 177, 178, 178, 178, 180, 186, 187, 0, 187, 187, 188, 188, 189, 189, 189, 192};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23, 28, 29, 54, 55, 60, 61, 64, 65, 66, 71, 72, 75, 79, 80, 82, 82, 85, 87, 88, 89, 90, 95, 96, 99, 100, 105, 106, 111, 112, 115, 119, 122, 125, 129, 132, 133, 135, 138, 142, 143, 150, 151, 159, 160, 162, 163, 166, 167, 169, 175, 178, 184, 185, 189, 190, 194, 195, 199, 200, 204, 205, 219, 224, 225, 227, 228, 228, 231, 233, 234, 235, 236, 244, 246, 247, 248, 251, 266, 267, 267, 270, 272, 273, 274, 276, 277, 278, 285};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 108 13
new 0 108 13
new 1 108 14
assign 1 112 18
new 1 112 18
assign 1 113 19
assign 1 114 20
new 0 114 20
assign 1 115 21
new 0 115 21
assign 1 116 22
new 0 116 22
assign 1 117 23
new 0 117 23
assign 1 121 28
new 1 121 28
return 1 121 29
assign 1 125 54
assign 1 126 55
undef 1 126 60
assign 1 0 61
assign 1 126 64
sizeGet 0 126 64
assign 1 126 65
sizeGet 0 126 65
assign 1 126 66
notEquals 1 126 71
assign 1 0 72
assign 1 0 75
assign 1 127 79
new 0 127 79
return 1 127 80
assign 1 129 82
mapIteratorGet 0 0 82
assign 1 129 85
hasNextGet 0 129 85
assign 1 129 87
nextGet 0 129 87
assign 1 130 88
keyGet 0 130 88
assign 1 130 89
get 1 130 89
assign 1 131 90
undef 1 131 95
assign 1 0 96
assign 1 131 99
valueGet 0 131 99
assign 1 131 100
undef 1 131 105
assign 1 131 106
def 1 131 111
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 0 122
assign 1 0 125
assign 1 0 129
assign 1 131 132
valueGet 0 131 132
assign 1 131 133
notEquals 1 131 133
assign 1 0 135
assign 1 0 138
assign 1 131 142
new 0 131 142
return 1 131 143
assign 1 133 150
new 0 133 150
return 1 133 151
assign 1 137 159
innerPut 4 137 159
assign 1 137 160
not 0 137 160
assign 1 138 162
assign 1 139 163
rehash 1 139 163
assign 1 140 166
innerPut 4 140 166
assign 1 140 167
not 0 140 167
assign 1 141 169
rehash 1 141 169
assign 1 143 175
assign 1 146 178
increment 0 146 178
assign 1 151 184
new 1 151 184
return 1 151 185
assign 1 155 189
valueIteratorGet 0 155 189
return 1 155 190
assign 1 159 194
new 1 159 194
return 1 159 195
assign 1 163 199
new 1 163 199
return 1 163 200
assign 1 167 204
new 1 167 204
return 1 167 205
assign 1 171 219
def 1 171 224
assign 1 172 225
sameType 1 172 225
assign 1 173 227
assign 1 174 228
mapIteratorGet 0 0 228
assign 1 174 231
hasNextGet 0 174 231
assign 1 174 233
nextGet 0 174 233
assign 1 175 234
keyGet 0 175 234
assign 1 175 235
valueGet 0 175 235
put 2 175 236
assign 1 177 244
sameType 1 177 244
assign 1 178 246
keyGet 0 178 246
assign 1 178 247
valueGet 0 178 247
put 2 178 248
put 2 180 251
assign 1 186 266
new 0 186 266
assign 1 187 267
mapIteratorGet 0 0 267
assign 1 187 270
hasNextGet 0 187 270
assign 1 187 272
nextGet 0 187 272
assign 1 188 273
keyGet 0 188 273
assign 1 188 274
begins 1 188 274
assign 1 189 276
keyGet 0 189 276
assign 1 189 277
valueGet 0 189 277
put 2 189 278
return 1 192 285
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 970559243: return bem_hashGet_0();
case 475849232: return bem_fieldNamesGet_0();
case -696933955: return bem_toString_0();
case -1445377704: return bem_nodesGet_0();
case -923119594: return bem_innerPutAddedGetDirect_0();
case 734719264: return bem_copy_0();
case 865626065: return bem_many_0();
case -166658506: return bem_slotsGetDirect_0();
case 624928855: return bem_relGet_0();
case 32795409: return bem_moduGet_0();
case -866769073: return bem_new_0();
case -2108540650: return bem_moduGetDirect_0();
case -1239962040: return bem_clear_0();
case 15052169: return bem_iteratorGet_0();
case -1204687973: return bem_isEmptyGet_0();
case 591325137: return bem_keyValueIteratorGet_0();
case -512745226: return bem_tagGet_0();
case 150594226: return bem_toAny_0();
case 101204366: return bem_nodeIteratorGet_0();
case -1956346985: return bem_valueIteratorGet_0();
case -1951943539: return bem_keyIteratorGet_0();
case -1010395565: return bem_deserializeClassNameGet_0();
case -96306095: return bem_echo_0();
case -267583782: return bem_multiGet_0();
case 1064240293: return bem_sourceFileNameGet_0();
case 67128417: return bem_valuesGet_0();
case -1238312381: return bem_print_0();
case -1164456509: return bem_sizeGetDirect_0();
case -1978806157: return bem_slotsGet_0();
case -1823187999: return bem_notEmptyGet_0();
case 1770146810: return bem_serializeToString_0();
case -791198660: return bem_serializationIteratorGet_0();
case -1429730316: return bem_mapIteratorGet_0();
case 1703076999: return bem_fieldIteratorGet_0();
case -481458436: return bem_once_0();
case 892264865: return bem_multiGetDirect_0();
case -232339846: return bem_classNameGet_0();
case -798874989: return bem_keysGet_0();
case -1022717104: return bem_innerPutAddedGet_0();
case -2119859851: return bem_relGetDirect_0();
case 1582808224: return bem_sizeGet_0();
case 1361603917: return bem_create_0();
case 189063253: return bem_serializeContents_0();
case -2048244367: return bem_setIteratorGet_0();
case -223643989: return bem_baseNodeGetDirect_0();
case -877688854: return bem_baseNodeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -359417665: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 1230679491: return bem_slotsSetDirect_1(bevd_0);
case -1364328580: return bem_relSetDirect_1(bevd_0);
case 202685189: return bem_multiSet_1(bevd_0);
case -1973562246: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 789848846: return bem_copyTo_1(bevd_0);
case -1696224976: return bem_otherClass_1(bevd_0);
case 1460909587: return bem_moduSetDirect_1(bevd_0);
case -2012242772: return bem_slotsSet_1(bevd_0);
case -12288982: return bem_get_1(bevd_0);
case -1499772887: return bem_multiSetDirect_1(bevd_0);
case 114554925: return bem_addValue_1(bevd_0);
case 964070445: return bem_sizeSetDirect_1(bevd_0);
case 836379522: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 749786370: return bem_innerPutAddedSet_1(bevd_0);
case -256855558: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1247942086: return bem_relSet_1(bevd_0);
case -1378821005: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 361737303: return bem_has_1(bevd_0);
case -1234688151: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -554198110: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1142364960: return bem_delete_1(bevd_0);
case -2140330656: return bem_baseNodeSetDirect_1(bevd_0);
case -304012900: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1258943525: return bem_equals_1(bevd_0);
case 954777710: return bem_undefined_1(bevd_0);
case 736840047: return bem_sizeSet_1(bevd_0);
case -2018144381: return bem_sameType_1(bevd_0);
case -1120668425: return bem_sameClass_1(bevd_0);
case -701743241: return bem_put_1(bevd_0);
case -1980800018: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 952631001: return bem_undef_1(bevd_0);
case -1657467808: return bem_def_1(bevd_0);
case 1122895467: return bem_baseNodeSet_1(bevd_0);
case -1827158381: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 721379891: return bem_otherType_1(bevd_0);
case -2067033204: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1814510964: return bem_notEquals_1(bevd_0);
case -1411547316: return bem_sameObject_1(bevd_0);
case -1233404916: return bem_moduSet_1(bevd_0);
case -1555556152: return bem_defined_1(bevd_0);
case 1689607871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -133579010: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1466443085: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -750254672: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1191848195: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 514912045: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1583656022: return bem_put_2(bevd_0, bevd_1);
case -2072659817: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1041788971: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 84003596: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1162849638: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst = (BEC_2_9_3_ContainerMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_type;
}
}
