package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOReader extends BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOReader() { }

    public java.io.InputStream bevi_is;
   private static byte[] becc_BEC_2_2_6_IOReader_clname = {0x49,0x4F,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_2 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_3 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_8 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_2_6_IOReader bece_BEC_2_2_6_IOReader_bevs_inst;
public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_3_MathInt bevp_blockSize;
public BEC_2_2_6_IOReader bem_new_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
bevp_blockSize = (new BEC_2_4_3_MathInt(256));
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_extOpen_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_close_0() throws Throwable {

      if (this.bevi_is != null) {
        this.bevi_is.close();
        this.bevi_is = null;
      }
      bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_vfileGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) throws Throwable {
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_byteReaderGet_0() throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_2_10_IOByteReader()).bem_readerNew_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_byteReader_1(BEC_2_4_3_MathInt beva_blockSize) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_2_10_IOByteReader()).bem_readerBlockNew_2(this, beva_blockSize);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_1(BEC_2_4_6_TextString beva_readBuf) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_0;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_readIntoBuffer_2(beva_readBuf, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_2(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_readIntoBuffer_3(beva_readBuf, beva_at, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_3(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at, BEC_2_4_3_MathInt beva_readsz) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;

      int bevls_read = this.bevi_is.read(beva_readBuf.bevi_bytes, beva_at.bevi_int, beva_readBuf.bevi_bytes.length - beva_at.bevi_int);
      if (bevls_read < 0) {
        bevls_read = 0;
      }
      beva_readsz.bevi_int = bevls_read + beva_at.bevi_int;
      bevt_0_tmpany_phold = beva_readBuf.bem_sizeGet_0();
bevt_0_tmpany_phold.bevi_int = beva_readsz.bevi_int;
return beva_readsz;
} /*method end*/
public BEC_2_2_6_IOReader bem_copyData_3(BEC_2_2_6_IOWriter beva_outw, BEC_2_4_6_TextString beva_rwbufE, BEC_2_4_3_MathInt beva_rsz) throws Throwable {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_at = bece_BEC_2_2_6_IOReader_bevo_1;
while (true)
 /* Line: 266 */ {
bevt_1_tmpany_phold = bem_readIntoBuffer_3(beva_rwbufE, bevl_at, beva_rsz);
bevt_2_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_2;
if (bevt_1_tmpany_phold.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 266 */ {
beva_outw.bem_write_1(beva_rwbufE);
} /* Line: 267 */
 else  /* Line: 266 */ {
break;
} /* Line: 266 */
} /* Line: 266 */
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_copyData_1(BEC_2_2_6_IOWriter beva_outw) throws Throwable {
BEC_2_4_6_TextString bevl_rwbufE = null;
BEC_2_4_3_MathInt bevl_rsz = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(4096));
bevl_rwbufE = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_rsz = (new BEC_2_4_3_MathInt());
bem_copyData_3(beva_outw, bevl_rwbufE, bevl_rsz);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevp_blockSize);
bevt_0_tmpany_phold = bem_readBuffer_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_4_3_MathInt bevl_nowAt = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevl_at = (new BEC_2_4_3_MathInt(0));
bevl_nowAt = (new BEC_2_4_3_MathInt());
bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
while (true)
 /* Line: 285 */ {
if (bevl_nowAt.bevi_int > bevl_at.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevl_at.bevi_int = bevl_nowAt.bevi_int;
bevt_3_tmpany_phold = beva_builder.bem_capacityGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_subtract_1(bevl_at);
bevt_4_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_3;
if (bevt_2_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 287 */ {
bevt_7_tmpany_phold = bevl_at.bem_add_1(bevp_blockSize);
bevt_8_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_4;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_5;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_multiply_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_6;
bevl_nsize = bevt_5_tmpany_phold.bem_divide_1(bevt_10_tmpany_phold);
beva_builder.bem_capacitySet_1(bevl_nsize);
} /* Line: 289 */
bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
} /* Line: 291 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
return beva_builder;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferLine_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = bem_readBufferLine_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferLine_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_6_TextString bevl_crb = null;
BEC_2_4_6_TextString bevl_rbuf = null;
BEC_2_4_3_MathInt bevl_got = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_newlineGet_0();
bevl_crb = bevt_0_tmpany_phold.bem_addValue_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_rbuf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_3_tmpany_phold);
bevl_got = bem_readIntoBuffer_1(bevl_rbuf);
bevt_5_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_7;
if (bevl_got.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 307 */ {
beva_builder = null;
return beva_builder;
} /* Line: 309 */
beva_builder.bem_addValue_1(bevl_rbuf);
while (true)
 /* Line: 312 */ {
bevt_7_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_8;
if (bevl_got.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_8_tmpany_phold = bevl_rbuf.bem_equals_1(bevl_crb);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 313 */ {
return beva_builder;
} /* Line: 314 */
bevl_got = bem_readIntoBuffer_1(bevl_rbuf);
beva_builder.bem_addValue_1(bevl_rbuf);
} /* Line: 317 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
return beva_builder;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_readBuffer_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_readBuffer_1(beva_builder);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_readStringClose_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = bem_readString_0();
bem_close_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_2_6_IOReader bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_blockSizeGet_0() throws Throwable {
return bevp_blockSize;
} /*method end*/
public BEC_2_2_6_IOReader bem_blockSizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_blockSize = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {161, 162, 168, 204, 212, 212, 216, 216, 220, 220, 220, 220, 224, 224, 224, 260, 260, 261, 265, 266, 266, 266, 266, 267, 272, 272, 273, 274, 278, 278, 278, 282, 283, 284, 285, 285, 286, 287, 287, 287, 287, 287, 288, 288, 288, 288, 288, 288, 288, 289, 291, 293, 297, 297, 297, 304, 304, 304, 304, 305, 305, 306, 307, 307, 307, 308, 309, 311, 312, 312, 312, 313, 314, 316, 317, 319, 323, 323, 327, 327, 331, 332, 333, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 28, 37, 48, 49, 53, 54, 60, 61, 62, 63, 68, 69, 70, 80, 81, 82, 89, 92, 93, 94, 99, 100, 112, 113, 114, 115, 121, 122, 123, 140, 141, 142, 145, 150, 151, 152, 153, 154, 155, 160, 161, 162, 163, 164, 165, 166, 167, 168, 170, 176, 181, 182, 183, 198, 199, 200, 201, 202, 203, 204, 205, 206, 211, 212, 213, 215, 218, 219, 224, 225, 227, 229, 230, 236, 240, 241, 245, 246, 250, 251, 252, 255, 258, 262, 265};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 161 23
new 0 161 23
assign 1 162 24
new 0 162 24
assign 1 168 28
new 0 168 28
assign 1 204 37
new 0 204 37
assign 1 212 48
readerNew 1 212 48
return 1 212 49
assign 1 216 53
readerBlockNew 2 216 53
return 1 216 54
assign 1 220 60
new 0 220 60
assign 1 220 61
once 0 220 61
assign 1 220 62
readIntoBuffer 2 220 62
return 1 220 63
assign 1 224 68
new 0 224 68
assign 1 224 69
readIntoBuffer 3 224 69
return 1 224 70
assign 1 260 80
sizeGet 0 260 80
setValue 1 260 81
return 1 261 82
assign 1 265 89
new 0 265 89
assign 1 266 92
readIntoBuffer 3 266 92
assign 1 266 93
new 0 266 93
assign 1 266 94
greater 1 266 99
write 1 267 100
assign 1 272 112
new 0 272 112
assign 1 272 113
new 1 272 113
assign 1 273 114
new 0 273 114
copyData 3 274 115
assign 1 278 121
new 1 278 121
assign 1 278 122
readBuffer 1 278 122
return 1 278 123
assign 1 282 140
new 0 282 140
assign 1 283 141
new 0 283 141
readIntoBuffer 3 284 142
assign 1 285 145
greater 1 285 150
setValue 1 286 151
assign 1 287 152
capacityGet 0 287 152
assign 1 287 153
subtract 1 287 153
assign 1 287 154
new 0 287 154
assign 1 287 155
lesser 1 287 160
assign 1 288 161
add 1 288 161
assign 1 288 162
new 0 288 162
assign 1 288 163
add 1 288 163
assign 1 288 164
new 0 288 164
assign 1 288 165
multiply 1 288 165
assign 1 288 166
new 0 288 166
assign 1 288 167
divide 1 288 167
capacitySet 1 289 168
readIntoBuffer 3 291 170
return 1 293 176
assign 1 297 181
new 0 297 181
assign 1 297 182
readBufferLine 1 297 182
return 1 297 183
assign 1 304 198
new 0 304 198
assign 1 304 199
new 0 304 199
assign 1 304 200
newlineGet 0 304 200
assign 1 304 201
addValue 1 304 201
assign 1 305 202
new 0 305 202
assign 1 305 203
new 1 305 203
assign 1 306 204
readIntoBuffer 1 306 204
assign 1 307 205
new 0 307 205
assign 1 307 206
equals 1 307 211
assign 1 308 212
return 1 309 213
addValue 1 311 215
assign 1 312 218
new 0 312 218
assign 1 312 219
notEquals 1 312 224
assign 1 313 225
equals 1 313 225
return 1 314 227
assign 1 316 229
readIntoBuffer 1 316 229
addValue 1 317 230
return 1 319 236
assign 1 323 240
readBuffer 0 323 240
return 1 323 241
assign 1 327 245
readBuffer 1 327 245
return 1 327 246
assign 1 331 250
readString 0 331 250
close 0 332 251
return 1 333 252
return 1 0 255
assign 1 0 258
return 1 0 262
assign 1 0 265
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -748130189: return bem_echo_0();
case 1063828377: return bem_vfileGet_0();
case -1256903143: return bem_print_0();
case -1693411633: return bem_fieldIteratorGet_0();
case -165345418: return bem_readBuffer_0();
case -2128130409: return bem_close_0();
case -2089883321: return bem_new_0();
case 1029417943: return bem_readString_0();
case 721298840: return bem_serializationIteratorGet_0();
case 1330053746: return bem_classNameGet_0();
case -1666892068: return bem_once_0();
case 755335905: return bem_isClosedGet_0();
case 394710523: return bem_toAny_0();
case 978873391: return bem_deserializeClassNameGet_0();
case -1755437106: return bem_serializeContents_0();
case -266150550: return bem_many_0();
case -67323485: return bem_create_0();
case 1087310574: return bem_extOpen_0();
case 895906767: return bem_toString_0();
case -721291680: return bem_readBufferLine_0();
case -582877759: return bem_readStringClose_0();
case -907223016: return bem_iteratorGet_0();
case 648643859: return bem_sourceFileNameGet_0();
case 19655765: return bem_tagGet_0();
case 271563984: return bem_byteReaderGet_0();
case 1973388656: return bem_blockSizeGet_0();
case 1781926555: return bem_copy_0();
case 1740583826: return bem_serializeToString_0();
case 1782125853: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2097315666: return bem_sameClass_1(bevd_0);
case 2119054446: return bem_otherType_1(bevd_0);
case 8077181: return bem_equals_1(bevd_0);
case -1247136899: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -934181394: return bem_isClosedSet_1(bevd_0);
case -832551193: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 299341724: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1294060004: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -1804976263: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 803845413: return bem_def_1(bevd_0);
case -60444975: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -780023472: return bem_vfileSet_1(bevd_0);
case 1019423408: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -2142325185: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 381862580: return bem_otherClass_1(bevd_0);
case 1011228115: return bem_blockSizeSet_1(bevd_0);
case -1126679171: return bem_undef_1(bevd_0);
case -815969475: return bem_sameType_1(bevd_0);
case -1474365668: return bem_notEquals_1(bevd_0);
case 520199625: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1643294736: return bem_defined_1(bevd_0);
case 269512976: return bem_copyTo_1(bevd_0);
case -1211310163: return bem_undefined_1(bevd_0);
case -254385268: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 965023375: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1813120815: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1138773197: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 459867300: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1853682603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -133639356: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1666758230: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -180252519: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1082039705: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1196404771: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -2079206653: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_6_IOReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst = (BEC_2_2_6_IOReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst;
}
}
