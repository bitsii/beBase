package be;
/* IO:File: source/extended/Properties.be */
public final class BEC_2_6_3_SystemEnv extends BEC_2_9_11_ContainerPropertyMap {
public BEC_2_6_3_SystemEnv() { }
private static byte[] becc_BEC_2_6_3_SystemEnv_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x6E,0x76};
private static byte[] becc_BEC_2_6_3_SystemEnv_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_3_SystemEnv_bels_0 = {0x3D};
public static BEC_2_6_3_SystemEnv bece_BEC_2_6_3_SystemEnv_bevs_inst;

public static BET_2_6_3_SystemEnv bece_BEC_2_6_3_SystemEnv_bevs_type;

public BEC_2_6_3_SystemEnv bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_default_0() throws Throwable {
super.bem_new_0();
return this;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_set_2(BEC_2_4_6_TextString beva_key, BEC_2_4_6_TextString beva_value) throws Throwable {
bevp_map.bem_put_2(beva_key, beva_value);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_get_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevl_toRet == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 90*/ {
bevp_map.bem_put_2(beva_key, bevl_toRet);
} /* Line: 91*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_getCached_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_map.bem_has_1(beva_key);
if (bevt_0_ta_ph.bevi_bool)/* Line: 97*/ {
bevt_1_ta_ph = bevp_map.bem_get_1(beva_key);
return (BEC_2_4_6_TextString) bevt_1_ta_ph;
} /* Line: 97*/
bevt_2_ta_ph = bem_get_1(beva_key);
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_unset_1(BEC_2_4_6_TextString beva_key) throws Throwable {
bevp_map.bem_delete_1(beva_key);
return this;
} /*method end*/
public BEC_2_6_3_SystemEnv bem_load_0() throws Throwable {
BEC_2_4_6_TextString bevl_next = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_6_TextString bevl_k = null;
BEC_2_4_6_TextString bevl_v = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_SystemEnv_bels_0));
bevl_p = bevl_next.bem_find_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_k = bevl_next.bem_substring_2(bevt_1_ta_ph, bevl_p);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevl_p.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevl_next.bem_sizeGet_0();
bevl_v = bevl_next.bem_substring_2(bevt_2_ta_ph, bevt_4_ta_ph);
bevp_map.bem_put_2(bevl_k, bevl_v);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bem_load_0();
bevt_0_ta_ph = bevp_map.bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_cwdGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_cwd = null;
return bevl_cwd;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_workingDirectoryGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_cwdGet_0();
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {58, 69, 90, 90, 91, 93, 97, 97, 97, 98, 98, 109, 126, 126, 127, 127, 128, 128, 128, 128, 129, 138, 139, 139, 165, 169, 169, 169};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 23, 29, 34, 35, 37, 43, 45, 46, 48, 49, 52, 65, 66, 67, 68, 69, 70, 71, 72, 73, 78, 79, 80, 84, 89, 90, 91};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 58 19
put 2 69 23
assign 1 90 29
def 1 90 34
put 2 91 35
return 1 93 37
assign 1 97 43
has 1 97 43
assign 1 97 45
get 1 97 45
return 1 97 46
assign 1 98 48
get 1 98 48
return 1 98 49
delete 1 109 52
assign 1 126 65
new 0 126 65
assign 1 126 66
find 1 126 66
assign 1 127 67
new 0 127 67
assign 1 127 68
substring 2 127 68
assign 1 128 69
new 0 128 69
assign 1 128 70
add 1 128 70
assign 1 128 71
sizeGet 0 128 71
assign 1 128 72
substring 2 128 72
put 2 129 73
load 0 138 78
assign 1 139 79
iteratorGet 0 139 79
return 1 139 80
return 1 165 84
assign 1 169 89
cwdGet 0 169 89
assign 1 169 90
apNew 1 169 90
return 1 169 91
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 967234853: return bem_fieldIteratorGet_0();
case 766881626: return bem_print_0();
case 941604947: return bem_cwdGet_0();
case 1955915393: return bem_fieldNamesGet_0();
case 509361355: return bem_once_0();
case -194416815: return bem_tagGet_0();
case -1455899172: return bem_create_0();
case -1715766851: return bem_toAny_0();
case -533443118: return bem_many_0();
case 549983454: return bem_mapGet_0();
case -180175097: return bem_classNameGet_0();
case -1034571137: return bem_default_0();
case -1006708777: return bem_load_0();
case 378307569: return bem_copy_0();
case 1797865600: return bem_new_0();
case 280712282: return bem_toString_0();
case -665649433: return bem_serializeContents_0();
case -754275027: return bem_workingDirectoryGet_0();
case -119499799: return bem_serializationIteratorGet_0();
case 1777587047: return bem_hashGet_0();
case 2011135674: return bem_iteratorGet_0();
case 617445256: return bem_sourceFileNameGet_0();
case -1700432699: return bem_deserializeClassNameGet_0();
case -1460004963: return bem_mapGetDirect_0();
case 1095297479: return bem_echo_0();
case -1724453868: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -445857610: return bem_notEquals_1(bevd_0);
case -87431730: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 855551287: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 16229423: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 644093837: return bem_undef_1(bevd_0);
case 69051240: return bem_undefined_1(bevd_0);
case -524226263: return bem_sameType_1(bevd_0);
case -1234151671: return bem_def_1(bevd_0);
case 648297031: return bem_mapSet_1((BEC_2_9_3_ContainerMap) bevd_0);
case 988667784: return bem_sameClass_1(bevd_0);
case 2096748739: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1825855108: return bem_getCached_1((BEC_2_4_6_TextString) bevd_0);
case 1727403006: return bem_sameObject_1(bevd_0);
case -1051960229: return bem_copyTo_1(bevd_0);
case 539403699: return bem_otherType_1(bevd_0);
case 1425595525: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2122901700: return bem_unset_1((BEC_2_4_6_TextString) bevd_0);
case 1698883170: return bem_otherClass_1(bevd_0);
case 906320876: return bem_defined_1(bevd_0);
case 198122111: return bem_mapSetDirect_1(bevd_0);
case -774009453: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 214448919: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704613584: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 541728737: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1271001996: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2084752424: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1676398857: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2142300911: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 274379488: return bem_set_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_SystemEnv_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_2_6_3_SystemEnv_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_SystemEnv();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_SystemEnv.bece_BEC_2_6_3_SystemEnv_bevs_inst = (BEC_2_6_3_SystemEnv) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_SystemEnv.bece_BEC_2_6_3_SystemEnv_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_SystemEnv.bece_BEC_2_6_3_SystemEnv_bevs_type;
}
}
